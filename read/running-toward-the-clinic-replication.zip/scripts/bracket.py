"""T13: one rule at both ends of the hospital bracket.

Three rules were mixed in one sentence.  This computes each rule COMPLETE -- both ends --
from the inputs the paper already prints, so nothing is estimated.

Inputs, all printed in the paper:
  excess deaths, authors' own count      42 and 67, over 74 attacks
  main specification                     effect 0.0077, SE 0.0042   (p = 0.07)
  more adverse specification             effect 0.0123, SE 0.0047
  implied exposed patients               42/0.0077 and 67/0.0123
  conversions                            displaced ceiling d = 30/365.25; averted 21.62 yr
"""
A = 74                     # attacks
DELTA = 30.0 / 365.25      # displaced-death ceiling, years
SE70 = 21.62               # WHO standard loss, ages 70-74
Z = 1.96

specs = {
    "main (p = 0.07)":  dict(b=0.0077, se=0.0042, deaths=42),
    "more adverse":     dict(b=0.0123, se=0.0047, deaths=67),
}
for name, s in specs.items():
    s["N"] = s["deaths"] / s["b"]          # implied exposed patients
    s["per_attack"] = s["N"] / A
    s["lo"] = s["b"] - Z * s["se"]
    s["hi"] = s["b"] + Z * s["se"]

print("=" * 78)
print("T13  the hospital bracket, one rule at a time, both ends")
print("=" * 78)
print(f"{'specification':<18}{'effect':>8}{'95% lo':>10}{'95% hi':>9}{'implied N':>11}{'N/attack':>10}")
for n, s in specs.items():
    print(f"{n:<18}{s['b']:>8.4f}{s['lo']:>10.6f}{s['hi']:>9.6f}{s['N']:>11.1f}{s['per_attack']:>10.2f}")

def dalys(deaths_per_attack, ell):
    return deaths_per_attack * ell

print()
print("RULE 1 -- point estimates (the authors' own counts).  d = 42/74 to 67/74.")
d_lo, d_hi = 42 / A, 67 / A
print(f"  d = {d_lo:.4f} to {d_hi:.4f}")
print(f"  lower end  (fewest deaths x displaced ceiling): {dalys(d_lo, DELTA):.5f} DALY/attack")
print(f"  upper end  (most deaths x averted standard loss): {dalys(d_hi, SE70):.3f} DALY/attack")
print(f"  -> bracket about {dalys(d_lo, DELTA):.2f}k to {dalys(d_hi, SE70):.0f}k.  Lower region NOT empty.")

print()
print("RULE 2 -- sampling limits, each specification on its own.")
for n, s in specs.items():
    lo_d = max(0.0, s["lo"]) * s["per_attack"]
    hi_d = s["hi"] * s["per_attack"]
    lo_dal = dalys(lo_d, DELTA)
    hi_dal = dalys(hi_d, SE70)
    empty = " (lower region EMPTY: the interval includes zero)" if s["lo"] <= 0 else ""
    print(f"  {n}:")
    print(f"    deaths/attack at the limits: {lo_d:.4f} to {hi_d:.4f}")
    print(f"    bracket: {lo_dal:.5f}k to {hi_dal:.2f}k{empty}")

print()
print("The paper's printed figures, checked:")
print(f"  about 20k   = 67/74 x 21.62                  = {dalys(d_hi, SE70):.3f}")
print(f"  about 34k   = adverse 95% hi x N/attack x SE = {dalys(specs['more adverse']['hi']*specs['more adverse']['per_attack'], SE70):.3f}")
print(f"  10.9k       = 67/74 x 12                     = {dalys(d_hi, 12.0):.3f}")
print(f"  under 0.05k = 42/74 x delta                  = {dalys(d_lo, DELTA):.5f}")
print("=" * 78)
