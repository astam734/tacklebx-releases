#!/usr/bin/env python3
"""The level-set half of "R3 cannot sign the facility comparison, and the facility comparison
cannot sign R3" (§4a.5, A-open item 4).

The speed-set half is proved in the paper: the hazard's elasticity decides R3's sign and is
absent from the facility rule. The level-set half was *stated without a counterexample*, which
is what A-open item 4 records and what both reads of 27 October called the paper's most material
mathematical overclaim. This script supplies the counterexamples, in both directions, by
building the loss from the set-up rather than from any printed formula.

Level-set, ramp-on, convention A (the hazard profile scales with the misuse distance):

    h_M(c) = hhat(c / K_M),   c = min(s t, K_M)
    C_M(s) = int_0^{t_D} h_M(min(s t, K_M)) dt + hpost * (L - t_D),
    t_D    = chi_D * K_D / s + m_D * T_D.

Direction 1 (R3 does not sign the facility comparison). Hold a facility move that shortens the
defence distance alone (dK_M = 0, dK_D < 0). Its sign is the sign of hhat(1) - hpost, because
shortening K_D only moves t_D along the plateau. Now move K_D across the two-distance boundary
K_D[h(K_M) - hpost] = K_M[h(K_M) - hbar_M]: R3 = dC_M/ds changes sign there while the facility
move keeps helping. So the sign of R3 does not determine the facility comparison.

Direction 2 (the facility comparison does not sign R3). Hold K_D where R3 < 0 and compare two
facility moves of the same size, one in K_D alone and one in K_M alone. Under convention A a
cut to K_M compresses the profile, and the two moves differ in sign while R3 is untouched.
"""
MIN_STEP = 1e-6


def loss(s, K_M, K_D, L, hpost, chi_D, m_D, T_D, hhat, n=40_000):
    """C_M built from the definition: Simpson on each smooth piece, kink at tau_M."""
    t_D = chi_D * K_D / s + m_D * T_D
    if t_D > L:
        t_D = L
    tau_M = K_M / s
    pieces = []
    if tau_M < t_D:                      # ramp then plateau
        pieces.append((0.0, tau_M, lambda t: hhat(s * t / K_M)))
        pieces.append((tau_M, t_D, lambda t: hhat(1.0)))
    else:                                 # the whole window is ramp
        pieces.append((0.0, t_D, lambda t: hhat(s * t / K_M)))
    total = 0.0
    for lo, hi, f in pieces:
        if hi - lo < MIN_STEP:
            continue
        m = n if n % 2 == 0 else n + 1
        h = (hi - lo) / m
        acc = f(lo) + f(hi)
        for i in range(1, m):
            acc += (4 if i % 2 else 2) * f(lo + i * h)
        total += acc * h / 3
    return total + hpost * (L - t_D)


def dC_ds(args, eps=1e-5):
    s = args[0]
    hi = loss(s + eps, *args[1:])
    lo = loss(s - eps, *args[1:])
    return (hi - lo) / (2 * eps)


def main():
    # A nondecreasing, continuous profile on [0, 1] with hhat(1) = 1.
    hhat = lambda x: min(max(x, 0.0), 1.0) ** 2
    hbar_coef = 1 / 3            # int_0^1 x^2 dx, so hbar_M = hhat(1)/3 under convention A

    K_M, L, hpost = 1.0, 6.0, 0.20
    chi_D, m_D, T_D = 1.0, 1.0, 1.00   # large enough that t_D >= tau_M across the row,
                                        # which is R3's stated regime tau_M <= t_D < L
    s = 0.5

    # the two-distance boundary: K_D[h(K_M) - hpost] = K_M[h(K_M) - hbar_M]
    K_D_star = K_M * (1.0 - hbar_coef) / (1.0 - hpost)
    print(f"profile hhat(x) = x^2 on [0,1];  hhat(1) = 1, hbar_M = {hbar_coef:.4f}, hpost = {hpost}")
    print(f"two-distance boundary at K_D* = {K_D_star:.4f}")
    print(f"regime check: tau_M = {K_M/s:.3f}, t_D ranges over "
          f"{chi_D*0.60/s + m_D*T_D:.3f} to {chi_D*1.40/s + m_D*T_D:.3f}, L = {L}\n")
    print("Direction 1: the facility move (dK_M = 0, dK_D < 0) against R3's sign\n")
    print(f"  {'K_D':>8} {'R3 = dC_M/ds':>14} {'facility dC_M':>16} {'same sign?':>11}")
    seen = set()
    for K_D in (0.60, 0.75, K_D_star, 1.00, 1.40):
        base = (s, K_M, K_D, L, hpost, chi_D, m_D, T_D, hhat)
        r3 = dC_ds(base)
        dK = -0.05
        fac = loss(s, K_M, K_D + dK, L, hpost, chi_D, m_D, T_D, hhat) - loss(*base)
        print(f"  {K_D:8.4f} {r3:14.6f} {fac:16.6f} {'yes' if r3*fac > 0 else 'no':>11}")
        seen.add((r3 > 0, fac > 0))
    print()
    facs = {f for _, f in seen}
    r3s = {r for r, _ in seen}
    print(f"  R3's sign takes {len(r3s)} value(s) over the row; the facility move's sign takes {len(facs)}.")
    if len(r3s) == 2 and len(facs) == 1:
        print("  R3 flips while the facility comparison does not: R3's sign does not determine it. QED(1)")
    else:
        print("  NOT a counterexample at these parameters.")

    print("\nDirection 2: two facility moves of equal size at one K_D where R3 < 0\n")
    K_D = 1.00
    base = (s, K_M, K_D, L, hpost, chi_D, m_D, T_D, hhat)
    r3 = dC_ds(base)
    assert r3 < 0, f"pick a K_D above the boundary; R3 = {r3}"
    d = -0.05
    only_KD = loss(s, K_M, K_D + d, L, hpost, chi_D, m_D, T_D, hhat) - loss(*base)
    only_KM = loss(s, K_M + d, K_D, L, hpost, chi_D, m_D, T_D, hhat) - loss(*base)
    print(f"  R3 = {r3:.6f}  (negative, so acceleration lowers misuse loss here)")
    print(f"  move in K_D alone, dK_D = {d}: dC_M = {only_KD:+.6f}")
    print(f"  move in K_M alone, dK_M = {d}: dC_M = {only_KM:+.6f}")
    if only_KD * only_KM < 0:
        print("  Two facility moves of the same size differ in sign at one R3 sign:")
        print("  the facility comparison does not determine R3 either. QED(2)")
    else:
        print("  NOT a counterexample at these parameters.")


if __name__ == "__main__":
    main()
