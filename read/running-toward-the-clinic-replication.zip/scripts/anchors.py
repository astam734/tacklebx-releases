"""T12: what a MARGINAL ledger needs per displaced death, under WHO's own unit.

The ledger differences two states of the world.  WHO books a death at age a at the
reference-table standard loss SE(a).  So one displaced death contributes
    SE(a) - SE(a + delta),
not SE(a).  Two questions, both answerable without a fitted life table:

  (1) Is that difference bounded by delta?   d SE/da = mu(a)SE(a) - 1 > -1, so YES, strictly.
  (2) How close to delta is it at ages 70-74 in a LOW-mortality reference table?

Calibrated to the figure the paper uses: WHO GHE standard loss at 70-74 = 21.62 years,
read as SE(72) = 21.62.  Gompertz-Makeham hazard, shape fitted to that one number.
"""
import math

def survival_factory(a0, target_e, b):
    """mu(x) = A*exp(b*(x-a0)); A chosen so that e(a0) = target_e."""
    def e_of(A, a):
        # integrate S(x)/S(a) from a upward
        H = lambda x: (A / b) * (math.exp(b * (x - a0)) - 1.0)   # cumulative hazard from a0
        tot, h, x = 0.0, 0.002, a
        Ha = H(a)
        while x < a0 + 80:
            s1 = math.exp(-(H(x) - Ha)); s2 = math.exp(-(H(x + h) - Ha))
            tot += 0.5 * (s1 + s2) * h
            if s2 < 1e-12: break
            x += h
        return tot
    lo, hi = 1e-8, 1.0
    for _ in range(200):
        mid = math.sqrt(lo * hi)
        if e_of(mid, a0) > target_e: lo = mid
        else: hi = mid
    A = math.sqrt(lo * hi)
    return A, (lambda a: e_of(A, a))

AGE, E72, DELTA = 72.0, 21.62, 30.0 / 365.25
print("=" * 74)
print("T12  marginal DALY loss per DISPLACED death, WHO unit, delta = 30 days")
print(f"calibrated so that SE({AGE:.0f}) = {E72} years, the figure the paper uses")
print("=" * 74)
print(f"{'Gompertz b':>11} {'mu(72)':>9} {'SE(72)':>8} {'SE(72+d)':>9} {'difference':>11} {'as % of d':>10}")
for b in (0.06, 0.08, 0.10, 0.12):
    A, e = survival_factory(AGE, E72, b)
    d = e(AGE) - e(AGE + DELTA)
    print(f"{b:>11.2f} {A:>9.4f} {e(AGE):>8.3f} {e(AGE+DELTA):>9.3f} {d:>11.5f} {100*d/DELTA:>9.1f}%")
print()
print(f"delta itself = {DELTA:.5f} years = 30.0 days")
print("Bound, analytic and life-table-free:  d SE/da = mu*SE - 1 > -1, so")
print("SE(a) - SE(a+delta) < delta ALWAYS.  The paper's low anchor, ell <= delta,")
print("is therefore already an upper bound for the displacement counterfactual.")
print()
print("Per-attack figures at d = 0.568-0.905 excess deaths:")
for label, ell in (("displacement bound (delta)", DELTA),
                   ("standard loss at 70-74", 21.62),
                   ("assumed actual expectancy", 12.0)):
    print(f"  {label:<28} ell={ell:>7.4f} yr -> {0.568*ell:>7.3f} to {0.905*ell:>7.3f} DALY")
print(f"  ratio, standard loss to displacement bound: {21.62/DELTA:.0f}x")
print("=" * 74)
