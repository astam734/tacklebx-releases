# Running Toward the Clinic: replication files

Files behind the technical paper "Running Toward the Clinic: Speed, Biological Risk and Health in the AI Transition" (Allan C. Stam, working paper).

- `lean/`: the Lean 4 source for the paper's machine-checked results (project `BioPaperProofs`; toolchain and library versions are pinned in `lean-toolchain` and `lake-manifest.json`). `lean/README.md` says how to build it and what each file holds. `build-and-audit-2026-10-28.txt` is the output of the last recorded build and axiom audit. Lean was not rebuilt when these files were packaged.
- `scripts/`: three scripts the paper names: `bracket.py` and `anchors.py` (the arithmetic of the hospital bound) and `facility_r3_levelset.py` (the counterexample of Appendix A, Section A.7).
- `numerical-check/`: the numerical derivative check (`check.py`) with its log and its saved results, from the run of 26 October 2026. The paper's Appendix B says what this check tested and what it did not.

The paper's appendix "What is machine-checked" states, result by result, what each proof assumes. A theorem's presence here shows that it was proved as stated in Lean, not that the statement is the claim made in words.

A note on the comments in these files. The source files are packaged as they were when the recorded build and the recorded numerical run were made, so their comments are unedited. Some refer to working documents that are not part of this package (a proof inventory, and derivation notes labelled MC3). Some name the AI models that produced a derivation or a proof ("Opus", "Sol"); the paper's Declarations describe how AI models were used. `check.py` needs Python 3 and SciPy; the `.venv` path in its header is the working environment's and can be ignored.
