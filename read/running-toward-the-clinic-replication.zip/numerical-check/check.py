"""NUMCHECK: finite-difference test of the MODEL-CHECK-3 closed forms.

Misuse loss V_M*C_M is built by direct numerical integration of the hazard
over [0, L]; derivatives come from central finite differences of that
integral; the closed forms are the ones stated in MC3-COMPARE / MC3-OPUS /
MC3-SOL. Run:  .venv/bin/python check.py   (writes results.json beside it)
"""
import json
import math
import os
import random

from scipy.integrate import quad

TOL = 1e-6          # pass threshold on the error measures below
FD_REL = 1e-5       # central-difference step, relative to the parameter
KREF = 1.5          # convention B: h(c) = g(c / KREF), fixed in c
X_STEP = 0.6        # location (in x) of the step / logistic jump


def _logistic(x):
    return 1.0 / (1.0 + math.exp(-40.0 * (x - X_STEP)))


# name: (g(x), g'(x), jump location or None). Under A, Gamma = g on [0, 1].
SHAPES = {
    "linear":   (lambda x: 0.2 + x,                       lambda x: 1.0,                                   None),
    "concave":  (lambda x: 1.05 - math.exp(-3 * x),       lambda x: 3 * math.exp(-3 * x),                  None),
    "convex":   (lambda x: 0.05 + x ** 3,                 lambda x: 3 * x * x,                             None),
    "logistic": (lambda x: 0.05 + _logistic(x),           lambda x: 40 * _logistic(x) * (1 - _logistic(x)), X_STEP),
    "step":     (lambda x: 0.1 + (1.0 if x >= X_STEP else 0.0), lambda x: 0.0,                             X_STEP),
    "hump":     (lambda x: 0.05 + 4 * x * (1 - x),        lambda x: 4 - 8 * x,                             None),
    "flat":     (lambda x: 0.7,                           lambda x: 0.0,                                   None),
}


# ---------------------------------------------------------------- the model

def H(p):
    return p["H0"] * p["s"] ** p["eps"]


def t_D(p):
    k = p["KD"] if p["branch"] == "own" else p["KM"]
    return max(k / p["s"], (1 - p["mD"]) * p["TD"]) + p["mD"] * p["TD"]


def chi(p):
    k = p["KD"] if p["branch"] == "own" else p["KM"]
    return 1.0 if k / p["s"] > (1 - p["mD"]) * p["TD"] else 0.0


def level_h(p, c, K):
    """Level-indexed hazard h(c; K_M) under the convention in p."""
    g = SHAPES[p["shape"]][0]
    return g(c / K) if p["conv"] == "A" else g(c / KREF)


def hazard(p, t):
    s, K = p["s"], p["KM"]
    arrived = s * t >= K
    if p["expo"] == "arrival" and not arrived:
        return 0.0
    if t >= t_D(p):
        return p["P"]
    if p["spec"] == "speed":
        return H(p)
    return level_h(p, min(s * t, K), K)


def breakpoints(p):
    s, K, L = p["s"], p["KM"], p["L"]
    pts = [K / s, t_D(p)]
    jump = SHAPES[p["shape"]][2] if p["spec"] == "level" else None
    if jump is not None:
        pts.append(jump * (K if p["conv"] == "A" else KREF) / s)
    return sorted({x for x in pts if 0 < x < L})


def loss(p):
    val, _ = quad(lambda t: hazard(p, t), 0.0, p["L"], points=breakpoints(p) or None,
                  limit=500, epsabs=1e-14, epsrel=1e-13)
    return p["VM"] * val


def signature(p):
    """Regime signature: changes iff a kink/boundary is crossed."""
    s, K, L = p["s"], p["KM"], p["L"]
    tau, td = K / s, t_D(p)
    k = p["KD"] if p["branch"] == "own" else K
    sig = [td > tau, td < L, tau < L, k / s > (1 - p["mD"]) * p["TD"]]
    jump = SHAPES[p["shape"]][2] if p["spec"] == "level" else None
    if jump is not None:
        tj = jump * (K if p["conv"] == "A" else KREF) / s
        sig += [tj < tau, tj < td, tj < L]
    return tuple(sig)


def with_(p, **kw):
    q = dict(p)
    q.update(kw)
    return q


def fd(p, key, rel=FD_REL):
    h = rel * max(abs(p[key]), 1e-3)
    lo, hi = with_(p, **{key: p[key] - h}), with_(p, **{key: p[key] + h})
    crosses = len({signature(lo), signature(p), signature(hi)}) > 1
    return (loss(hi) - loss(lo)) / (2 * h), crosses


def regime(p):
    tau, td, L = p["KM"] / p["s"], t_D(p), p["L"]
    if td <= tau:
        return "def_before_arrival" if td < L else "truncation"
    if td >= L:
        return "truncation" if tau >= L else "no_closure"
    return "interior"


# ---------------------------------------------------------- closed forms

def gamma_int(p, a, b):
    g = SHAPES[p["shape"]][0]
    jump = SHAPES[p["shape"]][2]
    pts = [jump] if jump is not None and a < jump < b else None
    return quad(g, a, b, points=pts, limit=500, epsabs=1e-14, epsrel=1e-13)[0]


def primitives(p):
    """h_plat, hbar (ramp average), h'(K_M) under B."""
    if p["spec"] == "speed":
        return H(p), H(p), 0.0
    g, gp, _ = SHAPES[p["shape"]]
    K = p["KM"]
    if p["conv"] == "A":
        return g(1.0), gamma_int(p, 0.0, 1.0), 0.0
    return g(K / KREF), KREF / K * gamma_int(p, 0.0, K / KREF), gp(K / KREF) / KREF


def cf_interior(p, td=None):
    """MC3-COMPARE's derived forms, own-distance interior tau_M < t_D < L."""
    s, VM, P = p["s"], p["VM"], p["P"]
    tau, X = p["KM"] / s, chi(p)
    td = t_D(p) if td is None else td
    hp, hbar, hpr = primitives(p)
    dKD = VM * X / s * (hp - P)                                   # (a), all four cases
    key = (p["spec"], p["expo"], p["conv"])
    if p["spec"] == "speed":
        dKM = 0.0 if p["expo"] == "ramp" else -VM * hp / s
    elif key[1:] == ("ramp", "A"):
        dKM = -VM * (hp - hbar) / s                               # Opus, A
    elif key[1:] == ("ramp", "B"):
        dKM = VM * (td - tau) * hpr                               # Sol, B
    elif key[1:] == ("arrival", "A"):
        dKM = -VM * hp / s                                        # Opus, A
    else:
        dKM = VM * ((td - tau) * hpr - hp / s)                    # Sol, B
    return dKM, dKD


def cf_general(p):
    """MC3-COMPARE (c), the convention-free formula, with the partials of
    h(c; K_M) taken numerically. Level-set only."""
    s, VM, K = p["s"], p["VM"], p["KM"]
    tau, td = K / s, t_D(p)
    e = 1e-6 * K
    dpl = (level_h(p, K + e, K + e) - level_h(p, K - e, K - e)) / (2 * e)
    tail = (td - tau) * dpl
    if p["expo"] == "arrival":
        return VM * (tail - level_h(p, K, K) / s)
    if SHAPES[p["shape"]][2] is not None and p["conv"] == "A":
        # the jump moves with K under A, so FD-in-K under the integral misses its
        # distributional part; use the by-parts form of the same first term
        ramp = -(level_h(p, K, K) - gamma_int(p, 0.0, 1.0))
        return VM * (ramp / s + tail)
    integrand = lambda c: (level_h(p, c, K + e) - level_h(p, c, K - e)) / (2 * e)
    pts = [X_STEP * KREF] if SHAPES[p["shape"]][2] is not None and X_STEP * KREF < K else None
    ramp = quad(integrand, 0.0, K, points=pts, limit=500, epsabs=1e-13)[0]
    return VM * (ramp / s + tail)


def cf_regime(p):
    """Forms the seats state for the non-interior regimes, plus the K_M-paced
    branch. Returns (dKM, dKD, source)."""
    s, VM, P, K, L = p["s"], p["VM"], p["P"], p["KM"], p["L"]
    tau, td, X = K / s, t_D(p), chi(p)
    hp, hbar, hpr = primitives(p)
    reg = regime(p)
    if p["branch"] == "paced":
        q = with_(p, branch="own", KD=K)        # same t_D, independent coordinates
        dKM, dKD = cf_interior(q)
        return dKM + dKD, 0.0, "paced: own dK_M + dK_D (Opus 1.1 / Sol total)"
    if reg == "interior":
        dKM, dKD = cf_interior(p)
        return dKM, dKD, "interior"
    if reg == "no_closure":
        dKM, _ = cf_interior(p, td=L)
        return dKM, 0.0, "no closure: t_D -> L, dK_D = 0 (Opus 1, Sol t_wedge)"
    if reg == "truncation":
        if p["spec"] == "level" and p["expo"] == "ramp" and p["conv"] == "A":
            xL = s * L / K
            ramp = -(xL * SHAPES[p["shape"]][0](xL) - gamma_int(p, 0.0, xL)) / s
            return VM * ramp, 0.0, "truncation A (Opus 1, by parts)"
        return 0.0, 0.0, "truncation (Opus 1: arrival 0, speed 0; B ramp: no K_M)"
    # defence before arrival, t_D < tau_M, t_D < L
    if p["spec"] == "speed":
        if p["expo"] == "ramp":
            return 0.0, VM * X / s * (hp - P), "def<arr speed ramp (Opus 2)"
        return (-VM * P / s if tau < L else 0.0), 0.0, "def<arr arrival: C=P(L-tau)+ (Opus 2)"
    if p["expo"] == "arrival":
        return (-VM * P / s if tau < L else 0.0), 0.0, "def<arr arrival: C=P(L-tau)+ (Opus 2)"
    h_td = level_h(p, s * td, K)
    dKD = VM * X / s * (h_td - P)                     # Opus 2 / Sol (P=0)
    if p["conv"] == "B":
        return 0.0, dKD, "def<arr level ramp B (Sol: dK_M = 0)"
    xd = s * td / K
    ramp = -(xd * SHAPES[p["shape"]][0](xd) - gamma_int(p, 0.0, xd)) / s
    return VM * ramp, dKD, "def<arr level ramp A (derived here: dK_M != 0)"


# ------------------------------------------------------------- draws

def draw_base(rng, spec, expo, conv, shape):
    return dict(spec=spec, expo=expo, conv=conv, shape=shape, branch="own",
                s=rng.uniform(0.5, 2.0), KM=rng.uniform(0.3, 1.35),
                mD=rng.uniform(0.0, 1.0), TD=rng.uniform(0.2, 2.0),
                VM=rng.uniform(0.5, 3.0), H0=rng.uniform(0.2, 2.0),
                eps=rng.uniform(0.0, 2.0), P=0.0, KD=1.0, L=10.0)


def far_from_kinks(p, margin=1e-3):
    s, K, L = p["s"], p["KM"], p["L"]
    tau, td = K / s, t_D(p)
    k = p["KD"] if p["branch"] == "own" else K
    gaps = [td - tau, L - td, L - tau, k / s - (1 - p["mD"]) * p["TD"]]
    jump = SHAPES[p["shape"]][2] if p["spec"] == "level" else None
    if jump is not None:
        tj = jump * (K if p["conv"] == "A" else KREF) / s
        gaps += [tj - tau, tj - td, tj - L]
    return all(abs(g) > margin * max(1.0, L) for g in gaps)


def draw_interior(rng, spec, expo, conv, shape, chi_D=1, P_mode="zero"):
    while True:
        p = draw_base(rng, spec, expo, conv, shape)
        tau = p["KM"] / p["s"]
        if chi_D:
            p["KD"] = p["s"] * (tau + rng.uniform(0.05, 1.5))
        else:   # adoption branch: K_D/s below (1 - mD) T_D, t_D still > tau
            p["mD"] = rng.uniform(0.0, 0.6)
            p["KD"] = p["s"] * (1 - p["mD"]) * p["TD"] * rng.uniform(0.2, 0.95)
        p["L"] = t_D(p) + rng.uniform(0.2, 2.0)
        hp = primitives(p)[0]
        p["P"] = {"zero": 0.0, "low": rng.uniform(0.0, 0.8) * hp,
                  "high": rng.uniform(1.1, 2.0) * hp}[P_mode]
        if regime(p) == "interior" and chi(p) == chi_D and far_from_kinks(p):
            return p


# ------------------------------------------------------------- tests

COMBOS = [(spec, expo, conv, shape)
          for spec in ("level", "speed") for expo in ("ramp", "arrival")
          for conv in ("A", "B")
          for shape in (SHAPES if spec == "level" else ["linear"])]


def err(num, cf, scale):
    return abs(num - cf) / max(abs(cf), scale)


def scale_of(p):
    hp, hbar, _ = primitives(p)
    return p["VM"] * max(abs(hp), abs(hbar), abs(p["P"]), 1e-9) / p["s"]


def label(p):
    return f'{p["spec"]}/{p["expo"]}/{p["conv"]}/{p["shape"]}'


def brief(p):
    keys = ("s", "KM", "KD", "L", "TD", "mD", "P", "VM", "H0", "eps")
    return {k: round(p[k], 6) for k in keys} | {"tau_M": round(p["KM"] / p["s"], 6),
                                                 "t_D": round(t_D(p), 6), "chi_D": chi(p)}


def t1_interior(rng, n=12):
    """Closed forms vs FD at interior own-distance draws."""
    rows, bad = {}, []
    for combo in COMBOS:
        for P_mode in ("zero", "low", "high"):
            for chi_D in (1, 0):
                for _ in range(n):
                    p = draw_interior(rng, *combo, chi_D=chi_D, P_mode=P_mode)
                    nKM, cKM = fd(p, "KM")
                    nKD, cKD = fd(p, "KD")
                    fKM, fKD = cf_interior(p)
                    sc = scale_of(p)
                    checks = [("dK_M", nKM, fKM, cKM), ("dK_D", nKD, fKD, cKD)]
                    if p["spec"] == "level":
                        checks.append(("dK_M general (c)", nKM, cf_general(p), cKM))
                    for name, num, cf, crossed in checks:
                        key = (combo[0], combo[1], combo[2] if combo[0] == "level" else "-", name)
                        e = err(num, cf, sc)
                        rows.setdefault(key, []).append(e)
                        if e > TOL:
                            bad.append(dict(test="T1", case=label(p), deriv=name, P_mode=P_mode,
                                            num=num, cf=cf, err=e, stencil_crosses_kink=crossed,
                                            params=brief(p)))
    table = {" | ".join(k): dict(n=len(v), max_err=max(v)) for k, v in sorted(rows.items())}
    return table, bad


def t2_near_kinks(rng):
    """Draws placed at controlled distances from each excluded boundary."""
    out = []
    h_rel = FD_REL
    for spec, expo, conv, shape in COMBOS:
        for gap_mult in (50.0, 0.3):     # gap in FD half-widths: well clear vs inside the stencil
            p = draw_interior(rng, spec, expo, conv, shape, P_mode="low")
            tau = p["KM"] / p["s"]
            gap_t = gap_mult * h_rel * max(p["KM"], p["KD"]) / p["s"]
            # (i) t_D just above tau_M (capability branch: t_D = K_D/s + mD TD)
            q = with_(p, KD=p["s"] * (tau - p["mD"] * p["TD"] + gap_t))
            # (ii) t_D just below L
            r = with_(p, L=t_D(p) + gap_t)
            # (iii) capability term just above the adoption term
            u = with_(p, TD=(p["KD"] / p["s"] - gap_t) / (1 - p["mD"]) if p["mD"] < 0.999 else p["TD"])
            cases = [("t_D near tau_M", q), ("t_D near L", r), ("adoption kink", u)]
            if spec == "level" and conv == "B" and SHAPES[shape][2] is not None:
                cases.append(("K_M near hazard jump (B)",
                              with_(p, KM=X_STEP * KREF * (1 + gap_mult * h_rel))))
            for name, c in cases:
                if c["KD"] <= 0 or t_D(c) <= c["KM"] / c["s"] or t_D(c) >= c["L"]:
                    continue
                nKM, xKM = fd(c, "KM")
                nKD, xKD = fd(c, "KD")
                fKM, fKD = cf_interior(c)
                sc = scale_of(c)
                out.append(dict(test="T2", boundary=name, case=label(c), gap_in_fd_steps=gap_mult,
                                err_dKM=err(nKM, fKM, sc), err_dKD=err(nKD, fKD, sc),
                                crosses_KM=xKM, crosses_KD=xKD, params=brief(c)))
    return out


def t3_regimes(rng, n=6):
    """Non-interior regimes and the K_M-paced branch against the seats' forms."""
    rows, bad = {}, []
    for spec, expo, conv, shape in COMBOS:
        for target in ("paced", "no_closure", "def_before_arrival", "truncation"):
            got = 0
            tries = 0
            while got < n and tries < 4000:
                tries += 1
                p = draw_base(rng, spec, expo, conv, shape)
                p["P"] = rng.choice([0.0, rng.uniform(0, 0.8) * primitives(p)[0]])
                tau = p["KM"] / p["s"]
                if target == "paced":
                    p["branch"] = "paced"
                    p["L"] = t_D(p) + rng.uniform(0.2, 2.0)
                elif target == "no_closure":
                    p["KD"] = p["s"] * (tau + rng.uniform(0.5, 2.0))
                    p["L"] = rng.uniform(tau + 0.05, t_D(p) - 0.01)
                elif target == "def_before_arrival":
                    p["mD"] = rng.uniform(0, 0.3)
                    p["TD"] = rng.uniform(0.05, 0.4) * tau
                    p["KD"] = p["s"] * rng.uniform(0.05, 0.6) * tau
                    p["L"] = rng.choice([tau + rng.uniform(0.2, 2.0), rng.uniform(t_D(p) + 0.01, tau)])
                else:
                    p["L"] = rng.uniform(0.2, 0.9) * tau
                    p["KD"] = p["s"] * (p["L"] + rng.uniform(0.1, 1.0))
                want = "interior" if target == "paced" else target
                if regime(p) != want or not far_from_kinks(p) or p["L"] <= 0:
                    continue
                got += 1
                nKM, xKM = fd(p, "KM")
                nKD, xKD = fd(p, "KD")
                fKM, fKD, src = cf_regime(p)
                sc = scale_of(p)
                for name, num, cf, crossed in (("dK_M", nKM, fKM, xKM), ("dK_D", nKD, fKD, xKD)):
                    key = (target, spec, expo, conv if spec == "level" else "-", name)
                    e = err(num, cf, sc)
                    rows.setdefault(key, []).append(e)
                    if e > TOL:
                        bad.append(dict(test="T3", regime=target, case=label(p), deriv=name, source=src,
                                        num=num, cf=cf, err=e, stencil_crosses_kink=crossed,
                                        params=brief(p)))
    table = {" | ".join(k): dict(n=len(v), max_err=max(v)) for k, v in sorted(rows.items())}
    return table, bad


def t4_affine(rng, n=10):
    """Finite moves: exact Delta(loss) vs the linear prediction w_M dK_M + w_D dK_D."""
    rows = {}
    worst = {}
    for spec, expo, conv, shape in COMBOS:
        for _ in range(n):
            p = draw_interior(rng, spec, expo, conv, shape, P_mode=rng.choice(["zero", "low"]))
            wM, wD = cf_interior(p)
            base = loss(p)
            for fM, fD in ((0.01, 0.01), (0.1, 0.0), (0.0, 0.1), (0.1, 0.3), (0.3, 0.1),
                           (0.3, 0.3), (-0.2, 0.2), (0.5, 0.5)):
                dKM, dKD = -fM * p["KM"], -fD * p["KD"]
                q = with_(p, KM=p["KM"] + dKM, KD=p["KD"] + dKD)
                exact = loss(q) - base
                pred = wM * dKM + wD * dKD
                gross = abs(wM * dKM) + abs(wD * dKD)
                e = abs(exact - pred) / max(gross, abs(exact), 1e-9 * max(abs(base), 1.0))
                same = signature(q) == signature(p)
                key = (spec, expo, conv if spec == "level" else "-",
                       "in-regime" if same else "crosses regime")
                rows.setdefault(key, []).append(e)
                if e > worst.get(key, (0,))[0]:
                    worst[key] = (e, dict(case=label(p), fM=fM, fD=fD, exact=exact, pred=pred,
                                          params=brief(p)))
    table = {" | ".join(k): dict(n=len(v), max_rel_err=max(v)) for k, v in sorted(rows.items())}
    return table, {" | ".join(k): v[1] for k, v in worst.items() if v[0] > TOL}


def t5_unweighted_rule(rng, n=400):
    """Arrival-on, P = 0, chi_D = 1: does loss fall iff delta_D > delta_M (finite moves)?"""
    out = {}
    cases = [("speed", "arrival", "A", "linear"),
             ("level", "arrival", "A", "convex"), ("level", "arrival", "A", "step"),
             ("level", "arrival", "B", "convex"), ("level", "arrival", "B", "linear"),
             ("level", "arrival", "B", "logistic")]
    for combo in cases:
        mism = {"in-regime": [0, 0], "crosses regime": [0, 0]}
        why = {}
        examples = []
        for _ in range(n):
            p = draw_interior(rng, *combo, P_mode="zero")
            dM = rng.uniform(0, 0.6) * p["KM"]
            dD = rng.uniform(0, 0.6) * p["KD"]
            if abs(dD - dM) < 1e-9:
                continue
            q = with_(p, KM=p["KM"] - dM, KD=p["KD"] - dD)
            falls = loss(q) - loss(p) < 0
            rule = dD > dM
            cls = "in-regime" if signature(q) == signature(p) else "crosses regime"
            mism[cls][1] += 1
            if falls != rule:
                mism[cls][0] += 1
                reason = ("chi_D -> 0 after move" if chi(q) == 0 else
                          f"regime -> {regime(q)}" if regime(q) != "interior" else
                          "hazard jump crossed" if cls == "crosses regime" else "none (in regime)")
                why[reason] = why.get(reason, 0) + 1
                if len(examples) < 3:
                    examples.append(dict(cls=cls, delta_M=dM, delta_D=dD, loss_falls=falls,
                                         regime_after=regime(q), chi_after=chi(q), params=brief(p)))
        out[label(dict(spec=combo[0], expo=combo[1], conv=combo[2], shape=combo[3]))] = dict(
            mismatches={k: f"{v[0]}/{v[1]}" for k, v in mism.items()}, reasons=why, examples=examples)
    return out


def t6_euler(rng, n=8):
    """s dC/ds vs -K_M dC/dK_M - K_D dC/dK_D (+ eps H ell under speed-set), and Sol's R3 forms."""
    rows = {}
    for spec, expo, conv, shape in COMBOS:
        for _ in range(n):
            p = draw_interior(rng, spec, expo, conv, shape, P_mode="low")
            nS, _ = fd(p, "s")
            nKM, _ = fd(p, "KM")
            nKD, _ = fd(p, "KD")
            s, VM, tau, td = p["s"], p["VM"], p["KM"] / p["s"], t_D(p)
            hp, hbar, _ = primitives(p)
            extra = 0.0
            if spec == "speed":
                ell = td if expo == "ramp" else td - tau
                extra = VM * p["eps"] * hp * ell
            euler = -p["KM"] * nKM - p["KD"] * nKD + extra
            if spec == "level":
                sol_r3 = VM * tau * ((hp - hbar) if expo == "ramp" else hp) - p["KD"] * nKD
            else:
                sol_r3 = (VM * p["eps"] * hp * td if expo == "ramp"
                          else VM * hp * (p["eps"] * (td - tau) + tau)) - p["KD"] * nKD
            sc = abs(s * nS) + scale_of(p)
            key = (spec, expo, conv if spec == "level" else "-")
            r = rows.setdefault(key, {"euler": [], "sol_R3": []})
            r["euler"].append(abs(s * nS - euler) / sc)
            r["sol_R3"].append(abs(s * nS - sol_r3) / sc)
    return {" | ".join(k): {m: max(v) for m, v in d.items()} for k, d in sorted(rows.items())}


def main():
    rng = random.Random(20261026)
    res = {}
    res["T1_interior"], res["T1_disagreements"] = t1_interior(rng)
    res["T2_near_kinks"] = t2_near_kinks(rng)
    res["T3_regimes"], res["T3_disagreements"] = t3_regimes(rng)
    res["T4_affine"], res["T4_worst_cases"] = t4_affine(rng)
    res["T5_unweighted_rule"] = t5_unweighted_rule(rng)
    res["T6_euler"] = t6_euler(rng)

    print("== T1 interior closed forms vs FD (max err) ==")
    for k, v in res["T1_interior"].items():
        print(f'  {"PASS" if v["max_err"] < TOL else "FAIL"}  {k:55s} n={v["n"]:3d}  {v["max_err"]:.2e}')
    print(f'  disagreements: {len(res["T1_disagreements"])}')
    for d in res["T1_disagreements"][:20]:
        print("   ", d["case"], d["deriv"], d["P_mode"], f'{d["err"]:.2e}', "crosses" if d["stencil_crosses_kink"] else "")
    print("== T2 near kinks (inside stencil = 0.3 steps; well inside = 50 steps) ==")
    agg = {}
    for d in res["T2_near_kinks"]:
        for der in ("KM", "KD"):
            k = (d["boundary"], "d" + der, "stencil crosses" if d["crosses_" + der] else "clear")
            a = agg.setdefault(k, [0, 0.0])
            a[0] += 1
            a[1] = max(a[1], d["err_d" + der])
    res["T2_summary"] = {" | ".join(k): dict(n=v[0], max_err=v[1]) for k, v in sorted(agg.items())}
    for k, v in res["T2_summary"].items():
        print(f'  {k:55s} n={v["n"]:3d}  max err {v["max_err"]:.2e}')
    print("== T3 other regimes vs seats' forms ==")
    for k, v in res["T3_regimes"].items():
        print(f'  {"PASS" if v["max_err"] < TOL else "FAIL"}  {k:60s} n={v["n"]:3d}  {v["max_err"]:.2e}')
    for d in res["T3_disagreements"][:20]:
        print("   ", d["regime"], d["case"], d["deriv"], d["source"], f'{d["err"]:.2e}')
    print("== T4 finite moves: |exact - linear| / gross ==")
    for k, v in res["T4_affine"].items():
        print(f'  {k:45s} n={v["n"]:3d}  {v["max_rel_err"]:.2e}')
    print("== T5 arrival-on, P=0, chi_D=1: loss falls iff delta_D > delta_M ==")
    for k, v in res["T5_unweighted_rule"].items():
        print(f'  {k:32s} mismatches {v["mismatches"]}  reasons {v["reasons"]}')
    print("== T6 Euler identity / Sol R3 forms (rel residual) ==")
    for k, v in res["T6_euler"].items():
        print(f'  {k:28s} euler {v["euler"]:.2e}   sol_R3 {v["sol_R3"]:.2e}')

    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results.json")
    with open(path, "w") as f:
        json.dump(res, f, indent=1, default=str)
    print("wrote", path)


if __name__ == "__main__":
    main()
