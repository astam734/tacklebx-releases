import BioPaperProofs
open Lean Elab Command

/-!
Whole-project axiom audit: every theorem declared in a module under `BioPaperProofs` is checked with
`Lean.collectAxioms`. It prints one summary line, `AUDIT <n> theorems, <k> outside the standard three`,
then one line per offending theorem. The three standard axioms are `propext`, `Classical.choice`
and `Quot.sound`; `sorryAx` or any added axiom counts as offending.
-/
#eval show CommandElabM Unit from do
  let env ← getEnv
  let ok : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut n : Nat := 0
  let mut bad : Array (Name × Array Name) := #[]
  for (c, ci) in env.constants.map₁.toList do
    if let .thmInfo _ := ci then
      if let some idx := env.getModuleIdxFor? c then
        let m := env.header.moduleNames[idx.toNat]!
        if m.getRoot == `BioPaperProofs && !c.isInternal then
          n := n + 1
          let ax ← liftCoreM (Lean.collectAxioms c)
          let off := ax.filter (fun a => !ok.contains a)
          if !off.isEmpty then bad := bad.push (c, off)
  logInfo m!"AUDIT {n} theorems, {bad.size} outside the standard three"
  for (c, off) in bad do logInfo m!"OFFENDING {c}: {off}"
