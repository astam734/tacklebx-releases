import Mathlib

/-!
# Piecewise-constant hazards: the integral-to-closed-form step

`Item1.lean` *defined* misuse loss as the closed form `Λ s * (L - K/s)` and said so in its own
docstring: that the integral of the hazard equals that closed form was "a separate step and is
**not** formalised here".  This file is that step.

Everything the paper's speed-set results rest on is the integral of a hazard that is constant on
each of two or three intervals -- zero before arrival, the plateau hazard between arrival and
deployment, the residual after.  So the work is done once here, for a general step function, and
the results reduce to arithmetic.

No sign hypotheses are needed.  Integrability of a step function follows from its agreement with
a constant on the *open* interval, so the value at the step itself never has to be argued about.
-/

open MeasureTheory intervalIntegral Set

namespace BioPaper

/-- A one-step hazard: `p` strictly before `d`, `q` from `d` onward. -/
noncomputable def step (p q d : ℝ) : ℝ → ℝ := fun t => if t < d then p else q

/-- A two-step hazard: `p` before `d`, `q` on `[d, e)`, `r` from `e` onward.  This is the
arrival-and-closure shape: no exposure, then the plateau hazard, then the residual. -/
noncomputable def step2 (p q r d e : ℝ) : ℝ → ℝ :=
  fun t => if t < d then p else if t < e then q else r

/-- On an interval ending weakly before the step, a step function agrees with the constant `p`
on the open interval, hence is interval integrable. -/
theorem intervalIntegrable_step_left (p q d a b : ℝ) (hab : a ≤ b) (hb : b ≤ d) :
    IntervalIntegrable (step p q d) volume a b := by
  rw [intervalIntegrable_congr_uIoo (g := fun _ : ℝ => p) ?_]
  · exact intervalIntegrable_const
  · intro t ht
    rw [uIoo_of_le hab] at ht
    simp [step, lt_of_lt_of_le ht.2 hb]

/-- On an interval starting weakly at or after the step, a step function agrees with the
constant `q` on the open interval. -/
theorem intervalIntegrable_step_right (p q d a b : ℝ) (hab : a ≤ b) (ha : d ≤ a) :
    IntervalIntegrable (step p q d) volume a b := by
  rw [intervalIntegrable_congr_uIoo (g := fun _ : ℝ => q) ?_]
  · exact intervalIntegrable_const
  · intro t ht
    rw [uIoo_of_le hab] at ht
    simp [step, not_lt.mpr (le_trans ha ht.1.le)]

/-- A step function is interval integrable across its own step. -/
theorem intervalIntegrable_step (p q a d b : ℝ) (had : a ≤ d) (hdb : d ≤ b) :
    IntervalIntegrable (step p q d) volume a b :=
  (intervalIntegrable_step_left p q d a d had le_rfl).trans
    (intervalIntegrable_step_right p q d d b hdb le_rfl)

/-- **The one-step integral.**  For `a ≤ d ≤ b`,
`∫_a^b (p before d, q from d) = p (d - a) + q (b - d)`. -/
theorem integral_step (p q a d b : ℝ) (had : a ≤ d) (hdb : d ≤ b) :
    (∫ t in a..b, step p q d t) = p * (d - a) + q * (b - d) := by
  have h1 : (∫ t in a..d, step p q d t) = p * (d - a) := by
    rw [integral_congr_Ioo_of_le had (g := fun _ : ℝ => p) ?_, intervalIntegral.integral_const, smul_eq_mul]
    · ring
    · intro t ht; simp [step, ht.2]
  have h2 : (∫ t in d..b, step p q d t) = q * (b - d) := by
    rw [integral_congr_Ioo_of_le hdb (g := fun _ : ℝ => q) ?_, intervalIntegral.integral_const, smul_eq_mul]
    · ring
    · intro t ht; simp [step, not_lt.mpr ht.1.le]
  rw [← integral_add_adjacent_intervals
    (intervalIntegrable_step_left p q d a d had le_rfl)
    (intervalIntegrable_step_right p q d d b hdb le_rfl), h1, h2]

/-- **The truncated one-step integral.**  An interval that ends before the step sees only `p`.
With `p = 0` this is the truncation case: below the activation speed there is no exposure at
all, so misuse loss is exactly zero, not merely small. -/
theorem integral_step_before (p q a d b : ℝ) (hab : a ≤ b) (hb : b ≤ d) :
    (∫ t in a..b, step p q d t) = p * (b - a) := by
  rw [integral_congr_Ioo_of_le hab (g := fun _ : ℝ => p) ?_, intervalIntegral.integral_const, smul_eq_mul]
  · ring
  · intro t ht; simp [step, lt_of_lt_of_le ht.2 hb]

/-- **The two-step integral.**  For `a ≤ d ≤ e ≤ b`,
`∫_a^b (p, then q, then r) = p (d - a) + q (e - d) + r (b - e)`. -/
theorem integral_step2 (p q r a d e b : ℝ) (had : a ≤ d) (hde : d ≤ e) (heb : e ≤ b) :
    (∫ t in a..b, step2 p q r d e t) = p * (d - a) + q * (e - d) + r * (b - e) := by
  have hdb : d ≤ b := le_trans hde heb
  have hEq : EqOn (step2 p q r d e) (step q r e) (uIoo d b) := by
    intro t ht
    rw [uIoo_of_le hdb] at ht
    simp [step2, step, not_lt.mpr ht.1.le]
  have hleft : IntervalIntegrable (step2 p q r d e) volume a d := by
    rw [intervalIntegrable_congr_uIoo (g := fun _ : ℝ => p) ?_]
    · exact intervalIntegrable_const
    · intro t ht
      rw [uIoo_of_le had] at ht
      simp [step2, ht.2]
  have hright : IntervalIntegrable (step2 p q r d e) volume d b := by
    rw [intervalIntegrable_congr_uIoo hEq]
    exact intervalIntegrable_step q r d e b hde heb
  have h1 : (∫ t in a..d, step2 p q r d e t) = p * (d - a) := by
    rw [integral_congr_Ioo_of_le had (g := fun _ : ℝ => p) ?_, intervalIntegral.integral_const, smul_eq_mul]
    · ring
    · intro t ht; simp [step2, ht.2]
  have h2 : (∫ t in d..b, step2 p q r d e t) = q * (e - d) + r * (b - e) := by
    rw [integral_congr_Ioo_of_le hdb (g := step q r e) (fun t ht => hEq (by
      rw [uIoo_of_le hdb]; exact ht))]
    exact integral_step q r d e b hde heb
  rw [← integral_add_adjacent_intervals hleft hright, h1, h2]; ring

end BioPaper
