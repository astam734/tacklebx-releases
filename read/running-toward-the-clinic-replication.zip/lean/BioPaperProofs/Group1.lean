import BioPaperProofs.StepIntegral

/-!
# Group 1 of `PROOF-INVENTORY.md` — speed-set, arrival-on

The inventory's Group 1 is six results, all of them consequences of
`C_M = Λ_M(s) · (L − K_M/s)` and the chain rule.  `Item1.lean` did the first of them from that
closed form, taking the closed form as a *definition*.  Here misuse loss is instead **defined as
the integral of the hazard**, `StepIntegral.lean` supplies the step from the integral to the
closed form, and the six results are proved on top of it.

## Translation note — still the whole risk of the exercise

Lean checks that these proofs prove *these statements*.  It cannot check that the statements are
the paper's claims.  What a reader must still agree with:

1. **The hazard shape.** Arrival-on, speed-set, no closure is taken to be `step 0 (Λ s) (K/s)`:
   identically zero before `τ_M = K_M/s`, the constant `Λ_M(s)` from `τ_M` onward.  With closure
   at `t_D` it is `step2 0 (Λ s) P (K/s) t_D`, with `P` the residual `h_M^post`.  These are
   formalisations of §4a.1's set-up, not consequences of it.
2. **The elasticity.** Statements are written with `Λ'` and multiplied through by `s`, never
   dividing by `Λ s`.  Substituting `ε_Λ = s·Λ'/Λ` recovers the paper's printed form exactly
   when `Λ s ≠ 0`, which the paper assumes throughout.
3. **Results 5 and 6 are algebraic equivalences, not modelling claims.** What is certified is
   the rearrangement of a sign condition into a threshold, and of a net-marginal sign into the
   printed inequality.  That the marginals are the paper's marginals is item 1 above.
-/

open MeasureTheory intervalIntegral Set Real

namespace BioPaper

variable {Λ : ℝ → ℝ}

/-- Misuse loss under speed-set arrival-on with no closure, **defined as the integral** of the
hazard over the counted window `[0, L]`. -/
noncomputable def CArr (Λ : ℝ → ℝ) (K L s : ℝ) : ℝ := ∫ t in (0:ℝ)..L, step 0 (Λ s) (K / s) t

/-- Misuse loss under speed-set arrival-on with a step to the residual `P` at `t_D`. -/
noncomputable def CArrClose (Λ : ℝ → ℝ) (K L s tD P : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, step2 0 (Λ s) P (K / s) tD t

/-! ## The integral-to-closed-form step -/

/-- **The translation step, no closure.**  While the capability is reached inside the horizon,
the integral of the arrival-on hazard is the closed form `Item1.lean` assumed. -/
theorem CArr_eq (Λ : ℝ → ℝ) (K L s : ℝ) (hτ : 0 ≤ K / s) (hwin : K / s ≤ L) :
    CArr Λ K L s = Λ s * (L - K / s) := by
  rw [CArr, integral_step 0 (Λ s) 0 (K / s) L hτ hwin]; ring

/-- **The translation step, with closure.** -/
theorem CArrClose_eq (Λ : ℝ → ℝ) (K L s tD P : ℝ) (hτ : 0 ≤ K / s) (hD : K / s ≤ tD)
    (hL : tD ≤ L) : CArrClose Λ K L s tD P = Λ s * (tD - K / s) + P * (L - tD) := by
  rw [CArrClose, integral_step2 0 (Λ s) P 0 (K / s) tD L hτ hD hL]; ring

/-- The closed form holds on a whole neighbourhood of any speed that reaches the capability
strictly inside the horizon.  This is what licenses differentiating the closed form: it is not
merely equal to the integral at a point. -/
theorem CArr_eventuallyEq (Λ : ℝ → ℝ) (K L s₀ : ℝ) (hK : 0 ≤ K) (hs : 0 < s₀)
    (hwin : K / s₀ < L) :
    ∀ᶠ s in nhds s₀, CArr Λ K L s = Λ s * (L - K / s) := by
  have hpos : ∀ᶠ s in nhds s₀, (0:ℝ) < s :=
    (isOpen_Ioi.eventually_mem hs).mono (fun x hx => hx)
  have hcont : ContinuousAt (fun x : ℝ => K / x) s₀ :=
    continuousAt_const.div continuousAt_id hs.ne'
  have hlt : ∀ᶠ s in nhds s₀, K / s < L :=
    hcont.eventually ((isOpen_Iio.eventually_mem hwin).mono (fun x hx => hx))
  filter_upwards [hpos, hlt] with s hs0 hsL
  exact CArr_eq Λ K L s (by positivity) hsL.le

/-- The same for the closure case: the two-piece closed form holds on a whole neighbourhood of
any speed at which the capability is reached strictly before deployment and deployment strictly
before the horizon. -/
theorem CArrClose_eventuallyEq (Λ TD : ℝ → ℝ) (K L s₀ P : ℝ) (hK : 0 ≤ K) (hs : 0 < s₀)
    (hTDc : ContinuousAt TD s₀) (harr : K / s₀ < TD s₀) (hhor : TD s₀ < L) :
    ∀ᶠ s in nhds s₀, CArrClose Λ K L s (TD s) P
      = Λ s * (TD s - K / s) + P * (L - TD s) := by
  have hpos : ∀ᶠ s in nhds s₀, (0:ℝ) < s :=
    (isOpen_Ioi.eventually_mem hs).mono (fun x hx => hx)
  have hcont : ContinuousAt (fun x : ℝ => K / x) s₀ :=
    continuousAt_const.div continuousAt_id hs.ne'
  have hgap : ∀ᶠ s in nhds s₀, (0:ℝ) < TD s - K / s :=
    (hTDc.sub hcont).eventually
      ((isOpen_Ioi.eventually_mem (sub_pos.mpr harr)).mono (fun x hx => hx))
  have hlt : ∀ᶠ s in nhds s₀, TD s < L :=
    hTDc.eventually ((isOpen_Iio.eventually_mem hhor).mono (fun x hx => hx))
  filter_upwards [hpos, hgap, hlt] with s hs0 hg hL
  exact CArrClose_eq Λ K L s (TD s) P (by positivity) (by linarith) hL.le

/-! ## Result 1 — R2, the plateau -/

/-- **Result 1, the derivative, from the integral.**  Where the capability is reached strictly
inside the horizon, misuse loss as defined by the integral is differentiable with the
product-rule derivative. -/
theorem r2_hasDerivAt (Λ : ℝ → ℝ) (L K s lam' : ℝ) (hK : 0 ≤ K) (hs : 0 < s)
    (hwin : K / s < L) (hΛ : HasDerivAt Λ lam' s) :
    HasDerivAt (fun x : ℝ => CArr Λ K L x) (lam' * (L - K / s) + Λ s * (K / s ^ 2)) s := by
  have hclosed : HasDerivAt (fun x : ℝ => Λ x * (L - K / x))
      (lam' * (L - K / s) + Λ s * (K / s ^ 2)) s := by
    have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs.ne'
    have hwindow : HasDerivAt (fun x : ℝ => L - K / x) (K / s ^ 2) s := by
      have hKx := (hinv.const_mul K).const_sub L
      simp only [div_eq_mul_inv] at *
      convert hKx using 1
      field_simp
    exact hΛ.mul hwindow
  exact hclosed.congr_of_eventuallyEq (CArr_eventuallyEq Λ K L s hK hs hwin)

/-- **Result 1, the paper's form.**  Multiplying by `s` gives the paper's
`Λ_M[ε_Λ(L − τ_M) + τ_M]` once `ε_Λ = s·Λ'/Λ` is substituted. -/
theorem r2_scaled (Λ : ℝ → ℝ) (L K s lam' : ℝ) (hs : s ≠ 0) :
    s * (lam' * (L - K / s) + Λ s * (K / s ^ 2))
      = s * lam' * (L - K / s) + Λ s * (K / s) := by
  field_simp

/-- **Result 1, the sign.**  Strictly positive even at zero elasticity, because the onset term
alone is positive.  That is the paper's point that arrival-on differs from ramp-on, where the
derivative vanishes at `ε_Λ = 0`. -/
theorem r2_pos (Λ : ℝ → ℝ) (L K s lam' : ℝ) (hs : 0 < s) (hK : 0 < K) (hΛs : 0 < Λ s)
    (hwin : K / s < L) (hlam : 0 ≤ lam') :
    0 < s * lam' * (L - K / s) + Λ s * (K / s) := by
  have h1 : 0 ≤ s * lam' * (L - K / s) := by
    have : 0 < L - K / s := sub_pos.mpr hwin
    positivity
  have h2 : 0 < Λ s * (K / s) := by positivity
  linarith

/-! ## Result 2 — the same, discounted -/

/-- `∫_a^b e^{−rt} dt = (e^{−ra} − e^{−rb})/r`, by the fundamental theorem of calculus. -/
theorem integral_exp_neg (r a b : ℝ) (hr : r ≠ 0) :
    (∫ t in a..b, exp (-r * t)) = (exp (-r * a) - exp (-r * b)) / r := by
  have hcont : Continuous (fun t : ℝ => exp (-r * t)) :=
    Real.continuous_exp.comp (continuous_const.mul continuous_id)
  have hderiv : ∀ t ∈ uIcc a b,
      HasDerivAt (fun u : ℝ => -(exp (-r * u)) / r) (exp (-r * t)) t := by
    intro t _
    have hinner : HasDerivAt (fun u : ℝ => -r * u) (-r) t := by
      simpa using (hasDerivAt_id t).const_mul (-r)
    have h := (hinner.exp.neg).div_const r
    convert h using 1
    field_simp
  rw [integral_eq_sub_of_hasDerivAt hderiv (hcont.intervalIntegrable a b)]
  field_simp
  ring

/-- The discounted arrival-on loss, defined as the integral of the discounted hazard. -/
noncomputable def CArrDisc (Λ : ℝ → ℝ) (K L s r : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, exp (-r * t) * step 0 (Λ s) (K / s) t

/-- **Result 2, the translation step.**  The discounted integral is
`Λ_M(s)·(e^{−rτ_M} − e^{−rL})/r`. -/
theorem CArrDisc_eq (Λ : ℝ → ℝ) (K L s r : ℝ) (hr : r ≠ 0) (hτ : 0 ≤ K / s)
    (hwin : K / s ≤ L) :
    CArrDisc Λ K L s r = Λ s * ((exp (-r * (K / s)) - exp (-r * L)) / r) := by
  have hleft : IntervalIntegrable (fun t : ℝ => exp (-r * t) * step 0 (Λ s) (K / s) t)
      volume 0 (K / s) := by
    rw [intervalIntegrable_congr_uIoo (g := fun _ : ℝ => (0:ℝ)) ?_]
    · exact intervalIntegrable_const
    · intro t ht
      rw [uIoo_of_le hτ] at ht
      simp [step, ht.2]
  have hright : IntervalIntegrable (fun t : ℝ => exp (-r * t) * step 0 (Λ s) (K / s) t)
      volume (K / s) L := by
    rw [intervalIntegrable_congr_uIoo (g := fun t : ℝ => exp (-r * t) * Λ s) ?_]
    · exact ((Real.continuous_exp.comp
        (continuous_const.mul continuous_id)).mul continuous_const).intervalIntegrable _ _
    · intro t ht
      rw [uIoo_of_le hwin] at ht
      simp [step, not_lt.mpr ht.1.le]
  have h1 : (∫ t in (0:ℝ)..(K / s), exp (-r * t) * step 0 (Λ s) (K / s) t) = 0 := by
    rw [integral_congr_Ioo_of_le hτ (g := fun _ : ℝ => (0:ℝ)) ?_]
    · simp
    · intro t ht; simp [step, ht.2]
  have h2 : (∫ t in (K / s)..L, exp (-r * t) * step 0 (Λ s) (K / s) t)
      = Λ s * ((exp (-r * (K / s)) - exp (-r * L)) / r) := by
    rw [integral_congr_Ioo_of_le hwin (g := fun t : ℝ => exp (-r * t) * Λ s) ?_]
    · rw [intervalIntegral.integral_mul_const, integral_exp_neg r (K / s) L hr]; ring
    · intro t ht; simp [step, not_lt.mpr ht.1.le]
  rw [CArrDisc, ← integral_add_adjacent_intervals hleft hright, h1, h2]; ring

/-- The discounted closed form holds on a neighbourhood, which licenses differentiating it. -/
theorem CArrDisc_eventuallyEq (Λ : ℝ → ℝ) (K L s₀ r : ℝ) (hK : 0 ≤ K) (hs : 0 < s₀)
    (hr : r ≠ 0) (hwin : K / s₀ < L) :
    ∀ᶠ s in nhds s₀,
      CArrDisc Λ K L s r = Λ s * ((exp (-r * (K / s)) - exp (-r * L)) / r) := by
  have hpos : ∀ᶠ s in nhds s₀, (0:ℝ) < s :=
    (isOpen_Ioi.eventually_mem hs).mono (fun x hx => hx)
  have hcont : ContinuousAt (fun x : ℝ => K / x) s₀ :=
    continuousAt_const.div continuousAt_id hs.ne'
  have hlt : ∀ᶠ s in nhds s₀, K / s < L :=
    hcont.eventually ((isOpen_Iio.eventually_mem hwin).mono (fun x hx => hx))
  filter_upwards [hpos, hlt] with s hs0 hsL
  exact CArrDisc_eq Λ K L s r hr (by positivity) hsL.le

/-- **Result 2, the derivative, from the integral.**  The discounted loss is differentiable
where the capability is reached strictly inside the horizon, with the product-rule derivative.
Without this the discounted result would be algebra about an expression rather than a statement
about the discounted integral. -/
theorem r2_disc_hasDerivAt (Λ : ℝ → ℝ) (L K s r lam' : ℝ) (hK : 0 ≤ K) (hs : 0 < s)
    (hr : r ≠ 0) (hwin : K / s < L) (hΛ : HasDerivAt Λ lam' s) :
    HasDerivAt (fun x : ℝ => CArrDisc Λ K L x r)
      (lam' * ((exp (-r * (K / s)) - exp (-r * L)) / r)
        + Λ s * (exp (-r * (K / s)) * (K / s ^ 2))) s := by
  have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs.ne'
  have hKx : HasDerivAt (fun x : ℝ => K / x) (-(K / s ^ 2)) s := by
    have h := hinv.const_mul K
    simp only [div_eq_mul_inv] at *
    convert h using 1
    field_simp
  have hbracket : HasDerivAt (fun x : ℝ => (exp (-r * (K / x)) - exp (-r * L)) / r)
      (exp (-r * (K / s)) * (K / s ^ 2)) s := by
    have hexp := (hKx.const_mul (-r)).exp
    have h := (hexp.sub_const (exp (-r * L))).div_const r
    convert h using 1
    field_simp
  have h := hΛ.mul hbracket
  exact h.congr_of_eventuallyEq (CArrDisc_eventuallyEq Λ K L s r hK hs hr hwin)

/-- **Result 2, the paper's form.**  `s·C'` for the discounted loss is
`Λ_M[ε_Λ(e^{−rτ_M} − e^{−rL})/r + τ_M e^{−rτ_M}]`. -/
theorem r2_disc_scaled (Λ : ℝ → ℝ) (L K s r lam' : ℝ) (hs : s ≠ 0) (hr : r ≠ 0) :
    s * (lam' * ((exp (-r * (K / s)) - exp (-r * L)) / r)
        + Λ s * (exp (-r * (K / s)) * (K / s ^ 2)))
      = s * lam' * ((exp (-r * (K / s)) - exp (-r * L)) / r)
        + Λ s * ((K / s) * exp (-r * (K / s))) := by
  field_simp

/-- **Result 2, the sign.**  Strictly positive for a nonnegative elasticity, and strictly
positive even at `Λ' = 0`: the onset term `τ_M e^{−rτ_M}` carries it, as undiscounted. -/
theorem r2_disc_pos (Λ : ℝ → ℝ) (L K s r lam' : ℝ) (hs : 0 < s) (hK : 0 < K) (hr : 0 < r)
    (hΛs : 0 < Λ s) (hwin : K / s < L) (hlam : 0 ≤ lam') :
    0 < s * lam' * ((exp (-r * (K / s)) - exp (-r * L)) / r)
        + Λ s * ((K / s) * exp (-r * (K / s))) := by
  have hmono : exp (-r * L) < exp (-r * (K / s)) := by
    apply exp_lt_exp.mpr
    have : r * (K / s) < r * L := by exact mul_lt_mul_of_pos_left hwin hr
    linarith
  have h1 : 0 ≤ s * lam' * ((exp (-r * (K / s)) - exp (-r * L)) / r) := by
    have hnum : 0 < exp (-r * (K / s)) - exp (-r * L) := sub_pos.mpr hmono
    positivity
  have h2 : 0 < Λ s * ((K / s) * exp (-r * (K / s))) := by positivity
  linarith

/-! ## Result 3 — R1, truncation -/

/-- **Result 3.**  Below the activation speed the capability is never reached inside the
horizon, and misuse loss is **exactly** zero, not merely small.  Nothing about `Λ` is used. -/
theorem CArr_eq_zero (Λ : ℝ → ℝ) (K L s : ℝ) (hL : 0 ≤ L) (htrunc : L ≤ K / s) :
    CArr Λ K L s = 0 := by
  rw [CArr, integral_step_before 0 (Λ s) 0 (K / s) L hL htrunc]; ring

/-- **Result 3, the derivative.**  Strictly inside the unreached region the loss is
*identically* zero on a neighbourhood, so its derivative is zero -- the paper's "`sC_M'` = 0
throughout the unreached region", which pointwise vanishing of `C_M` alone does not give. -/
theorem CArr_hasDerivAt_zero (Λ : ℝ → ℝ) (K L s : ℝ) (hs : 0 < s) (hL : 0 ≤ L)
    (htrunc : L < K / s) : HasDerivAt (fun x : ℝ => CArr Λ K L x) 0 s := by
  have hpos : ∀ᶠ x in nhds s, (0:ℝ) < x :=
    (isOpen_Ioi.eventually_mem hs).mono (fun y hy => hy)
  have hcont : ContinuousAt (fun x : ℝ => K / x) s :=
    continuousAt_const.div continuousAt_id hs.ne'
  have hgt : ∀ᶠ x in nhds s, L < K / x :=
    hcont.eventually ((isOpen_Ioi.eventually_mem htrunc).mono (fun y hy => hy))
  have heq : ∀ᶠ x in nhds s, CArr Λ K L x = 0 := by
    filter_upwards [hpos, hgt] with x hx0 hxL
    exact CArr_eq_zero Λ K L x hL hxL.le
  exact (hasDerivAt_const s (0:ℝ)).congr_of_eventuallyEq heq

/-- **Result 3, the activation kink.**  At the activation speed `s = K/L` the window closes, so
the elasticity term drops out and the scaled derivative takes the right-hand value `Λ_M·L`.
This is the paper's P16 analogue: the effect appears only at the kink. -/
theorem r2_scaled_at_kink (Λ : ℝ → ℝ) (L K s lam' : ℝ) (hkink : K / s = L) :
    s * lam' * (L - K / s) + Λ s * (K / s) = Λ s * L := by
  rw [hkink]; ring

/-! ## Result 4 — R3, the defence clock -/

/-- **Result 4, the derivative, from the integral.**  With closure at `t_D(s)` the loss is
differentiable, and the derivative is the product rule applied to the two-piece closed form. -/
theorem r3_hasDerivAt (Λ TD : ℝ → ℝ) (L K s P lam' tD' : ℝ) (hK : 0 ≤ K) (hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s) (hTD : HasDerivAt TD tD' s)
    (harr : K / s < TD s) (hhor : TD s < L) :
    HasDerivAt (fun x : ℝ => CArrClose Λ K L x (TD x) P)
      (lam' * (TD s - K / s) + Λ s * (tD' + K / s ^ 2) + P * -tD') s := by
  have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs.ne'
  have hwindow : HasDerivAt (fun x : ℝ => TD x - K / x) (tD' + K / s ^ 2) s := by
    have hKx : HasDerivAt (fun x : ℝ => K / x) (-(K / s ^ 2)) s := by
      have h := hinv.const_mul K
      simp only [div_eq_mul_inv] at *
      convert h using 1
      field_simp
    convert hTD.sub hKx using 1
    ring
  have h := (hΛ.mul hwindow).add ((hTD.const_sub L).const_mul P)
  exact h.congr_of_eventuallyEq
    (CArrClose_eventuallyEq Λ TD K L s P hK hs hTD.continuousAt harr hhor)

/-- **Result 4, the paper's form.**  `s·C' = Λ_M[ε_Λ(t_D − τ_M) + τ_M] + s·t_D'(Λ_M − h_M^post)`
once `ε_Λ = s·Λ'/Λ` and `τ_M = K/s` are substituted. -/
theorem r3_scaled (Λ : ℝ → ℝ) (K s P lam' tD tD' : ℝ) (hs : s ≠ 0) :
    s * (lam' * (tD - K / s) + Λ s * (tD' + K / s ^ 2) + P * -tD')
      = (s * lam' * (tD - K / s) + Λ s * (K / s)) + s * tD' * (Λ s - P) := by
  field_simp
  ring

/-! ## Result 5 — the arrival-on threshold -/

/-- **Result 5.**  Writing the deployment-date elasticity `α_D = −s·t_D'/t_D`, acceleration
lowers misuse loss exactly when `α_D` exceeds the threshold
`ᾱ_s^arr = Λ_M[ε_Λ(t_D − τ_M) + τ_M] / [t_D(Λ_M − h_M^post)]`.

The hypotheses are the ones the paper states: a positive deployment date and a residual below
the plateau hazard.  What is certified is the rearrangement; the marginals are the formalisation
choice recorded in the module docstring. -/
theorem alphaBar_arr (Λ : ℝ → ℝ) (K s P tD alpha lam' : ℝ) (htD : 0 < tD)
    (hgap : P < Λ s) :
    ((s * lam' * (tD - K / s) + Λ s * (K / s)) - alpha * tD * (Λ s - P) < 0)
      ↔ (s * lam' * (tD - K / s) + Λ s * (K / s)) / (tD * (Λ s - P)) < alpha := by
  set num := s * lam' * (tD - K / s) + Λ s * (K / s) with hnum
  set Lam := Λ s with hLam
  have hden : 0 < tD * (Lam - P) := mul_pos htD (sub_pos.mpr hgap)
  rw [div_lt_iff₀ hden]
  constructor
  · intro h; nlinarith [h]
  · intro h; nlinarith [h]

/-- The threshold reverses when the residual exceeds the plateau hazard — the condition the
paper says it needs, and which earlier drafts stated a paragraph away. -/
theorem alphaBar_arr_reversed (Λ : ℝ → ℝ) (K s P tD alpha lam' : ℝ) (htD : 0 < tD)
    (hgap : Λ s < P) :
    ((s * lam' * (tD - K / s) + Λ s * (K / s)) - alpha * tD * (Λ s - P) < 0)
      ↔ alpha < (s * lam' * (tD - K / s) + Λ s * (K / s)) / (tD * (Λ s - P)) := by
  set num := s * lam' * (tD - K / s) + Λ s * (K / s) with hnum
  set Lam := Λ s with hLam
  have hden : tD * (Lam - P) < 0 := mul_neg_of_pos_of_neg htD (sub_neg.mpr hgap)
  rw [lt_div_iff_of_neg hden]
  constructor
  · intro h; nlinarith [h]
  · intro h; nlinarith [h]

/-! ## Result 6 — the arrival-on coupled benefit test -/

/-- **Result 6.**  With the benefit marginal `p·y·q` and the misuse marginal `V_M` times the
scaled derivative of Result 1, the net marginal is positive exactly when
`p·y·q > V_M·Λ_M[ε_Λ(L − τ_M) + τ_M]`.

This is the step from a sign to the paper's printed inequality, nothing more: that `pyq` is the
benefit marginal and that `V_M·misuse` is the loss is §4a.1's set-up, not something Lean can
check. -/
theorem coupled_benefit_test (Λ : ℝ → ℝ) (L K s lam' pyq VM : ℝ) (hs : s ≠ 0) :
    (0 < pyq - VM * (s * (lam' * (L - K / s) + Λ s * (K / s ^ 2))))
      ↔ VM * (s * lam' * (L - K / s) + Λ s * (K / s)) < pyq := by
  rw [r2_scaled Λ L K s lam' hs]
  constructor
  · intro h; linarith
  · intro h; linarith

end BioPaper
