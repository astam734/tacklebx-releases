import BioPaperProofs.Group1
import BioPaperProofs.LevelSet

/-!
# Post-inventory rows G, H and I of S.4

Rows **G** and **H** are the arrival-on Relation entries of Table 4b.A (rows 1, 4, 5 and rows 2,
6, 7), compared like with like: the level-set side is **gated** as §4a.2 defines it.  Row **I**
is the `K_D` invariance of §4a.5 / A4a.7(i), with its gradual-coverage extension.

## How each paper object is represented, and why that is faithful

1. **The gated level profile** (§4a.2: "the profile that is zero below `K_M` and `h_M(K_M)` at
   it") is `gate h K c = if c < K then 0 else h K`.  The gated level-set losses are then the
   *existing* level-set objects of `LevelSet.lean` applied to that profile:
   `CLevPlateau (gate h K) K L s` with no closure and `CLev (gate h K) K L s t_D P` with a step
   to the residual `P` at `t_D`.  Nothing about the level-set loss is redefined; only the profile
   is substituted, which is what "substituting it into the level-set formulas" means.  The ramp
   average of the gated profile is *proved* to be zero (`gate_hbar`), not assumed.
   Under convention A the ungated profile is `convA ĥ K c = ĥ (c / K)`, the shape-preserving
   profile `LevelSet.lean`'s docstring describes (it has no definition there, so this is not a
   redefinition); its gated version is `gate (convA ĥ K) K`.
2. **The defence clock** is RTTR's mixed timing exactly as §4a.1 prints it,
   `clock K m T s = max (K/s) ((1 − m)T) + mT`, and `χ_D` is `chi`: 1 where the capability term
   binds, 0 where the adoption term binds.  Every derivative below is taken of the loss composed
   with this clock, on a stated branch, off the kink.  "Paced by `K_M`" is `clock K_M m T`.
3. **The speed-set losses** are Group 1's `CArr` and `CArrClose` (arrival-on) and the ramp-on
   step loss `CRamp`, defined here as the integral of `step (Λ s) P t_D` (no ramp-on step loss
   existed in the project).
4. **The benefit side of row 7** is `benefit = p·y·(L − a(s))⁺` with actual arrival
   `a = t_B + δ_T` (l.110), `t_B` on the same clock and `ω = 0`.  A4a.4(vi) sets `δ_T′ = 0`, not
   `δ_T = 0`, so `δ_T` is a function of the speed carried with `HasDerivAt δ 0 s`.  On the
   capability branch with **`a < L`** the scaled derivative is *proved* to be `p·y·q`,
   `q = K_B/s`; with `t_B < L` alone (the printed condition) it is not: `h7_delay_counterexample`
   has `t_B < L < a`, both printed tests passing and both balance derivatives negative.  The whole
   balance of row 7 is that benefit minus `V_M` times the misuse loss, every other channel at
   zero, as the row states.
5. **The elasticity**, as in `Group1.lean`, is written `s·Λ'` and never divided by `Λ s`, except
   in the printed `ε`-threshold of row 5, which is stated with `ε = s·Λ'/Λ` and `0 < Λ s`.
6. **Divergence** (§4b.1: "opposite strict signs") is `(s·dℓ)·(s·ds) < 0` for the scaled
   derivatives of the two defined losses.
7. **The translation theorem** of A4a.7(i) is `CTrans a b L t_D = ∫_0^L (a before t_D, b(t − t_D)
   after)`: a pre-deployment hazard `a` that does not move with `t_D`, and a post-deployment
   schedule `b` that translates rigidly with `t_D`.  Every step loss of row I is proved equal to
   a `CTrans` (`CLev_eq_trans`, `CRamp_eq_trans`, `CArrClose_eq_trans`), and gradual coverage is
   `b = cover plat P u`, `u` a fixed coverage schedule.
8. **Regularity.** Row I needs only `h_M` integrable on `[0, K_M]` (Lemma L's own assumption),
   not the `Continuous h` that `LevelSet.lean` takes as its standing choice: the derivative in
   `t_D` sees the hazard only on the plateau, where it is constant.
-/

open MeasureTheory intervalIntegral Set Real Filter Topology

namespace BioPaper
namespace PostGHI

/-! ## Shared objects: the clock, the gated profile, convention A -/

/-- RTTR's mixed timing clock, §4a.1: `t(s) = max{K/s, (1 − m)T} + mT`. -/
noncomputable def clock (K m T s : ℝ) : ℝ := max (K / s) ((1 - m) * T) + m * T

/-- `χ`: 1 where the capability term of the clock binds, 0 where the adoption term does. -/
noncomputable def chi (K m T s : ℝ) : ℝ := if (1 - m) * T < K / s then 1 else 0

/-- The gated level profile of §4a.2: zero below `K`, `h K` at and above it. -/
noncomputable def gate (h : ℝ → ℝ) (K : ℝ) : ℝ → ℝ := fun c => if c < K then 0 else h K

/-- Convention A's shape-preserving profile, `h_M(c; K_M) = ĥ_M(c/K_M)`. -/
noncomputable def convA (ĥ : ℝ → ℝ) (K : ℝ) : ℝ → ℝ := fun c => ĥ (c / K)

theorem clock_cap (K m T s : ℝ) (h : (1 - m) * T < K / s) : clock K m T s = K / s + m * T := by
  rw [clock, max_eq_left h.le]

theorem clock_adopt (K m T s : ℝ) (h : K / s < (1 - m) * T) :
    clock K m T s = (1 - m) * T + m * T := by
  rw [clock, max_eq_right h.le]

/-- On the capability branch the clock is `K/x + mT` on a whole neighbourhood of the speed. -/
theorem clock_cap_eventually_s (K m T s : ℝ) (hs : 0 < s) (h : (1 - m) * T < K / s) :
    ∀ᶠ x in 𝓝 s, clock K m T x = K / x + m * T := by
  have hc : ContinuousAt (fun x : ℝ => K / x) s := continuousAt_const.div continuousAt_id hs.ne'
  have hev : ∀ᶠ x in 𝓝 s, (1 - m) * T < K / x :=
    hc.eventually ((isOpen_Ioi.eventually_mem h).mono (fun y hy => hy))
  filter_upwards [hev] with x hx
  exact clock_cap K m T x hx

theorem clock_adopt_eventually_s (K m T s : ℝ) (hs : 0 < s) (h : K / s < (1 - m) * T) :
    ∀ᶠ x in 𝓝 s, clock K m T x = (1 - m) * T + m * T := by
  have hc : ContinuousAt (fun x : ℝ => K / x) s := continuousAt_const.div continuousAt_id hs.ne'
  have hev : ∀ᶠ x in 𝓝 s, K / x < (1 - m) * T :=
    hc.eventually ((isOpen_Iio.eventually_mem h).mono (fun y hy => hy))
  filter_upwards [hev] with x hx
  exact clock_adopt K m T x hx

theorem hasDerivAt_K_div (K s : ℝ) (hs : 0 < s) :
    HasDerivAt (fun x : ℝ => K / x) (-(K / s ^ 2)) s := by
  have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs.ne'
  have h := hinv.const_mul K
  simp only [div_eq_mul_inv] at *
  convert h using 1
  field_simp

/-- The clock's speed derivative on the capability branch: `t′ = −K/s²`, so `s·t′ = −K/s`. -/
theorem clock_hasDerivAt_s_cap (K m T s : ℝ) (hs : 0 < s) (h : (1 - m) * T < K / s) :
    HasDerivAt (fun x : ℝ => clock K m T x) (-(K / s ^ 2)) s := by
  have hd : HasDerivAt (fun x : ℝ => K / x + m * T) (-(K / s ^ 2)) s :=
    (hasDerivAt_K_div K s hs).add_const _
  exact hd.congr_of_eventuallyEq (clock_cap_eventually_s K m T s hs h)

/-- The clock's speed derivative on the adoption branch is zero. -/
theorem clock_hasDerivAt_s_adopt (K m T s : ℝ) (hs : 0 < s) (h : K / s < (1 - m) * T) :
    HasDerivAt (fun x : ℝ => clock K m T x) 0 s :=
  (hasDerivAt_const s _).congr_of_eventuallyEq (clock_adopt_eventually_s K m T s hs h)

/-- **`∂t_D/∂K_D = χ_D/s`** (A0), for the actual max clock, off the kink. -/
theorem clock_hasDerivAt_K (K m T s : ℝ) (_hs : 0 < s) (hkink : K / s ≠ (1 - m) * T) :
    HasDerivAt (fun k : ℝ => clock k m T s) (chi K m T s / s) K := by
  rcases lt_or_gt_of_ne hkink with hlt | hgt
  · -- adoption branch
    have hc : ContinuousAt (fun k : ℝ => k / s) K := continuousAt_id.div_const s
    have hev : ∀ᶠ k in 𝓝 K, k / s < (1 - m) * T :=
      hc.eventually ((isOpen_Iio.eventually_mem hlt).mono (fun y hy => hy))
    have heq : ∀ᶠ k in 𝓝 K, clock k m T s = (1 - m) * T + m * T := by
      filter_upwards [hev] with k hk
      exact clock_adopt k m T s hk
    have hchi : chi K m T s = 0 := by simp [chi, not_lt.mpr hlt.le]
    rw [hchi, zero_div]
    exact (hasDerivAt_const K _).congr_of_eventuallyEq heq
  · -- capability branch
    have hc : ContinuousAt (fun k : ℝ => k / s) K := continuousAt_id.div_const s
    have hev : ∀ᶠ k in 𝓝 K, (1 - m) * T < k / s :=
      hc.eventually ((isOpen_Ioi.eventually_mem hgt).mono (fun y hy => hy))
    have heq : ∀ᶠ k in 𝓝 K, clock k m T s = k / s + m * T := by
      filter_upwards [hev] with k hk
      exact clock_cap k m T s hk
    have hchi : chi K m T s = 1 := by simp [chi, hgt]
    rw [hchi]
    have hd : HasDerivAt (fun k : ℝ => k / s + m * T) (1 / s) K := by
      simpa using ((hasDerivAt_id K).div_const s).add_const (m * T)
    exact hd.congr_of_eventuallyEq heq

theorem gate_at (h : ℝ → ℝ) (K : ℝ) : gate h K K = h K := by simp [gate]

/-- The gated profile is zero strictly below the threshold. -/
theorem gate_zero_below (h : ℝ → ℝ) (K c : ℝ) (hc : c < K) : gate h K c = 0 := by
  simp [gate, hc]

theorem convA_at (ĥ : ℝ → ℝ) (K : ℝ) (hK : K ≠ 0) : convA ĥ K K = ĥ 1 := by
  simp [convA, div_self hK]

/-- **The gated profile has ramp average zero.**  §4a.2: "the gated level profile has ramp average
`h̄_M = 0`".  Proved of the profile, not substituted by hand. -/
theorem gate_hbar (h : ℝ → ℝ) (K : ℝ) (hK : 0 < K) : hbar (gate h K) K = 0 := by
  have : (∫ c in (0:ℝ)..K, gate h K c) = 0 := by
    rw [integral_congr_Ioo_of_le hK.le (g := fun _ : ℝ => (0:ℝ)) ?_]
    · simp
    · intro c hc; exact gate_zero_below h K c hc.2
  rw [hbar, this, zero_div]

/-- Along the capability path `c(t) = min(st, K)` the gated profile is the arrival-on step. -/
theorem gate_path (h : ℝ → ℝ) (K s : ℝ) (hs : 0 < s) (t : ℝ) :
    gate h K (min (s * t) K) = step 0 (h K) (K / s) t := by
  by_cases ht : t < K / s
  · have hst : s * t < K := by
      calc s * t < s * (K / s) := mul_lt_mul_of_pos_left ht hs
      _ = K := mul_div_cancel₀ K hs.ne'
    simp [gate, step, ht, min_eq_left hst.le, hst]
  · have hst : K ≤ s * t := by
      calc K = s * (K / s) := (mul_div_cancel₀ K hs.ne').symm
      _ ≤ s * t := mul_le_mul_of_nonneg_left (not_lt.mp ht) hs.le
    simp [gate, step, ht, min_eq_right hst]

/-- With closure, the gated level-set hazard is the arrival-on two-step hazard. -/
theorem gate_levHaz (h : ℝ → ℝ) (K s tD P : ℝ) (hs : 0 < s) (t : ℝ) :
    levHaz (gate h K) K s tD P t = step2 0 (h K) P (K / s) tD t := by
  by_cases ht : t < K / s
  · have hst : s * t < K := by
      calc s * t < s * (K / s) := mul_lt_mul_of_pos_left ht hs
      _ = K := mul_div_cancel₀ K hs.ne'
    simp [levHaz, step2, gate, ht, hst]
  · simp [levHaz, step2, gate, ht]

/-- **The gated level-set loss is the speed-set arrival-on loss of a hazard constant in `s`.**
No closure.  This is the object-level form of "the gated profile holds the hazard constant after
arrival, which is what a constant `Λ_M` means" (A4b). -/
theorem gate_plateau_eq_CArr (h : ℝ → ℝ) (K L s : ℝ) (hs : 0 < s) :
    CLevPlateau (gate h K) K L s = CArr (fun _ => h K) K L s := by
  unfold CLevPlateau CArr
  congr 1
  funext t
  exact gate_path h K s hs t

/-- The same with closure at `t_D` to the residual `P`. -/
theorem gate_close_eq_CArrClose (h : ℝ → ℝ) (K L s tD P : ℝ) (hs : 0 < s) :
    CLev (gate h K) K L s tD P = CArrClose (fun _ => h K) K L s tD P := by
  unfold CLev CArrClose
  congr 1
  funext t
  exact gate_levHaz h K s tD P hs t

theorem gate_plateau_eventuallyEq (h : ℝ → ℝ) (K L s : ℝ) (hs : 0 < s) :
    (fun x => CLevPlateau (gate h K) K L x) =ᶠ[𝓝 s] (fun x => CArr (fun _ => h K) K L x) := by
  filter_upwards [isOpen_Ioi.mem_nhds hs] with x hx
  exact gate_plateau_eq_CArr h K L x hx

theorem gate_close_eventuallyEq (h : ℝ → ℝ) (TD : ℝ → ℝ) (K L s P : ℝ) (hs : 0 < s) :
    (fun x => CLev (gate h K) K L x (TD x) P)
      =ᶠ[𝓝 s] (fun x => CArrClose (fun _ => h K) K L x (TD x) P) := by
  filter_upwards [isOpen_Ioi.mem_nhds hs] with x hx
  exact gate_close_eq_CArrClose h K L x (TD x) P hx

/-! ## A speed-set arrival-on derivative that allows `t_D = τ_M` on a neighbourhood

`Group1.r3_hasDerivAt` needs `τ_M < t_D` strictly.  The `K_M`-paced capability branch with
`m_D T_D = 0` has `t_D ≡ τ_M` on a neighbourhood, where the closed form still holds; this lemma
needs only the weak ordering on a neighbourhood. -/

theorem arrClose_hasDerivAt_weak (Λ TD : ℝ → ℝ) (L K s P lam' tD' : ℝ) (hK : 0 ≤ K)
    (hs : 0 < s) (hΛ : HasDerivAt Λ lam' s) (hTD : HasDerivAt TD tD' s)
    (hord : ∀ᶠ x in 𝓝 s, K / x ≤ TD x ∧ TD x ≤ L) :
    HasDerivAt (fun x : ℝ => CArrClose Λ K L x (TD x) P)
      (lam' * (TD s - K / s) + Λ s * (tD' + K / s ^ 2) + P * -tD') s := by
  have hwindow : HasDerivAt (fun x : ℝ => TD x - K / x) (tD' + K / s ^ 2) s := by
    convert hTD.sub (hasDerivAt_K_div K s hs) using 1
    ring
  have h := (hΛ.mul hwindow).add ((hTD.const_sub L).const_mul P)
  refine h.congr_of_eventuallyEq ?_
  filter_upwards [hord, isOpen_Ioi.mem_nhds hs] with x hx hx0
  exact CArrClose_eq Λ K L x (TD x) P (div_nonneg hK (le_of_lt hx0)) hx.1 hx.2

/-! ## The translation theorem (row I) -/

/-- A loss whose hazard is `a` before the deployment date `t_D` and a schedule `b` that moves
rigidly with `t_D` after it: `∫_0^L (a t if t < t_D, else b(t − t_D))`. -/
noncomputable def CTrans (a b : ℝ → ℝ) (L tD : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, if t < tD then a t else b (t - tD)

/-- Speed-set ramp-on misuse loss with a step to the residual `P` at `t_D`, **defined as the
integral**: the hazard `Λ(s)` runs from date 0 to `t_D`, then `P`. -/
noncomputable def CRamp (Λ : ℝ → ℝ) (L s tD P : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, step (Λ s) P tD t

/-- Splitting the translated loss at the deployment date. -/
theorem CTrans_split (a b : ℝ → ℝ) (L u : ℝ) (ha : IntervalIntegrable a volume 0 L)
    (hb : IntervalIntegrable b volume 0 L) (hu0 : 0 ≤ u) (huL : u ≤ L) :
    CTrans a b L u = (∫ t in (0:ℝ)..u, a t) + ∫ x in (0:ℝ)..(L - u), b x := by
  have hau : IntervalIntegrable a volume 0 u :=
    ha.mono_set (by rw [uIcc_of_le hu0, uIcc_of_le (hu0.trans huL)]; exact Icc_subset_Icc le_rfl huL)
  have hbu : IntervalIntegrable b volume 0 (L - u) :=
    hb.mono_set (by
      rw [uIcc_of_le (by linarith), uIcc_of_le (hu0.trans huL)]
      exact Icc_subset_Icc le_rfl (by linarith))
  have hb' : IntervalIntegrable (fun x => b (x - u)) volume u L := by
    have := hbu.comp_sub_right u
    simpa using this
  have hi1 : IntervalIntegrable (fun t => if t < u then a t else b (t - u)) volume 0 u := by
    rw [intervalIntegrable_congr_uIoo (g := a) ?_]
    · exact hau
    · intro t ht; rw [uIoo_of_le hu0] at ht; simp [ht.2]
  have hi2 : IntervalIntegrable (fun t => if t < u then a t else b (t - u)) volume u L := by
    rw [intervalIntegrable_congr_uIoo (g := fun x => b (x - u)) ?_]
    · exact hb'
    · intro t ht; rw [uIoo_of_le huL] at ht; simp [not_lt.mpr ht.1.le]
  have e1 : (∫ t in (0:ℝ)..u, (if t < u then a t else b (t - u))) = ∫ t in (0:ℝ)..u, a t := by
    rw [integral_congr_Ioo_of_le hu0 (g := a) ?_]
    intro t ht; simp [ht.2]
  have e2 : (∫ t in u..L, (if t < u then a t else b (t - u))) = ∫ x in (0:ℝ)..(L - u), b x := by
    rw [integral_congr_Ioo_of_le huL (g := fun x => b (x - u)) ?_]
    · rw [intervalIntegral.integral_comp_sub_right, sub_self]
    · intro t ht; simp [not_lt.mpr ht.1.le]
  rw [CTrans, ← integral_add_adjacent_intervals hi1 hi2, e1, e2]

/-- **The translation theorem (A4a.7(i), "What the result is").**  The derivative of the loss with
respect to a rigid shift of the post-deployment block is the hazard the block enters on, `a(t_D)`,
minus the hazard it leaves on at the horizon, `b(L − t_D)`.  Nothing about the jump at `t_D`
enters, which is why the step is a special case and not the reason. -/
theorem trans_hasDerivAt (a b : ℝ → ℝ) (L tD : ℝ) (ha : IntervalIntegrable a volume 0 L)
    (hb : IntervalIntegrable b volume 0 L) (h0 : 0 < tD) (hL : tD < L)
    (hac : ContinuousAt a tD) (ham : StronglyMeasurableAtFilter a (𝓝 tD))
    (hbc : ContinuousAt b (L - tD)) (hbm : StronglyMeasurableAtFilter b (𝓝 (L - tD))) :
    HasDerivAt (fun u => CTrans a b L u) (a tD - b (L - tD)) tD := by
  have hat : IntervalIntegrable a volume 0 tD :=
    ha.mono_set (by
      rw [uIcc_of_le h0.le, uIcc_of_le (h0.le.trans hL.le)]
      exact Icc_subset_Icc le_rfl hL.le)
  have hbt : IntervalIntegrable b volume 0 (L - tD) :=
    hb.mono_set (by
      rw [uIcc_of_le (by linarith), uIcc_of_le (h0.le.trans hL.le)]
      exact Icc_subset_Icc le_rfl (by linarith))
  have hA : HasDerivAt (fun u => ∫ t in (0:ℝ)..u, a t) (a tD) tD :=
    integral_hasDerivAt_right hat ham hac
  have hB0 : HasDerivAt (fun v => ∫ x in (0:ℝ)..v, b x) (b (L - tD)) (L - tD) :=
    integral_hasDerivAt_right hbt hbm hbc
  have hlin : HasDerivAt (fun u : ℝ => L - u) (-1) tD := by
    simpa using (hasDerivAt_id tD).const_sub L
  have hB : HasDerivAt (fun u => ∫ x in (0:ℝ)..(L - u), b x) (b (L - tD) * -1) tD :=
    hB0.comp tD hlin
  have hsum := hA.add hB
  have heq : ∀ᶠ u in 𝓝 tD, CTrans a b L u
      = (∫ t in (0:ℝ)..u, a t) + ∫ x in (0:ℝ)..(L - u), b x := by
    filter_upwards [isOpen_Ioi.mem_nhds h0, isOpen_Iio.mem_nhds hL] with u hu0 huL
    exact CTrans_split a b L u ha hb (le_of_lt hu0) (le_of_lt huL)
  convert hsum.congr_of_eventuallyEq heq using 1
  ring

/-! ## Row I: the `K_D` derivative of every defined loss -/

theorem clock_continuous_K (m T s : ℝ) : Continuous (fun k : ℝ => clock k m T s) := by
  unfold clock
  exact ((continuous_id.div_const s).max continuous_const).add continuous_const

/-- What the translation theorem needs of a pre-deployment hazard at the deployment date. -/
def PreOK (a : ℝ → ℝ) (L tD plat : ℝ) : Prop :=
  IntervalIntegrable a volume 0 L ∧ ContinuousAt a tD ∧ StronglyMeasurableAtFilter a (𝓝 tD) ∧
    a tD = plat

/-- A hazard that is the constant `c` after `d` meets the conditions at any `t_D > d`. -/
theorem preOK_of_eqOn (a : ℝ → ℝ) (L d tD c : ℝ) (ha : IntervalIntegrable a volume 0 L)
    (hd : d < tD) (heq : EqOn a (fun _ => c) (Ioi d)) : PreOK a L tD c := by
  have hcon : ContinuousOn a (Ioi d) := continuousOn_const.congr heq
  exact ⟨ha, hcon.continuousAt (isOpen_Ioi.mem_nhds hd),
    hcon.stronglyMeasurableAtFilter isOpen_Ioi tD hd, heq hd⟩

/-- The level-set pre-deployment hazard on the capability path, `h(min(st, K))`.  With `h` the
fixed profile this is convention B ramp-on; with `convA ĥ K` convention A ramp-on; with a gated
profile it is the arrival-on reading. -/
noncomputable def preLev (h : ℝ → ℝ) (K s : ℝ) : ℝ → ℝ := fun t => h (min (s * t) K)

theorem preLev_ok (h : ℝ → ℝ) (K L s tD : ℝ) (hint : IntervalIntegrable h volume 0 K)
    (hs : 0 < s) (hK : 0 ≤ K) (hD : K / s < tD) (hL : tD < L) :
    PreOK (preLev h K s) L tD (h K) := by
  have hτ : 0 ≤ K / s := by positivity
  have hKL : K / s ≤ L := (hD.trans hL).le
  have hramp : IntervalIntegrable (fun t => h (s * t)) volume 0 (K / s) := by
    have := hint.comp_mul_left (c := s)
    simpa using this
  have h1 : IntervalIntegrable (preLev h K s) volume 0 (K / s) := by
    rw [intervalIntegrable_congr_uIoo (g := fun t => h (s * t)) ?_]
    · exact hramp
    · intro t ht
      rw [uIoo_of_le hτ] at ht
      have hst : s * t ≤ K := by
        calc s * t ≤ s * (K / s) := mul_le_mul_of_nonneg_left ht.2.le hs.le
        _ = K := mul_div_cancel₀ K hs.ne'
      simp [preLev, min_eq_left hst]
  have heq : EqOn (preLev h K s) (fun _ => h K) (Ioi (K / s)) := by
    intro t ht
    have hst : K ≤ s * t := by
      calc K = s * (K / s) := (mul_div_cancel₀ K hs.ne').symm
      _ ≤ s * t := mul_le_mul_of_nonneg_left (le_of_lt ht) hs.le
    simp [preLev, min_eq_right hst]
  have h2 : IntervalIntegrable (preLev h K s) volume (K / s) L := by
    rw [intervalIntegrable_congr_uIoo (g := fun _ => h K) ?_]
    · exact intervalIntegrable_const
    · intro t ht
      rw [uIoo_of_le hKL] at ht
      exact heq ht.1
  exact preOK_of_eqOn _ L (K / s) tD (h K) (h1.trans h2) hD heq

theorem gate_intervalIntegrable (h : ℝ → ℝ) (K : ℝ) (hK : 0 ≤ K) :
    IntervalIntegrable (gate h K) volume 0 K := by
  rw [intervalIntegrable_congr_uIoo (g := fun _ => (0:ℝ)) ?_]
  · exact intervalIntegrable_const
  · intro c hc
    rw [uIoo_of_le hK] at hc
    exact gate_zero_below h K c hc.2

theorem convA_intervalIntegrable (ĥ : ℝ → ℝ) (K : ℝ) (hint : IntervalIntegrable ĥ volume 0 1)
    (_hK : 0 < K) : IntervalIntegrable (convA ĥ K) volume 0 K := by
  have := hint.comp_mul_left (c := K⁻¹)
  have hfun : (fun x => ĥ (K⁻¹ * x)) = convA ĥ K := by
    funext x; simp [convA, div_eq_inv_mul]
  rw [hfun] at this
  simpa using this

/-- The level-set loss **is** a translated loss: `CLev` with any profile, on `τ_M ≤ t_D`. -/
theorem CLev_eq_trans (h : ℝ → ℝ) (K L s tD P : ℝ) (hs : 0 < s) (hD : K / s ≤ tD) :
    CLev h K L s tD P = CTrans (preLev h K s) (fun _ => P) L tD := by
  unfold CLev CTrans
  congr 1
  funext t
  by_cases h1 : t < K / s
  · have hst : s * t ≤ K := by
      calc s * t ≤ s * (K / s) := mul_le_mul_of_nonneg_left h1.le hs.le
      _ = K := mul_div_cancel₀ K hs.ne'
    have h2 : t < tD := lt_of_lt_of_le h1 hD
    simp [levHaz, preLev, h1, h2, min_eq_left hst]
  · by_cases h2 : t < tD
    · have hst : K ≤ s * t := by
        calc K = s * (K / s) := (mul_div_cancel₀ K hs.ne').symm
        _ ≤ s * t := mul_le_mul_of_nonneg_left (not_lt.mp h1) hs.le
      simp [levHaz, preLev, h1, h2, min_eq_right hst]
    · simp [levHaz, h1, h2]

/-- The speed-set arrival-on loss is a translated loss on `τ_M ≤ t_D`. -/
theorem CArrClose_eq_trans (Λ : ℝ → ℝ) (K L s tD P : ℝ) (hD : K / s ≤ tD) :
    CArrClose Λ K L s tD P = CTrans (step 0 (Λ s) (K / s)) (fun _ => P) L tD := by
  unfold CArrClose CTrans
  congr 1
  funext t
  by_cases h1 : t < K / s
  · have h2 : t < tD := lt_of_lt_of_le h1 hD
    simp [step2, step, h1, h2]
  · by_cases h2 : t < tD
    · simp [step2, step, h1, h2]
    · simp [step2, h1, h2]

/-- The speed-set ramp-on loss is a translated loss. -/
theorem CRamp_eq_trans (Λ : ℝ → ℝ) (L s tD P : ℝ) :
    CRamp Λ L s tD P = CTrans (fun _ => Λ s) (fun _ => P) L tD := by
  unfold CRamp CTrans
  rfl

/-- The translated loss, composed with the actual clock, differentiated in `K_D`:
`(χ_D/s)(a(t_D) − P)`. -/
theorem trans_kd (a : ℝ → ℝ) (L s KD m T P plat : ℝ) (hs : 0 < s)
    (hkink : KD / s ≠ (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L)
    (ha : PreOK a L (clock KD m T s) plat) :
    HasDerivAt (fun k => CTrans a (fun _ => P) L (clock k m T s))
      (chi KD m T s / s * (plat - P)) KD := by
  have hF := trans_hasDerivAt a (fun _ => P) L (clock KD m T s) ha.1 intervalIntegrable_const h0
    hL ha.2.1 ha.2.2.1 continuousAt_const
    (continuous_const.aestronglyMeasurable.stronglyMeasurableAtFilter)
  have h : HasDerivAt (fun k => CTrans a (fun _ => P) L (clock k m T s))
      ((a (clock KD m T s) - P) * (chi KD m T s / s)) KD := by
    have hc := hF.comp KD (clock_hasDerivAt_K KD m T s hs hkink)
    exact hc
  rw [ha.2.2.2] at h
  convert h using 1
  ring

theorem clock_eventually_gt (KD m T s c : ℝ) (h : c < clock KD m T s) :
    ∀ᶠ k in 𝓝 KD, c < clock k m T s :=
  (clock_continuous_K m T s).continuousAt.eventually
    ((isOpen_Ioi.eventually_mem h).mono (fun _ hx => hx))

/-- **Lemma 1(d) for every level-set loss.**  `CLev` with any profile integrable on `[0, K_M]`,
on the actual clock: `∂C_M/∂K_D = (χ_D/s)(h(K_M) − h_M^post)`. -/
theorem i_CLev_kd (h : ℝ → ℝ) (K L s KD m T P : ℝ) (hint : IntervalIntegrable h volume 0 K)
    (hs : 0 < s) (hK : 0 ≤ K) (hkink : KD / s ≠ (1 - m) * T)
    (hD : K / s < clock KD m T s) (hL : clock KD m T s < L) :
    HasDerivAt (fun k => CLev h K L s (clock k m T s) P) (chi KD m T s / s * (h K - P)) KD := by
  have h0 : 0 < clock KD m T s := lt_of_le_of_lt (by positivity) hD
  have hd := trans_kd (preLev h K s) L s KD m T P (h K) hs hkink h0 hL
    (preLev_ok h K L s _ hint hs hK hD hL)
  refine hd.congr_of_eventuallyEq ?_
  filter_upwards [clock_eventually_gt KD m T s (K / s) hD] with k hk
  exact CLev_eq_trans h K L s (clock k m T s) P hs hk.le

/-- **Row I, level-set, convention B, ramp-on.** -/
theorem i_levB_rampon (h : ℝ → ℝ) (K L s KD m T P : ℝ) (hint : IntervalIntegrable h volume 0 K)
    (hs : 0 < s) (hK : 0 ≤ K) (hkink : KD / s ≠ (1 - m) * T)
    (hD : K / s < clock KD m T s) (hL : clock KD m T s < L) :
    HasDerivAt (fun k => CLev h K L s (clock k m T s) P) (chi KD m T s / s * (h K - P)) KD :=
  i_CLev_kd h K L s KD m T P hint hs hK hkink hD hL

/-- **Row I, level-set, convention A, ramp-on.**  The plateau hazard is `ĥ(1)`. -/
theorem i_levA_rampon (ĥ : ℝ → ℝ) (K L s KD m T P : ℝ) (hint : IntervalIntegrable ĥ volume 0 1)
    (hs : 0 < s) (hK : 0 < K) (hkink : KD / s ≠ (1 - m) * T)
    (hD : K / s < clock KD m T s) (hL : clock KD m T s < L) :
    HasDerivAt (fun k => CLev (convA ĥ K) K L s (clock k m T s) P)
      (chi KD m T s / s * (ĥ 1 - P)) KD := by
  have := i_CLev_kd (convA ĥ K) K L s KD m T P (convA_intervalIntegrable ĥ K hint hK) hs hK.le
    hkink hD hL
  rwa [convA_at ĥ K hK.ne'] at this

/-- **Row I, level-set, convention B, arrival-on** (the gated profile).  No integrability
hypothesis: the gated profile is zero on the ramp. -/
theorem i_levB_arrival (h : ℝ → ℝ) (K L s KD m T P : ℝ) (hs : 0 < s) (hK : 0 ≤ K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L) :
    HasDerivAt (fun k => CLev (gate h K) K L s (clock k m T s) P)
      (chi KD m T s / s * (h K - P)) KD := by
  have := i_CLev_kd (gate h K) K L s KD m T P (gate_intervalIntegrable h K hK) hs hK hkink hD hL
  rwa [gate_at] at this

/-- **Row I, level-set, convention A, arrival-on.** -/
theorem i_levA_arrival (ĥ : ℝ → ℝ) (K L s KD m T P : ℝ) (hs : 0 < s) (hK : 0 < K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L) :
    HasDerivAt (fun k => CLev (gate (convA ĥ K) K) K L s (clock k m T s) P)
      (chi KD m T s / s * (ĥ 1 - P)) KD := by
  have := i_CLev_kd (gate (convA ĥ K) K) K L s KD m T P
    (gate_intervalIntegrable _ K hK.le) hs hK.le hkink hD hL
  rwa [gate_at, convA_at ĥ K hK.ne'] at this

/-- **Row I, speed-set, ramp-on.**  The plateau hazard is `Λ_M(s)`.  Only `0 < t_D` is used;
`τ_M < t_D` implies it. -/
theorem i_speed_rampon (Λ : ℝ → ℝ) (L s KD m T P : ℝ) (hs : 0 < s)
    (hkink : KD / s ≠ (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L) :
    HasDerivAt (fun k => CRamp Λ L s (clock k m T s) P) (chi KD m T s / s * (Λ s - P)) KD := by
  have hpre : PreOK (fun _ => Λ s) L (clock KD m T s) (Λ s) :=
    ⟨intervalIntegrable_const, continuousAt_const,
      continuous_const.aestronglyMeasurable.stronglyMeasurableAtFilter, rfl⟩
  have hd := trans_kd (fun _ => Λ s) L s KD m T P (Λ s) hs hkink h0 hL hpre
  refine hd.congr_of_eventuallyEq (Eventually.of_forall (fun k => ?_))
  exact CRamp_eq_trans Λ L s (clock k m T s) P

theorem preArr_ok (Λ : ℝ → ℝ) (K L s tD : ℝ) (hs : 0 < s) (hK : 0 ≤ K) (hD : K / s < tD)
    (hL : tD < L) : PreOK (step 0 (Λ s) (K / s)) L tD (Λ s) := by
  have hτ : 0 ≤ K / s := by positivity
  refine preOK_of_eqOn _ L (K / s) tD (Λ s)
    (intervalIntegrable_step 0 (Λ s) 0 (K / s) L hτ (hD.trans hL).le) hD ?_
  intro t ht
  have hnt : ¬ t < K / s := not_lt.mpr (le_of_lt (mem_Ioi.mp ht))
  simp [step, hnt]

/-- **Row I, speed-set, arrival-on.** -/
theorem i_speed_arrival (Λ : ℝ → ℝ) (K L s KD m T P : ℝ) (hs : 0 < s) (hK : 0 ≤ K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L) :
    HasDerivAt (fun k => CArrClose Λ K L s (clock k m T s) P)
      (chi KD m T s / s * (Λ s - P)) KD := by
  have h0 : 0 < clock KD m T s := lt_of_le_of_lt (by positivity) hD
  have hd := trans_kd (step 0 (Λ s) (K / s)) L s KD m T P (Λ s) hs hkink h0 hL
    (preArr_ok Λ K L s _ hs hK hD hL)
  refine hd.congr_of_eventuallyEq ?_
  filter_upwards [clock_eventually_gt KD m T s (K / s) hD] with k hk
  exact CArrClose_eq_trans Λ K L s (clock k m T s) P hk.le

/-- **Row I, the sign condition, free of the three choices.**  Shortening `K_D` lowers misuse loss
(the `K_D` derivative is positive) iff `χ_D = 1` and the plateau hazard exceeds the residual; on
the adoption branch the derivative is zero; on the capability branch with the residual above the
plateau it is negative, so shortening `K_D` raises loss. -/
theorem i_sign (KD m T s plat P : ℝ) (hs : 0 < s) :
    (0 < chi KD m T s / s * (plat - P) ↔ chi KD m T s = 1 ∧ P < plat) ∧
    (chi KD m T s = 0 → chi KD m T s / s * (plat - P) = 0) ∧
    (chi KD m T s = 1 → plat < P → chi KD m T s / s * (plat - P) < 0) := by
  refine ⟨?_, fun h0 => by rw [h0]; ring, fun h1 hlt => ?_⟩
  · unfold chi
    split_ifs with hb
    · constructor
      · intro hpos
        refine ⟨rfl, ?_⟩
        have : 0 < plat - P := by
          by_contra hc
          push Not at hc
          have : 1 / s * (plat - P) ≤ 0 :=
            mul_nonpos_of_nonneg_of_nonpos (by positivity) hc
          linarith
        linarith
      · rintro ⟨-, hlt⟩
        exact mul_pos (by positivity) (sub_pos.mpr hlt)
    · simp
  · rw [h1]
    exact mul_neg_of_pos_of_neg (by positivity) (sub_neg.mpr hlt)

theorem chi_adopt (KD m T s : ℝ) (h : KD / s < (1 - m) * T) : chi KD m T s = 0 := by
  simp [chi, not_lt.mpr h.le]

/-- **l.1006's printed clock is not the clock on the adoption branch.**  "`t_D = χ_DK_D/s +
m_DT_D`" gives `m_DT_D` there, but the actual clock (l.134, l.840) is `T_D`; they differ whenever
the adoption term binds and `K_D ≥ 0`.  (On the capability branch they agree: `clock_cap`.) -/
theorem i_l1006_formula_adopt_ne (KD m T s : ℝ) (hKD : 0 ≤ KD) (hs : 0 < s)
    (hadopt : KD / s < (1 - m) * T) : chi KD m T s * KD / s + m * T ≠ clock KD m T s := by
  have hchi : chi KD m T s = 0 := by simp [chi, not_lt.mpr hadopt.le]
  rw [hchi, clock_adopt KD m T s hadopt]
  have : 0 ≤ KD / s := div_nonneg hKD hs.le
  intro h
  simp only [zero_mul, zero_div, zero_add] at h
  linarith

/-- The instance: `K_D = 1`, `m_D = 0`, `T_D = 2`, `s = 1`; the clock is 2, the printed
expression 0. -/
theorem i_l1006_formula_instance : clock 1 0 2 1 = 2 ∧ chi 1 0 2 1 * 1 / 1 + 0 * 2 = 0 := by
  have hadopt : (1:ℝ) / 1 < (1 - 0) * 2 := by norm_num
  have hchi : chi 1 0 2 1 = 0 := by simp [chi]
  rw [clock_adopt 1 0 2 1 hadopt, hchi]
  norm_num

theorem chi_cap (KD m T s : ℝ) (h : (1 - m) * T < KD / s) : chi KD m T s = 1 := by
  simp [chi, h]

/-- **Row I, "once the wait is set by adoption, further cuts buy nothing"**, for every level-set
loss (any profile: B or A, ungated or gated): on the adoption branch the `K_D` derivative of the
defined loss is exactly zero. -/
theorem i_CLev_kd_adopt (h : ℝ → ℝ) (K L s KD m T P : ℝ) (hint : IntervalIntegrable h volume 0 K)
    (hs : 0 < s) (hK : 0 ≤ K) (hadopt : KD / s < (1 - m) * T)
    (hD : K / s < clock KD m T s) (hL : clock KD m T s < L) :
    HasDerivAt (fun k => CLev h K L s (clock k m T s) P) 0 KD := by
  have := i_CLev_kd h K L s KD m T P hint hs hK hadopt.ne hD hL
  rwa [chi_adopt KD m T s hadopt, zero_div, zero_mul] at this

/-- The same on the adoption branch, speed-set ramp-on. -/
theorem i_speed_rampon_adopt (Λ : ℝ → ℝ) (L s KD m T P : ℝ) (hs : 0 < s)
    (hadopt : KD / s < (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L) :
    HasDerivAt (fun k => CRamp Λ L s (clock k m T s) P) 0 KD := by
  have := i_speed_rampon Λ L s KD m T P hs hadopt.ne h0 hL
  rwa [chi_adopt KD m T s hadopt, zero_div, zero_mul] at this

/-- The same on the adoption branch, speed-set arrival-on. -/
theorem i_speed_arrival_adopt (Λ : ℝ → ℝ) (K L s KD m T P : ℝ) (hs : 0 < s) (hK : 0 ≤ K)
    (hadopt : KD / s < (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L) :
    HasDerivAt (fun k => CArrClose Λ K L s (clock k m T s) P) 0 KD := by
  have := i_speed_arrival Λ K L s KD m T P hs hK hadopt.ne hD hL
  rwa [chi_adopt KD m T s hadopt, zero_div, zero_mul] at this

/-- **Row I's sign condition on the defined losses** (§4a.5, A4a.7(i), the summary's "shortening
`K_D` lowers misuse loss exactly while that wait is set by capability … and while the misuse hazard
before the countermeasure arrives exceeds the residual"): for the level-set loss with any profile,
off the kink and interior, the `K_D` derivative of the defined loss is positive iff the capability
term binds and `h(K_M) > h_M^post`. -/
theorem i_CLev_kd_sign (h : ℝ → ℝ) (K L s KD m T P d : ℝ) (hint : IntervalIntegrable h volume 0 K)
    (hs : 0 < s) (hK : 0 ≤ K) (hkink : KD / s ≠ (1 - m) * T)
    (hD : K / s < clock KD m T s) (hL : clock KD m T s < L)
    (hd : HasDerivAt (fun k => CLev h K L s (clock k m T s) P) d KD) :
    0 < d ↔ (1 - m) * T < KD / s ∧ P < h K := by
  rw [hd.unique (i_CLev_kd h K L s KD m T P hint hs hK hkink hD hL), (i_sign KD m T s _ P hs).1]
  constructor
  · rintro ⟨h1, h2⟩
    refine ⟨?_, h2⟩
    by_contra hc
    rw [chi_adopt KD m T s (lt_of_le_of_ne (not_lt.mp hc) hkink)] at h1
    exact zero_ne_one h1
  · rintro ⟨h1, h2⟩
    exact ⟨chi_cap KD m T s h1, h2⟩

/-- The same sign condition for the speed-set arrival-on loss. -/
theorem i_speed_arrival_sign (Λ : ℝ → ℝ) (K L s KD m T P d : ℝ) (hs : 0 < s) (hK : 0 ≤ K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L)
    (hd : HasDerivAt (fun k => CArrClose Λ K L s (clock k m T s) P) d KD) :
    0 < d ↔ (1 - m) * T < KD / s ∧ P < Λ s := by
  rw [hd.unique (i_speed_arrival Λ K L s KD m T P hs hK hkink hD hL),
    (i_sign KD m T s _ P hs).1]
  constructor
  · rintro ⟨h1, h2⟩
    refine ⟨?_, h2⟩
    by_contra hc
    rw [chi_adopt KD m T s (lt_of_le_of_ne (not_lt.mp hc) hkink)] at h1
    exact zero_ne_one h1
  · rintro ⟨h1, h2⟩
    exact ⟨chi_cap KD m T s h1, h2⟩

/-- The same sign condition for the speed-set ramp-on loss. -/
theorem i_speed_rampon_sign (Λ : ℝ → ℝ) (L s KD m T P d : ℝ) (hs : 0 < s)
    (hkink : KD / s ≠ (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L)
    (hd : HasDerivAt (fun k => CRamp Λ L s (clock k m T s) P) d KD) :
    0 < d ↔ (1 - m) * T < KD / s ∧ P < Λ s := by
  rw [hd.unique (i_speed_rampon Λ L s KD m T P hs hkink h0 hL), (i_sign KD m T s _ P hs).1]
  constructor
  · rintro ⟨h1, h2⟩
    refine ⟨?_, h2⟩
    by_contra hc
    rw [chi_adopt KD m T s (lt_of_le_of_ne (not_lt.mp hc) hkink)] at h1
    exact zero_ne_one h1
  · rintro ⟨h1, h2⟩
    exact ⟨chi_cap KD m T s h1, h2⟩

/-! ### Gradual coverage that translates rigidly with `t_D` -/

/-- Gradual coverage: after deployment the hazard falls from the plateau toward the residual as a
fixed coverage schedule `u` rises, `plat − u(t − t_D)(plat − P)`. -/
noncomputable def cover (plat P : ℝ) (u : ℝ → ℝ) : ℝ → ℝ := fun x => plat - u x * (plat - P)

/-- **Gradual coverage completing inside the window.**  If the schedule is fixed in shape
(integrable, nothing more) and complete (`u = 1`) from `w` on, with `t_D + w < L` (completion
before the horizon), the `K_D` derivative keeps the invariant form `(χ_D/s)(plat − P)`, whatever
the schedule does before completion. -/
theorem trans_kd_gradual (a u : ℝ → ℝ) (L s KD m T P plat w : ℝ) (hs : 0 < s)
    (hkink : KD / s ≠ (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L)
    (ha : PreOK a L (clock KD m T s) plat) (hu : IntervalIntegrable u volume 0 L)
    (hdone : ∀ x, w ≤ x → u x = 1) (hcomp : clock KD m T s + w < L) :
    HasDerivAt (fun k => CTrans a (cover plat P u) L (clock k m T s))
      (chi KD m T s / s * (plat - P)) KD := by
  have hbi : IntervalIntegrable (cover plat P u) volume 0 L := by
    unfold cover; exact intervalIntegrable_const.sub (hu.mul_const _)
  have heqb : EqOn (cover plat P u) (fun _ => P) (Ioi w) := by
    intro x hx
    simp [cover, hdone x (le_of_lt (mem_Ioi.mp hx))]
  have hw : L - clock KD m T s ∈ Ioi w := by rw [mem_Ioi]; linarith
  have hcon : ContinuousOn (cover plat P u) (Ioi w) := continuousOn_const.congr heqb
  have hF := trans_hasDerivAt a (cover plat P u) L (clock KD m T s) ha.1 hbi h0 hL ha.2.1
    ha.2.2.1 (hcon.continuousAt (isOpen_Ioi.mem_nhds hw))
    (hcon.stronglyMeasurableAtFilter isOpen_Ioi _ hw)
  have hb : cover plat P u (L - clock KD m T s) = P := heqb hw
  have h : HasDerivAt (fun k => CTrans a (cover plat P u) L (clock k m T s))
      ((a (clock KD m T s) - cover plat P u (L - clock KD m T s)) * (chi KD m T s / s)) KD := by
    have hc := hF.comp KD (clock_hasDerivAt_K KD m T s hs hkink)
    exact hc
  rw [ha.2.2.2, hb] at h
  convert h using 1
  ring

/-- **The printed replacement when coverage is still rising at `L`.**  Linear coverage over
`[t_D, t_D + w]` with `w ≥ L − t_D` (so the boundary `w = L − t_D`, completion exactly at `L`, is
included): the derivative is `(χ_D/s)(plat − P)(L − t_D)/w`. -/
theorem trans_kd_linear_trunc (a : ℝ → ℝ) (L s KD m T P plat w : ℝ) (hs : 0 < s)
    (hkink : KD / s ≠ (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L)
    (ha : PreOK a L (clock KD m T s) plat) (hw : L - clock KD m T s ≤ w) :
    HasDerivAt (fun k => CTrans a (cover plat P (fun x => min (x / w) 1)) L (clock k m T s))
      (chi KD m T s / s * (plat - P) * ((L - clock KD m T s) / w)) KD := by
  have hwpos : 0 < w := by linarith
  have hu : Continuous (fun x : ℝ => min (x / w) 1) :=
    (continuous_id.div_const w).min continuous_const
  have hbc : Continuous (cover plat P (fun x => min (x / w) 1)) := by
    unfold cover; exact continuous_const.sub (hu.mul continuous_const)
  have hF := trans_hasDerivAt a (cover plat P (fun x => min (x / w) 1)) L (clock KD m T s) ha.1
    (hbc.intervalIntegrable _ _) h0 hL ha.2.1 ha.2.2.1 hbc.continuousAt
    hbc.aestronglyMeasurable.stronglyMeasurableAtFilter
  have hle : (L - clock KD m T s) / w ≤ 1 := by
    rw [div_le_one hwpos]; exact hw
  have hb : cover plat P (fun x => min (x / w) 1) (L - clock KD m T s)
      = plat - (L - clock KD m T s) / w * (plat - P) := by
    simp only [cover, min_eq_left hle]
  have h : HasDerivAt
      (fun k => CTrans a (cover plat P (fun x => min (x / w) 1)) L (clock k m T s))
      ((a (clock KD m T s) - cover plat P (fun x => min (x / w) 1) (L - clock KD m T s))
        * (chi KD m T s / s)) KD := by
    have hc := hF.comp KD (clock_hasDerivAt_K KD m T s hs hkink)
    exact hc
  rw [ha.2.2.2, hb] at h
  convert h using 1
  ring

/-- **The invariant form fails whenever coverage completes after the horizon**, on the capability
branch with a nonzero hazard gap: the replacement differs from `(χ_D/s)(plat − P)`. -/
theorem trans_linear_trunc_ne (s plat P r : ℝ) (hs : 0 < s) (hgap : plat ≠ P) (hr : r < 1) :
    1 / s * (plat - P) * r ≠ 1 / s * (plat - P) := by
  intro h
  have hne : 1 / s * (plat - P) ≠ 0 :=
    mul_ne_zero (by positivity) (sub_ne_zero.mpr hgap)
  have : r = 1 := mul_left_cancel₀ hne (h.trans (mul_one _).symm)
  linarith

/-- **"Equals the invariant form only at `w = L − t_D`", on the defined loss.**  On the capability
branch with `plat ≠ P` and linear coverage with `w ≥ L − t_D`, any `K_D` derivative `d` of the
translated loss equals `(χ_D/s)(plat − P)` **iff** `w = L − t_D`: the "at" half (the boundary
case) and the "only" half, composed with the derivative rather than stated of a free ratio. -/
theorem trans_kd_linear_only_at (a : ℝ → ℝ) (L s KD m T P plat w d : ℝ) (hs : 0 < s)
    (hcap : (1 - m) * T < KD / s) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L)
    (ha : PreOK a L (clock KD m T s) plat) (hgap : plat ≠ P) (hw : L - clock KD m T s ≤ w)
    (hd : HasDerivAt
      (fun k => CTrans a (cover plat P (fun x => min (x / w) 1)) L (clock k m T s)) d KD) :
    d = chi KD m T s / s * (plat - P) ↔ w = L - clock KD m T s := by
  have e := hd.unique (trans_kd_linear_trunc a L s KD m T P plat w hs hcap.ne' h0 hL ha hw)
  have hwpos : 0 < w := by linarith
  rw [e, chi_cap KD m T s hcap]
  have hne : 1 / s * (plat - P) ≠ 0 := mul_ne_zero (by positivity) (sub_ne_zero.mpr hgap)
  constructor
  · intro h
    have h1 : (L - clock KD m T s) / w = 1 := mul_left_cancel₀ hne (h.trans (mul_one _).symm)
    rw [div_eq_one_iff_eq hwpos.ne'] at h1
    linarith
  · intro h
    rw [← h, div_self hwpos.ne', mul_one]

/-- **An exact nondegenerate failure instance**, on the speed-set arrival-on loss with linear
coverage.  `s = 1`, `K_M = 1`, `K_D = 2`, `m_D = 1`, `T_D = 1` (so `χ_D = 1`, `t_D = 3`), `L = 4`,
`Λ ≡ 1`, `h_M^post = 0`, coverage linear over `w = 2`, completing at 5 > L.  The `K_D`
derivative of the loss is `1/2`; the invariant form would say `1`. -/
theorem i_gradual_failure_instance :
    HasDerivAt
        (fun k => CTrans (step 0 1 (1 / 1)) (cover 1 0 (fun x => min (x / 2) 1)) 4
          (clock k 1 1 1)) (1 / 2) 2 ∧
      (1 / 2 : ℝ) ≠ chi 2 1 1 1 / 1 * (1 - 0) := by
  have hcap : (1 - (1:ℝ)) * 1 < 2 / 1 := by norm_num
  have hclk : clock 2 1 1 1 = 3 := by rw [clock_cap 2 1 1 1 hcap]; norm_num
  have hchi : chi 2 1 1 1 = 1 := by simp [chi]
  have hpre : PreOK (step 0 1 (1 / 1)) 4 (clock 2 1 1 1) 1 := by
    have := preArr_ok (fun _ => (1:ℝ)) 1 4 1 (clock 2 1 1 1) one_pos zero_le_one
      (by rw [hclk]; norm_num) (by rw [hclk]; norm_num)
    simpa using this
  have h := trans_kd_linear_trunc (step 0 1 (1 / 1)) 4 1 2 1 1 0 1 2 one_pos
    (by norm_num) (by rw [hclk]; norm_num) (by rw [hclk]; norm_num) hpre
    (by rw [hclk]; norm_num)
  rw [hclk, hchi] at h
  refine ⟨?_, ?_⟩
  · convert h using 1; norm_num
  · rw [hchi]; norm_num

/-- **Incomplete coverage need not break the form: the adoption branch.**  With linear coverage
still rising at `L` (`w ≥ L − t_D`), on the adoption branch the `K_D` derivative is zero, and so is
the invariant form `(χ_D/s)(plat − P)`: they agree for every such `w`.  So "fails when it does not
complete" holds only on the capability branch with `plat ≠ P` (`trans_kd_linear_only_at`). -/
theorem trans_kd_linear_adopt (a : ℝ → ℝ) (L s KD m T P plat w : ℝ) (hs : 0 < s)
    (hadopt : KD / s < (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L)
    (ha : PreOK a L (clock KD m T s) plat) (hw : L - clock KD m T s ≤ w) :
    HasDerivAt (fun k => CTrans a (cover plat P (fun x => min (x / w) 1)) L (clock k m T s))
      0 KD ∧ chi KD m T s / s * (plat - P) = 0 := by
  have h := trans_kd_linear_trunc a L s KD m T P plat w hs hadopt.ne h0 hL ha hw
  rw [chi_adopt KD m T s hadopt] at h ⊢
  refine ⟨?_, by ring⟩
  convert h using 1
  ring

/-- **The same with no hazard gap.**  With `plat = P`, on either branch off the kink, the
derivative of the incompletely covered loss is zero and so is the invariant form. -/
theorem trans_kd_linear_nogap (a : ℝ → ℝ) (L s KD m T P plat w : ℝ) (hs : 0 < s)
    (hkink : KD / s ≠ (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L)
    (ha : PreOK a L (clock KD m T s) plat) (hw : L - clock KD m T s ≤ w) (hgap : plat = P) :
    HasDerivAt (fun k => CTrans a (cover plat P (fun x => min (x / w) 1)) L (clock k m T s))
      0 KD ∧ chi KD m T s / s * (plat - P) = 0 := by
  have h := trans_kd_linear_trunc a L s KD m T P plat w hs hkink h0 hL ha hw
  rw [hgap] at h ⊢
  refine ⟨?_, by ring⟩
  convert h using 1
  ring

/-- **An exact instance where coverage does not complete and the form still holds.**  `s = 1`,
`K_D = 1`, `m_D = 0`, `T_D = 2` (adoption branch, `t_D = 2`), `L = 4`, pre-deployment hazard `≡ 1`
(the speed-set ramp-on loss, `CRamp_eq_trans`), `h_M^post = 0`, linear coverage over `w = 3`,
completing at 5 > L.  The `K_D` derivative is 0, which is the invariant form. -/
theorem i_gradual_incomplete_instance :
    clock 1 0 2 1 = 2 ∧ 4 < clock 1 0 2 1 + 3 ∧
    HasDerivAt (fun k => CTrans (fun _ => 1) (cover 1 0 (fun x => min (x / 3) 1)) 4
      (clock k 0 2 1)) 0 1 ∧
    chi 1 0 2 1 / 1 * (1 - 0) = 0 := by
  have hadopt : (1:ℝ) / 1 < (1 - 0) * 2 := by norm_num
  have hclk : clock 1 0 2 1 = 2 := by rw [clock_adopt 1 0 2 1 hadopt]; norm_num
  have hpre : PreOK (fun _ => (1:ℝ)) 4 (clock 1 0 2 1) 1 :=
    ⟨intervalIntegrable_const, continuousAt_const,
      continuous_const.aestronglyMeasurable.stronglyMeasurableAtFilter, rfl⟩
  obtain ⟨hd, hf⟩ := trans_kd_linear_adopt (fun _ => 1) 4 1 1 0 2 0 1 3 one_pos hadopt
    (by rw [hclk]; norm_num) (by rw [hclk]; norm_num) hpre (by rw [hclk]; norm_num)
  exact ⟨hclk, by rw [hclk]; norm_num, hd, hf⟩

/-- **Completion inside the window is not enough: the schedule must translate rigidly.**  Coverage
switches fully on `K_D` after deployment, `u_k(x) = 0` for `x < k` and 1 after, so it is complete
at `t_D + K_D = 3 < L = 4`, but its shape moves with `K_D` (`trans_kd_gradual` holds `u` fixed).
Adoption branch: `s = 1`, `K_D = 1`, `m_D = 0`, `T_D = 2` (`t_D = 2`, `χ_D = 0`), pre-deployment
hazard `≡ 1`, `h_M^post = 0`.  The `K_D` derivative is 1; the invariant form says 0. -/
theorem i_gradual_nonrigid_instance :
    clock 1 0 2 1 + 1 < 4 ∧
    HasDerivAt (fun k => CTrans (fun _ => 1) (cover 1 0 (fun x => if x < k then 0 else 1)) 4
      (clock k 0 2 1)) 1 1 ∧
    (1 : ℝ) ≠ chi 1 0 2 1 / 1 * (1 - 0) := by
  have hadopt : (1:ℝ) / 1 < (1 - 0) * 2 := by norm_num
  have hclk : clock 1 0 2 1 = 2 := by rw [clock_adopt 1 0 2 1 hadopt]; norm_num
  have hchi : chi 1 0 2 1 = 0 := chi_adopt 1 0 2 1 hadopt
  have hT := trans_hasDerivAt (fun _ => (1:ℝ)) (fun _ => (0:ℝ)) 4 (2 + 1) intervalIntegrable_const
    intervalIntegrable_const (by norm_num) (by norm_num) continuousAt_const
    (continuous_const.aestronglyMeasurable.stronglyMeasurableAtFilter) continuousAt_const
    (continuous_const.aestronglyMeasurable.stronglyMeasurableAtFilter)
  have hsh : HasDerivAt (fun k : ℝ => 2 + k) 1 1 := (hasDerivAt_id' (1:ℝ)).const_add 2
  have hd := hT.comp (1:ℝ) hsh
  have heq : ∀ᶠ k in 𝓝 (1:ℝ),
      CTrans (fun _ => 1) (cover 1 0 (fun x => if x < k then 0 else 1)) 4 (clock k 0 2 1)
        = CTrans (fun _ => (1:ℝ)) (fun _ => 0) 4 (2 + k) := by
    filter_upwards [isOpen_Ioi.mem_nhds (by norm_num : (1:ℝ) ∈ Ioi 0),
      isOpen_Iio.mem_nhds (by norm_num : (1:ℝ) ∈ Iio 2)] with k hk0 hk2
    rw [mem_Ioi] at hk0
    rw [mem_Iio] at hk2
    have hck : clock k 0 2 1 = 2 := by
      rw [clock_adopt k 0 2 1 (by norm_num; linarith)]; ring
    rw [hck]
    unfold CTrans
    congr 1
    funext t
    by_cases h1 : t < 2
    · have h2 : t < 2 + k := by linarith
      simp [h1, h2]
    · by_cases h3 : t - 2 < k
      · have h2 : t < 2 + k := by linarith
        simp [cover, h1, h2, h3]
      · have h2 : ¬ t < 2 + k := fun h => h3 (by linarith)
        simp [cover, h1, h2, h3]
  refine ⟨by rw [hclk]; norm_num, ?_, by rw [hchi]; norm_num⟩
  have h := hd.congr_of_eventuallyEq heq
  convert h using 1
  norm_num

/-! ### A residual that responds to `K_D` -/

/-- **A responsive residual adds `(L − t_D)∂h_M^post/∂K_D`.**  With the residual a function of
`K_D`, the translated loss's `K_D` derivative is the invariant form plus that interior term. -/
theorem trans_kd_resp (a Pf : ℝ → ℝ) (L s KD m T plat p' : ℝ) (hs : 0 < s)
    (hkink : KD / s ≠ (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L)
    (ha : PreOK a L (clock KD m T s) plat) (hP : HasDerivAt Pf p' KD) :
    HasDerivAt (fun k => CTrans a (fun _ => Pf k) L (clock k m T s))
      (chi KD m T s / s * (plat - Pf KD) + p' * (L - clock KD m T s)) KD := by
  set tD := clock KD m T s with htD
  have hclk := clock_hasDerivAt_K KD m T s hs hkink
  have hat : IntervalIntegrable a volume 0 tD :=
    ha.1.mono_set (by
      rw [uIcc_of_le h0.le, uIcc_of_le (h0.le.trans hL.le)]
      exact Icc_subset_Icc le_rfl hL.le)
  have hA : HasDerivAt (fun u => ∫ t in (0:ℝ)..u, a t) (a tD) tD :=
    integral_hasDerivAt_right hat ha.2.2.1 ha.2.1
  have hAk := hA.comp KD hclk
  have hR : HasDerivAt (fun k => Pf k * (L - clock k m T s))
      (p' * (L - tD) + Pf KD * -(chi KD m T s / s)) KD :=
    hP.mul (hclk.const_sub L)
  have hsum := hAk.add hR
  have heq : ∀ᶠ k in 𝓝 KD, CTrans a (fun _ => Pf k) L (clock k m T s)
      = (∫ t in (0:ℝ)..(clock k m T s), a t) + Pf k * (L - clock k m T s) := by
    have hcK := (clock_continuous_K m T s).continuousAt (x := KD)
    have e1 : ∀ᶠ k in 𝓝 KD, 0 < clock k m T s :=
      hcK.eventually ((isOpen_Ioi.eventually_mem h0).mono (fun x hx => hx))
    have e2 : ∀ᶠ k in 𝓝 KD, clock k m T s < L :=
      hcK.eventually ((isOpen_Iio.eventually_mem hL).mono (fun x hx => hx))
    filter_upwards [e1, e2] with k hk0 hkL
    rw [CTrans_split a (fun _ => Pf k) L _ ha.1 intervalIntegrable_const hk0.le hkL.le,
      intervalIntegral.integral_const, smul_eq_mul]
    ring
  have h := hsum.congr_of_eventuallyEq heq
  rw [ha.2.2.2] at h
  convert h using 1
  ring

/-- The responsive-residual term for the level-set losses (any profile). -/
theorem i_CLev_kd_resp (h Pf : ℝ → ℝ) (K L s KD m T p' : ℝ)
    (hint : IntervalIntegrable h volume 0 K) (hs : 0 < s) (hK : 0 ≤ K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L)
    (hP : HasDerivAt Pf p' KD) :
    HasDerivAt (fun k => CLev h K L s (clock k m T s) (Pf k))
      (chi KD m T s / s * (h K - Pf KD) + p' * (L - clock KD m T s)) KD := by
  have h0 : 0 < clock KD m T s := lt_of_le_of_lt (by positivity) hD
  have hd := trans_kd_resp (preLev h K s) Pf L s KD m T (h K) p' hs hkink h0 hL
    (preLev_ok h K L s _ hint hs hK hD hL) hP
  refine hd.congr_of_eventuallyEq ?_
  filter_upwards [clock_eventually_gt KD m T s (K / s) hD] with k hk
  exact CLev_eq_trans h K L s (clock k m T s) (Pf k) hs hk.le

/-- The responsive-residual term, speed-set arrival-on. -/
theorem i_speed_arrival_resp (Λ Pf : ℝ → ℝ) (K L s KD m T p' : ℝ) (hs : 0 < s) (hK : 0 ≤ K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L)
    (hP : HasDerivAt Pf p' KD) :
    HasDerivAt (fun k => CArrClose Λ K L s (clock k m T s) (Pf k))
      (chi KD m T s / s * (Λ s - Pf KD) + p' * (L - clock KD m T s)) KD := by
  have h0 : 0 < clock KD m T s := lt_of_le_of_lt (by positivity) hD
  have hd := trans_kd_resp (step 0 (Λ s) (K / s)) Pf L s KD m T (Λ s) p' hs hkink h0 hL
    (preArr_ok Λ K L s _ hs hK hD hL) hP
  refine hd.congr_of_eventuallyEq ?_
  filter_upwards [clock_eventually_gt KD m T s (K / s) hD] with k hk
  exact CArrClose_eq_trans Λ K L s (clock k m T s) (Pf k) hk.le

/-- The responsive-residual term, speed-set ramp-on. -/
theorem i_speed_rampon_resp (Λ Pf : ℝ → ℝ) (L s KD m T p' : ℝ) (hs : 0 < s)
    (hkink : KD / s ≠ (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L)
    (hP : HasDerivAt Pf p' KD) :
    HasDerivAt (fun k => CRamp Λ L s (clock k m T s) (Pf k))
      (chi KD m T s / s * (Λ s - Pf KD) + p' * (L - clock KD m T s)) KD := by
  have hpre : PreOK (fun _ => Λ s) L (clock KD m T s) (Λ s) :=
    ⟨intervalIntegrable_const, continuousAt_const,
      continuous_const.aestronglyMeasurable.stronglyMeasurableAtFilter, rfl⟩
  have hd := trans_kd_resp (fun _ => Λ s) Pf L s KD m T (Λ s) p' hs hkink h0 hL hpre hP
  refine hd.congr_of_eventuallyEq (Eventually.of_forall (fun k => ?_))
  exact CRamp_eq_trans Λ L s (clock k m T s) (Pf k)

/-- **A responsive residual under gradual coverage.**  With coverage `u` complete from `w` on and
`t_D + w < L`, a residual `Pf(K_D)` adds `∂h_M^post/∂K_D` times the *covered time*
`∫_0^{L − t_D} u`, not times `L − t_D`.  The two agree only when coverage is a step. -/
theorem trans_kd_resp_gradual (a u Pf : ℝ → ℝ) (L s KD m T plat p' w : ℝ) (hs : 0 < s)
    (hkink : KD / s ≠ (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L)
    (ha : PreOK a L (clock KD m T s) plat) (hu : IntervalIntegrable u volume 0 L)
    (hdone : ∀ x, w ≤ x → u x = 1) (hcomp : clock KD m T s + w < L)
    (hP : HasDerivAt Pf p' KD) :
    HasDerivAt (fun k => CTrans a (cover plat (Pf k) u) L (clock k m T s))
      (chi KD m T s / s * (plat - Pf KD) + p' * ∫ x in (0:ℝ)..(L - clock KD m T s), u x) KD := by
  set tD := clock KD m T s with htD
  have hclk := clock_hasDerivAt_K KD m T s hs hkink
  have hat : IntervalIntegrable a volume 0 tD :=
    ha.1.mono_set (by
      rw [uIcc_of_le h0.le, uIcc_of_le (h0.le.trans hL.le)]
      exact Icc_subset_Icc le_rfl hL.le)
  have hA : HasDerivAt (fun v => ∫ t in (0:ℝ)..v, a t) (a tD) tD :=
    integral_hasDerivAt_right hat ha.2.2.1 ha.2.1
  have hAk := hA.comp KD hclk
  have hequ : EqOn u (fun _ => 1) (Ioi w) := fun x hx => hdone x (le_of_lt hx)
  have hwmem : L - tD ∈ Ioi w := by rw [mem_Ioi]; linarith
  have hucon : ContinuousOn u (Ioi w) := continuousOn_const.congr hequ
  have hut : IntervalIntegrable u volume 0 (L - tD) :=
    hu.mono_set (by
      rw [uIcc_of_le (by linarith), uIcc_of_le (h0.le.trans hL.le)]
      exact Icc_subset_Icc le_rfl (by linarith))
  have hU : HasDerivAt (fun v => ∫ x in (0:ℝ)..v, u x) (u (L - tD)) (L - tD) :=
    integral_hasDerivAt_right hut (hucon.stronglyMeasurableAtFilter isOpen_Ioi _ hwmem)
      (hucon.continuousAt (isOpen_Ioi.mem_nhds hwmem))
  have hu1 : u (L - tD) = 1 := hequ hwmem
  have hUk := hU.comp KD (hclk.const_sub L)
  have hR : HasDerivAt (fun k => plat * (L - clock k m T s)) (plat * -(chi KD m T s / s)) KD :=
    (hclk.const_sub L).const_mul plat
  have hQ := (hP.const_sub plat).mul hUk
  have hsum := (hAk.add hR).sub hQ
  have heq : ∀ᶠ k in 𝓝 KD, CTrans a (cover plat (Pf k) u) L (clock k m T s)
      = (∫ t in (0:ℝ)..(clock k m T s), a t) + plat * (L - clock k m T s)
        - (plat - Pf k) * ∫ x in (0:ℝ)..(L - clock k m T s), u x := by
    have hcK := (clock_continuous_K m T s).continuousAt (x := KD)
    have e1 : ∀ᶠ k in 𝓝 KD, 0 < clock k m T s :=
      hcK.eventually ((isOpen_Ioi.eventually_mem h0).mono (fun x hx => hx))
    have e2 : ∀ᶠ k in 𝓝 KD, clock k m T s < L :=
      hcK.eventually ((isOpen_Iio.eventually_mem hL).mono (fun x hx => hx))
    filter_upwards [e1, e2] with k hk0 hkL
    have hci : IntervalIntegrable (cover plat (Pf k) u) volume 0 L := by
      unfold cover; exact intervalIntegrable_const.sub (hu.mul_const _)
    have hutk : IntervalIntegrable u volume 0 (L - clock k m T s) :=
      hu.mono_set (by
        rw [uIcc_of_le (by linarith), uIcc_of_le (hk0.le.trans hkL.le)]
        exact Icc_subset_Icc le_rfl (by linarith))
    have hint : ∫ x in (0:ℝ)..(L - clock k m T s), cover plat (Pf k) u x
        = plat * (L - clock k m T s) - (plat - Pf k) * ∫ x in (0:ℝ)..(L - clock k m T s), u x := by
      unfold cover
      rw [intervalIntegral.integral_sub intervalIntegrable_const (hutk.mul_const _),
        intervalIntegral.integral_const, smul_eq_mul, intervalIntegral.integral_mul_const]
      ring
    rw [CTrans_split a _ L _ ha.1 hci hk0.le hkL.le, hint]
    ring
  have h := hsum.congr_of_eventuallyEq heq
  rw [Function.comp_apply, ← htD, ha.2.2.2, hu1] at h
  convert h using 1
  ring

/-- **The step-coverage correction fails under gradual coverage: an exact instance.**  Speed-set
ramp-on with `Λ ≡ 1`, `s = m_D = T_D = 1` (so `t_D = K_D + 1`), `L = 4`, residual `K_D/4`, linear
coverage completing over width 1 (inside the window).  At `K_D = 1` the derivative is `9/8`; the
printed `(χ_D/s)(h_M^plat − h_M^post) + (L − t_D)∂h_M^post/∂K_D` gives `5/4`. -/
theorem i_resp_gradual_instance :
    HasDerivAt (fun k => CTrans (fun _ => 1) (cover 1 (k / 4) (fun x => min x 1)) 4
        (clock k 1 1 1)) (9 / 8) 1 ∧
      (9 / 8 : ℝ) ≠ chi 1 1 1 1 / 1 * (1 - 1 / 4) + 1 / 4 * (4 - clock 1 1 1 1) := by
  have hcap : (1 - (1:ℝ)) * 1 < 1 / 1 := by norm_num
  have hclk : clock 1 1 1 1 = 2 := by rw [clock_cap 1 1 1 1 hcap]; norm_num
  have hchi : chi 1 1 1 1 = 1 := chi_cap 1 1 1 1 hcap
  have hpre : PreOK (fun _ => (1:ℝ)) 4 (clock 1 1 1 1) 1 :=
    ⟨intervalIntegrable_const, continuousAt_const,
      continuous_const.aestronglyMeasurable.stronglyMeasurableAtFilter, rfl⟩
  have hPf : HasDerivAt (fun k : ℝ => k / 4) (1 / 4) 1 := by
    simpa using (hasDerivAt_id (1:ℝ)).div_const 4
  have hc : Continuous (fun x : ℝ => min x 1) := continuous_id.min continuous_const
  have hint : ∫ x in (0:ℝ)..2, min x 1 = 3 / 2 := by
    rw [← intervalIntegral.integral_add_adjacent_intervals (b := 1) (hc.intervalIntegrable 0 1)
      (hc.intervalIntegrable 1 2)]
    have e1 : ∫ x in (0:ℝ)..1, min x 1 = ∫ x in (0:ℝ)..1, x :=
      intervalIntegral.integral_congr (fun x hx => by
        rw [uIcc_of_le zero_le_one] at hx; exact min_eq_left hx.2)
    have e2 : ∫ x in (1:ℝ)..2, min x 1 = ∫ x in (1:ℝ)..2, (1:ℝ) :=
      intervalIntegral.integral_congr (fun x hx => by
        rw [uIcc_of_le one_le_two] at hx; exact min_eq_right hx.1)
    rw [e1, e2, integral_id, intervalIntegral.integral_const, smul_eq_mul]
    norm_num
  have h := trans_kd_resp_gradual (fun _ => 1) (fun x => min x 1) (fun k => k / 4) 4 1 1 1 1 1
    (1 / 4) 1 one_pos (by norm_num) (by rw [hclk]; norm_num) (by rw [hclk]; norm_num) hpre
    (hc.intervalIntegrable _ _) (fun x hx => min_eq_right hx) (by rw [hclk]; norm_num) hPf
  rw [hclk, hchi] at h
  refine ⟨?_, ?_⟩
  · convert h using 1
    rw [show (4:ℝ) - 2 = 2 by norm_num, hint]
    norm_num
  · rw [hchi, hclk]; norm_num

/-! ### Gradual coverage, case by case

The gradual-coverage loss of each case is the case's own pre-deployment hazard followed by the
rigidly translating coverage schedule.  The six instances below are the three level-and-speed
cases by two readings that A4a.7(i)'s numerical check covers. -/

theorem i_gradual_lev (h u : ℝ → ℝ) (K L s KD m T P w : ℝ)
    (hint : IntervalIntegrable h volume 0 K) (hs : 0 < s) (hK : 0 ≤ K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L)
    (hu : IntervalIntegrable u volume 0 L) (hdone : ∀ x, w ≤ x → u x = 1)
    (hcomp : clock KD m T s + w < L) :
    HasDerivAt (fun k => CTrans (preLev h K s) (cover (h K) P u) L (clock k m T s))
      (chi KD m T s / s * (h K - P)) KD :=
  trans_kd_gradual _ u L s KD m T P (h K) w hs hkink (lt_of_le_of_lt (by positivity) hD) hL
    (preLev_ok h K L s _ hint hs hK hD hL) hu hdone hcomp

/-- Level-set B, ramp-on, gradual. -/
theorem i_gradual_levB_rampon (h u : ℝ → ℝ) (K L s KD m T P w : ℝ)
    (hint : IntervalIntegrable h volume 0 K) (hs : 0 < s) (hK : 0 ≤ K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L)
    (hu : IntervalIntegrable u volume 0 L) (hdone : ∀ x, w ≤ x → u x = 1)
    (hcomp : clock KD m T s + w < L) :
    HasDerivAt (fun k => CTrans (preLev h K s) (cover (h K) P u) L (clock k m T s))
      (chi KD m T s / s * (h K - P)) KD :=
  i_gradual_lev h u K L s KD m T P w hint hs hK hkink hD hL hu hdone hcomp

/-- Level-set A, ramp-on, gradual. -/
theorem i_gradual_levA_rampon (ĥ u : ℝ → ℝ) (K L s KD m T P w : ℝ)
    (hint : IntervalIntegrable ĥ volume 0 1) (hs : 0 < s) (hK : 0 < K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L)
    (hu : IntervalIntegrable u volume 0 L) (hdone : ∀ x, w ≤ x → u x = 1)
    (hcomp : clock KD m T s + w < L) :
    HasDerivAt (fun k => CTrans (preLev (convA ĥ K) K s) (cover (ĥ 1) P u) L (clock k m T s))
      (chi KD m T s / s * (ĥ 1 - P)) KD := by
  have := i_gradual_lev (convA ĥ K) u K L s KD m T P w (convA_intervalIntegrable ĥ K hint hK)
    hs hK.le hkink hD hL hu hdone hcomp
  rwa [convA_at ĥ K hK.ne'] at this

/-- Level-set B, arrival-on (gated), gradual. -/
theorem i_gradual_levB_arrival (h u : ℝ → ℝ) (K L s KD m T P w : ℝ) (hs : 0 < s) (hK : 0 ≤ K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L)
    (hu : IntervalIntegrable u volume 0 L) (hdone : ∀ x, w ≤ x → u x = 1)
    (hcomp : clock KD m T s + w < L) :
    HasDerivAt (fun k => CTrans (preLev (gate h K) K s) (cover (h K) P u) L (clock k m T s))
      (chi KD m T s / s * (h K - P)) KD := by
  have := i_gradual_lev (gate h K) u K L s KD m T P w (gate_intervalIntegrable h K hK) hs hK
    hkink hD hL hu hdone hcomp
  rwa [gate_at] at this

/-- Level-set A, arrival-on (gated), gradual. -/
theorem i_gradual_levA_arrival (ĥ u : ℝ → ℝ) (K L s KD m T P w : ℝ) (hs : 0 < s) (hK : 0 < K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L)
    (hu : IntervalIntegrable u volume 0 L) (hdone : ∀ x, w ≤ x → u x = 1)
    (hcomp : clock KD m T s + w < L) :
    HasDerivAt
      (fun k => CTrans (preLev (gate (convA ĥ K) K) K s) (cover (ĥ 1) P u) L (clock k m T s))
      (chi KD m T s / s * (ĥ 1 - P)) KD := by
  have := i_gradual_lev (gate (convA ĥ K) K) u K L s KD m T P w
    (gate_intervalIntegrable _ K hK.le) hs hK.le hkink hD hL hu hdone hcomp
  rwa [gate_at, convA_at ĥ K hK.ne'] at this

/-- Speed-set, ramp-on, gradual. -/
theorem i_gradual_speed_rampon (Λ u : ℝ → ℝ) (L s KD m T P w : ℝ) (hs : 0 < s)
    (hkink : KD / s ≠ (1 - m) * T) (h0 : 0 < clock KD m T s) (hL : clock KD m T s < L)
    (hu : IntervalIntegrable u volume 0 L) (hdone : ∀ x, w ≤ x → u x = 1)
    (hcomp : clock KD m T s + w < L) :
    HasDerivAt (fun k => CTrans (fun _ => Λ s) (cover (Λ s) P u) L (clock k m T s))
      (chi KD m T s / s * (Λ s - P)) KD :=
  trans_kd_gradual _ u L s KD m T P (Λ s) w hs hkink h0 hL
    ⟨intervalIntegrable_const, continuousAt_const,
      continuous_const.aestronglyMeasurable.stronglyMeasurableAtFilter, rfl⟩ hu hdone hcomp

/-- Speed-set, arrival-on, gradual. -/
theorem i_gradual_speed_arrival (Λ u : ℝ → ℝ) (K L s KD m T P w : ℝ) (hs : 0 < s) (hK : 0 ≤ K)
    (hkink : KD / s ≠ (1 - m) * T) (hD : K / s < clock KD m T s) (hL : clock KD m T s < L)
    (hu : IntervalIntegrable u volume 0 L) (hdone : ∀ x, w ≤ x → u x = 1)
    (hcomp : clock KD m T s + w < L) :
    HasDerivAt (fun k => CTrans (step 0 (Λ s) (K / s)) (cover (Λ s) P u) L (clock k m T s))
      (chi KD m T s / s * (Λ s - P)) KD :=
  trans_kd_gradual _ u L s KD m T P (Λ s) w hs hkink (lt_of_le_of_lt (by positivity) hD) hL
    (preArr_ok Λ K L s _ hs hK hD hL) hu hdone hcomp

/-! ## Rows G and H: the gated derivatives -/

/-- The gated level-set loss with no closure is differentiable, with `s·C′ = τ_M h_M(K_M)`. -/
theorem gated_plateau_hasDerivAt (h : ℝ → ℝ) (K L s : ℝ) (hK : 0 ≤ K) (hs : 0 < s)
    (hwin : K / s < L) :
    HasDerivAt (fun x => CLevPlateau (gate h K) K L x) (h K * (K / s ^ 2)) s := by
  have hd := r2_hasDerivAt (fun _ => h K) L K s 0 hK hs hwin (hasDerivAt_const s (h K))
  have hd' : HasDerivAt (fun x => CArr (fun _ => h K) K L x) (h K * (K / s ^ 2)) s := by
    convert hd using 1; simp only [zero_mul, zero_add]
  exact hd'.congr_of_eventuallyEq (gate_plateau_eventuallyEq h K L s hs)

/-- The gated level-set loss with closure on any differentiable clock, strictly after arrival. -/
theorem gated_close_hasDerivAt (h TD : ℝ → ℝ) (K L s P tD' : ℝ) (hK : 0 ≤ K) (hs : 0 < s)
    (hTD : HasDerivAt TD tD' s) (harr : K / s < TD s) (hhor : TD s < L) :
    HasDerivAt (fun x => CLev (gate h K) K L x (TD x) P)
      (h K * (tD' + K / s ^ 2) + P * -tD') s := by
  have hd := r3_hasDerivAt (fun _ => h K) TD L K s P 0 tD' hK hs (hasDerivAt_const s (h K)) hTD
    harr hhor
  have hd' : HasDerivAt (fun x => CArrClose (fun _ => h K) K L x (TD x) P)
      (h K * (tD' + K / s ^ 2) + P * -tD') s := by
    convert hd using 1; simp only [zero_mul, zero_add]
  exact hd'.congr_of_eventuallyEq (gate_close_eventuallyEq h TD K L s P hs)

/-! ### Row 1 (G): plateau, no defence -/

/-- **Row 1, arrival-on, both sides gated.**  The gated level-set marginal is `τ_M[h_M(K_M) − h̄_M]`
with `h̄_M` the gated profile's own ramp average, which is zero; the speed-set marginal is positive
under A4; and they take opposite strict signs **iff `h_M(K_M) < 0`**. -/
theorem g1_relation (h Λ : ℝ → ℝ) (K L s lam' dl ds : ℝ) (hK : 0 < K) (hs : 0 < s)
    (hwin : K / s < L) (hΛ : HasDerivAt Λ lam' s) (hA4 : 0 < lam') (hΛ0 : 0 ≤ Λ s)
    (hdl : HasDerivAt (fun x => CLevPlateau (gate h K) K L x) dl s)
    (hds : HasDerivAt (fun x => CArr Λ K L x) ds s) :
    s * dl = (K / s) * (h K - hbar (gate h K) K) ∧ hbar (gate h K) K = 0 ∧ 0 < s * ds ∧
      ((s * dl) * (s * ds) < 0 ↔ h K < 0) := by
  have e1 := hdl.unique (gated_plateau_hasDerivAt h K L s hK.le hs hwin)
  have e2 := hds.unique (r2_hasDerivAt Λ L K s lam' hK.le hs hwin hΛ)
  have hb := gate_hbar h K hK
  have hτ : 0 < K / s := div_pos hK hs
  have hl : s * dl = (K / s) * h K := by rw [e1]; field_simp
  have hsd : s * ds = s * lam' * (L - K / s) + Λ s * (K / s) := by
    rw [e2]; exact r2_scaled Λ L K s lam' hs.ne'
  have hpos : 0 < s * ds := by
    rw [hsd]
    have : 0 < s * lam' * (L - K / s) := mul_pos (mul_pos hs hA4) (sub_pos.mpr hwin)
    have : 0 ≤ Λ s * (K / s) := mul_nonneg hΛ0 hτ.le
    linarith
  refine ⟨by rw [hb, hl, sub_zero], hb, hpos, ?_⟩
  rw [hl]
  constructor
  · intro hneg
    have : (K / s) * h K < 0 := by
      by_contra hc; push Not at hc; nlinarith
    by_contra hc; push Not at hc
    nlinarith [mul_nonneg hτ.le hc]
  · intro hneg
    exact mul_neg_of_neg_of_pos (mul_neg_of_pos_of_neg hτ hneg) hpos

/-- **Row 1: cannot diverge**, since a hazard is not negative. -/
theorem g1_cannot_diverge (h Λ : ℝ → ℝ) (K L s lam' dl ds : ℝ) (hK : 0 < K) (hs : 0 < s)
    (hwin : K / s < L) (hΛ : HasDerivAt Λ lam' s) (hA4 : 0 < lam') (hΛ0 : 0 ≤ Λ s)
    (hh : 0 ≤ h K)
    (hdl : HasDerivAt (fun x => CLevPlateau (gate h K) K L x) dl s)
    (hds : HasDerivAt (fun x => CArr Λ K L x) ds s) :
    ¬ (s * dl) * (s * ds) < 0 := by
  rw [(g1_relation h Λ K L s lam' dl ds hK hs hwin hΛ hA4 hΛ0 hdl hds).2.2.2]
  exact not_lt.mpr hh

/-! ### Row 2 (H): truncation -/

/-- **Row 2, arrival-on, both sides gated: agree, both exactly zero.**  In the regime `sL < K_M`
the gated hazard is zero at every date of the window, both losses vanish, and both speed
derivatives are exactly zero. -/
theorem h2_relation (h Λ : ℝ → ℝ) (K L s : ℝ) (hs : 0 < s) (hL : 0 ≤ L) (htrunc : L < K / s) :
    (∀ t ∈ Icc (0:ℝ) L, gate h K (min (s * t) K) = 0) ∧
    CLevPlateau (gate h K) K L s = 0 ∧ CArr Λ K L s = 0 ∧
    HasDerivAt (fun x => CLevPlateau (gate h K) K L x) 0 s ∧
    HasDerivAt (fun x => CArr Λ K L x) 0 s := by
  refine ⟨?_, ?_, CArr_eq_zero Λ K L s hL htrunc.le, ?_, CArr_hasDerivAt_zero Λ K L s hs hL htrunc⟩
  · intro t ht
    have hst : s * t < K := by
      calc s * t ≤ s * L := mul_le_mul_of_nonneg_left ht.2 hs.le
      _ < s * (K / s) := mul_lt_mul_of_pos_left htrunc hs
      _ = K := mul_div_cancel₀ K hs.ne'
    rw [min_eq_left hst.le]
    exact gate_zero_below h K _ hst
  · rw [gate_plateau_eq_CArr h K L s hs]
    exact CArr_eq_zero _ K L s hL htrunc.le
  · exact (CArr_hasDerivAt_zero (fun _ => h K) K L s hs hL htrunc).congr_of_eventuallyEq
      (gate_plateau_eventuallyEq h K L s hs)

/-! ### Row 4 (G): defence paced by `K_M` -/

/-- On the `K_M`-paced capability branch `t_D − τ_M = m_DT_D ≥ 0` at every nearby speed, so the
ordering `τ_M ≤ t_D ≤ L` holds on a neighbourhood even when `m_DT_D = 0`. -/
theorem paced_ord (K m T s L : ℝ) (hs : 0 < s) (hcap : (1 - m) * T < K / s) (hmT : 0 ≤ m * T)
    (hhor : clock K m T s < L) :
    ∀ᶠ x in 𝓝 s, K / x ≤ clock K m T x ∧ clock K m T x ≤ L := by
  have hc : ContinuousAt (fun x : ℝ => K / x + m * T) s :=
    (continuousAt_const.div continuousAt_id hs.ne').add continuousAt_const
  rw [clock_cap K m T s hcap] at hhor
  have hlt : ∀ᶠ x in 𝓝 s, K / x + m * T < L :=
    hc.eventually ((isOpen_Iio.eventually_mem hhor).mono (fun _ hx => hx))
  filter_upwards [clock_cap_eventually_s K m T s hs hcap, hlt] with x hx hxL
  rw [hx]
  exact ⟨by linarith, hxL.le⟩

/-- **Row 4, arrival-on, both sides gated: cannot diverge.**  On the `K_M`-paced capability
branch, with the actual clock: the gated level-set marginal is `τ_M[(1 − χ_D)h_M(K_M) +
χ_D h_M^post − h̄_M]` at `χ_D = 1` with the gated `h̄_M = 0`, that is `h_M^post·τ_M`; its "helps"
condition is `h_M^post < 0`; the speed-set marginal is `ε_ΛΛ_M m_DT_D + h_M^post·τ_M`; for a
nonnegative residual both are `≥ 0`, they cannot take opposite strict signs, and the speed-set one
is strict iff `m_DT_D > 0` or `h_M^post > 0`.  `m_DT_D = 0` is included. -/
theorem g4_relation (h Λ : ℝ → ℝ) (K L s m T P lam' dl ds : ℝ) (hK : 0 < K) (hs : 0 < s)
    (hcap : (1 - m) * T < K / s) (hmT : 0 ≤ m * T) (hhor : clock K m T s < L)
    (hΛ : HasDerivAt Λ lam' s)
    (hdl : HasDerivAt (fun x => CLev (gate h K) K L x (clock K m T x) P) dl s)
    (hds : HasDerivAt (fun x => CArrClose Λ K L x (clock K m T x) P) ds s) :
    s * dl = (K / s) * ((1 - 1) * h K + 1 * P - hbar (gate h K) K) ∧
    s * dl = P * (K / s) ∧
    s * ds = s * lam' * (m * T) + P * (K / s) ∧
    (s * dl < 0 ↔ P < 0) ∧
    (0 ≤ P → 0 < lam' →
      0 ≤ s * dl ∧ 0 ≤ s * ds ∧ ¬ (s * dl) * (s * ds) < 0 ∧
        (0 < s * ds ↔ 0 < m * T ∨ 0 < P)) := by
  have hord := paced_ord K m T s L hs hcap hmT hhor
  have hTD := clock_hasDerivAt_s_cap K m T s hs hcap
  have hgl := (arrClose_hasDerivAt_weak (fun _ => h K) (fun x => clock K m T x) L K s P 0
    (-(K / s ^ 2)) hK.le hs (hasDerivAt_const s (h K)) hTD hord).congr_of_eventuallyEq
    (gate_close_eventuallyEq h (fun x => clock K m T x) K L s P hs)
  have e1 := hdl.unique hgl
  have e2 := hds.unique
    (arrClose_hasDerivAt_weak Λ (fun x => clock K m T x) L K s P lam' (-(K / s ^ 2)) hK.le hs
      hΛ hTD hord)
  have hcl : clock K m T s - K / s = m * T := by rw [clock_cap K m T s hcap]; ring
  have hτ : 0 < K / s := div_pos hK hs
  have hl : s * dl = P * (K / s) := by rw [e1]; field_simp; ring
  have hsd : s * ds = s * lam' * (m * T) + P * (K / s) := by
    rw [e2, hcl]; field_simp; ring
  refine ⟨by rw [hl, gate_hbar h K hK]; ring, hl, hsd, ?_, ?_⟩
  · rw [hl]
    constructor
    · intro hneg; by_contra hc; push Not at hc; nlinarith [mul_nonneg hc hτ.le]
    · intro hneg; exact mul_neg_of_neg_of_pos hneg hτ
  · intro hP hA4
    have hl0 : 0 ≤ s * dl := by rw [hl]; exact mul_nonneg hP hτ.le
    have hs0 : 0 ≤ s * ds := by
      rw [hsd]
      have : 0 ≤ s * lam' * (m * T) := mul_nonneg (mul_pos hs hA4).le hmT
      have : 0 ≤ P * (K / s) := mul_nonneg hP hτ.le
      linarith
    refine ⟨hl0, hs0, not_lt.mpr (mul_nonneg hl0 hs0), ?_⟩
    rw [hsd]
    constructor
    · intro hpos
      by_contra hc
      push Not at hc
      have h1 : m * T = 0 := le_antisymm hc.1 hmT
      have h2 : P = 0 := le_antisymm hc.2 hP
      rw [h1, h2] at hpos
      simp at hpos
    · rintro (hm | hp)
      · have : 0 < s * lam' * (m * T) := mul_pos (mul_pos hs hA4) hm
        have : 0 ≤ P * (K / s) := mul_nonneg hP hτ.le
        linarith
      · have : 0 ≤ s * lam' * (m * T) := mul_nonneg (mul_pos hs hA4).le hmT
        have : 0 < P * (K / s) := mul_pos hp hτ
        linarith

/-! ### Row 5 (G): defence on its own distance `K_D` -/

/-- **Row 5, the gated level-set side.**  On the own-distance capability branch with the actual
clock: `s·C′ = τ_M[h_M(K_M) − h̄_M] + s·t_D′[h_M(K_M) − h_M^post]` with `s·t_D′ = −K_D/s` and the
gated `h̄_M = 0`, that is `τ_M h_M(K_M) − τ_D[h_M(K_M) − h_M^post]`; it helps iff
`K_D[h_M(K_M) − h_M^post] > K_M[h_M(K_M) − h̄_M]`, the two-distance inequality with `h̄_M = 0`. -/
theorem g5_level (h : ℝ → ℝ) (K L s KD m T P dl : ℝ) (hK : 0 < K) (hs : 0 < s)
    (hcap : (1 - m) * T < KD / s) (harr : K / s < clock KD m T s) (hhor : clock KD m T s < L)
    (hdl : HasDerivAt (fun x => CLev (gate h K) K L x (clock KD m T x) P) dl s) :
    s * dl = (K / s) * (h K - hbar (gate h K) K) + -(KD / s) * (h K - P) ∧
    s * dl = (K / s) * h K - (KD / s) * (h K - P) ∧
    (s * dl < 0 ↔ K * (h K - hbar (gate h K) K) < KD * (h K - P)) := by
  have e1 := hdl.unique (gated_close_hasDerivAt h (fun x => clock KD m T x) K L s P
    (-(KD / s ^ 2)) hK.le hs (clock_hasDerivAt_s_cap KD m T s hs hcap) harr hhor)
  have hb := gate_hbar h K hK
  have hl : s * dl = (K / s) * h K - (KD / s) * (h K - P) := by rw [e1]; field_simp; ring
  refine ⟨by rw [hl, hb]; ring, hl, ?_⟩
  rw [hl, hb, sub_zero]
  have key : (K / s) * h K - (KD / s) * (h K - P) = (K * h K - KD * (h K - P)) / s := by
    field_simp
  rw [key, div_neg_iff]
  constructor
  · rintro (⟨-, hn⟩ | ⟨hp, hn⟩)
    · exact absurd hs (not_lt.mpr hn.le)
    · linarith
  · intro hlt; right; exact ⟨by linarith, hs⟩

/-- **Row 5, the speed-set arrival-on side** (A4a.4(iv), own distance, capability branch):
`s·C′ = Λ_M[ε_Λ(t_D − τ_M) + τ_M] − τ_D(Λ_M − h_M^post)`, and with `Λ_M > 0` and the positive
exposure the interior regime supplies, it helps iff
`ε_Λ < [τ_D(1 − h_M^post/Λ_M) − τ_M]/(τ_D − τ_M + m_DT_D)`, `ε_Λ = sΛ′/Λ`. -/
theorem g5_speed (Λ : ℝ → ℝ) (K L s KD m T P lam' ds : ℝ) (hK : 0 ≤ K) (hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s) (hcap : (1 - m) * T < KD / s) (harr : K / s < clock KD m T s)
    (hhor : clock KD m T s < L)
    (hds : HasDerivAt (fun x => CArrClose Λ K L x (clock KD m T x) P) ds s) :
    s * ds = s * lam' * (KD / s - K / s + m * T) + Λ s * (K / s) - (KD / s) * (Λ s - P) ∧
    0 < KD / s - K / s + m * T ∧
    (0 < Λ s → (s * ds < 0 ↔
      s * lam' / Λ s < ((KD / s) * (1 - P / Λ s) - K / s) / (KD / s - K / s + m * T))) := by
  have e2 := hds.unique (r3_hasDerivAt Λ (fun x => clock KD m T x) L K s P lam' (-(KD / s ^ 2))
    hK hs hΛ (clock_hasDerivAt_s_cap KD m T s hs hcap) harr hhor)
  have hcl : clock KD m T s = KD / s + m * T := clock_cap KD m T s hcap
  have hE : 0 < KD / s - K / s + m * T := by rw [hcl] at harr; linarith
  have hsd : s * ds
      = s * lam' * (KD / s - K / s + m * T) + Λ s * (K / s) - (KD / s) * (Λ s - P) := by
    rw [e2, hcl]; field_simp; ring
  refine ⟨hsd, hE, fun hΛp => ?_⟩
  set E := KD / s - K / s + m * T with hEdef
  have hfac : s * ds = Λ s * (s * lam' / Λ s * E - ((KD / s) * (1 - P / Λ s) - K / s)) := by
    rw [hsd]; field_simp; ring
  rw [hfac, lt_div_iff₀ hE]
  constructor
  · intro hneg
    have := (mul_neg_iff.mp hneg)
    rcases this with ⟨-, hn⟩ | ⟨hn, -⟩
    · linarith
    · exact absurd hΛp (not_lt.mpr hn.le)
  · intro hlt
    exact mul_neg_of_pos_of_neg hΛp (by linarith)

/-- **Row 5's direction under the comparison convention** (`Λ_M(s) = h_M(K_M)` at the speed in
question) and A4: the speed-set marginal exceeds the gated level-set one by `Λ_Mε_Λ(t_D − τ_M)`,
the gated level marginal being the speed-set one at `ε_Λ = 0`; so where they diverge it is
level-set that favours speed. -/
theorem g5_direction_convention (h Λ : ℝ → ℝ) (K L s KD m T P lam' dl ds : ℝ) (hK : 0 < K)
    (hs : 0 < s) (hΛ : HasDerivAt Λ lam' s) (hconv : Λ s = h K) (hA4 : 0 < lam')
    (hcap : (1 - m) * T < KD / s) (harr : K / s < clock KD m T s) (hhor : clock KD m T s < L)
    (hdl : HasDerivAt (fun x => CLev (gate h K) K L x (clock KD m T x) P) dl s)
    (hds : HasDerivAt (fun x => CArrClose Λ K L x (clock KD m T x) P) ds s) :
    s * ds - s * dl = s * lam' * (clock KD m T s - K / s) ∧
    0 < s * ds - s * dl ∧
    ((s * dl) * (s * ds) < 0 → s * dl < 0 ∧ 0 < s * ds) := by
  obtain ⟨-, hl, -⟩ := g5_level h K L s KD m T P dl hK hs hcap harr hhor hdl
  obtain ⟨hsd, hE, -⟩ := g5_speed Λ K L s KD m T P lam' ds hK.le hs hΛ hcap harr hhor hds
  have hcl : clock KD m T s - K / s = KD / s - K / s + m * T := by
    rw [clock_cap KD m T s hcap]; ring
  have hgap : s * ds - s * dl = s * lam' * (clock KD m T s - K / s) := by
    rw [hsd, hl, hcl, hconv]; ring
  have hpos : 0 < s * ds - s * dl := by
    rw [hgap, hcl]; exact mul_pos (mul_pos hs hA4) hE
  refine ⟨hgap, hpos, fun hneg => ?_⟩
  rcases mul_neg_iff.mp hneg with ⟨h1, h2⟩ | ⟨h1, h2⟩
  · exact absurd hpos (by linarith)
  · exact ⟨h1, h2⟩

/-- **Row 5's direction at zero residual**, without the convention: for nonnegative hazards and
A4, if the two marginals diverge then level-set favours speed and speed-set opposes it. -/
theorem g5_direction_zero_residual (h Λ : ℝ → ℝ) (K L s KD m T lam' dl ds : ℝ) (hK : 0 < K)
    (hs : 0 < s) (hΛ : HasDerivAt Λ lam' s) (hA4 : 0 < lam') (hΛ0 : 0 ≤ Λ s) (hh : 0 ≤ h K)
    (hcap : (1 - m) * T < KD / s) (harr : K / s < clock KD m T s) (hhor : clock KD m T s < L)
    (hdl : HasDerivAt (fun x => CLev (gate h K) K L x (clock KD m T x) 0) dl s)
    (hds : HasDerivAt (fun x => CArrClose Λ K L x (clock KD m T x) 0) ds s) :
    (s * dl) * (s * ds) < 0 → s * dl < 0 ∧ 0 < s * ds := by
  obtain ⟨-, hl, -⟩ := g5_level h K L s KD m T 0 dl hK hs hcap harr hhor hdl
  obtain ⟨hsd, hE, -⟩ := g5_speed Λ K L s KD m T 0 lam' ds hK.le hs hΛ hcap harr hhor hds
  intro hneg
  rcases mul_neg_iff.mp hneg with ⟨h1, h2⟩ | ⟨h1, h2⟩
  · exfalso
    have hx : 0 < K / s - KD / s := by
      by_contra hc; push Not at hc
      have : s * dl ≤ 0 := by rw [hl]; nlinarith [mul_nonneg hh (by linarith : 0 ≤ KD / s - K / s)]
      linarith
    have : 0 < s * ds := by
      rw [hsd]
      have : 0 < s * lam' * (KD / s - K / s + m * T) := mul_pos (mul_pos hs hA4) hE
      nlinarith [mul_nonneg hΛ0 hx.le]
    linarith
  · exact ⟨h1, h2⟩

/-- `ε_Λ` at the paper's row-5 point and `Λ_M(s) = s/2 + 1/5`: `Λ(0.6) = 0.5`, `Λ′ = 0.5`. -/
theorem g5_point_Lam : HasDerivAt (fun x : ℝ => x / 2 + 1 / 5) (1 / 2) (3 / 5) := by
  simpa using ((hasDerivAt_id (3 / 5 : ℝ)).div_const 2).add_const (1 / 5 : ℝ)

theorem g5_point_clock : clock (7 / 10) 1 (2 / 5) (3 / 5) = 47 / 30 := by
  rw [clock_cap _ _ _ _ (by norm_num)]; norm_num

/-- **The below-unity divergence witness of row 5**, the paper's own point on the gated
arrival-on reading: `h_M(K_M) = 0.5`, `K_M = 0.6`, `K_D = 0.7`, `h_M^post = 0`, `m_DT_D = 0.4`,
`ε_Λ = 0.6`, `s = 0.6`, `Λ_M(s) = h_M(K_M) = 0.5`.  The paper leaves `L`, and `m_D`, `T_D`
separately, unspecified; the witness takes `L = 2`, `m_D = 1`, `T_D = 0.4` (any values keeping the
point interior and on the capability branch give the same marginals).  Gated level-set marginal
`−1/12 = −0.0833`, speed-set `13/150 = +0.0867`: opposite strict signs with `ε_Λ < 1`. -/
theorem g5_witness (h : ℝ → ℝ) (hh : h (3 / 5) = 1 / 2) :
    ∃ dl ds : ℝ,
      HasDerivAt (fun x => CLev (gate h (3 / 5)) (3 / 5) 2 x (clock (7 / 10) 1 (2 / 5) x) 0)
        dl (3 / 5) ∧
      HasDerivAt (fun x => CArrClose (fun x : ℝ => x / 2 + 1 / 5) (3 / 5) 2 x
        (clock (7 / 10) 1 (2 / 5) x) 0) ds (3 / 5) ∧
      (3 / 5) * dl = -1 / 12 ∧ (3 / 5) * ds = 13 / 150 ∧
      (3 / 5 : ℝ) * (1 / 2) / ((3 / 5) / 2 + 1 / 5) = 3 / 5 ∧
      ((3 / 5 : ℝ) / 2 + 1 / 5) = h (3 / 5) := by
  have hcap : (1 - (1:ℝ)) * (2 / 5) < (7 / 10) / (3 / 5) := by norm_num
  have harr : (3 / 5 : ℝ) / (3 / 5) < clock (7 / 10) 1 (2 / 5) (3 / 5) := by
    rw [g5_point_clock]; norm_num
  have hhor : clock (7 / 10) 1 (2 / 5) (3 / 5) < 2 := by rw [g5_point_clock]; norm_num
  have hTD := clock_hasDerivAt_s_cap (7 / 10) 1 (2 / 5) (3 / 5) (by norm_num) hcap
  refine ⟨_, _, gated_close_hasDerivAt h _ (3 / 5) 2 (3 / 5) 0 _ (by norm_num) (by norm_num)
    hTD harr hhor, r3_hasDerivAt _ _ 2 (3 / 5) (3 / 5) 0 _ _ (by norm_num) (by norm_num)
    g5_point_Lam hTD harr hhor, ?_, ?_, by norm_num, by rw [hh]; norm_num⟩
  · rw [hh]; norm_num
  · rw [g5_point_clock]; norm_num

/-- **At zero residual without the convention, the identification fails.**  At the row-5 point
with `h_M^post = 0` and the zero-elasticity speed hazard `Λ ≡ 1 ≠ h_M(K_M) = 0.5`, the gated
level-set marginal is `−1/12` and the speed-set one at `ε_Λ = 0` is `−1/6`: the direction result
of `g5_direction_zero_residual` holds, but "the gated level-set marginal is the speed-set one at
`ε_Λ = 0`" does not. -/
theorem g5_zero_residual_no_identity (h : ℝ → ℝ) (hh : h (3 / 5) = 1 / 2) :
    ∃ dl ds : ℝ,
      HasDerivAt (fun x => CLev (gate h (3 / 5)) (3 / 5) 2 x (clock (7 / 10) 1 (2 / 5) x) 0)
        dl (3 / 5) ∧
      HasDerivAt (fun x => CArrClose (fun _ : ℝ => (1:ℝ)) (3 / 5) 2 x
        (clock (7 / 10) 1 (2 / 5) x) 0) ds (3 / 5) ∧
      (3 / 5) * dl = -1 / 12 ∧ (3 / 5) * ds = -1 / 6 ∧ dl ≠ ds := by
  have hcap : (1 - (1:ℝ)) * (2 / 5) < (7 / 10) / (3 / 5) := by norm_num
  have harr : (3 / 5 : ℝ) / (3 / 5) < clock (7 / 10) 1 (2 / 5) (3 / 5) := by
    rw [g5_point_clock]; norm_num
  have hhor : clock (7 / 10) 1 (2 / 5) (3 / 5) < 2 := by rw [g5_point_clock]; norm_num
  have hTD := clock_hasDerivAt_s_cap (7 / 10) 1 (2 / 5) (3 / 5) (by norm_num) hcap
  refine ⟨_, _, gated_close_hasDerivAt h _ (3 / 5) 2 (3 / 5) 0 _ (by norm_num) (by norm_num)
    hTD harr hhor, r3_hasDerivAt _ _ 2 (3 / 5) (3 / 5) 0 0 _ (by norm_num) (by norm_num)
    (hasDerivAt_const _ _) hTD harr hhor, ?_, ?_, ?_⟩
  · rw [hh]; norm_num
  · norm_num
  · rw [hh]; norm_num

/-- **"The divergence survives either way."**  At the paper's row-5 point with `ε_Λ = 0.6` and
`h_M^post = 0`, the speed-set arrival-on marginal is `(13/75)Λ_M > 0` for **every** `Λ_M > 0`,
including the earlier draft's `Λ_M = 0.5s^{ε_Λ} = 0.368`. -/
theorem g5_witness_any_scale (Λ : ℝ → ℝ) (lam' ds : ℝ) (hΛ : HasDerivAt Λ lam' (3 / 5))
    (hpos : 0 < Λ (3 / 5)) (heps : (3 / 5) * lam' = (3 / 5) * Λ (3 / 5))
    (hds : HasDerivAt (fun x => CArrClose Λ (3 / 5) 2 x (clock (7 / 10) 1 (2 / 5) x) 0) ds
      (3 / 5)) :
    (3 / 5) * ds = 13 / 75 * Λ (3 / 5) ∧ 0 < (3 / 5) * ds := by
  have hcap : (1 - (1:ℝ)) * (2 / 5) < (7 / 10) / (3 / 5) := by norm_num
  have harr : (3 / 5 : ℝ) / (3 / 5) < clock (7 / 10) 1 (2 / 5) (3 / 5) := by
    rw [g5_point_clock]; norm_num
  have hhor : clock (7 / 10) 1 (2 / 5) (3 / 5) < 2 := by rw [g5_point_clock]; norm_num
  obtain ⟨hsd, -, -⟩ := g5_speed Λ (3 / 5) 2 (3 / 5) (7 / 10) 1 (2 / 5) 0 lam' ds (by norm_num)
    (by norm_num) hΛ hcap harr hhor hds
  have : (3 / 5) * ds = 13 / 75 * Λ (3 / 5) := by rw [hsd]; linarith
  exact ⟨this, by rw [this]; positivity⟩

/-- `0.6^0.6` lies in `(0.7359, 0.7362)`: its fifth power is `0.6³ = 27/125`. -/
theorem g5_rpow_bounds : (0.7359 : ℝ) < (3 / 5 : ℝ) ^ (3 / 5 : ℝ) ∧
    (3 / 5 : ℝ) ^ (3 / 5 : ℝ) < 0.7362 := by
  have hy0 : 0 < (3 / 5 : ℝ) ^ (3 / 5 : ℝ) := by positivity
  have hy5 : ((3 / 5 : ℝ) ^ (3 / 5 : ℝ)) ^ (5 : ℕ) = 27 / 125 := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul (by norm_num),
      show (3 / 5 : ℝ) * ((5 : ℕ) : ℝ) = ((3 : ℕ) : ℝ) by norm_num, Real.rpow_natCast]
    norm_num
  constructor
  · by_contra hc
    have := pow_le_pow_left₀ hy0.le (not_lt.mp hc) 5
    rw [hy5] at this; norm_num at this
  · by_contra hc
    have := pow_le_pow_left₀ (by norm_num) (not_lt.mp hc) 5
    rw [hy5] at this; norm_num at this

/-- **The earlier draft's power law, instantiated.**  `Λ_M(s) = 0.5s^{0.6}` has `ε_Λ = 0.6`
everywhere; at the row-5 point `Λ_M = 0.368` (to three places) and the speed-set arrival-on
marginal is `(13/75)Λ_M = +0.0638` (to four places), positive, so the divergence survives with
it.  The premises of `g5_witness_any_scale` are *derived* here, not assumed. -/
theorem g5_witness_power_law :
    ∃ ds : ℝ,
      HasDerivAt (fun x => CArrClose (fun x : ℝ => 1 / 2 * x ^ (3 / 5 : ℝ)) (3 / 5) 2 x
        (clock (7 / 10) 1 (2 / 5) x) 0) ds (3 / 5) ∧
      (3 / 5) * ds = 13 / 75 * (1 / 2 * (3 / 5 : ℝ) ^ (3 / 5 : ℝ)) ∧ 0 < (3 / 5) * ds ∧
      (0.3679 : ℝ) < 1 / 2 * (3 / 5 : ℝ) ^ (3 / 5 : ℝ) ∧
      1 / 2 * (3 / 5 : ℝ) ^ (3 / 5 : ℝ) < 0.3681 ∧
      (0.06375 : ℝ) < (3 / 5) * ds ∧ (3 / 5) * ds < 0.06385 := by
  have hcap : (1 - (1:ℝ)) * (2 / 5) < (7 / 10) / (3 / 5) := by norm_num
  have harr : (3 / 5 : ℝ) / (3 / 5) < clock (7 / 10) 1 (2 / 5) (3 / 5) := by
    rw [g5_point_clock]; norm_num
  have hhor : clock (7 / 10) 1 (2 / 5) (3 / 5) < 2 := by rw [g5_point_clock]; norm_num
  have hTD := clock_hasDerivAt_s_cap (7 / 10) 1 (2 / 5) (3 / 5) (by norm_num) hcap
  have hΛ : HasDerivAt (fun x : ℝ => 1 / 2 * x ^ (3 / 5 : ℝ))
      (1 / 2 * (3 / 5 * (3 / 5 : ℝ) ^ ((3 / 5 : ℝ) - 1))) (3 / 5) :=
    (Real.hasDerivAt_rpow_const (Or.inl (by norm_num))).const_mul (1 / 2)
  have heps : (3 / 5) * (1 / 2 * (3 / 5 * (3 / 5 : ℝ) ^ ((3 / 5 : ℝ) - 1)))
      = (3 / 5) * (1 / 2 * (3 / 5 : ℝ) ^ (3 / 5 : ℝ)) := by
    rw [Real.rpow_sub_one (by norm_num : (3 / 5 : ℝ) ≠ 0)]; ring
  have hpos : (0:ℝ) < 1 / 2 * (3 / 5 : ℝ) ^ (3 / 5 : ℝ) := by positivity
  obtain ⟨ds, hds⟩ : ∃ ds, HasDerivAt (fun x => CArrClose (fun x : ℝ => 1 / 2 * x ^ (3 / 5 : ℝ))
      (3 / 5) 2 x (clock (7 / 10) 1 (2 / 5) x) 0) ds (3 / 5) :=
    ⟨_, r3_hasDerivAt _ _ 2 (3 / 5) (3 / 5) 0 _ _ (by norm_num) (by norm_num) hΛ hTD harr hhor⟩
  obtain ⟨h1, h2⟩ := g5_witness_any_scale _ _ ds hΛ hpos heps hds
  have h1' : (3 / 5) * ds = 13 / 75 * (1 / 2 * (3 / 5 : ℝ) ^ (3 / 5 : ℝ)) := h1
  obtain ⟨hlo, hhi⟩ := g5_rpow_bounds
  exact ⟨ds, hds, h1', h2, by linarith, by linarith, by rw [h1']; linarith,
    by rw [h1']; linarith⟩

/-- The speed-set ramp-on loss with a step at a moving `t_D(s)`, differentiated in the speed. -/
theorem ramp_hasDerivAt_s (Λ TD : ℝ → ℝ) (L s P lam' tD' : ℝ) (_hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s) (hTD : HasDerivAt TD tD' s) (h0 : 0 < TD s) (hL : TD s < L) :
    HasDerivAt (fun x => CRamp Λ L x (TD x) P) (lam' * TD s + Λ s * tD' + P * -tD') s := by
  have hd := (hΛ.mul hTD).add ((hTD.const_sub L).const_mul P)
  refine hd.congr_of_eventuallyEq ?_
  have e1 : ∀ᶠ x in 𝓝 s, 0 < TD x :=
    hTD.continuousAt.eventually ((isOpen_Ioi.eventually_mem h0).mono (fun _ hx => hx))
  have e2 : ∀ᶠ x in 𝓝 s, TD x < L :=
    hTD.continuousAt.eventually ((isOpen_Iio.eventually_mem hL).mono (fun _ hx => hx))
  filter_upwards [e1, e2] with x hx0 hxL
  rw [CRamp, integral_step (Λ x) P 0 (TD x) L hx0.le hxL.le]
  simp only [Pi.add_apply, Pi.mul_apply]
  ring

/-- **Why the row-5 point belongs to the arrival-on reading.**  On the ramp-on reading at the
same point (`α_D = τ_D/t_D = 35/47 ≈ 0.745 > ε_Λ = 0.6`, zero residual) the speed-set marginal is
negative for every `Λ_M > 0`. -/
theorem g5_witness_rampon_negative (Λ : ℝ → ℝ) (lam' ds : ℝ) (hΛ : HasDerivAt Λ lam' (3 / 5))
    (hpos : 0 < Λ (3 / 5)) (heps : (3 / 5) * lam' = (3 / 5) * Λ (3 / 5))
    (hds : HasDerivAt (fun x => CRamp Λ 2 x (clock (7 / 10) 1 (2 / 5) x) 0) ds (3 / 5)) :
    (3 / 5) * ds = -(34 / 150) * Λ (3 / 5) ∧ (3 / 5) * ds < 0 := by
  have hcap : (1 - (1:ℝ)) * (2 / 5) < (7 / 10) / (3 / 5) := by norm_num
  have hTD := clock_hasDerivAt_s_cap (7 / 10) 1 (2 / 5) (3 / 5) (by norm_num) hcap
  have e := hds.unique (ramp_hasDerivAt_s Λ _ 2 (3 / 5) 0 lam' _ (by norm_num) hΛ hTD
    (by rw [g5_point_clock]; norm_num) (by rw [g5_point_clock]; norm_num))
  rw [g5_point_clock] at e
  have : (3 / 5) * ds = -(34 / 150) * Λ (3 / 5) := by rw [e]; linarith
  refine ⟨this, ?_⟩
  rw [this]
  have := hpos
  linarith

theorem g5_rev_clock : clock 2 1 (1 / 10) 1 = 21 / 10 := by
  rw [clock_cap _ _ _ _ (by norm_num)]; norm_num

/-- **Without the normalisation the direction is not fixed.**  A point inside the admissible region
(A4, `Λ_M > h_M^post`, `h_M(K_M) > h_M^post`, interior, capability branch) with `Λ_M ≠ h_M(K_M)` at
which the gated level-set marginal is positive and the speed-set one negative — the reverse of
the direction the convention fixes.  `s = 1`, `K_M = 1`, `K_D = 2`, `m_D = 1`, `T_D = 0.1`,
`L = 3`, `h_M(K_M) = 0.5`, `h_M^post = 0.3`, `Λ_M(s) = s + 1`. -/
theorem g5_reversal_witness (h : ℝ → ℝ) (hh : h 1 = 1 / 2) :
    ∃ dl ds : ℝ,
      HasDerivAt (fun x => CLev (gate h 1) 1 3 x (clock 2 1 (1 / 10) x) (3 / 10)) dl 1 ∧
      HasDerivAt (fun x => CArrClose (fun x : ℝ => x + 1) 1 3 x (clock 2 1 (1 / 10) x)
        (3 / 10)) ds 1 ∧
      0 < 1 * dl ∧ 1 * ds < 0 ∧
      (fun x : ℝ => x + 1) 1 ≠ h 1 ∧ (3 / 10 : ℝ) < h 1 ∧ (3 / 10 : ℝ) < (fun x : ℝ => x + 1) 1 := by
  have hcap : (1 - (1:ℝ)) * (1 / 10) < 2 / 1 := by norm_num
  have harr : (1 : ℝ) / 1 < clock 2 1 (1 / 10) 1 := by rw [g5_rev_clock]; norm_num
  have hhor : clock 2 1 (1 / 10) 1 < 3 := by rw [g5_rev_clock]; norm_num
  have hTD := clock_hasDerivAt_s_cap 2 1 (1 / 10) 1 one_pos hcap
  have hΛ : HasDerivAt (fun x : ℝ => x + 1) 1 1 := (hasDerivAt_id (1:ℝ)).add_const 1
  refine ⟨_, _, gated_close_hasDerivAt h _ 1 3 1 (3 / 10) _ zero_le_one one_pos hTD harr hhor,
    r3_hasDerivAt _ _ 3 1 1 (3 / 10) 1 _ zero_le_one one_pos hΛ hTD harr hhor, ?_, ?_, ?_, ?_,
    by norm_num⟩
  · rw [hh]; norm_num
  · rw [g5_rev_clock]; norm_num
  · rw [hh]; norm_num
  · rw [hh]; norm_num

/-- **The unrescaled case of the reversal witness.**  `Λ_M = s + 1` is `4·Λ₀` for
`Λ₀(s) = (s + 1)/4`, which meets the comparison convention at the witness speed
(`Λ₀(1) = h_M(K_M) = 0.5`).  There the gated level marginal is `+1/10` and the speed-set one
`+3/8`: no divergence.  So it is the rescaling by 4 alone that produces the reversal. -/
theorem g5_reversal_unscaled (h : ℝ → ℝ) (hh : h 1 = 1 / 2) :
    ∃ dl ds : ℝ,
      HasDerivAt (fun x => CLev (gate h 1) 1 3 x (clock 2 1 (1 / 10) x) (3 / 10)) dl 1 ∧
      HasDerivAt (fun x => CArrClose (fun x : ℝ => (x + 1) / 4) 1 3 x (clock 2 1 (1 / 10) x)
        (3 / 10)) ds 1 ∧
      (fun x : ℝ => (x + 1) / 4) 1 = h 1 ∧
      (fun x : ℝ => x + 1) = (fun x : ℝ => 4 * ((x + 1) / 4)) ∧
      1 * dl = 1 / 10 ∧ 1 * ds = 3 / 8 ∧ 0 < (1 * dl) * (1 * ds) := by
  have hcap : (1 - (1:ℝ)) * (1 / 10) < 2 / 1 := by norm_num
  have harr : (1 : ℝ) / 1 < clock 2 1 (1 / 10) 1 := by rw [g5_rev_clock]; norm_num
  have hhor : clock 2 1 (1 / 10) 1 < 3 := by rw [g5_rev_clock]; norm_num
  have hTD := clock_hasDerivAt_s_cap 2 1 (1 / 10) 1 one_pos hcap
  have hΛ : HasDerivAt (fun x : ℝ => (x + 1) / 4) (1 / 4) 1 := by
    simpa using ((hasDerivAt_id (1:ℝ)).add_const 1).div_const 4
  refine ⟨_, _, gated_close_hasDerivAt h _ 1 3 1 (3 / 10) _ zero_le_one one_pos hTD harr hhor,
    r3_hasDerivAt _ _ 3 1 1 (3 / 10) (1 / 4) _ zero_le_one one_pos hΛ hTD harr hhor,
    by rw [hh]; norm_num, by funext x; ring, ?_, ?_, ?_⟩
  · rw [hh]; norm_num
  · rw [g5_rev_clock]; norm_num
  · rw [hh, g5_rev_clock]; norm_num

/-! ### Row 6 (H): defence on the adoption branch -/

/-- R2's restrictions on a nonnegative hazard — nondecreasing up to `K_M` and not constant there —
give `h_M(K_M) > 0`, which is what makes the gated level derivative strictly positive. -/
theorem h6_pos_of_R2 (h : ℝ → ℝ) (K : ℝ) (hmono : ∀ c ∈ Icc (0:ℝ) K, h c ≤ h K)
    (hnn : ∀ c, 0 ≤ h c) (hnc : ∃ c ∈ Icc (0:ℝ) K, h c ≠ h K) : 0 < h K := by
  obtain ⟨c, hc, hne⟩ := hnc
  have := lt_of_le_of_ne (hmono c hc) hne
  linarith [hnn c]

/-- **Row 6, arrival-on, both sides gated: agree.**  On the adoption branch of the actual clock
the gated level-set marginal is `h_M(K_M)·τ_M` (R2's form with the gated `h̄_M = 0`), the speed-set
marginal is `Λ_M[ε_Λ(t_D − τ_M) + τ_M] > 0` under A4, and for `h_M(K_M) > 0` both are strictly
positive. -/
theorem h6_relation (h Λ : ℝ → ℝ) (K L s KD m T P lam' dl ds : ℝ) (hK : 0 < K) (hs : 0 < s)
    (hadopt : KD / s < (1 - m) * T) (harr : K / s < clock KD m T s) (hhor : clock KD m T s < L)
    (hΛ : HasDerivAt Λ lam' s) (hA4 : 0 < lam') (hΛ0 : 0 ≤ Λ s)
    (hdl : HasDerivAt (fun x => CLev (gate h K) K L x (clock KD m T x) P) dl s)
    (hds : HasDerivAt (fun x => CArrClose Λ K L x (clock KD m T x) P) ds s) :
    s * dl = (K / s) * (h K - hbar (gate h K) K) ∧ s * dl = (K / s) * h K ∧
    s * ds = s * lam' * (clock KD m T s - K / s) + Λ s * (K / s) ∧ 0 < s * ds ∧
    (0 < h K → 0 < s * dl ∧ 0 < (s * dl) * (s * ds)) := by
  have hTD := clock_hasDerivAt_s_adopt KD m T s hs hadopt
  have e1 := hdl.unique (gated_close_hasDerivAt h (fun x => clock KD m T x) K L s P 0 hK.le hs
    hTD harr hhor)
  have e2 := hds.unique (r3_hasDerivAt Λ (fun x => clock KD m T x) L K s P lam' 0 hK.le hs hΛ
    hTD harr hhor)
  have hτ : 0 < K / s := div_pos hK hs
  have hl : s * dl = (K / s) * h K := by rw [e1]; field_simp; ring
  have hsd : s * ds = s * lam' * (clock KD m T s - K / s) + Λ s * (K / s) := by
    rw [e2]; field_simp; ring
  have hpos : 0 < s * ds := by
    rw [hsd]
    have : 0 < s * lam' * (clock KD m T s - K / s) := mul_pos (mul_pos hs hA4) (sub_pos.mpr harr)
    have : 0 ≤ Λ s * (K / s) := mul_nonneg hΛ0 hτ.le
    linarith
  refine ⟨by rw [hl, gate_hbar h K hK, sub_zero], hl, hsd, hpos, fun hh => ?_⟩
  have : 0 < s * dl := by rw [hl]; exact mul_pos hτ hh
  exact ⟨this, mul_pos this hpos⟩

/-! ### Row 7 (H): R2 with the coupled benefit -/

/-- The benefit term of the scenario balance with `ω = 0`: `p·y·(L − a(s))⁺`, with actual
arrival `a = t_B + δ_T` (l.110) and `t_B` on the mixed clock.  A4a.4(vi) sets `δ_T′ = 0`, which
the theorems below carry as `HasDerivAt δ 0 s`; `δ_T` itself need not be zero. -/
noncomputable def benefit (p y KB mB TB : ℝ) (δ : ℝ → ℝ) (L s : ℝ) : ℝ :=
  p * y * max (L - (clock KB mB TB s + δ s)) 0

/-- On the benefit's capability branch (`χ_B = 1`) with `δ_T′ = 0` and actual arrival
`a = t_B + δ_T < L`, the timing margin is `p·y·q`, `q = K_B/s`: the derivative is `p·y·K_B/s²`. -/
theorem benefit_hasDerivAt (p y KB mB TB : ℝ) (δ : ℝ → ℝ) (L s : ℝ) (hs : 0 < s)
    (hcapB : (1 - mB) * TB < KB / s) (hδ : HasDerivAt δ 0 s)
    (harrB : clock KB mB TB s + δ s < L) :
    HasDerivAt (fun x => benefit p y KB mB TB δ L x) (p * y * (KB / s ^ 2)) s := by
  have hc : ContinuousAt (fun x : ℝ => KB / x + mB * TB + δ x) s :=
    ((continuousAt_const.div continuousAt_id hs.ne').add continuousAt_const).add hδ.continuousAt
  rw [clock_cap KB mB TB s hcapB] at harrB
  have hlt : ∀ᶠ x in 𝓝 s, KB / x + mB * TB + δ x < L :=
    hc.eventually ((isOpen_Iio.eventually_mem harrB).mono (fun _ hx => hx))
  have heq : ∀ᶠ x in 𝓝 s,
      benefit p y KB mB TB δ L x = p * y * (L - (KB / x + mB * TB + δ x)) := by
    filter_upwards [clock_cap_eventually_s KB mB TB s hs hcapB, hlt] with x hx hxL
    rw [benefit, hx, max_eq_left (by linarith)]
  have hd : HasDerivAt (fun x => p * y * (L - (KB / x + mB * TB + δ x)))
      (p * y * (KB / s ^ 2)) s := by
    have := ((((hasDerivAt_K_div KB s hs).add_const (mB * TB)).add hδ).const_sub L).const_mul
      (p * y)
    convert this using 1; ring
  exact hd.congr_of_eventuallyEq heq

/-- When the actual arrival falls after the horizon (`L < t_B + δ_T`), the benefit is zero near
the speed and its derivative is zero, whatever `t_B < L` says. -/
theorem benefit_hasDerivAt_late (p y KB mB TB : ℝ) (δ : ℝ → ℝ) (L s : ℝ) (hs : 0 < s)
    (hcapB : (1 - mB) * TB < KB / s) (hδc : ContinuousAt δ s)
    (hlate : L < clock KB mB TB s + δ s) :
    HasDerivAt (fun x => benefit p y KB mB TB δ L x) 0 s := by
  have hc : ContinuousAt (fun x : ℝ => KB / x + mB * TB + δ x) s :=
    ((continuousAt_const.div continuousAt_id hs.ne').add continuousAt_const).add hδc
  rw [clock_cap KB mB TB s hcapB] at hlate
  have hgt : ∀ᶠ x in 𝓝 s, L < KB / x + mB * TB + δ x :=
    hc.eventually ((isOpen_Ioi.eventually_mem hlate).mono (fun _ hx => hx))
  have heq : ∀ᶠ x in 𝓝 s, benefit p y KB mB TB δ L x = 0 := by
    filter_upwards [clock_cap_eventually_s KB mB TB s hs hcapB, hgt] with x hx hxL
    rw [benefit, hx, max_eq_right (by linarith), mul_zero]
  exact (hasDerivAt_const s (0:ℝ)).congr_of_eventuallyEq heq

/-- Row 7's whole balance, level-set side gated: the benefit less `V_M` times the gated misuse
loss, every other channel at zero. -/
noncomputable def Wlev (p y KB mB TB VM : ℝ) (δ h : ℝ → ℝ) (K L s : ℝ) : ℝ :=
  benefit p y KB mB TB δ L s - VM * CLevPlateau (gate h K) K L s

/-- Row 7's whole balance, speed-set arrival-on. -/
noncomputable def Wspd (p y KB mB TB VM : ℝ) (δ Λ : ℝ → ℝ) (K L s : ℝ) : ℝ :=
  benefit p y KB mB TB δ L s - VM * CArr Λ K L s

/-- **The whole-balance interval rule** (A4b), for any `Υ` and endpoints: two marginals `Υ − a`,
`Υ − b` have opposite strict signs iff `Υ` lies strictly between the endpoints, and share a
strict sign iff `Υ` is strictly below both or strictly above both. -/
theorem whole_balance_interval_le (U a b : ℝ) (hab : a ≤ b) :
    ((U - a) * (U - b) < 0 ↔ a < U ∧ U < b) ∧ (0 < (U - a) * (U - b) ↔ U < a ∨ b < U) := by
  refine ⟨⟨fun h => ?_, fun ⟨h1, h2⟩ => mul_neg_of_pos_of_neg (by linarith) (by linarith)⟩,
    ⟨fun h => ?_, ?_⟩⟩
  · rcases mul_neg_iff.mp h with ⟨h1, h2⟩ | ⟨h1, h2⟩
    · exact ⟨by linarith, by linarith⟩
    · exact absurd hab (by linarith)
  · rcases mul_pos_iff.mp h with ⟨h1, h2⟩ | ⟨h1, h2⟩
    · right; linarith
    · left; linarith
  · rintro (h | h)
    · exact mul_pos_of_neg_of_neg (by linarith) (by linarith)
    · exact mul_pos (by linarith) (by linarith)

theorem whole_balance_interval (U a b : ℝ) :
    ((U - a) * (U - b) < 0 ↔ min a b < U ∧ U < max a b) ∧
    (0 < (U - a) * (U - b) ↔ U < min a b ∨ max a b < U) := by
  rcases le_total a b with hab | hab
  · rw [min_eq_left hab, max_eq_right hab]; exact whole_balance_interval_le U a b hab
  · rw [min_eq_right hab, max_eq_left hab, mul_comm (U - a)]
    have := whole_balance_interval_le U b a hab
    exact this

/-- **Row 7, arrival-on, level side gated, on the `pyq` scale (`q = K_B/s`).**  For the defined
whole balances, on the benefit's capability branch with `δ_T′ = 0`, actual arrival
`a = t_B + δ_T < L` (not merely `t_B < L`: see `h7_delay_counterexample`) and `τ_M < L`:

* the gated level-set test is `pyK_B > V_MK_M h_M(K_M)` — the ungated `pyK_B > V_MK_M[h_M(K_M) −
  h̄_M]` with the gated profile's own `h̄_M = 0` — and on the `pyq` scale `pyq > V_M τ_M h_M(K_M)`;
* the speed-set arrival-on test is `pyq > V_MΛ_M[ε_Λ(L − τ_M) + τ_M]`;
* under the comparison convention `Λ_M(s) = h_M(K_M)` (pointwise, at this speed), the gated
  level-set test **is** the speed-set test with `sΛ′ = 0` (`ε_Λ = 0`);
* the thresholds differ by exactly `V_MΛ_Mε_Λ(L − τ_M)` (`= V_M·sΛ′·(L − τ_M)`). -/
theorem h7_tests (p y KB mB TB VM : ℝ) (δ h Λ : ℝ → ℝ) (K L s lam' dl ds : ℝ) (hK : 0 < K)
    (hs : 0 < s) (hwin : K / s < L) (hcapB : (1 - mB) * TB < KB / s)
    (hδ : HasDerivAt δ 0 s) (harrB : clock KB mB TB s + δ s < L) (hΛ : HasDerivAt Λ lam' s)
    (hdl : HasDerivAt (fun x => Wlev p y KB mB TB VM δ h K L x) dl s)
    (hds : HasDerivAt (fun x => Wspd p y KB mB TB VM δ Λ K L x) ds s) :
    s * dl = p * y * (KB / s) - VM * ((K / s) * h K) ∧
    s * ds = p * y * (KB / s) - VM * (s * lam' * (L - K / s) + Λ s * (K / s)) ∧
    (0 < s * dl ↔ VM * K * (h K - hbar (gate h K) K) < p * y * KB) ∧
    (0 < s * dl ↔ VM * K * h K < p * y * KB) ∧
    (0 < s * ds ↔ VM * (s * lam' * (L - K / s) + Λ s * (K / s)) < p * y * (KB / s)) ∧
    (Λ s = h K →
      (0 < s * dl ↔ VM * (s * 0 * (L - K / s) + Λ s * (K / s)) < p * y * (KB / s)) ∧
      VM * (s * lam' * (L - K / s) + Λ s * (K / s)) - VM * ((K / s) * h K)
        = VM * (s * lam') * (L - K / s)) := by
  have hB := benefit_hasDerivAt p y KB mB TB δ L s hs hcapB hδ harrB
  have e1 := hdl.unique ((hB.sub ((gated_plateau_hasDerivAt h K L s hK.le hs hwin).const_mul VM)))
  have e2 := hds.unique (hB.sub ((r2_hasDerivAt Λ L K s lam' hK.le hs hwin hΛ).const_mul VM))
  have hl : s * dl = p * y * (KB / s) - VM * ((K / s) * h K) := by rw [e1]; field_simp
  have hsd : s * ds = p * y * (KB / s) - VM * (s * lam' * (L - K / s) + Λ s * (K / s)) := by
    rw [e2]; field_simp
  have hlev : 0 < s * dl ↔ VM * K * h K < p * y * KB := by
    rw [hl, sub_pos]
    have k1 : VM * ((K / s) * h K) = (VM * K * h K) / s := by field_simp
    have k2 : p * y * (KB / s) = (p * y * KB) / s := by field_simp
    rw [k1, k2, div_lt_div_iff_of_pos_right hs]
  refine ⟨hl, hsd, by rw [gate_hbar h K hK, sub_zero]; exact hlev, hlev, by rw [hsd, sub_pos],
    fun hconv => ⟨?_, by rw [hconv]; ring⟩⟩
  rw [hl, sub_pos, hconv]
  constructor <;> intro hlt <;> linarith

/-- **Row 7: the gap is positive, the interval is directed, never the reverse, and the row is the
whole-balance interval rule with `Υ = pyq`.**  Under the comparison convention, A4 (`Λ′ > 0`),
`τ_M < L` and `V_M > 0`: the speed-set threshold strictly exceeds the gated level-set one; a benefit
strictly between them passes the level-set test and fails the speed-set test; no benefit passes
the speed-set test and fails the level-set test; and the two balances rank speed oppositely iff
`pyq` lies strictly between `V_MΞ_ℓ` and `V_MΞ_s`. -/
theorem h7_interval (p y KB mB TB VM : ℝ) (δ h Λ : ℝ → ℝ) (K L s lam' dl ds : ℝ) (hK : 0 < K)
    (hs : 0 < s) (hwin : K / s < L) (hcapB : (1 - mB) * TB < KB / s)
    (hδ : HasDerivAt δ 0 s) (harrB : clock KB mB TB s + δ s < L) (hΛ : HasDerivAt Λ lam' s)
    (hconv : Λ s = h K) (hA4 : 0 < lam') (hVM : 0 < VM)
    (hdl : HasDerivAt (fun x => Wlev p y KB mB TB VM δ h K L x) dl s)
    (hds : HasDerivAt (fun x => Wspd p y KB mB TB VM δ Λ K L x) ds s) :
    0 < VM * (s * lam') * (L - K / s) ∧
    VM * ((K / s) * h K) < VM * (s * lam' * (L - K / s) + Λ s * (K / s)) ∧
    (VM * ((K / s) * h K) < p * y * (KB / s) →
      p * y * (KB / s) < VM * (s * lam' * (L - K / s) + Λ s * (K / s)) →
      0 < s * dl ∧ s * ds < 0) ∧
    (0 < s * ds → 0 < s * dl) ∧
    ((s * dl) * (s * ds) < 0 ↔
      VM * ((K / s) * h K) < p * y * (KB / s) ∧
        p * y * (KB / s) < VM * (s * lam' * (L - K / s) + Λ s * (K / s))) := by
  obtain ⟨hl, hsd, -, -, -, hconvp⟩ :=
    h7_tests p y KB mB TB VM δ h Λ K L s lam' dl ds hK hs hwin hcapB hδ harrB hΛ hdl hds
  obtain ⟨-, hgap⟩ := hconvp hconv
  have hgpos : 0 < VM * (s * lam') * (L - K / s) :=
    mul_pos (mul_pos hVM (mul_pos hs hA4)) (sub_pos.mpr hwin)
  have hord : VM * ((K / s) * h K) < VM * (s * lam' * (L - K / s) + Λ s * (K / s)) := by
    linarith
  refine ⟨hgpos, hord, fun h1 h2 => ⟨by rw [hl]; linarith, by rw [hsd]; linarith⟩,
    fun hpos => by rw [hl]; rw [hsd] at hpos; linarith, ?_⟩
  rw [hl, hsd]
  exact (whole_balance_interval_le (p * y * (KB / s)) _ _ hord.le).1

/-- **Row 7's gap in the printed elasticity form.**  With `Λ_M(s) > 0` and `ε_Λ = sΛ′/Λ_M`, the
gap `V_M·sΛ′·(L − τ_M)` of `h7_tests` is `V_MΛ_Mε_Λ(L − τ_M)`; this is the only place the
elasticity is divided out, and it is algebraic. -/
theorem h7_gap_eps (VM Λs lam' s K L : ℝ) (hΛ : 0 < Λs) :
    VM * (s * lam') * (L - K / s) = VM * Λs * (s * lam' / Λs) * (L - K / s) := by
  field_simp

/-- **Row 7's printed condition `t_B < L` is not enough when `δ_T ≠ 0`** (A4a.4(vi) sets only
`δ_T′ = 0`).  `s = K_M = K_B = m_B = T_B = p = V_M = 1`, `y = 4`, `L = 3`, constant `δ_T = 2`,
`h_M(K_M) = 1`, `Λ_M(s) = s` (A4, `ε_Λ = 1`): `t_B = 2 < L` but actual arrival is `4 > L`.  Both
printed tests pass (`pyK_B = 4 > V_MK_Mh_M(K_M) = 1`; `pyq = 4 > V_MΛ_M[ε_Λ(L − τ_M) + τ_M] = 3`),
yet the derivatives of both defined balances are negative (`−1` and `−3`). -/
theorem h7_delay_counterexample (h : ℝ → ℝ) (hh : h 1 = 1) :
    ∃ dl ds : ℝ,
      HasDerivAt (fun x => Wlev 1 4 1 1 1 1 (fun _ => 2) h 1 3 x) dl 1 ∧
      HasDerivAt (fun x => Wspd 1 4 1 1 1 1 (fun _ => 2) (fun x : ℝ => x) 1 3 x) ds 1 ∧
      clock 1 1 1 1 < 3 ∧ 3 < clock 1 1 1 1 + 2 ∧
      (1 : ℝ) * 1 * h 1 < 1 * 4 * 1 ∧
      (1 : ℝ) * (1 * 1 * (3 - 1 / 1) + (fun x : ℝ => x) 1 * (1 / 1)) < 1 * 4 * (1 / 1) ∧
      1 * dl = -1 ∧ 1 * ds = -3 := by
  have hcapB : (1 - (1:ℝ)) * 1 < 1 / 1 := by norm_num
  have hclk : clock 1 1 1 1 = 2 := by rw [clock_cap 1 1 1 1 hcapB]; norm_num
  have hwin : (1:ℝ) / 1 < 3 := by norm_num
  have hB := benefit_hasDerivAt_late 1 4 1 1 1 (fun _ => 2) 3 1 one_pos hcapB continuousAt_const
    (by rw [hclk]; norm_num)
  refine ⟨_, _, hB.sub ((gated_plateau_hasDerivAt h 1 3 1 zero_le_one one_pos hwin).const_mul 1),
    hB.sub ((r2_hasDerivAt (fun x : ℝ => x) 3 1 1 1 zero_le_one one_pos hwin
      (hasDerivAt_id' 1)).const_mul 1), by rw [hclk]; norm_num, by rw [hclk]; norm_num,
    by rw [hh]; norm_num, by norm_num, ?_, ?_⟩
  · rw [hh]; norm_num
  · norm_num

end PostGHI
end BioPaper

#print axioms BioPaper.PostGHI.clock_cap
#print axioms BioPaper.PostGHI.clock_adopt
#print axioms BioPaper.PostGHI.clock_cap_eventually_s
#print axioms BioPaper.PostGHI.clock_adopt_eventually_s
#print axioms BioPaper.PostGHI.hasDerivAt_K_div
#print axioms BioPaper.PostGHI.clock_hasDerivAt_s_cap
#print axioms BioPaper.PostGHI.clock_hasDerivAt_s_adopt
#print axioms BioPaper.PostGHI.clock_hasDerivAt_K
#print axioms BioPaper.PostGHI.gate_at
#print axioms BioPaper.PostGHI.gate_zero_below
#print axioms BioPaper.PostGHI.convA_at
#print axioms BioPaper.PostGHI.gate_hbar
#print axioms BioPaper.PostGHI.gate_path
#print axioms BioPaper.PostGHI.gate_levHaz
#print axioms BioPaper.PostGHI.gate_plateau_eq_CArr
#print axioms BioPaper.PostGHI.gate_close_eq_CArrClose
#print axioms BioPaper.PostGHI.gate_plateau_eventuallyEq
#print axioms BioPaper.PostGHI.gate_close_eventuallyEq
#print axioms BioPaper.PostGHI.arrClose_hasDerivAt_weak
#print axioms BioPaper.PostGHI.CTrans_split
#print axioms BioPaper.PostGHI.trans_hasDerivAt
#print axioms BioPaper.PostGHI.clock_continuous_K
#print axioms BioPaper.PostGHI.preOK_of_eqOn
#print axioms BioPaper.PostGHI.preLev_ok
#print axioms BioPaper.PostGHI.gate_intervalIntegrable
#print axioms BioPaper.PostGHI.convA_intervalIntegrable
#print axioms BioPaper.PostGHI.CLev_eq_trans
#print axioms BioPaper.PostGHI.CArrClose_eq_trans
#print axioms BioPaper.PostGHI.CRamp_eq_trans
#print axioms BioPaper.PostGHI.trans_kd
#print axioms BioPaper.PostGHI.clock_eventually_gt
#print axioms BioPaper.PostGHI.i_CLev_kd
#print axioms BioPaper.PostGHI.i_levB_rampon
#print axioms BioPaper.PostGHI.i_levA_rampon
#print axioms BioPaper.PostGHI.i_levB_arrival
#print axioms BioPaper.PostGHI.i_levA_arrival
#print axioms BioPaper.PostGHI.i_speed_rampon
#print axioms BioPaper.PostGHI.preArr_ok
#print axioms BioPaper.PostGHI.i_speed_arrival
#print axioms BioPaper.PostGHI.i_sign
#print axioms BioPaper.PostGHI.chi_adopt
#print axioms BioPaper.PostGHI.chi_cap
#print axioms BioPaper.PostGHI.i_CLev_kd_adopt
#print axioms BioPaper.PostGHI.i_speed_rampon_adopt
#print axioms BioPaper.PostGHI.i_speed_arrival_adopt
#print axioms BioPaper.PostGHI.i_CLev_kd_sign
#print axioms BioPaper.PostGHI.i_speed_arrival_sign
#print axioms BioPaper.PostGHI.i_speed_rampon_sign
#print axioms BioPaper.PostGHI.trans_kd_gradual
#print axioms BioPaper.PostGHI.trans_kd_linear_trunc
#print axioms BioPaper.PostGHI.trans_linear_trunc_ne
#print axioms BioPaper.PostGHI.i_gradual_failure_instance
#print axioms BioPaper.PostGHI.trans_kd_resp
#print axioms BioPaper.PostGHI.i_CLev_kd_resp
#print axioms BioPaper.PostGHI.i_speed_arrival_resp
#print axioms BioPaper.PostGHI.i_speed_rampon_resp
#print axioms BioPaper.PostGHI.i_gradual_lev
#print axioms BioPaper.PostGHI.i_gradual_levB_rampon
#print axioms BioPaper.PostGHI.i_gradual_levA_rampon
#print axioms BioPaper.PostGHI.i_gradual_levB_arrival
#print axioms BioPaper.PostGHI.i_gradual_levA_arrival
#print axioms BioPaper.PostGHI.i_gradual_speed_rampon
#print axioms BioPaper.PostGHI.i_gradual_speed_arrival
#print axioms BioPaper.PostGHI.gated_plateau_hasDerivAt
#print axioms BioPaper.PostGHI.gated_close_hasDerivAt
#print axioms BioPaper.PostGHI.g1_relation
#print axioms BioPaper.PostGHI.g1_cannot_diverge
#print axioms BioPaper.PostGHI.h2_relation
#print axioms BioPaper.PostGHI.paced_ord
#print axioms BioPaper.PostGHI.g4_relation
#print axioms BioPaper.PostGHI.g5_level
#print axioms BioPaper.PostGHI.g5_speed
#print axioms BioPaper.PostGHI.g5_direction_convention
#print axioms BioPaper.PostGHI.g5_direction_zero_residual
#print axioms BioPaper.PostGHI.g5_point_Lam
#print axioms BioPaper.PostGHI.g5_point_clock
#print axioms BioPaper.PostGHI.g5_witness
#print axioms BioPaper.PostGHI.g5_witness_any_scale
#print axioms BioPaper.PostGHI.ramp_hasDerivAt_s
#print axioms BioPaper.PostGHI.g5_witness_rampon_negative
#print axioms BioPaper.PostGHI.g5_rev_clock
#print axioms BioPaper.PostGHI.g5_reversal_witness
#print axioms BioPaper.PostGHI.h6_pos_of_R2
#print axioms BioPaper.PostGHI.h6_relation
#print axioms BioPaper.PostGHI.benefit_hasDerivAt
#print axioms BioPaper.PostGHI.whole_balance_interval_le
#print axioms BioPaper.PostGHI.whole_balance_interval
#print axioms BioPaper.PostGHI.h7_tests
#print axioms BioPaper.PostGHI.h7_interval
#print axioms BioPaper.PostGHI.h7_gap_eps
#print axioms BioPaper.PostGHI.i_l1006_formula_adopt_ne
#print axioms BioPaper.PostGHI.i_l1006_formula_instance
#print axioms BioPaper.PostGHI.trans_kd_linear_only_at
#print axioms BioPaper.PostGHI.trans_kd_resp_gradual
#print axioms BioPaper.PostGHI.i_resp_gradual_instance
#print axioms BioPaper.PostGHI.g5_zero_residual_no_identity
#print axioms BioPaper.PostGHI.g5_rpow_bounds
#print axioms BioPaper.PostGHI.g5_witness_power_law
#print axioms BioPaper.PostGHI.g5_reversal_unscaled
#print axioms BioPaper.PostGHI.benefit_hasDerivAt_late
#print axioms BioPaper.PostGHI.h7_delay_counterexample
#print axioms BioPaper.PostGHI.trans_kd_linear_adopt
#print axioms BioPaper.PostGHI.trans_kd_linear_nogap
#print axioms BioPaper.PostGHI.i_gradual_incomplete_instance
#print axioms BioPaper.PostGHI.i_gradual_nonrigid_instance
