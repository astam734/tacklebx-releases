import Mathlib

/-!
# Item 1 of `PROOF-INVENTORY.md` — the speed-set, arrival-on plateau

The paper prints `s * C_M' = Λ_M * (ε_Λ * (L - τ_M) + τ_M)`, with `τ_M = K_M/s`
and `ε_Λ = s * Λ_M' / Λ_M`.  Under speed-set arrival-on with no closure the
hazard is the constant `Λ_M s` on `[τ_M, L]`, so `C_M s = Λ_M s * (L - K_M/s)`.

## Translation note — this is the whole risk of the exercise

Lean checks that the proofs below prove *these statements*.  It cannot check
that these statements are the paper's claim.  Two translation choices were made
and a human reader must agree with both.

1. `C` is **defined** here as `Λ s * (L - K/s)`: the closed form of the
   integral, not the integral itself.  That the integral equals this — because
   the hazard is constant in `t` across the exposure window — is a separate
   step and is **not** formalised here.
2. The conclusion avoids dividing by `Λ s`, which `ε_Λ` carries.  Substituting
   `ε_Λ = s * Λ' / Λ` recovers the paper's form exactly when `Λ s ≠ 0`, which
   the paper assumes but which is not a hypothesis below.
-/

open Real

variable {Λ : ℝ → ℝ}

/-- The exposure window `L - K/s` has derivative `K/s²`. -/
theorem window_deriv (L K s : ℝ) (hs : s ≠ 0) :
    HasDerivAt (fun x : ℝ => L - K / x) (K / s ^ 2) s := by
  have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs
  have hK : HasDerivAt (fun x : ℝ => K * x⁻¹) (K * -(s ^ 2)⁻¹) s := hinv.const_mul K
  have h := hK.const_sub L
  simp only [div_eq_mul_inv] at *
  convert h using 1
  field_simp

/-- **Item 1, the derivative.**  The misuse loss under speed-set arrival-on with
no closure is `C s = Λ s * (L - K/s)`, and it is differentiable with the
product-rule derivative. -/
theorem item1_hasDerivAt (L K s lam' : ℝ) (hs : s ≠ 0) (hΛ : HasDerivAt Λ lam' s) :
    HasDerivAt (fun x : ℝ => Λ x * (L - K / x))
      (lam' * (L - K / s) + Λ s * (K / s ^ 2)) s :=
  hΛ.mul (window_deriv L K s hs)

/-- **Item 1, the paper's form.**  Multiplying by `s` gives
`s*Λ' * (L - K/s) + Λ s * (K/s)`, which is the paper's
`Λ * (ε_Λ * (L - τ_M) + τ_M)` once `ε_Λ = s*Λ'/Λ` is substituted. -/
theorem item1_scaled (L K s lam' : ℝ) (hs : s ≠ 0) :
    s * (lam' * (L - K / s) + Λ s * (K / s ^ 2))
      = s * lam' * (L - K / s) + Λ s * (K / s) := by
  field_simp

/-- **Item 1, the sign.**  With `Λ s > 0`, `K > 0`, `s > 0` and the capability
reached inside the horizon (`K/s < L`), a nonnegative `Λ'` makes the scaled
derivative strictly positive — and it is strictly positive even at `Λ' = 0`,
because the onset term `Λ s * (K/s)` alone is positive.  That is the paper's
observation that arrival-on differs from ramp-on, where the derivative vanishes
at zero elasticity. -/
theorem item1_pos (L K s lam' : ℝ) (hs : 0 < s) (hK : 0 < K) (hΛs : 0 < Λ s)
    (hwin : K / s < L) (hlam : 0 ≤ lam') :
    0 < s * lam' * (L - K / s) + Λ s * (K / s) := by
  have h1 : 0 ≤ s * lam' * (L - K / s) := by
    have : 0 < L - K / s := sub_pos.mpr hwin
    positivity
  have h2 : 0 < Λ s * (K / s) := by positivity
  linarith
