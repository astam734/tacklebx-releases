import BioPaperProofs.StepIntegral

/-!
# The level-set family: Leibniz at a moving boundary over a non-constant hazard profile

Under the level-set specification the misuse hazard is indexed by the capability *level* reached,
`c(t) = min (s t) K_M`, so misuse loss carries an integral of a non-constant profile over a
window whose upper limit moves with the thing being differentiated.  That is what makes this
family harder than Group 1, where the hazard was constant across the exposure window.

Two moving boundaries appear, and they are different:

* **In the speed.** Under truncation (R1) the capability lies beyond the horizon, so the whole
  window is ramp and `C_M = (1/s)∫_0^{sL} h_M`.  Acceleration moves the upper limit `sL`, which
  is what "pulls level-indexed risk into the window" means.  The derivative needs the
  fundamental theorem of calculus, not just the chain rule.
* **In the misuse distance.** Differentiating in `K_M` moves the boundary between ramp and
  plateau.  Under convention B the ramp integral's upper limit contributes `+h_M(K_M)/s` and the
  shrinking plateau contributes `−h_M(K_M)/s`, and **the two cancel** — which is why the
  convention-B derivative is `(t_D − τ_M)h_M′(K_M)` with no level term.  The appendix says the
  boundary terms "cancel as in Lemma 1(b)"; `dKM_B_rampon` below is that cancellation.

## Translation note — the choices a reader must agree with

1. **Regularity.** `h_M` is taken `Continuous` throughout, and differentiable at `K_M` where a
   `K_M` derivative is claimed.  The paper assumes continuity at `K_M` and uses monotonicity;
   continuity on the range integrated over is a formalisation choice, stated here.
2. **The hazard shape.** Ramp-on with closure is `levHaz`: `h_M(st)` while climbing, `h_M(K_M)`
   on the plateau, the residual `P` after `t_D`.  Arrival-on is `step2 0 (h K) P (K/s) t_D` from
   `StepIntegral.lean` — the same object Group 1 used, with the plateau level now `h_M(K_M)`.
   That the two specifications differ *only* in that level is the structural fact the paper's
   §4a.5 passage on the `K_D` invariance turns on.
3. **Convention A** is `hA ĥ K c = ĥ (c/K)`, the shape-preserving profile, and **convention B**
   is the fixed profile `h` itself.  `ĥ 1` is the plateau hazard under A.
4. **`h̄_M`** is `hbar h K = (∫_0^K h)/K`, the paper's ramp average `h̄_M(0, K_M)`.
-/

open MeasureTheory intervalIntegral Set

namespace BioPaper

variable {h : ℝ → ℝ}

/-- The ramp average `h̄_M(0, K)`. -/
noncomputable def hbar (h : ℝ → ℝ) (K : ℝ) : ℝ := (∫ c in (0:ℝ)..K, h c) / K

/-- Level-set ramp-on hazard with closure: `h(st)` while climbing, `h(K)` on the plateau, the
residual `P` from `t_D`. -/
noncomputable def levHaz (h : ℝ → ℝ) (K s tD P : ℝ) : ℝ → ℝ :=
  fun t => if t < K / s then h (s * t) else if t < tD then h K else P

/-- Level-set ramp-on misuse loss with closure, **defined as the integral**. -/
noncomputable def CLev (h : ℝ → ℝ) (K L s tD P : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, levHaz h K s tD P t

/-- Level-set ramp-on misuse loss with no closure: the hazard is `h(c(t))` with
`c(t) = min (s t) K`, the paper's capability path. -/
noncomputable def CLevPlateau (h : ℝ → ℝ) (K L s : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, h (min (s * t) K)

/-! ## The ramp integral: a change of variable -/

/-- **The ramp integral.**  `∫_0^{K/s} h(st) dt = (1/s)∫_0^K h`.  This is the substitution that
turns a date integral into a capability integral, and it is why the level-set loss carries
`∫_0^{K_M} h_M` rather than anything about `s` inside the integrand. -/
theorem ramp_integral (h : ℝ → ℝ) (K s : ℝ) (hs : s ≠ 0) :
    (∫ t in (0:ℝ)..(K / s), h (s * t)) = s⁻¹ * ∫ c in (0:ℝ)..K, h c := by
  rw [integral_comp_mul_left (f := h) hs, smul_eq_mul, mul_zero,
    mul_div_cancel₀ K hs]

/-- Convention A's profile integrates to `K` times the average of `ĥ` on the unit interval:
`∫_0^K ĥ(c/K) dc = K ∫_0^1 ĥ`.  Compressing the profile with the threshold leaves the *shape*
alone, which is what makes `ĥ 1` the plateau hazard at every `K`. -/
theorem integral_shapePreserving (ĥ : ℝ → ℝ) (K : ℝ) (hK : K ≠ 0) :
    (∫ c in (0:ℝ)..K, ĥ (c / K)) = K * ∫ u in (0:ℝ)..1, ĥ u := by
  have hinv : K⁻¹ ≠ 0 := inv_ne_zero hK
  have : (∫ c in (0:ℝ)..K, ĥ (K⁻¹ * c)) = K * ∫ u in (0:ℝ)..1, ĥ u := by
    rw [integral_comp_mul_left (f := ĥ) hinv, smul_eq_mul, mul_zero, inv_inv,
      inv_mul_cancel₀ hK]
  simpa [div_eq_inv_mul] using this

/-! ## The closed forms -/

/-- **The level-set closed form, plateau regime.**  While the capability is reached inside the
horizon, the loss splits into a capability integral over the ramp and a plateau term. -/
theorem CLevPlateau_eq (h : ℝ → ℝ) (K L s : ℝ) (hcont : Continuous h) (hs : 0 < s)
    (hK : 0 ≤ K) (hwin : K / s ≤ L) :
    CLevPlateau h K L s = s⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (L - K / s) := by
  have hτ : 0 ≤ K / s := by positivity
  have hramp : IntervalIntegrable (fun t : ℝ => h (min (s * t) K)) volume 0 (K / s) :=
    ((hcont.comp ((continuous_const.mul continuous_id).min continuous_const)).intervalIntegrable
      _ _)
  have hplat : IntervalIntegrable (fun t : ℝ => h (min (s * t) K)) volume (K / s) L :=
    ((hcont.comp ((continuous_const.mul continuous_id).min continuous_const)).intervalIntegrable
      _ _)
  have h1 : (∫ t in (0:ℝ)..(K / s), h (min (s * t) K)) = s⁻¹ * ∫ c in (0:ℝ)..K, h c := by
    rw [integral_congr_Ioo_of_le hτ (g := fun t : ℝ => h (s * t)) ?_]
    · exact ramp_integral h K s hs.ne'
    · intro t ht
      have : s * t ≤ K := by
        have := ht.2.le
        calc s * t ≤ s * (K / s) := by exact mul_le_mul_of_nonneg_left this hs.le
        _ = K := mul_div_cancel₀ K hs.ne'
      simp [min_eq_left this]
  have h2 : (∫ t in (K / s)..L, h (min (s * t) K)) = h K * (L - K / s) := by
    rw [integral_congr_Ioo_of_le hwin (g := fun _ : ℝ => h K) ?_,
      intervalIntegral.integral_const, smul_eq_mul]
    · ring
    · intro t ht
      have : K ≤ s * t := by
        have h' : K / s ≤ t := ht.1.le
        calc K = s * (K / s) := (mul_div_cancel₀ K hs.ne').symm
        _ ≤ s * t := mul_le_mul_of_nonneg_left h' hs.le
      simp [min_eq_right this]
  rw [CLevPlateau, ← integral_add_adjacent_intervals hramp hplat, h1, h2]

/-- **The level-set closed form, truncated regime (R1).**  Where the capability lies beyond the
horizon the whole window is ramp, and the loss is `(1/s)∫_0^{sL} h` — an integral whose upper
limit moves with the speed. -/
theorem CLevPlateau_eq_trunc (h : ℝ → ℝ) (K L s : ℝ) (_hcont : Continuous h) (hs : 0 < s)
    (hL : 0 ≤ L) (htrunc : L ≤ K / s) :
    CLevPlateau h K L s = s⁻¹ * ∫ c in (0:ℝ)..(s * L), h c := by
  have hstep : (∫ t in (0:ℝ)..L, h (min (s * t) K)) = ∫ t in (0:ℝ)..L, h (s * t) := by
    rw [integral_congr_Ioo_of_le hL (g := fun t : ℝ => h (s * t)) ?_]
    intro t ht
    have : s * t ≤ K := by
      have h1 : t ≤ K / s := le_trans ht.2.le htrunc
      calc s * t ≤ s * (K / s) := mul_le_mul_of_nonneg_left h1 hs.le
      _ = K := mul_div_cancel₀ K hs.ne'
    simp [min_eq_left this]
  rw [CLevPlateau, hstep, integral_comp_mul_left (f := h) hs.ne', smul_eq_mul, mul_zero]

/-- **The level-set closed form with closure (R3).** -/
theorem CLev_eq (h : ℝ → ℝ) (K L s tD P : ℝ) (hcont : Continuous h) (hs : 0 < s) (hK : 0 ≤ K)
    (hD : K / s ≤ tD) (hL : tD ≤ L) :
    CLev h K L s tD P
      = s⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (tD - K / s) + P * (L - tD) := by
  have hτ : 0 ≤ K / s := by positivity
  have hcomp : Continuous (fun t : ℝ => h (s * t)) :=
    hcont.comp (continuous_const.mul continuous_id)
  have hi1 : IntervalIntegrable (levHaz h K s tD P) volume 0 (K / s) := by
    rw [intervalIntegrable_congr_uIoo (g := fun t : ℝ => h (s * t)) ?_]
    · exact hcomp.intervalIntegrable _ _
    · intro t ht
      rw [uIoo_of_le hτ] at ht
      simp [levHaz, ht.2]
  have hi2 : IntervalIntegrable (levHaz h K s tD P) volume (K / s) L := by
    rw [intervalIntegrable_congr_uIoo (g := step (h K) P tD) ?_]
    · exact intervalIntegrable_step (h K) P (K / s) tD L hD hL
    · intro t ht
      rw [uIoo_of_le (le_trans hD hL)] at ht
      have : ¬ t < K / s := not_lt.mpr ht.1.le
      simp [levHaz, step, this]
  have h1 : (∫ t in (0:ℝ)..(K / s), levHaz h K s tD P t) = s⁻¹ * ∫ c in (0:ℝ)..K, h c := by
    rw [integral_congr_Ioo_of_le hτ (g := fun t : ℝ => h (s * t)) ?_]
    · exact ramp_integral h K s hs.ne'
    · intro t ht; simp [levHaz, ht.2]
  have h2 : (∫ t in (K / s)..L, levHaz h K s tD P t) = h K * (tD - K / s) + P * (L - tD) := by
    rw [integral_congr_Ioo_of_le (le_trans hD hL) (g := step (h K) P tD) ?_]
    · exact integral_step (h K) P (K / s) tD L hD hL
    · intro t ht
      have : ¬ t < K / s := not_lt.mpr ht.1.le
      simp [levHaz, step, this]
  rw [CLev, ← integral_add_adjacent_intervals hi1 hi2, h1, h2]; ring

/-! ## R2: the plateau -/

/-- The plateau-regime closed form holds on a neighbourhood of any speed that reaches the
capability strictly inside the horizon. -/
theorem CLevPlateau_eventuallyEq (h : ℝ → ℝ) (K L s₀ : ℝ) (hcont : Continuous h) (hK : 0 ≤ K)
    (hs : 0 < s₀) (hwin : K / s₀ < L) :
    ∀ᶠ s in nhds s₀, CLevPlateau h K L s = s⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (L - K / s) := by
  have hpos : ∀ᶠ s in nhds s₀, (0:ℝ) < s :=
    (isOpen_Ioi.eventually_mem hs).mono (fun x hx => hx)
  have hcd : ContinuousAt (fun x : ℝ => K / x) s₀ :=
    continuousAt_const.div continuousAt_id hs.ne'
  have hlt : ∀ᶠ s in nhds s₀, K / s < L :=
    hcd.eventually ((isOpen_Iio.eventually_mem hwin).mono (fun x hx => hx))
  filter_upwards [hpos, hlt] with s hs0 hsL
  exact CLevPlateau_eq h K L s hcont hs0 hK hsL.le

/-- **R2, level-set, the derivative from the integral.** -/
theorem r2_lev_hasDerivAt (h : ℝ → ℝ) (K L s : ℝ) (hcont : Continuous h) (hK : 0 ≤ K)
    (hs : 0 < s) (hwin : K / s < L) :
    HasDerivAt (fun x : ℝ => CLevPlateau h K L x)
      (-(s ^ 2)⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (K / s ^ 2)) s := by
  have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs.ne'
  have hA : HasDerivAt (fun x : ℝ => x⁻¹ * ∫ c in (0:ℝ)..K, h c)
      (-(s ^ 2)⁻¹ * ∫ c in (0:ℝ)..K, h c) s := hinv.mul_const _
  have hwindow : HasDerivAt (fun x : ℝ => h K * (L - K / x)) (h K * (K / s ^ 2)) s := by
    have hKx : HasDerivAt (fun x : ℝ => K / x) (-(K / s ^ 2)) s := by
      have hh := hinv.const_mul K
      simp only [div_eq_mul_inv] at *
      convert hh using 1
      field_simp
    have := (hKx.const_sub L).const_mul (h K)
    convert this using 1
    ring
  exact (hA.add hwindow).congr_of_eventuallyEq
    (CLevPlateau_eventuallyEq h K L s hcont hK hs hwin)

/-- **R2, level-set, the paper's form.**  `s·C_M′ = τ_M[h_M(K_M) − h̄_M]`. -/
theorem r2_lev_scaled (A hK K s : ℝ) (hs : s ≠ 0) (hKne : K ≠ 0) :
    s * (-(s ^ 2)⁻¹ * A + hK * (K / s ^ 2)) = (K / s) * (hK - A / K) := by
  field_simp
  ring

/-- **R2, level-set, the paper's form with the proved derivative substituted.**  The scaled
derivative of the loss `r2_lev_hasDerivAt` proves is exactly `τ_M[h_M(K_M) − h̄_M]`.  Stated
separately from `r2_lev_scaled` because that one has free variables where this one has the
integral and the ramp average themselves. -/
theorem r2_lev_paper_form (h : ℝ → ℝ) (K s : ℝ) (hs : s ≠ 0) (hK : K ≠ 0) :
    s * (-(s ^ 2)⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (K / s ^ 2))
      = (K / s) * (h K - hbar h K) := by
  rw [hbar]; field_simp; ring

/-! ## R1: truncation, the moving boundary in the speed -/

/-- The truncated closed form holds on a neighbourhood of any speed strictly inside the
unreached region. -/
theorem CLevPlateau_eventuallyEq_trunc (h : ℝ → ℝ) (K L s₀ : ℝ) (hcont : Continuous h)
    (hL : 0 ≤ L) (hs : 0 < s₀) (htrunc : L < K / s₀) :
    ∀ᶠ s in nhds s₀, CLevPlateau h K L s = s⁻¹ * ∫ c in (0:ℝ)..(s * L), h c := by
  have hpos : ∀ᶠ s in nhds s₀, (0:ℝ) < s :=
    (isOpen_Ioi.eventually_mem hs).mono (fun x hx => hx)
  have hcd : ContinuousAt (fun x : ℝ => K / x) s₀ :=
    continuousAt_const.div continuousAt_id hs.ne'
  have hgt : ∀ᶠ s in nhds s₀, L < K / s :=
    hcd.eventually ((isOpen_Ioi.eventually_mem htrunc).mono (fun x hx => hx))
  filter_upwards [hpos, hgt] with s hs0 hsL
  exact CLevPlateau_eq_trunc h K L s hcont hs0 hL hsL.le

/-- **R1, the derivative.**  The upper limit of the capability integral moves with the speed, so
this needs the fundamental theorem of calculus and not only the chain rule.  This is the
mechanism the paper calls pulling level-indexed risk inside the horizon. -/
theorem r1_lev_hasDerivAt (h : ℝ → ℝ) (K L s : ℝ) (hcont : Continuous h) (hL : 0 ≤ L)
    (hs : 0 < s) (htrunc : L < K / s) :
    HasDerivAt (fun x : ℝ => CLevPlateau h K L x)
      (-(s ^ 2)⁻¹ * (∫ c in (0:ℝ)..(s * L), h c) + s⁻¹ * (h (s * L) * L)) s := by
  have hFTC : HasDerivAt (fun u : ℝ => ∫ c in (0:ℝ)..u, h c) (h (s * L)) (s * L) :=
    integral_hasDerivAt_right (hcont.intervalIntegrable _ _)
      hcont.aestronglyMeasurable.stronglyMeasurableAtFilter hcont.continuousAt
  have hlin : HasDerivAt (fun x : ℝ => x * L) L s := by
    simpa using (hasDerivAt_id s).mul_const L
  have hcomp : HasDerivAt ((fun u : ℝ => ∫ c in (0:ℝ)..u, h c) ∘ fun x : ℝ => x * L)
      (h (s * L) * L) s := hFTC.comp s hlin
  have hupper : HasDerivAt (fun x : ℝ => ∫ c in (0:ℝ)..(x * L), h c) (h (s * L) * L) s := hcomp
  have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs.ne'
  have hprod := hinv.mul hupper
  exact hprod.congr_of_eventuallyEq
    (CLevPlateau_eventuallyEq_trunc h K L s hcont hL hs htrunc)

/-- **R1, the paper's form.**  `s·C_M′ = L[h_M(sL) − h̄_M(0, sL)]`. -/
theorem r1_lev_scaled (H hsl s L : ℝ) (hs : s ≠ 0) (hL : L ≠ 0) :
    s * (-(s ^ 2)⁻¹ * H + s⁻¹ * (hsl * L)) = L * (hsl - H / (s * L)) := by
  field_simp
  ring

/-- **R1, the paper's form with the proved derivative substituted.**  `L[h_M(sL) − h̄_M(0, sL)]`,
with the ramp average taken over the capability range the horizon actually reaches. -/
theorem r1_lev_paper_form (h : ℝ → ℝ) (s L : ℝ) (hs : s ≠ 0) (hL : L ≠ 0) :
    s * (-(s ^ 2)⁻¹ * (∫ c in (0:ℝ)..(s * L), h c) + s⁻¹ * (h (s * L) * L))
      = L * (h (s * L) - hbar h (s * L)) := by
  rw [hbar]; field_simp; ring

/-! ## The sign: monotonicity alone -/

/-- **The inequality that signs R1 and R2.**  A nondecreasing hazard's ramp average never
exceeds its terminal value, so `h_M(K_M) − h̄_M ≥ 0` and both derivatives are nonnegative
"by monotonicity alone", as the paper puts it.  Nothing else about `h_M` is used. -/
theorem integral_le_endpoint (f : ℝ → ℝ) (x : ℝ) (hx : 0 ≤ x) (hcont : Continuous f)
    (hmono : ∀ u ∈ Icc (0:ℝ) x, f u ≤ f x) : (∫ u in (0:ℝ)..x, f u) ≤ x * f x := by
  have hle : (∫ u in (0:ℝ)..x, f u) ≤ ∫ _u in (0:ℝ)..x, f x :=
    integral_mono_on hx (hcont.intervalIntegrable _ _) intervalIntegrable_const hmono
  calc (∫ u in (0:ℝ)..x, f u) ≤ ∫ _u in (0:ℝ)..x, f x := hle
  _ = x * f x := by rw [intervalIntegral.integral_const, smul_eq_mul]; ring

theorem hbar_le (h : ℝ → ℝ) (K : ℝ) (hK : 0 < K) (hcont : Continuous h)
    (hmono : ∀ x ∈ Icc (0:ℝ) K, h x ≤ h K) : hbar h K ≤ h K := by
  rw [hbar, div_le_iff₀ hK]
  calc (∫ c in (0:ℝ)..K, h c) ≤ K * h K := integral_le_endpoint h K hK.le hcont hmono
  _ = h K * K := by ring

/-- The paper's hypothesis is monotonicity, which implies the pointwise bound `hbar_le` needs.
Stated so that the chain from "nondecreasing hazard" to the sign is machine-checked end to end
rather than left as an evident step. -/
theorem hbar_le_of_monotone (h : ℝ → ℝ) (K : ℝ) (hK : 0 < K) (hcont : Continuous h)
    (hmono : Monotone h) : hbar h K ≤ h K :=
  hbar_le h K hK hcont (fun _ hx => hmono hx.2)

/-- R2's bracket is nonnegative for a nondecreasing hazard. -/
theorem r2_lev_bracket_nonneg (h : ℝ → ℝ) (K : ℝ) (hK : 0 < K) (hcont : Continuous h)
    (hmono : ∀ x ∈ Icc (0:ℝ) K, h x ≤ h K) : 0 ≤ h K - hbar h K :=
  sub_nonneg.mpr (hbar_le h K hK hcont hmono)

/-! ## R3: the defence clock -/

/-- **R3, level-set, the paper's form.**
`s·C_M′ = τ_M[h_M(K_M) − h̄_M] + s·t_D′[h_M(K_M) − h_M^post]`. -/
theorem r3_lev_scaled (A hK K s P tD' : ℝ) (hs : s ≠ 0) (hKne : K ≠ 0) :
    s * (-(s ^ 2)⁻¹ * A + hK * (tD' + K / s ^ 2) + P * -tD')
      = (K / s) * (hK - A / K) + s * tD' * (hK - P) := by
  field_simp
  ring

/-- **R3, level-set, the paper's form with the ramp average substituted.** -/
theorem r3_lev_paper_form (h : ℝ → ℝ) (K s P tD' : ℝ) (hs : s ≠ 0) (hK : K ≠ 0) :
    s * (-(s ^ 2)⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (tD' + K / s ^ 2) + P * -tD')
      = (K / s) * (h K - hbar h K) + s * tD' * (h K - P) := by
  rw [hbar]; field_simp; ring

/-- **The defence-distance derivative, level-set.**  `∂C_M/∂t_D = h_M(K_M) − h_M^post`, so with
`t_D = χ_D K_D/s + m_D T_D` the `K_D` derivative is `(χ_D/s)(h_M(K_M) − h_M^post)`.  The plateau
level is the only thing the specification changes here, which is why the `K_D` result takes one
form across both specifications. -/
theorem dtD_lev (h : ℝ → ℝ) (K L s tD P : ℝ) (hcont : Continuous h) (hs : 0 < s) (hK : 0 ≤ K)
    (hD : K / s < tD) (hL : tD < L) :
    HasDerivAt (fun u : ℝ => CLev h K L s u P) (h K - P) tD := by
  have heq : ∀ᶠ u in nhds tD, CLev h K L s u P
      = s⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (u - K / s) + P * (L - u) := by
    have h1 : ∀ᶠ u in nhds tD, K / s < u :=
      (isOpen_Ioi.eventually_mem hD).mono (fun x hx => hx)
    have h2 : ∀ᶠ u in nhds tD, u < L :=
      (isOpen_Iio.eventually_mem hL).mono (fun x hx => hx)
    filter_upwards [h1, h2] with u hu1 hu2
    exact CLev_eq h K L s u P hcont hs hK hu1.le hu2.le
  have hd : HasDerivAt
      (fun u : ℝ => s⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (u - K / s) + P * (L - u))
      (h K - P) tD := by
    have ha : HasDerivAt (fun u : ℝ => h K * (u - K / s)) (h K) tD := by
      simpa using ((hasDerivAt_id tD).sub_const (K / s)).const_mul (h K)
    have hb : HasDerivAt (fun u : ℝ => P * (L - u)) (-P) tD := by
      simpa using ((hasDerivAt_id tD).const_sub L).const_mul P
    have := ((hasDerivAt_const tD (s⁻¹ * ∫ c in (0:ℝ)..K, h c)).add ha).add hb
    convert this using 1
    ring
  exact hd.congr_of_eventuallyEq heq

/-! ## The misuse-distance derivatives: the boundary terms, and whether they cancel -/

/-- **Convention B, ramp-on (A4a.7(ii)): the cancellation.**  Differentiating in `K_M` moves the
boundary between ramp and plateau.  The ramp integral's upper limit contributes `+h_M(K_M)/s`
and the shrinking plateau contributes `−h_M(K_M)/s`; the two cancel, leaving
`∂C_M/∂K_M = (t_D − τ_M)h_M′(K_M)` with no level term at all.

That cancellation is the whole content of the result, and it is why a nondecreasing hazard makes
a cut to `K_M` weakly beneficial under ramp-on exposure. -/
theorem dKM_B_rampon (h : ℝ → ℝ) (K s tD P L hK' : ℝ) (hcont : Continuous h) (hs : 0 < s)
    (hderiv : HasDerivAt h hK' K) :
    HasDerivAt (fun x : ℝ => s⁻¹ * (∫ c in (0:ℝ)..x, h c) + h x * (tD - x / s) + P * (L - tD))
      (hK' * (tD - K / s)) K := by
  have hFTC : HasDerivAt (fun u : ℝ => ∫ c in (0:ℝ)..u, h c) (h K) K :=
    integral_hasDerivAt_right (hcont.intervalIntegrable _ _)
      hcont.aestronglyMeasurable.stronglyMeasurableAtFilter hcont.continuousAt
  have hramp : HasDerivAt (fun x : ℝ => s⁻¹ * ∫ c in (0:ℝ)..x, h c) (s⁻¹ * h K) K :=
    hFTC.const_mul s⁻¹
  have hplat : HasDerivAt (fun x : ℝ => h x * (tD - x / s))
      (hK' * (tD - K / s) + h K * -s⁻¹) K := by
    have hlin : HasDerivAt (fun x : ℝ => tD - x / s) (-s⁻¹) K := by
      have := ((hasDerivAt_id K).div_const s).const_sub tD
      simpa using this
    exact hderiv.mul hlin
  have h0 : HasDerivAt (fun _ : ℝ => P * (L - tD)) 0 K := hasDerivAt_const K _
  have := ((hramp.add hplat).add h0)
  convert this using 1
  field_simp
  ring

/-- **Convention B, arrival-on (A4a.7(iii)): no cancellation.**  With no ramp there is no
boundary term to cancel the plateau's, so `∂C_M/∂K_M = (t_D − τ_M)h_M′(K_M) − h_M(K_M)/s`, which
monotonicity alone does not sign.  The contrast with `dKM_B_rampon` is exactly the missing ramp
term. -/
theorem dKM_B_arrivalon (h : ℝ → ℝ) (K s tD P L hK' : ℝ) (hs : 0 < s)
    (hderiv : HasDerivAt h hK' K) :
    HasDerivAt (fun x : ℝ => h x * (tD - x / s) + P * (L - tD))
      (hK' * (tD - K / s) - h K / s) K := by
  have hlin : HasDerivAt (fun x : ℝ => tD - x / s) (-s⁻¹) K := by
    have := ((hasDerivAt_id K).div_const s).const_sub tD
    simpa using this
  have hplat : HasDerivAt (fun x : ℝ => h x * (tD - x / s))
      (hK' * (tD - K / s) + h K * -s⁻¹) K := hderiv.mul hlin
  have h0 : HasDerivAt (fun _ : ℝ => P * (L - tD)) 0 K := hasDerivAt_const K _
  have := hplat.add h0
  convert this using 1
  field_simp
  ring

/-- **Convention A, ramp-on (A4a.7(ii)).**  Under the shape-preserving profile the plateau
hazard `ĥ 1` does not move with `K_M`, and the ramp integral is linear in `K_M`, so
`∂C_M/∂K_M = −[ĥ 1 − h̄]/s` with `h̄ = ∫_0^1 ĥ`.  Shortening `K_M` *raises* misuse loss whenever
the terminal hazard exceeds its ramp average — the opposite sign to convention B. -/
theorem dKM_A_rampon (ĥ : ℝ → ℝ) (K s tD P L : ℝ) (hs : 0 < s) :
    HasDerivAt
      (fun x : ℝ => s⁻¹ * (x * ∫ u in (0:ℝ)..1, ĥ u) + ĥ 1 * (tD - x / s) + P * (L - tD))
      (-((ĥ 1 - ∫ u in (0:ℝ)..1, ĥ u) / s)) K := by
  have h1 : HasDerivAt (fun x : ℝ => s⁻¹ * (x * ∫ u in (0:ℝ)..1, ĥ u))
      (s⁻¹ * ∫ u in (0:ℝ)..1, ĥ u) K := by
    have := ((hasDerivAt_id K).mul_const (∫ u in (0:ℝ)..1, ĥ u)).const_mul s⁻¹
    simpa using this
  have h2 : HasDerivAt (fun x : ℝ => ĥ 1 * (tD - x / s)) (ĥ 1 * -s⁻¹) K := by
    have hlin : HasDerivAt (fun x : ℝ => tD - x / s) (-s⁻¹) K := by
      have := ((hasDerivAt_id K).div_const s).const_sub tD
      simpa using this
    exact hlin.const_mul (ĥ 1)
  have h0 : HasDerivAt (fun _ : ℝ => P * (L - tD)) 0 K := hasDerivAt_const K _
  have := (h1.add h2).add h0
  convert this using 1
  field_simp
  ring

/-- **Convention A, arrival-on (A4a.7(iii)).**  With no ramp, `∂C_M/∂K_M = −ĥ 1 / s`, negative
iff `ĥ 1 > 0`.  This uses no property of `ĥ` beyond `ĥ 1` being defined, which is what the
appendix says of it. -/
theorem dKM_A_arrivalon (ĥ : ℝ → ℝ) (K s tD P L : ℝ) (hs : 0 < s) :
    HasDerivAt (fun x : ℝ => ĥ 1 * (tD - x / s) + P * (L - tD)) (-(ĥ 1 / s)) K := by
  have hlin : HasDerivAt (fun x : ℝ => tD - x / s) (-s⁻¹) K := by
    have := ((hasDerivAt_id K).div_const s).const_sub tD
    simpa using this
  have h2 : HasDerivAt (fun x : ℝ => ĥ 1 * (tD - x / s)) (ĥ 1 * -s⁻¹) K := hlin.const_mul (ĥ 1)
  have h0 : HasDerivAt (fun _ : ℝ => P * (L - tD)) 0 K := hasDerivAt_const K _
  have := h2.add h0
  convert this using 1
  field_simp
  ring

/-- **The sign flip between the conventions.**  Under ramp-on, with a strictly increasing hazard
and a terminal value above its ramp average, convention B's `K_M` derivative is positive and
convention A's is negative.  One hazard, two conventions, opposite signs — the paper's §4a.5
claim, and the contrast that explains why the `K_D` derivative is *not* convention-dependent
while this one is. -/
theorem dKM_conventions_differ (ĥ : ℝ → ℝ) (K s tD hK' : ℝ) (hs : 0 < s)
    (hgap : (∫ u in (0:ℝ)..1, ĥ u) < ĥ 1) (hpos : 0 < hK') (hwin : K / s < tD) :
    0 < hK' * (tD - K / s) ∧ -((ĥ 1 - ∫ u in (0:ℝ)..1, ĥ u) / s) < 0 := by
  refine ⟨mul_pos hpos (sub_pos.mpr hwin), ?_⟩
  have : 0 < (ĥ 1 - ∫ u in (0:ℝ)..1, ĥ u) / s := div_pos (sub_pos.mpr hgap) hs
  linarith

/-! ## Group 2, items 9 to 12: the facility conditions and the before-arrival case -/

/-- **Item 9, arrival-on: the weight.**  Multiplying convention B's arrival-on `K_M` derivative
by `−s` gives the weight the facility inequality puts on a cut to `K_M`,
`h_M(K_M) − s(t_D − τ_M)h_M′(K_M)` — the quantity the appendix says is negative exactly when the
level-elasticity condition holds. -/
theorem facility_B_arrivalon_weight (hKv hK' s tD τ : ℝ) (hs : s ≠ 0) :
    s * -(hK' * (tD - τ) - hKv / s) = hKv - s * (tD - τ) * hK' := by
  field_simp; ring

/-- **Item 9, ramp-on: the inequality.**  To first order the two cuts combine, and misuse loss
falls exactly when the defence term beats the misuse term.  This is the sign rearrangement; the
two partials it is stated about are `dKM_B_rampon` and `dtD_lev`. -/
theorem facility_B_rampon_iff (hKv P hK' s tD τ ΔKD ΔKM chi : ℝ) (hs : 0 < s) :
    (hK' * (tD - τ) * ΔKM + (chi / s) * (hKv - P) * ΔKD < 0)
      ↔ 0 < chi * (hKv - P) * (-ΔKD) + s * (hK' * (tD - τ)) * (-ΔKM) := by
  have key : ∀ a : ℝ, a < 0 ↔ s * a < 0 := by
    intro a
    refine ⟨fun h => mul_neg_of_pos_of_neg hs h, fun h => ?_⟩
    nlinarith [h, hs]
  rw [key]
  have hexp : s * (hK' * (tD - τ) * ΔKM + (chi / s) * (hKv - P) * ΔKD)
      = s * (hK' * (tD - τ)) * ΔKM + chi * (hKv - P) * ΔKD := by
    field_simp
  rw [hexp]
  constructor
  · intro h; linarith
  · intro h; linarith

/-- **Item 12, the arrival-on slope under convention A.**  The boundary of the region in which a
facility lowers misuse loss has slope `h/(h − P)` — the ratio of the two partials, with
convention A's `−h/s` on the misuse distance and `(χ_D/s)(h − P)` on the defence distance at
`χ_D = 1`.  It exceeds 1 whenever the residual is positive, and equals 1 at complete closure. -/
theorem facility_A_arrivalon_slope (hKv P s : ℝ) (hs : 0 < s) (hgap : P < hKv) :
    (hKv / s) / ((1:ℝ) / s * (hKv - P)) = hKv / (hKv - P) := by
  have hne : hKv - P ≠ 0 := sub_ne_zero.mpr (ne_of_gt hgap)
  field_simp

/-- **Item 12, affine under convention A.**  Within one regime the level-set loss under
convention A is affine in the misuse distance and the deployment date jointly, which is why the
facility conditions hold for finite moves and not only marginal ones. -/
theorem CLev_A_affine (ĥ : ℝ → ℝ) (K L s tD P : ℝ) :
    s⁻¹ * (K * ∫ u in (0:ℝ)..1, ĥ u) + ĥ 1 * (tD - K / s) + P * (L - tD)
      = ((∫ u in (0:ℝ)..1, ĥ u) - ĥ 1) / s * K + (ĥ 1 - P) * tD + P * L := by
  field_simp
  ring

/-- Loss when the countermeasure completes **before** the capability is reached: the hazard is
still climbing at `t_D`, then drops to the residual. -/
noncomputable def CBefore (h : ℝ → ℝ) (K L s tD P : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, (if t < tD then h (min (s * t) K) else P)

/-- **Item 10, convention B.**  With the defence completing before the capability, the misuse
distance has dropped out of the loss entirely: on the counted window neither the integrand nor
any limit mentions `K_M`.  So the `K_M` derivative is **zero**, and nothing about `h_M` is used.

The proof is the paper's own argument: the loss equals a `K_M`-free expression on a whole
neighbourhood of `K_M`, because `t_D < K_M/s` is an open condition. -/
theorem dKM_B_before (h : ℝ → ℝ) (K L s tD P : ℝ) (hcont : Continuous h) (hs : 0 < s)
    (htD : 0 ≤ tD) (hlt : tD < K / s) (hL : tD ≤ L) :
    HasDerivAt (fun x : ℝ => CBefore h x L s tD P) 0 K := by
  have key : ∀ x : ℝ, tD < x / s →
      CBefore h x L s tD P = (∫ t in (0:ℝ)..tD, h (s * t)) + P * (L - tD) := by
    intro x hx
    have hcc : Continuous (fun t : ℝ => h (min (s * t) x)) :=
      hcont.comp ((continuous_const.mul continuous_id).min continuous_const)
    have hi1 : IntervalIntegrable (fun t : ℝ => if t < tD then h (min (s * t) x) else P)
        volume 0 tD := by
      rw [intervalIntegrable_congr_uIoo (g := fun t : ℝ => h (min (s * t) x)) ?_]
      · exact hcc.intervalIntegrable _ _
      · intro u hu; rw [uIoo_of_le htD] at hu; simp [hu.2]
    have hi2 : IntervalIntegrable (fun t : ℝ => if t < tD then h (min (s * t) x) else P)
        volume tD L := by
      rw [intervalIntegrable_congr_uIoo (g := fun _ : ℝ => P) ?_]
      · exact intervalIntegrable_const
      · intro u hu; rw [uIoo_of_le hL] at hu; simp [not_lt.mpr hu.1.le]
    have e1 : (∫ t in (0:ℝ)..tD, (if t < tD then h (min (s * t) x) else P))
        = ∫ t in (0:ℝ)..tD, h (s * t) := by
      rw [integral_congr_Ioo_of_le htD (g := fun t : ℝ => h (s * t)) ?_]
      intro u hu
      have hsu : s * u ≤ x := by
        have h1 : u ≤ x / s := le_of_lt (lt_trans hu.2 hx)
        calc s * u ≤ s * (x / s) := mul_le_mul_of_nonneg_left h1 hs.le
        _ = x := mul_div_cancel₀ x hs.ne'
      simp [hu.2, min_eq_left hsu]
    have e2 : (∫ t in tD..L, (if t < tD then h (min (s * t) x) else P)) = P * (L - tD) := by
      rw [integral_congr_Ioo_of_le hL (g := fun _ : ℝ => P) ?_,
        intervalIntegral.integral_const, smul_eq_mul]
      · ring
      · intro u hu; simp [not_lt.mpr hu.1.le]
    rw [CBefore, ← integral_add_adjacent_intervals hi1 hi2, e1, e2]
  have heq : ∀ᶠ x in nhds K, CBefore h x L s tD P
      = (∫ t in (0:ℝ)..tD, h (s * t)) + P * (L - tD) := by
    have hcd : ContinuousAt (fun x : ℝ => x / s) K := continuousAt_id.div continuousAt_const hs.ne'
    have hopen : ∀ᶠ x in nhds K, tD < x / s :=
      hcd.eventually ((isOpen_Ioi.eventually_mem hlt).mono (fun y hy => hy))
    filter_upwards [hopen] with x hx
    exact key x hx
  exact (hasDerivAt_const K _).congr_of_eventuallyEq heq

/-- Convention A's before-arrival loss, written with the compressed profile `ĥ(c/K)`. -/
noncomputable def CBeforeA (ĥ : ℝ → ℝ) (K L s tD P : ℝ) : ℝ :=
  (K / s) * (∫ u in (0:ℝ)..(s * tD / K), ĥ u) + P * (L - tD)

/-- **Item 11, convention A, the derivative.**  Unlike B, convention A's profile *does* move with
`K_M`, so the misuse distance does not drop out:

`∂C_M/∂K_M = −(1/s)[x_d ĥ_M(x_d) − ∫_0^{x_d} ĥ_M]`,  `x_d = s t_D/K_M`.

This is the inventory's item 11, the one result there that no model-check seat derived — the
numerical check derived and matched it. It is now machine-checked. -/
theorem dKM_A_before (ĥ : ℝ → ℝ) (K L s tD P : ℝ) (hcont : Continuous ĥ) (hs : 0 < s)
    (hK : 0 < K) :
    HasDerivAt (fun x : ℝ => CBeforeA ĥ x L s tD P)
      (-((s * tD / K) * ĥ (s * tD / K) - ∫ u in (0:ℝ)..(s * tD / K), ĥ u) / s) K := by
  have hFTC : HasDerivAt (fun y : ℝ => ∫ u in (0:ℝ)..y, ĥ u) (ĥ (s * tD / K)) (s * tD / K) :=
    integral_hasDerivAt_right (hcont.intervalIntegrable _ _)
      hcont.aestronglyMeasurable.stronglyMeasurableAtFilter hcont.continuousAt
  have hxd : HasDerivAt (fun x : ℝ => s * tD / x) (-(s * tD / K ^ 2)) K := by
    have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(K ^ 2)⁻¹) K := hasDerivAt_inv hK.ne'
    have hh := hinv.const_mul (s * tD)
    simp only [div_eq_mul_inv] at *
    convert hh using 1
    field_simp
  have hcomp : HasDerivAt ((fun y : ℝ => ∫ u in (0:ℝ)..y, ĥ u) ∘ fun x : ℝ => s * tD / x)
      (ĥ (s * tD / K) * -(s * tD / K ^ 2)) K := hFTC.comp K hxd
  have hH : HasDerivAt (fun x : ℝ => ∫ u in (0:ℝ)..(s * tD / x), ĥ u)
      (ĥ (s * tD / K) * -(s * tD / K ^ 2)) K := hcomp
  have hlin : HasDerivAt (fun x : ℝ => x / s) s⁻¹ K := by
    simpa using (hasDerivAt_id K).div_const s
  have hP : HasDerivAt (fun _ : ℝ => P * (L - tD)) 0 K := hasDerivAt_const K _
  show HasDerivAt
    (fun x : ℝ => x / s * (∫ u in (0:ℝ)..(s * tD / x), ĥ u) + P * (L - tD)) _ K
  have h := (hlin.mul hH).add hP
  convert h using 1
  field_simp [hs.ne', hK.ne']
  ring

/-- Convention A's before-arrival loss as an **integral** of the hazard. -/
noncomputable def CBeforeAInt (ĥ : ℝ → ℝ) (K L s tD P : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, (if t < tD then ĥ (min (s * t) K / K) else P)

/-- **Item 11, the translation step.**  The integral equals convention A's closed form.  This is
where the appendix's condition `t_D < L` actually bites: the closed form is differentiable in
`K_M` whatever `L` does, but it is only *the loss* while the ramp lies inside the counted window,
which is what the appendix's counterexample without `t_D < L` shows. -/
theorem CBeforeAInt_eq (ĥ : ℝ → ℝ) (K L s tD P : ℝ) (hcont : Continuous ĥ) (hs : 0 < s)
    (hK : 0 < K) (htD : 0 ≤ tD) (hlt : tD < K / s) (hL : tD ≤ L) :
    CBeforeAInt ĥ K L s tD P = (K / s) * (∫ u in (0:ℝ)..(s * tD / K), ĥ u) + P * (L - tD) := by
  have hsK : s / K ≠ 0 := div_ne_zero hs.ne' hK.ne'
  have hcc : Continuous (fun t : ℝ => ĥ (s / K * t)) :=
    hcont.comp (continuous_const.mul continuous_id)
  have hi1 : IntervalIntegrable (fun t : ℝ => if t < tD then ĥ (min (s * t) K / K) else P)
      volume 0 tD := by
    rw [intervalIntegrable_congr_uIoo (g := fun t : ℝ => ĥ (s / K * t)) ?_]
    · exact hcc.intervalIntegrable _ _
    · intro u hu
      rw [uIoo_of_le htD] at hu
      have hsu : s * u ≤ K := by
        have h1 : u ≤ K / s := le_of_lt (lt_trans hu.2 hlt)
        calc s * u ≤ s * (K / s) := mul_le_mul_of_nonneg_left h1 hs.le
        _ = K := mul_div_cancel₀ K hs.ne'
      simp only [hu.2, ite_true, min_eq_left hsu]
      congr 1
      ring
  have hi2 : IntervalIntegrable (fun t : ℝ => if t < tD then ĥ (min (s * t) K / K) else P)
      volume tD L := by
    rw [intervalIntegrable_congr_uIoo (g := fun _ : ℝ => P) ?_]
    · exact intervalIntegrable_const
    · intro u hu; rw [uIoo_of_le hL] at hu; simp [not_lt.mpr hu.1.le]
  have e1 : (∫ t in (0:ℝ)..tD, (if t < tD then ĥ (min (s * t) K / K) else P))
      = (K / s) * ∫ u in (0:ℝ)..(s * tD / K), ĥ u := by
    rw [integral_congr_Ioo_of_le htD (g := fun t : ℝ => ĥ (s / K * t)) ?_]
    · rw [integral_comp_mul_left (f := ĥ) hsK, smul_eq_mul, mul_zero, inv_div,
        div_mul_eq_mul_div, mul_comm s tD]
      ring_nf
    · intro u hu
      have hsu : s * u ≤ K := by
        have h1 : u ≤ K / s := le_of_lt (lt_trans hu.2 hlt)
        calc s * u ≤ s * (K / s) := mul_le_mul_of_nonneg_left h1 hs.le
        _ = K := mul_div_cancel₀ K hs.ne'
      simp only [hu.2, ite_true, min_eq_left hsu]
      congr 1
      ring
  have e2 : (∫ t in tD..L, (if t < tD then ĥ (min (s * t) K / K) else P)) = P * (L - tD) := by
    rw [integral_congr_Ioo_of_le hL (g := fun _ : ℝ => P) ?_,
      intervalIntegral.integral_const, smul_eq_mul]
    · ring
    · intro u hu; simp [not_lt.mpr hu.1.le]
  rw [CBeforeAInt, ← integral_add_adjacent_intervals hi1 hi2, e1, e2]

/-- **Item 11, the derivative of the loss itself**, not of a closed form taken on trust. -/
theorem dKM_A_before_int (ĥ : ℝ → ℝ) (K L s tD P : ℝ) (hcont : Continuous ĥ) (hs : 0 < s)
    (hK : 0 < K) (htD : 0 ≤ tD) (hlt : tD < K / s) (hL : tD ≤ L) :
    HasDerivAt (fun x : ℝ => CBeforeAInt ĥ x L s tD P)
      (-((s * tD / K) * ĥ (s * tD / K) - ∫ u in (0:ℝ)..(s * tD / K), ĥ u) / s) K := by
  have heq : ∀ᶠ x in nhds K, CBeforeAInt ĥ x L s tD P = CBeforeA ĥ x L s tD P := by
    have hcd : ContinuousAt (fun x : ℝ => x / s) K :=
      continuousAt_id.div continuousAt_const hs.ne'
    have hopen : ∀ᶠ x in nhds K, tD < x / s :=
      hcd.eventually ((isOpen_Ioi.eventually_mem hlt).mono (fun y hy => hy))
    have hposx : ∀ᶠ x in nhds K, (0:ℝ) < x :=
      (isOpen_Ioi.eventually_mem hK).mono (fun y hy => hy)
    filter_upwards [hopen, hposx] with x hx hx0
    exact CBeforeAInt_eq ĥ x L s tD P hcont hs hx0 htD hx hL
  exact (dKM_A_before ĥ K L s tD P hcont hs hK).congr_of_eventuallyEq heq

/-- **Item 11, the sign.**  Under convention A the before-arrival derivative is `≤ 0` for a
nondecreasing profile, because `x ĥ(x) − ∫_0^x ĥ = ∫_0^x [ĥ(x) − ĥ(u)] du ≥ 0`.  The compressed
profile reaches higher hazard levels before `t_D`, which is the paper's reading of it. -/
theorem dKM_A_before_nonpos (ĥ : ℝ → ℝ) (s xd : ℝ) (hs : 0 < s) (hxd : 0 ≤ xd)
    (hcont : Continuous ĥ) (hmono : ∀ u ∈ Icc (0:ℝ) xd, ĥ u ≤ ĥ xd) :
    -((xd * ĥ xd - ∫ u in (0:ℝ)..xd, ĥ u) / s) ≤ 0 := by
  have hgap : 0 ≤ xd * ĥ xd - ∫ u in (0:ℝ)..xd, ĥ u :=
    sub_nonneg.mpr (integral_le_endpoint ĥ xd hxd hcont hmono)
  have : 0 ≤ (xd * ĥ xd - ∫ u in (0:ℝ)..xd, ĥ u) / s := by positivity
  linarith

end BioPaper
