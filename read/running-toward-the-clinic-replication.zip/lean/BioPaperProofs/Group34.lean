import BioPaperProofs.LevelSet

/-!
# Groups 3 and 4 of `../PROOF-INVENTORY.md`

The last four numbered results.

* **Group 3, the responsive residual.** Item 13: a residual that responds to speed adds
  `(L − t_D)s·h_M^post′` to every speed-set derivative. Item 14: the level-set counterpart adds
  `(L − t_D)s²h_M^post′` to the right side of R3's inequality.
* **Group 4, two singletons.** Item 15: the benefit margin's logarithmic rate derivative,
  `−t_B + ℓ_B/(e^{rℓ_B} − 1)`, positive exactly on `r < log(1 + ℓ_B/t_B)/ℓ_B`. Item 16: the
  separable mixed hazard `Λ_M(s)g_M(min(st, K_M))`, its closed form, its scaled derivative and
  the exposure-response threshold `ε̄_g`.

## It is an interior term, not a boundary term

The inventory's own wording for item 13 — "the Leibniz term from a moving boundary" — is the
description the paper's S.7 records as a **mislabel**. The residual's response to speed is the
derivative of the *integrand* on `[t_D, L]`, with both limits held fixed; `(L − t_D)` is the
length of that interval, not a boundary that moves. `r3_resp_hasDerivAt` below is stated so the
distinction is visible: the term arrives from differentiating `P` inside, while `s·t_D′(Λ_M − P)`
is the one that comes from a moving boundary.

## Translation note

1. **Item 15's constant.** The margin is written `C * exp (-t_B * r) * (1 - exp (-ℓ_B * r))`,
   with `C` standing for the paper's `p·y·q·χ_B`. Nothing in the result depends on how `C`
   decomposes, and the sign statements take `0 < C`, which the paper's conditions (`p > 0`,
   `χ_B = 1`) supply. Writing the exponent coefficient first is a Lean convenience; the number
   is the paper's `e^{−rt_B}`.
2. **Item 16's hazard** is `Λ_M(s)·g_M(c(t))` with `c(t) = min(st, K_M)` and complete closure at
   `t_D`, which is `levHaz g K s t_D 0` scaled by `Λ_M(s)`. The closed form therefore reuses
   `CLev_eq` from `LevelSet.lean` rather than redoing the split.
3. **Items 14 and 16's thresholds** are rearrangements of a sign condition, as in Group 1's items
   5 and 6; the marginals they are stated about are the ones proved of the integral here.
-/

open MeasureTheory intervalIntegral Set Real

namespace BioPaper

/-! ## Item 13: the responsive residual, speed-set -/

/-- Speed-set arrival-on loss with closure at `TD s` to a residual `P s` that itself responds to
speed, **defined as the integral**. -/
noncomputable def CResp (Λ P TD : ℝ → ℝ) (K L s : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, step2 0 (Λ s) (P s) (K / s) (TD s) t

/-- The closed form, from `integral_step2`. -/
theorem CResp_eq (Λ P TD : ℝ → ℝ) (K L s : ℝ) (hτ : 0 ≤ K / s) (hD : K / s ≤ TD s)
    (hL : TD s ≤ L) : CResp Λ P TD K L s = Λ s * (TD s - K / s) + P s * (L - TD s) := by
  rw [CResp, integral_step2 0 (Λ s) (P s) 0 (K / s) (TD s) L hτ hD hL]; ring

/-- The closed form on a neighbourhood, so that it can be differentiated. -/
theorem CResp_eventuallyEq (Λ P TD : ℝ → ℝ) (K L s₀ : ℝ) (hK : 0 ≤ K) (hs : 0 < s₀)
    (hTDc : ContinuousAt TD s₀) (harr : K / s₀ < TD s₀) (hhor : TD s₀ < L) :
    ∀ᶠ s in nhds s₀, CResp Λ P TD K L s = Λ s * (TD s - K / s) + P s * (L - TD s) := by
  have hpos : ∀ᶠ s in nhds s₀, (0:ℝ) < s :=
    (isOpen_Ioi.eventually_mem hs).mono (fun x hx => hx)
  have hcont : ContinuousAt (fun x : ℝ => K / x) s₀ :=
    continuousAt_const.div continuousAt_id hs.ne'
  have hgap : ∀ᶠ s in nhds s₀, (0:ℝ) < TD s - K / s :=
    (hTDc.sub hcont).eventually
      ((isOpen_Ioi.eventually_mem (sub_pos.mpr harr)).mono (fun x hx => hx))
  have hlt : ∀ᶠ s in nhds s₀, TD s < L :=
    hTDc.eventually ((isOpen_Iio.eventually_mem hhor).mono (fun x hx => hx))
  filter_upwards [hpos, hgap, hlt] with s hs0 hg hL'
  exact CResp_eq Λ P TD K L s (by positivity) (by linarith) hL'.le

/-- **Item 13, the derivative.**  Four terms: the hazard's own response, the window's response to
the arrival date, **the residual's response inside the interval** `P′(L − t_D)`, and the moving
deployment boundary `−P·t_D′`.  The third is the one item 13 is about, and it comes from
differentiating the integrand, not from moving a limit. -/
theorem r3_resp_hasDerivAt (Λ P TD : ℝ → ℝ) (K L s lam' p' tD' : ℝ) (hK : 0 ≤ K) (hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s) (hP : HasDerivAt P p' s) (hTD : HasDerivAt TD tD' s)
    (harr : K / s < TD s) (hhor : TD s < L) :
    HasDerivAt (fun x : ℝ => CResp Λ P TD K L x)
      (lam' * (TD s - K / s) + Λ s * (tD' + K / s ^ 2)
        + (p' * (L - TD s) + P s * -tD')) s := by
  have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs.ne'
  have hwindow : HasDerivAt (fun x : ℝ => TD x - K / x) (tD' + K / s ^ 2) s := by
    have hKx : HasDerivAt (fun x : ℝ => K / x) (-(K / s ^ 2)) s := by
      have hh := hinv.const_mul K
      simp only [div_eq_mul_inv] at *
      convert hh using 1
      field_simp
    convert hTD.sub hKx using 1
    ring
  have hres : HasDerivAt (fun x : ℝ => P x * (L - TD x)) (p' * (L - TD s) + P s * -tD') s :=
    hP.mul (hTD.const_sub L)
  exact ((hΛ.mul hwindow).add hres).congr_of_eventuallyEq
    (CResp_eventuallyEq Λ P TD K L s hK hs hTD.continuousAt harr hhor)

/-- **Item 13, the paper's form.**  Scaling by `s`, the responsive residual contributes exactly
`(L − t_D)s·h_M^post′` on top of the fixed-residual test — which is the appendix's A4a.4(v). -/
theorem r3_resp_scaled (Lam Pv lam' p' s K L tD tD' : ℝ) (hs : s ≠ 0) :
    s * (lam' * (tD - K / s) + Lam * (tD' + K / s ^ 2) + (p' * (L - tD) + Pv * -tD'))
      = (s * lam' * (tD - K / s) + Lam * (K / s)) + s * tD' * (Lam - Pv)
        + (L - tD) * s * p' := by
  field_simp
  ring

/-! ## Item 14: the level-set counterpart -/

/-- **Item 14.**  Under level-set on the capability branch, where `s·t_D′ = −K_D/s`, acceleration
lowers misuse loss exactly when

`K_D[h_M(K_M) − h_M^post] > K_M[h_M(K_M) − h̄_M] + (L − t_D)s²h_M^post′`,

so a responsive residual adds `(L − t_D)s²h_M^post′` to the right side of R3's inequality.  The
factor `s²` rather than `s` is the whole difference from item 13, and it is there because the
level-set test is already multiplied through by `s` to clear `τ_M = K_M/s`.

Multiplying a strict inequality by `s` is where `0 < s` is used; without it the rearrangement
fails, which is why the hypothesis is not decoration. -/
theorem r3_lev_resp_iff (hKv Pv p' hbarv K KD s L tD : ℝ) (hs : 0 < s) :
    ((K / s) * (hKv - hbarv) - (KD / s) * (hKv - Pv) + s * (L - tD) * p' < 0)
      ↔ K * (hKv - hbarv) + (L - tD) * s ^ 2 * p' < KD * (hKv - Pv) := by
  have key : ∀ a : ℝ, a < 0 ↔ s * a < 0 := by
    intro a
    refine ⟨fun ha => mul_neg_of_pos_of_neg hs ha, fun ha => ?_⟩
    nlinarith [ha, hs]
  rw [key]
  have hexp : s * ((K / s) * (hKv - hbarv) - (KD / s) * (hKv - Pv) + s * (L - tD) * p')
      = K * (hKv - hbarv) - KD * (hKv - Pv) + (L - tD) * s ^ 2 * p' := by
    field_simp
  rw [hexp]
  constructor
  · intro hlt; linarith
  · intro hgt; linarith

/-! ## Item 15: the benefit margin's logarithmic rate derivative -/

/-- `d/dx exp (c*x) = c * exp (c*x)`, in the argument form the margin below uses. -/
theorem hasDerivAt_exp_lin (c r : ℝ) :
    HasDerivAt (fun x : ℝ => exp (c * x)) (c * exp (c * r)) r := by
  have hinner : HasDerivAt (fun x : ℝ => c * x) c r := by
    simpa using (hasDerivAt_id r).const_mul c
  have h := hinner.exp
  convert h using 1
  ring

/-- The timing margin of a benefit of fixed duration `ℓ_B` arriving at `t_B`, counted in full:
the paper's `pyqχ_B e^{−rt_B}(1 − e^{−rℓ_B})`, with `C` for `pyqχ_B`. -/
noncomputable def benefitMargin (C tB lB r : ℝ) : ℝ :=
  C * exp (-tB * r) * (1 - exp (-lB * r))

/-- **The corollary of §4a.7: the undiscounted timing margin is exactly zero.**  Earlier arrival
moves the end of the benefit forward as well as its start, so with no discounting it buys
nothing.  This is why the paper states the benefit side discounted. -/
theorem benefitMargin_zero (C tB lB : ℝ) : benefitMargin C tB lB 0 = 0 := by
  simp [benefitMargin]

/-- The margin is differentiable in the rate, with the product-rule derivative. -/
theorem benefitMargin_hasDerivAt (C tB lB r : ℝ) :
    HasDerivAt (fun x : ℝ => benefitMargin C tB lB x)
      (C * (-tB * exp (-tB * r)) * (1 - exp (-lB * r))
        + C * exp (-tB * r) * (lB * exp (-lB * r))) r := by
  have h1 : HasDerivAt (fun x : ℝ => C * exp (-tB * x)) (C * (-tB * exp (-tB * r))) r :=
    (hasDerivAt_exp_lin (-tB) r).const_mul C
  have h2 : HasDerivAt (fun x : ℝ => 1 - exp (-lB * x)) (lB * exp (-lB * r)) r := by
    have := (hasDerivAt_exp_lin (-lB) r).const_sub 1
    convert this using 1
    ring
  show HasDerivAt (fun x : ℝ => C * exp (-tB * x) * (1 - exp (-lB * x))) _ r
  exact h1.mul h2

/-- **Item 15.**  The logarithmic rate derivative is `−t_B + ℓ_B/(e^{rℓ_B} − 1)`.  Stated on the
bracket, so that nothing is divided by a margin that could vanish. -/
theorem benefitMargin_logDeriv (tB lB r : ℝ) (hlB : 0 < lB) (hr : 0 < r) :
    (-tB * (1 - exp (-lB * r)) + lB * exp (-lB * r)) / (1 - exp (-lB * r))
      = -tB + lB / (exp (lB * r) - 1) := by
  have hpos : 0 < lB * r := mul_pos hlB hr
  have hu : 1 < exp (lB * r) := by
    have := exp_lt_exp.mpr hpos
    simpa using this
  have hinv : exp (-lB * r) = (exp (lB * r))⁻¹ := by
    rw [neg_mul, Real.exp_neg]
  have hne : exp (lB * r) - 1 ≠ 0 := sub_ne_zero.mpr (ne_of_gt hu)
  have hne2 : (1 : ℝ) - exp (-lB * r) ≠ 0 := by
    rw [hinv]
    have : (exp (lB * r))⁻¹ < 1 := inv_lt_one_of_one_lt₀ hu
    exact sub_ne_zero.mpr (ne_of_gt this)
  rw [hinv]
  have hexp : exp (lB * r) ≠ 0 := exp_ne_zero _
  field_simp

/-- The derivative **factorises through the margin**: `M′ = M·[−t_B + ℓ_B/(e^{rℓ_B} − 1)]`.
Without this the bracket above would merely resemble a logarithmic derivative; with it, it is
one, and item 15 is a statement about the margin rather than two halves a reader must join. -/
theorem benefitMargin_deriv_eq (C tB lB r : ℝ) (hlB : 0 < lB) (hr : 0 < r) :
    C * (-tB * exp (-tB * r)) * (1 - exp (-lB * r))
        + C * exp (-tB * r) * (lB * exp (-lB * r))
      = benefitMargin C tB lB r * (-tB + lB / (exp (lB * r) - 1)) := by
  have hpos : 0 < lB * r := mul_pos hlB hr
  have hu : 1 < exp (lB * r) := by
    have := exp_lt_exp.mpr hpos
    simpa using this
  have hinv : exp (-lB * r) = (exp (lB * r))⁻¹ := by rw [neg_mul, Real.exp_neg]
  -- generalised over `u = exp (lB*r)`, so that `field_simp` sees its nonzero hypotheses in
  -- exactly the form the goal contains; matching them through `exp` is what failed first
  have key : ∀ u : ℝ, u ≠ 0 → u - 1 ≠ 0 →
      C * (-tB * exp (-tB * r)) * (1 - u⁻¹) + C * exp (-tB * r) * (lB * u⁻¹)
        = C * exp (-tB * r) * (1 - u⁻¹) * (-tB + lB / (u - 1)) := by
    intro u h0 h1
    field_simp
  rw [benefitMargin, hinv]
  exact key (exp (lB * r)) (exp_ne_zero _) (sub_ne_zero.mpr (ne_of_gt hu))

/-- **Item 15, the interval.**  The logarithmic rate derivative is positive exactly on
`r < log(1 + ℓ_B/t_B)/ℓ_B`.  The paper's earlier drafts said "at small enough `r`"; this is the
interval, and S.7 records the strengthening. -/
theorem benefitMargin_logDeriv_pos_iff (tB lB r : ℝ) (htB : 0 < tB) (hlB : 0 < lB)
    (hr : 0 < r) :
    (0 < -tB + lB / (exp (lB * r) - 1)) ↔ r < log (1 + lB / tB) / lB := by
  have hpos : 0 < lB * r := mul_pos hlB hr
  have hu : 1 < exp (lB * r) := by
    have := exp_lt_exp.mpr hpos
    simpa using this
  have hden : 0 < exp (lB * r) - 1 := sub_pos.mpr hu
  have hone : 0 < 1 + lB / tB := by positivity
  calc (0 < -tB + lB / (exp (lB * r) - 1))
      ↔ tB * (exp (lB * r) - 1) < lB := by
        rw [← lt_div_iff₀ hden]
        constructor
        · intro hlt; linarith
        · intro hlt; linarith
    _ ↔ exp (lB * r) < 1 + lB / tB := by
        have hrw : (1 : ℝ) + lB / tB = (tB + lB) / tB := by field_simp
        rw [hrw, lt_div_iff₀ htB]
        constructor
        · intro hlt; nlinarith [hlt]
        · intro hlt; nlinarith [hlt]
    _ ↔ lB * r < log (1 + lB / tB) := (lt_log_iff_exp_lt hone).symm
    _ ↔ r < log (1 + lB / tB) / lB := by
        rw [lt_div_iff₀ hlB]
        constructor
        · intro hlt; linarith
        · intro hlt; linarith

/-! ## Item 16: the separable mixed form -/

/-- The separable mixed hazard: a speed component `Λ_M(s)` multiplying a level component
`g_M(c(t))`, with complete closure at `t_D`. -/
noncomputable def CMix (Λ g : ℝ → ℝ) (K L s tD : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, Λ s * levHaz g K s tD 0 t

/-- **Item 16, the closed form.**  `C_M = Λ_M[τ_Mḡ_M + (t_D − τ_M)g_M(K_M)]`, where
`τ_Mḡ_M = (1/s)∫_0^{K_M}g_M` is the capability ramp's contribution.  The split is `CLev_eq`'s,
reused: the mixed hazard is the level-set hazard scaled by `Λ_M(s)`, so no new integral
argument is needed. -/
theorem CMix_eq (Λ g : ℝ → ℝ) (K L s tD : ℝ) (hcont : Continuous g) (hs : 0 < s) (hK : 0 ≤ K)
    (hD : K / s ≤ tD) (hL : tD ≤ L) :
    CMix Λ g K L s tD = Λ s * (s⁻¹ * (∫ c in (0:ℝ)..K, g c) + g K * (tD - K / s)) := by
  rw [CMix, intervalIntegral.integral_const_mul]
  have := CLev_eq g K L s tD 0 hcont hs hK hD hL
  rw [CLev] at this
  rw [this]
  ring

/-- The mixed closed form on a neighbourhood, so that it can be differentiated. -/
theorem CMix_eventuallyEq (Λ g TD : ℝ → ℝ) (K L s₀ : ℝ) (hcont : Continuous g) (hK : 0 ≤ K)
    (hs : 0 < s₀) (hTDc : ContinuousAt TD s₀) (harr : K / s₀ < TD s₀) (hhor : TD s₀ < L) :
    ∀ᶠ s in nhds s₀, CMix Λ g K L s (TD s)
      = Λ s * (s⁻¹ * (∫ c in (0:ℝ)..K, g c) + g K * (TD s - K / s)) := by
  have hpos : ∀ᶠ s in nhds s₀, (0:ℝ) < s :=
    (isOpen_Ioi.eventually_mem hs).mono (fun x hx => hx)
  have hcd : ContinuousAt (fun x : ℝ => K / x) s₀ :=
    continuousAt_const.div continuousAt_id hs.ne'
  have hgap : ∀ᶠ s in nhds s₀, (0:ℝ) < TD s - K / s :=
    (hTDc.sub hcd).eventually
      ((isOpen_Ioi.eventually_mem (sub_pos.mpr harr)).mono (fun x hx => hx))
  have hlt : ∀ᶠ s in nhds s₀, TD s < L :=
    hTDc.eventually ((isOpen_Iio.eventually_mem hhor).mono (fun x hx => hx))
  filter_upwards [hpos, hgap, hlt] with s hs0 hg hL'
  exact CMix_eq Λ g K L s (TD s) hcont hs0 hK (by linarith) hL'.le

/-- **Item 16, the derivative of the loss itself.**  Proved of the integral, so that the scaled
form below is a statement about the mixed hazard's loss and not about an expression. -/
theorem CMix_hasDerivAt (Λ g TD : ℝ → ℝ) (K L s lam' tD' : ℝ) (hcont : Continuous g)
    (hK : 0 ≤ K) (hs : 0 < s) (hΛ : HasDerivAt Λ lam' s) (hTD : HasDerivAt TD tD' s)
    (harr : K / s < TD s) (hhor : TD s < L) :
    HasDerivAt (fun x : ℝ => CMix Λ g K L x (TD x))
      (lam' * (s⁻¹ * (∫ c in (0:ℝ)..K, g c) + g K * (TD s - K / s))
        + Λ s * (-(s ^ 2)⁻¹ * (∫ c in (0:ℝ)..K, g c)
          + g K * (tD' + K / s ^ 2))) s := by
  have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs.ne'
  have hKx : HasDerivAt (fun x : ℝ => K / x) (-(K / s ^ 2)) s := by
    have hh := hinv.const_mul K
    simp only [div_eq_mul_inv] at *
    convert hh using 1
    field_simp
  have hA : HasDerivAt (fun x : ℝ => x⁻¹ * ∫ c in (0:ℝ)..K, g c)
      (-(s ^ 2)⁻¹ * ∫ c in (0:ℝ)..K, g c) s := hinv.mul_const _
  have hwin : HasDerivAt (fun x : ℝ => g K * (TD x - K / x)) (g K * (tD' + K / s ^ 2)) s := by
    have hw : HasDerivAt (fun x : ℝ => TD x - K / x) (tD' + K / s ^ 2) s := by
      convert hTD.sub hKx using 1
      ring
    exact hw.const_mul (g K)
  exact (hΛ.mul (hA.add hwin)).congr_of_eventuallyEq
    (CMix_eventuallyEq Λ g TD K L s hcont hK hs hTD.continuousAt harr hhor)

/-- **Item 16, the scaled derivative.**  With `A = ∫_0^{K_M}g_M`, `ḡ_M = A/K_M` and
`g_K = g_M(K_M)`:

`s·C_M′ = Λ_M{ε_Λ[τ_Mḡ_M + (t_D − τ_M)g_K] + τ_M[g_K − ḡ_M] + s·t_D′·g_K}`.

The first brace term is the elasticity acting on the whole accumulated loss; the second is the
level component's own ramp-versus-plateau gap, which is the level-set mechanism surviving inside
the mixed form; the third is the clock. -/
theorem r_mix_scaled (Lam lam' A gK K s tD tD' : ℝ) (hs : s ≠ 0) (hK : K ≠ 0) :
    s * (lam' * (s⁻¹ * A + gK * (tD - K / s))
        + Lam * (-(s ^ 2)⁻¹ * A + gK * (tD' + K / s ^ 2)))
      = s * lam' * (s⁻¹ * A + gK * (tD - K / s))
        + Lam * ((K / s) * (gK - A / K) + s * tD' * gK) := by
  field_simp
  ring

/-- **Item 16, the threshold.**  On the `K_M`-paced capability branch, where `s·t_D′ = −τ_M`,
acceleration lowers misuse loss exactly when `ε_Λ` falls below

`ε̄_g = τ_Mḡ_M / [τ_Mḡ_M + (t_D − τ_M)g_M(K_M)]`,

the capability ramp's share of accumulated loss — hazard-weighted, not calendar-weighted.  The
hypotheses are that accumulated loss and the speed component are positive. -/
theorem epsBar_g_iff (Lam eps ramp plat : ℝ) (hLam : 0 < Lam) (htot : 0 < ramp + plat) :
    (Lam * (eps * (ramp + plat) - ramp) < 0) ↔ eps < ramp / (ramp + plat) := by
  rw [lt_div_iff₀ htot]
  constructor
  · intro hlt
    have hX : eps * (ramp + plat) - ramp < 0 := by
      by_contra hc
      push Not at hc
      nlinarith [mul_nonneg hLam.le hc]
    linarith
  · intro hlt
    exact mul_neg_of_pos_of_neg hLam (by linarith)

/-- **Item 16: when the hazard-weighted share equals the calendar share.**  The threshold `ε̄_g`
equals `α_D = τ_M/t_D` exactly when the level component's value at `K_M` equals its average along
the ramp, or when `t_D = τ_M`.  A constant level component is therefore sufficient but not
necessary, which is what §4a.6 says. -/
theorem epsBar_g_eq_calendar_iff (τ tD gbar gK : ℝ) (hτ : 0 < τ) :
    tD * (τ * gbar) = τ * (τ * gbar + (tD - τ) * gK)
      ↔ (tD - τ) * (gbar - gK) = 0 := by
  have key : tD * (τ * gbar) - τ * (τ * gbar + (tD - τ) * gK)
      = τ * ((tD - τ) * (gbar - gK)) := by ring
  constructor
  · intro h
    have h0 : τ * ((tD - τ) * (gbar - gK)) = 0 := by rw [← key]; linarith
    rcases mul_eq_zero.mp h0 with h1 | h1
    · exact absurd h1 hτ.ne'
    · exact h1
  · intro h
    have : tD * (τ * gbar) - τ * (τ * gbar + (tD - τ) * gK) = 0 := by
      rw [key, h, mul_zero]
    linarith

end BioPaper
