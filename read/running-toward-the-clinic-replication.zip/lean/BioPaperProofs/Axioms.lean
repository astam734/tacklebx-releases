import BioPaperProofs.Basic

/-!
Axiom audit.  Every theorem below must depend on nothing beyond Lean's three standard axioms
(`propext`, `Classical.choice`, `Quot.sound`), which every Mathlib proof uses.  A `sorryAx` in
this output means the result is NOT proved.
-/

-- the integral-to-closed-form machinery
#print axioms BioPaper.integral_step
#print axioms BioPaper.integral_step_before
#print axioms BioPaper.integral_step2
#print axioms BioPaper.intervalIntegrable_step

-- the translation step from the integral to Item1's closed form
#print axioms BioPaper.CArr_eq
#print axioms BioPaper.CArrClose_eq
#print axioms BioPaper.CArr_eventuallyEq
#print axioms BioPaper.CArrClose_eventuallyEq

-- Group 1, result 1: R2, the plateau
#print axioms BioPaper.r2_hasDerivAt
#print axioms BioPaper.r2_scaled
#print axioms BioPaper.r2_pos

-- Group 1, result 2: the same, discounted
#print axioms BioPaper.integral_exp_neg
#print axioms BioPaper.CArrDisc_eq
#print axioms BioPaper.CArrDisc_eventuallyEq
#print axioms BioPaper.r2_disc_hasDerivAt
#print axioms BioPaper.r2_disc_scaled
#print axioms BioPaper.r2_disc_pos

-- Group 1, result 3: R1, truncation
#print axioms BioPaper.CArr_eq_zero
#print axioms BioPaper.CArr_hasDerivAt_zero
#print axioms BioPaper.r2_scaled_at_kink

-- Group 1, result 4: R3, the defence clock
#print axioms BioPaper.r3_hasDerivAt
#print axioms BioPaper.r3_scaled

-- Group 1, result 5: the arrival-on threshold
#print axioms BioPaper.alphaBar_arr
#print axioms BioPaper.alphaBar_arr_reversed

-- Group 1, result 6: the coupled benefit test
#print axioms BioPaper.coupled_benefit_test

-- Item 1 as originally proved, from the closed form taken as a definition
#print axioms window_deriv
#print axioms item1_hasDerivAt
#print axioms item1_scaled
#print axioms item1_pos

-- ---- the level-set family: Leibniz at a moving boundary over a non-constant profile ----

-- the change of variable and the closed forms
#print axioms BioPaper.ramp_integral
#print axioms BioPaper.integral_shapePreserving
#print axioms BioPaper.CLevPlateau_eq
#print axioms BioPaper.CLevPlateau_eq_trunc
#print axioms BioPaper.CLev_eq

-- R2, level-set
#print axioms BioPaper.CLevPlateau_eventuallyEq
#print axioms BioPaper.r2_lev_hasDerivAt
#print axioms BioPaper.r2_lev_scaled
#print axioms BioPaper.r2_lev_paper_form

-- R1, truncation: the moving boundary in the speed
#print axioms BioPaper.CLevPlateau_eventuallyEq_trunc
#print axioms BioPaper.r1_lev_hasDerivAt
#print axioms BioPaper.r1_lev_scaled
#print axioms BioPaper.r1_lev_paper_form

-- the sign, by monotonicity alone
#print axioms BioPaper.hbar_le
#print axioms BioPaper.hbar_le_of_monotone
#print axioms BioPaper.r2_lev_bracket_nonneg

-- R3, the defence clock, level-set
#print axioms BioPaper.r3_lev_scaled
#print axioms BioPaper.r3_lev_paper_form
#print axioms BioPaper.dtD_lev

-- the misuse-distance derivatives: whether the boundary terms cancel
#print axioms BioPaper.dKM_B_rampon
#print axioms BioPaper.dKM_B_arrivalon
#print axioms BioPaper.dKM_A_rampon
#print axioms BioPaper.dKM_A_arrivalon
#print axioms BioPaper.dKM_conventions_differ

-- Group 2, items 9 to 12, and the before-arrival case
#print axioms BioPaper.integral_le_endpoint
#print axioms BioPaper.facility_B_arrivalon_weight
#print axioms BioPaper.facility_B_rampon_iff
#print axioms BioPaper.facility_A_arrivalon_slope
#print axioms BioPaper.CLev_A_affine
#print axioms BioPaper.dKM_B_before
#print axioms BioPaper.dKM_A_before
#print axioms BioPaper.CBeforeAInt_eq
#print axioms BioPaper.dKM_A_before_int
#print axioms BioPaper.dKM_A_before_nonpos

-- ---- Group 3: the responsive residual ----
#print axioms BioPaper.CResp_eq
#print axioms BioPaper.CResp_eventuallyEq
#print axioms BioPaper.r3_resp_hasDerivAt
#print axioms BioPaper.r3_resp_scaled
#print axioms BioPaper.r3_lev_resp_iff

-- ---- Group 4: the benefit margin and the separable mixed form ----
#print axioms BioPaper.hasDerivAt_exp_lin
#print axioms BioPaper.benefitMargin_zero
#print axioms BioPaper.benefitMargin_hasDerivAt
#print axioms BioPaper.benefitMargin_logDeriv
#print axioms BioPaper.benefitMargin_deriv_eq
#print axioms BioPaper.benefitMargin_logDeriv_pos_iff
#print axioms BioPaper.CMix_eq
#print axioms BioPaper.CMix_eventuallyEq
#print axioms BioPaper.CMix_hasDerivAt
#print axioms BioPaper.r_mix_scaled
#print axioms BioPaper.epsBar_g_iff
#print axioms BioPaper.epsBar_g_eq_calendar_iff

-- ---- Post-inventory rows E1–E4 (PostE.lean, added 28 Oct 2026) ----
#print axioms BioPaper.PostE.phi_partials
#print axioms BioPaper.PostE.baseW_mem
#print axioms BioPaper.PostE.integral_id01
#print axioms BioPaper.PostE.e1_A_ramp_worked
#print axioms BioPaper.PostE.e1_A_arr_worked
#print axioms BioPaper.PostE.ivW_mem
#print axioms BioPaper.PostE.e1_S_arr_worked
#print axioms BioPaper.PostE.e1_S_ramp_worked
#print axioms BioPaper.PostE.e1_B_constant_holds
#print axioms BioPaper.PostE.tDc_cap
#print axioms BioPaper.PostE.tDc_adopt
#print axioms BioPaper.PostE.tDc_scale
#print axioms BioPaper.PostE.tDc_hasDerivAt_cap
#print axioms BioPaper.PostE.CLevArr_eq_CArrClose
#print axioms BioPaper.PostE.CRampClose_eq
#print axioms BioPaper.PostE.CArrClose_eq_before
#print axioms BioPaper.PostE.lemmaH_A_ramp
#print axioms BioPaper.PostE.lemmaH_A_arr
#print axioms BioPaper.PostE.CSarr_eq_F
#print axioms BioPaper.PostE.CSramp_eq_F
#print axioms BioPaper.PostE.lemmaH_S_arr
#print axioms BioPaper.PostE.lemmaH_S_ramp
#print axioms BioPaper.PostE.euler_deg0
#print axioms BioPaper.PostE.euler_partials
#print axioms BioPaper.PostE.lemmaH1_A_ramp
#print axioms BioPaper.PostE.lemmaH1_A_arr
#print axioms BioPaper.PostE.sections_eventually
#print axioms BioPaper.PostE.phi_euler
#print axioms BioPaper.PostE.isOpen_Ucap
#print axioms BioPaper.PostE.isOpen_Uadopt
#print axioms BioPaper.PostE.of_mem_Ucap
#print axioms BioPaper.PostE.mem_Ucap
#print axioms BioPaper.PostE.of_mem_Uadopt
#print axioms BioPaper.PostE.mem_Uadopt
#print axioms BioPaper.PostE.CAramp_cap
#print axioms BioPaper.PostE.CAramp_adopt
#print axioms BioPaper.PostE.CAarr_cap
#print axioms BioPaper.PostE.CAarr_adopt
#print axioms BioPaper.PostE.CSarr_cap
#print axioms BioPaper.PostE.CSarr_adopt
#print axioms BioPaper.PostE.CSramp_cap
#print axioms BioPaper.PostE.CSramp_adopt
#print axioms BioPaper.PostE.e1_A_ramp_cap
#print axioms BioPaper.PostE.e1_A_ramp_adopt
#print axioms BioPaper.PostE.e1_A_arr_cap
#print axioms BioPaper.PostE.e1_A_arr_adopt
#print axioms BioPaper.PostE.e1_S_arr_cap
#print axioms BioPaper.PostE.e1_S_arr_adopt
#print axioms BioPaper.PostE.e1_S_ramp_cap
#print axioms BioPaper.PostE.e1_S_ramp_adopt
#print axioms BioPaper.PostE.CBramp_quarter_cap
#print axioms BioPaper.PostE.e1_B_counterexample
#print axioms BioPaper.PostE.e2_speed_marginal
#print axioms BioPaper.PostE.e2_bracket
#print axioms BioPaper.PostE.e2_KD_coefficient
#print axioms BioPaper.PostE.e2_affine
#print axioms BioPaper.PostE.e2_coefficient_eps
#print axioms BioPaper.PostE.rampClose_hasDerivAt
#print axioms BioPaper.PostE.e2_ramp_bracket
#print axioms BioPaper.PostE.e2_ramp_KD_coefficient
#print axioms BioPaper.PostE.e3_posExposure
#print axioms BioPaper.PostE.e3_defenceFirst
#print axioms BioPaper.PostE.e3_gap
#print axioms BioPaper.PostE.e3_boundary
#print axioms BioPaper.PostE.e3_sides
#print axioms BioPaper.PostE.e3_accumulate
#print axioms BioPaper.PostE.e3_right
#print axioms BioPaper.PostE.e3_left
#print axioms BioPaper.PostE.e3_kink_iff
#print axioms BioPaper.PostE.e3_degenerate
#print axioms BioPaper.PostE.gatedLevel_path
#print axioms BioPaper.PostE.path_intervalIntegrable
#print axioms BioPaper.PostE.CLevPlateau_eq_int
#print axioms BioPaper.PostE.bracket_nonneg_of_monotoneOn
#print axioms BioPaper.PostE.CMixAddRamp_eq
#print axioms BioPaper.PostE.CMixAddArrSpeed_eq
#print axioms BioPaper.PostE.CMixAddArrBoth_eq
#print axioms BioPaper.PostE.plateau_eventually
#print axioms BioPaper.PostE.r2_lev_hasDerivAt_int
#print axioms BioPaper.PostE.e4_speedGated_hasDerivAt
#print axioms BioPaper.PostE.e4_speedGated_scaled
#print axioms BioPaper.PostE.e4_speedGated_pos
#print axioms BioPaper.PostE.e4_bothGated_hasDerivAt
#print axioms BioPaper.PostE.e4_bothGated_scaled
#print axioms BioPaper.PostE.e4_bothGated_pos
#print axioms BioPaper.PostE.e4_ramp_hasDerivAt
#print axioms BioPaper.PostE.e4_ramp_scaled
#print axioms BioPaper.PostE.e4_ramp_pos
#print axioms BioPaper.PostE.threshold_nonpos
#print axioms BioPaper.PostE.e4_ramp_threshold
#print axioms BioPaper.PostE.e4_speedGated_threshold
#print axioms BioPaper.PostE.e4_bothGated_threshold
#print axioms BioPaper.PostE.isOpen_UcapF
#print axioms BioPaper.PostE.isOpen_UadoptF
#print axioms BioPaper.PostE.of_mem_UcapF
#print axioms BioPaper.PostE.mem_UcapF
#print axioms BioPaper.PostE.of_mem_UadoptF
#print axioms BioPaper.PostE.mem_UadoptF
#print axioms BioPaper.PostE.CSarr_capF
#print axioms BioPaper.PostE.CSarr_adoptF
#print axioms BioPaper.PostE.e1_S_arr_defFirst_cap
#print axioms BioPaper.PostE.e1_S_arr_defFirst_adopt
#print axioms BioPaper.PostE.phi_dLam
#print axioms BioPaper.PostE.e1_dF_dLam_arr_cap
#print axioms BioPaper.PostE.e1_dF_dLam_arr_adopt
#print axioms BioPaper.PostE.e1_dF_dLam_ramp_cap
#print axioms BioPaper.PostE.e1_dF_dLam_ramp_adopt
#print axioms BioPaper.PostE.e1_dF_dLam_arr_defFirst
#print axioms BioPaper.PostE.tDc_ex
#print axioms BioPaper.PostE.ev_s
#print axioms BioPaper.PostE.ev_KD
#print axioms BioPaper.PostE.ev_KM
#print axioms BioPaper.PostE.half_div_le
#print axioms BioPaper.PostE.e1_residual_S_ramp
#print axioms BioPaper.PostE.e1_residual_S_arr
#print axioms BioPaper.PostE.CArampR_one
#print axioms BioPaper.PostE.e1_residual_A_ramp
#print axioms BioPaper.PostE.CAarrR_one
#print axioms BioPaper.PostE.e1_residual_A_arr
#print axioms BioPaper.PostE.Λw_one
#print axioms BioPaper.PostE.Λw_hasDerivAt
#print axioms BioPaper.PostE.e2_worked_instance
#print axioms BioPaper.PostE.e3_worked_instance
#print axioms BioPaper.PostE.CBefore_eq_CLev
#print axioms BioPaper.PostE.CAramp_eq_CLev
#print axioms BioPaper.PostE.CBramp_eq_CLev
#print axioms BioPaper.PostE.CAramp_const
#print axioms BioPaper.PostE.CAarr_const
#print axioms BioPaper.PostE.CLev_eq_int
#print axioms BioPaper.PostE.shape_intervalIntegrable
#print axioms BioPaper.PostE.CAramp_defFirst
#print axioms BioPaper.PostE.CAramp_defFirst_witness
#print axioms BioPaper.PostE.isOpen_UrampCap
#print axioms BioPaper.PostE.isOpen_UrampAdopt
#print axioms BioPaper.PostE.mem_UrampCap
#print axioms BioPaper.PostE.mem_UrampAdopt
#print axioms BioPaper.PostE.CSramp_rcap
#print axioms BioPaper.PostE.CSramp_radopt
#print axioms BioPaper.PostE.e1_B_constant_baseW
#print axioms BioPaper.PostE.e1_dF_dLam_ramp
#print axioms BioPaper.PostE.e1_dF_dLam_ramp_beyond
#print axioms BioPaper.PostE.e1_dF_dLam_ramp_counterexample
#print axioms BioPaper.PostE.e1_dF_dLam_arr
#print axioms BioPaper.PostE.e1_dF_dLam_arr_first
#print axioms BioPaper.PostE.e1_dF_dLam_arr_beyond
#print axioms BioPaper.PostE.euler_H2
#print axioms BioPaper.PostE.lemmaH2_S_arr
#print axioms BioPaper.PostE.lemmaH2_S_ramp
#print axioms BioPaper.PostE.tDc_one
#print axioms BioPaper.PostE.ev_half_two
#print axioms BioPaper.PostE.ev_pos_two
#print axioms BioPaper.PostE.e1_mDTD_S_ramp
#print axioms BioPaper.PostE.e1_mDTD_S_arr
#print axioms BioPaper.PostE.e1_mDTD_A_ramp
#print axioms BioPaper.PostE.e1_mDTD_A_arr
#print axioms BioPaper.PostE.e4_K0_counterexample
#print axioms BioPaper.PostE.defFirst_hasDerivAt
#print axioms BioPaper.PostE.e3_left_limit
#print axioms BioPaper.PostE.e3_right_limit

-- ---- Post-inventory rows G, H, I (PostGHI.lean, added 28 Oct 2026) ----
#print axioms BioPaper.PostGHI.clock_cap
#print axioms BioPaper.PostGHI.clock_adopt
#print axioms BioPaper.PostGHI.clock_cap_eventually_s
#print axioms BioPaper.PostGHI.clock_adopt_eventually_s
#print axioms BioPaper.PostGHI.hasDerivAt_K_div
#print axioms BioPaper.PostGHI.clock_hasDerivAt_s_cap
#print axioms BioPaper.PostGHI.clock_hasDerivAt_s_adopt
#print axioms BioPaper.PostGHI.clock_hasDerivAt_K
#print axioms BioPaper.PostGHI.gate_at
#print axioms BioPaper.PostGHI.gate_zero_below
#print axioms BioPaper.PostGHI.convA_at
#print axioms BioPaper.PostGHI.gate_hbar
#print axioms BioPaper.PostGHI.gate_path
#print axioms BioPaper.PostGHI.gate_levHaz
#print axioms BioPaper.PostGHI.gate_plateau_eq_CArr
#print axioms BioPaper.PostGHI.gate_close_eq_CArrClose
#print axioms BioPaper.PostGHI.gate_plateau_eventuallyEq
#print axioms BioPaper.PostGHI.gate_close_eventuallyEq
#print axioms BioPaper.PostGHI.arrClose_hasDerivAt_weak
#print axioms BioPaper.PostGHI.CTrans_split
#print axioms BioPaper.PostGHI.trans_hasDerivAt
#print axioms BioPaper.PostGHI.clock_continuous_K
#print axioms BioPaper.PostGHI.preOK_of_eqOn
#print axioms BioPaper.PostGHI.preLev_ok
#print axioms BioPaper.PostGHI.gate_intervalIntegrable
#print axioms BioPaper.PostGHI.convA_intervalIntegrable
#print axioms BioPaper.PostGHI.CLev_eq_trans
#print axioms BioPaper.PostGHI.CArrClose_eq_trans
#print axioms BioPaper.PostGHI.CRamp_eq_trans
#print axioms BioPaper.PostGHI.trans_kd
#print axioms BioPaper.PostGHI.clock_eventually_gt
#print axioms BioPaper.PostGHI.i_CLev_kd
#print axioms BioPaper.PostGHI.i_levB_rampon
#print axioms BioPaper.PostGHI.i_levA_rampon
#print axioms BioPaper.PostGHI.i_levB_arrival
#print axioms BioPaper.PostGHI.i_levA_arrival
#print axioms BioPaper.PostGHI.i_speed_rampon
#print axioms BioPaper.PostGHI.preArr_ok
#print axioms BioPaper.PostGHI.i_speed_arrival
#print axioms BioPaper.PostGHI.i_sign
#print axioms BioPaper.PostGHI.chi_adopt
#print axioms BioPaper.PostGHI.chi_cap
#print axioms BioPaper.PostGHI.i_CLev_kd_adopt
#print axioms BioPaper.PostGHI.i_speed_rampon_adopt
#print axioms BioPaper.PostGHI.i_speed_arrival_adopt
#print axioms BioPaper.PostGHI.i_CLev_kd_sign
#print axioms BioPaper.PostGHI.i_speed_arrival_sign
#print axioms BioPaper.PostGHI.i_speed_rampon_sign
#print axioms BioPaper.PostGHI.trans_kd_gradual
#print axioms BioPaper.PostGHI.trans_kd_linear_trunc
#print axioms BioPaper.PostGHI.trans_linear_trunc_ne
#print axioms BioPaper.PostGHI.i_gradual_failure_instance
#print axioms BioPaper.PostGHI.trans_kd_resp
#print axioms BioPaper.PostGHI.i_CLev_kd_resp
#print axioms BioPaper.PostGHI.i_speed_arrival_resp
#print axioms BioPaper.PostGHI.i_speed_rampon_resp
#print axioms BioPaper.PostGHI.i_gradual_lev
#print axioms BioPaper.PostGHI.i_gradual_levB_rampon
#print axioms BioPaper.PostGHI.i_gradual_levA_rampon
#print axioms BioPaper.PostGHI.i_gradual_levB_arrival
#print axioms BioPaper.PostGHI.i_gradual_levA_arrival
#print axioms BioPaper.PostGHI.i_gradual_speed_rampon
#print axioms BioPaper.PostGHI.i_gradual_speed_arrival
#print axioms BioPaper.PostGHI.gated_plateau_hasDerivAt
#print axioms BioPaper.PostGHI.gated_close_hasDerivAt
#print axioms BioPaper.PostGHI.g1_relation
#print axioms BioPaper.PostGHI.g1_cannot_diverge
#print axioms BioPaper.PostGHI.h2_relation
#print axioms BioPaper.PostGHI.paced_ord
#print axioms BioPaper.PostGHI.g4_relation
#print axioms BioPaper.PostGHI.g5_level
#print axioms BioPaper.PostGHI.g5_speed
#print axioms BioPaper.PostGHI.g5_direction_convention
#print axioms BioPaper.PostGHI.g5_direction_zero_residual
#print axioms BioPaper.PostGHI.g5_point_Lam
#print axioms BioPaper.PostGHI.g5_point_clock
#print axioms BioPaper.PostGHI.g5_witness
#print axioms BioPaper.PostGHI.g5_witness_any_scale
#print axioms BioPaper.PostGHI.ramp_hasDerivAt_s
#print axioms BioPaper.PostGHI.g5_witness_rampon_negative
#print axioms BioPaper.PostGHI.g5_rev_clock
#print axioms BioPaper.PostGHI.g5_reversal_witness
#print axioms BioPaper.PostGHI.h6_pos_of_R2
#print axioms BioPaper.PostGHI.h6_relation
#print axioms BioPaper.PostGHI.benefit_hasDerivAt
#print axioms BioPaper.PostGHI.whole_balance_interval_le
#print axioms BioPaper.PostGHI.whole_balance_interval
#print axioms BioPaper.PostGHI.h7_tests
#print axioms BioPaper.PostGHI.h7_interval
#print axioms BioPaper.PostGHI.h7_gap_eps
#print axioms BioPaper.PostGHI.i_l1006_formula_adopt_ne
#print axioms BioPaper.PostGHI.i_l1006_formula_instance
#print axioms BioPaper.PostGHI.trans_kd_linear_only_at
#print axioms BioPaper.PostGHI.trans_kd_resp_gradual
#print axioms BioPaper.PostGHI.i_resp_gradual_instance
#print axioms BioPaper.PostGHI.g5_zero_residual_no_identity
#print axioms BioPaper.PostGHI.g5_rpow_bounds
#print axioms BioPaper.PostGHI.g5_witness_power_law
#print axioms BioPaper.PostGHI.g5_reversal_unscaled
#print axioms BioPaper.PostGHI.benefit_hasDerivAt_late
#print axioms BioPaper.PostGHI.h7_delay_counterexample
#print axioms BioPaper.PostGHI.trans_kd_linear_adopt
#print axioms BioPaper.PostGHI.trans_kd_linear_nogap
#print axioms BioPaper.PostGHI.i_gradual_incomplete_instance
#print axioms BioPaper.PostGHI.i_gradual_nonrigid_instance
