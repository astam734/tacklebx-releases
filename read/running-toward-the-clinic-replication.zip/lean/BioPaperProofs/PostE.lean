import BioPaperProofs.Group1
import BioPaperProofs.Group34

/-!
# Rows E1–E4 of S.4: the post-inventory results of §4a

Four results added after `PROOF-INVENTORY.md` was written: the proportional-cut identity and
Lemma H (E1), the arrival-on `K_D` coefficient (E2), the one-sided limits at `t_D = τ_M` on the
own-distance clock (E3), and the additive mixed form on the plateau (E4).  Every statement is
about a loss **defined as the integral of its hazard**, reusing the objects the 82 existing
theorems are about: `step`, `step2` (`StepIntegral.lean`), `CArr`, `CArrClose`, `r2_hasDerivAt`,
`r3_hasDerivAt` (`Group1.lean`), `levHaz`, `CLev`, `CLevPlateau`, `CLev_eq`, `hbar`,
`integral_shapePreserving` (`LevelSet.lean`).  Nothing that exists is redefined.

## Modelling choices a reader must agree with

1. **The clock.** `tDc mD TD KD s = max (KD/s) ((1 − mD)TD) + mD·TD` is A0's
   `t_D = max{K_D/s, (1 − m_D)T_D} + m_DT_D`, verbatim.  No existing module defined it (Group 1
   takes `t_D` as an arbitrary function), so it is defined here.  The **capability branch**
   (`χ_D = 1`) is `(1 − m_D)T_D < K_D/s`; the **adoption branch** (`χ_D = 0`) is the reverse
   strict inequality.  The clock kink is excluded, as A4a.7 says.
2. **The four losses of E1.**  Each is a function of `(s, K_M, K_D)` with `L`, `h_M^post = P`,
   `m_D`, `T_D` fixed, and the hazard fixed:
   * level-set, convention A, ramp-on: the existing `CBeforeAInt ĥ K_M L s t_D P`
     (`LevelSet.lean`), whose hazard is `ĥ(min(st, K_M)/K_M)` before `t_D` and `P` from `t_D` —
     the hazard of Lemma H's proof, in every ordering of `τ_M` and `t_D`.  Where `τ_M ≤ t_D` it is
     the existing `CLev` at the shape-preserving profile `ĥ(c/K_M)` (`CAramp_eq_CLev`); where
     `t_D < τ_M` it is Lemma 2's (2.1) (`CAramp_defFirst`).  (Fix round 1: the first version used
     `CLev` everywhere, whose hazard steps to `P` at `max(τ_M, t_D)`, not at `t_D`.)
   * level-set, convention A, arrival-on: `step2 0 (h K) P (K/s) t_D` integrated, the shape
     `LevelSet.lean`'s docstring names for level-set arrival-on; with `h = ĥ(·/K_M)` its plateau
     is `ĥ(K_M/K_M) = ĥ(1)`.  It is literally `CArrClose` with a constant intensity (`rfl`).
   * speed-set, arrival-on: the existing `CArrClose Λ K_M L s t_D P`.
   * speed-set, ramp-on: `step (Λ s) P t_D` integrated (new: Group 1 is arrival-on only).
3. **Convention B** is the fixed profile `h` inside the existing `CBefore`, the same gating as
   convention A (`CBramp_eq_CLev` where `τ_M ≤ t_D`).
4. **Elasticity.** As in `Group1.lean`, `Λ_Mε_Λ` is written `s·Λ'` and nothing is divided by
   `Λ s`, except where a statement is *about* `ε_Λ` (E4's "for every `ε_Λ ≥ 0`"); there
   `ε_Λ := s·Λ'/Λ(s)` with `Λ'` the derivative of the defined `Λ`, and `Λ(s) > 0` is carried.
5. **Partial derivatives** are `HasDerivAt` of the defined loss in one argument with the other two
   fixed.  "Wherever `C_M` is differentiable" in Lemma H is read as Fréchet differentiability of
   `C_M` as a function on `ℝ³`; the Euler step needs that, not merely three partials.  For
   speed-set (H.2) it is read as Fréchet differentiability of `(λ, s, K_M, K_D) ↦ F(λ; s, K_M, K_D)`
   at `(Λ_M(s), s, K_M, K_D)` (`euler_H2`, `lemmaH2_S_*`); `∂F/∂Λ` is the derivative in the
   intensity held at a number, which `e1_dF_dLam_*` identify with `ℓ_M` pointwise.
6. **A0's residual-from-arrival convention** (speed-set arrival-on, defence before arrival) needs
   no new object: `step2 0 Λ P (K/s) t_D` with `t_D < K/s` is already zero before `K/s` and `P`
   after it (`CArrClose_eq_before`).  E3 uses that.
7. **E4's gatings.** The speed component gated is `step 0 (Λ s) (K/s)` (Group 1's arrival-on
   hazard).  The level component gated is §4a.2's gated profile — zero below `K_M`, `h_M(K_M)` at
   it — applied to the capability path `c(t) = min(st, K_M)` (`gatedLevel`).
8. **Regularity of the level profile.**  The general (H.1) theorems `lemmaH1_A_ramp/arr` assume
   nothing about `ĥ`.  The interior ramp-on theorems `CAramp_cap/adopt`, `e1_A_ramp_cap/adopt`
   assume only `IntervalIntegrable ĥ volume 0 1`, which under convention A is Lemma L's "*h_M* is
   integrable on *[0, K_M]*" (`shape_intervalIntegrable`); they go through `CLev_eq_int`, the
   existing `CLev_eq` re-proved without continuity.  Only `CAramp_defFirst`, which ties the loss
   to (2.1) through the existing `CBeforeAInt_eq`, takes `Continuous ĥ`.  Convention A divides by
   `K_M`, so `K_M > 0` is presupposed wherever it appears.  E4 assumes no continuity: its formulas need
   `h_M` integrable on `[0, K_M]` (Lemma L's own assumption), and its signs need `h_M`
   nondecreasing on `[0, K_M]` (A4a.5), which implies integrability.  `CLevPlateau_eq_int` and
   `r2_lev_hasDerivAt_int` re-prove `LevelSet.lean`'s plateau closed form and R2 derivative under
   integrability alone, about the same `CLevPlateau`.
9. **A responsive residual** (A0: "unless a result says it responds to speed") is a function
   `Pf` put into the same four losses (`CSrampR`, `CSarrR`, `CArampR`, `CAarrR`, each the existing
   object with `P := Pf s`); used only to show the identities *need* a fixed residual.
10. **Defence before arrival** (speed-set arrival-on) is the open region `UcapF`/`UadoptF`
   (`t_D < τ_M < L`, either clock branch), where (H.2) holds with `ℓ_M = 0`.
11. **Worked instances** use `Λw(s) = 0.02√s`.  The paper prints only the product `m_DT_D`; the
   instances take `m_D = 1`, which is on the capability branch, where the printed quantities
   depend on `m_D`, `T_D` only through `m_DT_D`.
12. **A speed-responsive build time** (testing "*m_DT_D* held fixed") needs no new object: the
   loss as a function of `(s, K_M, K_D)` is the defined loss with `T_D := s` (`e1_mDTD_*`).
13. **E3's "tends to"** is the limit of `s·C_M′(s)` as `s ↓ s₀` or `s ↑ s₀` (`e3_right_limit`,
   `e3_left_limit`).  The positive-exposure limit needs `Λ_M′` continuous at `s₀`; the one-sided
   derivatives at `s₀` (`e3_right`, `e3_left`) need only `Λ_M` differentiable at `s₀`.
-/

open MeasureTheory intervalIntegral Set Filter Topology

namespace BioPaper.PostE

/-! ## The clock -/

/-- A0's deployment clock, `t_D = max{K_D/s, (1 − m_D)T_D} + m_DT_D`. -/
noncomputable def tDc (mD TD KD s : ℝ) : ℝ := max (KD / s) ((1 - mD) * TD) + mD * TD

theorem tDc_cap (mD TD KD s : ℝ) (h : (1 - mD) * TD ≤ KD / s) :
    tDc mD TD KD s = KD / s + mD * TD := by
  rw [tDc, max_eq_left h]

theorem tDc_adopt (mD TD KD s : ℝ) (h : KD / s ≤ (1 - mD) * TD) : tDc mD TD KD s = TD := by
  rw [tDc, max_eq_right h]; ring

/-- Scaling `s` and `K_D` together leaves the clock unchanged, on either branch. -/
theorem tDc_scale (mD TD KD s k : ℝ) (hk : k ≠ 0) :
    tDc mD TD (k * KD) (k * s) = tDc mD TD KD s := by
  rw [tDc, tDc, mul_div_mul_left _ _ hk]

/-- On the capability branch the clock is differentiable in `s`, with `t_D′ = −K_D/s²`. -/
theorem tDc_hasDerivAt_cap (mD TD KD s : ℝ) (hs : 0 < s) (hbr : (1 - mD) * TD < KD / s) :
    HasDerivAt (fun x => tDc mD TD KD x) (-(KD / s ^ 2)) s := by
  have hcd : ContinuousAt (fun x : ℝ => KD / x) s := continuousAt_const.div continuousAt_id hs.ne'
  have hev : ∀ᶠ x in 𝓝 s, (1 - mD) * TD < KD / x :=
    hcd.eventually ((isOpen_Ioi.eventually_mem hbr).mono (fun x hx => hx))
  have heq : (fun x => tDc mD TD KD x) =ᶠ[𝓝 s] fun x => KD / x + mD * TD := by
    filter_upwards [hev] with x hx
    exact tDc_cap mD TD KD x hx.le
  have hd : HasDerivAt (fun x : ℝ => KD / x + mD * TD) (-(KD / s ^ 2)) s := by
    have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs.ne'
    have h := (hinv.const_mul KD).add_const (mD * TD)
    simp only [div_eq_mul_inv]
    convert h using 1
    ring
  exact hd.congr_of_eventuallyEq heq

/-! ## The losses, defined as integrals -/

/-- Level-set, convention A, ramp-on, with the clock: the existing `CBeforeAInt`, whose hazard is
`ĥ(min(st, K_M)/K_M)` before `t_D` and the residual from `t_D`, whichever of `τ_M`, `t_D` comes
first (Lemma H's proof; Lemma 2 when the defence comes first). -/
noncomputable def CAramp (ĥ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) : ℝ :=
  CBeforeAInt ĥ KM L s (tDc mD TD KD s) P

/-- Level-set arrival-on loss: no hazard on the ramp, the plateau level `h K` from `K/s`, the
residual from `t_D` (A0, first bullet). -/
noncomputable def CLevArr (h : ℝ → ℝ) (K L s tD P : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, step2 0 (h K) P (K / s) tD t

/-- Level-set arrival-on *is* the speed-set arrival-on loss at the constant intensity `h K`. -/
theorem CLevArr_eq_CArrClose (h : ℝ → ℝ) (K L s tD P : ℝ) :
    CLevArr h K L s tD P = CArrClose (fun _ => h K) K L s tD P := rfl

/-- Level-set, convention A, arrival-on, with the clock. -/
noncomputable def CAarr (ĥ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) : ℝ :=
  CLevArr (fun c => ĥ (c / KM)) KM L s (tDc mD TD KD s) P

/-- Speed-set ramp-on loss with a step to the residual at `t_D`. -/
noncomputable def CRampClose (Λ : ℝ → ℝ) (L s tD P : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, step (Λ s) P tD t

/-- Speed-set arrival-on with the clock: the existing `CArrClose`. -/
noncomputable def CSarr (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) : ℝ :=
  CArrClose Λ KM L s (tDc mD TD KD s) P

/-- Speed-set ramp-on with the clock. -/
noncomputable def CSramp (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) : ℝ :=
  CRampClose Λ L s (tDc mD TD KD s) P

/-- Level-set, convention B (fixed profile `h`), ramp-on, with the clock: the existing `CBefore`,
gated at `t_D` as `CAramp` is. -/
noncomputable def CBramp (h : ℝ → ℝ) (L P mD TD s KM KD : ℝ) : ℝ :=
  CBefore h KM L s (tDc mD TD KD s) P

/-- At a constant profile, level-set A ramp-on is speed-set ramp-on at that intensity. -/
theorem CAramp_const (c L P mD TD s KM KD : ℝ) :
    CAramp (fun _ => c) L P mD TD s KM KD = CSramp (fun _ => c) L P mD TD s KM KD := rfl

/-- At a constant profile, level-set A arrival-on is speed-set arrival-on at that intensity. -/
theorem CAarr_const (c L P mD TD s KM KD : ℝ) :
    CAarr (fun _ => c) L P mD TD s KM KD = CSarr (fun _ => c) L P mD TD s KM KD := rfl

theorem CRampClose_eq (Λ : ℝ → ℝ) (L s tD P : ℝ) (h0 : 0 ≤ tD) (hL : tD ≤ L) :
    CRampClose Λ L s tD P = Λ s * tD + P * (L - tD) := by
  rw [CRampClose, integral_step (Λ s) P 0 tD L h0 hL]; ring

/-- **A0's residual-from-arrival convention, from the definition.**  With the defence before
arrival, the arrival-on hazard is zero before `τ_M` and the residual from `τ_M`, so
`C_M = h_M^post(L − τ_M)`. -/
theorem CArrClose_eq_before (Λ : ℝ → ℝ) (K L s tD P : ℝ) (hτ : 0 ≤ K / s) (hD : tD ≤ K / s)
    (hL : K / s ≤ L) : CArrClose Λ K L s tD P = P * (L - K / s) := by
  have hfun : (fun t => step2 0 (Λ s) P (K / s) tD t) = step 0 P (K / s) := by
    funext t
    simp only [step2, step]
    split_ifs with h1 h2 <;> first | rfl | (exfalso; linarith)
  rw [CArrClose, hfun, integral_step 0 P 0 (K / s) L hτ hL]; ring

/-- Once the capability is reached before the step (`τ_M ≤ t_D`), the gated ramp-on loss is the
existing `CLev`: the two hazards agree at every date. -/
theorem CBefore_eq_CLev (h : ℝ → ℝ) (K L s tD P : ℝ) (hs : 0 < s) (hD : K / s ≤ tD) :
    CBefore h K L s tD P = CLev h K L s tD P := by
  unfold CBefore CLev levHaz
  congr 1
  funext t
  by_cases h1 : t < K / s
  · have hst : s * t ≤ K := by
      calc s * t ≤ s * (K / s) := mul_le_mul_of_nonneg_left h1.le hs.le
      _ = K := mul_div_cancel₀ K hs.ne'
    simp [h1, lt_of_lt_of_le h1 hD, min_eq_left hst]
  · have hst : K ≤ s * t := by
      calc K = s * (K / s) := (mul_div_cancel₀ K hs.ne').symm
      _ ≤ s * t := mul_le_mul_of_nonneg_left (not_lt.mp h1) hs.le
    simp [h1, min_eq_right hst]

theorem CAramp_eq_CLev (ĥ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (hs : 0 < s)
    (hD : KM / s ≤ tDc mD TD KD s) :
    CAramp ĥ L P mD TD s KM KD = CLev (fun c => ĥ (c / KM)) KM L s (tDc mD TD KD s) P :=
  CBefore_eq_CLev (fun c => ĥ (c / KM)) KM L s _ P hs hD

theorem CBramp_eq_CLev (h : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (hs : 0 < s)
    (hD : KM / s ≤ tDc mD TD KD s) :
    CBramp h L P mD TD s KM KD = CLev h KM L s (tDc mD TD KD s) P :=
  CBefore_eq_CLev h KM L s _ P hs hD

/-- `LevelSet.lean`'s closed form with closure (`CLev_eq`) for a merely integrable profile
(Lemma L's assumption). -/
theorem CLev_eq_int (h : ℝ → ℝ) (K L s tD P : ℝ) (hi : IntervalIntegrable h volume 0 K)
    (hs : 0 < s) (hK : 0 ≤ K) (hD : K / s ≤ tD) (hL : tD ≤ L) :
    CLev h K L s tD P
      = s⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (tD - K / s) + P * (L - tD) := by
  have hτ : 0 ≤ K / s := by positivity
  have hcomp : IntervalIntegrable (fun t : ℝ => h (s * t)) volume 0 (K / s) := by
    have := hi.comp_mul_left (c := s)
    rwa [zero_div] at this
  have hi1 : IntervalIntegrable (levHaz h K s tD P) volume 0 (K / s) := by
    rw [intervalIntegrable_congr_uIoo (g := fun t : ℝ => h (s * t)) ?_]
    · exact hcomp
    · intro t ht
      rw [uIoo_of_le hτ] at ht
      simp [levHaz, ht.2]
  have hi2 : IntervalIntegrable (levHaz h K s tD P) volume (K / s) L := by
    rw [intervalIntegrable_congr_uIoo (g := step (h K) P tD) ?_]
    · exact intervalIntegrable_step (h K) P (K / s) tD L hD hL
    · intro t ht
      rw [uIoo_of_le (le_trans hD hL)] at ht
      have : ¬ t < K / s := not_lt.mpr ht.1.le
      simp [levHaz, step, this]
  have h1 : (∫ t in (0:ℝ)..(K / s), levHaz h K s tD P t) = s⁻¹ * ∫ c in (0:ℝ)..K, h c := by
    rw [integral_congr_Ioo_of_le hτ (g := fun t : ℝ => h (s * t)) ?_]
    · exact ramp_integral h K s hs.ne'
    · intro t ht; simp [levHaz, ht.2]
  have h2 : (∫ t in (K / s)..L, levHaz h K s tD P t) = h K * (tD - K / s) + P * (L - tD) := by
    rw [integral_congr_Ioo_of_le (le_trans hD hL) (g := step (h K) P tD) ?_]
    · exact integral_step (h K) P (K / s) tD L hD hL
    · intro t ht
      have : ¬ t < K / s := not_lt.mpr ht.1.le
      simp [levHaz, step, this]
  rw [CLev, ← integral_add_adjacent_intervals hi1 hi2, h1, h2]; ring

/-- Under convention A, `ĥ` integrable on `[0, 1]` is `h_M(c) = ĥ(c/K_M)` integrable on
`[0, K_M]`. -/
theorem shape_intervalIntegrable (ĥ : ℝ → ℝ) (K : ℝ) (hi : IntervalIntegrable ĥ volume 0 1) :
    IntervalIntegrable (fun c => ĥ (c / K)) volume 0 K := by
  have := hi.comp_mul_left (c := K⁻¹)
  rw [zero_div, one_div, inv_inv] at this
  simpa [div_eq_inv_mul] using this

/-- **The defence before the capability (Lemma 2, (2.1)).**  With `t_D < τ_M` the defined ramp-on
loss is `s⁻¹∫₀^{st_D} ĥ(c/K_M)dc + (L − t_D)h_M^post`, written
`(K_M/s)∫₀^{st_D/K_M} ĥ + h_M^post(L − t_D)`: the step is at `t_D`, before the plateau. -/
theorem CAramp_defFirst (ĥ : ℝ → ℝ) (hc : Continuous ĥ) (L P mD TD s KM KD : ℝ) (hs : 0 < s)
    (hKM : 0 < KM) (h0 : 0 ≤ tDc mD TD KD s) (hfirst : tDc mD TD KD s < KM / s)
    (hL : tDc mD TD KD s ≤ L) :
    CAramp ĥ L P mD TD s KM KD
      = KM / s * (∫ u in (0:ℝ)..(s * tDc mD TD KD s / KM), ĥ u) + P * (L - tDc mD TD KD s) :=
  CBeforeAInt_eq ĥ KM L s _ P hc hs hKM h0 hfirst hL

/-- **The observer's defence-first point** (`ĥ ≡ 1`, `L = 3`, `P = 0`, `m_D = 0`, `T_D = 1`,
`s = 1`, `K_M = 2`, `K_D = 1/2`, so `t_D = 1 < τ_M = 2`): the defined loss is (2.1)'s
`s⁻¹∫₀^{st_D}h + (L − t_D)P = 1`. -/
theorem CAramp_defFirst_witness : CAramp (fun _ => 1) 3 0 0 1 1 2 (1 / 2) = 1 := by
  rw [CAramp_const, CSramp, tDc_adopt 0 1 (1 / 2) 1 (by norm_num),
    CRampClose_eq _ 3 1 1 0 (by norm_num) (by norm_num)]
  norm_num

/-! ## E1, part 1: Lemma H — degree-zero homogeneity of the defined losses -/

/-- **Lemma H, convention A, ramp-on.**  `C_M(λs, λK_M, λK_D) = C_M(s, K_M, K_D)` for `λ > 0`:
the integrand is the same at every date. -/
theorem lemmaH_A_ramp (ĥ : ℝ → ℝ) (L P mD TD s KM KD k : ℝ) (hk : 0 < k) :
    CAramp ĥ L P mD TD (k * s) (k * KM) (k * KD) = CAramp ĥ L P mD TD s KM KD := by
  have hk0 : k ≠ 0 := hk.ne'
  have e : ∀ t : ℝ, min (k * s * t) (k * KM) / (k * KM) = min (s * t) KM / KM := fun t => by
    rw [mul_assoc, ← mul_min_of_nonneg _ _ hk.le, mul_div_mul_left _ _ hk0]
  simp only [CAramp, CBeforeAInt, tDc_scale mD TD KD s k hk0, e]

/-- **Lemma H, convention A, arrival-on.** -/
theorem lemmaH_A_arr (ĥ : ℝ → ℝ) (L P mD TD s KM KD k : ℝ) (hk : 0 < k) :
    CAarr ĥ L P mD TD (k * s) (k * KM) (k * KD) = CAarr ĥ L P mD TD s KM KD := by
  have hk0 : k ≠ 0 := hk.ne'
  have e1 : k * KM / (k * s) = KM / s := mul_div_mul_left _ _ hk0
  have e3 : k * KM / (k * KM) = KM / KM := mul_div_mul_left _ _ hk0
  simp only [CAarr, CLevArr, tDc_scale mD TD KD s k hk0, e1, e3]

/-- Under speed-set, `C_M = F(Λ_M(s); s, K_M, K_D)` with `F(Λ; ·)` the loss at the intensity
held at the number `Λ`: true by definition. -/
theorem CSarr_eq_F (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) :
    CSarr Λ L P mD TD s KM KD = CSarr (fun _ => Λ s) L P mD TD s KM KD := rfl

theorem CSramp_eq_F (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) :
    CSramp Λ L P mD TD s KM KD = CSramp (fun _ => Λ s) L P mD TD s KM KD := rfl

/-- **Lemma H, speed-set arrival-on:** `F` is homogeneous of degree zero in `(s, K_M, K_D)`. -/
theorem lemmaH_S_arr (lam L P mD TD s KM KD k : ℝ) (hk : 0 < k) :
    CSarr (fun _ => lam) L P mD TD (k * s) (k * KM) (k * KD)
      = CSarr (fun _ => lam) L P mD TD s KM KD := by
  have e1 : k * KM / (k * s) = KM / s := mul_div_mul_left _ _ hk.ne'
  simp only [CSarr, CArrClose, tDc_scale mD TD KD s k hk.ne', e1]

/-- **Lemma H, speed-set ramp-on.** -/
theorem lemmaH_S_ramp (lam L P mD TD s KM KD k : ℝ) (hk : 0 < k) :
    CSramp (fun _ => lam) L P mD TD (k * s) (k * KM) (k * KD)
      = CSramp (fun _ => lam) L P mD TD s KM KD := by
  simp only [CSramp, CRampClose, tDc_scale mD TD KD s k hk.ne']

/-! ## E1, part 2: Euler's theorem for a degree-zero homogeneous function -/

/-- A function on `ℝ³` homogeneous of degree zero and Fréchet differentiable at `p` has
derivative zero along the ray through `p`. -/
theorem euler_deg0 (F : ℝ × ℝ × ℝ → ℝ) (p : ℝ × ℝ × ℝ) (f' : ℝ × ℝ × ℝ →L[ℝ] ℝ)
    (hF : HasFDerivAt F f' p) (hhom : ∀ k : ℝ, 0 < k → F (k • p) = F p) : f' p = 0 := by
  have hray : HasDerivAt (fun k : ℝ => k • p) ((1:ℝ) • p) 1 := (hasDerivAt_id (1:ℝ)).smul_const p
  have hF' : HasFDerivAt F f' ((fun k : ℝ => k • p) 1) := by simpa using hF
  have hcomp : HasDerivAt (F ∘ fun k : ℝ => k • p) (f' ((1:ℝ) • p)) 1 :=
    hF'.comp_hasDerivAt (1:ℝ) hray
  have hev : (F ∘ fun k : ℝ => k • p) =ᶠ[𝓝 (1:ℝ)] fun _ => F p := by
    filter_upwards [(isOpen_Ioi.eventually_mem (show (1:ℝ) ∈ Ioi 0 by norm_num))] with k hk
    exact hhom k hk
  have hconst : HasDerivAt (F ∘ fun k : ℝ => k • p) 0 1 :=
    (hasDerivAt_const (1:ℝ) (F p)).congr_of_eventuallyEq hev
  have := hcomp.unique hconst
  simpa using this

/-- **Euler's identity (H.1) from homogeneity.**  If `F` is homogeneous of degree zero and
differentiable at `(s, K_M, K_D)`, its three partial derivatives satisfy
`s∂F/∂s + K_M∂F/∂K_M + K_D∂F/∂K_D = 0`. -/
theorem euler_partials (F : ℝ × ℝ × ℝ → ℝ) (s KM KD : ℝ) (f' : ℝ × ℝ × ℝ →L[ℝ] ℝ)
    (hF : HasFDerivAt F f' (s, KM, KD))
    (hhom : ∀ k : ℝ, 0 < k → F (k * s, k * KM, k * KD) = F (s, KM, KD)) (ds dK dD : ℝ)
    (hs : HasDerivAt (fun x => F (x, KM, KD)) ds s)
    (hK : HasDerivAt (fun x => F (s, x, KD)) dK KM)
    (hD : HasDerivAt (fun x => F (s, KM, x)) dD KD) :
    s * ds + KM * dK + KD * dD = 0 := by
  have h0 := euler_deg0 F (s, KM, KD) f' hF (fun k hk => by
    simpa [Prod.smul_mk, smul_eq_mul] using hhom k hk)
  have g1 : HasDerivAt (fun x => F (x, KM, KD)) (f' ((1:ℝ), (0:ℝ), (0:ℝ))) s :=
    hF.comp_hasDerivAt s
      ((hasDerivAt_id' s).prodMk ((hasDerivAt_const s KM).prodMk (hasDerivAt_const s KD)))
  have g2 : HasDerivAt (fun x => F (s, x, KD)) (f' ((0:ℝ), (1:ℝ), (0:ℝ))) KM :=
    hF.comp_hasDerivAt KM
      ((hasDerivAt_const KM s).prodMk ((hasDerivAt_id' KM).prodMk (hasDerivAt_const KM KD)))
  have g3 : HasDerivAt (fun x => F (s, KM, x)) (f' ((0:ℝ), (0:ℝ), (1:ℝ))) KD :=
    hF.comp_hasDerivAt KD
      ((hasDerivAt_const KD s).prodMk ((hasDerivAt_const KD KM).prodMk (hasDerivAt_id' KD)))
  have hsplit : ((s, KM, KD) : ℝ × ℝ × ℝ)
      = s • ((1:ℝ), (0:ℝ), (0:ℝ)) + KM • ((0:ℝ), (1:ℝ), (0:ℝ)) + KD • ((0:ℝ), (0:ℝ), (1:ℝ)) := by
    ext <;> simp
  rw [hsplit, map_add, map_add, map_smul, map_smul, map_smul, smul_eq_mul, smul_eq_mul,
    smul_eq_mul] at h0
  rw [hs.unique g1, hK.unique g2, hD.unique g3]
  exact h0

/-- **(H.1), convention A, ramp-on, wherever `C_M` is differentiable.** -/
theorem lemmaH1_A_ramp (ĥ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (f' : ℝ × ℝ × ℝ →L[ℝ] ℝ)
    (hF : HasFDerivAt (fun q : ℝ × ℝ × ℝ => CAramp ĥ L P mD TD q.1 q.2.1 q.2.2) f' (s, KM, KD))
    (ds dK dD : ℝ) (hs : HasDerivAt (fun x => CAramp ĥ L P mD TD x KM KD) ds s)
    (hK : HasDerivAt (fun x => CAramp ĥ L P mD TD s x KD) dK KM)
    (hD : HasDerivAt (fun x => CAramp ĥ L P mD TD s KM x) dD KD) :
    s * ds + KM * dK + KD * dD = 0 :=
  euler_partials _ s KM KD f' hF (fun k hk => lemmaH_A_ramp ĥ L P mD TD s KM KD k hk)
    ds dK dD hs hK hD

/-- **(H.1), convention A, arrival-on, wherever `C_M` is differentiable.** -/
theorem lemmaH1_A_arr (ĥ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (f' : ℝ × ℝ × ℝ →L[ℝ] ℝ)
    (hF : HasFDerivAt (fun q : ℝ × ℝ × ℝ => CAarr ĥ L P mD TD q.1 q.2.1 q.2.2) f' (s, KM, KD))
    (ds dK dD : ℝ) (hs : HasDerivAt (fun x => CAarr ĥ L P mD TD x KM KD) ds s)
    (hK : HasDerivAt (fun x => CAarr ĥ L P mD TD s x KD) dK KM)
    (hD : HasDerivAt (fun x => CAarr ĥ L P mD TD s KM x) dD KD) :
    s * ds + KM * dK + KD * dD = 0 :=
  euler_partials _ s KM KD f' hF (fun k hk => lemmaH_A_arr ĥ L P mD TD s KM KD k hk)
    ds dK dD hs hK hD

/-! ## E1, part 3: the identity at every interior point, from the partials themselves

Lemma H gives the identity wherever the loss is differentiable; the theorems below show that on
the region A4a.7 states (`τ_M < t_D < L`, off the clock kink) the defined loss *is*
differentiable in each argument and the identity holds — on both clock branches, both readings,
under convention A and under speed-set with the intensity term.  Every interior case has a local
closed form of one shape, `Phi`, so the calculus is done once. -/

/-- The local closed form shared by every interior case:
`Λ(s)·[(aK_M + cK_D)/s + d] + [(bK_M + eK_D)/s + f]`. -/
noncomputable def Phi (Λ : ℝ → ℝ) (a c d b e f s KM KD : ℝ) : ℝ :=
  Λ s * ((a * KM + c * KD) / s + d) + ((b * KM + e * KD) / s + f)

theorem sections_eventually (U : Set (ℝ × ℝ × ℝ)) (hU : IsOpen U) {s KM KD : ℝ}
    (hp : (s, KM, KD) ∈ U) :
    (∀ᶠ x in 𝓝 s, (x, KM, KD) ∈ U) ∧ (∀ᶠ x in 𝓝 KM, (s, x, KD) ∈ U)
      ∧ (∀ᶠ x in 𝓝 KD, (s, KM, x) ∈ U) := by
  refine ⟨?_, ?_, ?_⟩
  · exact (Continuous.continuousAt (by fun_prop : Continuous fun x : ℝ => ((x, KM, KD) : ℝ × ℝ × ℝ))).eventually_mem
      (hU.mem_nhds hp)
  · exact (Continuous.continuousAt (by fun_prop : Continuous fun x : ℝ => ((s, x, KD) : ℝ × ℝ × ℝ))).eventually_mem
      (hU.mem_nhds hp)
  · exact (Continuous.continuousAt (by fun_prop : Continuous fun x : ℝ => ((s, KM, x) : ℝ × ℝ × ℝ))).eventually_mem
      (hU.mem_nhds hp)

/-- **The calculus, once.**  A function equal to `Phi` on an open set has, at each point of it,
the three partials below, and they satisfy `s∂_s = sΛ′ℓ − K_M∂_{K_M} − K_D∂_{K_D}` with
`ℓ = (aK_M + cK_D)/s + d`, the coefficient of `Λ`. -/
theorem phi_euler (C : ℝ → ℝ → ℝ → ℝ) (Λ : ℝ → ℝ) (a c d b e f s KM KD lam' : ℝ)
    (U : Set (ℝ × ℝ × ℝ)) (hU : IsOpen U) (hp : (s, KM, KD) ∈ U)
    (hC : ∀ x y z : ℝ, (x, y, z) ∈ U → C x y z = Phi Λ a c d b e f x y z)
    (hs : s ≠ 0) (hΛ : HasDerivAt Λ lam' s) :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => C x KM KD) ds s ∧ HasDerivAt (fun x => C s x KD) dK KM ∧
      HasDerivAt (fun x => C s KM x) dD KD ∧
      s * ds = s * lam' * ((a * KM + c * KD) / s + d) - KM * dK - KD * dD := by
  obtain ⟨h1, h2, h3⟩ := sections_eventually U hU hp
  have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs
  have hA := (hinv.const_mul (a * KM + c * KD)).add_const d
  have hB := (hinv.const_mul (b * KM + e * KD)).add_const f
  have hS := (hΛ.mul hA).add hB
  have e1 : (fun x => C x KM KD) =ᶠ[𝓝 s] fun x =>
      Λ x * ((a * KM + c * KD) * x⁻¹ + d) + ((b * KM + e * KD) * x⁻¹ + f) := by
    filter_upwards [h1] with x hx
    rw [hC x KM KD hx, Phi, div_eq_mul_inv, div_eq_mul_inv]
  have hlinK : HasDerivAt (fun x : ℝ => Λ s * ((a * x + c * KD) / s + d) + ((b * x + e * KD) / s + f))
      (Λ s * (a / s) + b / s) KM := by
    have ha := (((((hasDerivAt_id' KM).const_mul a).add_const (c * KD)).div_const s).add_const d).const_mul (Λ s)
    have hb := ((((hasDerivAt_id' KM).const_mul b).add_const (e * KD)).div_const s).add_const f
    convert ha.add hb using 1
    ring
  have hlinD : HasDerivAt (fun x : ℝ => Λ s * ((a * KM + c * x) / s + d) + ((b * KM + e * x) / s + f))
      (Λ s * (c / s) + e / s) KD := by
    have ha := (((((hasDerivAt_id' KD).const_mul c).const_add (a * KM)).div_const s).add_const d).const_mul (Λ s)
    have hb := ((((hasDerivAt_id' KD).const_mul e).const_add (b * KM)).div_const s).add_const f
    convert ha.add hb using 1
    ring
  have e2 : (fun x => C s x KD) =ᶠ[𝓝 KM] fun x =>
      Λ s * ((a * x + c * KD) / s + d) + ((b * x + e * KD) / s + f) := by
    filter_upwards [h2] with x hx
    rw [hC s x KD hx, Phi]
  have e3 : (fun x => C s KM x) =ᶠ[𝓝 KD] fun x =>
      Λ s * ((a * KM + c * x) / s + d) + ((b * KM + e * x) / s + f) := by
    filter_upwards [h3] with x hx
    rw [hC s KM x hx, Phi]
  refine ⟨_, _, _, hS.congr_of_eventuallyEq e1, hlinK.congr_of_eventuallyEq e2,
    hlinD.congr_of_eventuallyEq e3, ?_⟩
  field_simp
  ring

/-- The interior region on the capability branch, cleared of denominators so that it is visibly
open: `s > 0`, `K_M > 0`, `(1 − m_D)T_D < K_D/s`, `τ_M < t_D`, `t_D < L`. -/
def Ucap (L mD TD : ℝ) : Set (ℝ × ℝ × ℝ) :=
  {q | 0 < q.1 ∧ 0 < q.2.1 ∧ (1 - mD) * TD * q.1 < q.2.2 ∧ q.2.1 < q.2.2 + mD * TD * q.1 ∧
    q.2.2 + mD * TD * q.1 < L * q.1}

/-- The interior region on the adoption branch: `K_D/s < (1 − m_D)T_D`, `τ_M < T_D < L`. -/
def Uadopt (L mD TD : ℝ) : Set (ℝ × ℝ × ℝ) :=
  {q | 0 < q.1 ∧ 0 < q.2.1 ∧ q.2.2 < (1 - mD) * TD * q.1 ∧ q.2.1 < TD * q.1 ∧ TD < L}

theorem isOpen_Ucap (L mD TD : ℝ) : IsOpen (Ucap L mD TD) := by
  unfold Ucap
  repeat' apply IsOpen.and
  all_goals exact isOpen_lt (by fun_prop) (by fun_prop)

theorem isOpen_Uadopt (L mD TD : ℝ) : IsOpen (Uadopt L mD TD) := by
  unfold Uadopt
  repeat' apply IsOpen.and
  all_goals exact isOpen_lt (by fun_prop) (by fun_prop)

theorem of_mem_Ucap {L mD TD s KM KD : ℝ} (h : (s, KM, KD) ∈ Ucap L mD TD) :
    0 < s ∧ 0 < KM ∧ (1 - mD) * TD < KD / s ∧ KM / s < KD / s + mD * TD ∧
      KD / s + mD * TD < L := by
  obtain ⟨hs, hKM, h1, h2, h3⟩ := h
  have e : KD / s + mD * TD = (KD + mD * TD * s) / s := by field_simp
  refine ⟨hs, hKM, (lt_div_iff₀ hs).mpr h1, ?_, ?_⟩
  · rw [e]; exact (div_lt_div_iff_of_pos_right hs).mpr h2
  · rw [e]; exact (div_lt_iff₀ hs).mpr h3

theorem mem_Ucap {L mD TD s KM KD : ℝ} (hs : 0 < s) (hKM : 0 < KM)
    (hbr : (1 - mD) * TD < KD / s) (harr : KM / s < tDc mD TD KD s)
    (hhor : tDc mD TD KD s < L) : (s, KM, KD) ∈ Ucap L mD TD := by
  rw [tDc_cap _ _ _ _ hbr.le] at harr hhor
  have e : KD / s + mD * TD = (KD + mD * TD * s) / s := by field_simp
  rw [e] at harr hhor
  exact ⟨hs, hKM, (lt_div_iff₀ hs).mp hbr, (div_lt_div_iff_of_pos_right hs).mp harr,
    (div_lt_iff₀ hs).mp hhor⟩

theorem of_mem_Uadopt {L mD TD s KM KD : ℝ} (h : (s, KM, KD) ∈ Uadopt L mD TD) :
    0 < s ∧ 0 < KM ∧ KD / s < (1 - mD) * TD ∧ KM / s < TD ∧ TD < L := by
  obtain ⟨hs, hKM, h1, h2, h3⟩ := h
  exact ⟨hs, hKM, (div_lt_iff₀ hs).mpr h1, (div_lt_iff₀ hs).mpr h2, h3⟩

theorem mem_Uadopt {L mD TD s KM KD : ℝ} (hs : 0 < s) (hKM : 0 < KM)
    (hbr : KD / s < (1 - mD) * TD) (harr : KM / s < tDc mD TD KD s)
    (hhor : tDc mD TD KD s < L) : (s, KM, KD) ∈ Uadopt L mD TD := by
  rw [tDc_adopt _ _ _ _ hbr.le] at harr hhor
  exact ⟨hs, hKM, (div_lt_iff₀ hs).mp hbr, (div_lt_iff₀ hs).mp harr, hhor⟩

/-! ### The closed forms on the two regions -/

theorem CAramp_cap (ĥ : ℝ → ℝ) (hi : IntervalIntegrable ĥ volume 0 1) (L P mD TD s KM KD : ℝ)
    (h : (s, KM, KD) ∈ Ucap L mD TD) :
    CAramp ĥ L P mD TD s KM KD
      = Phi (fun _ => ĥ 1) (-1) 1 (mD * TD) (∫ u in (0:ℝ)..1, ĥ u) (-P) (P * (L - mD * TD))
          s KM KD := by
  obtain ⟨hs, hKM, hbr, harr, hhor⟩ := of_mem_Ucap h
  have hD : KM / s ≤ tDc mD TD KD s := by rw [tDc_cap _ _ _ _ hbr.le]; exact harr.le
  rw [CAramp_eq_CLev ĥ L P mD TD s KM KD hs hD, tDc_cap _ _ _ _ hbr.le,
    CLev_eq_int _ KM L s _ P (shape_intervalIntegrable ĥ KM hi) hs hKM.le harr.le hhor.le]
  rw [integral_shapePreserving ĥ KM hKM.ne', div_self hKM.ne', Phi]
  field_simp
  ring

theorem CAramp_adopt (ĥ : ℝ → ℝ) (hi : IntervalIntegrable ĥ volume 0 1)
    (L P mD TD s KM KD : ℝ) (h : (s, KM, KD) ∈ Uadopt L mD TD) :
    CAramp ĥ L P mD TD s KM KD
      = Phi (fun _ => ĥ 1) (-1) 0 TD (∫ u in (0:ℝ)..1, ĥ u) 0 (P * (L - TD)) s KM KD := by
  obtain ⟨hs, hKM, hbr, harr, hhor⟩ := of_mem_Uadopt h
  have hD : KM / s ≤ tDc mD TD KD s := by rw [tDc_adopt _ _ _ _ hbr.le]; exact harr.le
  rw [CAramp_eq_CLev ĥ L P mD TD s KM KD hs hD, tDc_adopt _ _ _ _ hbr.le,
    CLev_eq_int _ KM L s _ P (shape_intervalIntegrable ĥ KM hi) hs hKM.le harr.le hhor.le]
  rw [integral_shapePreserving ĥ KM hKM.ne', div_self hKM.ne', Phi]
  field_simp
  ring

theorem CAarr_cap (ĥ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (h : (s, KM, KD) ∈ Ucap L mD TD) :
    CAarr ĥ L P mD TD s KM KD
      = Phi (fun _ => ĥ 1) (-1) 1 (mD * TD) 0 (-P) (P * (L - mD * TD)) s KM KD := by
  obtain ⟨hs, hKM, hbr, harr, hhor⟩ := of_mem_Ucap h
  rw [CAarr, CLevArr_eq_CArrClose, tDc_cap _ _ _ _ hbr.le,
    CArrClose_eq _ KM L s _ P (by positivity) harr.le hhor.le]
  beta_reduce
  rw [div_self hKM.ne', Phi]
  field_simp
  ring

theorem CAarr_adopt (ĥ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (h : (s, KM, KD) ∈ Uadopt L mD TD) :
    CAarr ĥ L P mD TD s KM KD = Phi (fun _ => ĥ 1) (-1) 0 TD 0 0 (P * (L - TD)) s KM KD := by
  obtain ⟨hs, hKM, hbr, harr, hhor⟩ := of_mem_Uadopt h
  rw [CAarr, CLevArr_eq_CArrClose, tDc_adopt _ _ _ _ hbr.le,
    CArrClose_eq _ KM L s _ P (by positivity) harr.le hhor.le]
  beta_reduce
  rw [div_self hKM.ne', Phi]
  field_simp
  ring

theorem CSarr_cap (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (h : (s, KM, KD) ∈ Ucap L mD TD) :
    CSarr Λ L P mD TD s KM KD = Phi Λ (-1) 1 (mD * TD) 0 (-P) (P * (L - mD * TD)) s KM KD := by
  obtain ⟨hs, hKM, hbr, harr, hhor⟩ := of_mem_Ucap h
  rw [CSarr, tDc_cap _ _ _ _ hbr.le, CArrClose_eq _ KM L s _ P (by positivity) harr.le hhor.le,
    Phi]
  field_simp
  ring

theorem CSarr_adopt (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (h : (s, KM, KD) ∈ Uadopt L mD TD) :
    CSarr Λ L P mD TD s KM KD = Phi Λ (-1) 0 TD 0 0 (P * (L - TD)) s KM KD := by
  obtain ⟨hs, hKM, hbr, harr, hhor⟩ := of_mem_Uadopt h
  rw [CSarr, tDc_adopt _ _ _ _ hbr.le, CArrClose_eq _ KM L s _ P (by positivity) harr.le hhor.le,
    Phi]
  field_simp
  ring

theorem CSramp_cap (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (h : (s, KM, KD) ∈ Ucap L mD TD) :
    CSramp Λ L P mD TD s KM KD = Phi Λ 0 1 (mD * TD) 0 (-P) (P * (L - mD * TD)) s KM KD := by
  obtain ⟨hs, hKM, hbr, harr, hhor⟩ := of_mem_Ucap h
  have h0 : 0 ≤ KD / s + mD * TD := le_trans (by positivity) harr.le
  rw [CSramp, tDc_cap _ _ _ _ hbr.le, CRampClose_eq Λ L s _ P h0 hhor.le, Phi]
  field_simp
  ring

theorem CSramp_adopt (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (h : (s, KM, KD) ∈ Uadopt L mD TD) :
    CSramp Λ L P mD TD s KM KD = Phi Λ 0 0 TD 0 0 (P * (L - TD)) s KM KD := by
  obtain ⟨hs, hKM, hbr, harr, hhor⟩ := of_mem_Uadopt h
  have h0 : 0 ≤ TD := le_trans (by positivity) harr.le
  rw [CSramp, tDc_adopt _ _ _ _ hbr.le, CRampClose_eq Λ L s _ P h0 hhor.le, Phi]
  field_simp
  ring

/-! ### The identity, case by case -/

/-- **E1 / (H.1), convention A, ramp-on, capability branch.** -/
theorem e1_A_ramp_cap (ĥ : ℝ → ℝ) (hi : IntervalIntegrable ĥ volume 0 1)
    (L P mD TD s KM KD : ℝ) (hs : 0 < s)
    (hKM : 0 < KM) (hbr : (1 - mD) * TD < KD / s) (harr : KM / s < tDc mD TD KD s)
    (hhor : tDc mD TD KD s < L) :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => CAramp ĥ L P mD TD x KM KD) ds s ∧
      HasDerivAt (fun x => CAramp ĥ L P mD TD s x KD) dK KM ∧
      HasDerivAt (fun x => CAramp ĥ L P mD TD s KM x) dD KD ∧
      s * ds = -(KM * dK) - KD * dD := by
  obtain ⟨ds, dK, dD, h1, h2, h3, h4⟩ :=
    phi_euler (CAramp ĥ L P mD TD) (fun _ => ĥ 1) (-1) 1 (mD * TD) _ (-P) (P * (L - mD * TD))
      s KM KD 0 (Ucap L mD TD) (isOpen_Ucap L mD TD) (mem_Ucap hs hKM hbr harr hhor)
      (fun x y z h => CAramp_cap ĥ hi L P mD TD x y z h) hs.ne' (hasDerivAt_const s _)
  exact ⟨ds, dK, dD, h1, h2, h3, by rw [h4]; ring⟩

/-- **E1 / (H.1), convention A, ramp-on, adoption branch.** -/
theorem e1_A_ramp_adopt (ĥ : ℝ → ℝ) (hi : IntervalIntegrable ĥ volume 0 1)
    (L P mD TD s KM KD : ℝ) (hs : 0 < s)
    (hKM : 0 < KM) (hbr : KD / s < (1 - mD) * TD) (harr : KM / s < tDc mD TD KD s)
    (hhor : tDc mD TD KD s < L) :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => CAramp ĥ L P mD TD x KM KD) ds s ∧
      HasDerivAt (fun x => CAramp ĥ L P mD TD s x KD) dK KM ∧
      HasDerivAt (fun x => CAramp ĥ L P mD TD s KM x) dD KD ∧
      s * ds = -(KM * dK) - KD * dD := by
  obtain ⟨ds, dK, dD, h1, h2, h3, h4⟩ :=
    phi_euler (CAramp ĥ L P mD TD) (fun _ => ĥ 1) (-1) 0 TD _ 0 (P * (L - TD))
      s KM KD 0 (Uadopt L mD TD) (isOpen_Uadopt L mD TD) (mem_Uadopt hs hKM hbr harr hhor)
      (fun x y z h => CAramp_adopt ĥ hi L P mD TD x y z h) hs.ne' (hasDerivAt_const s _)
  exact ⟨ds, dK, dD, h1, h2, h3, by rw [h4]; ring⟩

/-- **E1 / (H.1), convention A, arrival-on, capability branch.** -/
theorem e1_A_arr_cap (ĥ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (hs : 0 < s)
    (hKM : 0 < KM) (hbr : (1 - mD) * TD < KD / s) (harr : KM / s < tDc mD TD KD s)
    (hhor : tDc mD TD KD s < L) :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => CAarr ĥ L P mD TD x KM KD) ds s ∧
      HasDerivAt (fun x => CAarr ĥ L P mD TD s x KD) dK KM ∧
      HasDerivAt (fun x => CAarr ĥ L P mD TD s KM x) dD KD ∧
      s * ds = -(KM * dK) - KD * dD := by
  obtain ⟨ds, dK, dD, h1, h2, h3, h4⟩ :=
    phi_euler (CAarr ĥ L P mD TD) (fun _ => ĥ 1) (-1) 1 (mD * TD) 0 (-P) (P * (L - mD * TD))
      s KM KD 0 (Ucap L mD TD) (isOpen_Ucap L mD TD) (mem_Ucap hs hKM hbr harr hhor)
      (fun x y z h => CAarr_cap ĥ L P mD TD x y z h) hs.ne' (hasDerivAt_const s _)
  exact ⟨ds, dK, dD, h1, h2, h3, by rw [h4]; ring⟩

/-- **E1 / (H.1), convention A, arrival-on, adoption branch.** -/
theorem e1_A_arr_adopt (ĥ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (hs : 0 < s)
    (hKM : 0 < KM) (hbr : KD / s < (1 - mD) * TD) (harr : KM / s < tDc mD TD KD s)
    (hhor : tDc mD TD KD s < L) :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => CAarr ĥ L P mD TD x KM KD) ds s ∧
      HasDerivAt (fun x => CAarr ĥ L P mD TD s x KD) dK KM ∧
      HasDerivAt (fun x => CAarr ĥ L P mD TD s KM x) dD KD ∧
      s * ds = -(KM * dK) - KD * dD := by
  obtain ⟨ds, dK, dD, h1, h2, h3, h4⟩ :=
    phi_euler (CAarr ĥ L P mD TD) (fun _ => ĥ 1) (-1) 0 TD 0 0 (P * (L - TD))
      s KM KD 0 (Uadopt L mD TD) (isOpen_Uadopt L mD TD) (mem_Uadopt hs hKM hbr harr hhor)
      (fun x y z h => CAarr_adopt ĥ L P mD TD x y z h) hs.ne' (hasDerivAt_const s _)
  exact ⟨ds, dK, dD, h1, h2, h3, by rw [h4]; ring⟩

/-- **E1 / (H.2), speed-set, arrival-on, capability branch:** the intensity term with
`ℓ_M = t_D − τ_M`, written `s·Λ′·ℓ_M` for `Λ_Mε_Λℓ_M`. -/
theorem e1_S_arr_cap (Λ : ℝ → ℝ) (L P mD TD s KM KD lam' : ℝ) (hs : 0 < s) (hKM : 0 < KM)
    (hΛ : HasDerivAt Λ lam' s) (hbr : (1 - mD) * TD < KD / s)
    (harr : KM / s < tDc mD TD KD s) (hhor : tDc mD TD KD s < L) :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => CSarr Λ L P mD TD x KM KD) ds s ∧
      HasDerivAt (fun x => CSarr Λ L P mD TD s x KD) dK KM ∧
      HasDerivAt (fun x => CSarr Λ L P mD TD s KM x) dD KD ∧
      s * ds = s * lam' * (tDc mD TD KD s - KM / s) - KM * dK - KD * dD := by
  obtain ⟨ds, dK, dD, h1, h2, h3, h4⟩ :=
    phi_euler (CSarr Λ L P mD TD) Λ (-1) 1 (mD * TD) 0 (-P) (P * (L - mD * TD))
      s KM KD lam' (Ucap L mD TD) (isOpen_Ucap L mD TD) (mem_Ucap hs hKM hbr harr hhor)
      (fun x y z h => CSarr_cap Λ L P mD TD x y z h) hs.ne' hΛ
  refine ⟨ds, dK, dD, h1, h2, h3, ?_⟩
  rw [h4, tDc_cap _ _ _ _ hbr.le]; ring

/-- **E1 / (H.2), speed-set, arrival-on, adoption branch.** -/
theorem e1_S_arr_adopt (Λ : ℝ → ℝ) (L P mD TD s KM KD lam' : ℝ) (hs : 0 < s) (hKM : 0 < KM)
    (hΛ : HasDerivAt Λ lam' s) (hbr : KD / s < (1 - mD) * TD)
    (harr : KM / s < tDc mD TD KD s) (hhor : tDc mD TD KD s < L) :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => CSarr Λ L P mD TD x KM KD) ds s ∧
      HasDerivAt (fun x => CSarr Λ L P mD TD s x KD) dK KM ∧
      HasDerivAt (fun x => CSarr Λ L P mD TD s KM x) dD KD ∧
      s * ds = s * lam' * (tDc mD TD KD s - KM / s) - KM * dK - KD * dD := by
  obtain ⟨ds, dK, dD, h1, h2, h3, h4⟩ :=
    phi_euler (CSarr Λ L P mD TD) Λ (-1) 0 TD 0 0 (P * (L - TD))
      s KM KD lam' (Uadopt L mD TD) (isOpen_Uadopt L mD TD) (mem_Uadopt hs hKM hbr harr hhor)
      (fun x y z h => CSarr_adopt Λ L P mD TD x y z h) hs.ne' hΛ
  refine ⟨ds, dK, dD, h1, h2, h3, ?_⟩
  rw [h4, tDc_adopt _ _ _ _ hbr.le]; ring

/-- Speed-set ramp-on's open region, capability branch: `s > 0`, the branch, `0 < t_D < L`.  No
condition on `K_M`, which the ramp-on loss does not involve (Fix round 1). -/
def UrampCap (L mD TD : ℝ) : Set (ℝ × ℝ × ℝ) :=
  {q | 0 < q.1 ∧ (1 - mD) * TD * q.1 < q.2.2 ∧ 0 < q.2.2 + mD * TD * q.1 ∧
    q.2.2 + mD * TD * q.1 < L * q.1}

/-- Speed-set ramp-on's open region, adoption branch: `s > 0`, the branch, `0 < T_D < L`. -/
def UrampAdopt (L mD TD : ℝ) : Set (ℝ × ℝ × ℝ) :=
  {q | 0 < q.1 ∧ q.2.2 < (1 - mD) * TD * q.1 ∧ 0 < TD ∧ TD < L}

theorem isOpen_UrampCap (L mD TD : ℝ) : IsOpen (UrampCap L mD TD) := by
  unfold UrampCap
  repeat' apply IsOpen.and
  all_goals exact isOpen_lt (by fun_prop) (by fun_prop)

theorem isOpen_UrampAdopt (L mD TD : ℝ) : IsOpen (UrampAdopt L mD TD) := by
  unfold UrampAdopt
  repeat' apply IsOpen.and
  all_goals exact isOpen_lt (by fun_prop) (by fun_prop)

theorem mem_UrampCap {L mD TD s KM KD : ℝ} (hs : 0 < s) (hbr : (1 - mD) * TD < KD / s)
    (h0 : 0 < tDc mD TD KD s) (hhor : tDc mD TD KD s < L) : (s, KM, KD) ∈ UrampCap L mD TD := by
  rw [tDc_cap _ _ _ _ hbr.le] at h0 hhor
  have e : KD / s + mD * TD = (KD + mD * TD * s) / s := by field_simp
  rw [e] at h0 hhor
  exact ⟨hs, (lt_div_iff₀ hs).mp hbr,
    by have := mul_pos h0 hs; rwa [div_mul_cancel₀ _ hs.ne'] at this, (div_lt_iff₀ hs).mp hhor⟩

theorem mem_UrampAdopt {L mD TD s KM KD : ℝ} (hs : 0 < s) (hbr : KD / s < (1 - mD) * TD)
    (h0 : 0 < tDc mD TD KD s) (hhor : tDc mD TD KD s < L) : (s, KM, KD) ∈ UrampAdopt L mD TD := by
  rw [tDc_adopt _ _ _ _ hbr.le] at h0 hhor
  exact ⟨hs, (div_lt_iff₀ hs).mp hbr, h0, hhor⟩

theorem CSramp_rcap (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (h : (s, KM, KD) ∈ UrampCap L mD TD) :
    CSramp Λ L P mD TD s KM KD = Phi Λ 0 1 (mD * TD) 0 (-P) (P * (L - mD * TD)) s KM KD := by
  obtain ⟨hs, h1, h2, h3⟩ := h
  have hbr : (1 - mD) * TD < KD / s := (lt_div_iff₀ hs).mpr h1
  have e : KD / s + mD * TD = (KD + mD * TD * s) / s := by field_simp
  have h0 : 0 ≤ KD / s + mD * TD := by rw [e]; exact (div_pos h2 hs).le
  have hhor : KD / s + mD * TD ≤ L := by rw [e]; exact ((div_lt_iff₀ hs).mpr h3).le
  rw [CSramp, tDc_cap _ _ _ _ hbr.le, CRampClose_eq Λ L s _ P h0 hhor, Phi]
  field_simp
  ring

theorem CSramp_radopt (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ)
    (h : (s, KM, KD) ∈ UrampAdopt L mD TD) :
    CSramp Λ L P mD TD s KM KD = Phi Λ 0 0 TD 0 0 (P * (L - TD)) s KM KD := by
  obtain ⟨hs, h1, h2, h3⟩ := h
  have hbr : KD / s < (1 - mD) * TD := (div_lt_iff₀ hs).mpr h1
  rw [CSramp, tDc_adopt _ _ _ _ hbr.le, CRampClose_eq Λ L s _ P h2.le h3.le, Phi]
  field_simp
  ring

/-- **E1 / (H.2), speed-set, ramp-on, capability branch:** `ℓ_M = t_D`, wherever `0 < t_D < L`
off the clock kink.  No condition on `K_M` or on the order of `τ_M` and `t_D`. -/
theorem e1_S_ramp_cap (Λ : ℝ → ℝ) (L P mD TD s KM KD lam' : ℝ) (hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s) (hbr : (1 - mD) * TD < KD / s)
    (h0 : 0 < tDc mD TD KD s) (hhor : tDc mD TD KD s < L) :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => CSramp Λ L P mD TD x KM KD) ds s ∧
      HasDerivAt (fun x => CSramp Λ L P mD TD s x KD) dK KM ∧
      HasDerivAt (fun x => CSramp Λ L P mD TD s KM x) dD KD ∧
      s * ds = s * lam' * tDc mD TD KD s - KM * dK - KD * dD := by
  obtain ⟨ds, dK, dD, h1, h2, h3, h4⟩ :=
    phi_euler (CSramp Λ L P mD TD) Λ 0 1 (mD * TD) 0 (-P) (P * (L - mD * TD))
      s KM KD lam' (UrampCap L mD TD) (isOpen_UrampCap L mD TD) (mem_UrampCap hs hbr h0 hhor)
      (fun x y z h => CSramp_rcap Λ L P mD TD x y z h) hs.ne' hΛ
  refine ⟨ds, dK, dD, h1, h2, h3, ?_⟩
  rw [h4, tDc_cap _ _ _ _ hbr.le]; ring

/-- **E1 / (H.2), speed-set, ramp-on, adoption branch** (`0 < T_D < L`). -/
theorem e1_S_ramp_adopt (Λ : ℝ → ℝ) (L P mD TD s KM KD lam' : ℝ) (hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s) (hbr : KD / s < (1 - mD) * TD)
    (h0 : 0 < tDc mD TD KD s) (hhor : tDc mD TD KD s < L) :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => CSramp Λ L P mD TD x KM KD) ds s ∧
      HasDerivAt (fun x => CSramp Λ L P mD TD s x KD) dK KM ∧
      HasDerivAt (fun x => CSramp Λ L P mD TD s KM x) dD KD ∧
      s * ds = s * lam' * tDc mD TD KD s - KM * dK - KD * dD := by
  obtain ⟨ds, dK, dD, h1, h2, h3, h4⟩ :=
    phi_euler (CSramp Λ L P mD TD) Λ 0 0 TD 0 0 (P * (L - TD))
      s KM KD lam' (UrampAdopt L mD TD) (isOpen_UrampAdopt L mD TD)
      (mem_UrampAdopt hs hbr h0 hhor)
      (fun x y z h => CSramp_radopt Λ L P mD TD x y z h) hs.ne' hΛ
  refine ⟨ds, dK, dD, h1, h2, h3, ?_⟩
  rw [h4, tDc_adopt _ _ _ _ hbr.le]; ring

/-! ## E1, part 4: under convention B the identity fails — the printed instance -/

/-- Convention B's ramp-on closed form for the profile `h_M(c) = c/4` on the capability branch. -/
theorem CBramp_quarter_cap (L P mD TD s KM KD : ℝ) (h : (s, KM, KD) ∈ Ucap L mD TD) :
    CBramp (fun c => c / 4) L P mD TD s KM KD
      = s⁻¹ * (KM ^ 2 / 8) + KM / 4 * (KD / s + mD * TD - KM / s)
        + P * (L - (KD / s + mD * TD)) := by
  obtain ⟨hs, hKM, hbr, harr, hhor⟩ := of_mem_Ucap h
  have hI : (∫ c in (0:ℝ)..KM, c / 4) = KM ^ 2 / 8 := by
    rw [intervalIntegral.integral_div, integral_id]; ring
  rw [CBramp_eq_CLev _ L P mD TD s KM KD hs (by rw [tDc_cap _ _ _ _ hbr.le]; exact harr.le),
    tDc_cap _ _ _ _ hbr.le,
    CLev_eq _ KM L s _ P (by fun_prop : Continuous fun c : ℝ => c / 4) hs hKM.le harr.le hhor.le]
  rw [hI]

/-- **E1, the convention-B failure (A4a.7(vii), "Base W, B, ramp-on").**  At base W
(`s = 2`, `K_M = 4`, `K_D = 10`, `m_D = 0.5`, `T_D = 2`, `L = 10`, `h_M^post = 0.1`) with
`h_M(c) = c/4`, the defined convention-B loss has `∂C/∂s = −7/4` (so `s∂C/∂s = −3.5`),
`∂C/∂K_M = 1` and `∂C/∂K_D = 0.45`, and `−K_M∂C/∂K_M − K_D∂C/∂K_D = −8.5 ≠ −3.5`. -/
theorem e1_B_counterexample :
    HasDerivAt (fun x => CBramp (fun c => c / 4) 10 (1 / 10) (1 / 2) 2 x 4 10) (-7 / 4) 2 ∧
    HasDerivAt (fun x => CBramp (fun c => c / 4) 10 (1 / 10) (1 / 2) 2 2 x 10) 1 4 ∧
    HasDerivAt (fun x => CBramp (fun c => c / 4) 10 (1 / 10) (1 / 2) 2 2 4 x) (9 / 20) 10 ∧
    (2 : ℝ) * (-7 / 4) = -7 / 2 ∧ -((4 : ℝ) * 1) - 10 * (9 / 20) = -17 / 2 ∧
    (2 : ℝ) * (-7 / 4) ≠ -((4 : ℝ) * 1) - 10 * (9 / 20) := by
  have hp : ((2:ℝ), (4:ℝ), (10:ℝ)) ∈ Ucap 10 (1 / 2) 2 := by
    refine ⟨by norm_num, by norm_num, by norm_num, by norm_num, by norm_num⟩
  obtain ⟨h1, h2, h3⟩ := sections_eventually _ (isOpen_Ucap 10 (1 / 2) 2) hp
  refine ⟨?_, ?_, ?_, by norm_num, by norm_num, by norm_num⟩
  · have heq : (fun x => CBramp (fun c => c / 4) 10 (1 / 10) (1 / 2) 2 x 4 10)
        =ᶠ[𝓝 2] fun x => 7 * x⁻¹ + 19 / 10 := by
      filter_upwards [h1] with x hx
      have hx0 : x ≠ 0 := (of_mem_Ucap hx).1.ne'
      rw [CBramp_quarter_cap _ _ _ _ _ _ _ hx]
      field_simp
      ring
    have hd : HasDerivAt (fun x : ℝ => 7 * x⁻¹ + 19 / 10) (-7 / 4) 2 := by
      have := ((hasDerivAt_inv (two_ne_zero : (2:ℝ) ≠ 0)).const_mul 7).add_const (19 / 10)
      convert this using 1; norm_num
    exact hd.congr_of_eventuallyEq heq
  · have heq : (fun x => CBramp (fun c => c / 4) 10 (1 / 10) (1 / 2) 2 2 x 10)
        =ᶠ[𝓝 4] fun x => -(1 / 16) * x ^ 2 + 3 / 2 * x + 2 / 5 := by
      filter_upwards [h2] with x hx
      rw [CBramp_quarter_cap _ _ _ _ _ _ _ hx]
      ring
    have hd : HasDerivAt (fun x : ℝ => -(1 / 16) * x ^ 2 + 3 / 2 * x + 2 / 5) 1 4 := by
      have := (((hasDerivAt_pow 2 (4:ℝ)).const_mul (-(1 / 16))).add
        ((hasDerivAt_id' (4:ℝ)).const_mul (3 / 2))).add_const (2 / 5)
      convert this using 1; norm_num
    exact hd.congr_of_eventuallyEq heq
  · have heq : (fun x => CBramp (fun c => c / 4) 10 (1 / 10) (1 / 2) 2 2 4 x)
        =ᶠ[𝓝 10] fun x => 9 / 20 * x + 9 / 10 := by
      filter_upwards [h3] with x hx
      rw [CBramp_quarter_cap _ _ _ _ _ _ _ hx]
      ring
    have hd : HasDerivAt (fun x : ℝ => 9 / 20 * x + 9 / 10) (9 / 20) 10 := by
      have := ((hasDerivAt_id' (10:ℝ)).const_mul (9 / 20)).add_const (9 / 10)
      convert this using 1; norm_num
    exact hd.congr_of_eventuallyEq heq

/-! ## E2: the arrival-on `K_D` coefficient -/

/-- **E2, the speed marginal**, from `r3_hasDerivAt` with the actual clock on the own-distance
capability branch (`t_D′ = −K_D/s²`). -/
theorem e2_speed_marginal (Λ : ℝ → ℝ) (L P mD TD s KM KD lam' : ℝ) (hKM : 0 ≤ KM) (hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s) (hbr : (1 - mD) * TD < KD / s)
    (harr : KM / s < tDc mD TD KD s) (hhor : tDc mD TD KD s < L) :
    HasDerivAt (fun x => CSarr Λ L P mD TD x KM KD)
      (lam' * (tDc mD TD KD s - KM / s) + Λ s * (-(KD / s ^ 2) + KM / s ^ 2)
        + P * -(-(KD / s ^ 2))) s :=
  r3_hasDerivAt Λ (fun x => tDc mD TD KD x) L KM s P lam' (-(KD / s ^ 2)) hKM hs hΛ
    (tDc_hasDerivAt_cap mD TD KD s hs hbr) harr hhor

/-- **E2, the bracket.**  `s·C_M′ = Λ_Mε_Λ(m_DT_D − τ_M) + Λ_Mτ_M + (K_D/s)[Λ_M(ε_Λ − 1) + h_M^post]`,
with `Λ_Mε_Λ` written `s·Λ′`, for the defined loss's actual derivative. -/
theorem e2_bracket (Λ : ℝ → ℝ) (L P mD TD s KM KD lam' : ℝ) (hKM : 0 ≤ KM) (hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s) (hbr : (1 - mD) * TD < KD / s)
    (harr : KM / s < tDc mD TD KD s) (hhor : tDc mD TD KD s < L) :
    s * deriv (fun x => CSarr Λ L P mD TD x KM KD) s
      = s * lam' * (mD * TD - KM / s) + Λ s * (KM / s) + KD / s * (s * lam' - Λ s + P) := by
  rw [(e2_speed_marginal Λ L P mD TD s KM KD lam' hKM hs hΛ hbr harr hhor).deriv,
    tDc_cap _ _ _ _ hbr.le]
  field_simp
  ring

/-- **E2, the coefficient.**  `∂(s∂C_M/∂s)/∂K_D = [Λ_M(ε_Λ − 1) + h_M^post]/s`, written
`(sΛ′ − Λ + h_M^post)/s`: the derivative in `K_D` of the function `K_D ↦ s·∂C_M/∂s` of the
defined arrival-on loss, with `s`, `K_M`, `m_D`, `T_D`, the hazard and the residual fixed. -/
theorem e2_KD_coefficient (Λ : ℝ → ℝ) (L P mD TD s KM KD lam' : ℝ) (hKM : 0 ≤ KM) (hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s) (hbr : (1 - mD) * TD < KD / s)
    (harr : KM / s < tDc mD TD KD s) (hhor : tDc mD TD KD s < L) :
    HasDerivAt (fun kd => s * deriv (fun x => CSarr Λ L P mD TD x KM kd) s)
      ((s * lam' - Λ s + P) / s) KD := by
  rw [tDc_cap _ _ _ _ hbr.le] at harr hhor
  have ev1 : ∀ᶠ kd in 𝓝 KD, (1 - mD) * TD < kd / s :=
    (Continuous.continuousAt (by fun_prop : Continuous fun kd : ℝ => kd / s)).eventually
      ((isOpen_Ioi.eventually_mem hbr).mono fun _ h => h)
  have ev2 : ∀ᶠ kd in 𝓝 KD, KM / s < kd / s + mD * TD :=
    (Continuous.continuousAt (by fun_prop : Continuous fun kd : ℝ => kd / s + mD * TD)).eventually
      ((isOpen_Ioi.eventually_mem harr).mono fun _ h => h)
  have ev3 : ∀ᶠ kd in 𝓝 KD, kd / s + mD * TD < L :=
    (Continuous.continuousAt (by fun_prop : Continuous fun kd : ℝ => kd / s + mD * TD)).eventually
      ((isOpen_Iio.eventually_mem hhor).mono fun _ h => h)
  have heq : (fun kd => s * deriv (fun x => CSarr Λ L P mD TD x KM kd) s) =ᶠ[𝓝 KD]
      fun kd => s * lam' * (mD * TD - KM / s) + Λ s * (KM / s) + kd / s * (s * lam' - Λ s + P) := by
    filter_upwards [ev1, ev2, ev3] with kd h1 h2 h3
    rw [← tDc_cap _ _ _ _ h1.le] at h2 h3
    exact e2_bracket Λ L P mD TD s KM kd lam' hKM hs hΛ h1 h2 h3
  have hd : HasDerivAt
      (fun kd : ℝ => s * lam' * (mD * TD - KM / s) + Λ s * (KM / s) + kd / s * (s * lam' - Λ s + P))
      ((s * lam' - Λ s + P) / s) KD := by
    have := (((hasDerivAt_id' KD).div_const s).mul_const (s * lam' - Λ s + P)).const_add
      (s * lam' * (mD * TD - KM / s) + Λ s * (KM / s))
    convert this using 1
    ring
  exact hd.congr_of_eventuallyEq heq

/-- **E2, affine between two admissible values of `K_D`.**  Both on the own-distance
capability branch with `τ_M < t_D < L`; everything else fixed. -/
theorem e2_affine (Λ : ℝ → ℝ) (L P mD TD s KM KD₁ KD₂ lam' : ℝ) (hKM : 0 ≤ KM) (hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s)
    (hbr₁ : (1 - mD) * TD < KD₁ / s) (harr₁ : KM / s < tDc mD TD KD₁ s)
    (hhor₁ : tDc mD TD KD₁ s < L)
    (hbr₂ : (1 - mD) * TD < KD₂ / s) (harr₂ : KM / s < tDc mD TD KD₂ s)
    (hhor₂ : tDc mD TD KD₂ s < L) :
    s * deriv (fun x => CSarr Λ L P mD TD x KM KD₂) s
        - s * deriv (fun x => CSarr Λ L P mD TD x KM KD₁) s
      = (s * lam' - Λ s + P) / s * (KD₂ - KD₁) := by
  rw [e2_bracket Λ L P mD TD s KM KD₂ lam' hKM hs hΛ hbr₂ harr₂ hhor₂,
    e2_bracket Λ L P mD TD s KM KD₁ lam' hKM hs hΛ hbr₁ harr₁ hhor₁]
  ring

/-- The coefficient in the paper's elasticity notation, for `Λ_M ≠ 0`. -/
theorem e2_coefficient_eps (Λ : ℝ → ℝ) (P s lam' : ℝ) (hΛ0 : Λ s ≠ 0) :
    (s * lam' - Λ s + P) / s = (Λ s * (s * lam' / Λ s - 1) + P) / s := by
  field_simp

/-- The ramp-on speed derivative with closure at a differentiable `t_D(s)`. -/
theorem rampClose_hasDerivAt (Λ TDf : ℝ → ℝ) (L s P lam' tD' : ℝ) (hΛ : HasDerivAt Λ lam' s)
    (hTD : HasDerivAt TDf tD' s) (h0 : 0 < TDf s) (hL : TDf s < L) :
    HasDerivAt (fun x => CRampClose Λ L x (TDf x) P) (lam' * TDf s + Λ s * tD' + P * -tD') s := by
  have hc := hTD.continuousAt
  have hev : (fun x => CRampClose Λ L x (TDf x) P) =ᶠ[𝓝 s]
      fun x => Λ x * TDf x + P * (L - TDf x) := by
    filter_upwards [hc.eventually ((isOpen_Ioi.eventually_mem h0).mono fun _ h => h),
      hc.eventually ((isOpen_Iio.eventually_mem hL).mono fun _ h => h)] with x hx0 hxL
    exact CRampClose_eq Λ L x (TDf x) P (le_of_lt hx0) hxL.le
  exact ((hΛ.mul hTD).add ((hTD.const_sub L).const_mul P)).congr_of_eventuallyEq hev

/-- **E2, "the same coefficient as under ramp-on".**  The ramp-on bracket
`Ξ_s = Λ_Mε_Λm_DT_D + (K_D/s)[Λ_M(ε_Λ − 1) + h_M^post]` of the defined ramp-on loss. -/
theorem e2_ramp_bracket (Λ : ℝ → ℝ) (L P mD TD s KM KD lam' : ℝ) (hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s) (hbr : (1 - mD) * TD < KD / s)
    (h0 : 0 < tDc mD TD KD s) (hhor : tDc mD TD KD s < L) :
    s * deriv (fun x => CSramp Λ L P mD TD x KM KD) s
      = s * lam' * (mD * TD) + KD / s * (s * lam' - Λ s + P) := by
  have hd := rampClose_hasDerivAt Λ (fun x => tDc mD TD KD x) L s P lam' (-(KD / s ^ 2)) hΛ
    (tDc_hasDerivAt_cap mD TD KD s hs hbr) h0 hhor
  rw [show (fun x => CSramp Λ L P mD TD x KM KD)
      = fun x => CRampClose Λ L x (tDc mD TD KD x) P from rfl, hd.deriv, tDc_cap _ _ _ _ hbr.le]
  field_simp
  ring

/-- **E2, the ramp-on coefficient**, which is the arrival-on one of `e2_KD_coefficient`. -/
theorem e2_ramp_KD_coefficient (Λ : ℝ → ℝ) (L P mD TD s KM KD lam' : ℝ) (hs : 0 < s)
    (hΛ : HasDerivAt Λ lam' s) (hbr : (1 - mD) * TD < KD / s)
    (h0 : 0 < tDc mD TD KD s) (hhor : tDc mD TD KD s < L) :
    HasDerivAt (fun kd => s * deriv (fun x => CSramp Λ L P mD TD x KM kd) s)
      ((s * lam' - Λ s + P) / s) KD := by
  rw [tDc_cap _ _ _ _ hbr.le] at h0 hhor
  have ev1 : ∀ᶠ kd in 𝓝 KD, (1 - mD) * TD < kd / s :=
    (Continuous.continuousAt (by fun_prop : Continuous fun kd : ℝ => kd / s)).eventually
      ((isOpen_Ioi.eventually_mem hbr).mono fun _ h => h)
  have ev2 : ∀ᶠ kd in 𝓝 KD, 0 < kd / s + mD * TD :=
    (Continuous.continuousAt (by fun_prop : Continuous fun kd : ℝ => kd / s + mD * TD)).eventually
      ((isOpen_Ioi.eventually_mem h0).mono fun _ h => h)
  have ev3 : ∀ᶠ kd in 𝓝 KD, kd / s + mD * TD < L :=
    (Continuous.continuousAt (by fun_prop : Continuous fun kd : ℝ => kd / s + mD * TD)).eventually
      ((isOpen_Iio.eventually_mem hhor).mono fun _ h => h)
  have heq : (fun kd => s * deriv (fun x => CSramp Λ L P mD TD x KM kd) s) =ᶠ[𝓝 KD]
      fun kd => s * lam' * (mD * TD) + kd / s * (s * lam' - Λ s + P) := by
    filter_upwards [ev1, ev2, ev3] with kd h1 h2 h3
    rw [← tDc_cap _ _ _ _ h1.le] at h2 h3
    exact e2_ramp_bracket Λ L P mD TD s KM kd lam' hs hΛ h1 h2 h3
  have hd : HasDerivAt (fun kd : ℝ => s * lam' * (mD * TD) + kd / s * (s * lam' - Λ s + P))
      ((s * lam' - Λ s + P) / s) KD := by
    have := (((hasDerivAt_id' KD).div_const s).mul_const (s * lam' - Λ s + P)).const_add
      (s * lam' * (mD * TD))
    convert this using 1
    ring
  exact hd.congr_of_eventuallyEq heq

/-! ## E3: one-sided derivatives at `t_D = τ_M` on the own-distance clock

The limiting variable is the speed `s`, with `K_M`, `K_D`, `m_D`, `T_D`, `L`, the residual and the
hazard function fixed.  At the boundary speed `s₀` (`t_D(s₀) = τ_M(s₀)`) on the capability branch,
`t_D − τ_M = m_DT_D(s − s₀)/s`, so for `m_DT_D > 0` the positive-exposure side is `s ↓ s₀` and the
defence-before-arrival side is `s ↑ s₀`.  Each one-sided derivative is stated as the printed
scaled value divided by `s₀`. -/

/-- **E3, the positive-exposure side.**  Within `{s : τ_M(s) < t_D(s)}`, the derivative at `s₀` is
`[Λ_Mτ_M − τ_D(Λ_M − h_M^post)]/s₀`. -/
theorem e3_posExposure (Λ : ℝ → ℝ) (L P mD TD s₀ KM KD lam' : ℝ) (hs : 0 < s₀) (hKM : 0 ≤ KM)
    (hΛ : HasDerivAt Λ lam' s₀) (hbr : (1 - mD) * TD < KD / s₀)
    (hbd : tDc mD TD KD s₀ = KM / s₀) (hL : KM / s₀ < L) :
    HasDerivWithinAt (fun s => CSarr Λ L P mD TD s KM KD)
      ((Λ s₀ * (KM / s₀) - KD / s₀ * (Λ s₀ - P)) / s₀) {s | KM / s < tDc mD TD KD s} s₀ := by
  have hTD := tDc_hasDerivAt_cap mD TD KD s₀ hs hbr
  have hKx : HasDerivAt (fun x : ℝ => KM / x) (-(KM / s₀ ^ 2)) s₀ := by
    have h := (hasDerivAt_inv hs.ne').const_mul KM
    simp only [div_eq_mul_inv]
    convert h using 1; ring
  have hg := (hΛ.mul (hTD.sub hKx)).add ((hTD.const_sub L).const_mul P)
  have hpos : ∀ᶠ s in 𝓝 s₀, (0:ℝ) < s := (isOpen_Ioi.eventually_mem hs).mono fun _ h => h
  have hL' : tDc mD TD KD s₀ < L := by rw [hbd]; exact hL
  have hlt : ∀ᶠ s in 𝓝 s₀, tDc mD TD KD s < L :=
    hTD.continuousAt.eventually ((isOpen_Iio.eventually_mem hL').mono fun _ h => h)
  have hev : (fun s => CSarr Λ L P mD TD s KM KD) =ᶠ[𝓝[{s | KM / s < tDc mD TD KD s}] s₀]
      fun s => Λ s * (tDc mD TD KD s - KM / s) + P * (L - tDc mD TD KD s) := by
    rw [EventuallyEq, eventually_nhdsWithin_iff]
    filter_upwards [hpos, hlt] with s hs0 hsL hmem
    exact CArrClose_eq Λ KM L s _ P (by positivity) (le_of_lt hmem) hsL.le
  have hx : CSarr Λ L P mD TD s₀ KM KD
      = Λ s₀ * (tDc mD TD KD s₀ - KM / s₀) + P * (L - tDc mD TD KD s₀) :=
    CArrClose_eq Λ KM L s₀ _ P (by positivity) hbd.ge hL'.le
  have := hg.hasDerivWithinAt (s := {s | KM / s < tDc mD TD KD s}).congr_of_eventuallyEq hev hx
  convert this using 1
  simp only [Pi.sub_apply]
  rw [hbd, sub_self]
  field_simp
  ring

/-- **E3, the defence-before-arrival side**, under A0's modelling choice: within
`{s : t_D(s) < τ_M(s)}` the loss is `h_M^post(L − τ_M)` and the derivative at `s₀` is
`h_M^post·τ_M/s₀`. -/
theorem e3_defenceFirst (Λ : ℝ → ℝ) (L P mD TD s₀ KM KD : ℝ) (hs : 0 < s₀) (hKM : 0 ≤ KM)
    (hbd : tDc mD TD KD s₀ = KM / s₀) (hL : KM / s₀ < L) :
    HasDerivWithinAt (fun s => CSarr Λ L P mD TD s KM KD)
      (P * (KM / s₀) / s₀) {s | tDc mD TD KD s < KM / s} s₀ := by
  have hKx : HasDerivAt (fun x : ℝ => KM / x) (-(KM / s₀ ^ 2)) s₀ := by
    have h := (hasDerivAt_inv hs.ne').const_mul KM
    simp only [div_eq_mul_inv]
    convert h using 1; ring
  have hg := (hKx.const_sub L).const_mul P
  have hpos : ∀ᶠ s in 𝓝 s₀, (0:ℝ) < s := (isOpen_Ioi.eventually_mem hs).mono fun _ h => h
  have hlt : ∀ᶠ s in 𝓝 s₀, KM / s < L :=
    (continuousAt_const.div continuousAt_id hs.ne').eventually
      ((isOpen_Iio.eventually_mem hL).mono fun _ h => h)
  have hev : (fun s => CSarr Λ L P mD TD s KM KD) =ᶠ[𝓝[{s | tDc mD TD KD s < KM / s}] s₀]
      fun s => P * (L - KM / s) := by
    rw [EventuallyEq, eventually_nhdsWithin_iff]
    filter_upwards [hpos, hlt] with s hs0 hsL hmem
    exact CArrClose_eq_before Λ KM L s _ P (by positivity) (le_of_lt hmem) hsL.le
  have hx : CSarr Λ L P mD TD s₀ KM KD = P * (L - KM / s₀) :=
    CArrClose_eq_before Λ KM L s₀ _ P (by positivity) hbd.le hL.le
  have := hg.hasDerivWithinAt (s := {s | tDc mD TD KD s < KM / s}).congr_of_eventuallyEq hev hx
  convert this using 1
  field_simp

/-- **E3, the gap.**  The two one-sided scaled values differ by `(Λ_M − h_M^post)m_DT_D`, because
`τ_M − τ_D = m_DT_D` on the boundary. -/
theorem e3_gap (Λs P mD TD s₀ KM KD : ℝ) (hbd' : KM / s₀ = KD / s₀ + mD * TD) :
    (Λs * (KM / s₀) - KD / s₀ * (Λs - P)) - P * (KM / s₀) = (Λs - P) * (mD * TD) := by
  rw [hbd']; ring

/-- On the capability branch the boundary condition `t_D = τ_M` is `τ_M = τ_D + m_DT_D`. -/
theorem e3_boundary (mD TD s₀ KM KD : ℝ) (hbr : (1 - mD) * TD < KD / s₀)
    (hbd : tDc mD TD KD s₀ = KM / s₀) : KM / s₀ = KD / s₀ + mD * TD := by
  rw [← hbd, tDc_cap _ _ _ _ hbr.le]

/-- **E3, the sides accumulate, and which side is which.**  For `m_DT_D > 0`, every speed above
`s₀` has positive exposure, and every speed just below it has the defence first. -/
theorem e3_sides (mD TD s₀ KM KD : ℝ) (hs : 0 < s₀) (hbr : (1 - mD) * TD < KD / s₀)
    (hbd : tDc mD TD KD s₀ = KM / s₀) (hmT : 0 < mD * TD) :
    (∀ᶠ s in 𝓝[>] s₀, KM / s < tDc mD TD KD s) ∧ (∀ᶠ s in 𝓝[<] s₀, tDc mD TD KD s < KM / s) := by
  have hb := e3_boundary mD TD s₀ KM KD hbr hbd
  have hKMe : KM = KD + mD * TD * s₀ := by
    have := hb; field_simp at this; linarith
  have key : ∀ s : ℝ, 0 < s → KD / s + mD * TD - KM / s = mD * TD * (s - s₀) / s := by
    intro s hs'; rw [hKMe]; field_simp; ring
  constructor
  · refine eventually_nhdsWithin_of_forall fun s hs' => ?_
    have hs'' : (0:ℝ) < s := lt_trans hs hs'
    have h1 : KD / s + mD * TD ≤ tDc mD TD KD s := by
      rw [tDc]; linarith [le_max_left (KD / s) ((1 - mD) * TD)]
    have h2 : 0 < mD * TD * (s - s₀) / s := div_pos (mul_pos hmT (sub_pos.mpr hs')) hs''
    linarith [key s hs'']
  · have hcd : ContinuousAt (fun x : ℝ => KD / x) s₀ :=
      continuousAt_const.div continuousAt_id hs.ne'
    have hev : ∀ᶠ x in 𝓝 s₀, (1 - mD) * TD < KD / x :=
      hcd.eventually ((isOpen_Ioi.eventually_mem hbr).mono (fun x hx => hx))
    have hpos : ∀ᶠ s in 𝓝 s₀, (0:ℝ) < s := (isOpen_Ioi.eventually_mem hs).mono fun _ h => h
    rw [eventually_nhdsWithin_iff]
    filter_upwards [hev, hpos] with s h1 h0 hs'
    rw [tDc_cap _ _ _ _ h1.le]
    have h2 : mD * TD * (s - s₀) / s < 0 :=
      div_neg_of_neg_of_pos (mul_neg_of_pos_of_neg hmT (sub_neg.mpr hs')) h0
    linarith [key s h0]

/-- **E3, each claimed side is a genuine side:** `s₀` is an accumulation point of both. -/
theorem e3_accumulate (mD TD s₀ KM KD : ℝ) (hs : 0 < s₀) (hbr : (1 - mD) * TD < KD / s₀)
    (hbd : tDc mD TD KD s₀ = KM / s₀) (hmT : 0 < mD * TD) :
    (𝓝[{s | KM / s < tDc mD TD KD s}] s₀).NeBot ∧
      (𝓝[{s | tDc mD TD KD s < KM / s}] s₀).NeBot := by
  obtain ⟨h1, h2⟩ := e3_sides mD TD s₀ KM KD hs hbr hbd hmT
  exact ⟨NeBot.mono inferInstance (nhdsWithin_le_of_mem h1),
    NeBot.mono inferInstance (nhdsWithin_le_of_mem h2)⟩

/-- **E3, the right derivative** (`s ↓ s₀`, positive exposure). -/
theorem e3_right (Λ : ℝ → ℝ) (L P mD TD s₀ KM KD lam' : ℝ) (hs : 0 < s₀) (hKM : 0 ≤ KM)
    (hΛ : HasDerivAt Λ lam' s₀) (hbr : (1 - mD) * TD < KD / s₀)
    (hbd : tDc mD TD KD s₀ = KM / s₀) (hL : KM / s₀ < L) (hmT : 0 < mD * TD) :
    HasDerivWithinAt (fun s => CSarr Λ L P mD TD s KM KD)
      ((Λ s₀ * (KM / s₀) - KD / s₀ * (Λ s₀ - P)) / s₀) (Ioi s₀) s₀ :=
  (e3_posExposure Λ L P mD TD s₀ KM KD lam' hs hKM hΛ hbr hbd hL).mono_of_mem_nhdsWithin
    (e3_sides mD TD s₀ KM KD hs hbr hbd hmT).1

/-- **E3, the left derivative** (`s ↑ s₀`, defence before arrival). -/
theorem e3_left (Λ : ℝ → ℝ) (L P mD TD s₀ KM KD : ℝ) (hs : 0 < s₀) (hKM : 0 ≤ KM)
    (hbr : (1 - mD) * TD < KD / s₀)
    (hbd : tDc mD TD KD s₀ = KM / s₀) (hL : KM / s₀ < L) (hmT : 0 < mD * TD) :
    HasDerivWithinAt (fun s => CSarr Λ L P mD TD s KM KD) (P * (KM / s₀) / s₀) (Iio s₀) s₀ :=
  (e3_defenceFirst Λ L P mD TD s₀ KM KD hs hKM hbd hL).mono_of_mem_nhdsWithin
    (e3_sides mD TD s₀ KM KD hs hbr hbd hmT).2

/-- **E3, the kink criterion.**  With `m_DT_D > 0`, the defined loss is differentiable at the
boundary exactly when `Λ_M = h_M^post`; otherwise the boundary is a kink. -/
theorem e3_kink_iff (Λ : ℝ → ℝ) (L P mD TD s₀ KM KD lam' : ℝ) (hs : 0 < s₀) (hKM : 0 ≤ KM)
    (hΛ : HasDerivAt Λ lam' s₀) (hbr : (1 - mD) * TD < KD / s₀)
    (hbd : tDc mD TD KD s₀ = KM / s₀) (hL : KM / s₀ < L) (hmT : 0 < mD * TD) :
    DifferentiableAt ℝ (fun s => CSarr Λ L P mD TD s KM KD) s₀ ↔ Λ s₀ = P := by
  have hR := e3_right Λ L P mD TD s₀ KM KD lam' hs hKM hΛ hbr hbd hL hmT
  have hLft := e3_left Λ L P mD TD s₀ KM KD hs hKM hbr hbd hL hmT
  have hgap := e3_gap (Λ s₀) P mD TD s₀ KM KD (e3_boundary mD TD s₀ KM KD hbr hbd)
  constructor
  · intro hd
    have h := hd.hasDerivAt
    have r := (uniqueDiffWithinAt_Ioi s₀).eq_deriv _ h.hasDerivWithinAt hR
    have l := (uniqueDiffWithinAt_Iio s₀).eq_deriv _ h.hasDerivWithinAt hLft
    have e : Λ s₀ * (KM / s₀) - KD / s₀ * (Λ s₀ - P) = P * (KM / s₀) :=
      (div_left_inj' hs.ne').mp (r.symm.trans l)
    have h0 : (Λ s₀ - P) * (mD * TD) = 0 := by rw [← hgap, e, sub_self]
    rcases mul_eq_zero.mp h0 with h1 | h1
    · linarith
    · exact absurd h1 hmT.ne'
  · intro hΛP
    have e : (Λ s₀ * (KM / s₀) - KD / s₀ * (Λ s₀ - P)) / s₀ = P * (KM / s₀) / s₀ := by
      congr 1
      have : (Λ s₀ - P) * (mD * TD) = 0 := by rw [hΛP, sub_self, zero_mul]
      linarith
    rw [e] at hR
    have hR' := hasDerivWithinAt_Ioi_iff_Ici.mp hR
    have hL' := hasDerivWithinAt_Iio_iff_Iic.mp hLft
    have hU := hL'.union hR'
    rw [Iic_union_Ici, hasDerivWithinAt_univ] at hU
    exact hU.differentiableAt

/-- **E3, the degenerate case `K_D = K_M`, `m_DT_D = 0`: an ordinary derivative.**  Here
`t_D ≡ τ_M` on a neighbourhood, the plateau has zero length on both sides, and the defined loss is
differentiable at `s₀` with `s·C_M′ = h_M^post·τ_M` — not a pair of one-sided values over an
empty side. -/
theorem e3_degenerate (Λ : ℝ → ℝ) (L P mD TD s₀ K : ℝ) (hs : 0 < s₀) (hK : 0 ≤ K)
    (hmT : mD * TD = 0) (hbr : (1 - mD) * TD < K / s₀) (hL : K / s₀ < L) :
    HasDerivAt (fun s => CSarr Λ L P mD TD s K K) (P * (K / s₀) / s₀) s₀ := by
  have hKx : HasDerivAt (fun x : ℝ => K / x) (-(K / s₀ ^ 2)) s₀ := by
    have h := (hasDerivAt_inv hs.ne').const_mul K
    simp only [div_eq_mul_inv]
    convert h using 1; ring
  have hg := (hKx.const_sub L).const_mul P
  have hcd : ContinuousAt (fun x : ℝ => K / x) s₀ := continuousAt_const.div continuousAt_id hs.ne'
  have hev1 : ∀ᶠ x in 𝓝 s₀, (1 - mD) * TD < K / x :=
    hcd.eventually ((isOpen_Ioi.eventually_mem hbr).mono (fun x hx => hx))
  have hev2 : ∀ᶠ x in 𝓝 s₀, K / x < L :=
    hcd.eventually ((isOpen_Iio.eventually_mem hL).mono (fun x hx => hx))
  have hpos : ∀ᶠ s in 𝓝 s₀, (0:ℝ) < s := (isOpen_Ioi.eventually_mem hs).mono fun _ h => h
  have hev : (fun s => CSarr Λ L P mD TD s K K) =ᶠ[𝓝 s₀] fun s => P * (L - K / s) := by
    filter_upwards [hev1, hev2, hpos] with s h1 h2 h0
    have ht : tDc mD TD K s = K / s := by rw [tDc_cap _ _ _ _ h1.le, hmT, add_zero]
    rw [CSarr, ht]
    exact CArrClose_eq_before Λ K L s _ P (by positivity) le_rfl h2.le
  convert hg.congr_of_eventuallyEq hev using 1
  field_simp

/-! ## E4: the additive mixed form on the plateau -/

/-- §4a.2's gated level profile: zero below `K_M`, `h_M(K_M)` at it. -/
noncomputable def gatedLevel (h : ℝ → ℝ) (K c : ℝ) : ℝ := if c < K then 0 else h K

/-- Additive mixed hazard, no closure, **ramp-on**: `h_M(c(t)) + Λ_M(s)` from date 0. -/
noncomputable def CMixAddRamp (h Λ : ℝ → ℝ) (K L s : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, (h (min (s * t) K) + Λ s)

/-- Additive mixed hazard, no closure, **arrival-on with only the speed component gated**. -/
noncomputable def CMixAddArrSpeed (h Λ : ℝ → ℝ) (K L s : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, (h (min (s * t) K) + step 0 (Λ s) (K / s) t)

/-- Additive mixed hazard, no closure, **arrival-on with both components gated**. -/
noncomputable def CMixAddArrBoth (h Λ : ℝ → ℝ) (K L s : ℝ) : ℝ :=
  ∫ t in (0:ℝ)..L, (gatedLevel h K (min (s * t) K) + step 0 (Λ s) (K / s) t)

/-- On the capability path the gated profile is the arrival-on step at the plateau level. -/
theorem gatedLevel_path (h : ℝ → ℝ) (K s t : ℝ) (hs : 0 < s) :
    gatedLevel h K (min (s * t) K) = step 0 (h K) (K / s) t := by
  unfold gatedLevel step
  by_cases ht : t < K / s
  · have hst : s * t < K := by
      calc s * t < s * (K / s) := mul_lt_mul_of_pos_left ht hs
      _ = K := mul_div_cancel₀ K hs.ne'
    simp [ht, min_eq_left hst.le, hst]
  · have hst : K ≤ s * t := by
      calc K = s * (K / s) := (mul_div_cancel₀ K hs.ne').symm
      _ ≤ s * t := mul_le_mul_of_nonneg_left (not_lt.mp ht) hs.le
    simp [ht, min_eq_right hst]

/-! ### The plateau closed form for a merely integrable level profile

`LevelSet.lean` proves the plateau closed form for a continuous profile.  A4a.5 states E4 for a
level component that is nonnegative and nondecreasing, and Lemma L asks only that `h_M` be
integrable on `[0, K_M]`, so the closed form and the R2 derivative are re-proved here under
integrability alone, about the same `CLevPlateau`.  No continuity is assumed anywhere in E4. -/

theorem path_intervalIntegrable (h : ℝ → ℝ) (K L s : ℝ) (hi : IntervalIntegrable h volume 0 K)
    (hs : 0 < s) (hK : 0 ≤ K) (hwin : K / s ≤ L) :
    IntervalIntegrable (fun t : ℝ => h (min (s * t) K)) volume 0 (K / s) ∧
      IntervalIntegrable (fun t : ℝ => h (min (s * t) K)) volume (K / s) L := by
  have hτ : 0 ≤ K / s := by positivity
  have h1 : IntervalIntegrable (fun x => h (s * x)) volume 0 (K / s) := by
    have := hi.comp_mul_left (c := s)
    rwa [zero_div] at this
  constructor
  · rw [intervalIntegrable_iff_integrableOn_Ioc_of_le hτ] at h1 ⊢
    refine h1.congr_fun (fun t ht => ?_) measurableSet_Ioc
    have : s * t ≤ K := by
      calc s * t ≤ s * (K / s) := mul_le_mul_of_nonneg_left ht.2 hs.le
      _ = K := mul_div_cancel₀ K hs.ne'
    simp [min_eq_left this]
  · have hc : IntervalIntegrable (fun _ : ℝ => h K) volume (K / s) L := intervalIntegrable_const
    rw [intervalIntegrable_iff_integrableOn_Ioc_of_le hwin] at hc ⊢
    refine hc.congr_fun (fun t ht => ?_) measurableSet_Ioc
    have : K ≤ s * t := by
      calc K = s * (K / s) := (mul_div_cancel₀ K hs.ne').symm
      _ ≤ s * t := mul_le_mul_of_nonneg_left ht.1.le hs.le
    simp [min_eq_right this]

/-- The plateau closed form `C = s⁻¹∫_0^{K}h + h(K)(L − K/s)`, for an integrable profile. -/
theorem CLevPlateau_eq_int (h : ℝ → ℝ) (K L s : ℝ) (hi : IntervalIntegrable h volume 0 K)
    (hs : 0 < s) (hK : 0 ≤ K) (hwin : K / s ≤ L) :
    CLevPlateau h K L s = s⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (L - K / s) := by
  have hτ : 0 ≤ K / s := by positivity
  obtain ⟨hramp, hplat⟩ := path_intervalIntegrable h K L s hi hs hK hwin
  have h1 : (∫ t in (0:ℝ)..(K / s), h (min (s * t) K)) = s⁻¹ * ∫ c in (0:ℝ)..K, h c := by
    rw [integral_congr_Ioo_of_le hτ (g := fun t : ℝ => h (s * t)) ?_]
    · exact ramp_integral h K s hs.ne'
    · intro t ht
      have : s * t ≤ K := by
        calc s * t ≤ s * (K / s) := mul_le_mul_of_nonneg_left ht.2.le hs.le
        _ = K := mul_div_cancel₀ K hs.ne'
      simp [min_eq_left this]
  have h2 : (∫ t in (K / s)..L, h (min (s * t) K)) = h K * (L - K / s) := by
    rw [integral_congr_Ioo_of_le hwin (g := fun _ : ℝ => h K) ?_,
      intervalIntegral.integral_const, smul_eq_mul]
    · ring
    · intro t ht
      have : K ≤ s * t := by
        calc K = s * (K / s) := (mul_div_cancel₀ K hs.ne').symm
        _ ≤ s * t := mul_le_mul_of_nonneg_left ht.1.le hs.le
      simp [min_eq_right this]
  rw [CLevPlateau, ← integral_add_adjacent_intervals hramp hplat, h1, h2]

/-- `h̄_M ≤ h_M(K_M)` for a profile nondecreasing on `[0, K_M]`, with no continuity. -/
theorem bracket_nonneg_of_monotoneOn (h : ℝ → ℝ) (K : ℝ) (hK : 0 < K)
    (hmono : MonotoneOn h (Icc 0 K)) : 0 ≤ h K - hbar h K := by
  have hi : IntervalIntegrable h volume 0 K :=
    MonotoneOn.intervalIntegrable (by rwa [uIcc_of_le hK.le])
  have hle : (∫ c in (0:ℝ)..K, h c) ≤ ∫ c in (0:ℝ)..K, h K :=
    intervalIntegral.integral_mono_on hK.le hi intervalIntegrable_const
      (fun x hx => hmono hx (right_mem_Icc.mpr hK.le) hx.2)
  rw [intervalIntegral.integral_const, smul_eq_mul, sub_zero] at hle
  rw [sub_nonneg, hbar, div_le_iff₀ hK]
  linarith [mul_comm K (h K)]

theorem CMixAddRamp_eq (h Λ : ℝ → ℝ) (K L s : ℝ) (hi : IntervalIntegrable h volume 0 K)
    (hs : 0 < s) (hK : 0 ≤ K) (hwin : K / s ≤ L) :
    CMixAddRamp h Λ K L s = CLevPlateau h K L s + Λ s * L := by
  obtain ⟨h1, h2⟩ := path_intervalIntegrable h K L s hi hs hK hwin
  rw [CMixAddRamp, intervalIntegral.integral_add (h1.trans h2) intervalIntegrable_const,
    intervalIntegral.integral_const, smul_eq_mul, CLevPlateau]
  ring

theorem CMixAddArrSpeed_eq (h Λ : ℝ → ℝ) (K L s : ℝ) (hi : IntervalIntegrable h volume 0 K)
    (hs : 0 < s) (hK : 0 ≤ K) (hwin : K / s ≤ L) :
    CMixAddArrSpeed h Λ K L s = CLevPlateau h K L s + CArr Λ K L s := by
  have hτ : 0 ≤ K / s := by positivity
  obtain ⟨h1, h2⟩ := path_intervalIntegrable h K L s hi hs hK hwin
  rw [CMixAddArrSpeed, intervalIntegral.integral_add (h1.trans h2)
    (intervalIntegrable_step 0 (Λ s) 0 (K / s) L hτ hwin), CLevPlateau, CArr]

theorem CMixAddArrBoth_eq (h Λ : ℝ → ℝ) (K L s : ℝ) (hs : 0 < s) (hτ : 0 ≤ K / s)
    (hwin : K / s ≤ L) :
    CMixAddArrBoth h Λ K L s = CArr (fun _ => h K) K L s + CArr Λ K L s := by
  have hfun : (fun t => gatedLevel h K (min (s * t) K) + step 0 (Λ s) (K / s) t)
      = fun t => step 0 (h K) (K / s) t + step 0 (Λ s) (K / s) t := by
    funext t; rw [gatedLevel_path h K s t hs]
  rw [CMixAddArrBoth, hfun, intervalIntegral.integral_add
    (intervalIntegrable_step 0 (h K) 0 (K / s) L hτ hwin)
    (intervalIntegrable_step 0 (Λ s) 0 (K / s) L hτ hwin), CArr, CArr]

/-- The plateau conditions hold on a neighbourhood of the speed. -/
theorem plateau_eventually (K L s : ℝ) (hK : 0 ≤ K) (hs : 0 < s) (hwin : K / s < L) :
    ∀ᶠ x in 𝓝 s, 0 < x ∧ 0 ≤ K / x ∧ K / x ≤ L := by
  have hpos : ∀ᶠ x in 𝓝 s, (0:ℝ) < x := (isOpen_Ioi.eventually_mem hs).mono fun _ h => h
  have hlt : ∀ᶠ x in 𝓝 s, K / x < L :=
    (continuousAt_const.div continuousAt_id hs.ne').eventually
      ((isOpen_Iio.eventually_mem hwin).mono fun _ h => h)
  filter_upwards [hpos, hlt] with x hx hxL
  exact ⟨hx, by positivity, hxL.le⟩

/-- R2 level-set derivative for an integrable profile (`r2_lev_hasDerivAt` without continuity). -/
theorem r2_lev_hasDerivAt_int (h : ℝ → ℝ) (K L s : ℝ) (hi : IntervalIntegrable h volume 0 K)
    (hK : 0 ≤ K) (hs : 0 < s) (hwin : K / s < L) :
    HasDerivAt (fun x : ℝ => CLevPlateau h K L x)
      (-(s ^ 2)⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (K / s ^ 2)) s := by
  have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs.ne'
  have hA : HasDerivAt (fun x : ℝ => x⁻¹ * ∫ c in (0:ℝ)..K, h c)
      (-(s ^ 2)⁻¹ * ∫ c in (0:ℝ)..K, h c) s := hinv.mul_const _
  have hwindow : HasDerivAt (fun x : ℝ => h K * (L - K / x)) (h K * (K / s ^ 2)) s := by
    have hKx : HasDerivAt (fun x : ℝ => K / x) (-(K / s ^ 2)) s := by
      have hh := hinv.const_mul K
      simp only [div_eq_mul_inv] at *
      convert hh using 1
      field_simp
    have := (hKx.const_sub L).const_mul (h K)
    convert this using 1
    ring
  refine (hA.add hwindow).congr_of_eventuallyEq ?_
  filter_upwards [plateau_eventually K L s hK hs hwin] with x hx
  exact CLevPlateau_eq_int h K L x hi hx.1 hK hx.2.2

/-- **E4, arrival-on, speed component gated: the derivative of the defined loss.** -/
theorem e4_speedGated_hasDerivAt (h Λ : ℝ → ℝ) (K L s lam' : ℝ)
    (hi : IntervalIntegrable h volume 0 K)
    (hK : 0 ≤ K) (hs : 0 < s) (hwin : K / s < L) (hΛ : HasDerivAt Λ lam' s) :
    HasDerivAt (fun x => CMixAddArrSpeed h Λ K L x)
      ((-(s ^ 2)⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (K / s ^ 2))
        + (lam' * (L - K / s) + Λ s * (K / s ^ 2))) s := by
  have hd := (r2_lev_hasDerivAt_int h K L s hi hK hs hwin).add
    (r2_hasDerivAt Λ L K s lam' hK hs hwin hΛ)
  refine hd.congr_of_eventuallyEq ?_
  filter_upwards [plateau_eventually K L s hK hs hwin] with x hx
  exact CMixAddArrSpeed_eq h Λ K L x hi hx.1 hK hx.2.2

/-- **E4, arrival-on, speed component gated: the printed form.**
`sC_M′ = Λ_M[ε_Λ(L − τ_M) + τ_M] + τ_M[h_M(K_M) − h̄_M]`, with `ε_Λ = sΛ′/Λ`. -/
theorem e4_speedGated_scaled (h Λ : ℝ → ℝ) (K L s lam' : ℝ)
    (hi : IntervalIntegrable h volume 0 K)
    (hK : 0 < K) (hs : 0 < s) (hwin : K / s < L) (hΛ : HasDerivAt Λ lam' s) (hΛ0 : Λ s ≠ 0) :
    s * deriv (fun x => CMixAddArrSpeed h Λ K L x) s
      = Λ s * (s * lam' / Λ s * (L - K / s) + K / s) + K / s * (h K - hbar h K) := by
  rw [(e4_speedGated_hasDerivAt h Λ K L s lam' hi hK.le hs hwin hΛ).deriv, hbar]
  field_simp
  ring

/-- **E4, arrival-on, speed component gated: positive for every `ε_Λ ≥ 0`**, for a level
component nondecreasing on `[0, K_M]` (no continuity) and `Λ_M > 0`. -/
theorem e4_speedGated_pos (h Λ : ℝ → ℝ) (K L s lam' : ℝ)
    (hmono : MonotoneOn h (Icc 0 K)) (hK : 0 < K) (hs : 0 < s) (hwin : K / s < L)
    (hΛ : HasDerivAt Λ lam' s) (hΛpos : 0 < Λ s) (hε : 0 ≤ s * lam' / Λ s) :
    0 < deriv (fun x => CMixAddArrSpeed h Λ K L x) s := by
  have hi : IntervalIntegrable h volume 0 K :=
    MonotoneOn.intervalIntegrable (by rwa [uIcc_of_le hK.le])
  have hsc := e4_speedGated_scaled h Λ K L s lam' hi hK hs hwin hΛ hΛpos.ne'
  have hbr : 0 ≤ h K - hbar h K := bracket_nonneg_of_monotoneOn h K hK hmono
  have hτ : 0 < K / s := by positivity
  have h1 : 0 < Λ s * (s * lam' / Λ s * (L - K / s) + K / s) := by
    have : 0 ≤ s * lam' / Λ s * (L - K / s) := mul_nonneg hε (sub_pos.mpr hwin).le
    positivity
  have h2 : 0 ≤ K / s * (h K - hbar h K) := mul_nonneg hτ.le hbr
  have : 0 < s * deriv (fun x => CMixAddArrSpeed h Λ K L x) s := by rw [hsc]; linarith
  exact (mul_pos_iff_of_pos_left hs).mp this

/-- **E4, arrival-on, both components gated: the derivative of the defined loss.** -/
theorem e4_bothGated_hasDerivAt (h Λ : ℝ → ℝ) (K L s lam' : ℝ)
    (hK : 0 ≤ K) (hs : 0 < s) (hwin : K / s < L) (hΛ : HasDerivAt Λ lam' s) :
    HasDerivAt (fun x => CMixAddArrBoth h Λ K L x)
      ((0 * (L - K / s) + h K * (K / s ^ 2)) + (lam' * (L - K / s) + Λ s * (K / s ^ 2))) s := by
  have hd := (r2_hasDerivAt (fun _ => h K) L K s 0 hK hs hwin (hasDerivAt_const s _)).add
    (r2_hasDerivAt Λ L K s lam' hK hs hwin hΛ)
  refine hd.congr_of_eventuallyEq ?_
  filter_upwards [plateau_eventually K L s hK hs hwin] with x hx
  exact CMixAddArrBoth_eq h Λ K L x hx.1 hx.2.1 hx.2.2

/-- **E4, arrival-on, both components gated: the printed form.**
`sC_M′ = Λ_Mε_Λ(L − τ_M) + [Λ_M + h_M(K_M)]τ_M`. -/
theorem e4_bothGated_scaled (h Λ : ℝ → ℝ) (K L s lam' : ℝ)
    (hK : 0 ≤ K) (hs : 0 < s) (hwin : K / s < L) (hΛ : HasDerivAt Λ lam' s) (hΛ0 : Λ s ≠ 0) :
    s * deriv (fun x => CMixAddArrBoth h Λ K L x) s
      = Λ s * (s * lam' / Λ s) * (L - K / s) + (Λ s + h K) * (K / s) := by
  rw [(e4_bothGated_hasDerivAt h Λ K L s lam' hK hs hwin hΛ).deriv]
  field_simp
  ring

/-- **E4, arrival-on, both components gated: positive for every `ε_Λ ≥ 0`.**  Uses only
`h_M(K_M) ≥ 0`, which a nonnegative hazard supplies; monotonicity is not needed here. -/
theorem e4_bothGated_pos (h Λ : ℝ → ℝ) (K L s lam' : ℝ) (hnn : ∀ c, 0 ≤ h c)
    (hK : 0 < K) (hs : 0 < s) (hwin : K / s < L)
    (hΛ : HasDerivAt Λ lam' s) (hΛpos : 0 < Λ s) (hε : 0 ≤ s * lam' / Λ s) :
    0 < deriv (fun x => CMixAddArrBoth h Λ K L x) s := by
  have hsc := e4_bothGated_scaled h Λ K L s lam' hK.le hs hwin hΛ hΛpos.ne'
  have hτ : 0 < K / s := by positivity
  have h1 : 0 ≤ Λ s * (s * lam' / Λ s) * (L - K / s) :=
    mul_nonneg (mul_nonneg hΛpos.le hε) (sub_pos.mpr hwin).le
  have h2 : 0 < (Λ s + h K) * (K / s) := mul_pos (by linarith [hnn K]) hτ
  have : 0 < s * deriv (fun x => CMixAddArrBoth h Λ K L x) s := by rw [hsc]; linarith
  exact (mul_pos_iff_of_pos_left hs).mp this

/-- **E4's companion, ramp-on: the derivative of the defined loss.** -/
theorem e4_ramp_hasDerivAt (h Λ : ℝ → ℝ) (K L s lam' : ℝ)
    (hi : IntervalIntegrable h volume 0 K)
    (hK : 0 ≤ K) (hs : 0 < s) (hwin : K / s < L) (hΛ : HasDerivAt Λ lam' s) :
    HasDerivAt (fun x => CMixAddRamp h Λ K L x)
      ((-(s ^ 2)⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (K / s ^ 2)) + lam' * L) s := by
  have hd := (r2_lev_hasDerivAt_int h K L s hi hK hs hwin).add (hΛ.mul_const L)
  refine hd.congr_of_eventuallyEq ?_
  filter_upwards [plateau_eventually K L s hK hs hwin] with x hx
  exact CMixAddRamp_eq h Λ K L x hi hx.1 hK hx.2.2

/-- **E4's companion, ramp-on: the printed form** `sC_M′ = LΛ_Mε_Λ + τ_M[h_M(K_M) − h̄_M]`. -/
theorem e4_ramp_scaled (h Λ : ℝ → ℝ) (K L s lam' : ℝ)
    (hi : IntervalIntegrable h volume 0 K)
    (hK : 0 < K) (hs : 0 < s) (hwin : K / s < L) (hΛ : HasDerivAt Λ lam' s) (hΛ0 : Λ s ≠ 0) :
    s * deriv (fun x => CMixAddRamp h Λ K L x) s
      = L * Λ s * (s * lam' / Λ s) + K / s * (h K - hbar h K) := by
  rw [(e4_ramp_hasDerivAt h Λ K L s lam' hi hK.le hs hwin hΛ).deriv, hbar]
  field_simp
  ring

/-- **E4's companion, ramp-on: positive for every `ε_Λ > 0`** when the level component is
nondecreasing (no continuity). -/
theorem e4_ramp_pos (h Λ : ℝ → ℝ) (K L s lam' : ℝ)
    (hmono : MonotoneOn h (Icc 0 K)) (hK : 0 < K) (hs : 0 < s) (hwin : K / s < L)
    (hΛ : HasDerivAt Λ lam' s) (hΛpos : 0 < Λ s) (hε : 0 < s * lam' / Λ s) :
    0 < deriv (fun x => CMixAddRamp h Λ K L x) s := by
  have hi : IntervalIntegrable h volume 0 K :=
    MonotoneOn.intervalIntegrable (by rwa [uIcc_of_le hK.le])
  have hsc := e4_ramp_scaled h Λ K L s lam' hi hK hs hwin hΛ hΛpos.ne'
  have hbr : 0 ≤ h K - hbar h K := bracket_nonneg_of_monotoneOn h K hK hmono
  have hτ : 0 < K / s := by positivity
  have hLpos : 0 < L := lt_trans hτ hwin
  have h1 : 0 < L * Λ s * (s * lam' / Λ s) := by positivity
  have h2 : 0 ≤ K / s * (h K - hbar h K) := mul_nonneg hτ.le hbr
  have : 0 < s * deriv (fun x => CMixAddRamp h Λ K L x) s := by rw [hsc]; linarith
  exact (mul_pos_iff_of_pos_left hs).mp this

/-! ### §4a.6: on the plateau the elasticity threshold is nonpositive

§4a.6: "Under a fixed horizon and a nondecreasing level component the threshold is nonpositive,
so A4 raises loss."  For each plateau form, `C_M′ < 0` iff `ε_Λ` lies below an explicit threshold,
and that threshold is `≤ 0`.  A4 (`Λ_M′ > 0`, so `ε_Λ > 0`) then gives the positive derivatives
proved above. -/

/-- The algebra shared by the three forms: `s·d = a·ε + c` with `s, a > 0`, `c ≥ 0` gives
`d < 0 ↔ ε < −c/a`, a threshold `≤ 0`. -/
theorem threshold_nonpos (a ε c d s : ℝ) (hs : 0 < s) (ha : 0 < a) (hc : 0 ≤ c)
    (hd : s * d = a * ε + c) : (d < 0 ↔ ε < -c / a) ∧ -c / a ≤ 0 := by
  refine ⟨?_, ?_⟩
  · rw [lt_div_iff₀ ha]
    constructor
    · intro h
      have : s * d < 0 := mul_neg_of_pos_of_neg hs h
      linarith [mul_comm ε a]
    · intro h
      by_contra hn
      have : 0 ≤ s * d := mul_nonneg hs.le (not_lt.mp hn)
      linarith [mul_comm ε a]
  · rw [neg_div]; linarith [div_nonneg hc ha.le]

/-- **§4a.6, ramp-on plateau:** `C_M′ < 0 ↔ ε_Λ < −τ_M[h_M(K_M) − h̄_M]/(LΛ_M)`, and that
threshold is `≤ 0`. -/
theorem e4_ramp_threshold (h Λ : ℝ → ℝ) (K L s lam' : ℝ)
    (hmono : MonotoneOn h (Icc 0 K)) (hK : 0 < K) (hs : 0 < s) (hwin : K / s < L)
    (hΛ : HasDerivAt Λ lam' s) (hΛpos : 0 < Λ s) :
    (deriv (fun x => CMixAddRamp h Λ K L x) s < 0 ↔
        s * lam' / Λ s < -(K / s * (h K - hbar h K)) / (L * Λ s)) ∧
      -(K / s * (h K - hbar h K)) / (L * Λ s) ≤ 0 := by
  have hi : IntervalIntegrable h volume 0 K :=
    MonotoneOn.intervalIntegrable (by rwa [uIcc_of_le hK.le])
  have hτ : 0 < K / s := by positivity
  have hLpos : 0 < L := lt_trans hτ hwin
  exact threshold_nonpos _ _ _ _ s hs (by positivity)
    (mul_nonneg hτ.le (bracket_nonneg_of_monotoneOn h K hK hmono))
    (e4_ramp_scaled h Λ K L s lam' hi hK hs hwin hΛ hΛpos.ne')

/-- **§4a.6, arrival-on plateau, speed component gated:** the threshold
`−(Λ_Mτ_M + τ_M[h_M(K_M) − h̄_M])/(Λ_M(L − τ_M))` is `≤ 0`. -/
theorem e4_speedGated_threshold (h Λ : ℝ → ℝ) (K L s lam' : ℝ)
    (hmono : MonotoneOn h (Icc 0 K)) (hK : 0 < K) (hs : 0 < s) (hwin : K / s < L)
    (hΛ : HasDerivAt Λ lam' s) (hΛpos : 0 < Λ s) :
    (deriv (fun x => CMixAddArrSpeed h Λ K L x) s < 0 ↔
        s * lam' / Λ s < -(Λ s * (K / s) + K / s * (h K - hbar h K)) / (Λ s * (L - K / s))) ∧
      -(Λ s * (K / s) + K / s * (h K - hbar h K)) / (Λ s * (L - K / s)) ≤ 0 := by
  have hi : IntervalIntegrable h volume 0 K :=
    MonotoneOn.intervalIntegrable (by rwa [uIcc_of_le hK.le])
  have hτ : 0 < K / s := by positivity
  have hgap : 0 < L - K / s := sub_pos.mpr hwin
  have hbr := bracket_nonneg_of_monotoneOn h K hK hmono
  refine threshold_nonpos _ _ _ _ s hs (by positivity)
    (add_nonneg (by positivity) (mul_nonneg hτ.le hbr)) ?_
  rw [e4_speedGated_scaled h Λ K L s lam' hi hK hs hwin hΛ hΛpos.ne']
  ring

/-- **§4a.6, arrival-on plateau, both components gated:** the threshold
`−[Λ_M + h_M(K_M)]τ_M/(Λ_M(L − τ_M))` is `≤ 0`. -/
theorem e4_bothGated_threshold (h Λ : ℝ → ℝ) (K L s lam' : ℝ) (hnn : ∀ c, 0 ≤ h c)
    (hK : 0 < K) (hs : 0 < s) (hwin : K / s < L)
    (hΛ : HasDerivAt Λ lam' s) (hΛpos : 0 < Λ s) :
    (deriv (fun x => CMixAddArrBoth h Λ K L x) s < 0 ↔
        s * lam' / Λ s < -((Λ s + h K) * (K / s)) / (Λ s * (L - K / s))) ∧
      -((Λ s + h K) * (K / s)) / (Λ s * (L - K / s)) ≤ 0 := by
  have hτ : 0 < K / s := by positivity
  have hgap : 0 < L - K / s := sub_pos.mpr hwin
  refine threshold_nonpos _ _ _ _ s hs (by positivity)
    (mul_nonneg (by linarith [hnn K]) hτ.le) ?_
  rw [e4_bothGated_scaled h Λ K L s lam' hK.le hs hwin hΛ hΛpos.ne']
  ring

/-! ## E1, part 5: (H.2) when the defence comes first, and `∂F/∂Λ = ℓ_M`

A0's (H.2) sets `ℓ_M = 0` when the defence precedes arrival (speed-set arrival-on), where A0's
residual-from-arrival choice makes the loss `h_M^post(L − τ_M)`.  On that open region, on both
clock branches, the identity holds with no intensity term.  Then `∂F/∂Λ = ℓ_M`: the derivative
of the defined loss in the intensity, held at a number, is the exposure length the identities
use, in every region. -/

def UcapF (L mD TD : ℝ) : Set (ℝ × ℝ × ℝ) :=
  {q | 0 < q.1 ∧ 0 < q.2.1 ∧ (1 - mD) * TD * q.1 < q.2.2 ∧ q.2.2 + mD * TD * q.1 < q.2.1 ∧
    q.2.1 < L * q.1}

def UadoptF (L mD TD : ℝ) : Set (ℝ × ℝ × ℝ) :=
  {q | 0 < q.1 ∧ 0 < q.2.1 ∧ q.2.2 < (1 - mD) * TD * q.1 ∧ TD * q.1 < q.2.1 ∧ q.2.1 < L * q.1}

theorem isOpen_UcapF (L mD TD : ℝ) : IsOpen (UcapF L mD TD) := by
  unfold UcapF
  repeat' apply IsOpen.and
  all_goals exact isOpen_lt (by fun_prop) (by fun_prop)

theorem isOpen_UadoptF (L mD TD : ℝ) : IsOpen (UadoptF L mD TD) := by
  unfold UadoptF
  repeat' apply IsOpen.and
  all_goals exact isOpen_lt (by fun_prop) (by fun_prop)

theorem of_mem_UcapF {L mD TD s KM KD : ℝ} (h : (s, KM, KD) ∈ UcapF L mD TD) :
    0 < s ∧ 0 < KM ∧ (1 - mD) * TD < KD / s ∧ KD / s + mD * TD < KM / s ∧ KM / s < L := by
  obtain ⟨hs, hKM, h1, h2, h3⟩ := h
  have e : KD / s + mD * TD = (KD + mD * TD * s) / s := by field_simp
  refine ⟨hs, hKM, (lt_div_iff₀ hs).mpr h1, ?_, (div_lt_iff₀ hs).mpr h3⟩
  rw [e]; exact (div_lt_div_iff_of_pos_right hs).mpr h2

theorem mem_UcapF {L mD TD s KM KD : ℝ} (hs : 0 < s) (hKM : 0 < KM)
    (hbr : (1 - mD) * TD < KD / s) (hfirst : tDc mD TD KD s < KM / s) (hL : KM / s < L) :
    (s, KM, KD) ∈ UcapF L mD TD := by
  rw [tDc_cap _ _ _ _ hbr.le] at hfirst
  have e : KD / s + mD * TD = (KD + mD * TD * s) / s := by field_simp
  rw [e] at hfirst
  exact ⟨hs, hKM, (lt_div_iff₀ hs).mp hbr, (div_lt_div_iff_of_pos_right hs).mp hfirst,
    (div_lt_iff₀ hs).mp hL⟩

theorem of_mem_UadoptF {L mD TD s KM KD : ℝ} (h : (s, KM, KD) ∈ UadoptF L mD TD) :
    0 < s ∧ 0 < KM ∧ KD / s < (1 - mD) * TD ∧ TD < KM / s ∧ KM / s < L := by
  obtain ⟨hs, hKM, h1, h2, h3⟩ := h
  exact ⟨hs, hKM, (div_lt_iff₀ hs).mpr h1, (lt_div_iff₀ hs).mpr h2, (div_lt_iff₀ hs).mpr h3⟩

theorem mem_UadoptF {L mD TD s KM KD : ℝ} (hs : 0 < s) (hKM : 0 < KM)
    (hbr : KD / s < (1 - mD) * TD) (hfirst : tDc mD TD KD s < KM / s) (hL : KM / s < L) :
    (s, KM, KD) ∈ UadoptF L mD TD := by
  rw [tDc_adopt _ _ _ _ hbr.le] at hfirst
  exact ⟨hs, hKM, (div_lt_iff₀ hs).mp hbr, (lt_div_iff₀ hs).mp hfirst, (div_lt_iff₀ hs).mp hL⟩

theorem CSarr_capF (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (h : (s, KM, KD) ∈ UcapF L mD TD) :
    CSarr Λ L P mD TD s KM KD = Phi (fun _ => 0) 0 0 0 (-P) 0 (P * L) s KM KD := by
  obtain ⟨hs, hKM, hbr, hfirst, hL⟩ := of_mem_UcapF h
  rw [CSarr, CArrClose_eq_before Λ KM L s _ P (by positivity)
    (by rw [tDc_cap _ _ _ _ hbr.le]; exact hfirst.le) hL.le, Phi]
  ring

theorem CSarr_adoptF (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (h : (s, KM, KD) ∈ UadoptF L mD TD) :
    CSarr Λ L P mD TD s KM KD = Phi (fun _ => 0) 0 0 0 (-P) 0 (P * L) s KM KD := by
  obtain ⟨hs, hKM, hbr, hfirst, hL⟩ := of_mem_UadoptF h
  rw [CSarr, CArrClose_eq_before Λ KM L s _ P (by positivity)
    (by rw [tDc_adopt _ _ _ _ hbr.le]; exact hfirst.le) hL.le, Phi]
  ring

/-- **E1 / (H.2), speed-set arrival-on, defence first, capability branch:** `ℓ_M = 0`, so
`s∂C_M/∂s = −K_M∂C_M/∂K_M − K_D∂C_M/∂K_D`. -/
theorem e1_S_arr_defFirst_cap (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (hs : 0 < s) (hKM : 0 < KM)
    (hbr : (1 - mD) * TD < KD / s) (hfirst : tDc mD TD KD s < KM / s) (hL : KM / s < L) :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => CSarr Λ L P mD TD x KM KD) ds s ∧
      HasDerivAt (fun x => CSarr Λ L P mD TD s x KD) dK KM ∧
      HasDerivAt (fun x => CSarr Λ L P mD TD s KM x) dD KD ∧
      s * ds = -(KM * dK) - KD * dD := by
  obtain ⟨ds, dK, dD, h1, h2, h3, h4⟩ :=
    phi_euler (CSarr Λ L P mD TD) (fun _ => 0) 0 0 0 (-P) 0 (P * L) s KM KD 0
      (UcapF L mD TD) (isOpen_UcapF L mD TD) (mem_UcapF hs hKM hbr hfirst hL)
      (fun x y z h => CSarr_capF Λ L P mD TD x y z h) hs.ne' (hasDerivAt_const s _)
  exact ⟨ds, dK, dD, h1, h2, h3, by rw [h4]; ring⟩

/-- **E1 / (H.2), speed-set arrival-on, defence first, adoption branch.** -/
theorem e1_S_arr_defFirst_adopt (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (hs : 0 < s)
    (hKM : 0 < KM) (hbr : KD / s < (1 - mD) * TD) (hfirst : tDc mD TD KD s < KM / s)
    (hL : KM / s < L) :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => CSarr Λ L P mD TD x KM KD) ds s ∧
      HasDerivAt (fun x => CSarr Λ L P mD TD s x KD) dK KM ∧
      HasDerivAt (fun x => CSarr Λ L P mD TD s KM x) dD KD ∧
      s * ds = -(KM * dK) - KD * dD := by
  obtain ⟨ds, dK, dD, h1, h2, h3, h4⟩ :=
    phi_euler (CSarr Λ L P mD TD) (fun _ => 0) 0 0 0 (-P) 0 (P * L) s KM KD 0
      (UadoptF L mD TD) (isOpen_UadoptF L mD TD) (mem_UadoptF hs hKM hbr hfirst hL)
      (fun x y z h => CSarr_adoptF Λ L P mD TD x y z h) hs.ne' (hasDerivAt_const s _)
  exact ⟨ds, dK, dD, h1, h2, h3, by rw [h4]; ring⟩

theorem phi_dLam (a c d b e f s KM KD lam0 : ℝ) :
    HasDerivAt (fun lam => Phi (fun _ => lam) a c d b e f s KM KD)
      ((a * KM + c * KD) / s + d) lam0 := by
  unfold Phi
  simpa using ((hasDerivAt_id lam0).mul_const ((a * KM + c * KD) / s + d)).add_const
    ((b * KM + e * KD) / s + f)

/-- **`∂F/∂Λ = ℓ_M = t_D − τ_M`**, speed-set arrival-on, interior, capability branch. -/
theorem e1_dF_dLam_arr_cap (L P mD TD s KM KD lam0 : ℝ) (h : (s, KM, KD) ∈ Ucap L mD TD) :
    HasDerivAt (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD)
      (tDc mD TD KD s - KM / s) lam0 := by
  have hfun : (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD) = fun lam =>
      Phi (fun _ => lam) (-1) 1 (mD * TD) 0 (-P) (P * (L - mD * TD)) s KM KD :=
    funext fun lam => CSarr_cap (fun _ => lam) L P mD TD s KM KD h
  rw [hfun, tDc_cap _ _ _ _ (of_mem_Ucap h).2.2.1.le]
  convert phi_dLam (-1) 1 (mD * TD) 0 (-P) (P * (L - mD * TD)) s KM KD lam0 using 1
  ring

/-- **`∂F/∂Λ = ℓ_M = t_D − τ_M`**, speed-set arrival-on, interior, adoption branch. -/
theorem e1_dF_dLam_arr_adopt (L P mD TD s KM KD lam0 : ℝ) (h : (s, KM, KD) ∈ Uadopt L mD TD) :
    HasDerivAt (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD)
      (tDc mD TD KD s - KM / s) lam0 := by
  have hfun : (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD) = fun lam =>
      Phi (fun _ => lam) (-1) 0 TD 0 0 (P * (L - TD)) s KM KD :=
    funext fun lam => CSarr_adopt (fun _ => lam) L P mD TD s KM KD h
  rw [hfun, tDc_adopt _ _ _ _ (of_mem_Uadopt h).2.2.1.le]
  convert phi_dLam (-1) 0 TD 0 0 (P * (L - TD)) s KM KD lam0 using 1
  ring

/-- **`∂F/∂Λ = ℓ_M = t_D`**, speed-set ramp-on, interior, capability branch. -/
theorem e1_dF_dLam_ramp_cap (L P mD TD s KM KD lam0 : ℝ) (h : (s, KM, KD) ∈ Ucap L mD TD) :
    HasDerivAt (fun lam => CSramp (fun _ => lam) L P mD TD s KM KD) (tDc mD TD KD s) lam0 := by
  have hfun : (fun lam => CSramp (fun _ => lam) L P mD TD s KM KD) = fun lam =>
      Phi (fun _ => lam) 0 1 (mD * TD) 0 (-P) (P * (L - mD * TD)) s KM KD :=
    funext fun lam => CSramp_cap (fun _ => lam) L P mD TD s KM KD h
  rw [hfun, tDc_cap _ _ _ _ (of_mem_Ucap h).2.2.1.le]
  convert phi_dLam 0 1 (mD * TD) 0 (-P) (P * (L - mD * TD)) s KM KD lam0 using 1
  ring

/-- **`∂F/∂Λ = ℓ_M = t_D`**, speed-set ramp-on, interior, adoption branch. -/
theorem e1_dF_dLam_ramp_adopt (L P mD TD s KM KD lam0 : ℝ) (h : (s, KM, KD) ∈ Uadopt L mD TD) :
    HasDerivAt (fun lam => CSramp (fun _ => lam) L P mD TD s KM KD) (tDc mD TD KD s) lam0 := by
  have hfun : (fun lam => CSramp (fun _ => lam) L P mD TD s KM KD) = fun lam =>
      Phi (fun _ => lam) 0 0 TD 0 0 (P * (L - TD)) s KM KD :=
    funext fun lam => CSramp_adopt (fun _ => lam) L P mD TD s KM KD h
  rw [hfun, tDc_adopt _ _ _ _ (of_mem_Uadopt h).2.2.1.le]
  convert phi_dLam 0 0 TD 0 0 (P * (L - TD)) s KM KD lam0 using 1
  ring

/-- **`∂F/∂Λ = ℓ_M = 0`** when the defence comes first (speed-set arrival-on, either branch). -/
theorem e1_dF_dLam_arr_defFirst (L P mD TD s KM KD lam0 : ℝ)
    (h : (s, KM, KD) ∈ UcapF L mD TD ∨ (s, KM, KD) ∈ UadoptF L mD TD) :
    HasDerivAt (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD) 0 lam0 := by
  have hfun : (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD) = fun _ =>
      Phi (fun _ => 0) 0 0 0 (-P) 0 (P * L) s KM KD := by
    funext lam
    rcases h with h | h
    · exact CSarr_capF (fun _ => lam) L P mD TD s KM KD h
    · exact CSarr_adoptF (fun _ => lam) L P mD TD s KM KD h
  rw [hfun]; exact hasDerivAt_const _ _

/-! ## E1, part 6: "each form needs a fixed residual" — four exact failures

A responsive residual `h_M^post(s)` (A0: "unless a result says it responds to speed") is put into
each of the four defined losses unchanged.  At one adoption-branch point (`s = 1`, `K_M = K_D =
1/2`, `m_D = 0`, `T_D = 1`, `L = 2`, `h_M^post(s) = s`, so `τ_M = 1/2 < t_D = 1 < L`) the
identity of each form fails.  Speed-set uses `Λ_M(s) = s` (A4 holds), level-set A uses `ĥ ≡ 1`. -/

noncomputable def CSrampR (Λ Pf : ℝ → ℝ) (L mD TD s KM KD : ℝ) : ℝ :=
  CRampClose Λ L s (tDc mD TD KD s) (Pf s)

noncomputable def CSarrR (Λ Pf : ℝ → ℝ) (L mD TD s KM KD : ℝ) : ℝ :=
  CArrClose Λ KM L s (tDc mD TD KD s) (Pf s)

noncomputable def CArampR (ĥ Pf : ℝ → ℝ) (L mD TD s KM KD : ℝ) : ℝ :=
  CBeforeAInt ĥ KM L s (tDc mD TD KD s) (Pf s)

noncomputable def CAarrR (ĥ Pf : ℝ → ℝ) (L mD TD s KM KD : ℝ) : ℝ :=
  CLevArr (fun c => ĥ (c / KM)) KM L s (tDc mD TD KD s) (Pf s)

theorem tDc_ex (KD x : ℝ) (h : KD / x ≤ 1) : tDc 0 1 KD x = 1 :=
  tDc_adopt 0 1 KD x (by rw [sub_zero, mul_one]; exact h)

theorem ev_s : ∀ᶠ x in 𝓝 (1:ℝ), 1 / 2 < x := Ioi_mem_nhds (by norm_num)

theorem ev_KD : ∀ᶠ y in 𝓝 (1 / 2 : ℝ), y < 1 := Iio_mem_nhds (by norm_num)

theorem ev_KM : ∀ᶠ y in 𝓝 (1 / 2 : ℝ), 0 < y ∧ y < 1 := by
  filter_upwards [Ioo_mem_nhds (show (0:ℝ) < 1 / 2 by norm_num) (show (1 / 2 : ℝ) < 1 by norm_num)]
    with y hy using hy

theorem half_div_le {x : ℝ} (hx : 1 / 2 < x) : 1 / 2 / x ≤ 1 := by
  rw [div_le_one (by linarith)]; linarith

/-- Speed-set ramp-on: `s∂C/∂s = 2` but `sΛ′ℓ_M − K_M∂C/∂K_M − K_D∂C/∂K_D = 1`. -/
theorem e1_residual_S_ramp :
    HasDerivAt (fun x => CSrampR id id 2 0 1 x (1 / 2) (1 / 2)) 2 1 ∧
    HasDerivAt (fun x => CSrampR id id 2 0 1 1 x (1 / 2)) 0 (1 / 2) ∧
    HasDerivAt (fun x => CSrampR id id 2 0 1 1 (1 / 2) x) 0 (1 / 2) ∧
    HasDerivAt (id : ℝ → ℝ) 1 1 ∧ tDc 0 1 (1 / 2) 1 = 1 ∧
    (1:ℝ) * 2 ≠ 1 * 1 * tDc 0 1 (1 / 2) 1 - 1 / 2 * 0 - 1 / 2 * 0 := by
  have ht : tDc 0 1 (1 / 2) 1 = 1 := tDc_ex _ _ (by norm_num)
  refine ⟨?_, ?_, ?_, hasDerivAt_id 1, ht, by rw [ht]; norm_num⟩
  · have heq : (fun x => CSrampR id id 2 0 1 x (1 / 2) (1 / 2)) =ᶠ[𝓝 1] fun x => 2 * x := by
      filter_upwards [ev_s] with x hx
      rw [CSrampR, tDc_ex _ _ (half_div_le hx), CRampClose_eq id 2 x 1 (id x) (by norm_num)
        (by norm_num)]
      simp only [id]; ring
    have := (hasDerivAt_id (1:ℝ)).const_mul 2
    simp only [mul_one] at this
    exact this.congr_of_eventuallyEq heq
  · exact hasDerivAt_const (1 / 2 : ℝ) (CSrampR id id 2 0 1 1 (1 / 2) (1 / 2))
  · have heq : (fun x => CSrampR id id 2 0 1 1 (1 / 2) x) =ᶠ[𝓝 (1 / 2)] fun _ => (2:ℝ) := by
      filter_upwards [ev_KD] with y hy
      rw [CSrampR, tDc_ex _ _ (by rw [div_one]; exact hy.le), CRampClose_eq id 2 1 1 (id 1)
        (by norm_num) (by norm_num)]
      simp only [id]; norm_num
    exact (hasDerivAt_const _ _).congr_of_eventuallyEq heq

/-- Speed-set arrival-on: `s∂C/∂s = 2` but the right side of (H.2) is `1`. -/
theorem e1_residual_S_arr :
    HasDerivAt (fun x => CSarrR id id 2 0 1 x (1 / 2) (1 / 2)) 2 1 ∧
    HasDerivAt (fun x => CSarrR id id 2 0 1 1 x (1 / 2)) (-1) (1 / 2) ∧
    HasDerivAt (fun x => CSarrR id id 2 0 1 1 (1 / 2) x) 0 (1 / 2) ∧
    HasDerivAt (id : ℝ → ℝ) 1 1 ∧ tDc 0 1 (1 / 2) 1 = 1 ∧
    (1:ℝ) * 2 ≠ 1 * 1 * (tDc 0 1 (1 / 2) 1 - 1 / 2 / 1) - 1 / 2 * (-1) - 1 / 2 * 0 := by
  have ht : tDc 0 1 (1 / 2) 1 = 1 := tDc_ex _ _ (by norm_num)
  refine ⟨?_, ?_, ?_, hasDerivAt_id 1, ht, by rw [ht]; norm_num⟩
  · have heq : (fun x => CSarrR id id 2 0 1 x (1 / 2) (1 / 2)) =ᶠ[𝓝 1]
        fun x => 2 * x - 1 / 2 := by
      filter_upwards [ev_s] with x hx
      have hx0 : x ≠ 0 := by linarith
      rw [CSarrR, tDc_ex _ _ (half_div_le hx), CArrClose_eq id (1 / 2) 2 x 1 (id x)
        (by positivity) (half_div_le hx) (by norm_num)]
      simp only [id]; field_simp; ring
    have := ((hasDerivAt_id (1:ℝ)).const_mul 2).sub_const (1 / 2)
    simp only [mul_one] at this
    exact this.congr_of_eventuallyEq heq
  · have heq : (fun x => CSarrR id id 2 0 1 1 x (1 / 2)) =ᶠ[𝓝 (1 / 2)] fun y => 2 - y := by
      filter_upwards [ev_KM] with y hy
      rw [CSarrR, tDc_ex _ _ (by norm_num), CArrClose_eq id y 2 1 1 (id 1)
        (by rw [div_one]; exact hy.1.le) (by rw [div_one]; exact hy.2.le) (by norm_num)]
      simp only [id]; ring
    have := (hasDerivAt_id (1 / 2 : ℝ)).const_sub 2
    exact this.congr_of_eventuallyEq heq
  · have heq : (fun x => CSarrR id id 2 0 1 1 (1 / 2) x) =ᶠ[𝓝 (1 / 2)] fun _ => (3 / 2 : ℝ) := by
      filter_upwards [ev_KD] with y hy
      rw [CSarrR, tDc_ex _ _ (by rw [div_one]; exact hy.le), CArrClose_eq id (1 / 2) 2 1 1 (id 1)
        (by norm_num) (by norm_num) (by norm_num)]
      simp only [id]; norm_num
    exact (hasDerivAt_const _ _).congr_of_eventuallyEq heq

theorem CArampR_one (Pf : ℝ → ℝ) (L mD TD s KM KD : ℝ) (h0 : 0 ≤ tDc mD TD KD s)
    (hhor : tDc mD TD KD s ≤ L) :
    CArampR (fun _ => 1) Pf L mD TD s KM KD
      = tDc mD TD KD s + Pf s * (L - tDc mD TD KD s) := by
  rw [show CArampR (fun _ => 1) Pf L mD TD s KM KD
      = CRampClose (fun _ => 1) L s (tDc mD TD KD s) (Pf s) from rfl,
    CRampClose_eq _ L s _ _ h0 hhor]
  simp only [one_mul]

/-- Level-set convention A, ramp-on: `s∂C/∂s = 1` but the right side of (H.1) is `0`. -/
theorem e1_residual_A_ramp :
    HasDerivAt (fun x => CArampR (fun _ => 1) id 2 0 1 x (1 / 2) (1 / 2)) 1 1 ∧
    HasDerivAt (fun x => CArampR (fun _ => 1) id 2 0 1 1 x (1 / 2)) 0 (1 / 2) ∧
    HasDerivAt (fun x => CArampR (fun _ => 1) id 2 0 1 1 (1 / 2) x) 0 (1 / 2) ∧
    (1:ℝ) * 1 ≠ -(1 / 2 * 0) - 1 / 2 * 0 := by
  refine ⟨?_, ?_, ?_, by norm_num⟩
  · have heq : (fun x => CArampR (fun _ => 1) id 2 0 1 x (1 / 2) (1 / 2)) =ᶠ[𝓝 1]
        fun x => 1 + x := by
      filter_upwards [ev_s] with x hx
      have ht : tDc 0 1 (1 / 2) x = 1 := tDc_ex _ _ (half_div_le hx)
      rw [CArampR_one id 2 0 1 x _ _ (by rw [ht]; norm_num) (by rw [ht]; norm_num), ht]
      simp only [id]; ring
    exact ((hasDerivAt_id (1:ℝ)).const_add 1).congr_of_eventuallyEq heq
  · have heq : (fun x => CArampR (fun _ => 1) id 2 0 1 1 x (1 / 2)) =ᶠ[𝓝 (1 / 2)]
        fun _ => (2:ℝ) := by
      filter_upwards [ev_KM] with y hy
      have ht : tDc 0 1 (1 / 2) 1 = 1 := tDc_ex _ _ (by norm_num)
      rw [CArampR_one id 2 0 1 1 y _ (by rw [ht]; norm_num) (by rw [ht]; norm_num), ht]
      simp only [id]; norm_num
    exact (hasDerivAt_const _ _).congr_of_eventuallyEq heq
  · have heq : (fun x => CArampR (fun _ => 1) id 2 0 1 1 (1 / 2) x) =ᶠ[𝓝 (1 / 2)]
        fun _ => (2:ℝ) := by
      filter_upwards [ev_KD] with y hy
      have ht : tDc 0 1 y 1 = 1 := tDc_ex _ _ (by rw [div_one]; exact hy.le)
      rw [CArampR_one id 2 0 1 1 (1 / 2) y (by rw [ht]; norm_num) (by rw [ht]; norm_num), ht]
      simp only [id]; norm_num
    exact (hasDerivAt_const _ _).congr_of_eventuallyEq heq

theorem CAarrR_one (Pf : ℝ → ℝ) (L mD TD s KM KD : ℝ) (hKM : 0 ≤ KM / s)
    (harr : KM / s ≤ tDc mD TD KD s) (hhor : tDc mD TD KD s ≤ L) :
    CAarrR (fun _ => 1) Pf L mD TD s KM KD
      = (tDc mD TD KD s - KM / s) + Pf s * (L - tDc mD TD KD s) := by
  rw [CAarrR, CLevArr_eq_CArrClose, CArrClose_eq _ KM L s _ _ hKM harr hhor, one_mul]

/-- Level-set convention A, arrival-on: `s∂C/∂s = 3/2` but the right side of (H.1) is `1/2`. -/
theorem e1_residual_A_arr :
    HasDerivAt (fun x => CAarrR (fun _ => 1) id 2 0 1 x (1 / 2) (1 / 2)) (3 / 2) 1 ∧
    HasDerivAt (fun x => CAarrR (fun _ => 1) id 2 0 1 1 x (1 / 2)) (-1) (1 / 2) ∧
    HasDerivAt (fun x => CAarrR (fun _ => 1) id 2 0 1 1 (1 / 2) x) 0 (1 / 2) ∧
    (1:ℝ) * (3 / 2) ≠ -(1 / 2 * (-1)) - 1 / 2 * 0 := by
  refine ⟨?_, ?_, ?_, by norm_num⟩
  · have heq : (fun x => CAarrR (fun _ => 1) id 2 0 1 x (1 / 2) (1 / 2)) =ᶠ[𝓝 1]
        fun x => 1 + (-(1 / 2) * x⁻¹ + x) := by
      filter_upwards [ev_s] with x hx
      have hx0 : 0 < x := by linarith
      rw [CAarrR_one id 2 0 1 x _ _ (by positivity)
        (by rw [tDc_ex _ _ (half_div_le hx)]; exact half_div_le hx)
        (by rw [tDc_ex _ _ (half_div_le hx)]; norm_num), tDc_ex _ _ (half_div_le hx)]
      simp only [id]; field_simp; ring
    have hd := ((((hasDerivAt_inv (one_ne_zero : (1:ℝ) ≠ 0)).const_mul (-(1 / 2))).add
      (hasDerivAt_id' (1:ℝ))).const_add 1)
    have : HasDerivAt (fun x : ℝ => 1 + (-(1 / 2) * x⁻¹ + x)) (3 / 2) 1 := by
      convert hd using 1 <;> norm_num
    exact this.congr_of_eventuallyEq heq
  · have heq : (fun x => CAarrR (fun _ => 1) id 2 0 1 1 x (1 / 2)) =ᶠ[𝓝 (1 / 2)]
        fun y => 2 - y := by
      filter_upwards [ev_KM] with y hy
      have ht : tDc 0 1 (1 / 2) 1 = 1 := tDc_ex _ _ (by norm_num)
      rw [CAarrR_one id 2 0 1 1 y _ (by rw [div_one]; exact hy.1.le)
        (by rw [ht, div_one]; exact hy.2.le) (by rw [ht]; norm_num), ht]
      simp only [id]; ring
    exact ((hasDerivAt_id (1 / 2 : ℝ)).const_sub 2).congr_of_eventuallyEq heq
  · have heq : (fun x => CAarrR (fun _ => 1) id 2 0 1 1 (1 / 2) x) =ᶠ[𝓝 (1 / 2)]
        fun _ => (3 / 2 : ℝ) := by
      filter_upwards [ev_KD] with y hy
      have ht : tDc 0 1 y 1 = 1 := tDc_ex _ _ (by rw [div_one]; exact hy.le)
      rw [CAarrR_one id 2 0 1 1 (1 / 2) y (by norm_num) (by rw [ht]; norm_num)
        (by rw [ht]; norm_num), ht]
      simp only [id]; norm_num
    exact (hasDerivAt_const _ _).congr_of_eventuallyEq heq

/-! ## The printed worked instances of E2 and E3

`Λ_M(s) = 0.02s^{1/2}` at `s = 1` (`Λ_M = 0.02`, `sΛ′ = 0.01`, `ε_Λ = 0.5`).  The paper gives only
the product `m_DT_D`; the instances take `m_D = 1`, which puts the point on the capability branch
for any `T_D` (the brackets depend on `m_D`, `T_D` only through `m_DT_D` there). -/

noncomputable def Λw (s : ℝ) : ℝ := 2 / 100 * Real.sqrt s

theorem Λw_one : Λw 1 = 2 / 100 := by simp [Λw]

theorem Λw_hasDerivAt : HasDerivAt Λw (1 / 100) 1 := by
  have := (Real.hasDerivAt_sqrt (one_ne_zero : (1:ℝ) ≠ 0)).const_mul (2 / 100)
  rw [Real.sqrt_one, show (2:ℝ) / 100 * (1 / (2 * 1)) = 1 / 100 by norm_num] at this
  exact this

/-- **E2, worked instance (A4a.4(iv)).**  At `K_D = 6` and `7` (`m_DT_D = 2`, `h_M^post = 0.005`,
`K_M = 4`, `L = 10`): `sC_M′ = 0.03` and `0.025`, a change of `−0.005 = [0.02(0.5 − 1) + 0.005]/1`. -/
theorem e2_worked_instance :
    1 * deriv (fun x => CSarr Λw 10 (5 / 1000) 1 2 x 4 6) 1 = 3 / 100 ∧
    1 * deriv (fun x => CSarr Λw 10 (5 / 1000) 1 2 x 4 7) 1 = 25 / 1000 ∧
    (25 / 1000 : ℝ) - 3 / 100 = (2 / 100 * ((1 / 100) / (2 / 100) - 1) + 5 / 1000) / 1 := by
  have t6 : tDc 1 2 6 1 = 8 := by rw [tDc_cap _ _ _ _ (by norm_num)]; norm_num
  have t7 : tDc 1 2 7 1 = 9 := by rw [tDc_cap _ _ _ _ (by norm_num)]; norm_num
  refine ⟨?_, ?_, by norm_num⟩
  · rw [e2_bracket Λw 10 (5 / 1000) 1 2 1 4 6 (1 / 100) (by norm_num) one_pos Λw_hasDerivAt
      (by norm_num) (by rw [t6]; norm_num) (by rw [t6]; norm_num), Λw_one]
    norm_num
  · rw [e2_bracket Λw 10 (5 / 1000) 1 2 1 4 7 (1 / 100) (by norm_num) one_pos Λw_hasDerivAt
      (by norm_num) (by rw [t7]; norm_num) (by rw [t7]; norm_num), Λw_one]
    norm_num

/-- **E3, worked instance (A4a.4(iv)).**  `K_M = 4`, `K_D = 3`, `m_DT_D = 1`, `h_M^post = 0.005`,
`L = 10`, `s = 1`, so `t_D = 4 = τ_M`: the positive-exposure side is `0.035`, the other `0.02`, and
they differ by `0.015 = (0.02 − 0.005)·1`. -/
theorem e3_worked_instance :
    HasDerivWithinAt (fun s => CSarr Λw 10 (5 / 1000) 1 1 s 4 3) (35 / 1000) (Ioi 1) 1 ∧
    HasDerivWithinAt (fun s => CSarr Λw 10 (5 / 1000) 1 1 s 4 3) (2 / 100) (Iio 1) 1 ∧
    (35 / 1000 : ℝ) - 2 / 100 = (2 / 100 - 5 / 1000) * 1 := by
  have hbd : tDc 1 1 3 1 = 4 / 1 := by rw [tDc_cap _ _ _ _ (by norm_num)]; norm_num
  refine ⟨?_, ?_, by norm_num⟩
  · convert e3_right Λw 10 (5 / 1000) 1 1 1 4 3 (1 / 100) one_pos (by norm_num) Λw_hasDerivAt
      (by norm_num) hbd (by norm_num) (by norm_num) using 1
    rw [Λw_one]; norm_num
  · convert e3_left Λw 10 (5 / 1000) 1 1 1 4 3 one_pos (by norm_num) (by norm_num) hbd
      (by norm_num) (by norm_num) using 1
    norm_num

/-! ## The printed worked instances of E1 (A4a.7(vii)), and convention B at a constant profile -/

/-- `phi_euler` with the three partials written out. -/
theorem phi_partials (C : ℝ → ℝ → ℝ → ℝ) (Λ : ℝ → ℝ) (a c d b e f s KM KD lam' : ℝ)
    (U : Set (ℝ × ℝ × ℝ)) (hU : IsOpen U) (hp : (s, KM, KD) ∈ U)
    (hC : ∀ x y z : ℝ, (x, y, z) ∈ U → C x y z = Phi Λ a c d b e f x y z)
    (hs : s ≠ 0) (hΛ : HasDerivAt Λ lam' s) :
    HasDerivAt (fun x => C x KM KD)
        (lam' * ((a * KM + c * KD) * s⁻¹ + d) + Λ s * ((a * KM + c * KD) * -(s ^ 2)⁻¹)
          + (b * KM + e * KD) * -(s ^ 2)⁻¹) s ∧
      HasDerivAt (fun x => C s x KD) (Λ s * (a / s) + b / s) KM ∧
      HasDerivAt (fun x => C s KM x) (Λ s * (c / s) + e / s) KD := by
  obtain ⟨h1, h2, h3⟩ := sections_eventually U hU hp
  have hinv : HasDerivAt (fun x : ℝ => x⁻¹) (-(s ^ 2)⁻¹) s := hasDerivAt_inv hs
  have hA := (hinv.const_mul (a * KM + c * KD)).add_const d
  have hB := (hinv.const_mul (b * KM + e * KD)).add_const f
  have hS := (hΛ.mul hA).add hB
  have e1 : (fun x => C x KM KD) =ᶠ[𝓝 s] fun x =>
      Λ x * ((a * KM + c * KD) * x⁻¹ + d) + ((b * KM + e * KD) * x⁻¹ + f) := by
    filter_upwards [h1] with x hx
    rw [hC x KM KD hx, Phi, div_eq_mul_inv, div_eq_mul_inv]
  have hlinK : HasDerivAt (fun x : ℝ => Λ s * ((a * x + c * KD) / s + d) + ((b * x + e * KD) / s + f))
      (Λ s * (a / s) + b / s) KM := by
    have ha := (((((hasDerivAt_id' KM).const_mul a).add_const (c * KD)).div_const s).add_const d).const_mul (Λ s)
    have hb := ((((hasDerivAt_id' KM).const_mul b).add_const (e * KD)).div_const s).add_const f
    convert ha.add hb using 1
    ring
  have hlinD : HasDerivAt (fun x : ℝ => Λ s * ((a * KM + c * x) / s + d) + ((b * KM + e * x) / s + f))
      (Λ s * (c / s) + e / s) KD := by
    have ha := (((((hasDerivAt_id' KD).const_mul c).const_add (a * KM)).div_const s).add_const d).const_mul (Λ s)
    have hb := ((((hasDerivAt_id' KD).const_mul e).const_add (b * KM)).div_const s).add_const f
    convert ha.add hb using 1
    ring
  have e2 : (fun x => C s x KD) =ᶠ[𝓝 KM] fun x =>
      Λ s * ((a * x + c * KD) / s + d) + ((b * x + e * KD) / s + f) := by
    filter_upwards [h2] with x hx
    rw [hC s x KD hx, Phi]
  have e3 : (fun x => C s KM x) =ᶠ[𝓝 KD] fun x =>
      Λ s * ((a * KM + c * x) / s + d) + ((b * KM + e * x) / s + f) := by
    filter_upwards [h3] with x hx
    rw [hC s KM x hx, Phi]
  exact ⟨hS.congr_of_eventuallyEq e1, hlinK.congr_of_eventuallyEq e2,
    hlinD.congr_of_eventuallyEq e3⟩

theorem baseW_mem : ((2:ℝ), (4:ℝ), (10:ℝ)) ∈ Ucap 10 (1 / 2) 2 :=
  ⟨by norm_num, by norm_num, by norm_num, by norm_num, by norm_num⟩

theorem integral_id01 : (∫ u in (0:ℝ)..1, id u) = 1 / 2 := by
  simp only [id]; rw [integral_id]; norm_num

/-- **E1 worked instance, base W, A, ramp-on** (`ĥ_M(x) = x`): `∂C_M/∂K_M = −0.25`,
`∂C_M/∂K_D = 0.45`, `s∂C_M/∂s = −3.5 = 4·0.25 − 10·0.45`. -/
theorem e1_A_ramp_worked :
    HasDerivAt (fun x => CAramp id 10 (1 / 10) (1 / 2) 2 2 x 10) (-1 / 4) 4 ∧
    HasDerivAt (fun x => CAramp id 10 (1 / 10) (1 / 2) 2 2 4 x) (9 / 20) 10 ∧
    HasDerivAt (fun x => CAramp id 10 (1 / 10) (1 / 2) 2 x 4 10) (-7 / 4) 2 ∧
    (2:ℝ) * (-7 / 4) = -7 / 2 ∧ -((4:ℝ) * (-1 / 4)) - 10 * (9 / 20) = -7 / 2 := by
  obtain ⟨h1, h2, h3⟩ := phi_partials (CAramp id 10 (1 / 10) (1 / 2) 2) _ _ _ _ _ _ _ 2 4 10 0
    _ (isOpen_Ucap 10 (1 / 2) 2) baseW_mem
    (fun x y z h => CAramp_cap id (continuous_id.intervalIntegrable 0 1) 10 (1 / 10) (1 / 2) 2
      x y z h) two_ne_zero
    (hasDerivAt_const _ _)
  rw [integral_id01] at h1 h2
  refine ⟨?_, ?_, ?_, by norm_num, by norm_num⟩
  · convert h2 using 1; norm_num
  · convert h3 using 1; norm_num
  · convert h1 using 1; norm_num

/-- **E1 worked instance, base W, A, arrival-on:** right side `4·0.5 − 4.5 = −2.5`, and
`s∂C_M/∂s = −2.5`. -/
theorem e1_A_arr_worked :
    HasDerivAt (fun x => CAarr id 10 (1 / 10) (1 / 2) 2 2 x 10) (-1 / 2) 4 ∧
    HasDerivAt (fun x => CAarr id 10 (1 / 10) (1 / 2) 2 2 4 x) (9 / 20) 10 ∧
    HasDerivAt (fun x => CAarr id 10 (1 / 10) (1 / 2) 2 x 4 10) (-5 / 4) 2 ∧
    (2:ℝ) * (-5 / 4) = -5 / 2 ∧ -((4:ℝ) * (-1 / 2)) - 10 * (9 / 20) = -5 / 2 := by
  obtain ⟨h1, h2, h3⟩ := phi_partials (CAarr id 10 (1 / 10) (1 / 2) 2) _ _ _ _ _ _ _ 2 4 10 0
    _ (isOpen_Ucap 10 (1 / 2) 2) baseW_mem
    (fun x y z h => CAarr_cap id 10 (1 / 10) (1 / 2) 2 x y z h) two_ne_zero
    (hasDerivAt_const _ _)
  refine ⟨?_, ?_, ?_, by norm_num, by norm_num⟩
  · convert h2 using 1; norm_num
  · convert h3 using 1; norm_num
  · convert h1 using 1; norm_num

theorem ivW_mem : ((1:ℝ), (4:ℝ), (6:ℝ)) ∈ Ucap 10 1 2 :=
  ⟨by norm_num, by norm_num, by norm_num, by norm_num, by norm_num⟩

/-- **E1 worked instance, speed-set, (iv)'s values at `K_D = 6`, arrival-on:**
`0.03 = 0.02·0.5·4 + 4·0.02 − 6·0.015`. -/
theorem e1_S_arr_worked :
    HasDerivAt (fun x => CSarr Λw 10 (5 / 1000) 1 2 x 4 6) (3 / 100) 1 ∧
    HasDerivAt (fun x => CSarr Λw 10 (5 / 1000) 1 2 1 x 6) (-2 / 100) 4 ∧
    HasDerivAt (fun x => CSarr Λw 10 (5 / 1000) 1 2 1 4 x) (15 / 1000) 6 ∧
    tDc 1 2 6 1 - 4 / 1 = 4 ∧
    (3 / 100 : ℝ) = 2 / 100 * (1 / 2) * 4 + 4 * (2 / 100) - 6 * (15 / 1000) := by
  obtain ⟨h1, h2, h3⟩ := phi_partials (CSarr Λw 10 (5 / 1000) 1 2) Λw _ _ _ _ _ _ 1 4 6 (1 / 100)
    _ (isOpen_Ucap 10 1 2) ivW_mem
    (fun x y z h => CSarr_cap Λw 10 (5 / 1000) 1 2 x y z h) one_ne_zero Λw_hasDerivAt
  rw [Λw_one] at h1 h2 h3
  refine ⟨?_, ?_, ?_, by rw [tDc_cap _ _ _ _ (by norm_num)]; norm_num, by norm_num⟩
  · convert h1 using 1; norm_num
  · convert h2 using 1; norm_num
  · convert h3 using 1; norm_num

/-- **E1 worked instance, speed-set, ramp-on:** `−0.01 = 0.02·0.5·8 + 0 − 6·0.015`. -/
theorem e1_S_ramp_worked :
    HasDerivAt (fun x => CSramp Λw 10 (5 / 1000) 1 2 x 4 6) (-1 / 100) 1 ∧
    HasDerivAt (fun x => CSramp Λw 10 (5 / 1000) 1 2 1 x 6) 0 4 ∧
    HasDerivAt (fun x => CSramp Λw 10 (5 / 1000) 1 2 1 4 x) (15 / 1000) 6 ∧
    tDc 1 2 6 1 = 8 ∧
    (-1 / 100 : ℝ) = 2 / 100 * (1 / 2) * 8 + 0 - 6 * (15 / 1000) := by
  obtain ⟨h1, h2, h3⟩ := phi_partials (CSramp Λw 10 (5 / 1000) 1 2) Λw _ _ _ _ _ _ 1 4 6 (1 / 100)
    _ (isOpen_Ucap 10 1 2) ivW_mem
    (fun x y z h => CSramp_cap Λw 10 (5 / 1000) 1 2 x y z h) one_ne_zero Λw_hasDerivAt
  rw [Λw_one] at h1 h2 h3
  refine ⟨?_, ?_, ?_, by rw [tDc_cap _ _ _ _ (by norm_num)]; norm_num, by norm_num⟩
  · convert h1 using 1; norm_num
  · convert h2 using 1; norm_num
  · convert h3 using 1; norm_num

/-- **Convention B at a constant profile: (H.1) holds.**  A constant `h_M` is shape-preserving,
so convention B's loss at it *is* convention A's (`rfl`), and Lemma H applies.  Hence "under B
the identity fails" is true *in general* (A4a.7(vii); `e1_B_counterexample`), not for every
profile. -/
theorem e1_B_constant_holds (c L P mD TD s KM KD : ℝ) (f' : ℝ × ℝ × ℝ →L[ℝ] ℝ)
    (hF : HasFDerivAt (fun q : ℝ × ℝ × ℝ => CBramp (fun _ => c) L P mD TD q.1 q.2.1 q.2.2) f'
      (s, KM, KD))
    (ds dK dD : ℝ) (hs : HasDerivAt (fun x => CBramp (fun _ => c) L P mD TD x KM KD) ds s)
    (hK : HasDerivAt (fun x => CBramp (fun _ => c) L P mD TD s x KD) dK KM)
    (hD : HasDerivAt (fun x => CBramp (fun _ => c) L P mD TD s KM x) dD KD) :
    s * ds + KM * dK + KD * dD = 0 :=
  lemmaH1_A_ramp (fun _ => c) L P mD TD s KM KD f' hF ds dK dD hs hK hD

/-- **Convention B at a constant profile: a point where the identity holds** (base W,
`h_M ≡ 1`).  The three partials of the defined convention-B loss exist there and satisfy
`s∂C/∂s = −K_M∂C/∂K_M − K_D∂C/∂K_D`; with `e1_B_counterexample`, B "fails in general", not
everywhere. -/
theorem e1_B_constant_baseW :
    ∃ ds dK dD : ℝ, HasDerivAt (fun x => CBramp (fun _ => 1) 10 (1 / 10) (1 / 2) 2 x 4 10) ds 2 ∧
      HasDerivAt (fun x => CBramp (fun _ => 1) 10 (1 / 10) (1 / 2) 2 2 x 10) dK 4 ∧
      HasDerivAt (fun x => CBramp (fun _ => 1) 10 (1 / 10) (1 / 2) 2 2 4 x) dD 10 ∧
      2 * ds = -(4 * dK) - 10 * dD := by
  have ht : tDc (1 / 2) 2 10 2 = 6 := by rw [tDc_cap _ _ _ _ (by norm_num)]; norm_num
  exact e1_A_ramp_cap (fun _ => 1) intervalIntegrable_const 10 (1 / 10) (1 / 2) 2 2 4 10
    (by norm_num) (by norm_num) (by norm_num) (by rw [ht]; norm_num) (by rw [ht]; norm_num)

/-! ## Fix round 1: `∂F/∂Λ` at a point, (H.2) wherever differentiable, the `m_DT_D` failures,
E4 at `K_M = 0`, and E3's limits -/

/-- **`∂F/∂Λ = t_D`, speed-set ramp-on, whenever `0 ≤ t_D ≤ L`.**  At a fixed `(s, K_M, K_D)` the
loss is affine in the intensity held at a number, so no open region is needed and `K_M` plays no
part. -/
theorem e1_dF_dLam_ramp (L P mD TD s KM KD lam0 : ℝ) (h0 : 0 ≤ tDc mD TD KD s)
    (hL : tDc mD TD KD s ≤ L) :
    HasDerivAt (fun lam => CSramp (fun _ => lam) L P mD TD s KM KD) (tDc mD TD KD s) lam0 := by
  have hfun : (fun lam => CSramp (fun _ => lam) L P mD TD s KM KD)
      = fun lam => lam * tDc mD TD KD s + P * (L - tDc mD TD KD s) :=
    funext fun lam => CRampClose_eq (fun _ => lam) L s _ P h0 hL
  rw [hfun]
  simpa using ((hasDerivAt_id' lam0).mul_const (tDc mD TD KD s)).add_const
    (P * (L - tDc mD TD KD s))

/-- With the step at or beyond the horizon (`L ≤ t_D`) the ramp-on exposure is the whole window:
`∂F/∂Λ = L`, not `t_D`. -/
theorem e1_dF_dLam_ramp_beyond (L P mD TD s KM KD lam0 : ℝ) (hL0 : 0 ≤ L)
    (hL : L ≤ tDc mD TD KD s) :
    HasDerivAt (fun lam => CSramp (fun _ => lam) L P mD TD s KM KD) L lam0 := by
  have hfun : (fun lam => CSramp (fun _ => lam) L P mD TD s KM KD) = fun lam => lam * L := by
    funext lam
    rw [CSramp, CRampClose, integral_congr_Ioo_of_le hL0 (g := fun _ : ℝ => lam) ?_,
      intervalIntegral.integral_const, smul_eq_mul]
    · ring
    · intro t ht; simp [step, lt_of_lt_of_le ht.2 hL]
  rw [hfun]
  simpa using (hasDerivAt_id' lam0).mul_const L

/-- **l.908's "`t_D` under ramp-on" fails beyond the horizon** (Sol's instance
`(s, K_M, K_D, m_D, T_D, L, h_M^post) = (1, 1/2, 2, 1, 1, 1, 0)`): the clock gives `t_D = 3 > L = 1`
and `∂F/∂Λ = 1 ≠ 3`. -/
theorem e1_dF_dLam_ramp_counterexample (lam0 : ℝ) :
    tDc 1 1 2 1 = 3 ∧
      HasDerivAt (fun lam => CSramp (fun _ => lam) 1 0 1 1 1 (1 / 2) 2) 1 lam0 ∧ (1:ℝ) ≠ 3 := by
  have ht : tDc 1 1 2 1 = 3 := by rw [tDc_cap _ _ _ _ (by norm_num)]; norm_num
  exact ⟨ht, e1_dF_dLam_ramp_beyond 1 0 1 1 1 (1 / 2) 2 lam0 zero_le_one (by rw [ht]; norm_num),
    by norm_num⟩

/-- **`∂F/∂Λ = t_D − τ_M`, speed-set arrival-on, whenever `0 ≤ τ_M ≤ t_D ≤ L`** (the boundary
`t_D = τ_M` included, where the value is `0`). -/
theorem e1_dF_dLam_arr (L P mD TD s KM KD lam0 : ℝ) (hτ : 0 ≤ KM / s)
    (harr : KM / s ≤ tDc mD TD KD s) (hL : tDc mD TD KD s ≤ L) :
    HasDerivAt (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD)
      (tDc mD TD KD s - KM / s) lam0 := by
  have hfun : (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD)
      = fun lam => lam * (tDc mD TD KD s - KM / s) + P * (L - tDc mD TD KD s) :=
    funext fun lam => CArrClose_eq (fun _ => lam) KM L s _ P hτ harr hL
  rw [hfun]
  simpa using ((hasDerivAt_id' lam0).mul_const (tDc mD TD KD s - KM / s)).add_const
    (P * (L - tDc mD TD KD s))

/-- **`∂F/∂Λ = 0` when the defence comes first** (`t_D ≤ τ_M ≤ L`, closed conditions). -/
theorem e1_dF_dLam_arr_first (L P mD TD s KM KD lam0 : ℝ) (hτ : 0 ≤ KM / s)
    (hD : tDc mD TD KD s ≤ KM / s) (hL : KM / s ≤ L) :
    HasDerivAt (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD) 0 lam0 := by
  have hfun : (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD) = fun _ => P * (L - KM / s) :=
    funext fun lam => CArrClose_eq_before (fun _ => lam) KM L s _ P hτ hD hL
  rw [hfun]
  exact hasDerivAt_const _ _

/-- Arrival-on with the step at or beyond the horizon (`τ_M ≤ L ≤ t_D`): `∂F/∂Λ = L − τ_M`. -/
theorem e1_dF_dLam_arr_beyond (L P mD TD s KM KD lam0 : ℝ) (hτ : 0 ≤ KM / s)
    (hτL : KM / s ≤ L) (hL : L ≤ tDc mD TD KD s) :
    HasDerivAt (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD) (L - KM / s) lam0 := by
  have hL0 : (0:ℝ) ≤ L := le_trans hτ hτL
  have hfun : (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD)
      = fun lam => lam * (L - KM / s) := by
    funext lam
    rw [CSarr, CArrClose, integral_congr_Ioo_of_le hL0 (g := step 0 lam (KM / s)) ?_,
      integral_step 0 lam 0 (KM / s) L hτ hτL]
    · ring
    · intro t ht; simp [step, step2, lt_of_lt_of_le ht.2 hL]
  rw [hfun]
  simpa using (hasDerivAt_id' lam0).mul_const (L - KM / s)

/-- **(H.2) from the homogeneity of `F`, wherever `F` is differentiable.**  `G(λ, s, K_M, K_D)`
is the loss with the intensity held at the number `λ`.  If `G` is Fréchet differentiable at
`(Λ_M(s), s, K_M, K_D)` and homogeneous of degree zero in `(s, K_M, K_D)` at `λ = Λ_M(s)`, then
`C_M(s) = G(Λ_M(s), s, K_M, K_D)` satisfies `s∂C_M/∂s = sΛ′·∂F/∂Λ − K_M∂C_M/∂K_M − K_D∂C_M/∂K_D`. -/
theorem euler_H2 (G : ℝ × ℝ × ℝ × ℝ → ℝ) (Λ : ℝ → ℝ) (s KM KD lam' : ℝ)
    (g' : ℝ × ℝ × ℝ × ℝ →L[ℝ] ℝ) (hG : HasFDerivAt G g' (Λ s, s, KM, KD))
    (hhom : ∀ k : ℝ, 0 < k → G (Λ s, k * s, k * KM, k * KD) = G (Λ s, s, KM, KD))
    (hΛ : HasDerivAt Λ lam' s) (ds dK dD dL : ℝ)
    (hs : HasDerivAt (fun x => G (Λ x, x, KM, KD)) ds s)
    (hK : HasDerivAt (fun x => G (Λ s, s, x, KD)) dK KM)
    (hD : HasDerivAt (fun x => G (Λ s, s, KM, x)) dD KD)
    (hL : HasDerivAt (fun l => G (l, s, KM, KD)) dL (Λ s)) :
    s * ds = s * lam' * dL - KM * dK - KD * dD := by
  have hray : HasDerivAt (fun k : ℝ => ((Λ s, k * s, k * KM, k * KD) : ℝ × ℝ × ℝ × ℝ))
      ((0:ℝ), s, KM, KD) 1 :=
    ((hasDerivAt_const (1:ℝ) (Λ s)).prodMk (((hasDerivAt_id' (1:ℝ)).mul_const s).prodMk
      (((hasDerivAt_id' (1:ℝ)).mul_const KM).prodMk
        ((hasDerivAt_id' (1:ℝ)).mul_const KD)))).congr_deriv (by simp)
  have hG' : HasFDerivAt G g'
      ((fun k : ℝ => ((Λ s, k * s, k * KM, k * KD) : ℝ × ℝ × ℝ × ℝ)) 1) := by simpa using hG
  have hcomp := hG'.comp_hasDerivAt (1:ℝ) hray
  have hev : (G ∘ fun k : ℝ => ((Λ s, k * s, k * KM, k * KD) : ℝ × ℝ × ℝ × ℝ))
      =ᶠ[𝓝 (1:ℝ)] fun _ => G (Λ s, s, KM, KD) := by
    filter_upwards [(isOpen_Ioi.eventually_mem (show (1:ℝ) ∈ Ioi 0 by norm_num))] with k hk
    exact hhom k hk
  have h0 : g' ((0:ℝ), s, KM, KD) = 0 :=
    hcomp.unique ((hasDerivAt_const (1:ℝ) (G (Λ s, s, KM, KD))).congr_of_eventuallyEq hev)
  have g1 : HasDerivAt (fun x => G (Λ x, x, KM, KD)) (g' (lam', (1:ℝ), (0:ℝ), (0:ℝ))) s :=
    hG.comp_hasDerivAt s (hΛ.prodMk ((hasDerivAt_id' s).prodMk
      ((hasDerivAt_const s KM).prodMk (hasDerivAt_const s KD))))
  have g2 : HasDerivAt (fun x => G (Λ s, s, x, KD)) (g' ((0:ℝ), (0:ℝ), (1:ℝ), (0:ℝ))) KM :=
    hG.comp_hasDerivAt KM ((hasDerivAt_const KM (Λ s)).prodMk ((hasDerivAt_const KM s).prodMk
      ((hasDerivAt_id' KM).prodMk (hasDerivAt_const KM KD))))
  have g3 : HasDerivAt (fun x => G (Λ s, s, KM, x)) (g' ((0:ℝ), (0:ℝ), (0:ℝ), (1:ℝ))) KD :=
    hG.comp_hasDerivAt KD ((hasDerivAt_const KD (Λ s)).prodMk ((hasDerivAt_const KD s).prodMk
      ((hasDerivAt_const KD KM).prodMk (hasDerivAt_id' KD))))
  have g4 : HasDerivAt (fun l => G (l, s, KM, KD)) (g' ((1:ℝ), (0:ℝ), (0:ℝ), (0:ℝ))) (Λ s) :=
    hG.comp_hasDerivAt (Λ s) ((hasDerivAt_id' (Λ s)).prodMk ((hasDerivAt_const (Λ s) s).prodMk
      ((hasDerivAt_const (Λ s) KM).prodMk (hasDerivAt_const (Λ s) KD))))
  have hsplit0 : ((0:ℝ), s, KM, KD) = s • ((0:ℝ), (1:ℝ), (0:ℝ), (0:ℝ))
      + KM • ((0:ℝ), (0:ℝ), (1:ℝ), (0:ℝ)) + KD • ((0:ℝ), (0:ℝ), (0:ℝ), (1:ℝ)) := by
    ext <;> simp
  have hsplit1 : (lam', (1:ℝ), (0:ℝ), (0:ℝ))
      = lam' • ((1:ℝ), (0:ℝ), (0:ℝ), (0:ℝ)) + ((0:ℝ), (1:ℝ), (0:ℝ), (0:ℝ)) := by
    ext <;> simp
  rw [hsplit0, map_add, map_add, map_smul, map_smul, map_smul, smul_eq_mul, smul_eq_mul,
    smul_eq_mul] at h0
  rw [hs.unique g1, hK.unique g2, hD.unique g3, hL.unique g4, hsplit1, map_add, map_smul,
    smul_eq_mul]
  linear_combination h0

/-- **(H.2), speed-set arrival-on, wherever `F` is differentiable.** -/
theorem lemmaH2_S_arr (Λ : ℝ → ℝ) (L P mD TD s KM KD lam' : ℝ) (g' : ℝ × ℝ × ℝ × ℝ →L[ℝ] ℝ)
    (hG : HasFDerivAt (fun p : ℝ × ℝ × ℝ × ℝ =>
      CSarr (fun _ => p.1) L P mD TD p.2.1 p.2.2.1 p.2.2.2) g' (Λ s, s, KM, KD))
    (hΛ : HasDerivAt Λ lam' s) (ds dK dD dL : ℝ)
    (hs : HasDerivAt (fun x => CSarr Λ L P mD TD x KM KD) ds s)
    (hK : HasDerivAt (fun x => CSarr Λ L P mD TD s x KD) dK KM)
    (hD : HasDerivAt (fun x => CSarr Λ L P mD TD s KM x) dD KD)
    (hL : HasDerivAt (fun lam => CSarr (fun _ => lam) L P mD TD s KM KD) dL (Λ s)) :
    s * ds = s * lam' * dL - KM * dK - KD * dD :=
  euler_H2 _ Λ s KM KD lam' g' hG (fun k hk => lemmaH_S_arr (Λ s) L P mD TD s KM KD k hk) hΛ
    ds dK dD dL hs hK hD hL

/-- **(H.2), speed-set ramp-on, wherever `F` is differentiable.** -/
theorem lemmaH2_S_ramp (Λ : ℝ → ℝ) (L P mD TD s KM KD lam' : ℝ) (g' : ℝ × ℝ × ℝ × ℝ →L[ℝ] ℝ)
    (hG : HasFDerivAt (fun p : ℝ × ℝ × ℝ × ℝ =>
      CSramp (fun _ => p.1) L P mD TD p.2.1 p.2.2.1 p.2.2.2) g' (Λ s, s, KM, KD))
    (hΛ : HasDerivAt Λ lam' s) (ds dK dD dL : ℝ)
    (hs : HasDerivAt (fun x => CSramp Λ L P mD TD x KM KD) ds s)
    (hK : HasDerivAt (fun x => CSramp Λ L P mD TD s x KD) dK KM)
    (hD : HasDerivAt (fun x => CSramp Λ L P mD TD s KM x) dD KD)
    (hL : HasDerivAt (fun lam => CSramp (fun _ => lam) L P mD TD s KM KD) dL (Λ s)) :
    s * ds = s * lam' * dL - KM * dK - KD * dD :=
  euler_H2 _ Λ s KM KD lam' g' hG (fun k hk => lemmaH_S_ramp (Λ s) L P mD TD s KM KD k hk) hΛ
    ds dK dD dL hs hK hD hL

theorem tDc_one (T KD x : ℝ) (hx : 0 < x) (hKD : 0 ≤ KD) : tDc 1 T KD x = KD / x + T := by
  rw [tDc_cap _ _ _ _ (by rw [sub_self, zero_mul]; positivity)]; ring

theorem ev_half_two : ∀ᶠ x in 𝓝 (1:ℝ), 1 / 2 < x ∧ x < 2 := by
  filter_upwards [Ioo_mem_nhds (show (1 / 2 : ℝ) < 1 by norm_num) (show (1:ℝ) < 2 by norm_num)]
    with x hx using hx

theorem ev_pos_two : ∀ᶠ x in 𝓝 (1:ℝ), 0 < x ∧ x < 2 := by
  filter_upwards [Ioo_mem_nhds (show (0:ℝ) < 1 by norm_num) (show (1:ℝ) < 2 by norm_num)]
    with x hx using hx

/-- **"… and `m_DT_D` held fixed", speed-set ramp-on.**  Let the build time respond to speed,
`T_D(s) = s`, with `m_D = 1`, `Λ_M ≡ 1`, `h_M^post = 0`, `L = 10`, at `s = K_M = K_D = 1`
(`t_D = K_D/s + s = 2`).  The loss of `(s, K_M, K_D)` is the defined `CSramp` with `T_D := s`:
`s∂C/∂s = 0`, but `sΛ′ℓ_M − K_M∂C/∂K_M − K_D∂C/∂K_D = −1`. -/
theorem e1_mDTD_S_ramp :
    HasDerivAt (fun x => CSramp (fun _ => 1) 10 0 1 x x 1 1) 0 1 ∧
    HasDerivAt (fun y => CSramp (fun _ => 1) 10 0 1 1 1 y 1) 0 1 ∧
    HasDerivAt (fun z => CSramp (fun _ => 1) 10 0 1 1 1 1 z) 1 1 ∧
    (1:ℝ) * 0 ≠ 1 * 0 * tDc 1 1 1 1 - 1 * 0 - 1 * 1 := by
  refine ⟨?_, hasDerivAt_const (1:ℝ) (CSramp (fun _ => (1:ℝ)) 10 0 1 1 1 1 1), ?_, by norm_num⟩
  · have heq : (fun x => CSramp (fun _ => 1) 10 0 1 x x 1 1) =ᶠ[𝓝 1] fun x => x⁻¹ + x := by
      filter_upwards [ev_half_two] with x hx
      have hx0 : 0 < x := by linarith [hx.1]
      have hinv : 1 / x ≤ 2 := by rw [div_le_iff₀ hx0]; linarith [hx.1]
      rw [CSramp, tDc_one x 1 x hx0 zero_le_one,
        CRampClose_eq _ 10 x _ 0 (add_pos (one_div_pos.mpr hx0) hx0).le (by linarith [hx.2])]
      simp only [one_mul, zero_mul, add_zero, one_div]
    have hd : HasDerivAt (fun x : ℝ => x⁻¹ + x) 0 1 := by
      convert (hasDerivAt_inv (one_ne_zero : (1:ℝ) ≠ 0)).add (hasDerivAt_id' (1:ℝ)) using 1
      norm_num
    exact hd.congr_of_eventuallyEq heq
  · have heq : (fun z => CSramp (fun _ => 1) 10 0 1 1 1 1 z) =ᶠ[𝓝 1] fun z => z + 1 := by
      filter_upwards [ev_pos_two] with z hz
      rw [CSramp, tDc_one 1 z 1 one_pos hz.1.le, div_one,
        CRampClose_eq _ 10 1 _ 0 (by linarith [hz.1]) (by linarith [hz.2])]
      simp only [one_mul, zero_mul, add_zero]
    exact ((hasDerivAt_id' (1:ℝ)).add_const 1).congr_of_eventuallyEq heq

/-- **"… and `m_DT_D` held fixed", speed-set arrival-on**, at the same point: `s∂C/∂s = 1`, but
the right side of (H.2) is `0`. -/
theorem e1_mDTD_S_arr :
    HasDerivAt (fun x => CSarr (fun _ => 1) 10 0 1 x x 1 1) 1 1 ∧
    HasDerivAt (fun y => CSarr (fun _ => 1) 10 0 1 1 1 y 1) (-1) 1 ∧
    HasDerivAt (fun z => CSarr (fun _ => 1) 10 0 1 1 1 1 z) 1 1 ∧
    (1:ℝ) * 1 ≠ 1 * 0 * (tDc 1 1 1 1 - 1 / 1) - 1 * (-1) - 1 * 1 := by
  have ht : tDc 1 1 1 1 = 2 := by rw [tDc_one 1 1 1 one_pos zero_le_one]; norm_num
  refine ⟨?_, ?_, ?_, by rw [ht]; norm_num⟩
  · have heq : (fun x => CSarr (fun _ => 1) 10 0 1 x x 1 1) =ᶠ[𝓝 1] fun x => x := by
      filter_upwards [ev_half_two] with x hx
      have hx0 : 0 < x := by linarith [hx.1]
      have hinv : 1 / x ≤ 2 := by rw [div_le_iff₀ hx0]; linarith [hx.1]
      rw [CSarr, tDc_one x 1 x hx0 zero_le_one,
        CArrClose_eq _ 1 10 x _ 0 (one_div_pos.mpr hx0).le (by linarith) (by linarith [hx.2])]
      simp only [one_mul, zero_mul, add_zero]
      ring
    exact (hasDerivAt_id' (1:ℝ)).congr_of_eventuallyEq heq
  · have heq : (fun y => CSarr (fun _ => 1) 10 0 1 1 1 y 1) =ᶠ[𝓝 1] fun y => 2 - y := by
      filter_upwards [ev_pos_two] with y hy
      rw [CSarr, ht, CArrClose_eq _ y 10 1 2 0 (by rw [div_one]; exact hy.1.le)
        (by rw [div_one]; exact hy.2.le) (by norm_num)]
      simp only [one_mul, zero_mul, add_zero, div_one]
    exact ((hasDerivAt_id' (1:ℝ)).const_sub 2).congr_of_eventuallyEq heq
  · have heq : (fun z => CSarr (fun _ => 1) 10 0 1 1 1 1 z) =ᶠ[𝓝 1] fun z => z := by
      filter_upwards [ev_pos_two] with z hz
      rw [CSarr, tDc_one 1 z 1 one_pos hz.1.le, div_one,
        CArrClose_eq _ 1 10 1 (z + 1) 0 (by norm_num) (by rw [div_one]; linarith [hz.1])
          (by linarith [hz.2])]
      simp only [one_mul, zero_mul, add_zero, div_one]
      ring
    exact (hasDerivAt_id' (1:ℝ)).congr_of_eventuallyEq heq

/-- **"… and `m_DT_D` held fixed", level-set A ramp-on** (`ĥ ≡ 1`, the same point): `s∂C/∂s = 0`
but the right side of (H.1) is `−1`. -/
theorem e1_mDTD_A_ramp :
    HasDerivAt (fun x => CAramp (fun _ => 1) 10 0 1 x x 1 1) 0 1 ∧
    HasDerivAt (fun y => CAramp (fun _ => 1) 10 0 1 1 1 y 1) 0 1 ∧
    HasDerivAt (fun z => CAramp (fun _ => 1) 10 0 1 1 1 1 z) 1 1 ∧
    (1:ℝ) * 0 ≠ -(1 * 0) - 1 * 1 := by
  simp only [CAramp_const]
  exact ⟨e1_mDTD_S_ramp.1, e1_mDTD_S_ramp.2.1, e1_mDTD_S_ramp.2.2.1, by norm_num⟩

/-- **"… and `m_DT_D` held fixed", level-set A arrival-on** (`ĥ ≡ 1`): `s∂C/∂s = 1` but the right
side of (H.1) is `0`. -/
theorem e1_mDTD_A_arr :
    HasDerivAt (fun x => CAarr (fun _ => 1) 10 0 1 x x 1 1) 1 1 ∧
    HasDerivAt (fun y => CAarr (fun _ => 1) 10 0 1 1 1 y 1) (-1) 1 ∧
    HasDerivAt (fun z => CAarr (fun _ => 1) 10 0 1 1 1 1 z) 1 1 ∧
    (1:ℝ) * 1 ≠ -(1 * (-1)) - 1 * 1 := by
  simp only [CAarr_const]
  exact ⟨e1_mDTD_S_arr.1, e1_mDTD_S_arr.2.1, e1_mDTD_S_arr.2.2.1, by norm_num⟩

/-- **E4 at `K_M = 0`: "positive for every `ε_Λ ≥ 0`" fails.**  `h_M ≡ 0` (nonnegative,
nondecreasing on `[0, K_M]`), `Λ_M ≡ 1 > 0` with `Λ_M′ = 0` (so `ε_Λ = 0`), `K_M = 0`, `L = 1`,
`s = 1`, on the plateau (`τ_M = 0 < L`): both arrival-on derivatives are `0`.  (The observer's
`obs_E4_K0`, with the hypotheses exhibited.) -/
theorem e4_K0_counterexample :
    MonotoneOn (fun _ : ℝ => (0:ℝ)) (Icc 0 0) ∧ (∀ c : ℝ, 0 ≤ (fun _ : ℝ => (0:ℝ)) c) ∧
    HasDerivAt (fun _ : ℝ => (1:ℝ)) 0 1 ∧ (0:ℝ) < 1 ∧ (0:ℝ) / 1 < 1 ∧
    deriv (fun x => CMixAddArrSpeed (fun _ => 0) (fun _ => 1) 0 1 x) 1 = 0 ∧
    deriv (fun x => CMixAddArrBoth (fun _ => 0) (fun _ => 1) 0 1 x) 1 = 0 := by
  have h1 : ∀ x : ℝ, CMixAddArrSpeed (fun _ => 0) (fun _ => 1) 0 1 x = 1 := by
    intro x
    simp only [CMixAddArrSpeed, zero_div, zero_add]
    rw [integral_step 0 1 0 0 1 (le_refl _) (by norm_num)]; norm_num
  have h2 : ∀ x : ℝ, CMixAddArrBoth (fun _ => 0) (fun _ => 1) 0 1 x = 1 := by
    intro x
    have : (fun t : ℝ => gatedLevel (fun _ => (0:ℝ)) 0 (min (x * t) 0) + step 0 1 (0 / x) t)
        = step 0 1 0 := by
      funext t; simp [gatedLevel]
    simp only [CMixAddArrBoth]
    rw [this, integral_step 0 1 0 0 1 (le_refl _) (by norm_num)]; norm_num
  refine ⟨monotoneOn_const, fun _ => le_rfl, hasDerivAt_const _ _, by norm_num, by norm_num,
    ?_, ?_⟩
  · rw [show (fun x => CMixAddArrSpeed (fun _ => 0) (fun _ => 1) 0 1 x) = fun _ => (1:ℝ) from
      funext h1]; simp
  · rw [show (fun x => CMixAddArrBoth (fun _ => 0) (fun _ => 1) 0 1 x) = fun _ => (1:ℝ) from
      funext h2]; simp

/-- The derivative of the defined arrival-on loss at a speed where the defence comes first:
`C_M = h_M^post(L − τ_M)` nearby, so `C_M′ = h_M^post·K_M/s²`. -/
theorem defFirst_hasDerivAt (Λ : ℝ → ℝ) (L P mD TD s KM KD : ℝ) (hs : 0 < s) (hKM : 0 ≤ KM)
    (hfirst : tDc mD TD KD s < KM / s) (hL : KM / s < L) :
    HasDerivAt (fun x => CSarr Λ L P mD TD x KM KD) (P * (KM / s ^ 2)) s := by
  have hKx : HasDerivAt (fun x : ℝ => KM / x) (-(KM / s ^ 2)) s := by
    have h := (hasDerivAt_inv hs.ne').const_mul KM
    simp only [div_eq_mul_inv]
    convert h using 1; ring
  have htc : ContinuousAt (fun x => tDc mD TD KD x) s := by
    unfold tDc
    exact ((continuousAt_const.div continuousAt_id hs.ne').max continuousAt_const).add
      continuousAt_const
  have hKc : ContinuousAt (fun x : ℝ => KM / x) s := continuousAt_const.div continuousAt_id hs.ne'
  have hev1 : ∀ᶠ x in 𝓝 s, tDc mD TD KD x < KM / x := htc.eventually_lt hKc hfirst
  have hev2 : ∀ᶠ x in 𝓝 s, KM / x < L :=
    hKc.eventually ((isOpen_Iio.eventually_mem hL).mono fun _ h => h)
  have hpos : ∀ᶠ x in 𝓝 s, (0:ℝ) < x := (isOpen_Ioi.eventually_mem hs).mono fun _ h => h
  have hev : (fun x => CSarr Λ L P mD TD x KM KD) =ᶠ[𝓝 s] fun x => P * (L - KM / x) := by
    filter_upwards [hev1, hev2, hpos] with x h1 h2 h0
    exact CArrClose_eq_before Λ KM L x _ P (by positivity) h1.le h2.le
  convert ((hKx.const_sub L).const_mul P).congr_of_eventuallyEq hev using 1
  ring

/-- **E3, the defence-before-arrival side as a limit:** `s·C_M′(s) → h_M^post·τ_M` as `s ↑ s₀`
(equivalently `t_D − τ_M ↑ 0`), with no regularity of `Λ_M`. -/
theorem e3_left_limit (Λ : ℝ → ℝ) (L P mD TD s₀ KM KD : ℝ) (hs : 0 < s₀) (hKM : 0 ≤ KM)
    (hbr : (1 - mD) * TD < KD / s₀) (hbd : tDc mD TD KD s₀ = KM / s₀) (hL : KM / s₀ < L)
    (hmT : 0 < mD * TD) :
    Tendsto (fun s => s * deriv (fun x => CSarr Λ L P mD TD x KM KD) s) (𝓝[<] s₀)
      (𝓝 (P * (KM / s₀))) := by
  have hKc : ContinuousAt (fun x : ℝ => KM / x) s₀ := continuousAt_const.div continuousAt_id hs.ne'
  have hg : Tendsto (fun s : ℝ => P * (KM / s)) (𝓝[<] s₀) (𝓝 (P * (KM / s₀))) :=
    (continuousAt_const.mul hKc).tendsto.mono_left nhdsWithin_le_nhds
  refine hg.congr' ?_
  have hpos : ∀ᶠ s in 𝓝 s₀, (0:ℝ) < s := (isOpen_Ioi.eventually_mem hs).mono fun _ h => h
  have hlt : ∀ᶠ s in 𝓝 s₀, KM / s < L :=
    hKc.eventually ((isOpen_Iio.eventually_mem hL).mono fun _ h => h)
  filter_upwards [(e3_sides mD TD s₀ KM KD hs hbr hbd hmT).2, nhdsWithin_le_nhds hpos,
    nhdsWithin_le_nhds hlt] with s h1 h0 h2
  rw [(defFirst_hasDerivAt Λ L P mD TD s KM KD h0 hKM h1 h2).deriv]
  field_simp

/-- **E3, the positive-exposure side as a limit:** the own-distance form `s·C_M′(s)` tends to
`Λ_Mτ_M − τ_D(Λ_M − h_M^post)` as `s ↓ s₀` (equivalently `t_D − τ_M ↓ 0`), when `Λ_M` is
differentiable near `s₀` with derivative continuous at `s₀`.  (Without that, `sΛ_M′(t_D − τ_M)`
need not vanish; `e3_right` gives the one-sided derivative under differentiability at `s₀`
alone.) -/
theorem e3_right_limit (Λ Λ' : ℝ → ℝ) (L P mD TD s₀ KM KD : ℝ) (hs : 0 < s₀) (hKM : 0 ≤ KM)
    (hΛ : ∀ᶠ s in 𝓝 s₀, HasDerivAt Λ (Λ' s) s) (hΛ'c : ContinuousAt Λ' s₀)
    (hbr : (1 - mD) * TD < KD / s₀) (hbd : tDc mD TD KD s₀ = KM / s₀) (hL : KM / s₀ < L)
    (hmT : 0 < mD * TD) :
    Tendsto (fun s => s * deriv (fun x => CSarr Λ L P mD TD x KM KD) s) (𝓝[>] s₀)
      (𝓝 (Λ s₀ * (KM / s₀) - KD / s₀ * (Λ s₀ - P))) := by
  have hcd : ContinuousAt (fun x : ℝ => KD / x) s₀ := continuousAt_const.div continuousAt_id hs.ne'
  have hKc : ContinuousAt (fun x : ℝ => KM / x) s₀ := continuousAt_const.div continuousAt_id hs.ne'
  have htc : ContinuousAt (fun x => tDc mD TD KD x) s₀ :=
    (tDc_hasDerivAt_cap mD TD KD s₀ hs hbr).continuousAt
  have hΛc : ContinuousAt Λ s₀ := hΛ.self_of_nhds.continuousAt
  have hp : s₀ ^ 2 ≠ 0 := pow_ne_zero 2 hs.ne'
  have hKD2 : ContinuousAt (fun x : ℝ => KD / x ^ 2) s₀ :=
    continuousAt_const.div (continuousAt_id.pow 2) hp
  have hKM2 : ContinuousAt (fun x : ℝ => KM / x ^ 2) s₀ :=
    continuousAt_const.div (continuousAt_id.pow 2) hp
  have hgc : ContinuousAt (fun s : ℝ => s * (Λ' s * (tDc mD TD KD s - KM / s)
      + Λ s * (-(KD / s ^ 2) + KM / s ^ 2) + P * -(-(KD / s ^ 2)))) s₀ :=
    continuousAt_id.mul (((hΛ'c.mul (htc.sub hKc)).add (hΛc.mul (hKD2.neg.add hKM2))).add
      (continuousAt_const.mul hKD2.neg.neg))
  have hpos : ∀ᶠ s in 𝓝 s₀, (0:ℝ) < s := (isOpen_Ioi.eventually_mem hs).mono fun _ h => h
  have hbrE : ∀ᶠ s in 𝓝 s₀, (1 - mD) * TD < KD / s :=
    hcd.eventually ((isOpen_Ioi.eventually_mem hbr).mono fun _ h => h)
  have hL' : tDc mD TD KD s₀ < L := by rw [hbd]; exact hL
  have hhorE : ∀ᶠ s in 𝓝 s₀, tDc mD TD KD s < L :=
    htc.eventually ((isOpen_Iio.eventually_mem hL').mono fun _ h => h)
  have hEq : (fun s : ℝ => s * (Λ' s * (tDc mD TD KD s - KM / s)
      + Λ s * (-(KD / s ^ 2) + KM / s ^ 2) + P * -(-(KD / s ^ 2))))
      =ᶠ[𝓝[>] s₀] fun s => s * deriv (fun x => CSarr Λ L P mD TD x KM KD) s := by
    filter_upwards [(e3_sides mD TD s₀ KM KD hs hbr hbd hmT).1, nhdsWithin_le_nhds hpos,
      nhdsWithin_le_nhds hbrE, nhdsWithin_le_nhds hhorE, nhdsWithin_le_nhds hΛ]
      with s harr h0 hb hh hd
    rw [(e2_speed_marginal Λ L P mD TD s KM KD (Λ' s) hKM h0 hd hb harr hh).deriv]
  have key := (hgc.tendsto.mono_left nhdsWithin_le_nhds).congr' hEq
  convert key using 2
  simp only [hbd, sub_self, mul_zero, zero_add]
  field_simp
  ring

end BioPaper.PostE

open BioPaper.PostE in
section
#print axioms phi_partials
#print axioms baseW_mem
#print axioms integral_id01
#print axioms e1_A_ramp_worked
#print axioms e1_A_arr_worked
#print axioms ivW_mem
#print axioms e1_S_arr_worked
#print axioms e1_S_ramp_worked
#print axioms e1_B_constant_holds
#print axioms tDc_cap
#print axioms tDc_adopt
#print axioms tDc_scale
#print axioms tDc_hasDerivAt_cap
#print axioms CLevArr_eq_CArrClose
#print axioms CRampClose_eq
#print axioms CArrClose_eq_before
#print axioms lemmaH_A_ramp
#print axioms lemmaH_A_arr
#print axioms CSarr_eq_F
#print axioms CSramp_eq_F
#print axioms lemmaH_S_arr
#print axioms lemmaH_S_ramp
#print axioms euler_deg0
#print axioms euler_partials
#print axioms lemmaH1_A_ramp
#print axioms lemmaH1_A_arr
#print axioms sections_eventually
#print axioms phi_euler
#print axioms isOpen_Ucap
#print axioms isOpen_Uadopt
#print axioms of_mem_Ucap
#print axioms mem_Ucap
#print axioms of_mem_Uadopt
#print axioms mem_Uadopt
#print axioms CAramp_cap
#print axioms CAramp_adopt
#print axioms CAarr_cap
#print axioms CAarr_adopt
#print axioms CSarr_cap
#print axioms CSarr_adopt
#print axioms CSramp_cap
#print axioms CSramp_adopt
#print axioms e1_A_ramp_cap
#print axioms e1_A_ramp_adopt
#print axioms e1_A_arr_cap
#print axioms e1_A_arr_adopt
#print axioms e1_S_arr_cap
#print axioms e1_S_arr_adopt
#print axioms e1_S_ramp_cap
#print axioms e1_S_ramp_adopt
#print axioms CBramp_quarter_cap
#print axioms e1_B_counterexample
#print axioms e2_speed_marginal
#print axioms e2_bracket
#print axioms e2_KD_coefficient
#print axioms e2_affine
#print axioms e2_coefficient_eps
#print axioms rampClose_hasDerivAt
#print axioms e2_ramp_bracket
#print axioms e2_ramp_KD_coefficient
#print axioms e3_posExposure
#print axioms e3_defenceFirst
#print axioms e3_gap
#print axioms e3_boundary
#print axioms e3_sides
#print axioms e3_accumulate
#print axioms e3_right
#print axioms e3_left
#print axioms e3_kink_iff
#print axioms e3_degenerate
#print axioms gatedLevel_path
#print axioms path_intervalIntegrable
#print axioms CLevPlateau_eq_int
#print axioms bracket_nonneg_of_monotoneOn
#print axioms CMixAddRamp_eq
#print axioms CMixAddArrSpeed_eq
#print axioms CMixAddArrBoth_eq
#print axioms plateau_eventually
#print axioms r2_lev_hasDerivAt_int
#print axioms e4_speedGated_hasDerivAt
#print axioms e4_speedGated_scaled
#print axioms e4_speedGated_pos
#print axioms e4_bothGated_hasDerivAt
#print axioms e4_bothGated_scaled
#print axioms e4_bothGated_pos
#print axioms e4_ramp_hasDerivAt
#print axioms e4_ramp_scaled
#print axioms e4_ramp_pos
#print axioms threshold_nonpos
#print axioms e4_ramp_threshold
#print axioms e4_speedGated_threshold
#print axioms e4_bothGated_threshold
#print axioms isOpen_UcapF
#print axioms isOpen_UadoptF
#print axioms of_mem_UcapF
#print axioms mem_UcapF
#print axioms of_mem_UadoptF
#print axioms mem_UadoptF
#print axioms CSarr_capF
#print axioms CSarr_adoptF
#print axioms e1_S_arr_defFirst_cap
#print axioms e1_S_arr_defFirst_adopt
#print axioms phi_dLam
#print axioms e1_dF_dLam_arr_cap
#print axioms e1_dF_dLam_arr_adopt
#print axioms e1_dF_dLam_ramp_cap
#print axioms e1_dF_dLam_ramp_adopt
#print axioms e1_dF_dLam_arr_defFirst
#print axioms tDc_ex
#print axioms ev_s
#print axioms ev_KD
#print axioms ev_KM
#print axioms half_div_le
#print axioms e1_residual_S_ramp
#print axioms e1_residual_S_arr
#print axioms CArampR_one
#print axioms e1_residual_A_ramp
#print axioms CAarrR_one
#print axioms e1_residual_A_arr
#print axioms Λw_one
#print axioms Λw_hasDerivAt
#print axioms e2_worked_instance
#print axioms e3_worked_instance
#print axioms CBefore_eq_CLev
#print axioms CAramp_eq_CLev
#print axioms CBramp_eq_CLev
#print axioms CAramp_const
#print axioms CAarr_const
#print axioms CLev_eq_int
#print axioms shape_intervalIntegrable
#print axioms CAramp_defFirst
#print axioms CAramp_defFirst_witness
#print axioms isOpen_UrampCap
#print axioms isOpen_UrampAdopt
#print axioms mem_UrampCap
#print axioms mem_UrampAdopt
#print axioms CSramp_rcap
#print axioms CSramp_radopt
#print axioms e1_B_constant_baseW
#print axioms e1_dF_dLam_ramp
#print axioms e1_dF_dLam_ramp_beyond
#print axioms e1_dF_dLam_ramp_counterexample
#print axioms e1_dF_dLam_arr
#print axioms e1_dF_dLam_arr_first
#print axioms e1_dF_dLam_arr_beyond
#print axioms euler_H2
#print axioms lemmaH2_S_arr
#print axioms lemmaH2_S_ramp
#print axioms tDc_one
#print axioms ev_half_two
#print axioms ev_pos_two
#print axioms e1_mDTD_S_ramp
#print axioms e1_mDTD_S_arr
#print axioms e1_mDTD_A_ramp
#print axioms e1_mDTD_A_arr
#print axioms e4_K0_counterexample
#print axioms defFirst_hasDerivAt
#print axioms e3_left_limit
#print axioms e3_right_limit
end
