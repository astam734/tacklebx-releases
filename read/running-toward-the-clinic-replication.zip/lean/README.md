# BioPaperProofs — the paper's mechanism results in Lean 4

Formalisation of **every result in the project's proof inventory** — all sixteen, in four groups —
with the integral-to-closed-form step that the first pass had assumed, in both specifications;
and, since 28 Oct 2026, of the paper's post-inventory rows E1–E4, G, H and I (S.4).

## Checking it

```bash
lake build && lake env lean BioPaperProofs/Axioms.lean
```

The build must end `Build completed successfully`, and the audit must print 344 lines each reading
`depends on axioms: [propext, Classical.choice, Quot.sound]` (346 theorems in all: 82 for the
inventory, whose two step-integrability helpers are reached through `intervalIntegrable_step`,
159 in `PostE.lean` and 105 in `PostGHI.lean`). Those three are Lean's standard axioms, used by
every Mathlib proof. **A `sorryAx` anywhere in that output means the result is not proved.** As of
28 Oct 2026 there is none, and no source file contains a `sorry` (build and audit output:
`build-and-audit-2026-10-28.txt`).

Toolchain: `leanprover/lean4:v4.35.0`, Mathlib pinned by `lake-manifest.json`.

## Layout

| File | What is in it |
|---|---|
| `StepIntegral.lean` | `step`, `step2` and their integrals. One- and two-step integrals over an interval, with integrability. This is the integral-to-closed-form machinery. |
| `Item1.lean` | The first pass at inventory item 1, which took the closed form as the *definition* of misuse loss. Kept as written. |
| `Group1.lean` | Misuse loss **defined as an integral**, the step to the closed form, and inventory items 1–6 on top of it. |
| `LevelSet.lean` | The level-set family: the change of variable to the capability integral, the closed forms, R1/R2/R3 in the speed, and inventory items 7–12 — the misuse-distance derivatives under both conventions and both readings. |
| `Group34.lean` | Inventory Groups 3 and 4: the responsive residual and its level-set counterpart, the benefit margin's rate derivative, and the separable mixed hazard. |
| `PostE.lean` | Rows E1–E4: the proportional-cut identity and its convention-B counterexample, the arrival-on `K_D` coefficient, the one-sided limits at the kink, and the additive mixed form under both gatings. Per-row statuses: `../LEDGER/LEAN-BIO-E-ROWS.md`. |
| `PostGHI.lean` | Rows G, H (Table 4b.A rows 1, 4, 5 and 2, 6, 7, with the gated level-set profile defined first) and I (the defence-distance derivative under level-set A, B and speed-set, both readings, with the translation theorem and the gradual-coverage cases). Per-row statuses: `../LEDGER/LEAN-BIO-GHI-ROWS.md`. |
| `Axioms.lean` | The audit. Nothing but `#print axioms`. |
| `AuditAll.lean` | A second, whole-project audit, not imported by the root and so not run by `lake build`: run it with `lake env lean BioPaperProofs/AuditAll.lean` after the build. It applies `Lean.collectAxioms` to every theorem constant in every `BioPaperProofs` module, compiler-generated ones included, and prints `AUDIT <n> theorems, <k> outside the standard three`, then any offender by name. On 28 Oct 2026 it printed `AUDIT 385 theorems, 0 outside the standard three` (`../LEDGER/LEAN-BIO-auditall.txt`); a planted `sorry` in a scratch module made it report that theorem with `sorryAx`. |
| `Basic.lean` | Imports the seven modules so `lake build` reaches them. |

## What the formalisation does and does not certify

Lean checks that these proofs prove *these statements*. It cannot check that the statements are
the paper's claims. The speed-set choices are below, repeated from the `Group1.lean` docstring;
the level-set ones — the two hazard shapes, convention A as `ĥ(c/K)` and B as the fixed profile,
`h̄_M` as `(∫_0^K h)/K`, and `Continuous h` as the regularity assumption — are in the
`LevelSet.lean` docstring.

1. **The hazard shape.** Arrival-on, speed-set, no closure is `step 0 (Λ s) (K/s)` — identically
   zero before `τ_M = K_M/s`, the constant `Λ_M(s)` from `τ_M` onward. With closure at `t_D` it
   is `step2 0 (Λ s) P (K/s) t_D`, with `P` the residual `h_M^post`. These formalise §4a.1's
   set-up; they are not consequences of it.
2. **The elasticity.** Statements are written with `Λ'` and multiplied through by `s`, never
   dividing by `Λ s`. Substituting `ε_Λ = s·Λ'/Λ` recovers the paper's printed form exactly when
   `Λ s ≠ 0`, which the paper assumes throughout.
3. **Items 5 and 6 are algebraic equivalences, not modelling claims.** What is certified is the
   rearrangement of a sign condition into the threshold `ᾱ_s^arr`, and of a net marginal into
   the printed benefit inequality. The marginals they are stated about come from items 1 and 4,
   which *are* proved of the integral.

## Item-by-item

| Inventory item | Theorems |
|---|---|
| the translation step | `CArr_eq`, `CArrClose_eq`, `CArrDisc_eq`, and the neighbourhood versions `CArr_eventuallyEq`, `CArrClose_eventuallyEq`, `CArrDisc_eventuallyEq` |
| **1** R2, the plateau | `r2_hasDerivAt` (of the integral), `r2_scaled`, `r2_pos` |
| **2** the same, discounted | `integral_exp_neg`, `r2_disc_hasDerivAt`, `r2_disc_scaled`, `r2_disc_pos` |
| **3** R1, truncation | `CArr_eq_zero`, `CArr_hasDerivAt_zero`, `r2_scaled_at_kink` |
| **4** R3, the defence clock | `r3_hasDerivAt` (of the integral), `r3_scaled` |
| **5** the arrival-on threshold | `alphaBar_arr`, `alphaBar_arr_reversed` |
| **6** the coupled benefit test | `coupled_benefit_test` |

Item 5's hypotheses are `0 < t_D` and `h_M^post < Λ_M`. The paper's further condition
`t_D > τ_M` is not needed for the rearrangement; it belongs to the derivation of the marginal,
where it appears as `r3_hasDerivAt`'s `harr`.

## The level-set family: where the moving boundaries are

Two of them, and they are different objects:

- **In the speed** (R1, truncation). The capability lies beyond the horizon, so the whole window
  is ramp and `C_M = (1/s)∫_0^{sL} h_M`. Acceleration moves the *upper limit* `sL`, which is what
  "pulls level-indexed risk into the window" means. `r1_lev_hasDerivAt` needs the fundamental
  theorem of calculus, not just the chain rule.
- **In the misuse distance** (items 7–12). Differentiating in `K_M` moves the boundary between
  ramp and plateau. Under convention B the ramp integral's upper limit contributes `+h_M(K_M)/s`
  and the shrinking plateau `−h_M(K_M)/s`, and **the two cancel** — which is why the derivative
  is `(t_D − τ_M)h_M′(K_M)` with no level term. `dKM_B_rampon` is that cancellation; the appendix
  states it as "the boundary terms cancel as in Lemma 1(b)".

Under arrival-on there is no ramp, so there is no term to cancel the plateau's, and the
derivative keeps `− h_M(K_M)/s`. The contrast between `dKM_B_rampon` and `dKM_B_arrivalon` is
exactly that missing term, and it is why monotonicity signs the first and not the second.

| Inventory item | Theorems |
|---|---|
| the change of variable | `ramp_integral`, `integral_shapePreserving` |
| the closed forms | `CLevPlateau_eq`, `CLevPlateau_eq_trunc`, `CLev_eq`, `CBeforeAInt_eq` + three `eventuallyEq` neighbourhood versions |
| R2, level-set | `r2_lev_hasDerivAt`, `r2_lev_scaled`, `r2_lev_paper_form` |
| R1, truncation | `r1_lev_hasDerivAt`, `r1_lev_scaled`, `r1_lev_paper_form` |
| the sign, by monotonicity | `integral_le_endpoint`, `hbar_le`, `hbar_le_of_monotone`, `r2_lev_bracket_nonneg` |
| R3, level-set | `r3_lev_scaled`, `r3_lev_paper_form`, `dtD_lev` |
| **7**, **8** `∂C_M/∂K_M` arrival-on, A and B | `dKM_A_arrivalon`, `dKM_B_arrivalon` |
| **9** convention-B facility inequalities | `facility_B_rampon_iff`, `facility_B_arrivalon_weight` |
| **10** defence before capability, B: zero | `dKM_B_before` |
| **11** the same under A | `CBeforeAInt_eq`, `dKM_A_before_int`, `dKM_A_before`, `dKM_A_before_nonpos` |
| **12** arrival-on slope and affineness under A | `facility_A_arrivalon_slope`, `CLev_A_affine` |
| the convention sign flip | `dKM_conventions_differ` |

Also `dKM_B_rampon` and `dKM_A_rampon`, the ramp-on misuse-distance derivatives, which the
inventory folds into items 7–9 rather than numbering separately.

## Groups 3 and 4

| Inventory item | Theorems |
|---|---|
| **13** responsive residual, speed-set | `CResp_eq`, `CResp_eventuallyEq`, `r3_resp_hasDerivAt`, `r3_resp_scaled` |
| **14** the level-set counterpart | `r3_lev_resp_iff` |
| **15** the benefit margin's rate derivative | `benefitMargin_zero`, `benefitMargin_hasDerivAt`, `benefitMargin_deriv_eq`, `benefitMargin_logDeriv`, `benefitMargin_logDeriv_pos_iff` |
| **16** the separable mixed form | `CMix_eq`, `CMix_eventuallyEq`, `CMix_hasDerivAt`, `r_mix_scaled`, `epsBar_g_iff`, `epsBar_g_eq_calendar_iff` |

**Item 13 is an interior term, not a boundary term.** The inventory's own wording for it — "the
Leibniz term from a moving boundary" — is what the paper's S.7 records as a mislabel. The
residual's response to speed is the derivative of the *integrand* on `[t_D, L]`, with both limits
held fixed. `r3_resp_hasDerivAt` states it beside the genuine moving-boundary term
`s·t_D′(Λ_M − P)`, so the two are visibly different objects in one statement.

**Item 15 is proved of the margin.** `benefitMargin_deriv_eq` factors the derivative as the
margin times the bracket, so the bracket *is* the logarithmic derivative rather than an
expression resembling one; `benefitMargin_logDeriv_pos_iff` then gives the interval
`r < log(1 + ℓ_B/t_B)/ℓ_B` exactly.

## Not formalised

The sixteen numbered results and the E, G, H and I rows are all covered. Where a row's Lean
statement needed a condition the paper's sentence omits, or a counterexample refutes the sentence
as printed, the row is NARROWED and its ROWS file gives the exact new wording; one G/H/I claim is
NUMERICAL. Nothing in those two ROWS files is OPEN.
