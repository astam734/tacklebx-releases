# Files in this package

Every file, with its size in bytes and SHA-256, sorted by path. This list does not include itself (FILES.md). Generated 14 November 2026 with `shasum -a 256`.

| Path | Bytes | SHA-256 |
|---|---|---|
| `LICENSE` | 1070 | 538bee68b1e27a8d981ca25e0f1af24e42f25bdc872d08d4df2e691d6ecb8eb9 |
| `LICENSE-CC-BY-4.0.txt` | 462 | 78899f619721420777f6b009a1a0507f600a12cffa794140191455e6e0010823 |
| `M8/kev_mix.py` | 7274 | 8d408b37c772da036a434f829f9065a78fe0d943cbe0f6fb818a93b7f3deb73b |
| `M8/kev_v5.py` | 8344 | ac583bf6c6955839f8e3f7eba43abf55f9c98e09864103b3118cb7c7ce6902f0 |
| `M8/kev_v5_out.txt` | 6470 | de8878184836848fd3a67dc29265d94010a51e069bdcddd2d1330c02cfb870c4 |
| `M8/sources/G4-kev_live.csv` | 1070956 | 80e1af588c78dbd79f3c7c312156f8bccb698e03c758fd2af328c6c70ed1ae45 |
| `M8/sources/G4-kev_live.json` | 1803428 | ef8fffede5c472001da046c7751beb2a3242458896d0ce08da52b30968b8b56b |
| `MODEL/EXT/code/check_ext.py` | 12170 | e845e79098f665854c32dac64d32d2c50fb928ca482c5ba8d075f40b8b86bde0 |
| `MODEL/EXT/code/check_ext_out.txt` | 845 | 3a0d34496c4dfef69561ebcbb4b7eb4b6f10f15f7e1ba7a026ee055eeb8e4e31 |
| `MODEL/EXT/code/mutation_runs/E1.py` | 12160 | 4f6ec158712514644f6ec33ac08a458f0e30a09276bc6fee417802676fe062e7 |
| `MODEL/EXT/code/mutation_runs/E1_out.txt` | 482 | 2f10bc48327c50e970da5462f687ad237af96493c4a45318739bd4b09aa575c0 |
| `MODEL/EXT/code/mutation_runs/E2.py` | 12171 | 0987270b5175d9a189b32ae57c16a13c0d4aaafb56a94f0b162efcc7bda50d70 |
| `MODEL/EXT/code/mutation_runs/E2_out.txt` | 480 | 90264d5ef6cfe8c758c1908f82ba33d3b56f510ce11b6831002e25278d73a6be |
| `MODEL/EXT/code/mutation_runs/E3.py` | 12163 | 24996b6d915d14ddd46161323315aa4b7f208cc88d59ff0d5d6589e02b531fa0 |
| `MODEL/EXT/code/mutation_runs/E3_out.txt` | 478 | c87b0c333e269641ca0003a4abad10f56bfaca30fe5d4b4652e50fce2aa288a4 |
| `MODEL/code/check_benefits.py` | 27012 | 5829c9ba3220d025c71140ca3afa9784f0d051f0a6f095cbbe07eda784b198b4 |
| `MODEL/code/check_benefits_out.txt` | 13317 | 6f7e99880a6b4a9b2963a39c0fff3e6387e480dbeb9176d933b01946059b0f81 |
| `MODEL/code/check_model.py` | 85402 | 49f5c9c2d119b589ea216a8f181a15f1d4476c33c39d1a520d963145331ccb1a |
| `MODEL/code/check_model_out.txt` | 28356 | ba6ff2f691db9fb44e0afbd24dc63a000709e5db44ffd637146a1cbd824148de |
| `MODEL/code/race_model.py` | 20424 | c9de4fdd4919b1cac3b992cb419ebdc8ee77fb4437672247326feb599463c916 |
| `MODEL/code/race_model_out.txt` | 14778 | 4f660a01d2e1fdf8facf06cc69e68abfcb4b1095741382c6fab92ffa47ce02f3 |
| `README.md` | 40097 | 01ec126519fcd7adb4b428e2730a4a3a73ee3d949455f5846fac80d164e42226 |
| `lean/RTTRProofs/.gitignore` | 7 | b3ad09fc93f83fdbd0bee771258dd4a58d3798fd7e6048611dde5a804bb43f1e |
| `lean/RTTRProofs/RTTRProofs.lean` | 516 | 65979faf59c9767fa278788aca24140a8b98be09d03f70b0768ee1a192b2f271 |
| `lean/RTTRProofs/RTTRProofs/AuditAll.lean` | 1178 | 10af339480d26482659fbe138e61258e6d6335c08c0bc6cdd3d4cca95727445e |
| `lean/RTTRProofs/RTTRProofs/Benefits.lean` | 253497 | 27de35d0c6f4ea08fb323701a8adfb09d5562d458e3bb77d08eae137725ca1a9 |
| `lean/RTTRProofs/RTTRProofs/Contest.lean` | 97256 | ead4798c3e7cef01df80e4c51ca144635a3ba014b581bc9b5604110d2f56cb63 |
| `lean/RTTRProofs/RTTRProofs/Copies.lean` | 77740 | 06cdecf0991b1cf21a2cbb1b94bf11cb892273a145d798536bdd85dac4797826 |
| `lean/RTTRProofs/RTTRProofs/Gaps1.lean` | 47554 | 5a51654cfed0102acabcb0541704cc6c3b30dc535ac2c5bca1cbd6c6d0497a2c |
| `lean/RTTRProofs/RTTRProofs/Gaps2.lean` | 97560 | b70112fb7fd5ec158639f6d199c8b687b47878f95f857857d3eb072dca68b26a |
| `lean/RTTRProofs/RTTRProofs/Gaps3.lean` | 62733 | fdb9934eb1e6d88a7400a0d6f89abe2c86e942c6a50a3d43a3c7524a6cf523d7 |
| `lean/RTTRProofs/RTTRProofs/Gaps4.lean` | 107989 | 52495a1c87794b2e925a274828a90d0ecb84455206c1f5f246a20cb69f05e430 |
| `lean/RTTRProofs/RTTRProofs/Hold.lean` | 105298 | 236e9c03386ac8b3d59875ea1d4ebbfed110091813adede5fda06562455bd1a2 |
| `lean/RTTRProofs/RTTRProofs/OpenModels.lean` | 118751 | ed8950a276c7a30f06304f8ffe380fb2a82be5bce35bde37be380cab6b93509a |
| `lean/RTTRProofs/RTTRProofs/Peak.lean` | 129637 | 881e3e7f577da9274642457fdee354c34a9ad1cfafbc1bc89870bba9fa0c1d06 |
| `lean/RTTRProofs/RTTRProofs/Program.lean` | 78047 | d2b90f73d3660025feb2c5f1d31efae511f73b32898c46623d2e9f7a4ecf737a |
| `lean/RTTRProofs/RTTRProofs/Release.lean` | 155371 | 8fea73f4568f4c84a6106a1101510823f5ed98f9994b87d4e130ec100ffb9f9b |
| `lean/RTTRProofs/RTTRProofs/Smoke.lean` | 80 | 4cfc368e073bc420a545469751f503142dd2f6d852d8da71e6b2dbb56ba46967 |
| `lean/RTTRProofs/RTTRProofs/Speed.lean` | 121228 | fc0db1d0da33087f80c85c5e45826a3464d878f98a3049d485f5fe57d28a1eb5 |
| `lean/RTTRProofs/RTTRProofs/Timings.lean` | 43133 | fddc87f1586e42ea5ae61a717c128cb75d7a9ed63f9970f72fda421e3c16132b |
| `lean/RTTRProofs/lake-manifest.json` | 3144 | f141988f72af425749222cb7dc1e8eabbec0eb87d67048e59577aa3860673dd9 |
| `lean/RTTRProofs/lakefile.toml` | 359 | f42068fc568ac3a5117fa88a8ca72a5a5a963200022d548ef3bf82816f3da642 |
| `lean/RTTRProofs/lean-toolchain` | 25 | ca5f1f601d34c49079e38d7e7041eb0f2a9c227fbc1df0f404820069a052330c |
| `lean/build-record/RTTR-auditall.txt` | 57 | 71098485b36df6b4070f259ec4ef83f60cc5f054ade986ad573a81eeaf248d77 |
| `lean/build-record/RTTR-lake-build.txt` | 237722 | ec8d3e0446a4493d04a0c8fe7b3feef87a9698a3c72bee5638b4b6ced02b8e9c |
| `supplement/SUPPLEMENT-v9.md` | 32775 | a62b124dd3515bcc419f5b266e325828ab9c9d4607c9435da26823777e6e8110 |
