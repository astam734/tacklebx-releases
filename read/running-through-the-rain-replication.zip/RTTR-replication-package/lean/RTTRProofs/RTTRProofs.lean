-- Root of the Lean check of Running Through the Rain (v8; OpenModels and Gaps4 added for v15, 13 November 2026). Smoke.lean, the toolchain smoke test, is left out.
import RTTRProofs.Speed
import RTTRProofs.Timings
import RTTRProofs.Peak
import RTTRProofs.Hold
import RTTRProofs.Contest
import RTTRProofs.Release
import RTTRProofs.Program
import RTTRProofs.Benefits
import RTTRProofs.Copies
import RTTRProofs.Gaps1
import RTTRProofs.Gaps2
import RTTRProofs.Gaps3
import RTTRProofs.OpenModels
import RTTRProofs.Gaps4
