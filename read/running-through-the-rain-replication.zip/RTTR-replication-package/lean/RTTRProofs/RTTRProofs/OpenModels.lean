import RTTRProofs.Copies

/-!
# Appendix B, the enlarged event system: Propositions E4, E5 (with its corollary) and E6,
# and E1's thinning step

Paper: `PEAKS-PAPER/PAPER/PAPER-DRAFT-v14.md`, Appendix B (lines 1224–1517): B.2.3 at
1289–1347, E4 at 1404–1412, E5 and its corollary at 1414–1434, E6 at 1436–1458, proofs at
1490–1512. This module imports `RTTRProofs.Copies` (E1–E3) and reuses its first-arrival
machinery (`HasExpSurvival`, `FirstArrivals`, `survival_inf`), E1's rates (`Rates`), the
schedule of B.2.2 (`Schedule`) and its exposure `X(Σ, W)` (`exposure`). No existing module is
edited.

## Modelling choices, and why they are faithful

* **Probability space and coupling.** One probability space `(Ω, μ)`; every stream, `B_h`, the
  added waits and every schedule live on it, so "common future streams, added waits and
  baseline schedule" (E6) and "future streams are the same under the holder's actions" (B-S8)
  are literal: the random objects do not depend on the action.
* **The first-arrival premise (FA7).** As in `Copies`, Mathlib has no Poisson-process library.
  The probabilistic results take the joint law of the *first-arrival times* of the seven marked
  streams of the table at lines 1297–1305 (`O^full, O^wt, C1, C0, Θ, L, O^R`) as the premise
  `FirstArrivals μ τ Q.rate`: mutually independent, exponential at the table's rates, and
  identically `∞` at rate zero. The paper derives this from Poisson streams, independent
  marking of O (B-S8) and of closed arrivals (B.2.1), and an independent restricted stream
  (B-S8); the text says E4–E6 take "Poisson marking" as a hypothesis (line 1118). Lean takes the
  first-arrival law that marking yields, not marking itself. Every pathwise statement below
  needs no premise at all.
* **Thinning, superposition and competing exponentials (`e1t_*`).** Proved from FA-type
  premises: grouping independent first arrivals by any map gives independent group minima,
  each exponential with the summed rate (`e1t_group`); the law of a first-arrival family is
  determined by its rates (`e1t_law_unique`); two independent exponential times race with
  `P(X < Y, X > t) = a/(a+b) e^{-(a+b)t}` (`e1t_race_joint`), so the winner is independent of
  the time of the first arrival (`e1t_race_indep_of_min`, `e1t_first_is`). **Not proved**: the
  thinning theorem itself (that independent Bernoulli marks on the arrivals of one Poisson
  stream give independent marked streams, with exponential first marked arrivals at rate `qλ`).
  `e1t_closed_marks` proves only the consistency direction for E1's closed split.
* **Windows** are *defined* from B.2.2 / line 1313 (`WCR`, `WAR`): the commercial window ends at
  the first of `ω_C` and the holder's own commercial substitute; the attacker window at the
  first of `ω_A^R = min(ω_A, ω_R)` and the date the holder's own action arms attackers.
  Restricted terms are effective with no commercial offer (B-S8), so the holder's restricted
  release supplies no commercial substitute. `t_pkg` is `0` under full open-model release and
  `ω_full` otherwise (line 1313). The action table (1315–1322) is a theorem.
* **Marks and arrival dates (E4).** "Changing package marks while preserving arrival dates" is
  modelled literally: O has arrival dates `d : ℕ → [0, ∞]` and marks `m : ℕ → Bool`; the first
  full and first weights-only dates are the first dates carrying each mark (`firstMarked`). The
  invariance holds for every date sequence and every pair of mark sequences (`e4_relabel`).
  "Window laws depend on the marked open stream only through `λ_o`" is proved as equality of
  joint laws across two systems (on any probability spaces) whose rate tuples differ only in
  `p_full` (`e4_window_law`, `e4_realized_window_law`, `e4_realized_window_law_random`).
* **`X̃` (lines 1326–1339).** `pkgExposure` is the paper's sum over patched and unfound
  flaw–operator pairs and both cohorts of `k_{fji}(u_fj − min{b_fi(Σ, W), t + Z_f})⁺`, on the
  schedule of B.2.2 (`Copies.Schedule`, real-valued dates), with a map from pairs to flaws so that
  pairs of one flaw share `Z_f`. Onsets and discovery dates live in `EReal`; `⊤` is a minimum over
  no finite dates, contributing no exposure (`ppart u ⊤ = 0`). With every `Z_f = ∞`, `X̃ = X`
  (`b23_pkgExposure_noPkg`).
* **E6 on weighted terms.** E6 is proved for an abstract finite family of flaw–operator–cohort
  terms (`Xpkg`): fixed weights `k ≥ 0` (B-S10), random terminal dates `u` (real-valued),
  random baseline onsets `b ∈ ℝ ∪ {+∞}` (an `EReal` with `b ≠ ⊥`: B-S10's "real or `+∞`"), the
  flaw of each term, waits `Z_f`, and the package date. `pkgExposure_eq_Xpkg` shows the paper's
  `X̃` is an instance, and `e6_strict_iff_concrete` states the strictness result for it.
  **Restriction**: terminal dates are finite on every path; B-S10 asks only that they be finite
  almost surely on positively weighted terms. Changing them on a null set, or on zero-weight
  terms, changes no expectation and no positively weighted term, so the expectation results are
  unaffected, but the statements are about real-valued terminal dates.
* **B-S9's waits.** `Z_f` is exponential with rate `η_f` when `η_f > 0` and identically `∞` when
  `η_f = 0`. The independence used is only `Z_f ⟂ g_{fji}` for each term, which B-S9's
  independence of `Z_f` from the full baseline schedule implies; mutual independence among the
  waits is not used, and no independence of `ω_full` from anything is used.
* **Expectations.** Window means are `lintegral`s (extended nonnegative, no integrability
  presupposed). Exposures are Bochner integrals with explicit integrability hypotheses, which is
  how B-S10's "all exposures used in expectations … are integrable" is read.
-/

open MeasureTheory ProbabilityTheory Set
open scoped ENNReal

namespace RTTR.OpenModels

open RTTR.Copies

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

/-! ## 1. General first-arrival machinery -/

/-- A zero-rate exponential survival (`P(X > t) = 1` for all `t ≥ 0`) forces `X = ∞` a.s. -/
theorem e1t_zero_rate_ae_top {X : Ω → ℝ≥0∞} (hX : Measurable X)
    (h : HasExpSurvival μ X 0) : ∀ᵐ ω ∂μ, X ω = ⊤ := by
  have hn : ∀ n : ℕ, μ {ω | X ω ≤ (n : ℝ≥0∞)} = 0 := by
    intro n
    have hs : {ω | X ω ≤ (n : ℝ≥0∞)} = {ω | ENNReal.ofReal n < X ω}ᶜ := by
      ext ω; simp
    have hm : MeasurableSet {ω | ENNReal.ofReal n < X ω} := measurableSet_lt measurable_const hX
    rw [hs, prob_compl_eq_one_sub hm, h n (Nat.cast_nonneg n)]
    simp
  have hU : μ (⋃ n : ℕ, {ω | X ω ≤ (n : ℝ≥0∞)}) = 0 := measure_iUnion_null hn
  rw [ae_iff]
  refine measure_mono_null (fun ω hω => ?_) hU
  simp only [mem_ofPred_eq] at hω
  obtain ⟨n, hn⟩ := ENNReal.exists_nat_gt hω
  exact mem_iUnion.mpr ⟨n, le_of_lt hn⟩

/-- An exponential time is positive almost surely (`P(X > 0) = 1`). -/
theorem e1t_exp_ae_pos {X : Ω → ℝ≥0∞} (hX : Measurable X) {r : ℝ}
    (h : HasExpSurvival μ X r) : ∀ᵐ ω ∂μ, 0 < X ω := by
  have h0 := h 0 le_rfl
  simp only [ENNReal.ofReal_zero, mul_zero, neg_zero, Real.exp_zero, ENNReal.ofReal_one] at h0
  have hm : MeasurableSet {ω | 0 < X ω} := measurableSet_lt measurable_const hX
  rw [ae_iff]
  have : {ω | ¬ 0 < X ω} = {ω | 0 < X ω}ᶜ := rfl
  rw [this, prob_compl_eq_one_sub hm, h0, tsub_self]

/-- **Superposition with grouping.** Group independent first arrivals by a map `g : ι → κ` and
take the first arrival in each group. The group minima are again independent, each is
exponential with the summed rate of its group, and a zero-rate group never arrives. This is
`FirstArrivals` for the grouped family: the "minimum of independent exponential waits is
exponential with the summed rate", with mutual independence of disjoint groups. -/
theorem e1t_group {ι κ : Type*} [Fintype ι] [DecidableEq κ] {τ : ι → Ω → ℝ≥0∞}
    {r : ι → ℝ} (h : FirstArrivals μ τ r) (g : ι → κ) :
    FirstArrivals μ (fun k ω => (Finset.univ.filter (fun i => g i = k)).inf (fun i => τ i ω))
      (fun k => ∑ i ∈ Finset.univ.filter (fun i => g i = k), r i) := by
  classical
  have hS : Measurable (fun ω i => τ i ω) := measurable_pi_iff.mpr h.meas
  set τ' : κ → Ω → ℝ≥0∞ :=
    fun k ω => (Finset.univ.filter (fun i => g i = k)).inf (fun i => τ i ω) with hτ'
  have hmeas : ∀ k, Measurable (τ' k) := fun k => (measurable_finset_inf _).comp hS
  refine ⟨hmeas, ?_, fun k => Finset.sum_nonneg (fun i _ => h.rate_nonneg i),
    fun k _ => survival_inf h _, ?_⟩
  · -- independence of the group minima, from a generating π-system of upper rays
    rw [iIndepFun_iff_iIndep]
    let π : κ → Set (Set Ω) := fun k => {s | ∃ t ∈ range (Ioi : ℝ≥0∞ → Set ℝ≥0∞), τ' k ⁻¹' t = s}
    refine iIndepSets.iIndep (fun k => (hmeas k).comap_le) π
      (fun k => isPiSystem_Ioi.comap (τ' k)) (fun k => ?_) ?_
    · change MeasurableSpace.comap (τ' k) inferInstance = _
      rw [show (inferInstance : MeasurableSpace ℝ≥0∞) = MeasurableSpace.generateFrom (range Ioi)
        from BorelSpace.measurable_eq.trans (borel_eq_generateFrom_Ioi _),
        MeasurableSpace.comap_generateFrom]
      rfl
    · rw [iIndepSets_iff]
      intro s f hf
      have hx : ∀ k ∈ s, ∃ x : ℝ≥0∞, τ' k ⁻¹' Ioi x = f k := by
        intro k hk
        obtain ⟨t, ⟨x, rfl⟩, ht⟩ := hf k hk
        exact ⟨x, ht⟩
      choose! x hxk using hx
      -- rewrite every set as a preimage of an upper ray
      have hfs : ∀ k ∈ s, f k = τ' k ⁻¹' Ioi (x k) := fun k hk => (hxk k hk).symm
      rw [Finset.prod_congr rfl (fun k hk => by rw [hfs k hk])]
      rw [show (⋂ k ∈ s, f k) = ⋂ k ∈ s, τ' k ⁻¹' Ioi (x k) from
        iInter₂_congr (fun k hk => hfs k hk)]
      by_cases htop : ∃ k ∈ s, x k = ⊤
      · obtain ⟨k0, hk0, hx0⟩ := htop
        have hempty : τ' k0 ⁻¹' Ioi (x k0) = ∅ := by rw [hx0]; simp
        have h1 : (⋂ k ∈ s, τ' k ⁻¹' Ioi (x k)) = ∅ :=
          subset_empty_iff.mp (hempty ▸ biInter_subset_of_mem hk0)
        rw [h1, measure_empty]
        exact (Finset.prod_eq_zero hk0 (by rw [hempty, measure_empty])).symm
      · push Not at htop
        have hlt : ∀ k ∈ s, x k < ⊤ := fun k hk => lt_top_iff_ne_top.mpr (htop k hk)
        -- a group minimum exceeds a finite level iff every member does
        have hgrp : ∀ k ∈ s, τ' k ⁻¹' Ioi (x k) =
            ⋂ i ∈ Finset.univ.filter (fun i => g i = k), τ i ⁻¹' Ioi (x k) := by
          intro k hk
          ext ω
          simp only [mem_preimage, mem_Ioi, mem_iInter, hτ']
          exact Finset.lt_inf_iff (hlt k hk)
        have hind := iIndepFun_iff_measure_inter_preimage_eq_mul.mp h.indep
        -- the full intersection, indexed by the original streams
        set s7 : Finset ι := Finset.univ.filter (fun i => g i ∈ s) with hs7
        have hbig : (⋂ k ∈ s, τ' k ⁻¹' Ioi (x k)) = ⋂ i ∈ s7, τ i ⁻¹' Ioi (x (g i)) := by
          ext ω
          simp only [mem_iInter, hs7, Finset.mem_filter, Finset.mem_univ, true_and]
          constructor
          · intro hω i hi
            have := hω (g i) hi
            rw [hgrp (g i) hi] at this
            simp only [mem_iInter, Finset.mem_filter, Finset.mem_univ, true_and] at this
            exact this i rfl
          · intro hω k hk
            rw [hgrp k hk]
            simp only [mem_iInter, Finset.mem_filter, Finset.mem_univ, true_and]
            intro i hi
            have := hω i (hi ▸ hk)
            rwa [hi] at this
        rw [hbig, hind s7 (fun i _ => measurableSet_Ioi)]
        rw [← Finset.prod_fiberwise_of_maps_to (g := g) (t := s)
          (fun i hi => (Finset.mem_filter.mp hi).2)]
        apply Finset.prod_congr rfl
        intro k hk
        rw [hgrp k hk, hind _ (fun i _ => measurableSet_Ioi)]
        have hfib : s7.filter (fun i => g i = k) = Finset.univ.filter (fun i => g i = k) := by
          ext i
          simp only [hs7, Finset.mem_filter, Finset.mem_univ, true_and]
          constructor
          · exact fun h => h.2
          · intro hi; exact ⟨hi ▸ hk, hi⟩
        rw [hfib]
        apply Finset.prod_congr rfl
        intro i hi
        rw [(Finset.mem_filter.mp hi).2]
  · intro k hk ω
    have hzero : ∀ i ∈ Finset.univ.filter (fun i => g i = k), r i = 0 :=
      (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => h.rate_nonneg i)).mp hk
    exact top_le_iff.mp (Finset.le_inf (fun i hi => (h.never_of_zero i (hzero i hi) ω).ge))

/-- The survival function determines the law: two extended nonnegative times (possibly on
different probability spaces) with the same exponential survival have the same law. -/
theorem e1t_law_eq_of_survival {Ω' : Type*} [MeasurableSpace Ω'] {μ' : Measure Ω'}
    [IsProbabilityMeasure μ'] {X : Ω → ℝ≥0∞} {X' : Ω' → ℝ≥0∞} (hX : Measurable X)
    (hX' : Measurable X') {r : ℝ} (h : HasExpSurvival μ X r) (h' : HasExpSurvival μ' X' r) :
    μ.map X = μ'.map X' := by
  refine ext_of_generate_finite (range Ioi)
    (BorelSpace.measurable_eq.trans (borel_eq_generateFrom_Ioi _)) isPiSystem_Ioi ?_ ?_
  · rintro _ ⟨x, rfl⟩
    rw [Measure.map_apply hX measurableSet_Ioi, Measure.map_apply hX' measurableSet_Ioi]
    rcases eq_or_ne x ⊤ with rfl | hx
    · simp
    · have hxr : x = ENNReal.ofReal x.toReal := (ENNReal.ofReal_toReal hx).symm
      have e1 := h x.toReal ENNReal.toReal_nonneg
      have e2 := h' x.toReal ENNReal.toReal_nonneg
      rw [← hxr] at e1 e2
      exact e1.trans e2.symm
  · rw [Measure.map_apply hX MeasurableSet.univ, Measure.map_apply hX' MeasurableSet.univ]
    simp

/-- **The joint law of first arrivals is determined by the rates.** Two families satisfying
`FirstArrivals` with the same rates (on possibly different probability spaces) have the same
joint law. -/
theorem e1t_law_unique {ι : Type*} [Fintype ι] {τ : ι → Ω → ℝ≥0∞} {r : ι → ℝ}
    {Ω' : Type*} [MeasurableSpace Ω'] {μ' : Measure Ω'} [IsProbabilityMeasure μ']
    {τ' : ι → Ω' → ℝ≥0∞} (h : FirstArrivals μ τ r) (h' : FirstArrivals μ' τ' r) :
    μ.map (fun ω i => τ i ω) = μ'.map (fun ω i => τ' i ω) := by
  rw [(iIndepFun_iff_map_fun_eq_pi_map (fun i => (h.meas i).aemeasurable)).mp h.indep,
    (iIndepFun_iff_map_fun_eq_pi_map (fun i => (h'.meas i).aemeasurable)).mp h'.indep]
  congr 1
  funext i
  exact e1t_law_eq_of_survival (h.meas i) (h'.meas i) (h.law i) (h'.law i)

/-! ### The race of two independent exponential times (competing exponentials) -/

theorem e1t_integrableOn_rate_exp {b : ℝ} (hb : 0 < b) (s : ℝ) :
    IntegrableOn (fun u : ℝ => b * Real.exp (-(b * u))) (Ioi s) := by
  have h2 : (fun u : ℝ => b * Real.exp (-(b * u))) = fun x => b * Real.exp (-b * x) := by
    funext u; ring_nf
  rw [h2]; exact (exp_neg_integrableOn_Ioi s hb).const_mul b

theorem e1t_integral_rate_exp {b : ℝ} (hb : 0 < b) (s : ℝ) :
    ∫ u in Ioi s, b * Real.exp (-(b * u)) = Real.exp (-(b * s)) := by
  rw [integral_const_mul]
  have h := integral_exp_mul_Ioi (a := -b) (by linarith) s
  simp only [neg_mul] at h
  rw [h]; field_simp

/-- For `b > 0` and `x` beyond the level `t`, the survival `P(Y > x) = e^{-bx}` written as the
integral of the density `b e^{-bu}` over `u ≥ x`, inside `(t, ∞)`. -/
theorem e1t_surv_as_integral {Y : Ω → ℝ≥0∞} {b : ℝ} (hb : 0 < b) (hY : HasExpSurvival μ Y b)
    {t : ℝ} (ht : 0 ≤ t) (x : ℝ≥0∞) :
    (if ENNReal.ofReal t < x then μ {ω | x < Y ω} else 0) =
      ∫⁻ u in Ioi t, {u : ℝ | ENNReal.ofReal t < x ∧ x ≤ ENNReal.ofReal u}.indicator
        (fun u => ENNReal.ofReal (b * Real.exp (-(b * u)))) u := by
  split_ifs with hx
  · have hset : {u : ℝ | ENNReal.ofReal t < x ∧ x ≤ ENNReal.ofReal u} =
        {u : ℝ | x ≤ ENNReal.ofReal u} := by ext u; simp [hx]
    rw [hset]
    rcases eq_or_ne x ⊤ with rfl | hxt
    · simp
    · set s := x.toReal with hs
      have hxs : x = ENNReal.ofReal s := (ENNReal.ofReal_toReal hxt).symm
      have hts : t < s := by
        rw [hxs] at hx; exact (ENNReal.ofReal_lt_ofReal_iff'.mp hx).1
      rw [hxs, hY s (by linarith)]
      have hmS : MeasurableSet {u : ℝ | ENNReal.ofReal s ≤ ENNReal.ofReal u} :=
        measurableSet_le measurable_const ENNReal.measurable_ofReal
      rw [lintegral_indicator hmS, Measure.restrict_restrict hmS]
      have hI : {u : ℝ | ENNReal.ofReal s ≤ ENNReal.ofReal u} ∩ Ioi t = Ici s := by
        ext u
        simp only [mem_inter_iff, mem_ofPred_eq, mem_Ioi, mem_Ici]
        constructor
        · rintro ⟨h1, h2⟩
          exact (ENNReal.ofReal_le_ofReal_iff (by linarith)).mp h1
        · intro h1
          exact ⟨ENNReal.ofReal_le_ofReal h1, by linarith⟩
      rw [hI, setLIntegral_congr Ioi_ae_eq_Ici.symm,
        ← ofReal_integral_eq_lintegral_ofReal (e1t_integrableOn_rate_exp hb s)
          (ae_restrict_of_forall_mem measurableSet_Ioi
            (fun u _ => mul_nonneg hb.le (Real.exp_pos _).le)),
        e1t_integral_rate_exp hb s]
  · have hset : {u : ℝ | ENNReal.ofReal t < x ∧ x ≤ ENNReal.ofReal u} = ∅ := by
      ext u; simp [hx]
    rw [hset]; simp

theorem e1t_race_integral {a b : ℝ} (ha : 0 ≤ a) (hb : 0 < b) (t : ℝ) :
    ∫ u in Ioi t, b * Real.exp (-(b * u)) * (Real.exp (-(a * t)) - Real.exp (-(a * u))) =
      a / (a + b) * Real.exp (-((a + b) * t)) := by
  have hab : 0 < a + b := by linarith
  have hfun : (fun u : ℝ => b * Real.exp (-(b * u)) * (Real.exp (-(a * t)) - Real.exp (-(a * u))))
      = fun u => Real.exp (-(a * t)) * (b * Real.exp (-(b * u)))
          - (b / (a + b)) * ((a + b) * Real.exp (-((a + b) * u))) := by
    funext u
    have hexp : Real.exp (-((a + b) * u)) = Real.exp (-(b * u)) * Real.exp (-(a * u)) := by
      rw [← Real.exp_add]; congr 1; ring
    rw [hexp]; field_simp
  rw [hfun, integral_sub ((e1t_integrableOn_rate_exp hb t).const_mul _)
      ((e1t_integrableOn_rate_exp hab t).const_mul _),
    integral_const_mul (Real.exp (-(a * t))), integral_const_mul (b / (a + b)),
    e1t_integral_rate_exp hb t, e1t_integral_rate_exp hab t]
  have : Real.exp (-(a * t)) * Real.exp (-(b * t)) = Real.exp (-((a + b) * t)) := by
    rw [← Real.exp_add]; ring_nf
  rw [this]; field_simp; ring

/-- **The race, with a level.** For independent exponential times `X` (rate `a`) and `Y`
(rate `b`), `a, b ≥ 0`, `a + b > 0`, and `t ≥ 0`:
`P(X > t and X < Y) = a/(a+b) · e^{-(a+b)t}`. -/
theorem e1t_race_joint {X Y : Ω → ℝ≥0∞} (hX : Measurable X) (hY : Measurable Y)
    (hXY : IndepFun X Y μ) {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : 0 < a + b)
    (hXa : HasExpSurvival μ X a) (hYb : HasExpSurvival μ Y b) {t : ℝ} (ht : 0 ≤ t) :
    μ {ω | ENNReal.ofReal t < X ω ∧ X ω < Y ω} =
      ENNReal.ofReal (a / (a + b) * Real.exp (-((a + b) * t))) := by
  rcases hb.lt_or_eq with hb | hb0
  · -- Step A: the product law of `(X, Y)`
    set S : Set (ℝ≥0∞ × ℝ≥0∞) := {p | ENNReal.ofReal t < p.1 ∧ p.1 < p.2} with hSdef
    have hS : MeasurableSet S :=
      (measurableSet_lt measurable_const measurable_fst).inter
        (measurableSet_lt measurable_fst measurable_snd)
    have hA : μ {ω | ENNReal.ofReal t < X ω ∧ X ω < Y ω} =
        ∫⁻ ω, (if ENNReal.ofReal t < X ω then μ {ω' | X ω < Y ω'} else 0) ∂μ := by
      calc μ {ω | ENNReal.ofReal t < X ω ∧ X ω < Y ω}
          = μ ((fun ω => (X ω, Y ω)) ⁻¹' S) := rfl
        _ = (μ.map (fun ω => (X ω, Y ω))) S := (Measure.map_apply (hX.prodMk hY) hS).symm
        _ = ((μ.map X).prod (μ.map Y)) S := by
            rw [(indepFun_iff_map_prod_eq_prod_map_map hX.aemeasurable hY.aemeasurable).mp hXY]
        _ = ∫⁻ x, (μ.map Y) (Prod.mk x ⁻¹' S) ∂(μ.map X) := Measure.prod_apply hS
        _ = ∫⁻ ω, (μ.map Y) (Prod.mk (X ω) ⁻¹' S) ∂μ :=
            lintegral_map (measurable_measure_prodMk_left hS) hX
        _ = _ := by
            congr 1; funext ω
            rw [Measure.map_apply hY (measurable_prodMk_left hS)]
            by_cases hx : ENNReal.ofReal t < X ω
            · simp only [hx, ↓reduceIte]; congr 1; ext ω'; simp [hSdef, hx]
            · simp only [hx, ↓reduceIte]
              have : Y ⁻¹' (Prod.mk (X ω) ⁻¹' S) = ∅ := by ext ω'; simp [hSdef, hx]
              rw [this, measure_empty]
    -- Step B: write each survival as an integral of the density of `Y`
    rw [hA]
    simp_rw [e1t_surv_as_integral hb hYb ht]
    -- Step C: Tonelli
    set f : ℝ → ℝ≥0∞ := fun u => ENNReal.ofReal (b * Real.exp (-(b * u))) with hf
    have hmeasF : Measurable (Function.uncurry fun ω (u : ℝ) =>
        {u : ℝ | ENNReal.ofReal t < X ω ∧ X ω ≤ ENNReal.ofReal u}.indicator f u) := by
      have heq : (Function.uncurry fun ω (u : ℝ) =>
          {u : ℝ | ENNReal.ofReal t < X ω ∧ X ω ≤ ENNReal.ofReal u}.indicator f u) =
          {p : Ω × ℝ | ENNReal.ofReal t < X p.1 ∧ X p.1 ≤ ENNReal.ofReal p.2}.indicator
            (fun p => f p.2) := by
        funext p; simp [Function.uncurry, Set.indicator]
      rw [heq]
      refine Measurable.indicator ?_ ?_
      · exact ENNReal.measurable_ofReal.comp
          (measurable_const.mul (Real.measurable_exp.comp (measurable_const.mul measurable_snd).neg))
      · exact (measurableSet_lt measurable_const (hX.comp measurable_fst)).inter
          (measurableSet_le (hX.comp measurable_fst) (ENNReal.measurable_ofReal.comp measurable_snd))
    rw [lintegral_lintegral_swap hmeasF.aemeasurable]
    -- Step D, E: the inner integral is `f u · P(t < X ≤ u)`
    have hinner : ∀ u ∈ Ioi t, ∫⁻ ω, {u : ℝ | ENNReal.ofReal t < X ω ∧ X ω ≤ ENNReal.ofReal u}.indicator
        f u ∂μ = ENNReal.ofReal (b * Real.exp (-(b * u)) *
          (Real.exp (-(a * t)) - Real.exp (-(a * u)))) := by
      intro u hu
      have hu' : t < u := hu
      have hset : (fun ω => {u : ℝ | ENNReal.ofReal t < X ω ∧ X ω ≤ ENNReal.ofReal u}.indicator f u)
          = {ω | ENNReal.ofReal t < X ω ∧ X ω ≤ ENNReal.ofReal u}.indicator (fun _ => f u) := by
        funext ω; simp [Set.indicator]
      have hmeasA : MeasurableSet {ω | ENNReal.ofReal t < X ω ∧ X ω ≤ ENNReal.ofReal u} :=
        (measurableSet_lt measurable_const hX).inter (measurableSet_le hX measurable_const)
      rw [hset, lintegral_indicator_const hmeasA]
      have hdiff : {ω | ENNReal.ofReal t < X ω ∧ X ω ≤ ENNReal.ofReal u} =
          {ω | ENNReal.ofReal t < X ω} \ {ω | ENNReal.ofReal u < X ω} := by
        ext ω; simp
      have hsub : {ω | ENNReal.ofReal u < X ω} ⊆ {ω | ENNReal.ofReal t < X ω} := fun ω hω =>
        lt_of_le_of_lt (ENNReal.ofReal_le_ofReal hu'.le) hω
      rw [hdiff, measure_sdiff hsub (measurableSet_lt measurable_const hX).nullMeasurableSet
          (measure_ne_top _ _), hXa t ht, hXa u (by linarith),
        ← ENNReal.ofReal_sub _ (Real.exp_pos _).le, hf,
        ← ENNReal.ofReal_mul (mul_nonneg hb.le (Real.exp_pos _).le)]
    rw [setLIntegral_congr_fun measurableSet_Ioi hinner]
    -- Step F, G: the real integral
    have hnn : ∀ u ∈ Ioi t, 0 ≤ b * Real.exp (-(b * u)) *
        (Real.exp (-(a * t)) - Real.exp (-(a * u))) := by
      intro u hu
      have hu' : t < u := hu
      apply mul_nonneg (mul_nonneg hb.le (Real.exp_pos _).le)
      rw [sub_nonneg]; apply Real.exp_le_exp.mpr; nlinarith
    have hint : IntegrableOn (fun u : ℝ => b * Real.exp (-(b * u)) *
        (Real.exp (-(a * t)) - Real.exp (-(a * u)))) (Ioi t) := by
      refine Integrable.mono' ((e1t_integrableOn_rate_exp hb t).const_mul (Real.exp (-(a * t)))) ?_ ?_
      · exact (Continuous.aestronglyMeasurable (by fun_prop))
      · refine ae_restrict_of_forall_mem measurableSet_Ioi (fun u hu => ?_)
        rw [Real.norm_eq_abs, abs_of_nonneg (hnn u hu)]
        have : Real.exp (-(a * t)) - Real.exp (-(a * u)) ≤ Real.exp (-(a * t)) := by
          linarith [Real.exp_pos (-(a * u))]
        nlinarith [mul_nonneg hb.le (Real.exp_pos (-(b * u))).le]
    rw [← ofReal_integral_eq_lintegral_ofReal hint (ae_restrict_of_forall_mem measurableSet_Ioi hnn),
      e1t_race_integral ha hb t]
  · -- `b = 0`: `Y = ∞` a.s. and `X < ∞` a.s.
    subst hb0
    have ha' : 0 < a := by linarith
    have hYtop := e1t_zero_rate_ae_top hY hYb
    have hXfin := hXa.ae_lt_top hX ha'
    rw [show μ {ω | ENNReal.ofReal t < X ω ∧ X ω < Y ω} = μ {ω | ENNReal.ofReal t < X ω} from
      measure_congr (by
        filter_upwards [hYtop, hXfin] with ω h1 h2
        rw [h1]; simp [h2]), hXa t ht]
    congr 1; rw [add_zero, div_self ha'.ne', one_mul]

/-- **The race.** `P(X < Y) = a/(a+b)` for independent exponential times with rates `a, b ≥ 0`,
`a + b > 0` (a zero-rate time never arrives). -/
theorem e1t_race_prob {X Y : Ω → ℝ≥0∞} (hX : Measurable X) (hY : Measurable Y)
    (hXY : IndepFun X Y μ) {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : 0 < a + b)
    (hXa : HasExpSurvival μ X a) (hYb : HasExpSurvival μ Y b) :
    μ {ω | X ω < Y ω} = ENNReal.ofReal (a / (a + b)) := by
  have h := e1t_race_joint hX hY hXY ha hb hab hXa hYb (t := 0) le_rfl
  simp only [ENNReal.ofReal_zero, mul_zero, neg_zero, Real.exp_zero, mul_one] at h
  rw [← h]
  refine measure_congr ?_
  filter_upwards [e1t_exp_ae_pos hX hXa] with ω hω
  simp [hω]

/-- The survival of the minimum of two independent exponential times is the product. -/
theorem e1t_min_survival {X Y : Ω → ℝ≥0∞} (hX : Measurable X) (hY : Measurable Y)
    (hXY : IndepFun X Y μ) {a b : ℝ} (hXa : HasExpSurvival μ X a) (hYb : HasExpSurvival μ Y b) :
    HasExpSurvival μ (fun ω => min (X ω) (Y ω)) (a + b) := by
  intro t ht
  have hset : {ω | ENNReal.ofReal t < min (X ω) (Y ω)} = X ⁻¹' Ioi (ENNReal.ofReal t) ∩
      Y ⁻¹' Ioi (ENNReal.ofReal t) := by ext ω; simp
  rw [hset, hXY.measure_inter_preimage_eq_mul _ _ measurableSet_Ioi measurableSet_Ioi]
  change μ {ω | _ < X ω} * μ {ω | _ < Y ω} = _
  rw [hXa t ht, hYb t ht, ← ENNReal.ofReal_mul (Real.exp_pos _).le, ← Real.exp_add]
  congr 2; ring

/-- **Which one arrives first is independent of when the first arrival occurs.** For
independent exponential times, `P(X < Y and min(X, Y) > t) = P(X < Y) · P(min(X, Y) > t)`. -/
theorem e1t_race_indep_of_min {X Y : Ω → ℝ≥0∞} (hX : Measurable X) (hY : Measurable Y)
    (hXY : IndepFun X Y μ) {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : 0 < a + b)
    (hXa : HasExpSurvival μ X a) (hYb : HasExpSurvival μ Y b) {t : ℝ} (ht : 0 ≤ t) :
    μ {ω | X ω < Y ω ∧ ENNReal.ofReal t < min (X ω) (Y ω)} =
      μ {ω | X ω < Y ω} * μ {ω | ENNReal.ofReal t < min (X ω) (Y ω)} := by
  have hset : {ω | X ω < Y ω ∧ ENNReal.ofReal t < min (X ω) (Y ω)} =
      {ω | ENNReal.ofReal t < X ω ∧ X ω < Y ω} := by
    ext ω
    simp only [mem_ofPred_eq, lt_min_iff]
    constructor
    · rintro ⟨h1, h2, _⟩; exact ⟨h2, h1⟩
    · rintro ⟨h1, h2⟩; exact ⟨h2, h1, lt_trans h1 h2⟩
  rw [hset, e1t_race_joint hX hY hXY ha hb hab hXa hYb ht, e1t_race_prob hX hY hXY ha hb hab hXa hYb,
    e1t_min_survival hX hY hXY hXa hYb t ht, ← ENNReal.ofReal_mul (div_nonneg ha hab.le)]

/-- **Competing exponentials, for a finite family.** For first arrivals satisfying
`FirstArrivals` with total rate `R > 0`, the probability that stream `i` arrives strictly first
and the first arrival is later than `t` is `(r_i/R) e^{-Rt}`: the winner is independent of the
time of the first arrival, and stream `i` wins with probability `r_i/R`. -/
theorem e1t_first_is {ι : Type*} [Fintype ι] [DecidableEq ι] {τ : ι → Ω → ℝ≥0∞}
    {r : ι → ℝ} (h : FirstArrivals μ τ r) (i : ι) (hR : 0 < ∑ j, r j) {t : ℝ} (ht : 0 ≤ t) :
    μ {ω | τ i ω < (Finset.univ.erase i).inf (fun j => τ j ω) ∧
        ENNReal.ofReal t < Finset.univ.inf (fun j => τ j ω)} =
      ENNReal.ofReal (r i / (∑ j, r j) * Real.exp (-((∑ j, r j) * t))) := by
  have hg := e1t_group h (fun j => decide (j = i))
  have hT : Finset.univ.filter (fun j => decide (j = i) = true) = {i} := by
    ext j; simp
  have hF : Finset.univ.filter (fun j => decide (j = i) = false) = Finset.univ.erase i := by
    ext j; simp
  have hsplit : ∑ j, r j = r i + ∑ j ∈ Finset.univ.erase i, r j := by
    rw [Finset.add_sum_erase _ _ (Finset.mem_univ i)]
  have hind : IndepFun (τ i) (fun ω => (Finset.univ.erase i).inf (fun j => τ j ω)) μ := by
    have h0 := hg.indep.indepFun (i := true) (j := false) (by decide)
    convert h0 using 1
    · funext ω; simp [Finset.filter_eq']
    · funext ω; simp [Finset.filter_ne']
  have hlawT : HasExpSurvival μ (τ i) (r i) := h.law i
  have hlawF : HasExpSurvival μ (fun ω => (Finset.univ.erase i).inf (fun j => τ j ω))
      (∑ j ∈ Finset.univ.erase i, r j) := survival_inf h _
  have hmF : Measurable (fun ω => (Finset.univ.erase i).inf (fun j => τ j ω)) :=
    (measurable_finset_inf _).comp (measurable_pi_iff.mpr h.meas)
  have hinf : ∀ ω, Finset.univ.inf (fun j => τ j ω) =
      min (τ i ω) ((Finset.univ.erase i).inf (fun j => τ j ω)) := by
    intro ω
    rw [← Finset.insert_erase (Finset.mem_univ i), Finset.inf_insert, Finset.insert_erase
      (Finset.mem_univ i)]
  have hset : {ω | τ i ω < (Finset.univ.erase i).inf (fun j => τ j ω) ∧
        ENNReal.ofReal t < Finset.univ.inf (fun j => τ j ω)} =
      {ω | ENNReal.ofReal t < τ i ω ∧ τ i ω < (Finset.univ.erase i).inf (fun j => τ j ω)} := by
    ext ω
    simp only [mem_ofPred_eq, hinf, lt_min_iff]
    constructor
    · rintro ⟨h1, h2, _⟩; exact ⟨h2, h1⟩
    · rintro ⟨h1, h2⟩; exact ⟨h2, h1, lt_trans h1 h2⟩
  rw [hset, e1t_race_joint (h.meas i) hmF hind (h.rate_nonneg i)
    (Finset.sum_nonneg (fun j _ => h.rate_nonneg j)) (by rw [← hsplit]; exact hR) hlawT hlawF ht,
    ← hsplit]

/-- **Competing exponentials, the winner's probability.** Stream `i` arrives strictly before
all the others with probability `r_i / R`. -/
theorem e1t_first_prob {ι : Type*} [Fintype ι] [DecidableEq ι] {τ : ι → Ω → ℝ≥0∞}
    {r : ι → ℝ} (h : FirstArrivals μ τ r) (i : ι) (hR : 0 < ∑ j, r j) :
    μ {ω | τ i ω < (Finset.univ.erase i).inf (fun j => τ j ω)} =
      ENNReal.ofReal (r i / (∑ j, r j)) := by
  have hg := e1t_group h (fun j => decide (j = i))
  have hsplit : ∑ j, r j = r i + ∑ j ∈ Finset.univ.erase i, r j := by
    rw [Finset.add_sum_erase _ _ (Finset.mem_univ i)]
  have hind : IndepFun (τ i) (fun ω => (Finset.univ.erase i).inf (fun j => τ j ω)) μ := by
    have h0 := hg.indep.indepFun (i := true) (j := false) (by decide)
    convert h0 using 1
    · funext ω; simp [Finset.filter_eq']
    · funext ω; simp [Finset.filter_ne']
  have hmF : Measurable (fun ω => (Finset.univ.erase i).inf (fun j => τ j ω)) :=
    (measurable_finset_inf _).comp (measurable_pi_iff.mpr h.meas)
  rw [e1t_race_prob (h.meas i) hmF hind (h.rate_nonneg i)
    (Finset.sum_nonneg (fun j _ => h.rate_nonneg j)) (by rw [← hsplit]; exact hR) (h.law i)
    (survival_inf h _), ← hsplit]

/-! ## 2. The enlarged event system of Section B.2.3 -/

/-- The seven event types of the table at lines 1297–1305. -/
inductive EvR
  | Ofull  -- rival full open-model release
  | Owt    -- rival permissive weights-only release
  | C1     -- rival closed release whose safeguards fail
  | C0     -- rival closed release whose safeguards work
  | Th     -- theft of weights
  | L      -- partner leak
  | R      -- rival restricted-terms release, no commercial offer
  deriving DecidableEq

instance : Fintype EvR :=
  ⟨{.Ofull, .Owt, .C1, .C0, .Th, .L, .R}, by intro x; cases x <;> decide⟩

/-- Primitive rates of the enlarged system: the original `λ_o, λ_c, p_c, λ_θ, λ_ℓ`, the
package-mark probability `p_full` and the restricted rate `λ_R`. -/
structure RatesR where
  q : Rates
  pfull : ℝ
  lR : ℝ

/-- Lines 1271, 1295, 1311 and B-S8: nonnegative rates, `0 ≤ p_c, p_full ≤ 1`, `λ_R ≥ 0`. -/
def RatesR.Admissible (Q : RatesR) : Prop :=
  Q.q.Admissible ∧ 0 ≤ Q.pfull ∧ Q.pfull ≤ 1 ∧ 0 ≤ Q.lR

/-- The intensity column of the table at lines 1297–1305. -/
def RatesR.rate (Q : RatesR) : EvR → ℝ
  | .Ofull => Q.pfull * Q.q.lo
  | .Owt => (1 - Q.pfull) * Q.q.lo
  | .C1 => Q.q.pc * Q.q.lc
  | .C0 => (1 - Q.q.pc) * Q.q.lc
  | .Th => Q.q.lth
  | .L => Q.q.ll
  | .R => Q.lR

theorem RatesR.rate_nonneg {Q : RatesR} (hQ : Q.Admissible) (e : EvR) : 0 ≤ Q.rate e := by
  obtain ⟨⟨h1, h2, h3, h4, h5, h6⟩, h7, h8, h9⟩ := hQ
  cases e <;> simp only [RatesR.rate]
  · exact mul_nonneg h7 h1
  · exact mul_nonneg (by linarith) h1
  · exact mul_nonneg h3 h2
  · exact mul_nonneg (by linarith) h2
  · exact h5
  · exact h6
  · exact h9

/-- Events that end the commercial lead (column 3 of the table): all but `O^R`. -/
def commR : Finset EvR := {.Ofull, .Owt, .C1, .C0, .Th, .L}

/-- Events of the original attack-enabling set (B.2.1, excluding C0), with `O` split by marks. -/
def attackR0 : Finset EvR := {.Ofull, .Owt, .C1, .Th, .L}

/-- Events that end attacker exclusion in the enlarged system (column 4): all but C0. -/
def attackRR : Finset EvR := {.Ofull, .Owt, .C1, .Th, .L, .R}

/-- `ω_C`, the first commercially substituting event (line 1307: as in B.2.1). -/
noncomputable def omegaC (s : EvR → ℝ≥0∞) : ℝ≥0∞ := commR.inf s

/-- `ω_A`, the first attack-enabling event of the original system. -/
noncomputable def omegaA (s : EvR → ℝ≥0∞) : ℝ≥0∞ := attackR0.inf s

/-- `ω_A^R = min(ω_A, ω_R)` (line 1309). -/
noncomputable def omegaAR (s : EvR → ℝ≥0∞) : ℝ≥0∞ := min (omegaA s) (s .R)

/-- `ω_full`, the first date of `O^full` (line 1307). -/
def omegaFull (s : EvR → ℝ≥0∞) : ℝ≥0∞ := s .Ofull

theorem omegaAR_eq (s : EvR → ℝ≥0∞) : omegaAR s = attackRR.inf s := by
  rw [show attackRR = insert EvR.R attackR0 from by decide, Finset.inf_insert, omegaAR, omegaA]
  exact min_comm _ _

theorem sum_commR (Q : RatesR) : ∑ e ∈ commR, Q.rate e = Q.q.lamC := by
  simp [commR, RatesR.rate, Rates.lamC]; ring

theorem sum_attackR0 (Q : RatesR) : ∑ e ∈ attackR0, Q.rate e = Q.q.lamA := by
  simp [attackR0, RatesR.rate, Rates.lamA]; ring

theorem sum_attackRR (Q : RatesR) : ∑ e ∈ attackRR, Q.rate e = Q.q.lamA + Q.lR := by
  simp [attackRR, RatesR.rate, Rates.lamA]; ring

theorem measurable_omegaC : Measurable omegaC := measurable_finset_inf commR
theorem measurable_omegaA : Measurable omegaA := measurable_finset_inf attackR0
theorem measurable_omegaAR : Measurable omegaAR := by
  have : omegaAR = fun s => attackRR.inf s := funext omegaAR_eq
  rw [this]; exact measurable_finset_inf attackRR

/-! ### The holder's actions and the realized windows (table at lines 1315–1322) -/

/-- The holder's initial actions in the enlarged system. -/
inductive ActR
  | hold       -- committed holding
  | wtRel      -- immediate permissive weights-only release
  | fullRel    -- immediate full open-model release
  | closedRel  -- immediate closed release (safeguards work or fail, by `B_h`)
  | restrRel   -- immediate restricted-terms release
  deriving DecidableEq

/-- Date at which the holder's own action supplies a commercial substitute. Restricted terms
are effective and the releaser makes no commercial offer (B-S8), so `restrRel` supplies none. -/
def commDateR : ActR → ℝ≥0∞
  | .hold => ⊤
  | .wtRel => 0
  | .fullRel => 0
  | .closedRel => 0
  | .restrRel => ⊤

/-- Date at which the holder's own action gives excluded attackers lasting capability;
`b = true` is `B_h = 1`. Holding includes no later voluntary release (B-S2, line 1313). -/
def attackDateR : ActR → Bool → ℝ≥0∞
  | .hold, _ => ⊤
  | .wtRel, _ => 0
  | .fullRel, _ => 0
  | .closedRel, b => if b then 0 else ⊤
  | .restrRel, _ => 0

/-- `W_C^R`: until the first commercial substitute (B.2.2's definition, line 1313). -/
def WCR (a : ActR) (ωC : ℝ≥0∞) : ℝ≥0∞ := min ωC (commDateR a)

/-- `W_A^R`: until excluded attackers obtain lasting capability (line 1313). -/
def WAR (a : ActR) (b : Bool) (ωAR : ℝ≥0∞) : ℝ≥0∞ := min ωAR (attackDateR a b)

/-- `t_pkg` (line 1313): `0` under immediate full open-model release, `ω_full` otherwise. -/
def tpkg (a : ActR) (ωfull : ℝ≥0∞) : ℝ≥0∞ := if a = .fullRel then 0 else ωfull

/-- **The action table** (lines 1315–1322), derived from the window definitions. -/
theorem b23_action_table (ωC ωAR ωf : ℝ≥0∞) :
    (WCR .hold ωC = ωC ∧ (∀ b, WAR .hold b ωAR = ωAR) ∧ tpkg .hold ωf = ωf) ∧
    (WCR .wtRel ωC = 0 ∧ (∀ b, WAR .wtRel b ωAR = 0) ∧ tpkg .wtRel ωf = ωf) ∧
    (WCR .fullRel ωC = 0 ∧ (∀ b, WAR .fullRel b ωAR = 0) ∧ tpkg .fullRel ωf = 0) ∧
    (WCR .closedRel ωC = 0 ∧ WAR .closedRel false ωAR = ωAR ∧ tpkg .closedRel ωf = ωf) ∧
    (WCR .closedRel ωC = 0 ∧ WAR .closedRel true ωAR = 0 ∧ tpkg .closedRel ωf = ωf) ∧
    (WCR .restrRel ωC = ωC ∧ (∀ b, WAR .restrRel b ωAR = 0) ∧ tpkg .restrRel ωf = ωf) := by
  simp [WCR, WAR, tpkg, commDateR, attackDateR]

/-- `ω_A^R ≤ ω_full` on every path (`O^full` ends attacker exclusion). -/
theorem omegaAR_le_omegaFull (s : EvR → ℝ≥0∞) : omegaAR s ≤ omegaFull s := by
  rw [omegaAR_eq]; exact Finset.inf_le (by decide)

/-- Line 1324: **`W_A^R ≤ t_pkg` in every row**, every safeguard outcome, every path. -/
theorem b23_WAR_le_tpkg (a : ActR) (b : Bool) (s : EvR → ℝ≥0∞) :
    WAR a b (omegaAR s) ≤ tpkg a (omegaFull s) := by
  cases a <;> cases b <;>
    simp [WAR, tpkg, attackDateR, omegaAR_le_omegaFull s]

/-! ### Exposure with the package discovery route (lines 1326–1339) -/

/-- `(u − m)⁺` for a real terminal date `u` and an onset `m ∈ ℝ ∪ {+∞}` (an `EReal`; `⊤` is a
minimum over no finite dates, line 1339, and contributes no exposure). -/
noncomputable def ppart (u : ℝ) (m : EReal) : ℝ := if m = ⊤ then 0 else max (u - m.toReal) 0

/-- The onset `min{b, t + Z}` with package date `t ∈ [0, ∞]` and added wait `Z ∈ [0, ∞]`
(an infinite date is omitted from the minimum, line 1339). -/
noncomputable def pkgOnset (b : EReal) (t z : ℝ≥0∞) : EReal := min b ((t + z : ℝ≥0∞) : EReal)

variable {P U F : Type*}

/-- **`X̃(Σ, W, t)`** (line 1335–1337) for the schedule `Σ` of Appendix B.2.2 (`Copies.Schedule`),
the map from patched and unfound flaw–operator pairs to their flaw (`fP`, `fU`), the added waits
`Z_f`, the window `W` and the package date `t`. The cohort weights are `k_{fj,ex} = w·(1 − π)` and
`k_{fj,par} = w·π`; the baseline onsets `b_{fi}(Σ, W)` are the table at lines 1328–1333; the
terminal date is `u = P_f + τ_fj` (patched) or `ζ_j` (unfound). -/
noncomputable def pkgExposure [Fintype P] [Fintype U] (π : ℝ) (σ : Schedule P U) (fP : P → F)
    (fU : U → F) (Z : F → ℝ≥0∞) (W : ℝ) (t : ℝ≥0∞) : ℝ :=
  (∑ i, σ.w i * ((1 - π) * ppart (σ.pub i + σ.dep i)
        (pkgOnset ((min (σ.pub i + σ.lag) (W + σ.disc i) : ℝ) : EReal) t (Z (fP i)))
      + π * ppart (σ.pub i + σ.dep i)
        (pkgOnset ((min (σ.pub i + σ.lag) (σ.discPi i) : ℝ) : EReal) t (Z (fP i)))))
  + ∑ k, σ.uw k * ((1 - π) * ppart (σ.rem k) (pkgOnset ((W + σ.udisc k : ℝ) : EReal) t (Z (fU k)))
      + π * ppart (σ.rem k) (pkgOnset ((σ.udiscPi k : ℝ) : EReal) t (Z (fU k))))

theorem ppart_coe (u x : ℝ) : ppart u (x : EReal) = max (u - x) 0 := by
  simp [ppart, EReal.coe_ne_top]

theorem pkgOnset_top (b : EReal) (t : ℝ≥0∞) : pkgOnset b t ⊤ = b := by
  simp [pkgOnset, EReal.coe_ennreal_top]

/-- Line 1347 and E4's last sentence: **with package discovery disabled (every `Z_f = ∞`, i.e.
every `η_f = 0`), `X̃ = X`** for every window and every package date. -/
theorem b23_pkgExposure_noPkg [Fintype P] [Fintype U] (π : ℝ) (σ : Schedule P U) (fP : P → F)
    (fU : U → F) (W : ℝ) (t : ℝ≥0∞) :
    pkgExposure π σ fP fU (fun _ => ⊤) W t = exposure π σ W := by
  simp only [pkgExposure, pkgOnset_top, ppart_coe, exposure, patchedTerm, unfoundTerm]
  congr 1
  apply Finset.sum_congr rfl; intro k _
  rw [sub_add_eq_sub_sub]

/-! ## 3. Proposition E4 -/

/-- Marks of a marked open stream with arrival dates `d n` and marks `m n` (`true` = full
open-model release): the first date carrying mark `b`. A stream with no such arrival has
first date `∞`. -/
noncomputable def firstMarked (d : ℕ → ℝ≥0∞) (m : ℕ → Bool) (b : Bool) : ℝ≥0∞ :=
  ⨅ n, if m n = b then d n else ⊤

/-- **Erasing the package marks returns the original path of O** (line 1494): whatever the
marks, the first of the two marked first dates is the first arrival of O. -/
theorem e4_erase_marks (d : ℕ → ℝ≥0∞) (m : ℕ → Bool) :
    min (firstMarked d m true) (firstMarked d m false) = ⨅ n, d n := by
  apply le_antisymm
  · refine le_iInf (fun n => ?_)
    cases hm : m n
    · exact (min_le_right _ _).trans (iInf_le_of_le n (by simp [hm]))
    · exact (min_le_left _ _).trans (iInf_le_of_le n (by simp [hm]))
  · exact le_min (le_iInf fun n => (iInf_le _ n).trans (by split_ifs <;> simp))
      (le_iInf fun n => (iInf_le _ n).trans (by split_ifs <;> simp))

/-- The first-arrival vector of the enlarged system built from the marked O stream (dates `d`,
marks `m`) and the first dates `o` of the other streams. -/
noncomputable def markedVec (d : ℕ → ℝ≥0∞) (m : ℕ → Bool) (o : EvR → ℝ≥0∞) : EvR → ℝ≥0∞
  | .Ofull => firstMarked d m true
  | .Owt => firstMarked d m false
  | e => o e

theorem commR_inf_split (s : EvR → ℝ≥0∞) :
    omegaC s = min (min (s .Ofull) (s .Owt)) (min (s .C1) (min (s .C0) (min (s .Th) (s .L)))) := by
  simp only [omegaC, commR, Finset.inf_insert, Finset.inf_singleton]
  exact (min_assoc _ _ _).symm

theorem attackRR_inf_split (s : EvR → ℝ≥0∞) :
    omegaAR s = min (min (s .Ofull) (s .Owt)) (min (s .C1) (min (s .Th) (min (s .L) (s .R)))) := by
  rw [omegaAR_eq]
  simp only [attackRR, Finset.inf_insert, Finset.inf_singleton]
  exact (min_assoc _ _ _).symm

/-- **E4, pathwise (first-date form).** Two first-arrival vectors that agree on every stream
other than the two marked open streams, and whose open streams have the same first arrival,
give the same `ω_C`, the same `ω_A^R`, the same realized windows for every action and safeguard
outcome, and the same `X(Σ, W_A^R)` at every common schedule. -/
theorem e4_pathwise (s s' : EvR → ℝ≥0∞)
    (hO : min (s .Ofull) (s .Owt) = min (s' .Ofull) (s' .Owt))
    (hrest : ∀ e, e ≠ .Ofull → e ≠ .Owt → s e = s' e) :
    omegaC s = omegaC s' ∧ omegaAR s = omegaAR s' ∧
    (∀ (a : ActR) (b : Bool), WCR a (omegaC s) = WCR a (omegaC s') ∧
      WAR a b (omegaAR s) = WAR a b (omegaAR s')) ∧
    (∀ [Fintype P] [Fintype U] (π : ℝ) (σ : Schedule P U) (a : ActR) (b : Bool),
      exposure π σ (WAR a b (omegaAR s)).toReal = exposure π σ (WAR a b (omegaAR s')).toReal) := by
  have hC : omegaC s = omegaC s' := by
    rw [commR_inf_split, commR_inf_split, hO, hrest .C1 (by decide) (by decide),
      hrest .C0 (by decide) (by decide), hrest .Th (by decide) (by decide),
      hrest .L (by decide) (by decide)]
  have hA : omegaAR s = omegaAR s' := by
    rw [attackRR_inf_split, attackRR_inf_split, hO, hrest .C1 (by decide) (by decide),
      hrest .Th (by decide) (by decide), hrest .L (by decide) (by decide),
      hrest .R (by decide) (by decide)]
  exact ⟨hC, hA, fun a b => ⟨by rw [hC], by rw [hA]⟩, fun π σ a b => by rw [hA]⟩

/-- **E4, pathwise (marked-stream form).** "Changing package marks while preserving arrival
dates" (line 1406): for every date sequence of O, any two mark sequences `m`, `m'`, and the
same other streams, `ω_C`, `ω_A^R`, every realized window and `X(Σ, W_A^R)` are unchanged. -/
theorem e4_relabel (d : ℕ → ℝ≥0∞) (m m' : ℕ → Bool) (o : EvR → ℝ≥0∞) :
    omegaC (markedVec d m o) = omegaC (markedVec d m' o) ∧
    omegaAR (markedVec d m o) = omegaAR (markedVec d m' o) ∧
    (∀ (a : ActR) (b : Bool), WCR a (omegaC (markedVec d m o)) = WCR a (omegaC (markedVec d m' o)) ∧
      WAR a b (omegaAR (markedVec d m o)) = WAR a b (omegaAR (markedVec d m' o))) ∧
    (∀ [Fintype P] [Fintype U] (π : ℝ) (σ : Schedule P U) (a : ActR) (b : Bool),
      exposure π σ (WAR a b (omegaAR (markedVec d m o))).toReal =
        exposure π σ (WAR a b (omegaAR (markedVec d m' o))).toReal) := by
  refine e4_pathwise (P := P) (U := U) _ _ ?_ ?_
  · simp only [markedVec, e4_erase_marks]
  · intro e h1 h2; cases e <;> simp_all [markedVec]

/-- The index of the erased system: O with its package marks erased. -/
inductive EvE
  | O | C1 | C0 | Th | L | R
  deriving DecidableEq

instance : Fintype EvE := ⟨{.O, .C1, .C0, .Th, .L, .R}, by intro x; cases x <;> decide⟩

/-- Erasing the package marks. -/
def eraseMark : EvR → EvE
  | .Ofull => .O
  | .Owt => .O
  | .C1 => .C1
  | .C0 => .C0
  | .Th => .Th
  | .L => .L
  | .R => .R

/-- Rates of the erased system: these do not involve `p_full`. -/
def RatesR.rateE (Q : RatesR) : EvE → ℝ
  | .O => Q.q.lo
  | .C1 => Q.q.pc * Q.q.lc
  | .C0 => (1 - Q.q.pc) * Q.q.lc
  | .Th => Q.q.lth
  | .L => Q.q.ll
  | .R => Q.lR

/-- The erased first-arrival vector: each erased stream's first date is the first date over its
marked parts. -/
noncomputable def eraseVec (s : EvR → ℝ≥0∞) (k : EvE) : ℝ≥0∞ :=
  (Finset.univ.filter (fun i => eraseMark i = k)).inf s

theorem erase_rates (Q : RatesR) (k : EvE) :
    ∑ i ∈ Finset.univ.filter (fun i => eraseMark i = k), Q.rate i = Q.rateE k := by
  cases k
  · rw [show Finset.univ.filter (fun i => eraseMark i = EvE.O) = {.Ofull, .Owt} from by decide]
    simp [RatesR.rate, RatesR.rateE]; ring
  all_goals
    first
    | rw [show Finset.univ.filter (fun i => eraseMark i = EvE.C1) = {.C1} from by decide]
      simp [RatesR.rate, RatesR.rateE]
    | rw [show Finset.univ.filter (fun i => eraseMark i = EvE.C0) = {.C0} from by decide]
      simp [RatesR.rate, RatesR.rateE]
    | rw [show Finset.univ.filter (fun i => eraseMark i = EvE.Th) = {.Th} from by decide]
      simp [RatesR.rate, RatesR.rateE]
    | rw [show Finset.univ.filter (fun i => eraseMark i = EvE.L) = {.L} from by decide]
      simp [RatesR.rate, RatesR.rateE]
    | rw [show Finset.univ.filter (fun i => eraseMark i = EvE.R) = {.R} from by decide]
      simp [RatesR.rate, RatesR.rateE]

/-- **E4, the marked stream recombines** (line 1490–1494). If the seven marked streams satisfy
the first-arrival law, the erased family (O with marks erased, and the other streams) again
satisfies it, with O at rate `λ_o`: independent of the other streams, survival
`e^{−p_full λ_o t} e^{−(1 − p_full) λ_o t} = e^{−λ_o t}`. -/
theorem e4_erased_firstArrivals {τ : EvR → Ω → ℝ≥0∞} {Q : RatesR}
    (h : FirstArrivals μ τ Q.rate) :
    FirstArrivals μ (fun k ω => eraseVec (fun e => τ e ω) k) Q.rateE := by
  have hg := e1t_group h eraseMark
  have hr : (fun k => ∑ i ∈ Finset.univ.filter (fun i => eraseMark i = k), Q.rate i) = Q.rateE :=
    funext (erase_rates Q)
  rw [hr] at hg
  exact hg

/-- The windows' first dates through the erased vector. -/
def commE : Finset EvE := {.O, .C1, .C0, .Th, .L}
def attackE : Finset EvE := {.O, .C1, .Th, .L, .R}

theorem eraseVec_O (s : EvR → ℝ≥0∞) : eraseVec s .O = min (s .Ofull) (s .Owt) := by
  rw [eraseVec, show Finset.univ.filter (fun i => eraseMark i = EvE.O) = {.Ofull, .Owt} from
    by decide]
  simp only [Finset.inf_insert, Finset.inf_singleton]

theorem eraseVec_single (s : EvR → ℝ≥0∞) :
    eraseVec s .C1 = s .C1 ∧ eraseVec s .C0 = s .C0 ∧ eraseVec s .Th = s .Th ∧
    eraseVec s .L = s .L ∧ eraseVec s .R = s .R := by
  refine ⟨?_, ?_, ?_, ?_, ?_⟩ <;> rw [eraseVec]
  · rw [show Finset.univ.filter (fun i => eraseMark i = EvE.C1) = {.C1} from by decide]; simp
  · rw [show Finset.univ.filter (fun i => eraseMark i = EvE.C0) = {.C0} from by decide]; simp
  · rw [show Finset.univ.filter (fun i => eraseMark i = EvE.Th) = {.Th} from by decide]; simp
  · rw [show Finset.univ.filter (fun i => eraseMark i = EvE.L) = {.L} from by decide]; simp
  · rw [show Finset.univ.filter (fun i => eraseMark i = EvE.R) = {.R} from by decide]; simp

theorem omegaC_erase (s : EvR → ℝ≥0∞) : omegaC s = commE.inf (eraseVec s) := by
  obtain ⟨h1, h2, h3, h4, _⟩ := eraseVec_single s
  rw [commR_inf_split]
  simp only [commE, Finset.inf_insert, Finset.inf_singleton, eraseVec_O, h1, h2, h3, h4]

theorem omegaAR_erase (s : EvR → ℝ≥0∞) : omegaAR s = attackE.inf (eraseVec s) := by
  obtain ⟨h1, _, h3, h4, h5⟩ := eraseVec_single s
  rw [attackRR_inf_split]
  simp only [attackE, Finset.inf_insert, Finset.inf_singleton, eraseVec_O, h1, h3, h4, h5]

theorem measurable_eraseVec : Measurable (fun (s : EvR → ℝ≥0∞) (k : EvE) => eraseVec s k) :=
  measurable_pi_iff.mpr (fun k => measurable_finset_inf _)

/-- **E4, laws: "Their window laws depend on the marked open stream only through `λ_o`"**
(line 1406). Two enlarged systems (on any probability spaces) whose seven marked streams satisfy
the first-arrival law with rate tuples that agree except, possibly, in the package-mark
probability `p_full`, give the same joint law of `(ω_C, ω_A^R)`. -/
theorem e4_window_law {τ : EvR → Ω → ℝ≥0∞} {Q Q' : RatesR} {Ω' : Type*} [MeasurableSpace Ω']
    {μ' : Measure Ω'} [IsProbabilityMeasure μ'] {τ' : EvR → Ω' → ℝ≥0∞}
    (h : FirstArrivals μ τ Q.rate) (h' : FirstArrivals μ' τ' Q'.rate)
    (hq : Q.q = Q'.q) (hR : Q.lR = Q'.lR) :
    μ.map (fun ω => (omegaC (fun e => τ e ω), omegaAR (fun e => τ e ω))) =
      μ'.map (fun ω => (omegaC (fun e => τ' e ω), omegaAR (fun e => τ' e ω))) := by
  have hE : Q.rateE = Q'.rateE := by
    funext k; cases k <;> simp [RatesR.rateE, hq, hR]
  have hl := e1t_law_unique (e4_erased_firstArrivals h) (hE ▸ e4_erased_firstArrivals h')
  have hF : Measurable (fun v : EvE → ℝ≥0∞ => (commE.inf v, attackE.inf v)) :=
    (measurable_finset_inf _).prodMk (measurable_finset_inf _)
  have hV : Measurable (fun ω k => eraseVec (fun e => τ e ω) k) :=
    measurable_eraseVec.comp (measurable_pi_iff.mpr h.meas)
  have hV' : Measurable (fun ω k => eraseVec (fun e => τ' e ω) k) :=
    measurable_eraseVec.comp (measurable_pi_iff.mpr h'.meas)
  have e1 : (fun ω => (omegaC (fun e => τ e ω), omegaAR (fun e => τ e ω))) =
      (fun v : EvE → ℝ≥0∞ => (commE.inf v, attackE.inf v)) ∘
        (fun ω k => eraseVec (fun e => τ e ω) k) := by
    funext ω; simp only [Function.comp, omegaC_erase, omegaAR_erase]
  have e2 : (fun ω => (omegaC (fun e => τ' e ω), omegaAR (fun e => τ' e ω))) =
      (fun v : EvE → ℝ≥0∞ => (commE.inf v, attackE.inf v)) ∘
        (fun ω k => eraseVec (fun e => τ' e ω) k) := by
    funext ω; simp only [Function.comp, omegaC_erase, omegaAR_erase]
  rw [e1, e2, ← Measure.map_map hF hV, ← Measure.map_map hF hV', hl]

/-- **E4, realized windows' laws.** For each action and each safeguard outcome, the joint law of
`(W_C^R, W_A^R)` depends on the marked open stream only through `λ_o`. -/
theorem e4_realized_window_law {τ : EvR → Ω → ℝ≥0∞} {Q Q' : RatesR} {Ω' : Type*}
    [MeasurableSpace Ω'] {μ' : Measure Ω'} [IsProbabilityMeasure μ'] {τ' : EvR → Ω' → ℝ≥0∞}
    (h : FirstArrivals μ τ Q.rate) (h' : FirstArrivals μ' τ' Q'.rate)
    (hq : Q.q = Q'.q) (hR : Q.lR = Q'.lR) (a : ActR) (b : Bool) :
    μ.map (fun ω => (WCR a (omegaC (fun e => τ e ω)), WAR a b (omegaAR (fun e => τ e ω)))) =
      μ'.map (fun ω => (WCR a (omegaC (fun e => τ' e ω)), WAR a b (omegaAR (fun e => τ' e ω)))) := by
  have hG : Measurable (fun p : ℝ≥0∞ × ℝ≥0∞ => (WCR a p.1, WAR a b p.2)) := by
    unfold WCR WAR; fun_prop
  have hm : Measurable (fun ω => (omegaC (fun e => τ e ω), omegaAR (fun e => τ e ω))) :=
    (measurable_omegaC.comp (measurable_pi_iff.mpr h.meas)).prodMk
      (measurable_omegaAR.comp (measurable_pi_iff.mpr h.meas))
  have hm' : Measurable (fun ω => (omegaC (fun e => τ' e ω), omegaAR (fun e => τ' e ω))) :=
    (measurable_omegaC.comp (measurable_pi_iff.mpr h'.meas)).prodMk
      (measurable_omegaAR.comp (measurable_pi_iff.mpr h'.meas))
  have := congrArg (fun ν => ν.map (fun p : ℝ≥0∞ × ℝ≥0∞ => (WCR a p.1, WAR a b p.2)))
    (e4_window_law h h' hq hR)
  rw [Measure.map_map hG hm, Measure.map_map hG hm'] at this
  exact this

/-- **E4, the two permissive releases** (lines 1406–1408): immediate permissive weights-only
release and immediate full open-model release both give `(W_C^R, W_A^R) = (0, 0)` and
`X(Σ, W_A^R) = X(Σ, 0)`, on every path, for every safeguard indicator. -/
theorem e4_permissive_releases [Fintype P] [Fintype U] (s : EvR → ℝ≥0∞) (b : Bool) (π : ℝ)
    (σ : Schedule P U) :
    (WCR .wtRel (omegaC s) = 0 ∧ WAR .wtRel b (omegaAR s) = 0) ∧
    (WCR .fullRel (omegaC s) = 0 ∧ WAR .fullRel b (omegaAR s) = 0) ∧
    exposure π σ (WAR .wtRel b (omegaAR s)).toReal = exposure π σ 0 ∧
    exposure π σ (WAR .fullRel b (omegaAR s)).toReal = exposure π σ 0 := by
  simp [WCR, WAR, commDateR, attackDateR]

/-- **E4, last sentence** (line 1410): if every `η_f = 0` (so every `Z_f = ∞`, B-S9), the two
permissive releases also give the same `X̃`: `X̃(Σ, 0, t_pkg)` with `t_pkg = ω_full` and
`t_pkg = 0` are both `X(Σ, 0)`. -/
theorem e4_noPkg_Xtilde [Fintype P] [Fintype U] (s : EvR → ℝ≥0∞) (b : Bool) (π : ℝ)
    (σ : Schedule P U) (fP : P → F) (fU : U → F) {Z : F → ℝ≥0∞} (hZ : ∀ f, Z f = ⊤) :
    pkgExposure π σ fP fU Z (WAR .wtRel b (omegaAR s)).toReal (tpkg .wtRel (omegaFull s)) =
      pkgExposure π σ fP fU Z (WAR .fullRel b (omegaAR s)).toReal (tpkg .fullRel (omegaFull s)) ∧
    pkgExposure π σ fP fU Z (WAR .fullRel b (omegaAR s)).toReal (tpkg .fullRel (omegaFull s)) =
      exposure π σ 0 := by
  have hZ' : Z = fun _ => ⊤ := funext hZ
  subst hZ'
  simp [b23_pkgExposure_noPkg, WAR, attackDateR]

/-! ## 4. Proposition E5 and its corollary -/

/-- The three event classes of the proof of E5 (line 1496). -/
inductive Cls
  | com   -- commercial-only: C0
  | both  -- both effects: O^full, O^wt, C1, Θ, L
  | atk   -- attack-only: O^R
  deriving DecidableEq

instance : Fintype Cls := ⟨{.com, .both, .atk}, by intro x; cases x <;> decide⟩

def clsOf : EvR → Cls
  | .C0 => .com
  | .R => .atk
  | _ => .both

/-- First date of each class. -/
noncomputable def classDate (s : EvR → ℝ≥0∞) (k : Cls) : ℝ≥0∞ :=
  (Finset.univ.filter (fun i => clsOf i = k)).inf s

/-- Class rates: `(1 − p_c)λ_c`, `λ_A`, `λ_R`. -/
def RatesR.clsRate (Q : RatesR) : Cls → ℝ
  | .com => (1 - Q.q.pc) * Q.q.lc
  | .both => Q.q.lamA
  | .atk => Q.lR

theorem cls_filter :
    Finset.univ.filter (fun i => clsOf i = Cls.com) = {EvR.C0} ∧
    Finset.univ.filter (fun i => clsOf i = Cls.both) = attackR0 ∧
    Finset.univ.filter (fun i => clsOf i = Cls.atk) = {EvR.R} := by
  refine ⟨by decide, by decide, by decide⟩

theorem cls_rates (Q : RatesR) (k : Cls) :
    ∑ i ∈ Finset.univ.filter (fun i => clsOf i = k), Q.rate i = Q.clsRate k := by
  obtain ⟨h1, h2, h3⟩ := cls_filter
  cases k
  · rw [h1]; simp [RatesR.rate, RatesR.clsRate]
  · rw [h2, sum_attackR0]; rfl
  · rw [h3]; simp [RatesR.rate, RatesR.clsRate]

theorem classDate_eq (s : EvR → ℝ≥0∞) :
    classDate s .com = s .C0 ∧ classDate s .both = omegaA s ∧ classDate s .atk = s .R := by
  obtain ⟨h1, h2, h3⟩ := cls_filter
  refine ⟨?_, ?_, ?_⟩ <;> simp only [classDate, h1, h2, h3, Finset.inf_singleton, omegaA]

theorem omegaC_classes (s : EvR → ℝ≥0∞) : omegaC s = min (s .C0) (omegaA s) := by
  rw [omegaC, show commR = insert EvR.C0 attackR0 from by decide, Finset.inf_insert]; rfl

/-- Line 1496: the classes are independent, with rates `(1 − p_c)λ_c`, `λ_A`, `λ_R`. -/
theorem e5_classes {τ : EvR → Ω → ℝ≥0∞} {Q : RatesR} (h : FirstArrivals μ τ Q.rate) :
    FirstArrivals μ (fun k ω => classDate (fun e => τ e ω) k) Q.clsRate := by
  have hg := e1t_group h clsOf
  have hr : (fun k => ∑ i ∈ Finset.univ.filter (fun i => clsOf i = k), Q.rate i) = Q.clsRate :=
    funext (cls_rates Q)
  rw [hr] at hg; exact hg

theorem lamC_split (Q : RatesR) : Q.q.lamC = Q.q.lamA + (1 - Q.q.pc) * Q.q.lc := by
  simp only [Rates.lamC, Rates.lamA]; ring

theorem min_lt_min_shared (x y z : ℝ≥0∞) : min x y < min y z ↔ x < min y z := by
  rw [min_lt_iff]
  constructor
  · rintro (h | h)
    · exact h
    · exact absurd h (not_lt.mpr (min_le_left _ _))
  · exact Or.inl

section E5

variable {τ : EvR → Ω → ℝ≥0∞} {Q : RatesR}

/-- **E5, laws.** Under committed holding, `ω_C` is exponential with rate `λ_C` and `ω_A^R` with
rate `λ_A + λ_R`. -/
theorem e5_laws (h : FirstArrivals μ τ Q.rate) :
    HasExpSurvival μ (fun ω => omegaC (fun e => τ e ω)) Q.q.lamC ∧
    HasExpSurvival μ (fun ω => omegaAR (fun e => τ e ω)) (Q.q.lamA + Q.lR) := by
  refine ⟨?_, ?_⟩
  · rw [← sum_commR]; exact survival_inf h commR
  · rw [← sum_attackRR]
    simp only [omegaAR_eq]; exact survival_inf h attackRR

theorem e5_total_pos (hQ : Q.Admissible) (hA : 0 < Q.q.lamA) : 0 < Q.q.lamC + Q.lR := by
  have := (e1_lambdaC_pos hQ.1 hA).2; linarith [hQ.2.2.2]

theorem e5_cls_total (Q : RatesR) : ∑ k, Q.clsRate k = Q.q.lamC + Q.lR := by
  rw [show (Finset.univ : Finset Cls) = {.com, .both, .atk} from rfl]
  simp [RatesR.clsRate, lamC_split]; ring

/-- **E5, `P(ω_A^R < ω_C) = λ_R/(λ_C + λ_R)`.** -/
theorem e5_prob_attack_first (hQ : Q.Admissible) (hA : 0 < Q.q.lamA)
    (h : FirstArrivals μ τ Q.rate) :
    μ {ω | omegaAR (fun e => τ e ω) < omegaC (fun e => τ e ω)} =
      ENNReal.ofReal (Q.lR / (Q.q.lamC + Q.lR)) := by
  have hc := e5_classes h
  have hp := e1t_first_prob hc Cls.atk (by rw [e5_cls_total]; exact e5_total_pos hQ hA)
  rw [e5_cls_total] at hp
  refine Eq.trans ?_ hp
  congr 1; ext ω
  obtain ⟨h1, h2, h3⟩ := classDate_eq (fun e => τ e ω)
  rw [show (Finset.univ.erase Cls.atk) = {.com, .both} from by decide]
  simp only [mem_ofPred_eq, Finset.inf_insert, Finset.inf_singleton, h1, h2, h3]
  rw [omegaAR, omegaC_classes, min_comm (omegaA _), min_comm (τ .C0 ω)]
  exact min_lt_min_shared _ _ _

/-- **E5, `P(ω_C < ω_A^R) = (1 − p_c)λ_c/(λ_C + λ_R)`.** -/
theorem e5_prob_comm_first (hQ : Q.Admissible) (hA : 0 < Q.q.lamA)
    (h : FirstArrivals μ τ Q.rate) :
    μ {ω | omegaC (fun e => τ e ω) < omegaAR (fun e => τ e ω)} =
      ENNReal.ofReal ((1 - Q.q.pc) * Q.q.lc / (Q.q.lamC + Q.lR)) := by
  have hc := e5_classes h
  have hp := e1t_first_prob hc Cls.com (by rw [e5_cls_total]; exact e5_total_pos hQ hA)
  rw [e5_cls_total] at hp
  refine Eq.trans ?_ hp
  congr 1; ext ω
  obtain ⟨h1, h2, h3⟩ := classDate_eq (fun e => τ e ω)
  rw [show (Finset.univ.erase Cls.com) = {.both, .atk} from by decide]
  simp only [mem_ofPred_eq, Finset.inf_insert, Finset.inf_singleton, h1, h2, h3]
  rw [omegaAR, omegaC_classes]
  exact min_lt_min_shared _ _ _

theorem measurableSet_lt_pair (h : FirstArrivals μ τ Q.rate) :
    MeasurableSet {ω | omegaAR (fun e => τ e ω) < omegaC (fun e => τ e ω)} ∧
    MeasurableSet {ω | omegaC (fun e => τ e ω) < omegaAR (fun e => τ e ω)} ∧
    MeasurableSet {ω | omegaAR (fun e => τ e ω) = omegaC (fun e => τ e ω)} := by
  have hS := measurable_pi_iff.mpr h.meas
  have hC := measurable_omegaC.comp hS
  have hA := measurable_omegaAR.comp hS
  exact ⟨measurableSet_lt hA hC, measurableSet_lt hC hA, measurableSet_eq_fun hA hC⟩

/-- **E5, `P(ω_A^R = ω_C) = λ_A/(λ_C + λ_R)`.** -/
theorem e5_prob_tie (hQ : Q.Admissible) (hA : 0 < Q.q.lamA) (h : FirstArrivals μ τ Q.rate) :
    μ {ω | omegaAR (fun e => τ e ω) = omegaC (fun e => τ e ω)} =
      ENNReal.ofReal (Q.q.lamA / (Q.q.lamC + Q.lR)) := by
  obtain ⟨m1, m2, m3⟩ := measurableSet_lt_pair h
  set A := {ω | omegaAR (fun e => τ e ω) < omegaC (fun e => τ e ω)}
  set B := {ω | omegaC (fun e => τ e ω) < omegaAR (fun e => τ e ω)}
  set E := {ω | omegaAR (fun e => τ e ω) = omegaC (fun e => τ e ω)}
  have hdisj1 : Disjoint A B := by
    rw [Set.disjoint_left]
    intro ω (h1 : omegaAR _ < omegaC _) (h2 : omegaC _ < omegaAR _)
    exact absurd (lt_trans h1 h2) (lt_irrefl _)
  have hdisj2 : Disjoint (A ∪ B) E := by
    rw [Set.disjoint_left]; intro ω h1 (h2 : omegaAR _ = omegaC _)
    rcases h1 with (h1 : omegaAR _ < omegaC _) | (h1 : omegaC _ < omegaAR _)
    · exact absurd h2 (ne_of_lt h1)
    · exact absurd h2.symm (ne_of_lt h1)
  have hcover : A ∪ B ∪ E = univ := by
    ext ω; simp only [mem_union, mem_univ, iff_true, A, B, E, mem_ofPred_eq]
    rcases lt_trichotomy (omegaAR (fun e => τ e ω)) (omegaC (fun e => τ e ω)) with h | h | h
    · exact Or.inl (Or.inl h)
    · exact Or.inr h
    · exact Or.inl (Or.inr h)
  have hsum : μ A + μ B + μ E = 1 := by
    rw [← measure_union hdisj1 m2, ← measure_union hdisj2 m3, hcover, measure_univ]
  have hT := e5_total_pos hQ hA
  have hx : 0 ≤ Q.lR / (Q.q.lamC + Q.lR) := div_nonneg hQ.2.2.2 hT.le
  have hy : 0 ≤ (1 - Q.q.pc) * Q.q.lc / (Q.q.lamC + Q.lR) :=
    div_nonneg (mul_nonneg (by linarith [hQ.1.2.2.2.1]) hQ.1.2.1) hT.le
  rw [show μ A = _ from e5_prob_attack_first hQ hA h,
    show μ B = _ from e5_prob_comm_first hQ hA h] at hsum
  have hE : μ E = 1 - (ENNReal.ofReal (Q.lR / (Q.q.lamC + Q.lR)) +
      ENNReal.ofReal ((1 - Q.q.pc) * Q.q.lc / (Q.q.lamC + Q.lR))) :=
    ENNReal.eq_sub_of_add_eq (by simp) (by rw [add_comm]; exact hsum)
  rw [hE, ← ENNReal.ofReal_add hx hy, ← ENNReal.ofReal_one, ← ENNReal.ofReal_sub _ (add_nonneg hx hy)]
  congr 1
  rw [lamC_split] at hT ⊢
  field_simp
  ring

/-- **E5, means.** Both means are finite: `E[ω_C] = 1/λ_C`, `E[ω_A^R] = 1/(λ_A + λ_R)`. -/
theorem e5_means (hQ : Q.Admissible) (hA : 0 < Q.q.lamA) (h : FirstArrivals μ τ Q.rate) :
    ∫⁻ ω, omegaC (fun e => τ e ω) ∂μ = ENNReal.ofReal (1 / Q.q.lamC) ∧
    ∫⁻ ω, omegaAR (fun e => τ e ω) ∂μ = ENNReal.ofReal (1 / (Q.q.lamA + Q.lR)) := by
  have hS := measurable_pi_iff.mpr h.meas
  obtain ⟨l1, l2⟩ := e5_laws h
  exact ⟨l1.lintegral_eq (measurable_omegaC.comp hS) (e1_lambdaC_pos hQ.1 hA).2,
    l2.lintegral_eq (measurable_omegaAR.comp hS) (by linarith [hQ.2.2.2])⟩

/-- **E5, first ordering equivalence.** `ω_C ≤ ω_A^R` almost surely iff `λ_R = 0`. -/
theorem e5_order_comm_first_iff (hQ : Q.Admissible) (hA : 0 < Q.q.lamA)
    (h : FirstArrivals μ τ Q.rate) :
    (∀ᵐ ω ∂μ, omegaC (fun e => τ e ω) ≤ omegaAR (fun e => τ e ω)) ↔ Q.lR = 0 := by
  rw [ae_iff]
  simp only [not_le]
  rw [e5_prob_attack_first hQ hA h, ENNReal.ofReal_eq_zero,
    div_le_iff₀ (e5_total_pos hQ hA), zero_mul]
  exact ⟨fun h1 => le_antisymm h1 hQ.2.2.2, fun h1 => h1.le⟩

/-- **E5, second ordering equivalence.** `ω_A^R ≤ ω_C` almost surely iff `(1 − p_c)λ_c = 0`. -/
theorem e5_order_attack_first_iff (hQ : Q.Admissible) (hA : 0 < Q.q.lamA)
    (h : FirstArrivals μ τ Q.rate) :
    (∀ᵐ ω ∂μ, omegaAR (fun e => τ e ω) ≤ omegaC (fun e => τ e ω)) ↔
      (1 - Q.q.pc) * Q.q.lc = 0 := by
  rw [ae_iff]
  simp only [not_le]
  rw [e5_prob_comm_first hQ hA h, ENNReal.ofReal_eq_zero,
    div_le_iff₀ (e5_total_pos hQ hA), zero_mul]
  have : 0 ≤ (1 - Q.q.pc) * Q.q.lc := mul_nonneg (by linarith [hQ.1.2.2.2.1]) hQ.1.2.1
  exact ⟨fun h1 => le_antisymm h1 this, fun h1 => h1.le⟩

/-- **E5, almost-sure equality requires both rates to vanish** (and conversely). -/
theorem e5_ae_eq_iff (hQ : Q.Admissible) (hA : 0 < Q.q.lamA) (h : FirstArrivals μ τ Q.rate) :
    (∀ᵐ ω ∂μ, omegaC (fun e => τ e ω) = omegaAR (fun e => τ e ω)) ↔
      Q.lR = 0 ∧ (1 - Q.q.pc) * Q.q.lc = 0 := by
  rw [← e5_order_comm_first_iff hQ hA h, ← e5_order_attack_first_iff hQ hA h]
  constructor
  · intro he
    exact ⟨he.mono fun ω h => h.le, he.mono fun ω h => h.ge⟩
  · rintro ⟨h1, h2⟩
    filter_upwards [h1, h2] with ω a b using le_antisymm a b

/-- **E5, mean comparison.** `E[ω_C] ≤ E[ω_A^R]` iff `λ_R ≤ (1 − p_c)λ_c`; equality iff
equality; strict inequality iff strict inequality. -/
theorem e5_mean_compare (hQ : Q.Admissible) (hA : 0 < Q.q.lamA) (h : FirstArrivals μ τ Q.rate) :
    ((∫⁻ ω, omegaC (fun e => τ e ω) ∂μ) ≤ ∫⁻ ω, omegaAR (fun e => τ e ω) ∂μ ↔
      Q.lR ≤ (1 - Q.q.pc) * Q.q.lc) ∧
    ((∫⁻ ω, omegaC (fun e => τ e ω) ∂μ) = ∫⁻ ω, omegaAR (fun e => τ e ω) ∂μ ↔
      Q.lR = (1 - Q.q.pc) * Q.q.lc) ∧
    ((∫⁻ ω, omegaC (fun e => τ e ω) ∂μ) < ∫⁻ ω, omegaAR (fun e => τ e ω) ∂μ ↔
      Q.lR < (1 - Q.q.pc) * Q.q.lc) := by
  obtain ⟨m1, m2⟩ := e5_means hQ hA h
  have hC := (e1_lambdaC_pos hQ.1 hA).2
  have hAR : 0 < Q.q.lamA + Q.lR := by linarith [hQ.2.2.2]
  have hsplit := lamC_split Q
  rw [m1, m2]
  refine ⟨?_, ?_, ?_⟩
  · rw [ENNReal.ofReal_le_ofReal_iff (by positivity), one_div_le_one_div hC hAR]
    constructor <;> intro h1 <;> linarith
  · rw [ENNReal.ofReal_eq_ofReal_iff (by positivity) (by positivity), one_div, one_div, inv_inj]
    constructor <;> intro h1 <;> linarith
  · rw [ENNReal.ofReal_lt_ofReal_iff (by positivity), one_div_lt_one_div hC hAR]
    constructor <;> intro h1 <;> linarith

/-- Line 1341: **positive `λ_R` gives a positive probability of reversal** under holding. -/
theorem b23_reversal_pos (hQ : Q.Admissible) (hA : 0 < Q.q.lamA) (h : FirstArrivals μ τ Q.rate)
    (hR : 0 < Q.lR) (B : Ω → Bool) :
    0 < μ {ω | WAR .hold (B ω) (omegaAR (fun e => τ e ω)) < WCR .hold (omegaC (fun e => τ e ω))} := by
  have hw : ∀ ω, WAR .hold (B ω) (omegaAR (fun e => τ e ω)) = omegaAR (fun e => τ e ω) ∧
      WCR .hold (omegaC (fun e => τ e ω)) = omegaC (fun e => τ e ω) := fun ω => by
    simp [WAR, WCR, attackDateR, commDateR]
  simp only [hw]
  rw [e5_prob_attack_first hQ hA h, ENNReal.ofReal_pos]
  exact div_pos hR (e5_total_pos hQ hA)

/-- Line 1341: under holding, `W_C^R ≤ W_A^R` almost surely exactly when `λ_R = 0`. -/
theorem b23_hold_order_iff (hQ : Q.Admissible) (hA : 0 < Q.q.lamA) (h : FirstArrivals μ τ Q.rate)
    (B : Ω → Bool) :
    (∀ᵐ ω ∂μ, WCR .hold (omegaC (fun e => τ e ω)) ≤ WAR .hold (B ω) (omegaAR (fun e => τ e ω)))
      ↔ Q.lR = 0 := by
  have hw : ∀ ω, WAR .hold (B ω) (omegaAR (fun e => τ e ω)) = omegaAR (fun e => τ e ω) ∧
      WCR .hold (omegaC (fun e => τ e ω)) = omegaC (fun e => τ e ω) := fun ω => by
    simp [WAR, WCR, attackDateR, commDateR]
  simp only [hw]
  exact e5_order_comm_first_iff hQ hA h

/-- **Corollary to E5, windows** (line 1430): immediate restricted-terms release gives
`W_A^R = 0` and `W_C^R = ω_C` on every path. -/
theorem e5c_windows (s : EvR → ℝ≥0∞) (b : Bool) :
    WAR .restrRel b (omegaAR s) = 0 ∧ WCR .restrRel (omegaC s) = omegaC s := by
  simp [WAR, WCR, attackDateR, commDateR]

/-- **Corollary to E5, `W_C^R = ω_C > 0` almost surely and `E[W_C^R] = 1/λ_C`.** -/
theorem e5c_commercial_window (hQ : Q.Admissible) (hA : 0 < Q.q.lamA)
    (h : FirstArrivals μ τ Q.rate) :
    (∀ᵐ ω ∂μ, 0 < WCR .restrRel (omegaC (fun e => τ e ω))) ∧
    ∫⁻ ω, WCR .restrRel (omegaC (fun e => τ e ω)) ∂μ = ENNReal.ofReal (1 / Q.q.lamC) := by
  have hS := measurable_pi_iff.mpr h.meas
  simp only [fun s => (e5c_windows s false).2]
  exact ⟨e1t_exp_ae_pos (measurable_omegaC.comp hS) (e5_laws h).1, (e5_means hQ hA h).1⟩

/-- **Corollary to E5, E1's realized-window ordering fails almost surely**: under immediate
restricted-terms release, `W_A^R < W_C^R` almost surely, for every safeguard indicator. -/
theorem e5c_order_fails (hQ : Q.Admissible) (hA : 0 < Q.q.lamA) (h : FirstArrivals μ τ Q.rate)
    (B : Ω → Bool) :
    ∀ᵐ ω ∂μ, WAR .restrRel (B ω) (omegaAR (fun e => τ e ω)) <
      WCR .restrRel (omegaC (fun e => τ e ω)) := by
  filter_upwards [(e5c_commercial_window hQ hA h).1] with ω hω
  rw [(e5c_windows _ (B ω)).1]; exact hω

/-- **Corollary to E5, exposure** (line 1432): at a common schedule, immediate restricted-terms
release has the same `X` and the same `X̃(Σ, 0, ω_full)` as immediate permissive weights-only
release; both supply weights without a package (`t_pkg = ω_full`); only the permissive action
supplies a commercial substitute (`W_C^R = 0` against `W_C^R = ω_C`). Pathwise. -/
theorem e5c_same_exposure [Fintype P] [Fintype U] (s : EvR → ℝ≥0∞) (b : Bool) (π : ℝ)
    (σ : Schedule P U) (fP : P → F) (fU : U → F) (Z : F → ℝ≥0∞) :
    exposure π σ (WAR .restrRel b (omegaAR s)).toReal =
      exposure π σ (WAR .wtRel b (omegaAR s)).toReal ∧
    pkgExposure π σ fP fU Z (WAR .restrRel b (omegaAR s)).toReal (tpkg .restrRel (omegaFull s)) =
      pkgExposure π σ fP fU Z 0 (omegaFull s) ∧
    pkgExposure π σ fP fU Z (WAR .wtRel b (omegaAR s)).toReal (tpkg .wtRel (omegaFull s)) =
      pkgExposure π σ fP fU Z 0 (omegaFull s) ∧
    tpkg .restrRel (omegaFull s) = omegaFull s ∧ tpkg .wtRel (omegaFull s) = omegaFull s ∧
    WCR .wtRel (omegaC s) = 0 ∧ WCR .restrRel (omegaC s) = omegaC s := by
  simp [WAR, WCR, attackDateR, commDateR, tpkg]

/-- Line 1341: **E1's laws and pathwise ordering survive in the enlarged system**: `ω_A` is
exponential with rate `λ_A` and `ω_C ≤ ω_A` on every path. -/
theorem b23_e1_survives (h : FirstArrivals μ τ Q.rate) :
    HasExpSurvival μ (fun ω => omegaA (fun e => τ e ω)) Q.q.lamA ∧
    ∀ s : EvR → ℝ≥0∞, omegaC s ≤ omegaA s := by
  refine ⟨?_, fun s => ?_⟩
  · rw [← sum_attackR0]; exact survival_inf h attackR0
  · rw [omegaC_classes]; exact min_le_right _ _

/-- Lines 1341–1345: **E3's chain survives for every action**: `W_A^R ≤ ω_A^R ≤ ω_A` pathwise,
hence `E[W_A^R] ≤ 1/λ_A`. -/
theorem b23_e3_survives (hA : 0 < Q.q.lamA) (h : FirstArrivals μ τ Q.rate) (a : ActR)
    (B : Ω → Bool) :
    (∀ s b, WAR a b (omegaAR s) ≤ omegaAR s ∧ omegaAR s ≤ omegaA s) ∧
    ∫⁻ ω, WAR a (B ω) (omegaAR (fun e => τ e ω)) ∂μ ≤ ENNReal.ofReal (1 / Q.q.lamA) := by
  have hchain : ∀ s b, WAR a b (omegaAR s) ≤ omegaAR s ∧ omegaAR s ≤ omegaA s :=
    fun s b => ⟨min_le_left _ _, min_le_left _ _⟩
  refine ⟨hchain, ?_⟩
  have hS := measurable_pi_iff.mpr h.meas
  rw [← (b23_e1_survives h).1.lintegral_eq (measurable_omegaA.comp hS) hA]
  exact lintegral_mono (fun ω => ((hchain _ _).1.trans (hchain _ (B ω)).2))

end E5

/-! ## 5. Proposition E6 -/

/-- `g = min{u, b}` with `b ∈ ℝ ∪ {+∞}` (line 1442). -/
noncomputable def gOf (u : ℝ) (b : EReal) : ℝ := if b = ⊤ then u else min u b.toReal

/-- `(g − Z)⁺` with `Z ∈ [0, ∞]` (`0` when `Z = ∞`), in `[0, ∞)`. -/
noncomputable def gapE (g : ℝ) (z : ℝ≥0∞) : ℝ≥0∞ :=
  if z = ⊤ then 0 else ENNReal.ofReal (g - z.toReal)

theorem e6_real_id (u b z w : ℝ) (hw : 0 ≤ w) :
    max (u - min b z) 0 - max (u - min b (w + z)) 0 = min w (max (min u b - z) 0) := by
  simp only [min_def, max_def]
  split_ifs <;> linarith

theorem e6_real_id_wtop (u b z : ℝ) :
    max (u - min b z) 0 - max (u - b) 0 = max (min u b - z) 0 := by
  simp only [min_def, max_def]
  split_ifs <;> linarith

theorem e6_real_id_btop (u z w : ℝ) (hw : 0 ≤ w) :
    max (u - z) 0 - max (u - (w + z)) 0 = min w (max (u - z) 0) := by
  simp only [min_def, max_def]
  split_ifs <;> linarith

theorem ereal_coe_ennreal (z : ℝ≥0∞) (hz : z ≠ ⊤) : (z : EReal) = ((z.toReal : ℝ) : EReal) := by
  conv_lhs => rw [← ENNReal.ofReal_toReal hz]
  rw [EReal.coe_ennreal_ofReal, max_eq_left (by exact_mod_cast ENNReal.toReal_nonneg)]

theorem ereal_min_coe (x y : ℝ) : min (x : EReal) (y : EReal) = ((min x y : ℝ) : EReal) :=
  (EReal.coe_strictMono.monotone.map_min).symm

/-- **E6, the unweighted difference** (line 1504–1506): for a finite terminal date `u`, a
baseline onset `b ∈ ℝ ∪ {+∞}`, an added wait `Z` and the package date `ω_full`,
`(u − min{b, Z})⁺ − (u − min{b, ω_full + Z})⁺ = min{ω_full, (g − Z)⁺}`, `g = min{u, b}`.
Negative dates and onsets are allowed. -/
theorem e6_term_identity (u : ℝ) {b : EReal} (hb : b ≠ ⊥) (z w : ℝ≥0∞) :
    ppart u (pkgOnset b 0 z) - ppart u (pkgOnset b w z) = (min w (gapE (gOf u b) z)).toReal := by
  rcases eq_or_ne z ⊤ with rfl | hz
  · simp [pkgOnset, gapE, EReal.coe_ennreal_top]
  have hz' := ereal_coe_ennreal z hz
  induction b using EReal.rec with
  | bot => exact absurd rfl hb
  | top =>
    rcases eq_or_ne w ⊤ with rfl | hw
    · simp [pkgOnset, gapE, gOf, hz, hz', EReal.coe_ennreal_top, ppart,
        ENNReal.toReal_ofReal']
    · have hwz : w + z ≠ ⊤ := ENNReal.add_ne_top.mpr ⟨hw, hz⟩
      have hwz' := ereal_coe_ennreal (w + z) hwz
      simp only [pkgOnset, zero_add, min_eq_right le_top, hz', hwz', ppart_coe,
        gapE, gOf, hz, ↓reduceIte]
      rw [ENNReal.toReal_min hw ENNReal.ofReal_ne_top, ENNReal.toReal_ofReal',
        ENNReal.toReal_add hw hz]
      exact e6_real_id_btop u z.toReal w.toReal ENNReal.toReal_nonneg
  | coe b' =>
    rcases eq_or_ne w ⊤ with rfl | hw
    · simp only [pkgOnset, zero_add, hz', top_add, EReal.coe_ennreal_top,
        min_eq_left le_top, ereal_min_coe, ppart_coe, gapE, gOf, hz, EReal.coe_ne_top,
        ↓reduceIte, EReal.toReal_coe]
      rw [min_eq_right le_top, ENNReal.toReal_ofReal']
      exact e6_real_id_wtop u b' z.toReal
    · have hwz : w + z ≠ ⊤ := ENNReal.add_ne_top.mpr ⟨hw, hz⟩
      have hwz' := ereal_coe_ennreal (w + z) hwz
      simp only [pkgOnset, zero_add, hz', hwz', ereal_min_coe, ppart_coe, gapE, gOf, hz,
        EReal.coe_ne_top, ↓reduceIte, EReal.toReal_coe]
      rw [ENNReal.toReal_min hw ENNReal.ofReal_ne_top, ENNReal.toReal_ofReal',
        ENNReal.toReal_add hw hz]
      exact e6_real_id u b' z.toReal w.toReal ENNReal.toReal_nonneg

/-- Each term's difference is nonnegative (immediate availability weakly advances the onset). -/
theorem e6_term_nonneg (u : ℝ) {b : EReal} (hb : b ≠ ⊥) (z w : ℝ≥0∞) :
    0 ≤ ppart u (pkgOnset b 0 z) - ppart u (pkgOnset b w z) := by
  rw [e6_term_identity u hb]; exact ENNReal.toReal_nonneg

/-- **E6, when a term's difference is positive** (line 1508): for `ω_full > 0`, exactly when
`Z < g`. -/
theorem e6_term_pos_iff (u : ℝ) {b : EReal} (hb : b ≠ ⊥) (z : ℝ≥0∞) {w : ℝ≥0∞} (hw : 0 < w) :
    0 < ppart u (pkgOnset b 0 z) - ppart u (pkgOnset b w z) ↔ z < ENNReal.ofReal (gOf u b) := by
  rw [e6_term_identity u hb, ENNReal.toReal_pos_iff, lt_min_iff]
  have hgap : gapE (gOf u b) z < ⊤ := by
    unfold gapE; split_ifs <;> simp
  have hlt : min w (gapE (gOf u b) z) < ⊤ := (min_le_right _ _).trans_lt hgap
  simp only [hlt, and_true, hw, true_and]
  unfold gapE
  split_ifs with hz
  · simp [hz]
  · rw [ENNReal.ofReal_pos, sub_pos]
    conv_rhs => rw [← ENNReal.ofReal_toReal hz]
    rw [ENNReal.ofReal_lt_ofReal_iff']
    constructor
    · intro h; exact ⟨h, lt_of_le_of_lt ENNReal.toReal_nonneg h⟩
    · exact fun h => h.1

variable {T : Type*} [Fintype T]

/-- **`X̃(Σ, 0, t)` as a sum of weighted terms** (line 1335–1337), indexed by a finite set `T` of
flaw–operator–cohort terms: fixed weights `k`, the flaw `fl` of each term, terminal dates `u`,
baseline onsets `b` (at `W = 0`), added waits `Z` per flaw and the package date `t`. -/
noncomputable def Xpkg (k : T → ℝ) (fl : T → F) (u : T → ℝ) (b : T → EReal) (Z : F → ℝ≥0∞)
    (t : ℝ≥0∞) : ℝ :=
  ∑ τ, k τ * ppart (u τ) (pkgOnset (b τ) t (Z (fl τ)))

theorem e6_diff_sum (k : T → ℝ) (fl : T → F) (u : T → ℝ) (b : T → EReal) (Z : F → ℝ≥0∞)
    (w : ℝ≥0∞) :
    Xpkg k fl u b Z 0 - Xpkg k fl u b Z w =
      ∑ τ, k τ * (ppart (u τ) (pkgOnset (b τ) 0 (Z (fl τ))) -
        ppart (u τ) (pkgOnset (b τ) w (Z (fl τ)))) := by
  simp only [Xpkg, ← Finset.sum_sub_distrib, mul_sub]

/-- **E6, pathwise** (line 1440): `X̃(Σ, 0, 0) ≥ X̃(Σ, 0, ω_full)` on every path, for nonnegative
weights and baseline onsets in `ℝ ∪ {+∞}`, whatever the package date `ω_full ∈ [0, ∞]`. -/
theorem e6_pathwise {k : T → ℝ} (hk : ∀ τ, 0 ≤ k τ) (fl : T → F) (u : T → ℝ) {b : T → EReal}
    (hb : ∀ τ, b τ ≠ ⊥) (Z : F → ℝ≥0∞) (w : ℝ≥0∞) :
    Xpkg k fl u b Z w ≤ Xpkg k fl u b Z 0 := by
  rw [← sub_nonneg, e6_diff_sum]
  exact Finset.sum_nonneg (fun τ _ => mul_nonneg (hk τ) (e6_term_nonneg _ (hb τ) _ _))

theorem measurable_ppart : Measurable (fun p : ℝ × EReal => ppart p.1 p.2) := by
  unfold ppart
  refine Measurable.ite (measurable_snd (measurableSet_singleton ⊤)) measurable_const ?_
  exact (measurable_fst.sub (measurable_ereal_toReal.comp measurable_snd)).max measurable_const

theorem measurable_pkgOnset :
    Measurable (fun p : EReal × ℝ≥0∞ × ℝ≥0∞ => pkgOnset p.1 p.2.1 p.2.2) := by
  unfold pkgOnset
  exact measurable_fst.min (measurable_coe_ennreal_ereal.comp
    ((measurable_fst.comp measurable_snd).add (measurable_snd.comp measurable_snd)))

theorem measurable_gOf : Measurable (fun p : ℝ × EReal => gOf p.1 p.2) := by
  unfold gOf
  exact Measurable.ite (measurable_snd (measurableSet_singleton ⊤)) measurable_fst
    (measurable_fst.min (measurable_ereal_toReal.comp measurable_snd))

/-- **The added wait falls before `g` with positive probability exactly when the route is
active and `g > 0` has positive probability** (line 1508–1512). `Z` is exponential with rate
`η > 0`, or `∞` when `η = 0` (B-S9), and independent of `g` (implied by B-S9's independence of
`Z_f` from the full baseline schedule). -/
theorem e6_wait_before_pos {Z : Ω → ℝ≥0∞} (hZ : Measurable Z) {g : Ω → ℝ} (hg : Measurable g)
    {η : ℝ} (hη : 0 ≤ η) (hlaw : 0 < η → HasExpSurvival μ Z η) (htop : η = 0 → ∀ ω, Z ω = ⊤)
    (hind : IndepFun Z g μ) :
    0 < μ {ω | Z ω < ENNReal.ofReal (g ω)} ↔ 0 < η ∧ 0 < μ {ω | 0 < g ω} := by
  constructor
  · intro hpos
    refine ⟨?_, ?_⟩
    · rcases hη.lt_or_eq with h | h
      · exact h
      · have : {ω | Z ω < ENNReal.ofReal (g ω)} = ∅ := by
          ext ω; simp [htop h.symm ω]
        rw [this, measure_empty] at hpos; exact absurd hpos (lt_irrefl _)
    · refine lt_of_lt_of_le hpos (measure_mono (fun ω hω => ?_))
      simp only [mem_ofPred_eq] at hω ⊢
      by_contra hle
      push Not at hle
      rw [ENNReal.ofReal_of_nonpos hle] at hω
      exact absurd hω (not_lt.mpr zero_le)
  · rintro ⟨hηpos, hgpos⟩
    have hU : {ω | 0 < g ω} = ⋃ n : ℕ, {ω | 1 / ((n : ℝ) + 1) < g ω} := by
      ext ω
      simp only [mem_ofPred_eq, mem_iUnion]
      constructor
      · intro h
        obtain ⟨n, hn⟩ := exists_nat_one_div_lt h
        exact ⟨n, hn⟩
      · rintro ⟨n, hn⟩
        exact lt_trans (by positivity) hn
    have : ∃ n : ℕ, 0 < μ {ω | 1 / ((n : ℝ) + 1) < g ω} := by
      by_contra hall
      push Not at hall
      have h0 : μ {ω | 0 < g ω} = 0 := by
        rw [hU]; exact measure_iUnion_null (fun n => le_antisymm (hall n) zero_le)
      rw [h0] at hgpos; exact absurd hgpos (lt_irrefl _)
    obtain ⟨n, hn⟩ := this
    set c : ℝ := 1 / ((n : ℝ) + 1) with hc
    have hcpos : 0 < c := by positivity
    have hsub : Z ⁻¹' Iic (ENNReal.ofReal (c / 2)) ∩ g ⁻¹' Ioi c ⊆
        {ω | Z ω < ENNReal.ofReal (g ω)} := by
      intro ω ⟨h1, h2⟩
      simp only [mem_preimage, mem_Iic, mem_Ioi] at h1 h2
      simp only [mem_ofPred_eq]
      refine lt_of_le_of_lt h1 ?_
      rw [ENNReal.ofReal_lt_ofReal_iff (by linarith)]
      linarith
    have hprod := hind.measure_inter_preimage_eq_mul (Iic (ENNReal.ofReal (c / 2))) (Ioi c)
      measurableSet_Iic measurableSet_Ioi
    refine lt_of_lt_of_le ?_ (measure_mono hsub)
    rw [hprod]
    have hA : 0 < μ (Z ⁻¹' Iic (ENNReal.ofReal (c / 2))) := by
      have hc2 : Z ⁻¹' Iic (ENNReal.ofReal (c / 2)) = {ω | ENNReal.ofReal (c / 2) < Z ω}ᶜ := by
        ext ω; simp
      rw [hc2, prob_compl_eq_one_sub (measurableSet_lt measurable_const hZ),
        hlaw hηpos (c / 2) (by linarith), tsub_pos_iff_lt, ← ENNReal.ofReal_one,
        ENNReal.ofReal_lt_ofReal_iff one_pos]
      have : -(η * (c / 2)) < 0 := by
        have := mul_pos hηpos (half_pos hcpos); linarith
      calc Real.exp (-(η * (c / 2))) < Real.exp 0 := Real.exp_lt_exp.mpr this
        _ = 1 := Real.exp_zero
    exact ENNReal.mul_pos hA.ne' hn.ne'

/-- **E6, strictness** (line 1442): with nonnegative fixed weights, baseline onsets in
`ℝ ∪ {+∞}`, B-S9's waits (exponential with rate `η_f > 0`, `∞` when `η_f = 0`), each wait
independent of its term's `g = min{u, b}`, a package date `ω_full > 0` almost surely, and
integrable exposures, `E[X̃(Σ, 0, ω_full)] < E[X̃(Σ, 0, 0)]` holds if and only if some term has
`k > 0`, `η_f > 0` and `P(g > 0) > 0`. No independence of `ω_full` from anything is used. -/
theorem e6_strict_iff {k : T → ℝ} (hk : ∀ τ, 0 ≤ k τ) {fl : T → F} {u : Ω → T → ℝ}
    {b : Ω → T → EReal} (hb : ∀ ω τ, b ω τ ≠ ⊥) (hu : ∀ τ, Measurable fun ω => u ω τ)
    (hbm : ∀ τ, Measurable fun ω => b ω τ) {Z : F → Ω → ℝ≥0∞} (hZ : ∀ f, Measurable (Z f))
    {η : F → ℝ} (hη : ∀ f, 0 ≤ η f) (hZlaw : ∀ f, 0 < η f → HasExpSurvival μ (Z f) (η f))
    (hZtop : ∀ f, η f = 0 → ∀ ω, Z f ω = ⊤)
    (hind : ∀ τ, IndepFun (Z (fl τ)) (fun ω => gOf (u ω τ) (b ω τ)) μ)
    {wf : Ω → ℝ≥0∞} (hwf : Measurable wf) (hwpos : ∀ᵐ ω ∂μ, 0 < wf ω)
    (hI0 : Integrable (fun ω => Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0) μ)
    (hI1 : Integrable (fun ω => Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω)) μ) :
    ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω) ∂μ <
        ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0 ∂μ ↔
      ∃ τ, 0 < k τ ∧ 0 < η (fl τ) ∧ 0 < μ {ω | 0 < gOf (u ω τ) (b ω τ)} := by
  -- the per-term differences
  set D : T → Ω → ℝ := fun τ ω => ppart (u ω τ) (pkgOnset (b ω τ) 0 (Z (fl τ) ω)) -
    ppart (u ω τ) (pkgOnset (b ω τ) (wf ω) (Z (fl τ) ω)) with hD
  have hDnn : ∀ τ ω, 0 ≤ D τ ω := fun τ ω => e6_term_nonneg _ (hb ω τ) _ _
  have hDm : ∀ τ, Measurable (D τ) := by
    intro τ
    have h0 : Measurable fun ω => pkgOnset (b ω τ) 0 (Z (fl τ) ω) :=
      measurable_pkgOnset.comp ((hbm τ).prodMk (measurable_const.prodMk (hZ (fl τ))))
    have h1 : Measurable fun ω => pkgOnset (b ω τ) (wf ω) (Z (fl τ) ω) :=
      measurable_pkgOnset.comp ((hbm τ).prodMk (hwf.prodMk (hZ (fl τ))))
    exact (measurable_ppart.comp ((hu τ).prodMk h0)).sub
      (measurable_ppart.comp ((hu τ).prodMk h1))
  have hsum : ∀ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0 -
      Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω) = ∑ τ, k τ * D τ ω := fun ω =>
    e6_diff_sum _ _ _ _ _ _
  have hIdiff := hI0.sub hI1
  have hIterm : ∀ τ, Integrable (fun ω => k τ * D τ ω) μ := by
    intro τ
    refine Integrable.mono' hIdiff ((measurable_const.mul (hDm τ)).aestronglyMeasurable) ?_
    refine Filter.Eventually.of_forall (fun ω => ?_)
    rw [Real.norm_eq_abs, abs_of_nonneg (mul_nonneg (hk τ) (hDnn τ ω))]
    change k τ * D τ ω ≤ Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0 -
      Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω)
    rw [hsum ω]
    exact Finset.single_le_sum (f := fun τ => k τ * D τ ω)
      (fun τ _ => mul_nonneg (hk τ) (hDnn τ ω)) (Finset.mem_univ τ)
  have hint : ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0 ∂μ -
      ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω) ∂μ = ∑ τ, ∫ ω, k τ * D τ ω ∂μ := by
    rw [← integral_sub hI0 hI1, ← integral_finsetSum _ (fun τ _ => hIterm τ)]
    exact integral_congr_ae (Filter.Eventually.of_forall hsum)
  rw [← sub_pos, hint, Finset.sum_pos_iff_of_nonneg
    (fun τ _ => integral_nonneg (fun ω => mul_nonneg (hk τ) (hDnn τ ω)))]
  simp only [Finset.mem_univ, true_and]
  apply exists_congr
  intro τ
  -- one term
  have hsupp : μ (Function.support (D τ)) = μ {ω | Z (fl τ) ω < ENNReal.ofReal (gOf (u ω τ) (b ω τ))} := by
    refine measure_congr ?_
    filter_upwards [hwpos] with ω hω
    change (D τ ω ≠ 0) = (Z (fl τ) ω < ENNReal.ofReal (gOf (u ω τ) (b ω τ)))
    rw [← e6_term_pos_iff _ (hb ω τ) _ hω, eq_iff_iff]
    exact ⟨fun h => lt_of_le_of_ne (hDnn τ ω) (Ne.symm h), fun h => h.ne'⟩
  have hgm : Measurable fun ω => gOf (u ω τ) (b ω τ) := measurable_gOf.comp ((hu τ).prodMk (hbm τ))
  have hwait := e6_wait_before_pos (hZ (fl τ)) hgm (hη (fl τ)) (hZlaw (fl τ)) (hZtop (fl τ))
    (hind τ)
  rcases (hk τ).lt_or_eq with hkp | hk0
  · rw [integral_const_mul, mul_pos_iff_of_pos_left hkp]
    have hDint : Integrable (D τ) μ := by
      have := (hIterm τ).const_mul (1 / k τ)
      refine this.congr (Filter.Eventually.of_forall (fun ω => ?_))
      field_simp
    rw [integral_pos_iff_support_of_nonneg (fun ω => hDnn τ ω) hDint, hsupp, hwait]
    simp [hkp]
  · rw [← hk0]
    simp

/-- **E6, the expected weak inequality** (line 1440 in expectation). -/
theorem e6_expected_weak {k : T → ℝ} (hk : ∀ τ, 0 ≤ k τ) {fl : T → F} {u : Ω → T → ℝ}
    {b : Ω → T → EReal} (hb : ∀ ω τ, b ω τ ≠ ⊥) {Z : F → Ω → ℝ≥0∞} {wf : Ω → ℝ≥0∞}
    (hI0 : Integrable (fun ω => Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0) μ)
    (hI1 : Integrable (fun ω => Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω)) μ) :
    ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω) ∂μ ≤
      ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0 ∂μ :=
  integral_mono hI1 hI0 (fun ω => e6_pathwise hk fl (u ω) (hb ω) _ (wf ω))

/-- **E6, the defensive threshold** (lines 1444–1454). For possibly different baseline schedules
`Σ_wt` and `Σ_full` (terms `(k, u, b)` and `(k', u', b')`) with integrable exposures,
`E[X̃(Σ_full, 0, 0)] − E[X̃(Σ_wt, 0, ω_full)] = Δ_disc − Δ_def`, `Δ_disc ≥ 0`, and full release
lowers expected exposure exactly when `Δ_def > Δ_disc`. No joint independence of the two
schedules is used; the content is an accounting identity. -/
theorem e6_threshold {k k' : T → ℝ} (hk : ∀ τ, 0 ≤ k τ) {fl : T → F} {u u' : Ω → T → ℝ}
    {b b' : Ω → T → EReal} (hb : ∀ ω τ, b ω τ ≠ ⊥) {Z : F → Ω → ℝ≥0∞} {wf : Ω → ℝ≥0∞}
    (hI0 : Integrable (fun ω => Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0) μ)
    (hI1 : Integrable (fun ω => Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω)) μ)
    (hIf : Integrable (fun ω => Xpkg k' fl (u' ω) (b' ω) (fun f => Z f ω) 0) μ) :
    let Δdisc := ∫ ω, (Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0 -
      Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω)) ∂μ
    let Δdef := ∫ ω, (Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0 -
      Xpkg k' fl (u' ω) (b' ω) (fun f => Z f ω) 0) ∂μ
    (∫ ω, Xpkg k' fl (u' ω) (b' ω) (fun f => Z f ω) 0 ∂μ -
        ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω) ∂μ = Δdisc - Δdef) ∧
    0 ≤ Δdisc ∧
    (∫ ω, Xpkg k' fl (u' ω) (b' ω) (fun f => Z f ω) 0 ∂μ <
        ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω) ∂μ ↔ Δdisc < Δdef) := by
  intro Δdisc Δdef
  have e1 : Δdisc = ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0 ∂μ -
      ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω) ∂μ := integral_sub hI0 hI1
  have e2 : Δdef = ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) 0 ∂μ -
      ∫ ω, Xpkg k' fl (u' ω) (b' ω) (fun f => Z f ω) 0 ∂μ := integral_sub hI0 hIf
  have hid : ∫ ω, Xpkg k' fl (u' ω) (b' ω) (fun f => Z f ω) 0 ∂μ -
      ∫ ω, Xpkg k fl (u ω) (b ω) (fun f => Z f ω) (wf ω) ∂μ = Δdisc - Δdef := by
    rw [e1, e2]; ring
  refine ⟨hid, ?_, ?_⟩
  · rw [e1, sub_nonneg]; exact e6_expected_weak hk hb hI0 hI1
  · rw [← sub_neg, hid, sub_neg]

/-! ### E6 on the paper's `X̃` (the schedule of Appendix B.2.2) -/

/-- Cohort weights `k_{fji}`: the original weight times `1 − π` (`ex`, `true`) or `π` (`par`). -/
def kOfW (π : ℝ) (w : P → ℝ) (uw : U → ℝ) : (P ⊕ U) × Bool → ℝ
  | (.inl i, true) => w i * (1 - π)
  | (.inl i, false) => w i * π
  | (.inr k, true) => uw k * (1 - π)
  | (.inr k, false) => uw k * π

/-- Terminal dates `u_fj`: `P_f + τ_fj` (patched) or `ζ_j` (unfound). -/
def uOf (σ : Schedule P U) : (P ⊕ U) × Bool → ℝ
  | (.inl i, _) => σ.pub i + σ.dep i
  | (.inr k, _) => σ.rem k

/-- Baseline onsets `b_{fi}(Σ, W)` (table at lines 1328–1333). -/
noncomputable def bOf (σ : Schedule P U) (W : ℝ) : (P ⊕ U) × Bool → EReal
  | (.inl i, true) => ((min (σ.pub i + σ.lag) (W + σ.disc i) : ℝ) : EReal)
  | (.inl i, false) => ((min (σ.pub i + σ.lag) (σ.discPi i) : ℝ) : EReal)
  | (.inr k, true) => ((W + σ.udisc k : ℝ) : EReal)
  | (.inr k, false) => ((σ.udiscPi k : ℝ) : EReal)

def flOf (fP : P → F) (fU : U → F) : (P ⊕ U) × Bool → F
  | (.inl i, _) => fP i
  | (.inr k, _) => fU k

/-- The paper's `X̃(Σ, W, t)` is the weighted-term sum `Xpkg` over flaw–operator–cohort terms. -/
theorem pkgExposure_eq_Xpkg [Fintype P] [Fintype U] (π : ℝ) (σ : Schedule P U) (fP : P → F)
    (fU : U → F) (Z : F → ℝ≥0∞) (W : ℝ) (t : ℝ≥0∞) :
    pkgExposure π σ fP fU Z W t =
      Xpkg (kOfW π σ.w σ.uw) (flOf fP fU) (uOf σ) (bOf σ W) Z t := by
  simp only [Xpkg, Fintype.sum_prod_type, Fintype.sum_sum_type, Fintype.sum_bool, kOfW, uOf,
    bOf, flOf, pkgExposure]
  congr 1 <;> apply Finset.sum_congr rfl <;> intro x _ <;> ring

theorem kOfW_nonneg {π : ℝ} (h0 : 0 ≤ π) (h1 : π ≤ 1) {σ : Schedule P U} (hσ : σ.Admissible)
    (x : (P ⊕ U) × Bool) : 0 ≤ kOfW π σ.w σ.uw x := by
  rcases x with ⟨i | k, _ | _⟩ <;> simp only [kOfW]
  all_goals first
    | exact mul_nonneg (hσ.1 _) (by linarith)
    | exact mul_nonneg (hσ.2 _) (by linarith)

theorem bOf_ne_bot (σ : Schedule P U) (W : ℝ) (x : (P ⊕ U) × Bool) : bOf σ W x ≠ ⊥ := by
  rcases x with ⟨i | k, _ | _⟩ <;> simp [bOf]

/-- **E6, pathwise, for the paper's `X̃`** (line 1440): `X̃(Σ, 0, 0) ≥ X̃(Σ, 0, ω_full)` for every
admissible schedule (nonnegative weights), `π ∈ [0, 1]`, every added-wait vector and every
`ω_full ∈ [0, ∞]`. -/
theorem e6_pathwise_concrete [Fintype P] [Fintype U] {π : ℝ} (h0 : 0 ≤ π) (h1 : π ≤ 1)
    {σ : Schedule P U} (hσ : σ.Admissible) (fP : P → F) (fU : U → F) (Z : F → ℝ≥0∞)
    (ωfull : ℝ≥0∞) :
    pkgExposure π σ fP fU Z 0 ωfull ≤ pkgExposure π σ fP fU Z 0 0 := by
  rw [pkgExposure_eq_Xpkg, pkgExposure_eq_Xpkg]
  exact e6_pathwise (kOfW_nonneg h0 h1 hσ) _ _ (bOf_ne_bot σ 0) Z ωfull

/-- `ω_full ∈ [0, ∞]` surely (its type) and `ω_full > 0` almost surely (line 1438), from the
first-arrival law: `O^full` is exponential with rate `p_full λ_o` (never arriving if zero). -/
theorem e6_omegaFull_pos {τ : EvR → Ω → ℝ≥0∞} {Q : RatesR} (h : FirstArrivals μ τ Q.rate) :
    ∀ᵐ ω ∂μ, 0 < omegaFull (fun e => τ e ω) :=
  e1t_exp_ae_pos (h.meas .Ofull) (h.law .Ofull)

/-- **E6, strictness, for the paper's `X̃`** (line 1442). The baseline schedule is random
(`σ : Ω → Schedule`) with fixed weights (B-S10), the package date is `ω_full` of the enlarged
system, and each flaw's wait is B-S9's (exponential with rate `η_f`, `∞` if `η_f = 0`) and
independent of each of that flaw's terms' `g_{fji} = min{u_fj, b_fi(Σ, 0)}`. Then the expected
inequality is strict iff some term has `k_{fji} > 0`, `η_f > 0` and `P(g_{fji} > 0) > 0`. -/
theorem e6_strict_iff_concrete [Fintype P] [Fintype U] {π : ℝ} (h0 : 0 ≤ π) (h1 : π ≤ 1)
    {σ : Ω → Schedule P U} (hσm : Measurable σ) {w0 : P → ℝ} {uw0 : U → ℝ}
    (hw : ∀ ω, (σ ω).w = w0 ∧ (σ ω).uw = uw0) (hσ : ∀ ω, (σ ω).Admissible)
    (fP : P → F) (fU : U → F) {Z : F → Ω → ℝ≥0∞} (hZ : ∀ f, Measurable (Z f))
    {η : F → ℝ} (hη : ∀ f, 0 ≤ η f) (hZlaw : ∀ f, 0 < η f → HasExpSurvival μ (Z f) (η f))
    (hZtop : ∀ f, η f = 0 → ∀ ω, Z f ω = ⊤)
    (hind : ∀ x, IndepFun (Z (flOf fP fU x)) (fun ω => gOf (uOf (σ ω) x) (bOf (σ ω) 0 x)) μ)
    {τ : EvR → Ω → ℝ≥0∞} {Q : RatesR} (hFA : FirstArrivals μ τ Q.rate)
    (hI0 : Integrable (fun ω => pkgExposure π (σ ω) fP fU (fun f => Z f ω) 0 0) μ)
    (hI1 : Integrable (fun ω => pkgExposure π (σ ω) fP fU (fun f => Z f ω) 0
      (omegaFull (fun e => τ e ω))) μ) :
    ∫ ω, pkgExposure π (σ ω) fP fU (fun f => Z f ω) 0 (omegaFull (fun e => τ e ω)) ∂μ <
        ∫ ω, pkgExposure π (σ ω) fP fU (fun f => Z f ω) 0 0 ∂μ ↔
      ∃ x, 0 < kOfW π w0 uw0 x ∧ 0 < η (flOf fP fU x) ∧
        0 < μ {ω | 0 < gOf (uOf (σ ω) x) (bOf (σ ω) 0 x)} := by
  have hrep : ∀ ω t, pkgExposure π (σ ω) fP fU (fun f => Z f ω) 0 t =
      Xpkg (kOfW π w0 uw0) (flOf fP fU) (uOf (σ ω)) (bOf (σ ω) 0) (fun f => Z f ω) t := by
    intro ω t; rw [pkgExposure_eq_Xpkg, (hw ω).1, (hw ω).2]
  simp only [hrep] at hI0 hI1 ⊢
  have hk : ∀ x, 0 ≤ kOfW π w0 uw0 x := by
    intro x
    obtain ⟨ω0⟩ : Nonempty Ω := by
      by_contra hne
      rw [not_nonempty_iff] at hne
      have := measure_univ (μ := μ)
      rw [Set.univ_eq_empty_iff.mpr hne, measure_empty] at this
      exact zero_ne_one this
    have := kOfW_nonneg h0 h1 (hσ ω0) x
    rwa [(hw ω0).1, (hw ω0).2] at this
  have hu : ∀ x, Measurable fun ω => uOf (σ ω) x := by
    rintro ⟨i | k, _⟩ <;> simp only [uOf]
    · exact ((measurable_pi_apply i).comp ((measurable_pub P U).comp hσm)).add
        ((measurable_pi_apply i).comp ((measurable_dep P U).comp hσm))
    · exact (measurable_pi_apply k).comp ((measurable_rem P U).comp hσm)
  have hb : ∀ x, Measurable fun ω => bOf (σ ω) 0 x := by
    rintro ⟨i | k, _ | _⟩ <;> simp only [bOf] <;> refine measurable_coe_real_ereal.comp ?_
    · exact (((measurable_pi_apply i).comp ((measurable_pub P U).comp hσm)).add
        ((measurable_lag P U).comp hσm)).min
        ((measurable_pi_apply i).comp ((measurable_discPi P U).comp hσm))
    · exact (((measurable_pi_apply i).comp ((measurable_pub P U).comp hσm)).add
        ((measurable_lag P U).comp hσm)).min
        (measurable_const.add ((measurable_pi_apply i).comp ((measurable_disc P U).comp hσm)))
    · exact (measurable_pi_apply k).comp ((measurable_udiscPi P U).comp hσm)
    · exact measurable_const.add ((measurable_pi_apply k).comp ((measurable_udisc P U).comp hσm))
  exact e6_strict_iff hk (fun ω => bOf_ne_bot (σ ω) 0) hu hb hZ hη hZlaw hZtop hind
    ((hFA.meas .Ofull)) (e6_omegaFull_pos hFA) hI0 hI1

/-- E4 (line 1412): **the equivalence does not extend to `X̃` once package discovery is active**.
A single positively weighted term with a finite wait gives `X̃(Σ, 0, 0) ≠ X̃(Σ, 0, ω_full)`. -/
theorem e4_Xtilde_can_differ :
    Xpkg (T := Unit) (fun _ => (1 : ℝ)) (fun _ => ()) (fun _ => 1) (fun _ => ⊤) (fun _ => 0) 0 ≠
      Xpkg (T := Unit) (fun _ => (1 : ℝ)) (fun _ => ()) (fun _ => 1) (fun _ => ⊤) (fun _ => 0) 1 := by
  have h := e6_term_identity (1 : ℝ) (b := ⊤) (by simp) 0 1
  simp only [gapE, gOf, ENNReal.zero_ne_top, ↓reduceIte, ENNReal.toReal_zero, sub_zero,
    ENNReal.ofReal_one, min_self, ENNReal.toReal_one] at h
  simp only [Xpkg, Finset.univ_unique, Finset.sum_singleton, one_mul]
  intro heq
  rw [heq, sub_self] at h
  exact zero_ne_one h

/-! ### The added wait given the baseline: `P(Z_f < g | g) = 1 − e^{−η_f g⁺}` (line 1510) -/

/-- An exponential time puts no mass at any finite level: `P(Z ≥ x) = e^{−η x⁺}` for real `x`. -/
theorem e6_exp_ge {Z : Ω → ℝ≥0∞} (hZ : Measurable Z) {η : ℝ} (hlaw : HasExpSurvival μ Z η)
    (x : ℝ) : μ {ω | ENNReal.ofReal x ≤ Z ω} = ENNReal.ofReal (Real.exp (-(η * max x 0))) := by
  set x' := max x 0 with hx'
  have hofr : ENNReal.ofReal x = ENNReal.ofReal x' := by
    rw [hx']; rcases le_total x 0 with h | h
    · rw [max_eq_right h, ENNReal.ofReal_of_nonpos h, ENNReal.ofReal_zero]
    · rw [max_eq_left h]
  rw [hofr]
  have hx0 : 0 ≤ x' := le_max_right _ _
  rcases hx0.lt_or_eq with hxp | hx00
  · -- levels increasing to `x'` from below
    set tn : ℕ → ℝ := fun n => x' - x' / ((n : ℝ) + 2) with htn
    have htn_lt : ∀ n, tn n < x' := fun n => by
      simp only [htn]; have : 0 < x' / ((n : ℝ) + 2) := by positivity
      linarith
    have htn_nn : ∀ n, 0 ≤ tn n := fun n => by
      simp only [htn]
      have : x' / ((n : ℝ) + 2) ≤ x' := div_le_self hx0 (by linarith [n.cast_nonneg (α := ℝ)])
      linarith
    have htn_mono : Monotone tn := by
      intro m n hmn
      simp only [htn]
      have hm : (0 : ℝ) < (m : ℝ) + 2 := by positivity
      have : x' / ((n : ℝ) + 2) ≤ x' / ((m : ℝ) + 2) :=
        div_le_div_of_nonneg_left hx0 hm (by exact_mod_cast (by omega : m + 2 ≤ n + 2))
      linarith
    have hset : {ω | ENNReal.ofReal x' ≤ Z ω} = ⋂ n, {ω | ENNReal.ofReal (tn n) < Z ω} := by
      ext ω
      simp only [mem_ofPred_eq, mem_iInter]
      constructor
      · intro h n
        exact lt_of_lt_of_le ((ENNReal.ofReal_lt_ofReal_iff hxp).mpr (htn_lt n)) h
      · intro h
        by_contra hlt
        push Not at hlt
        have hfin : Z ω ≠ ⊤ := ne_top_of_lt hlt
        have hzr : (Z ω).toReal < x' := by
          rwa [← ENNReal.ofReal_lt_ofReal_iff hxp, ENNReal.ofReal_toReal hfin]
        obtain ⟨n, hn⟩ := exists_nat_gt (x' / (x' - (Z ω).toReal))
        have hgap : 0 < x' - (Z ω).toReal := by linarith
        have hdiv : x' / ((n : ℝ) + 2) < x' - (Z ω).toReal := by
          rw [div_lt_iff₀ (by positivity)]
          rw [div_lt_iff₀ hgap] at hn
          nlinarith
        have : (Z ω).toReal < tn n := by simp only [htn]; linarith
        have h2 := h n
        rw [← ENNReal.ofReal_toReal hfin, ENNReal.ofReal_lt_ofReal_iff'] at h2
        linarith [h2.1]
    rw [hset]
    have hanti : Antitone (fun n => {ω | ENNReal.ofReal (tn n) < Z ω}) := by
      intro m n hmn ω hω
      exact lt_of_le_of_lt (ENNReal.ofReal_le_ofReal (htn_mono hmn)) hω
    have hlim := tendsto_measure_iInter_atTop (μ := μ)
      (fun n => (measurableSet_lt measurable_const hZ).nullMeasurableSet) hanti
      ⟨0, measure_ne_top _ _⟩
    have hvals : (fun n => μ {ω | ENNReal.ofReal (tn n) < Z ω}) =
        fun n => ENNReal.ofReal (Real.exp (-(η * tn n))) := funext fun n => hlaw _ (htn_nn n)
    have hlim' : Filter.Tendsto (fun n => ENNReal.ofReal (Real.exp (-(η * tn n)))) Filter.atTop
        (nhds (μ (⋂ n, {ω | ENNReal.ofReal (tn n) < Z ω}))) := by
      rw [← hvals]; exact hlim
    have htend : Filter.Tendsto tn Filter.atTop (nhds x') := by
      have h1 : Filter.Tendsto (fun n : ℕ => x' / ((n : ℝ) + 2)) Filter.atTop (nhds 0) := by
        have := tendsto_const_div_atTop_nhds_zero_nat x'
        have h2 : Filter.Tendsto (fun n : ℕ => (n : ℝ) + 2) Filter.atTop Filter.atTop :=
          Filter.tendsto_atTop_add_const_right _ _ tendsto_natCast_atTop_atTop
        exact (tendsto_const_nhds.div_atTop h2)
      simpa using (tendsto_const_nhds (x := x')).sub h1
    have hcont : Filter.Tendsto (fun n => ENNReal.ofReal (Real.exp (-(η * tn n)))) Filter.atTop
        (nhds (ENNReal.ofReal (Real.exp (-(η * x'))))) :=
      (ENNReal.continuous_ofReal.tendsto _).comp
        ((Real.continuous_exp.tendsto _).comp ((htend.const_mul η).neg))
    exact tendsto_nhds_unique hlim' hcont
  · rw [← hx00]
    simp only [ENNReal.ofReal_zero, zero_le, ofPred_true, measure_univ, mul_zero, neg_zero,
      Real.exp_zero, ENNReal.ofReal_one]

/-- **`P(Z_f < g | g) = 1 − e^{−η_f g⁺}`** (line 1510), as the defining identity of the
conditional probability given `g`: for every Borel set `S` of values of `g`,
`P(Z < g, g ∈ S) = E[(1 − e^{−η g⁺}) ; g ∈ S]`. Uses only that `Z` is exponential (rate `η`)
and independent of `g`. -/
theorem e6_conditional_wait {Z : Ω → ℝ≥0∞} (hZ : Measurable Z) {g : Ω → ℝ} (hg : Measurable g)
    {η : ℝ} (hlaw : HasExpSurvival μ Z η) (hind : IndepFun Z g μ) {S : Set ℝ}
    (hS : MeasurableSet S) :
    μ {ω | Z ω < ENNReal.ofReal (g ω) ∧ g ω ∈ S} =
      ∫⁻ ω in g ⁻¹' S, ENNReal.ofReal (1 - Real.exp (-(η * max (g ω) 0))) ∂μ := by
  have hpt : ∀ x : ℝ, μ {ω | Z ω < ENNReal.ofReal x} =
      ENNReal.ofReal (1 - Real.exp (-(η * max x 0))) := by
    intro x
    have hc : {ω | Z ω < ENNReal.ofReal x} = {ω | ENNReal.ofReal x ≤ Z ω}ᶜ := by ext ω; simp
    rw [hc, prob_compl_eq_one_sub (measurableSet_le measurable_const hZ), e6_exp_ge hZ hlaw x,
      ← ENNReal.ofReal_one, ← ENNReal.ofReal_sub _ (Real.exp_pos _).le]
  set S' : Set (ℝ × ℝ≥0∞) := {p | p.2 < ENNReal.ofReal p.1 ∧ p.1 ∈ S} with hS'
  have hmS' : MeasurableSet S' :=
    (measurableSet_lt measurable_snd (ENNReal.measurable_ofReal.comp measurable_fst)).inter
      (measurable_fst hS)
  calc μ {ω | Z ω < ENNReal.ofReal (g ω) ∧ g ω ∈ S}
      = μ ((fun ω => (g ω, Z ω)) ⁻¹' S') := rfl
    _ = (μ.map (fun ω => (g ω, Z ω))) S' := (Measure.map_apply (hg.prodMk hZ) hmS').symm
    _ = ((μ.map g).prod (μ.map Z)) S' := by
        rw [(indepFun_iff_map_prod_eq_prod_map_map hg.aemeasurable hZ.aemeasurable).mp hind.symm]
    _ = ∫⁻ x, (μ.map Z) (Prod.mk x ⁻¹' S') ∂(μ.map g) := Measure.prod_apply hmS'
    _ = ∫⁻ ω, (μ.map Z) (Prod.mk (g ω) ⁻¹' S') ∂μ :=
        lintegral_map (measurable_measure_prodMk_left hmS') hg
    _ = ∫⁻ ω, (g ⁻¹' S).indicator (fun ω => ENNReal.ofReal (1 - Real.exp (-(η * max (g ω) 0)))) ω ∂μ := by
        congr 1; funext ω
        rw [Measure.map_apply hZ (measurable_prodMk_left hmS')]
        by_cases hgS : g ω ∈ S
        · rw [Set.indicator_of_mem (show ω ∈ g ⁻¹' S from hgS), ← hpt]
          congr 1; ext ω'; simp [hS', hgS]
        · rw [Set.indicator_of_notMem (show ω ∉ g ⁻¹' S from hgS)]
          have : Z ⁻¹' (Prod.mk (g ω) ⁻¹' S') = ∅ := by ext ω'; simp [hS', hgS]
          rw [this, measure_empty]
    _ = _ := lintegral_indicator (hg hS) _

/-- **E4, realized windows' laws with a random safeguard outcome.** If `B_h` is independent of
the primitive streams in both systems and has the same failure probability `p_h`, the joint law
of `(W_C^R, W_A^R)` under every action (including closed release, where it depends on `B_h`)
depends on the marked open stream only through `λ_o`. -/
theorem e4_realized_window_law_random {τ : EvR → Ω → ℝ≥0∞} {Q Q' : RatesR} {Ω' : Type*}
    [MeasurableSpace Ω'] {μ' : Measure Ω'} [IsProbabilityMeasure μ'] {τ' : EvR → Ω' → ℝ≥0∞}
    (h : FirstArrivals μ τ Q.rate) (h' : FirstArrivals μ' τ' Q'.rate)
    (hq : Q.q = Q'.q) (hR : Q.lR = Q'.lR) {B : Ω → Bool} {B' : Ω' → Bool} (hB : Measurable B)
    (hB' : Measurable B') (hBi : IndepFun B (fun ω e => τ e ω) μ)
    (hBi' : IndepFun B' (fun ω e => τ' e ω) μ')
    (hph : μ {ω | B ω = true} = μ' {ω | B' ω = true}) (a : ActR) :
    μ.map (fun ω => (WCR a (omegaC (fun e => τ e ω)), WAR a (B ω) (omegaAR (fun e => τ e ω)))) =
      μ'.map (fun ω => (WCR a (omegaC (fun e => τ' e ω)),
        WAR a (B' ω) (omegaAR (fun e => τ' e ω)))) := by
  have hS := measurable_pi_iff.mpr h.meas
  have hS' := measurable_pi_iff.mpr h'.meas
  have hF : Measurable (fun s : EvR → ℝ≥0∞ => (omegaC s, omegaAR s)) :=
    measurable_omegaC.prodMk measurable_omegaAR
  have hpair : Measurable (fun ω => (omegaC (fun e => τ e ω), omegaAR (fun e => τ e ω))) :=
    hF.comp hS
  have hpair' : Measurable (fun ω => (omegaC (fun e => τ' e ω), omegaAR (fun e => τ' e ω))) :=
    hF.comp hS'
  have hind : IndepFun B (fun ω => (omegaC (fun e => τ e ω), omegaAR (fun e => τ e ω))) μ :=
    hBi.comp measurable_id hF
  have hind' : IndepFun B' (fun ω => (omegaC (fun e => τ' e ω), omegaAR (fun e => τ' e ω))) μ' :=
    hBi'.comp measurable_id hF
  have hlawB : μ.map B = μ'.map B' := by
    rw [Measure.ext_iff_singleton]
    intro x
    rw [Measure.map_apply hB (measurableSet_singleton x),
      Measure.map_apply hB' (measurableSet_singleton x)]
    cases x
    · have e1 : B ⁻¹' {false} = {ω | B ω = true}ᶜ := by ext ω; simp
      have e2 : B' ⁻¹' {false} = {ω | B' ω = true}ᶜ := by ext ω; simp
      have m1 : MeasurableSet {ω | B ω = true} := hB (measurableSet_singleton true)
      have m2 : MeasurableSet {ω | B' ω = true} := hB' (measurableSet_singleton true)
      rw [e1, e2, prob_compl_eq_one_sub m1, prob_compl_eq_one_sub m2, hph]
    · exact hph
  have hjoint : μ.map (fun ω => (B ω, (omegaC (fun e => τ e ω), omegaAR (fun e => τ e ω)))) =
      μ'.map (fun ω => (B' ω, (omegaC (fun e => τ' e ω), omegaAR (fun e => τ' e ω)))) := by
    rw [(indepFun_iff_map_prod_eq_prod_map_map hB.aemeasurable hpair.aemeasurable).mp hind,
      (indepFun_iff_map_prod_eq_prod_map_map hB'.aemeasurable hpair'.aemeasurable).mp hind',
      hlawB]
    congr 1
    exact e4_window_law h h' hq hR
  have hG : Measurable (fun p : Bool × (ℝ≥0∞ × ℝ≥0∞) => (WCR a p.2.1, WAR a p.1 p.2.2)) := by
    unfold WCR WAR
    refine ((measurable_fst.comp measurable_snd).min measurable_const).prodMk
      ((measurable_snd.comp measurable_snd).min ?_)
    exact (measurable_from_top (f := fun b : Bool => attackDateR a b)).comp measurable_fst
  have := congrArg (fun ν => ν.map (fun p : Bool × (ℝ≥0∞ × ℝ≥0∞) => (WCR a p.2.1, WAR a p.1 p.2.2)))
    hjoint
  rw [Measure.map_map hG (hB.prodMk hpair), Measure.map_map hG (hB'.prodMk hpair')] at this
  exact this

/-- **E1's closed split, consistency with marking** (line 1480). If the split closed streams C1
and C0 of E1 have independent exponential first arrivals with rates `p_c λ_c` and
`(1 − p_c) λ_c` (the first-arrival premise), then the first closed arrival is exponential with
rate `λ_c`, it is a failing one with probability `p_c`, and whether it fails is independent of
its date: exactly the law of the first arrival of a rate-`λ_c` stream whose arrivals are marked
independently with probability `p_c`. (The converse, deriving the premise from marking, is the
thinning theorem, which is not proved here.) -/
theorem e1t_closed_marks {τ : Ev → Ω → ℝ≥0∞} {q : Rates} (hq : q.Admissible) (hc : 0 < q.lc)
    (h : FirstArrivals μ τ q.rate) {t : ℝ} (ht : 0 ≤ t) :
    HasExpSurvival μ (fun ω => min (τ .C1 ω) (τ .C0 ω)) q.lc ∧
    μ {ω | τ .C1 ω < τ .C0 ω} = ENNReal.ofReal q.pc ∧
    μ {ω | τ .C1 ω < τ .C0 ω ∧ ENNReal.ofReal t < min (τ .C1 ω) (τ .C0 ω)} =
      μ {ω | τ .C1 ω < τ .C0 ω} * μ {ω | ENNReal.ofReal t < min (τ .C1 ω) (τ .C0 ω)} := by
  have hind : IndepFun (τ .C1) (τ .C0) μ := h.indep.indepFun (by decide)
  have h1 := h.law .C1
  have h0 := h.law .C0
  have hr1 : 0 ≤ q.rate .C1 := Rates.rate_nonneg hq .C1
  have hr0 : 0 ≤ q.rate .C0 := Rates.rate_nonneg hq .C0
  have hsum : q.rate .C1 + q.rate .C0 = q.lc := by simp only [Rates.rate]; ring
  have hpos : 0 < q.rate .C1 + q.rate .C0 := by rw [hsum]; exact hc
  refine ⟨?_, ?_, e1t_race_indep_of_min (h.meas _) (h.meas _) hind hr1 hr0 hpos h1 h0 ht⟩
  · rw [← hsum]; exact e1t_min_survival (h.meas _) (h.meas _) hind h1 h0
  · rw [e1t_race_prob (h.meas _) (h.meas _) hind hr1 hr0 hpos h1 h0, hsum]
    congr 1; simp only [Rates.rate]; field_simp

/-! ### E2 in the enlarged system (line 1341), for `X` -/

/-- The enlarged first-arrival vector viewed as E1's: `O^R` folded into the attack-enabling
open slot, so that E1's `ω_A` of the folded vector is `ω_A^R` and its `ω_C` is the first of the
commercial events and `O^R` (the latter is not used below). -/
noncomputable def toE1 (s : EvR → ℝ≥0∞) : Ev → ℝ≥0∞
  | .O => min (min (s .Ofull) (s .Owt)) (s .R)
  | .C1 => s .C1
  | .C0 => s .C0
  | .Th => s .Th
  | .L => s .L

theorem omegaAOf_toE1 (s : EvR → ℝ≥0∞) : omegaAOf (toE1 s) = omegaAR s := by
  rw [attackRR_inf_split]
  simp only [omegaAOf, attackSet, Finset.inf_insert, Finset.inf_singleton, toE1]
  ac_rfl

theorem measurable_toE1 : Measurable toE1 := by
  refine measurable_pi_iff.mpr (fun e => ?_)
  cases e <;> simp only [toE1]
  · exact ((measurable_pi_apply EvR.Ofull).min (measurable_pi_apply EvR.Owt)).min
      (measurable_pi_apply EvR.R)
  · exact measurable_pi_apply EvR.C1
  · exact measurable_pi_apply EvR.C0
  · exact measurable_pi_apply EvR.Th
  · exact measurable_pi_apply EvR.L

/-- **E2 survives with `ω_A` replaced by `ω_A^R`, for `X`** (line 1341). Copies' general E2
decomposition applied to the folded stream vector: with `W_H = ω_A^R` and
`W_cl = 0` if `B_h = 1`, `ω_A^R` otherwise, `X_cl − X_H = p_h S_H − Γ_def`, `S_H ≥ 0`, and
release lowers exposure exactly when `Γ_def > p_h S_H`, under the paper's independence of `B_h`
from the streams and of the holding schedule from (streams, `B_h`). -/
theorem b23_e2_survives {Sch : Type*} [MeasurableSpace Sch] {X : Sch → ℝ → ℝ}
    (hX : Measurable (Function.uncurry X)) {τ : EvR → Ω → ℝ≥0∞} (hτ : ∀ e, Measurable (τ e))
    {B : Ω → Bool} {sigH sigCl : Ω → Sch} (hB : Measurable B) (hH : Measurable sigH)
    (hanti : ∀ ω, Antitone (X (sigH ω)))
    (hBS : IndepFun B (fun ω e => τ e ω) μ)
    (hHi : IndepFun sigH (fun ω => ((fun e => τ e ω), B ω)) μ)
    (hI0 : Integrable (fun ω => X (sigH ω) 0) μ)
    (hI1 : Integrable (fun ω => X (sigH ω) (omegaAR (fun e => τ e ω)).toReal) μ)
    (hIcl : Integrable (fun ω => X (sigCl ω) (WA .closedRel (B ω) (omegaAR (fun e => τ e ω))).toReal) μ) :
    let S : Ω → Ev → ℝ≥0∞ := fun ω => toE1 (fun e => τ e ω)
    (∀ ω, WH S ω = (omegaAR (fun e => τ e ω)).toReal) ∧
    (Xcl μ X sigCl B S - XH μ X sigH S = ph μ B * SH μ X sigH S - Gdef μ X sigH sigCl B S) ∧
    0 ≤ SH μ X sigH S ∧
    (Xcl μ X sigCl B S < XH μ X sigH S ↔ ph μ B * SH μ X sigH S < Gdef μ X sigH sigCl B S) := by
  intro S
  have hWH : ∀ ω, WH S ω = (omegaAR (fun e => τ e ω)).toReal := fun ω => by
    simp only [WH, S, omegaAOf_toE1]
  have hWcl : ∀ ω, Wcl B S ω = (WA .closedRel (B ω) (omegaAR (fun e => τ e ω))).toReal :=
    fun ω => by simp only [Wcl, S, omegaAOf_toE1]
  have hSm : Measurable S := measurable_toE1.comp (measurable_pi_iff.mpr hτ)
  have hBS' : IndepFun B S μ := hBS.comp measurable_id measurable_toE1
  have hHi' : IndepFun sigH (fun ω => (S ω, B ω)) μ :=
    hHi.comp measurable_id (measurable_toE1.prodMap measurable_id)
  have hI1' : Integrable (fun ω => X (sigH ω) (WH S ω)) μ := by simpa only [hWH] using hI1
  have hIcl' : Integrable (fun ω => X (sigCl ω) (Wcl B S ω)) μ := by simpa only [hWcl] using hIcl
  exact ⟨hWH, e2_generic hX hB hSm hH hanti hBS' hHi' hI0 hI1' hIcl'⟩

/-- Section 8's restatement of E5 (line 406): under holding, **the attacker-access window is
shorter on average than the commercial window exactly when restricted releases arrive faster
than rival closed releases whose safeguards work**: `E[ω_A^R] < E[ω_C] ↔ (1 − p_c)λ_c < λ_R`. -/
theorem e5_attack_window_shorter_iff {τ : EvR → Ω → ℝ≥0∞} {Q : RatesR} (hQ : Q.Admissible)
    (hA : 0 < Q.q.lamA) (h : FirstArrivals μ τ Q.rate) :
    (∫⁻ ω, omegaAR (fun e => τ e ω) ∂μ) < ∫⁻ ω, omegaC (fun e => τ e ω) ∂μ ↔
      (1 - Q.q.pc) * Q.q.lc < Q.lR := by
  rw [← not_le, (e5_mean_compare hQ hA h).1, not_le]

/-- Corollary to E5 / line 406: the holder's restricted release leaves its commercial window as
under holding (`W_C^R(restricted) = W_C^R(hold) = ω_C`) and ends attacker exclusion at once. -/
theorem e5c_as_under_holding (s : EvR → ℝ≥0∞) (b : Bool) :
    WCR .restrRel (omegaC s) = WCR .hold (omegaC s) ∧ WAR .restrRel b (omegaAR s) = 0 := by
  simp [WCR, WAR, commDateR, attackDateR]

/-- Section 8's reading of E6's criterion (line 406): `g = min{u, b} > 0` exactly when **both the
deployment or removal date and the baseline attack onset are strictly after release** (an onset
of `+∞`, never, counts as after). -/
theorem gOf_pos_iff (u : ℝ) {b : EReal} (hb : b ≠ ⊥) : 0 < gOf u b ↔ 0 < u ∧ (0 : EReal) < b := by
  unfold gOf
  induction b using EReal.rec with
  | bot => exact absurd rfl hb
  | top => simp
  | coe b' => simp [EReal.coe_ne_top, lt_min_iff, EReal.coe_pos]

/-- Exact recovery (line 1347), the `λ_R = 0` route: with no restricted stream, `ω_A^R = ω_A`
on every path, and (from E4) erasing the package marks returns O. -/
theorem b23_recovery_lR_zero {τ : EvR → Ω → ℝ≥0∞} {Q : RatesR} (h : FirstArrivals μ τ Q.rate)
    (hR : Q.lR = 0) (ω : Ω) : omegaAR (fun e => τ e ω) = omegaA (fun e => τ e ω) := by
  have : τ .R ω = ⊤ := h.never_of_zero .R hR ω
  simp [omegaAR, this]


end RTTR.OpenModels


/-! ## Axiom audit -/

#print axioms RTTR.OpenModels.e1t_zero_rate_ae_top
#print axioms RTTR.OpenModels.e1t_exp_ae_pos
#print axioms RTTR.OpenModels.e1t_group
#print axioms RTTR.OpenModels.e1t_law_eq_of_survival
#print axioms RTTR.OpenModels.e1t_law_unique
#print axioms RTTR.OpenModels.e1t_integrableOn_rate_exp
#print axioms RTTR.OpenModels.e1t_integral_rate_exp
#print axioms RTTR.OpenModels.e1t_surv_as_integral
#print axioms RTTR.OpenModels.e1t_race_integral
#print axioms RTTR.OpenModels.e1t_race_joint
#print axioms RTTR.OpenModels.e1t_race_prob
#print axioms RTTR.OpenModels.e1t_min_survival
#print axioms RTTR.OpenModels.e1t_race_indep_of_min
#print axioms RTTR.OpenModels.e1t_first_is
#print axioms RTTR.OpenModels.e1t_first_prob
#print axioms RTTR.OpenModels.RatesR.rate_nonneg
#print axioms RTTR.OpenModels.omegaAR_eq
#print axioms RTTR.OpenModels.sum_commR
#print axioms RTTR.OpenModels.sum_attackR0
#print axioms RTTR.OpenModels.sum_attackRR
#print axioms RTTR.OpenModels.measurable_omegaC
#print axioms RTTR.OpenModels.measurable_omegaA
#print axioms RTTR.OpenModels.measurable_omegaAR
#print axioms RTTR.OpenModels.b23_action_table
#print axioms RTTR.OpenModels.omegaAR_le_omegaFull
#print axioms RTTR.OpenModels.b23_WAR_le_tpkg
#print axioms RTTR.OpenModels.ppart_coe
#print axioms RTTR.OpenModels.pkgOnset_top
#print axioms RTTR.OpenModels.b23_pkgExposure_noPkg
#print axioms RTTR.OpenModels.e4_erase_marks
#print axioms RTTR.OpenModels.commR_inf_split
#print axioms RTTR.OpenModels.attackRR_inf_split
#print axioms RTTR.OpenModels.e4_pathwise
#print axioms RTTR.OpenModels.e4_relabel
#print axioms RTTR.OpenModels.erase_rates
#print axioms RTTR.OpenModels.e4_erased_firstArrivals
#print axioms RTTR.OpenModels.eraseVec_O
#print axioms RTTR.OpenModels.eraseVec_single
#print axioms RTTR.OpenModels.omegaC_erase
#print axioms RTTR.OpenModels.omegaAR_erase
#print axioms RTTR.OpenModels.measurable_eraseVec
#print axioms RTTR.OpenModels.e4_window_law
#print axioms RTTR.OpenModels.e4_realized_window_law
#print axioms RTTR.OpenModels.e4_permissive_releases
#print axioms RTTR.OpenModels.e4_noPkg_Xtilde
#print axioms RTTR.OpenModels.cls_filter
#print axioms RTTR.OpenModels.cls_rates
#print axioms RTTR.OpenModels.classDate_eq
#print axioms RTTR.OpenModels.omegaC_classes
#print axioms RTTR.OpenModels.e5_classes
#print axioms RTTR.OpenModels.lamC_split
#print axioms RTTR.OpenModels.min_lt_min_shared
#print axioms RTTR.OpenModels.e5_laws
#print axioms RTTR.OpenModels.e5_total_pos
#print axioms RTTR.OpenModels.e5_cls_total
#print axioms RTTR.OpenModels.e5_prob_attack_first
#print axioms RTTR.OpenModels.e5_prob_comm_first
#print axioms RTTR.OpenModels.measurableSet_lt_pair
#print axioms RTTR.OpenModels.e5_prob_tie
#print axioms RTTR.OpenModels.e5_means
#print axioms RTTR.OpenModels.e5_order_comm_first_iff
#print axioms RTTR.OpenModels.e5_order_attack_first_iff
#print axioms RTTR.OpenModels.e5_ae_eq_iff
#print axioms RTTR.OpenModels.e5_mean_compare
#print axioms RTTR.OpenModels.b23_reversal_pos
#print axioms RTTR.OpenModels.b23_hold_order_iff
#print axioms RTTR.OpenModels.e5c_windows
#print axioms RTTR.OpenModels.e5c_commercial_window
#print axioms RTTR.OpenModels.e5c_order_fails
#print axioms RTTR.OpenModels.e5c_same_exposure
#print axioms RTTR.OpenModels.b23_e1_survives
#print axioms RTTR.OpenModels.b23_e3_survives
#print axioms RTTR.OpenModels.e6_real_id
#print axioms RTTR.OpenModels.e6_real_id_wtop
#print axioms RTTR.OpenModels.e6_real_id_btop
#print axioms RTTR.OpenModels.ereal_coe_ennreal
#print axioms RTTR.OpenModels.ereal_min_coe
#print axioms RTTR.OpenModels.e6_term_identity
#print axioms RTTR.OpenModels.e6_term_nonneg
#print axioms RTTR.OpenModels.e6_term_pos_iff
#print axioms RTTR.OpenModels.e6_diff_sum
#print axioms RTTR.OpenModels.e6_pathwise
#print axioms RTTR.OpenModels.measurable_ppart
#print axioms RTTR.OpenModels.measurable_pkgOnset
#print axioms RTTR.OpenModels.measurable_gOf
#print axioms RTTR.OpenModels.e6_wait_before_pos
#print axioms RTTR.OpenModels.e6_strict_iff
#print axioms RTTR.OpenModels.e6_expected_weak
#print axioms RTTR.OpenModels.e6_threshold
#print axioms RTTR.OpenModels.pkgExposure_eq_Xpkg
#print axioms RTTR.OpenModels.kOfW_nonneg
#print axioms RTTR.OpenModels.bOf_ne_bot
#print axioms RTTR.OpenModels.e6_pathwise_concrete
#print axioms RTTR.OpenModels.e6_omegaFull_pos
#print axioms RTTR.OpenModels.e6_strict_iff_concrete
#print axioms RTTR.OpenModels.e4_Xtilde_can_differ
#print axioms RTTR.OpenModels.e6_exp_ge
#print axioms RTTR.OpenModels.e6_conditional_wait
#print axioms RTTR.OpenModels.e4_realized_window_law_random
#print axioms RTTR.OpenModels.e1t_closed_marks
#print axioms RTTR.OpenModels.omegaAOf_toE1
#print axioms RTTR.OpenModels.measurable_toE1
#print axioms RTTR.OpenModels.b23_e2_survives
#print axioms RTTR.OpenModels.e5_attack_window_shorter_iff
#print axioms RTTR.OpenModels.e5c_as_under_holding
#print axioms RTTR.OpenModels.gOf_pos_iff
#print axioms RTTR.OpenModels.b23_recovery_lR_zero
