import Mathlib

/-!
# RTTR v8, sub-model Contest: Propositions 9 and 10 (seat L4)

Paper: `PAPER-DRAFT-v8.md`, Appendix A.3.3 (P9 lines 957–967, P10 969–973) and proofs A.6
(P9 line 1130, P10 line 1132). This file imports nothing from the project.

## How each paper object is represented, and why that is faithful

1. **Win probability** (`winProb`). Tullock, exponent one: `x_i/(x_i + x_j)`, with the equal split
   `1/2` at zero total effort (A10). `winProbN` is the N-player analogue, `x_i/X`, split `1/N`.
2. **Payoffs are defined as the text writes them.** `pay` is P9's
   `p_i v_W + (1 − p_i)v_L − c x_i − Lθ(x_i + x_j)`; `payN` its N-player form with `−LθX`;
   `payCvx` replaces `LθX` by `LθX²` (the convex-hazard counterexample); `stage` is P10's stage
   game, `pay` with `v_W = D`, `v_L = 0`; `payQ` is P10(ii)'s `D x_i/X − k x_i²/2 + bX − LθX`;
   `stageS` is the one-shot race with expected sanction `νQ` on any positive effort.
3. **Equilibrium is pure Nash over all deviations** (`IsBR`, `IsNE2`, `IsNEN`): each player's
   effort is nonnegative and no deviation to any `x' ≥ 0` raises its payoff. First-order
   conditions are never taken as the definition; where they appear they are *derived* from
   optimality (`quad_foc`, `p10_ii_sym_unique`) or used only to *verify* a global best response by
   an exact algebraic identity (`br_strict`, `cvx_sym_ne`, `quad_sym_ne`).
4. **"Unique pure-strategy equilibrium"** is stated as an `↔` or as "every equilibrium equals the
   formula" (`p9_i_nash_iff`, `p9_i_nplayer_nash_iff`, `p10_ii_unique`).
5. **Hypotheses are the text's**: `v_W > v_L` and `c + Lθ > 0` (P9), `D > 0` (P10), `k > 0`,
   `0 < ϱ < 1`. No sign is imposed on `c`, `L`, `θ` separately unless a proof needs it; where one
   is needed (`c + 2Lθ > 0`, `L_A > 0`, `σ_s ≥ 0`, `L_out θ ≥ 0`) it is an explicit hypothesis,
   recorded as a finding in `../LEAN/L4-ROWS.md`, and its necessity is shown where it matters
   (`p10_i_joint_needs_hyp`).
6. **Windows** (P9(ii)) are changes to the prizes: winner-only `v_W ↦ v_W + v_s`; shared
   `v_W, v_L ↦ v_W + v_s, v_L + v_s`; loser share `v_L ↦ v_L + v_s^L`. The multipliers relate the
   *unique equilibria* of the two games, not two copies of a formula.
7. **Welfare** (`welfare`, P9(iii)) is defined from the text's own accounting: outsiders get
   `G − P`, the holder `σ_s + P` (so the prize that drives effort is `v_s = σ_s + P`), racing costs
   `c` and yields `b` per unit of total effort and adds `θX + ξ` to the expected-loss index at
   social loss `L_A`; `C0` is everything that does not depend on the window. Once the equilibria
   are substituted, `ΔW` is an **algebraic** consequence of this definition: its content is that
   the payments cancel and that `ΔX = v_s/(2(c + Lθ))` at equilibrium.
8. **The repeated game** (P10(iii)) is represented by expected discounted payoff streams,
   `disc ϱ f = ∑' t, ϱ^t f t`, of explicitly defined strategies against grim trigger with detection
   probability `ν`, no false alarms and permanent reversion to the stage equilibrium:
   restraint, every one-shot deviation `e > 0`, and every stationary deviation. Effort `e = 0` is
   no deviation, so its stream is restraint's (no detection risk: no false alarms); the theorems
   still quantify over every `e ≥ 0`. The sums are
   evaluated as genuine `tsum`s. **Not formalised:** the one-shot deviation principle, i.e. that
   these deviations exhaust all strategies of the infinite game. The "only if" direction does not
   need it; the "if" direction does. This is the CHECKED-NARROWER premise of the restraint rows.
9. **P10(iv)'s dominance bound** quantifies over an arbitrary contest rule: any win probability
   `p : ℝ → ℝ` with values in `[0, 1]` and any loss term `ℓ` monotone on `[0, ∞)`, the rival's
   effort being fixed and absorbed into `p`, `ℓ` and the constant `K`. That generality is the
   claim.
10. **Numbers.** Exact rationals are proved exactly; transcendental values are proved by rigorous
   interval bounds on `Real.sqrt` (`p9_convex_multiplier`, `p10_ii_example`).
-/

open Real

namespace RTTR.Contest

/-- Tullock win probability, exponent one, equal split at zero total effort (A10). -/
noncomputable def winProb (xi xj : ℝ) : ℝ := if xi + xj = 0 then 1 / 2 else xi / (xi + xj)

/-- P9's payoff: `p_i v_W + (1 − p_i) v_L − c x_i − Lθ(x_i + x_j)`. -/
noncomputable def pay (vW vL c L θ xi xj : ℝ) : ℝ :=
  winProb xi xj * vW + (1 - winProb xi xj) * vL - c * xi - L * θ * (xi + xj)

/-- `x` is a best response for a player whose payoff is `u` (own effort ↦ payoff), over all
nonnegative efforts. -/
def IsBR (u : ℝ → ℝ) (x : ℝ) : Prop := 0 ≤ x ∧ ∀ x', 0 ≤ x' → u x' ≤ u x

/-- Pure Nash equilibrium of a symmetric two-player game with payoff `u own rival`. -/
def IsNE2 (u : ℝ → ℝ → ℝ) (a b : ℝ) : Prop := IsBR (fun x => u x b) a ∧ IsBR (fun x => u x a) b

/-- The candidate best-response formula `max{0, √(Δv·y/ĉ) − y}` of P10(iv). -/
noncomputable def br (dv ch y : ℝ) : ℝ := max 0 (√(dv * y / ch) - y)

lemma winProb_pos (x y : ℝ) (h : x + y ≠ 0) : winProb x y = x / (x + y) := by
  simp [winProb, h]

lemma winProb_zero_zero : winProb 0 0 = 1 / 2 := by simp [winProb]

lemma winProb_right_zero {x : ℝ} (hx : 0 < x) : winProb x 0 = 1 := by
  rw [winProb_pos _ _ (by simp; exact hx.ne')]; simp [hx.ne']

lemma winProb_left_zero {y : ℝ} (hy : 0 < y) : winProb 0 y = 0 := by
  rw [winProb_pos _ _ (by simp; exact hy.ne')]; simp

lemma winProb_add (x y : ℝ) : winProb x y + winProb y x = 1 := by
  by_cases h : x + y = 0
  · have h' : y + x = 0 := by linarith
    simp [winProb, h, h']; norm_num
  · have h' : y + x ≠ 0 := by rwa [add_comm]
    rw [winProb_pos _ _ h, winProb_pos _ _ h', add_comm y x]; field_simp

/-- Against a positive rival effort the payoff is `v_L + Δv·x/(x+y) − ĉx − Lθy`. -/
lemma pay_eq (vW vL c L θ : ℝ) {x y : ℝ} (hx : 0 ≤ x) (hy : 0 < y) :
    pay vW vL c L θ x y
      = vL + (vW - vL) * (x / (x + y)) - (c + L * θ) * x - L * θ * y := by
  rw [pay, winProb_pos _ _ (by linarith)]; ring

lemma br_nonneg (dv ch y : ℝ) : 0 ≤ br dv ch y := le_max_left _ _

/-- **Core lemma (strict).** Against `y > 0`, `br` is the unique maximiser over `x ≥ 0` of the
own-effort part `Δv·x/(x+y) − ĉx` of the payoff. -/
theorem br_strict {dv ch y x : ℝ} (hdv : 0 < dv) (hch : 0 < ch) (hy : 0 < y) (hx : 0 ≤ x)
    (hne : x ≠ br dv ch y) :
    dv * (x / (x + y)) - ch * x < dv * (br dv ch y / (br dv ch y + y)) - ch * br dv ch y := by
  set s := √(dv * y / ch) with hs_def
  have hs2 : s ^ 2 = dv * y / ch := Real.sq_sqrt (by positivity)
  have hdv_eq : dv = ch * s ^ 2 / y := by rw [hs2]; field_simp
  have hxy : 0 < x + y := by linarith
  rcases le_or_gt y s with h | h
  · have hbr : br dv ch y = s - y := by
      simp only [br, ← hs_def]; exact max_eq_right (by linarith)
    have hspos : 0 < s := lt_of_lt_of_le hy h
    have hz : x + y - s ≠ 0 := by
      intro h'; apply hne; rw [hbr]; linarith
    rw [hbr]
    have key : dv * ((s - y) / (s - y + y)) - ch * (s - y) - (dv * (x / (x + y)) - ch * x)
        = ch * (x + y - s) ^ 2 / (x + y) := by
      rw [hdv_eq]; field_simp; ring
    have hpos : 0 < ch * (x + y - s) ^ 2 / (x + y) := by
      apply div_pos (mul_pos hch (by positivity)) hxy
    linarith
  · have hbr : br dv ch y = 0 := by
      simp only [br, ← hs_def]; exact max_eq_left (by linarith)
    rw [hbr]
    have hx0 : 0 < x := lt_of_le_of_ne hx (fun h' => hne (by rw [hbr, h']))
    have hs0 : 0 ≤ s := Real.sqrt_nonneg _
    have hlt : s ^ 2 / (y * (x + y)) < 1 := by
      rw [div_lt_one (by positivity)]; nlinarith
    have : dv * (x / (x + y)) = ch * x * (s ^ 2 / (y * (x + y))) := by
      rw [hdv_eq]; field_simp
    rw [this]
    have : ch * x * (s ^ 2 / (y * (x + y))) < ch * x * 1 :=
      mul_lt_mul_of_pos_left hlt (by positivity)
    simp only [zero_div, mul_zero, sub_zero, zero_add]
    linarith

theorem br_le {dv ch y x : ℝ} (hdv : 0 < dv) (hch : 0 < ch) (hy : 0 < y) (hx : 0 ≤ x) :
    dv * (x / (x + y)) - ch * x ≤ dv * (br dv ch y / (br dv ch y + y)) - ch * br dv ch y := by
  by_cases h : x = br dv ch y
  · rw [h]
  · exact (br_strict hdv hch hy hx h).le

/-- On the positive branch, `br + y = √(Δv·y/ĉ)`, so `(br + y)² = Δv·y/ĉ`. -/
lemma br_pos_sq {dv ch y : ℝ} (hdv : 0 < dv) (hch : 0 < ch) (hy : 0 < y)
    (h : 0 < br dv ch y) : (br dv ch y + y) ^ 2 = dv * y / ch := by
  have hb : br dv ch y = √(dv * y / ch) - y := by
    unfold br at h ⊢
    rcases le_total (√(dv * y / ch) - y) 0 with h' | h'
    · rw [max_eq_left h'] at h; exact absurd h (lt_irrefl _)
    · exact max_eq_right h'
  rw [hb, sub_add_cancel, Real.sq_sqrt (by positivity)]

/-- `br(Δv/(4ĉ)) = Δv/(4ĉ)`. -/
lemma br_xstar {dv ch : ℝ} (hdv : 0 < dv) (hch : 0 < ch) :
    br dv ch (dv / (4 * ch)) = dv / (4 * ch) := by
  have : dv * (dv / (4 * ch)) / ch = (dv / (2 * ch)) ^ 2 := by field_simp; ring
  unfold br
  rw [this, Real.sqrt_sq (by positivity)]
  have : dv / (2 * ch) - dv / (4 * ch) = dv / (4 * ch) := by field_simp; ring
  rw [this]; exact max_eq_right (by positivity)

/-- A best response of a player facing `y > 0` is exactly `br`. -/
theorem isBR_iff {vW vL c L θ y x : ℝ} (hv : vL < vW) (hc : 0 < c + L * θ) (hy : 0 < y) :
    IsBR (fun x' => pay vW vL c L θ x' y) x ↔ x = br (vW - vL) (c + L * θ) y := by
  have hdv : 0 < vW - vL := by linarith
  constructor
  · rintro ⟨hx, hmax⟩
    by_contra hne
    have h1 := hmax _ (br_nonneg (vW - vL) (c + L * θ) y)
    simp only at h1
    rw [pay_eq _ _ _ _ _ hx hy, pay_eq _ _ _ _ _ (br_nonneg _ _ _) hy] at h1
    have h2 := br_strict hdv hc hy hx hne
    linarith
  · rintro rfl
    refine ⟨br_nonneg _ _ _, fun x' hx' => ?_⟩
    simp only
    rw [pay_eq _ _ _ _ _ hx' hy, pay_eq _ _ _ _ _ (br_nonneg _ _ _) hy]
    have := br_le hdv hc hy hx'
    linarith

/-! ## P9(i), two players -/

/-- **P9(i), two players.** Under A10 with `v_W > v_L` and `c + Lθ > 0`, a profile is a pure
Nash equilibrium (no profitable deviation to any `x ≥ 0`) **if and only if** both efforts equal
`(v_W − v_L)/(4(c + Lθ))`: existence and uniqueness in one statement. -/
theorem p9_i_nash_iff {vW vL c L θ : ℝ} (hv : vL < vW) (hc : 0 < c + L * θ) (a b : ℝ) :
    IsNE2 (pay vW vL c L θ) a b ↔
      a = (vW - vL) / (4 * (c + L * θ)) ∧ b = (vW - vL) / (4 * (c + L * θ)) := by
  have hdv : 0 < vW - vL := by linarith
  set ch := c + L * θ with hch_def
  set xs := (vW - vL) / (4 * ch) with hxs
  have hxs0 : 0 < xs := by positivity
  constructor
  · rintro ⟨⟨ha0, hA⟩, ⟨hb0, hB⟩⟩
    simp only at hA hB
    rcases eq_or_lt_of_le ha0 with ha | ha <;> rcases eq_or_lt_of_le hb0 with hb | hb
    · -- (0,0): a small effort wins everything
      subst ha; subst hb
      have h := hA xs hxs0.le
      simp only [pay, winProb_right_zero hxs0, winProb_zero_zero] at h
      have : xs * ch = (vW - vL) / 4 := by rw [hxs]; field_simp
      nlinarith
    · -- (0, b>0): b gains by halving its effort
      subst ha
      have h := hB (b / 2) (by linarith)
      simp only [pay, winProb_right_zero hb, winProb_right_zero (by linarith : 0 < b / 2)] at h
      nlinarith
    · subst hb
      have h := hA (a / 2) (by linarith)
      simp only [pay, winProb_right_zero ha, winProb_right_zero (by linarith : 0 < a / 2)] at h
      nlinarith
    · have hbrA : a = br (vW - vL) ch b := (isBR_iff hv hc hb).1 ⟨ha0, hA⟩
      have hbrB : b = br (vW - vL) ch a := (isBR_iff hv hc ha).1 ⟨hb0, hB⟩
      have e1 := br_pos_sq hdv hc hb (hbrA ▸ ha)
      have e2 := br_pos_sq hdv hc ha (hbrB ▸ hb)
      rw [← hbrA] at e1; rw [← hbrB] at e2
      have hab : a = b := by
        have : (vW - vL) * b / ch = (vW - vL) * a / ch := by rw [← e1, ← e2]; ring
        rw [div_left_inj' hc.ne'] at this
        exact (mul_left_cancel₀ hdv.ne' this).symm
      subst hab
      refine ⟨?_, ?_⟩ <;>
      · rw [hxs]; field_simp
        have : (a + a) ^ 2 * ch = (vW - vL) * a := by rw [e1]; field_simp
        nlinarith
  · rintro ⟨rfl, rfl⟩
    have hbr := br_xstar hdv hc
    refine ⟨(isBR_iff hv hc hxs0).2 hbr.symm, (isBR_iff hv hc hxs0).2 hbr.symm⟩

/-! ## P9(i), N players -/

/-- N-player Tullock win probability `x_i/X`, equal split `1/N` at zero total effort. -/
noncomputable def winProbN {N : ℕ} (x : Fin N → ℝ) (i : Fin N) : ℝ :=
  if ∑ j, x j = 0 then 1 / N else x i / ∑ j, x j

/-- N-player payoff `p_i v_W + (1 − p_i) v_L − c x_i − LθX`. -/
noncomputable def payN {N : ℕ} (vW vL c L θ : ℝ) (x : Fin N → ℝ) (i : Fin N) : ℝ :=
  winProbN x i * vW + (1 - winProbN x i) * vL - c * x i - L * θ * ∑ j, x j

/-- Pure Nash equilibrium of the N-player game: no player gains from any deviation `x' ≥ 0`. -/
def IsNEN {N : ℕ} (u : (Fin N → ℝ) → Fin N → ℝ) (x : Fin N → ℝ) : Prop :=
  (∀ i, 0 ≤ x i) ∧ ∀ i x', 0 ≤ x' → u (Function.update x i x') i ≤ u x i

lemma sum_update {N : ℕ} (x : Fin N → ℝ) (i : Fin N) (x' : ℝ) :
    ∑ j, Function.update x i x' j = x' + (∑ j, x j - x i) := by
  rw [Finset.sum_update_of_mem (Finset.mem_univ i),
    Finset.sum_eq_add_sum_sdiff_singleton_of_mem (Finset.mem_univ i) x]
  ring

lemma rival_sum_nonneg {N : ℕ} (x : Fin N → ℝ) (hx : ∀ j, 0 ≤ x j) (i : Fin N) :
    0 ≤ ∑ j, x j - x i := by
  rw [Finset.sum_eq_add_sum_sdiff_singleton_of_mem (Finset.mem_univ i) x, add_sub_cancel_left]
  exact Finset.sum_nonneg (fun j _ => hx j)

/-- Against positive rival total `Y = X − x_i`, a deviation's N-player payoff is the two-player
payoff against a single rival of effort `Y`. -/
lemma payN_update {N : ℕ} (vW vL c L θ : ℝ) (x : Fin N → ℝ) (i : Fin N) {x' : ℝ}
    (hx' : 0 ≤ x') (hY : 0 < ∑ j, x j - x i) :
    payN vW vL c L θ (Function.update x i x') i = pay vW vL c L θ x' (∑ j, x j - x i) := by
  have hne : x' + (∑ j, x j - x i) ≠ 0 := by linarith
  simp only [payN, winProbN, pay, winProb, sum_update, hne, ite_false, Function.update_self]

lemma payN_self {N : ℕ} (vW vL c L θ : ℝ) (x : Fin N → ℝ) (i : Fin N) (hx : 0 ≤ x i)
    (hY : 0 < ∑ j, x j - x i) :
    payN vW vL c L θ x i = pay vW vL c L θ (x i) (∑ j, x j - x i) := by
  rw [← payN_update vW vL c L θ x i hx hY, Function.update_eq_self]

/-- P9(i), N players, the case `N ≥ 2` (the contest proper); `p9_i_nplayer_nash_iff` adds
`N = 0, 1`. -/
lemma nplayer_nash_iff_of_two_le {N : ℕ} (hN : 2 ≤ N) {vW vL c L θ : ℝ} (hv : vL < vW)
    (hc : 0 < c + L * θ) (x : Fin N → ℝ) :
    IsNEN (payN vW vL c L θ) x ↔
      ∀ i, x i = (vW - vL) * (N - 1) / (N ^ 2 * (c + L * θ)) := by
  have hdv : 0 < vW - vL := by linarith
  have hN' : (2 : ℝ) ≤ N := by exact_mod_cast hN
  set ch := c + L * θ with hch_def
  set dv := vW - vL with hdv_def
  constructor
  · rintro ⟨hx0, hdev⟩
    set X := ∑ j, x j with hX_def
    have hYnn := rival_sum_nonneg x hx0
    -- Step 1: total effort is positive.
    have hX : 0 < X := by
      by_contra hneg
      have hX0 : X = 0 := le_antisymm (not_lt.1 hneg) (Finset.sum_nonneg (fun j _ => hx0 j))
      have hall : ∀ j, x j = 0 := fun j =>
        (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => hx0 j)).1 hX0 j (Finset.mem_univ j)
      let i0 : Fin N := ⟨0, by omega⟩
      set ε := dv * (N - 1) / (2 * N * ch) with hε
      have hεpos : 0 < ε := by
        rw [hε]; apply div_pos (mul_pos hdv (by linarith)) (by positivity)
      have h := hdev i0 ε hεpos.le
      have hsum : ∑ j, Function.update x i0 ε j = ε := by
        rw [sum_update, ← hX_def, hX0, hall i0]; ring
      simp only [payN, winProbN, hsum, hεpos.ne', ite_false, Function.update_self, ← hX_def,
        hX0, ite_true, hall i0, div_self hεpos.ne'] at h
      have hεch : ε * ch = dv * (N - 1) / (2 * N) := by rw [hε]; field_simp
      have hNpos : (0 : ℝ) < N := by linarith
      have key : dv * (N - 1) / (2 * N) < dv - dv / N := by
        rw [div_lt_iff₀ (by positivity)]
        have : (dv - dv / N) * (2 * N) = 2 * dv * (N - 1) := by field_simp
        rw [this]; nlinarith
      have : vW - c * ε - L * θ * ε = vW - ε * ch := by rw [hch_def]; ring
      have e : 1 / (N : ℝ) * vW + (1 - 1 / N) * vL = vL + dv / N := by
        rw [hdv_def]; field_simp; ring
      simp only [one_mul, sub_self, zero_mul, add_zero, mul_zero, sub_zero] at h
      linarith [this, hεch, e, key]
    -- Step 2: every player faces positive rival effort.
    have hYpos : ∀ i, 0 < X - x i := by
      intro i
      rcases eq_or_lt_of_le (hYnn i) with h0 | h0
      · exfalso
        have hxi : x i = X := by linarith
        have hxipos : 0 < x i := by linarith
        have h := hdev i (x i / 2) (by linarith)
        have hsum : ∑ j, Function.update x i (x i / 2) j = x i / 2 := by
          rw [sum_update, ← hX_def, ← h0]; ring
        simp only [payN, winProbN, hsum, (by linarith : x i / 2 ≠ 0), ite_false,
          Function.update_self, ← hX_def, hX.ne', div_self (by linarith : x i / 2 ≠ 0)] at h
        rw [← hxi, div_self hxipos.ne'] at h
        nlinarith
      · exact h0
    -- Step 3: each effort is the best response to the rivals' total.
    have hbr : ∀ i, x i = br dv ch (X - x i) := by
      intro i
      refine (isBR_iff hv hc (hYpos i)).1 ⟨hx0 i, fun x' hx' => ?_⟩
      have h := hdev i x' hx'
      rw [payN_update vW vL c L θ x i hx' (hYpos i), payN_self vW vL c L θ x i (hx0 i)
        (hYpos i)] at h
      exact h
    -- Step 4: every effort is positive, hence all are equal, hence the formula.
    have hsq : ∀ i, 0 < x i → X ^ 2 = dv * (X - x i) / ch := by
      intro i hi
      have := br_pos_sq hdv hc (hYpos i) (hbr i ▸ hi)
      rw [← hbr i, add_sub_cancel] at this
      exact this
    have hpos : ∀ i, 0 < x i := by
      intro i
      by_contra hneg
      have hxi : x i = 0 := le_antisymm (not_lt.1 hneg) (hx0 i)
      obtain ⟨j, hj⟩ : ∃ j, 0 < x j := by
        by_contra hnone
        push Not at hnone
        have : X ≤ 0 := Finset.sum_nonpos (fun j _ => hnone j)
        linarith
      have h1 : br dv ch X = 0 := by have := hbr i; rw [hxi, sub_zero] at this; linarith
      have h2 : √(dv * X / ch) ≤ X := by
        have := le_max_right 0 (√(dv * X / ch) - X); unfold br at h1; linarith
      have h3 : dv * X / ch ≤ X ^ 2 := by
        rw [← Real.sq_sqrt (by positivity : 0 ≤ dv * X / ch)]
        exact pow_le_pow_left₀ (Real.sqrt_nonneg _) h2 2
      have h4 : dv ≤ ch * X := by
        rw [div_le_iff₀ hc] at h3; nlinarith
      have h5 := hsq j hj
      rw [eq_div_iff hc.ne'] at h5
      nlinarith [hYpos j]
    have hY : ∀ i, X - x i = ch * X ^ 2 / dv := by
      intro i; have := hsq i (hpos i); field_simp at this ⊢; linarith
    have hequal : ∀ i j, x i = x j := by
      intro i j; have := hY i; have := hY j; linarith
    have hXN : ∀ i, X = N * x i := by
      intro i
      rw [hX_def, Finset.sum_congr rfl (fun j _ => hequal j i), Finset.sum_const,
        Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    intro i
    have h1 := hY i
    rw [hXN i] at h1
    have hi := hpos i
    have hNpos : (0 : ℝ) < N := by linarith
    rw [eq_div_iff (by positivity)]
    rw [eq_div_iff hdv.ne'] at h1
    have : (N * x i - x i) * dv = ch * (N * x i) ^ 2 := h1
    have : x i * ((N - 1) * dv - ch * N ^ 2 * x i) = 0 := by linear_combination this
    rcases mul_eq_zero.1 this with h | h
    · linarith
    · linarith
  · intro hx
    set xs := dv * (N - 1) / (N ^ 2 * ch) with hxs
    have hNpos : (0 : ℝ) < N := by linarith
    have hxs0 : 0 < xs := by
      rw [hxs]; apply div_pos (mul_pos hdv (by linarith)) (by positivity)
    have hsum : ∑ j, x j = N * xs := by
      rw [Finset.sum_congr rfl (fun j _ => hx j), Finset.sum_const, Finset.card_univ,
        Fintype.card_fin, nsmul_eq_mul]
    have hY : ∀ i, ∑ j, x j - x i = (N - 1) * xs := by intro i; rw [hsum, hx i]; ring
    have hYpos : ∀ i, 0 < ∑ j, x j - x i := by
      intro i; rw [hY i]; exact mul_pos (by linarith) hxs0
    have hbrxs : br dv ch ((N - 1) * xs) = xs := by
      have : dv * ((N - 1) * xs) / ch = (N * xs) ^ 2 := by
        rw [hxs]; field_simp
      unfold br
      rw [this, Real.sqrt_sq (by positivity)]
      rw [show N * xs - (N - 1) * xs = xs by ring]
      exact max_eq_right hxs0.le
    refine ⟨fun i => by rw [hx i]; exact hxs0.le, fun i x' hx' => ?_⟩
    rw [payN_update vW vL c L θ x i hx' (hYpos i), payN_self vW vL c L θ x i (by
      rw [hx i]; exact hxs0.le) (hYpos i)]
    have hBR : IsBR (fun x'' => pay vW vL c L θ x'' (∑ j, x j - x i)) (x i) :=
      (isBR_iff hv hc (hYpos i)).2 (by rw [hY i, hbrxs, hx i])
    exact hBR.2 x' hx'

/-- **P9(i), N players.** For every `N`, a profile is a pure Nash equilibrium **if and only if**
every effort equals `(v_W − v_L)(N − 1)/(N²(c + Lθ))`. The paper states the formula for the
symmetric profile; this proves it is an equilibrium and that there is no other pure one,
symmetric or not. No lower bound on `N` is needed: at `N = 1` the lone player wins for sure, so
zero effort is the unique equilibrium, which the formula also gives; `N = 0` is vacuous. -/
theorem p9_i_nplayer_nash_iff {N : ℕ} {vW vL c L θ : ℝ} (hv : vL < vW)
    (hc : 0 < c + L * θ) (x : Fin N → ℝ) :
    IsNEN (payN vW vL c L θ) x ↔
      ∀ i, x i = (vW - vL) * (N - 1) / (N ^ 2 * (c + L * θ)) := by
  rcases Nat.lt_or_ge N 2 with hN | hN
  · obtain rfl | rfl : N = 0 ∨ N = 1 := by omega
    · exact ⟨fun _ i => i.elim0, fun _ => ⟨fun i => i.elim0, fun i => i.elim0⟩⟩
    · have hpay : ∀ y : Fin 1 → ℝ, ∀ i, payN vW vL c L θ y i = vW - (c + L * θ) * y i := by
        intro y i
        obtain rfl : i = 0 := Subsingleton.elim i 0
        simp only [payN, winProbN, Fin.sum_univ_one]
        split_ifs with h
        · rw [h]; simp
        · rw [div_self h]; ring
      have hrhs : (vW - vL) * (((1 : ℕ) : ℝ) - 1) / (((1 : ℕ) : ℝ) ^ 2 * (c + L * θ)) = 0 := by
        simp
      rw [hrhs]
      constructor
      · rintro ⟨hx0, hdev⟩ i
        have h := hdev i 0 le_rfl
        rw [hpay, hpay, Function.update_self] at h
        have := hx0 i
        nlinarith
      · intro hx
        refine ⟨fun i => (hx i).ge, fun i x' hx' => ?_⟩
        rw [hpay, hpay, Function.update_self, hx i]
        nlinarith
  · exact nplayer_nash_iff_of_two_le hN hv hc x

/-! ## P9(ii), the multipliers -/

/-- **P9(ii), general window.** With baseline gap `v_W − v_L = D > 0`, a window worth `v_s` to the
winner and `v_s^L` to the loser (with the standing `v_W > v_L` for the new payoffs, i.e.
`D + v_s − v_s^L > 0`) multiplies the unique equilibrium effort of each player, and the
expected-loss index `θX*`, by `(D + v_s − v_s^L)/D`. -/
theorem p9_ii_window {vW vL c L θ vs vsL : ℝ} (hD : vL < vW) (hgap : 0 < (vW - vL) + vs - vsL)
    (hc : 0 < c + L * θ) {a0 b0 a1 b1 : ℝ} (h0 : IsNE2 (pay vW vL c L θ) a0 b0)
    (h1 : IsNE2 (pay (vW + vs) (vL + vsL) c L θ) a1 b1) :
    a1 = ((vW - vL) + vs - vsL) / (vW - vL) * a0 ∧
      b1 = ((vW - vL) + vs - vsL) / (vW - vL) * b0 ∧
      θ * (a1 + b1) = ((vW - vL) + vs - vsL) / (vW - vL) * (θ * (a0 + b0)) := by
  have hD' : 0 < vW - vL := by linarith
  obtain ⟨ha0, hb0⟩ := (p9_i_nash_iff hD hc a0 b0).1 h0
  obtain ⟨ha1, hb1⟩ := (p9_i_nash_iff (by linarith) hc a1 b1).1 h1
  subst ha0 hb0 ha1 hb1
  refine ⟨?_, ?_, ?_⟩ <;> field_simp <;> ring

/-- **P9(ii), winner-only window**: multiplier `(D + v_s)/D` on effort and on `θX*`. -/
theorem p9_ii_winner_only {vW vL c L θ vs : ℝ} (hD : vL < vW) (hvs : 0 < (vW - vL) + vs)
    (hc : 0 < c + L * θ) {a0 b0 a1 b1 : ℝ} (h0 : IsNE2 (pay vW vL c L θ) a0 b0)
    (h1 : IsNE2 (pay (vW + vs) vL c L θ) a1 b1) :
    a1 = ((vW - vL) + vs) / (vW - vL) * a0 ∧ b1 = ((vW - vL) + vs) / (vW - vL) * b0 ∧
      θ * (a1 + b1) = ((vW - vL) + vs) / (vW - vL) * (θ * (a0 + b0)) := by
  have h1' : IsNE2 (pay (vW + vs) (vL + 0) c L θ) a1 b1 := by simpa using h1
  have := p9_ii_window (vsL := 0) hD (by linarith) hc h0 h1'
  simpa using this

/-- **P9(ii), main text L334: "a winner-only window raises equilibrium effort"** — strictly, for
each player, **iff** the window's private value is positive. At `v_s = 0` effort is unchanged, so
the strict claim needs `v_s > 0`, which the notation (L858, "private value of a window") does not
state. -/
theorem p9_ii_winner_only_raises {vW vL c L θ vs : ℝ} (hD : vL < vW) (hvs : 0 < (vW - vL) + vs)
    (hc : 0 < c + L * θ) {a0 b0 a1 b1 : ℝ} (h0 : IsNE2 (pay vW vL c L θ) a0 b0)
    (h1 : IsNE2 (pay (vW + vs) vL c L θ) a1 b1) :
    (a0 < a1 ↔ 0 < vs) ∧ (b0 < b1 ↔ 0 < vs) := by
  have hD' : 0 < vW - vL := by linarith
  obtain ⟨ha, hb, -⟩ := p9_ii_winner_only hD hvs hc h0 h1
  obtain ⟨ha0, hb0⟩ := (p9_i_nash_iff hD hc a0 b0).1 h0
  have hpos : 0 < (vW - vL) / (4 * (c + L * θ)) := by positivity
  have key : ∀ z, 0 < z → (z < ((vW - vL) + vs) / (vW - vL) * z ↔ 0 < vs) := by
    intro z hz
    have e : ((vW - vL) + vs) / (vW - vL) * z = z + vs * (z / (vW - vL)) := by
      field_simp
    have hq : 0 < z / (vW - vL) := div_pos hz hD'
    rw [e, lt_add_iff_pos_right]
    exact ⟨fun h => by nlinarith, fun h => mul_pos h hq⟩
  rw [ha, hb]
  exact ⟨key a0 (ha0 ▸ hpos), key b0 (hb0 ▸ hpos)⟩

/-- **P9(ii), shared window**: a window both players receive leaves effort unchanged. -/
theorem p9_ii_shared {vW vL c L θ vs : ℝ} (hD : vL < vW) (hc : 0 < c + L * θ)
    {a0 b0 a1 b1 : ℝ} (h0 : IsNE2 (pay vW vL c L θ) a0 b0)
    (h1 : IsNE2 (pay (vW + vs) (vL + vs) c L θ) a1 b1) : a1 = a0 ∧ b1 = b0 := by
  have hD' : 0 < vW - vL := by linarith
  obtain ⟨h, h', -⟩ := p9_ii_window hD (by linarith) hc h0 h1
  rw [show (vW - vL + vs - vs) / (vW - vL) = 1 by field_simp; ring] at h h'
  simp [h, h']

/-- **P9(ii), loser share**: multiplier `(D + v_s − v_s^L)/D`. -/
theorem p9_ii_loser_share {vW vL c L θ vs vsL : ℝ} (hD : vL < vW)
    (hgap : 0 < (vW - vL) + vs - vsL) (hc : 0 < c + L * θ) {a0 b0 a1 b1 : ℝ}
    (h0 : IsNE2 (pay vW vL c L θ) a0 b0) (h1 : IsNE2 (pay (vW + vs) (vL + vsL) c L θ) a1 b1) :
    a1 = ((vW - vL) + vs - vsL) / (vW - vL) * a0 :=
  (p9_ii_window hD hgap hc h0 h1).1

/-! ## P9(iii), welfare -/

/-- **Welfare (P9(iii)), as the text defines it**: every party's real gains and losses in one
unit. Outsiders receive their real gain `G` less payments `P` to the holder; the holder receives
its real surplus `σ` plus `P`; total racing effort `X` costs `c` per unit, yields public value
`b` per unit, and adds `θX + ξ` to the expected-loss index at social loss `L_A` per unit (`ξ` is
the rivals' further change). `C0` collects every term that does not depend on the window
(e.g. the prize, always awarded). -/
def welfare (C0 G P σ b c LA θ X ξ : ℝ) : ℝ :=
  C0 + (G - P) + (σ + P) + b * X - c * X - LA * (θ * X + ξ)

/-- **P9(iii), the welfare change of a winner-only window.** Baseline: no window, equilibrium
`(a0, b0)`. Window: the winner's prize rises by `v_s = σ_s + P` (real surplus plus outsiders'
payments), equilibrium `(a1, b1)`. Payments cancel and
`ΔW = G + σ_s − (c + L_Aθ − b)·v_s/(2(c + Lθ))`. -/
theorem p9_iii_deltaW {vW vL c L θ LA b G σ P C0 : ℝ} (hD : vL < vW) (hσP : 0 < (vW - vL) + (σ + P))
    (hc : 0 < c + L * θ) {a0 b0 a1 b1 : ℝ} (h0 : IsNE2 (pay vW vL c L θ) a0 b0)
    (h1 : IsNE2 (pay (vW + (σ + P)) vL c L θ) a1 b1) :
    welfare C0 G P σ b c LA θ (a1 + b1) 0 - welfare C0 0 0 0 b c LA θ (a0 + b0) 0
      = G + σ - (c + LA * θ - b) * (σ + P) / (2 * (c + L * θ)) := by
  have hD' : 0 < vW - vL := by linarith
  obtain ⟨ha0, hb0⟩ := (p9_i_nash_iff hD hc a0 b0).1 h0
  obtain ⟨ha1, hb1⟩ := (p9_i_nash_iff (by linarith) hc a1 b1).1 h1
  subst ha0 hb0 ha1 hb1
  simp only [welfare]; field_simp; ring

/-- **P9(iii), the `ξ` threshold** (any window, any equilibrium totals `X0`, `X1`; `σ` is summed
over holders). Needs `L_A > 0`, which the text leaves implicit. -/
theorem p9_iii_harm_iff {C0 G P σ b c LA θ X0 X1 ξ : ℝ} (hLA : 0 < LA) :
    welfare C0 G P σ b c LA θ X1 ξ - welfare C0 0 0 0 b c LA θ X0 0 < 0 ↔
      (G + σ - (c + LA * θ - b) * (X1 - X0)) / LA < ξ := by
  simp only [welfare]
  rw [div_lt_iff₀ hLA]
  constructor <;> intro h <;> nlinarith

/-- **P9, escalation example.** A window both players receive (`ΔX = 0` by P9(ii)), `ξ = 0.005`,
`L_A = 100`, `G = 1`: welfare rises by at least `0.5` whatever the holders' nonnegative real
surplus `σ` and payments `P`. -/
theorem p9_escalation_rises {vW vL c L θ vs b σ P C0 : ℝ} (hD : vL < vW) (hc : 0 < c + L * θ)
    (hσ : 0 ≤ σ) {a0 b0 a1 b1 : ℝ} (h0 : IsNE2 (pay vW vL c L θ) a0 b0)
    (h1 : IsNE2 (pay (vW + vs) (vL + vs) c L θ) a1 b1) :
    1 / 2 ≤ welfare C0 1 P σ b c 100 θ (a1 + b1) (5 / 1000)
      - welfare C0 0 0 0 b c 100 θ (a0 + b0) 0 := by
  obtain ⟨ha, hb⟩ := p9_ii_shared hD hc h0 h1
  subst ha hb
  simp only [welfare]; nlinarith

/-- **P9, escalation thresholds.** Shared window, `L_A = 100`, `G = 1`: with transfers
(`σ = 0`) harm iff `ξ > 0.010`; with each holder's `v_s = 0.5` real surplus (`σ = 1` summed)
harm iff `ξ > 0.020`. -/
theorem p9_escalation_thresholds {vW vL c L θ vs b P C0 ξ : ℝ} (hD : vL < vW)
    (hc : 0 < c + L * θ) {a0 b0 a1 b1 : ℝ} (h0 : IsNE2 (pay vW vL c L θ) a0 b0)
    (h1 : IsNE2 (pay (vW + vs) (vL + vs) c L θ) a1 b1) :
    (welfare C0 1 P 0 b c 100 θ (a1 + b1) ξ - welfare C0 0 0 0 b c 100 θ (a0 + b0) 0 < 0 ↔
        1 / 100 < ξ) ∧
      (welfare C0 1 P 1 b c 100 θ (a1 + b1) ξ - welfare C0 0 0 0 b c 100 θ (a0 + b0) 0 < 0 ↔
        2 / 100 < ξ) := by
  obtain ⟨ha, hb⟩ := p9_ii_shared hD hc h0 h1
  subst ha hb
  rw [p9_iii_harm_iff (by norm_num), p9_iii_harm_iff (by norm_num)]
  constructor <;> norm_num

/-- **P9, "as first stated", second sentence refuted** (`D = c = L = 1`, `θ = 0.4`,
`L_A = 10`, `G = 1`, `v_s = 5 > G`). A window both players receive raises welfare by `11` if each
`v_s` is real surplus and by `1` if it is a transfer. -/
theorem p9_counterexample_shared {b C0 : ℝ} {a0 b0 a1 b1 : ℝ}
    (h0 : IsNE2 (pay 1 0 1 1 (2 / 5)) a0 b0) (h1 : IsNE2 (pay (1 + 5) (0 + 5) 1 1 (2 / 5)) a1 b1) :
    welfare C0 1 0 10 b 1 10 (2 / 5) (a1 + b1) 0 - welfare C0 0 0 0 b 1 10 (2 / 5) (a0 + b0) 0
        = 11 ∧
      welfare C0 1 10 0 b 1 10 (2 / 5) (a1 + b1) 0 - welfare C0 0 0 0 b 1 10 (2 / 5) (a0 + b0) 0
        = 1 := by
  obtain ⟨ha, hb⟩ := p9_ii_shared (by norm_num) (by norm_num) h0 h1
  subst ha hb
  simp only [welfare]; constructor <;> ring

/-- **P9, "as first stated", winner-only refutation** (same numbers, `b = 6 > c + L_Aθ = 5`,
winner-only `v_s = 5`): welfare rises by `109/14 ≈ 7.8` with real surplus and `39/14 ≈ 2.8` as
a transfer. -/
theorem p9_counterexample_winner_only {C0 : ℝ} {a0 b0 a1 b1 a2 b2 : ℝ}
    (h0 : IsNE2 (pay 1 0 1 1 (2 / 5)) a0 b0) (h1 : IsNE2 (pay (1 + (5 + 0)) 0 1 1 (2 / 5)) a1 b1)
    (h2 : IsNE2 (pay (1 + (0 + 5)) 0 1 1 (2 / 5)) a2 b2) :
    welfare C0 1 0 5 6 1 10 (2 / 5) (a1 + b1) 0 - welfare C0 0 0 0 6 1 10 (2 / 5) (a0 + b0) 0
        = 109 / 14 ∧
      welfare C0 1 5 0 6 1 10 (2 / 5) (a2 + b2) 0 - welfare C0 0 0 0 6 1 10 (2 / 5) (a0 + b0) 0
        = 39 / 14 ∧
      |(109 / 14 : ℝ) - 7.8| < 0.05 ∧ |(39 / 14 : ℝ) - 2.8| < 0.05 := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [p9_iii_deltaW (by norm_num) (by norm_num) (by norm_num) h0 h1]; norm_num
  · rw [p9_iii_deltaW (by norm_num) (by norm_num) (by norm_num) h0 h2]; norm_num
  · rw [abs_lt]; constructor <;> norm_num
  · rw [abs_lt]; constructor <;> norm_num

/-- **P9, the general form of the winner-only refutation**: if `b > c + L_Aθ`, `G ≥ 0`,
`σ_s ≥ 0` and `v_s > 0`, a winner-only window raises welfare, whether `v_s` is surplus or a
transfer. -/
theorem p9_winner_only_rises {vW vL c L θ LA b G σ P C0 : ℝ} (hD : vL < vW)
    (hvs : 0 < σ + P) (hc : 0 < c + L * θ) (hb : c + LA * θ < b) (hG : 0 ≤ G) (hσ : 0 ≤ σ)
    {a0 b0 a1 b1 : ℝ} (h0 : IsNE2 (pay vW vL c L θ) a0 b0)
    (h1 : IsNE2 (pay (vW + (σ + P)) vL c L θ) a1 b1) :
    0 < welfare C0 G P σ b c LA θ (a1 + b1) 0 - welfare C0 0 0 0 b c LA θ (a0 + b0) 0 := by
  rw [p9_iii_deltaW hD (by linarith) hc h0 h1]
  have : 0 < (b - (c + LA * θ)) * (σ + P) / (2 * (c + L * θ)) := by
    apply div_pos (mul_pos (by linarith) hvs) (by linarith)
  have e : (c + LA * θ - b) * (σ + P) / (2 * (c + L * θ))
      = -((b - (c + LA * θ)) * (σ + P) / (2 * (c + L * θ))) := by ring
  rw [e]; linarith

/-! ## P9, convex hazard `θX²`: the multiplier 1.38 -/

/-- P9's payoff with the catastrophe term convex in total effort, `Lθ(x_i + x_j)²`. -/
noncomputable def payCvx (vW vL c L θ xi xj : ℝ) : ℝ :=
  winProb xi xj * vW + (1 - winProb xi xj) * vL - c * xi - L * θ * (xi + xj) ^ 2

/-- With hazard `θX²`, `Lθ ≥ 0`, a symmetric profile `(y, y)`, `y > 0`, satisfying the first-order
condition `Δv = 4cy + 16Lθy²` is a Nash equilibrium (global best responses over all `x ≥ 0`). -/
theorem cvx_sym_ne {vW vL c L θ y : ℝ} (hy : 0 < y) (hLθ : 0 ≤ L * θ) (hdv : vL < vW)
    (hfoc : vW - vL = 4 * c * y + 16 * (L * θ) * y ^ 2) : IsNE2 (payCvx vW vL c L θ) y y := by
  have hbr : IsBR (fun x => payCvx vW vL c L θ x y) y := by
    refine ⟨hy.le, fun x hx => ?_⟩
    simp only [payCvx]
    rw [winProb_pos _ _ (by linarith), winProb_pos _ _ (by linarith)]
    have hvW : vW = vL + (4 * c * y + 16 * (L * θ) * y ^ 2) := by linarith
    have hcpos : 0 < c + 4 * (L * θ) * y := by nlinarith
    have key : (y / (y + y) * vW + (1 - y / (y + y)) * vL - c * y - L * θ * (y + y) ^ 2)
        - (x / (x + y) * vW + (1 - x / (x + y)) * vL - c * x - L * θ * (x + y) ^ 2)
        = (y - x) ^ 2 * (c + L * θ * (4 * y + (x + y))) / (x + y) := by
      rw [hvW]; field_simp; ring
    have : 0 ≤ (y - x) ^ 2 * (c + L * θ * (4 * y + (x + y))) / (x + y) := by
      apply div_nonneg (mul_nonneg (sq_nonneg _) (by nlinarith)) (by linarith)
    linarith
  exact ⟨hbr, hbr⟩

/-- Symmetric equilibrium effort of the convex-hazard game at `D = c = L = 1`, `θ = 0.4`. -/
noncomputable def cvxY0 : ℝ := (√(13 / 5) - 1) / (16 / 5)
/-- The same with the winner-only window `v_s = 0.5` (gap `1.5`). -/
noncomputable def cvxY1 : ℝ := (√(17 / 5) - 1) / (16 / 5)

/-- **P9, convex-hazard multiplier.** At `D = c = L = 1`, `θ = 0.4`, hazard `θX²`, winner-only
`v_s = 0.5`: `(cvxY0, cvxY0)` and `(cvxY1, cvxY1)` are Nash equilibria of the base and window
games, and the effort multiplier `cvxY1/cvxY0 = (√3.4 − 1)/(√2.6 − 1)` lies in
`(1.37785, 1.37795)` — so it prints as 1.3779, rounds to 1.38, and is not the linear `1.5`. -/
theorem p9_convex_multiplier :
    IsNE2 (payCvx 1 0 1 1 (2 / 5)) cvxY0 cvxY0 ∧ IsNE2 (payCvx (1 + 1 / 2) 0 1 1 (2 / 5)) cvxY1 cvxY1 ∧
      1.37785 < cvxY1 / cvxY0 ∧ cvxY1 / cvxY0 < 1.37795 ∧ cvxY1 / cvxY0 ≠ (1 + 1 / 2) / 1 := by
  have hs0 : √(13 / 5 : ℝ) ^ 2 = 13 / 5 := Real.sq_sqrt (by norm_num)
  have hs1 : √(17 / 5 : ℝ) ^ 2 = 17 / 5 := Real.sq_sqrt (by norm_num)
  have l0 : (1.612451 : ℝ) < √(13 / 5) := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  have u0 : √(13 / 5 : ℝ) < 1.612452 := by rw [Real.sqrt_lt' (by norm_num)]; norm_num
  have l1 : (1.843908 : ℝ) < √(17 / 5) := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  have u1 : √(17 / 5 : ℝ) < 1.843909 := by rw [Real.sqrt_lt' (by norm_num)]; norm_num
  have hy0 : 0 < cvxY0 := by unfold cvxY0; apply div_pos (by linarith) (by norm_num)
  have hy1 : 0 < cvxY1 := by unfold cvxY1; apply div_pos (by linarith) (by norm_num)
  have hratio : cvxY1 / cvxY0 = (√(17 / 5) - 1) / (√(13 / 5) - 1) := by
    unfold cvxY0 cvxY1; field_simp
  have hlo : 1.37785 < cvxY1 / cvxY0 := by
    rw [hratio, lt_div_iff₀ (by linarith)]; linarith
  have hhi : cvxY1 / cvxY0 < 1.37795 := by
    rw [hratio, div_lt_iff₀ (by linarith)]; linarith
  refine ⟨cvx_sym_ne hy0 (by norm_num) (by norm_num) ?_,
    cvx_sym_ne hy1 (by norm_num) (by norm_num) ?_, hlo, hhi, ?_⟩
  · unfold cvxY0; linear_combination (-5 / 8 : ℝ) * hs0
  · unfold cvxY1; linear_combination (-5 / 8 : ℝ) * hs1
  · intro h; rw [h] at hhi; norm_num at hhi

/-- Interior first-order condition of the convex-hazard game, derived from optimality:
`Δv·y/X² − c − 2LθX = 0`. -/
lemma cvx_foc {vW vL c L θ x y : ℝ} (hx : 0 < x) (hy : 0 < y)
    (h : IsBR (fun x' => payCvx vW vL c L θ x' y) x) :
    (vW - vL) * y / (x + y) ^ 2 - c - 2 * (L * θ) * (x + y) = 0 := by
  obtain ⟨-, hmax⟩ := h
  let g : ℝ → ℝ := fun x' =>
    vL + (vW - vL) * (x' / (x' + y)) - c * x' - L * θ * ((x' + y) * (x' + y))
  have hloc : IsLocalMax g x := by
    filter_upwards [Ioi_mem_nhds hx] with x' hx'
    have h1 := hmax x' (le_of_lt hx')
    simp only [payCvx] at h1
    rw [winProb_pos _ _ (by simp at hx'; linarith), winProb_pos _ _ (by linarith)] at h1
    have e : ∀ z, g z = z / (z + y) * vW + (1 - z / (z + y)) * vL - c * z - L * θ * (z + y) ^ 2 :=
      fun z => by simp only [g]; ring
    rw [e, e]; exact h1
  have h1 : HasDerivAt (fun x' : ℝ => x' + y) (1 + 0) x :=
    (hasDerivAt_id x).add_const y |>.congr_deriv (by simp)
  have h2 : HasDerivAt (fun x' : ℝ => x' / (x' + y)) ((1 * (x + y) - x * (1 + 0)) / (x + y) ^ 2) x :=
    (hasDerivAt_id x).div h1 (by linarith)
  have hd := (((h2.const_mul (vW - vL)).const_add vL).sub ((hasDerivAt_id' x).const_mul c)).sub
    ((h1.mul h1).const_mul (L * θ))
  have h0 := hloc.hasDerivAt_eq_zero hd
  have e : (1 * (x + y) - x * (1 + 0)) / (x + y) ^ 2 = y / (x + y) ^ 2 := by ring
  rw [e] at h0
  linear_combination h0

/-- **Uniqueness in the convex-hazard game** (`c > 0`, `Lθ ≥ 0`, which hold at the paper's
numbers): every pure equilibrium is symmetric, interior, and solves `Δv = 4cy + 16Lθy²`. Corners
are excluded as in `p9_i_nash_iff`; the interior first-order conditions force `x_i = x_j`. -/
lemma cvx_unique {vW vL c L θ a b : ℝ} (hdv : vL < vW) (hc : 0 < c) (hLθ : 0 ≤ L * θ)
    (h : IsNE2 (payCvx vW vL c L θ) a b) :
    a = b ∧ 0 < a ∧ vW - vL = 4 * c * a + 16 * (L * θ) * a ^ 2 := by
  obtain ⟨⟨ha0, hA⟩, ⟨hb0, hB⟩⟩ := h
  simp only at hA hB
  have hdv' : 0 < vW - vL := by linarith
  have hch : 0 < c + L * θ := by linarith
  rcases eq_or_lt_of_le ha0 with ha | ha <;> rcases eq_or_lt_of_le hb0 with hb | hb
  · exfalso
    subst ha; subst hb
    set ε := min 1 ((vW - vL) / (4 * (c + L * θ))) with hε
    have hε0 : 0 < ε := lt_min one_pos (by positivity)
    have hε1 : ε ≤ 1 := min_le_left _ _
    have hε2 : ε ≤ (vW - vL) / (4 * (c + L * θ)) := min_le_right _ _
    have hε2' : 4 * (c + L * θ) * ε ≤ vW - vL := by
      rw [le_div_iff₀ (by positivity)] at hε2; linarith
    have h := hA ε hε0.le
    simp only [payCvx, winProb_right_zero hε0, winProb_zero_zero] at h
    nlinarith [mul_le_mul_of_nonneg_left hε1 (mul_nonneg hLθ hε0.le)]
  · exfalso
    subst ha
    have h := hB (b / 2) (by linarith)
    simp only [payCvx, winProb_right_zero hb, winProb_right_zero (by linarith : 0 < b / 2)] at h
    nlinarith [mul_nonneg hLθ (sq_nonneg b)]
  · exfalso
    subst hb
    have h := hA (a / 2) (by linarith)
    simp only [payCvx, winProb_right_zero ha, winProb_right_zero (by linarith : 0 < a / 2)] at h
    nlinarith [mul_nonneg hLθ (sq_nonneg a)]
  · have f1 := cvx_foc ha hb ⟨ha0, hA⟩
    have f2 := cvx_foc hb ha ⟨hb0, hB⟩
    rw [show b + a = a + b by ring] at f2
    have hX : 0 < (a + b) ^ 2 := by positivity
    have hd : (vW - vL) * (b - a) / (a + b) ^ 2 = 0 := by linear_combination f1 - f2
    rcases div_eq_zero_iff.1 hd with h | h
    · rcases mul_eq_zero.1 h with h | h
      · linarith
      · have hab : a = b := by linarith
        subst hab
        refine ⟨rfl, ha, ?_⟩
        have key : (vW - vL) * a / (a + a) ^ 2 = (vW - vL) / (4 * a) := by field_simp; ring
        rw [key] at f1
        have h3 : (vW - vL) / (4 * a) = c + 4 * (L * θ) * a := by linarith
        rw [div_eq_iff (by positivity)] at h3
        linear_combination h3
    · linarith

lemma cvxY0_pos : 0 < cvxY0 := by
  unfold cvxY0
  have : (1.612451 : ℝ) < √(13 / 5) := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  apply div_pos (by linarith) (by norm_num)

lemma cvxY1_pos : 0 < cvxY1 := by
  unfold cvxY1
  have : (1.843908 : ℝ) < √(17 / 5) := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  apply div_pos (by linarith) (by norm_num)

lemma cvxY0_foc : (1 : ℝ) - 0 = 4 * 1 * cvxY0 + 16 * (1 * (2 / 5)) * cvxY0 ^ 2 := by
  have hs0 : √(13 / 5 : ℝ) ^ 2 = 13 / 5 := Real.sq_sqrt (by norm_num)
  unfold cvxY0; linear_combination (-5 / 8 : ℝ) * hs0

lemma cvxY1_foc : (1 + 1 / 2 : ℝ) - 0 = 4 * 1 * cvxY1 + 16 * (1 * (2 / 5)) * cvxY1 ^ 2 := by
  have hs1 : √(17 / 5 : ℝ) ^ 2 = 17 / 5 := Real.sq_sqrt (by norm_num)
  unfold cvxY1; linear_combination (-5 / 8 : ℝ) * hs1

/-- Two positive roots of `d = 4y + (32/5)y²` coincide. -/
lemma cvx_root_unique {d y y0 : ℝ} (hy : 0 < y) (hy0 : 0 < y0)
    (h : d = 4 * 1 * y + 16 * (1 * (2 / 5)) * y ^ 2)
    (h0 : d = 4 * 1 * y0 + 16 * (1 * (2 / 5)) * y0 ^ 2) : y = y0 := by
  have : (y - y0) * (4 + 32 / 5 * (y + y0)) = 0 := by linear_combination h0 - h
  rcases mul_eq_zero.1 this with h' | h'
  · linarith
  · nlinarith

/-- **P9, convex hazard: the equilibria are unique.** At `D = c = L = 1`, `θ = 0.4`, hazard
`θX²`, the base game's only pure equilibrium is `(cvxY0, cvxY0)` and the winner-only window
game's (`v_s = 0.5`) is `(cvxY1, cvxY1)`. So "the multiplier" of `p9_convex_multiplier` is the
ratio of the unique equilibria, not of two particular ones. -/
theorem p9_convex_unique (a b : ℝ) :
    (IsNE2 (payCvx 1 0 1 1 (2 / 5)) a b ↔ a = cvxY0 ∧ b = cvxY0) ∧
      (IsNE2 (payCvx (1 + 1 / 2) 0 1 1 (2 / 5)) a b ↔ a = cvxY1 ∧ b = cvxY1) := by
  obtain ⟨n0, n1, -⟩ := p9_convex_multiplier
  refine ⟨⟨fun h => ?_, fun ⟨ha, hb⟩ => ha ▸ hb ▸ n0⟩, ⟨fun h => ?_, fun ⟨ha, hb⟩ => ha ▸ hb ▸ n1⟩⟩
  · obtain ⟨hab, ha, hfoc⟩ := cvx_unique (by norm_num) (by norm_num) (by norm_num) h
    have := cvx_root_unique ha cvxY0_pos hfoc cvxY0_foc
    exact ⟨this, hab ▸ this⟩
  · obtain ⟨hab, ha, hfoc⟩ := cvx_unique (by norm_num) (by norm_num) (by norm_num) h
    have := cvx_root_unique ha cvxY1_pos hfoc cvxY1_foc
    exact ⟨this, hab ▸ this⟩

/-- **P9, convex hazard: the expected-loss index does not move by 1.38.** P9(ii) applies "the
multiplier" to effort *and* to the index. Under hazard `θX²` the index ratio
`θ(2y₁)²/(θ(2y₀)²)` is the square of the effort ratio and lies in `(1.8984, 1.8988)`, about 1.90.
So L967's "the multiplier is 1.38" holds for effort only. -/
theorem p9_convex_index_ratio :
    (2 / 5 : ℝ) * (cvxY1 + cvxY1) ^ 2 / ((2 / 5) * (cvxY0 + cvxY0) ^ 2) = (cvxY1 / cvxY0) ^ 2 ∧
      1.8984 < (cvxY1 / cvxY0) ^ 2 ∧ (cvxY1 / cvxY0) ^ 2 < 1.8988 := by
  obtain ⟨-, -, hlo, hhi, -⟩ := p9_convex_multiplier
  have hy0 := cvxY0_pos
  refine ⟨by field_simp, by nlinarith, by nlinarith⟩

/-! ## P10(i), the stage game and the joint optimum -/

/-- P10's stage game: racer `i` wins `D` with probability `x_i/X` (equal split at `X = 0`),
pays `c x_i` and bears `LθX`. It is P9 with `v_W = D`, `v_L = 0`. -/
noncomputable def stage (D c L θ : ℝ) : ℝ → ℝ → ℝ := pay D 0 c L θ

/-- The racers' joint payoff. -/
noncomputable def joint (D c L θ x y : ℝ) : ℝ := stage D c L θ x y + stage D c L θ y x

lemma joint_eq (D c L θ x y : ℝ) : joint D c L θ x y = D - (c + 2 * (L * θ)) * (x + y) := by
  have := winProb_add x y
  simp only [joint, stage, pay]
  linear_combination D * this

/-- **P10(i), equilibrium.** The stage game's unique pure equilibrium is `D/(4(c + Lθ)) > 0`. -/
theorem p10_i_equilibrium {D c L θ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ) (x y : ℝ) :
    (IsNE2 (stage D c L θ) x y ↔ x = D / (4 * (c + L * θ)) ∧ y = D / (4 * (c + L * θ))) ∧
      0 < D / (4 * (c + L * θ)) := by
  refine ⟨?_, by positivity⟩
  have := p9_i_nash_iff (vW := D) (vL := 0) (c := c) (L := L) (θ := θ) hD hc x y
  simpa [stage] using this

/-- **P10(i), joint optimum.** With `c + 2Lθ > 0`, the joint payoff `D − (c + 2Lθ)X` has the
unique maximiser `(0, 0)` over all nonnegative profiles. The hypothesis is implied by `c > 0`,
`L, θ ≥ 0` but not by the text's `c + Lθ > 0` (see `p10_i_joint_needs_hyp`). -/
theorem p10_i_joint_opt {D c L θ : ℝ} (h2 : 0 < c + 2 * (L * θ)) {x y : ℝ} (hx : 0 ≤ x)
    (hy : 0 ≤ y) (hne : ¬(x = 0 ∧ y = 0)) : joint D c L θ x y < joint D c L θ 0 0 := by
  rw [joint_eq, joint_eq]
  have : 0 < x + y := by
    by_contra h; push Not at h; exact hne ⟨by linarith, by linarith⟩
  nlinarith

/-- **P10(i): "adding outsiders' losses strengthens the result".** An outsiders' loss
`L_out θ X` with `L_out θ ≥ 0` keeps `(0, 0)` the unique maximiser, and widens zero effort's
margin over every profile. -/
theorem p10_i_joint_opt_outsiders {D c L θ Lout : ℝ} (h2 : 0 < c + 2 * (L * θ))
    (hout : 0 ≤ Lout * θ) {x y : ℝ} (hx : 0 ≤ x) (hy : 0 ≤ y) (hne : ¬(x = 0 ∧ y = 0)) :
    joint D c L θ x y - Lout * θ * (x + y) < joint D c L θ 0 0 - Lout * θ * (0 + 0) ∧
      joint D c L θ 0 0 - joint D c L θ x y ≤
        (joint D c L θ 0 0 - Lout * θ * (0 + 0)) - (joint D c L θ x y - Lout * θ * (x + y)) := by
  have := p10_i_joint_opt (D := D) h2 hx hy hne
  have : 0 ≤ Lout * θ * (x + y) := mul_nonneg hout (by linarith)
  simp only [add_zero, mul_zero, sub_zero]; constructor <;> linarith

/-- The extra hypothesis is needed: `c = 1`, `L = −0.6`, `θ = 1` satisfy the text's `c + Lθ > 0`,
yet positive joint effort beats zero. -/
theorem p10_i_joint_needs_hyp (D : ℝ) :
    0 < (1 : ℝ) + (-3 / 5) * 1 ∧ joint D 1 (-3 / 5) 1 0 0 < joint D 1 (-3 / 5) 1 (1 / 2) (1 / 2) := by
  refine ⟨by norm_num, ?_⟩
  rw [joint_eq, joint_eq]; norm_num

/-! ## P10(ii), quadratic cost and public value -/

/-- P10(ii)'s payoff: `D x_i/X − k x_i²/2 + bX − LθX` (equal split at `X = 0`). -/
noncomputable def payQ (D k b L θ xi xj : ℝ) : ℝ :=
  D * winProb xi xj - k * xi ^ 2 / 2 + b * (xi + xj) - L * θ * (xi + xj)

/-- The symmetric equilibrium effort `[b̃ + √(b̃² + kD)]/(2k)`. -/
noncomputable def xstarQ (D k bt : ℝ) : ℝ := (bt + √(bt ^ 2 + k * D)) / (2 * k)

/-- The per-racer joint optimum `max(2b̃/k, 0)`. -/
noncomputable def xcirc (k bt : ℝ) : ℝ := max (2 * bt / k) 0

/-- Joint payoff of P10(ii). -/
noncomputable def jointQ (D k b L θ x y : ℝ) : ℝ := payQ D k b L θ x y + payQ D k b L θ y x

lemma jointQ_eq (D k b L θ x y : ℝ) :
    jointQ D k b L θ x y = D + (-k * x ^ 2 / 2 + 2 * (b - L * θ) * x)
      + (-k * y ^ 2 / 2 + 2 * (b - L * θ) * y) := by
  have := winProb_add x y
  simp only [jointQ, payQ]
  linear_combination D * this

lemma xstarQ_pos {D k bt : ℝ} (hD : 0 < D) (hk : 0 < k) : 0 < xstarQ D k bt := by
  unfold xstarQ
  have : |bt| < √(bt ^ 2 + k * D) := by
    rw [← Real.sqrt_sq_eq_abs]; exact Real.sqrt_lt_sqrt (sq_nonneg _) (by nlinarith)
  have := neg_abs_le bt
  apply div_pos (by linarith) (by positivity)

lemma xstarQ_foc {D k bt : ℝ} (hD : 0 < D) (hk : 0 < k) :
    D = 4 * k * xstarQ D k bt ^ 2 - 4 * bt * xstarQ D k bt := by
  unfold xstarQ
  set S := √(bt ^ 2 + k * D) with hS_def
  have hs : S ^ 2 = bt ^ 2 + k * D := Real.sq_sqrt (by nlinarith)
  have : 4 * k * ((bt + S) / (2 * k)) ^ 2 - 4 * bt * ((bt + S) / (2 * k)) = (S ^ 2 - bt ^ 2) / k := by
    field_simp; ring
  rw [this, hs, show bt ^ 2 + k * D - bt ^ 2 = k * D by ring, mul_div_cancel_left₀ D hk.ne']

/-- A symmetric profile `(y, y)`, `y > 0`, meeting the first-order condition
`D = 4ky² − 4b̃y` is a Nash equilibrium of P10(ii) (global best responses). -/
theorem quad_sym_ne {D k b L θ y : ℝ} (hD : 0 < D) (hk : 0 < k) (hy : 0 < y)
    (hfoc : D = 4 * k * y ^ 2 - 4 * (b - L * θ) * y) : IsNE2 (payQ D k b L θ) y y := by
  have hbr : IsBR (fun x => payQ D k b L θ x y) y := by
    refine ⟨hy.le, fun x hx => ?_⟩
    simp only [payQ]
    rw [winProb_pos _ _ (by linarith), winProb_pos _ _ (by linarith)]
    have key : (D * (y / (y + y)) - k * y ^ 2 / 2 + b * (y + y) - L * θ * (y + y))
        - (D * (x / (x + y)) - k * x ^ 2 / 2 + b * (x + y) - L * θ * (x + y))
        = (y - x) ^ 2 * (D / (4 * y * (x + y)) + k / 2) := by
      have hb : b = (4 * k * y ^ 2 - D) / (4 * y) + L * θ := by field_simp; linarith
      rw [hb]; field_simp; ring
    have : 0 ≤ (y - x) ^ 2 * (D / (4 * y * (x + y)) + k / 2) := by
      apply mul_nonneg (sq_nonneg _); have : 0 ≤ D / (4 * y * (x + y)) := by
        apply div_nonneg hD.le; positivity
      linarith
    linarith
  exact ⟨hbr, hbr⟩

/-- **P10(ii), equilibrium.** `(x*, x*)`, `x* = [b̃ + √(b̃² + kD)]/(2k)`, is a Nash equilibrium. -/
theorem p10_ii_equilibrium {D k b L θ : ℝ} (hD : 0 < D) (hk : 0 < k) :
    IsNE2 (payQ D k b L θ) (xstarQ D k (b - L * θ)) (xstarQ D k (b - L * θ)) :=
  quad_sym_ne hD hk (xstarQ_pos hD hk) (xstarQ_foc hD hk)

/-- **P10(ii), uniqueness among symmetric profiles.** Every symmetric pure equilibrium is
`(x*, x*)`: `(0, 0)` is not one, and an interior symmetric one meets the first-order condition. -/
theorem p10_ii_sym_unique {D k b L θ y : ℝ} (hD : 0 < D) (hk : 0 < k)
    (h : IsNE2 (payQ D k b L θ) y y) : y = xstarQ D k (b - L * θ) := by
  set bt := b - L * θ with hbt
  obtain ⟨⟨hy0, hmax⟩, -⟩ := h
  rcases eq_or_lt_of_le hy0 with hy | hy
  · exfalso
    subst hy
    set m := k + |bt| + 1 with hm
    have hm0 : 0 < m := by have := abs_nonneg bt; linarith
    set ε := min 1 (D / (2 * m)) with hε
    have hε0 : 0 < ε := lt_min one_pos (by positivity)
    have hε1 : ε ≤ 1 := min_le_left _ _
    have hε2 : ε ≤ D / (2 * m) := min_le_right _ _
    have hε2' : 2 * m * ε ≤ D := by rw [le_div_iff₀ (by positivity)] at hε2; linarith
    have h := hmax ε hε0.le
    simp only [payQ, winProb_right_zero hε0, winProb_zero_zero] at h
    have habs : -bt ≤ |bt| := neg_le_abs bt
    nlinarith [mul_le_mul_of_nonneg_left hε1 (mul_nonneg hk.le hε0.le),
      mul_le_mul_of_nonneg_right habs hε0.le]
  · -- interior: the derivative of the own payoff vanishes at `y`.
    let g : ℝ → ℝ := fun x => D * (x / (x + y)) - k * x ^ 2 / 2 + b * (x + y) - L * θ * (x + y)
    have hloc : IsLocalMax g y := by
      filter_upwards [Ioi_mem_nhds hy] with x hx
      have h1 := hmax x (le_of_lt hx)
      simp only [payQ] at h1
      rw [winProb_pos _ _ (by simp at hx; linarith), winProb_pos _ _ (by linarith)] at h1
      exact h1
    have hd : HasDerivAt g (D * ((1 * (y + y) - y * (1 + 0)) / (y + y) ^ 2) - k * (2 * y ^ 1 * 1) / 2
        + b * (1 + 0) - L * θ * (1 + 0)) y := by
      have h1 : HasDerivAt (fun x : ℝ => x + y) (1 + 0) y := (hasDerivAt_id y).add_const y |>.congr_deriv (by simp)
      have h2 : HasDerivAt (fun x : ℝ => x / (x + y)) ((1 * (y + y) - y * (1 + 0)) / (y + y) ^ 2) y :=
        (hasDerivAt_id y).div h1 (by linarith)
      have h3 : HasDerivAt (fun x : ℝ => x ^ 2) (2 * y ^ 1 * 1) y := by
        simpa using hasDerivAt_pow 2 y
      exact (((h2.const_mul D).sub ((h3.const_mul k).div_const 2)).add (h1.const_mul b)).sub
        (h1.const_mul (L * θ))
    have h0 := hloc.hasDerivAt_eq_zero hd
    have hfoc : D = 4 * k * y ^ 2 - 4 * bt * y := by
      field_simp at h0; rw [hbt]; nlinarith [h0]
    -- solve the quadratic for its positive root
    have hS : 0 ≤ bt ^ 2 + k * D := by nlinarith
    have hsq : (2 * k * y - bt) ^ 2 = bt ^ 2 + k * D := by rw [hfoc]; ring
    have hpos : 0 ≤ 2 * k * y - bt := by
      have : bt * y < k * y ^ 2 := by nlinarith
      have : bt < k * y := by nlinarith
      nlinarith
    have : 2 * k * y - bt = √(bt ^ 2 + k * D) := by
      rw [← hsq, Real.sqrt_sq hpos]
    unfold xstarQ; field_simp; linarith

/-- Interior first-order condition of P10(ii) for an arbitrary (possibly asymmetric) profile. -/
lemma quad_foc {D k b L θ x y : ℝ} (hx : 0 < x) (hy : 0 < y)
    (h : IsBR (fun x' => payQ D k b L θ x' y) x) :
    D * y / (x + y) ^ 2 - k * x + (b - L * θ) = 0 := by
  obtain ⟨-, hmax⟩ := h
  let g : ℝ → ℝ := fun x' => D * (x' / (x' + y)) - k * x' ^ 2 / 2 + b * (x' + y) - L * θ * (x' + y)
  have hloc : IsLocalMax g x := by
    filter_upwards [Ioi_mem_nhds hx] with x' hx'
    have h1 := hmax x' (le_of_lt hx')
    simp only [payQ] at h1
    rw [winProb_pos _ _ (by simp at hx'; linarith), winProb_pos _ _ (by linarith)] at h1
    exact h1
  have hd : HasDerivAt g (D * ((1 * (x + y) - x * (1 + 0)) / (x + y) ^ 2) - k * (2 * x ^ 1 * 1) / 2
      + b * (1 + 0) - L * θ * (1 + 0)) x := by
    have h1 : HasDerivAt (fun x' : ℝ => x' + y) (1 + 0) x :=
      (hasDerivAt_id x).add_const y |>.congr_deriv (by simp)
    have h2 : HasDerivAt (fun x' : ℝ => x' / (x' + y)) ((1 * (x + y) - x * (1 + 0)) / (x + y) ^ 2) x :=
      (hasDerivAt_id x).div h1 (by linarith)
    have h3 : HasDerivAt (fun x' : ℝ => x' ^ 2) (2 * x ^ 1 * 1) x := by
      simpa using hasDerivAt_pow 2 x
    exact (((h2.const_mul D).sub ((h3.const_mul k).div_const 2)).add (h1.const_mul b)).sub
      (h1.const_mul (L * θ))
  have h0 := hloc.hasDerivAt_eq_zero hd
  have e : (1 * (x + y) - x * (1 + 0)) / (x + y) ^ 2 = y / (x + y) ^ 2 := by ring
  rw [e] at h0
  have e2 : D * (y / (x + y) ^ 2) = D * y / (x + y) ^ 2 := by ring
  rw [e2] at h0
  linear_combination h0

/-- No corner profile `(0, v)`, `v > 0`, is an equilibrium of P10(ii). -/
lemma quad_corner {D k b L θ v : ℝ} (hD : 0 < D) (hk : 0 < k) (hv : 0 < v)
    (h1 : ∀ x', 0 ≤ x' → payQ D k b L θ x' v ≤ payQ D k b L θ 0 v)
    (h2 : ∀ x', 0 ≤ x' → payQ D k b L θ x' 0 ≤ payQ D k b L θ v 0) : False := by
  rcases lt_or_ge (b - L * θ) 0 with hb | hb
  · have h := h2 (v / 2) (by linarith)
    simp only [payQ, winProb_right_zero hv, winProb_right_zero (by linarith : 0 < v / 2)] at h
    nlinarith [mul_pos hk (mul_pos hv hv), mul_neg_of_neg_of_pos hb hv]
  · set ε := min v (D / (2 * k * v)) with hε
    have hε0 : 0 < ε := lt_min hv (by positivity)
    have hεv : ε ≤ v := min_le_left _ _
    have hεk : ε ≤ D / (2 * k * v) := min_le_right _ _
    have hεk' : 2 * k * v * ε ≤ D := by rw [le_div_iff₀ (by positivity)] at hεk; linarith
    have h := h1 ε hε0.le
    simp only [payQ, winProb_left_zero hv] at h
    rw [winProb_pos _ _ (by linarith)] at h
    have hfrac : D * ε / (2 * v) ≤ D * (ε / (ε + v)) := by
      rw [mul_div_assoc]
      apply mul_le_mul_of_nonneg_left _ hD.le
      apply div_le_div_of_nonneg_left hε0.le (by linarith) (by linarith)
    have hgain : 0 < D * ε / (2 * v) - k * ε ^ 2 / 2 := by
      have : D * ε / (2 * v) - k * ε ^ 2 / 2 = ε * (D - k * v * ε) / (2 * v) := by
        field_simp
      rw [this]; apply div_pos (mul_pos hε0 (by nlinarith)) (by positivity)
    nlinarith [mul_nonneg hb hε0.le]

/-- **P10(ii), uniqueness.** `(x*, x*)` is the **only** pure equilibrium: corners are excluded,
and subtracting the two interior first-order conditions gives `(y − x)(D/X² + k) = 0`. So "the
equilibrium" of P10(ii) is well defined. -/
theorem p10_ii_unique {D k b L θ x y : ℝ} (hD : 0 < D) (hk : 0 < k)
    (h : IsNE2 (payQ D k b L θ) x y) :
    x = xstarQ D k (b - L * θ) ∧ y = xstarQ D k (b - L * θ) := by
  obtain ⟨⟨hx0, hA⟩, ⟨hy0, hB⟩⟩ := h
  rcases eq_or_lt_of_le hx0 with hx | hx <;> rcases eq_or_lt_of_le hy0 with hy | hy
  · subst hx; subst hy
    have := p10_ii_sym_unique hD hk ⟨⟨le_rfl, hA⟩, ⟨le_rfl, hB⟩⟩
    exact absurd this (ne_of_lt (xstarQ_pos hD hk))
  · subst hx; exact (quad_corner hD hk hy hA hB).elim
  · subst hy; exact (quad_corner hD hk hx hB hA).elim
  · have f1 := quad_foc hx hy ⟨hx0, hA⟩
    have f2 := quad_foc hy hx ⟨hy0, hB⟩
    have hxy : 0 < x + y := by linarith
    have hX : 0 < (x + y) ^ 2 := by positivity
    have : (y - x) * (D / (x + y) ^ 2 + k) = 0 := by
      rw [show (y + x) = (x + y) by ring] at f2
      have : D * y / (x + y) ^ 2 - D * x / (x + y) ^ 2 = (y - x) * (D / (x + y) ^ 2) := by ring
      linear_combination f1 - f2
    have hpos : 0 < D / (x + y) ^ 2 + k := by positivity
    have hxy' : x = y := by
      rcases mul_eq_zero.1 this with h | h
      · linarith
      · linarith
    subst hxy'
    have := p10_ii_sym_unique hD hk ⟨⟨hx0, hA⟩, ⟨hy0, hB⟩⟩
    exact ⟨this, this⟩

lemma phi_strict {k bt a : ℝ} (hk : 0 < k) (ha : 0 ≤ a) (hne : a ≠ xcirc k bt) :
    -k * a ^ 2 / 2 + 2 * bt * a < -k * xcirc k bt ^ 2 / 2 + 2 * bt * xcirc k bt := by
  unfold xcirc at *
  rcases le_or_gt bt 0 with h | h
  · have hx : max (2 * bt / k) 0 = 0 := max_eq_right (div_nonpos_of_nonpos_of_nonneg (by linarith) hk.le)
    rw [hx] at hne ⊢
    have : 0 < a := lt_of_le_of_ne ha (Ne.symm hne)
    have h1 : 0 < k * a ^ 2 := by positivity
    have h2 := mul_le_mul_of_nonneg_right h ha
    simp only [zero_mul] at h2
    norm_num; nlinarith
  · have hx : max (2 * bt / k) 0 = 2 * bt / k := max_eq_left (by positivity)
    rw [hx] at hne ⊢
    have key : -k * (2 * bt / k) ^ 2 / 2 + 2 * bt * (2 * bt / k) - (-k * a ^ 2 / 2 + 2 * bt * a)
        = k / 2 * (a - 2 * bt / k) ^ 2 := by field_simp; ring
    have : 0 < k / 2 * (a - 2 * bt / k) ^ 2 := by
      apply mul_pos (by positivity); have : a - 2 * bt / k ≠ 0 := sub_ne_zero.2 hne; positivity
    linarith

/-- **P10(ii), joint optimum.** Over all nonnegative profiles, the joint payoff has the unique
maximiser `(x°, x°)`, `x° = max(2b̃/k, 0)`. -/
theorem p10_ii_joint_opt {D k b L θ x y : ℝ} (hk : 0 < k) (hx : 0 ≤ x) (hy : 0 ≤ y)
    (hne : ¬(x = xcirc k (b - L * θ) ∧ y = xcirc k (b - L * θ))) :
    jointQ D k b L θ x y < jointQ D k b L θ (xcirc k (b - L * θ)) (xcirc k (b - L * θ)) := by
  rw [jointQ_eq, jointQ_eq]
  have le : ∀ a, 0 ≤ a → -k * a ^ 2 / 2 + 2 * (b - L * θ) * a
      ≤ -k * xcirc k (b - L * θ) ^ 2 / 2 + 2 * (b - L * θ) * xcirc k (b - L * θ) := by
    intro a ha
    by_cases h : a = xcirc k (b - L * θ)
    · rw [h]
    · exact (phi_strict hk ha h).le
  by_cases h : x = xcirc k (b - L * θ)
  · have hy' : y ≠ xcirc k (b - L * θ) := fun h' => hne ⟨h, h'⟩
    have := phi_strict hk hy hy'; have := le x hx; linarith
  · have := phi_strict hk hx h; have := le y hy; linarith

/-- **P10(ii), over-racing.** `x* > x°` iff `D > 8 max(b̃, 0)²/k`. -/
theorem p10_ii_over_iff {D k bt : ℝ} (hD : 0 < D) (hk : 0 < k) :
    xcirc k bt < xstarQ D k bt ↔ 8 * max bt 0 ^ 2 / k < D := by
  have hs0 : 0 ≤ √(bt ^ 2 + k * D) := Real.sqrt_nonneg _
  have hs : √(bt ^ 2 + k * D) ^ 2 = bt ^ 2 + k * D := Real.sq_sqrt (by nlinarith)
  rcases le_or_gt bt 0 with h | h
  · rw [xcirc, max_eq_right (div_nonpos_of_nonpos_of_nonneg (by linarith) hk.le),
      max_eq_right h]
    simp only [ne_eq, OfNat.ofNat_ne_zero, not_false_eq_true, zero_pow, mul_zero, zero_div]
    exact ⟨fun _ => hD, fun _ => xstarQ_pos hD hk⟩
  · rw [xcirc, max_eq_left (by positivity), max_eq_left h.le, xstarQ]
    have hk2 : (0:ℝ) < 2 * k := by positivity
    rw [div_lt_div_iff₀ hk hk2, div_lt_iff₀ hk]
    constructor
    · intro h1
      have h3 : 3 * bt < √(bt ^ 2 + k * D) := by nlinarith
      nlinarith [mul_self_lt_mul_self (by positivity : (0:ℝ) ≤ 3 * bt) h3]
    · intro h1
      have h3 : 3 * bt < √(bt ^ 2 + k * D) := by
        rw [Real.lt_sqrt (by linarith)]; nlinarith
      nlinarith [mul_lt_mul_of_pos_right h3 hk]

/-- **P10(ii), under-racing.** If `b̃ > 0` and `D < 8b̃²/k`, then `x* < x°`. -/
theorem p10_ii_under {D k bt : ℝ} (hk : 0 < k) (hbt : 0 < bt)
    (hDlt : D < 8 * bt ^ 2 / k) : xstarQ D k bt < xcirc k bt := by
  have hs0 : 0 ≤ √(bt ^ 2 + k * D) := Real.sqrt_nonneg _
  have : √(bt ^ 2 + k * D) < 3 * bt := by
    rw [Real.sqrt_lt' (by linarith)]; rw [lt_div_iff₀ hk] at hDlt; nlinarith
  rw [xcirc, max_eq_left (by positivity), xstarQ, div_lt_div_iff₀ (by positivity) hk]
  nlinarith

/-- Any joint maximiser of P10(ii) over nonnegative profiles is `(x°, x°)`. -/
lemma jointQ_argmax {D k b L θ u v : ℝ} (hk : 0 < k) (hu : 0 ≤ u) (hv : 0 ≤ v)
    (hopt : ∀ x' y', 0 ≤ x' → 0 ≤ y' → jointQ D k b L θ x' y' ≤ jointQ D k b L θ u v) :
    u = xcirc k (b - L * θ) ∧ v = xcirc k (b - L * θ) := by
  by_contra hne
  have hc0 : 0 ≤ xcirc k (b - L * θ) := le_max_right _ _
  have := p10_ii_joint_opt (D := D) hk hu hv hne
  have := hopt _ _ hc0 hc0
  linarith

/-- **P10(ii), over-racing, stated for the game.** If `(x, y)` is any pure equilibrium and
`(u, v)` any joint maximiser, both are symmetric and the equilibrium over-races (`u < x`) **iff**
`D > 8 max(b̃, 0)²/k`. -/
theorem p10_ii_over_game {D k b L θ x y u v : ℝ} (hD : 0 < D) (hk : 0 < k)
    (hNE : IsNE2 (payQ D k b L θ) x y) (hu : 0 ≤ u) (hv : 0 ≤ v)
    (hopt : ∀ x' y', 0 ≤ x' → 0 ≤ y' → jointQ D k b L θ x' y' ≤ jointQ D k b L θ u v) :
    x = y ∧ u = v ∧ (u < x ↔ 8 * max (b - L * θ) 0 ^ 2 / k < D) := by
  obtain ⟨hx, hy⟩ := p10_ii_unique hD hk hNE
  obtain ⟨hu', hv'⟩ := jointQ_argmax hk hu hv hopt
  refine ⟨hx.trans hy.symm, hu'.trans hv'.symm, ?_⟩
  rw [hx, hu']; exact p10_ii_over_iff hD hk

/-- **P10(ii), under-racing, stated for the game.** If `b̃ > 0` and `D < 8b̃²/k`, every pure
equilibrium effort is below every joint maximiser's. -/
theorem p10_ii_under_game {D k b L θ x y u v : ℝ} (hD : 0 < D) (hk : 0 < k)
    (hbt : 0 < b - L * θ) (hDlt : D < 8 * (b - L * θ) ^ 2 / k)
    (hNE : IsNE2 (payQ D k b L θ) x y) (hu : 0 ≤ u) (hv : 0 ≤ v)
    (hopt : ∀ x' y', 0 ≤ x' → 0 ≤ y' → jointQ D k b L θ x' y' ≤ jointQ D k b L θ u v) :
    x < u ∧ y < v := by
  obtain ⟨hx, hy⟩ := p10_ii_unique hD hk hNE
  obtain ⟨hu', hv'⟩ := jointQ_argmax hk hu hv hopt
  have := p10_ii_under hk hbt hDlt
  rw [hx, hy, hu', hv']; exact ⟨this, this⟩

/-- **P10(ii), the under-racing example** (`b = 0.5`, `Lθ = 0.2`, `k = 1`, `D = 0.36`):
threshold `8b̃²/k = 0.72`, equilibrium effort in `(0.4854, 0.4855)` (prints 0.485), optimum
`0.6`, and the equilibrium under-races. -/
theorem p10_ii_example :
    8 * ((1 / 2 : ℝ) - 1 * (1 / 5)) ^ 2 / 1 = 0.72 ∧
      0.4854 < xstarQ 0.36 1 (1 / 2 - 1 * (1 / 5)) ∧ xstarQ 0.36 1 (1 / 2 - 1 * (1 / 5)) < 0.4855 ∧
      xcirc 1 (1 / 2 - 1 * (1 / 5)) = 0.6 ∧
      xstarQ 0.36 1 (1 / 2 - 1 * (1 / 5)) < xcirc 1 (1 / 2 - 1 * (1 / 5)) := by
  have e : ((1 / 2 : ℝ) - 1 * (1 / 5)) ^ 2 + 1 * 0.36 = 0.45 := by norm_num
  have l : (0.6708 : ℝ) < √0.45 := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  have u : √(0.45 : ℝ) < 0.6709 := by rw [Real.sqrt_lt' (by norm_num)]; norm_num
  have hc : xcirc 1 (1 / 2 - 1 * (1 / 5)) = 0.6 := by
    rw [xcirc, max_eq_left (by norm_num)]; norm_num
  refine ⟨by norm_num, ?_, ?_, hc, ?_⟩
  · rw [xstarQ, e]; linarith
  · rw [xstarQ, e]; linarith
  · rw [hc, xstarQ, e]; linarith

/-! ## P10(iii), the repeated game

The repeated game is represented by the **expected discounted payoff streams** of the strategies
the paper's proof compares, each defined period by period from the stage game: restraint on
path; a one-shot deviation to any effort `e ≥ 0` against a restrained rival; and a stationary
deviation (effort `e` every period until detected). Detection has probability `ν` after each
period with a deviation, there are no false alarms, and detection triggers permanent reversion to
the stage equilibrium from the next period. What is *not* formalised is the one-shot deviation
principle itself (that checking these deviations suffices for all strategies of the infinite
game); the stationary-deviation theorem shows the threshold is the same for that larger class. -/

/-- Expected discounted value `∑_t ϱ^t f(t)` of a per-period expected payoff stream. -/
noncomputable def disc (ϱ : ℝ) (f : ℕ → ℝ) : ℝ := ∑' t, ϱ ^ t * f t

/-- Restraint's stage payoff `U_C` (both at zero, equal split). -/
noncomputable def UC (D c L θ : ℝ) : ℝ := stage D c L θ 0 0

/-- The stage equilibrium's payoff `U_N`, evaluated at the equilibrium of P10(i). -/
noncomputable def UN (D c L θ : ℝ) : ℝ :=
  stage D c L θ (D / (4 * (c + L * θ))) (D / (4 * (c + L * θ)))

/-- On path: restraint in every period. -/
noncomputable def restraintStream (D c L θ : ℝ) : ℕ → ℝ := fun _ => UC D c L θ

/-- One-shot deviation to effort `e > 0` in period 0, then back on path; from period 1 the
expected stage payoff is `ν U_N + (1 − ν) U_C`. Effort `e = 0` is no deviation and, with no false
alarms, carries no detection risk: its stream is restraint's. -/
noncomputable def oneShotStream (D c L θ ν e : ℝ) : ℕ → ℝ := fun t =>
  if e = 0 then UC D c L θ
  else if t = 0 then stage D c L θ e 0 else ν * UN D c L θ + (1 - ν) * UC D c L θ

/-- Stationary deviation: effort `e > 0` in every period until detected, which has not happened
by period `t` with probability `(1 − ν)^t`. At `e = 0` it is restraint (no false alarms). -/
noncomputable def statStream (D c L θ ν e : ℝ) : ℕ → ℝ := fun t =>
  if e = 0 then UC D c L θ
  else (1 - ν) ^ t * stage D c L θ e 0 + (1 - (1 - ν) ^ t) * UN D c L θ

lemma oneShot_zero (D c L θ ν : ℝ) : oneShotStream D c L θ ν 0 = restraintStream D c L θ := by
  funext t; simp [oneShotStream, restraintStream]

lemma stat_zero (D c L θ ν : ℝ) : statStream D c L θ ν 0 = restraintStream D c L θ := by
  funext t; simp [statStream, restraintStream]

/-- The detection threshold `ν* = ((1 − ϱ)/ϱ)·2(c + Lθ)/(c + 2Lθ)`. -/
noncomputable def nuStar (ϱ c L θ : ℝ) : ℝ :=
  (1 - ϱ) / ϱ * (2 * (c + L * θ) / (c + 2 * (L * θ)))

lemma UC_eq (D c L θ : ℝ) : UC D c L θ = D / 2 := by
  simp only [UC, stage, pay, winProb_zero_zero]; ring

lemma UN_eq {D c L θ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ) :
    UN D c L θ = D / 2 - (c + 2 * (L * θ)) * (D / (4 * (c + L * θ))) := by
  unfold UN stage pay
  have : 0 < D / (4 * (c + L * θ)) := by positivity
  rw [winProb_pos _ _ (by linarith)]; field_simp; ring

lemma stage_dev {D c L θ e : ℝ} (he : 0 < e) : stage D c L θ e 0 = D - (c + L * θ) * e := by
  simp only [stage, pay, winProb_right_zero he]; ring

lemma disc_const {ϱ : ℝ} (h0 : 0 ≤ ϱ) (h1 : ϱ < 1) (a : ℝ) :
    disc ϱ (fun _ => a) = a / (1 - ϱ) := by
  unfold disc; rw [tsum_mul_right, tsum_geometric_of_lt_one h0 h1, div_eq_inv_mul]

lemma disc_oneShot {D c L θ ν e ϱ : ℝ} (h0 : 0 ≤ ϱ) (h1 : ϱ < 1) (he : e ≠ 0) :
    disc ϱ (oneShotStream D c L θ ν e)
      = stage D c L θ e 0 + ϱ * (ν * UN D c L θ + (1 - ν) * UC D c L θ) / (1 - ϱ) := by
  set B := ν * UN D c L θ + (1 - ν) * UC D c L θ
  set A := stage D c L θ e 0
  have hB := (hasSum_geometric_of_lt_one h0 h1).mul_right B
  have hI := hasSum_ite_eq (0 : ℕ) (A - B)
  have hsum := hB.add hI
  have hfun : (fun t => ϱ ^ t * oneShotStream D c L θ ν e t)
      = fun t => ϱ ^ t * B + (if t = 0 then A - B else 0) := by
    funext t; rcases t with _ | n <;> simp [oneShotStream, he, A, B]
  unfold disc; rw [hfun, hsum.tsum_eq]
  have : (1 - ϱ) ≠ 0 := by linarith
  field_simp; ring

lemma disc_stat {D c L θ ν e ϱ : ℝ} (h0 : 0 ≤ ϱ) (h1 : ϱ < 1) (hν0 : 0 ≤ ν) (hν1 : ν ≤ 1)
    (he : e ≠ 0) :
    disc ϱ (statStream D c L θ ν e)
      = (stage D c L θ e 0 - UN D c L θ) / (1 - ϱ * (1 - ν)) + UN D c L θ / (1 - ϱ) := by
  set A := stage D c L θ e 0
  set N := UN D c L θ
  have hr0 : 0 ≤ ϱ * (1 - ν) := mul_nonneg h0 (by linarith)
  have hr1 : ϱ * (1 - ν) < 1 := by nlinarith
  have h1' := (hasSum_geometric_of_lt_one hr0 hr1).mul_right (A - N)
  have h2' := (hasSum_geometric_of_lt_one h0 h1).mul_right N
  have hsum := h1'.add h2'
  have hfun : (fun t => ϱ ^ t * statStream D c L θ ν e t)
      = fun t => (ϱ * (1 - ν)) ^ t * (A - N) + ϱ ^ t * N := by
    funext t; simp only [statStream, he, ite_false, mul_pow, A, N]; ring
  unfold disc; rw [hfun, hsum.tsum_eq]
  have : (1 - ϱ) ≠ 0 := by linarith
  have : (1 - ϱ * (1 - ν)) ≠ 0 := by linarith
  field_simp

/-- Against a restrained rival, the best gain over `D/2` is approached but never reached:
every positive effort gains at most `M` iff `D/2 ≤ M`. -/
lemma gain_iff {D c L θ M : ℝ} (hc : 0 < c + L * θ) :
    (∀ e, 0 < e → stage D c L θ e 0 - D / 2 ≤ M) ↔ D / 2 ≤ M := by
  constructor
  · intro h
    by_contra hlt; push Not at hlt
    set e := (D / 2 - M) / (2 * (c + L * θ)) with he_def
    have he : 0 < e := div_pos (by linarith) (by linarith)
    have h1 := h e he
    rw [stage_dev he] at h1
    have : (c + L * θ) * e = (D / 2 - M) / 2 := by rw [he_def]; field_simp
    linarith
  · intro h e he; rw [stage_dev he]; nlinarith [mul_pos hc he]

lemma M_alg (D A B ϱ ν : ℝ) (hA : A ≠ 0) (hB : B ≠ 0) (hϱ : ϱ ≠ 0) (h1 : 1 - ϱ ≠ 0) :
    ϱ * ν * (D / 2 - (D / 2 - B * (D / (4 * A)))) / (1 - ϱ) - D / 2
      = D * B * ϱ / (4 * A * (1 - ϱ)) * (ν - (1 - ϱ) / ϱ * (2 * A / B)) := by
  field_simp; ring

lemma M_iff {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ) (h2 : 0 < c + 2 * (L * θ))
    (h0 : 0 < ϱ) (h1 : ϱ < 1) :
    D / 2 ≤ ϱ * ν * (UC D c L θ - UN D c L θ) / (1 - ϱ) ↔ nuStar ϱ c L θ ≤ ν := by
  have h1' : 0 < 1 - ϱ := by linarith
  set K := D * (c + 2 * (L * θ)) * ϱ / (4 * (c + L * θ) * (1 - ϱ)) with hK
  have hKpos : 0 < K := by positivity
  have key : ϱ * ν * (UC D c L θ - UN D c L θ) / (1 - ϱ) - D / 2 = K * (ν - nuStar ϱ c L θ) := by
    rw [UC_eq, UN_eq hD hc, hK, nuStar]
    exact M_alg D (c + L * θ) (c + 2 * (L * θ)) ϱ ν hc.ne' h2.ne' h0.ne' h1'.ne'
  constructor
  · intro h
    have : 0 ≤ K * (ν - nuStar ϱ c L θ) := by linarith
    have := (mul_nonneg_iff_of_pos_left hKpos).1 this; linarith
  · intro h
    have : 0 ≤ K * (ν - nuStar ϱ c L θ) := mul_nonneg hKpos.le (by linarith)
    linarith

lemma oneShot_diff {D c L θ ν e ϱ : ℝ} (h0 : 0 ≤ ϱ) (h1 : ϱ < 1) (he : e ≠ 0) :
    disc ϱ (oneShotStream D c L θ ν e) - disc ϱ (restraintStream D c L θ)
      = (stage D c L θ e 0 - D / 2) - ϱ * ν * (UC D c L θ - UN D c L θ) / (1 - ϱ) := by
  rw [disc_oneShot h0 h1 he, show restraintStream D c L θ = fun _ => UC D c L θ from rfl, disc_const h0 h1, ← UC_eq D c L θ]
  have : (1 - ϱ) ≠ 0 := by linarith
  field_simp; ring

/-- **P10(iii), the restraint condition** (one-shot deviations). Restraint is worth at least
every one-shot deviation `e > 0` (and trivially the non-deviation `e = 0`) **iff** `ν ≥ ν*`.
Hypotheses: the text's `0 < ϱ < 1`, `D > 0`, `c + Lθ > 0`, plus `c + 2Lθ > 0` (implied by
`c > 0`, `L, θ ≥ 0`), without which `ν*` is undefined or of the wrong sign. -/
theorem p10_iii_restraint_iff {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (h2 : 0 < c + 2 * (L * θ)) (h0 : 0 < ϱ) (h1 : ϱ < 1) :
    (∀ e, 0 ≤ e → disc ϱ (oneShotStream D c L θ ν e) ≤ disc ϱ (restraintStream D c L θ)) ↔
      nuStar ϱ c L θ ≤ ν := by
  rw [← M_iff hD hc h2 h0 h1]
  constructor
  · intro h
    rw [← gain_iff hc]
    intro e he
    have := h e he.le
    have := oneShot_diff (D := D) (c := c) (L := L) (θ := θ) (ν := ν) h0.le h1 he.ne'
    linarith
  · intro hM e he
    rcases eq_or_lt_of_le he with rfl | he'
    · rw [oneShot_zero]
    · have hd := oneShot_diff (D := D) (c := c) (L := L) (θ := θ) (ν := ν) h0.le h1 he'.ne'
      have := (gain_iff hc).2 hM e he'; linarith

/-- **P10(iii), stationary deviations** give the same threshold (`0 ≤ ν ≤ 1`). -/
theorem p10_iii_stationary_iff {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (h2 : 0 < c + 2 * (L * θ)) (h0 : 0 < ϱ) (h1 : ϱ < 1) (hν0 : 0 ≤ ν) (hν1 : ν ≤ 1) :
    (∀ e, 0 ≤ e → disc ϱ (statStream D c L θ ν e) ≤ disc ϱ (restraintStream D c L θ)) ↔
      nuStar ϱ c L θ ≤ ν := by
  have hden : 0 < 1 - ϱ * (1 - ν) := by nlinarith
  have h1' : 0 < 1 - ϱ := by linarith
  have hd : ∀ e, e ≠ 0 → disc ϱ (statStream D c L θ ν e) - disc ϱ (restraintStream D c L θ)
      = ((stage D c L θ e 0 - D / 2) - ϱ * ν * (UC D c L θ - UN D c L θ) / (1 - ϱ))
        / (1 - ϱ * (1 - ν)) := by
    intro e he
    rw [disc_stat h0.le h1 hν0 hν1 he, show restraintStream D c L θ = fun _ => UC D c L θ from rfl, disc_const h0.le h1, ← UC_eq D c L θ]
    field_simp; ring
  have hsign : ∀ e, e ≠ 0 →
      (disc ϱ (statStream D c L θ ν e) ≤ disc ϱ (restraintStream D c L θ) ↔
        (stage D c L θ e 0 - D / 2) - ϱ * ν * (UC D c L θ - UN D c L θ) / (1 - ϱ) ≤ 0) := by
    intro e he
    rw [← sub_nonpos, hd e he, div_le_iff₀ hden, zero_mul]
  rw [← M_iff hD hc h2 h0 h1]
  constructor
  · intro h
    rw [← gain_iff hc]
    intro e he; have := (hsign e he.ne').1 (h e he.le); linarith
  · intro hM e he
    rcases eq_or_lt_of_le he with rfl | he'
    · rw [stat_zero]
    · refine (hsign e he'.ne').2 ?_
      have := (gain_iff hc).2 hM e he'; linarith

/-- **P10(iii), the punishment is credible**: reversion plays the stage equilibrium, a Nash
equilibrium of every period's game, worth `U_N = D/2 − (c + 2Lθ)x*`. -/
theorem p10_iii_punishment {D c L θ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ) :
    IsNE2 (stage D c L θ) (D / (4 * (c + L * θ))) (D / (4 * (c + L * θ))) ∧
      UN D c L θ = D / 2 - (c + 2 * (L * θ)) * (D / (4 * (c + L * θ))) :=
  ⟨((p10_i_equilibrium hD hc _ _).1).2 ⟨rfl, rfl⟩, UN_eq hD hc⟩

lemma nuStar_pos {c L θ ϱ : ℝ} (hc : 0 < c + L * θ) (h2 : 0 < c + 2 * (L * θ)) (h0 : 0 < ϱ)
    (h1 : ϱ < 1) : 0 < nuStar ϱ c L θ := by
  unfold nuStar; apply mul_pos (div_pos (by linarith) h0) (div_pos (by linarith) h2)

/-- A positive threshold already forces `c + 2Lθ > 0`: if `c + 2Lθ ≤ 0`, then `ν* ≤ 0`. So the
text's own premises `ν* > 1` and `ν = ν*/2 > 0` supply the hypothesis `c + 2Lθ > 0`. -/
lemma h2_of_nuStar_pos {c L θ ϱ : ℝ} (hc : 0 < c + L * θ) (h0 : 0 < ϱ) (h1 : ϱ < 1)
    (hpos : 0 < nuStar ϱ c L θ) : 0 < c + 2 * (L * θ) := by
  by_contra hle; push Not at hle
  have hq : 2 * (c + L * θ) / (c + 2 * (L * θ)) ≤ 0 :=
    div_nonpos_of_nonneg_of_nonpos (by linarith) hle
  have hr : 0 < (1 - ϱ) / ϱ := div_pos (by linarith) h0
  have : nuStar ϱ c L θ ≤ 0 := mul_nonpos_of_nonneg_of_nonpos hr.le hq
  linarith

/-- **P10(iii): `ν* > 1` exactly when `ϱ < 2(c + Lθ)/(2(c + Lθ) + c + 2Lθ)`**, i.e. for small `ϱ`. -/
theorem p10_iii_nustar_gt_one_iff {c L θ ϱ : ℝ} (hc : 0 < c + L * θ) (h2 : 0 < c + 2 * (L * θ))
    (h0 : 0 < ϱ) :
    1 < nuStar ϱ c L θ ↔ ϱ < 2 * (c + L * θ) / (2 * (c + L * θ) + (c + 2 * (L * θ))) := by
  have e : nuStar ϱ c L θ = (1 - ϱ) * (2 * (c + L * θ)) / (ϱ * (c + 2 * (L * θ))) := by
    unfold nuStar; field_simp
  rw [e, one_lt_div (by positivity), lt_div_iff₀ (by linarith)]
  constructor <;> intro h <;> nlinarith

/-- **P10(iii): "as for small `ϱ`"** — there is `ϱ₀ ∈ (0, 1)` below which `ν* > 1`. -/
theorem p10_iii_small_rho {c L θ : ℝ} (hc : 0 < c + L * θ) (h2 : 0 < c + 2 * (L * θ)) :
    ∃ ϱ₀, 0 < ϱ₀ ∧ ϱ₀ < 1 ∧ ∀ ϱ, 0 < ϱ → ϱ < ϱ₀ → 1 < nuStar ϱ c L θ := by
  refine ⟨2 * (c + L * θ) / (2 * (c + L * θ) + (c + 2 * (L * θ))), by positivity, ?_, ?_⟩
  · rw [div_lt_one (by positivity)]; linarith
  · intro ϱ h0 h; exact (p10_iii_nustar_gt_one_iff hc h2 h0).2 h

/-- **P10(iii): when `ν* > 1` no detection technology (`ν ≤ 1`) supports restraint.** Only the
text's hypotheses: `ν* > 1` itself forces `c + 2Lθ > 0` (if `c + 2Lθ ≤ 0`, then `ν* ≤ 0`). -/
theorem p10_iii_no_technology {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (h0 : 0 < ϱ) (h1 : ϱ < 1) (hgt : 1 < nuStar ϱ c L θ) (hν : ν ≤ 1) :
    ¬ ∀ e, 0 ≤ e → disc ϱ (oneShotStream D c L θ ν e) ≤ disc ϱ (restraintStream D c L θ) := by
  have h2 := h2_of_nuStar_pos hc h0 h1 (by linarith)
  rw [p10_iii_restraint_iff hD hc h2 h0 h1]; linarith

/-- **P10(iii): under full secrecy (`ν = 0`) restraint fails.** Only the text's hypotheses: the
effort `D/(4(c + Lθ))` gains `D/4` and is never detected. -/
theorem p10_iii_secrecy_fails {D c L θ ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (h0 : 0 < ϱ) (h1 : ϱ < 1) :
    ¬ ∀ e, 0 ≤ e → disc ϱ (oneShotStream D c L θ 0 e) ≤ disc ϱ (restraintStream D c L θ) := by
  intro h
  have he : 0 < D / (4 * (c + L * θ)) := by positivity
  have h' := h _ he.le
  have hd := oneShot_diff (D := D) (c := c) (L := L) (θ := θ) (ν := 0) h0.le h1 he.ne'
  rw [stage_dev he] at hd
  have : (c + L * θ) * (D / (4 * (c + L * θ))) = D / 4 := by field_simp
  simp only [mul_zero, zero_mul, zero_div, sub_zero] at hd
  linarith

/-- **P10, "verification is sufficient" refuted**: at `ν = ν*/2 > 0` some deviation `e > 0`
strictly pays. -/
theorem p10_iii_half_nustar {D c L θ ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (h2 : 0 < c + 2 * (L * θ)) (h0 : 0 < ϱ) (h1 : ϱ < 1) :
    0 < nuStar ϱ c L θ / 2 ∧ ∃ e, 0 < e ∧
      disc ϱ (restraintStream D c L θ) < disc ϱ (oneShotStream D c L θ (nuStar ϱ c L θ / 2) e) := by
  have hp := nuStar_pos hc h2 h0 h1
  refine ⟨by linarith, ?_⟩
  by_contra h; push Not at h
  have := (p10_iii_restraint_iff (ν := nuStar ϱ c L θ / 2) hD hc h2 h0 h1).1
    (fun e he => by
      rcases eq_or_lt_of_le he with rfl | he'
      · rw [oneShot_zero]
      · exact h e he')
  linarith

/-- A concrete case where `ν = ν*/2` is a genuine probability: `c = 1`, `Lθ = 0`, `ϱ = 0.9`
gives `ν* = 2/9`, so `ν = 1/9`. -/
theorem p10_iii_half_example : nuStar (9 / 10) 1 0 0 = 2 / 9 := by unfold nuStar; norm_num

/-- **Figure 22's bounds.** For `c ≥ 0`, `Lθ ≥ 0` (and `c + Lθ > 0`) the factor
`2(c + Lθ)/(c + 2Lθ)` lies in `[1, 2]`, so `ν* > 1` whenever `ϱ < 1/2`. -/
theorem p10_fig22_bounds {c L θ ϱ : ℝ} (hc0 : 0 ≤ c) (hLθ : 0 ≤ L * θ) (hc : 0 < c + L * θ)
    (h0 : 0 < ϱ) :
    1 ≤ 2 * (c + L * θ) / (c + 2 * (L * θ)) ∧ 2 * (c + L * θ) / (c + 2 * (L * θ)) ≤ 2 ∧
      (ϱ < 1 / 2 → 1 < nuStar ϱ c L θ) := by
  have h2 : 0 < c + 2 * (L * θ) := by linarith
  refine ⟨by rw [le_div_iff₀ h2]; linarith, by rw [div_le_iff₀ h2]; linarith, fun hϱ => ?_⟩
  rw [p10_iii_nustar_gt_one_iff hc h2 h0, lt_div_iff₀ (by positivity)]; nlinarith

/-- **Figure 22, `Lθ = 0`**: `ν* > 1` iff `ϱ < 2/3`. -/
theorem p10_fig22_zero_loss {c ϱ : ℝ} (hc : 0 < c) (h0 : 0 < ϱ) :
    1 < nuStar ϱ c 0 0 ↔ ϱ < 2 / 3 := by
  rw [p10_iii_nustar_gt_one_iff (by simpa using hc) (by simpa using hc) h0]
  rw [show 2 * (c + 0 * 0) / (2 * (c + 0 * 0) + (c + 2 * (0 * 0))) = 2 / 3 by field_simp; ring]

/-- **Figure 22, the endpoints of the factor** `f = 2(c + Lθ)/(c + 2Lθ)`, with `r = Lθ`.
(a) For `c > 0`, `f` depends on `Lθ` and `c` only through `t = Lθ/c`: `f = 2(1 + t)/(1 + 2t)`.
(b) `2(1 + t)/(1 + 2t) → 1` as `t → ∞`: the value 1 "as `Lθ/c → ∞`".
(c) At `Lθ = 0`, `c > 0`: `f = 2`. (d) At `c = 0`, `Lθ > 0`: `f = 1` (attained). -/
theorem p10_fig22_limits :
    (∀ c r : ℝ, 0 < c → 0 < c + 2 * r →
        2 * (c + r) / (c + 2 * r) = 2 * (1 + r / c) / (1 + 2 * (r / c))) ∧
      Filter.Tendsto (fun t : ℝ => 2 * (1 + t) / (1 + 2 * t)) Filter.atTop (nhds 1) ∧
      (∀ c : ℝ, 0 < c → 2 * (c + 0) / (c + 2 * 0) = 2) ∧
      (∀ r : ℝ, 0 < r → 2 * (0 + r) / (0 + 2 * r) = 1) := by
  refine ⟨fun c r hc h2 => ?_, ?_, fun c hc => ?_, fun r hr => ?_⟩
  · have hc' := hc.ne'
    have h2' := h2.ne'
    have e1 : 1 + r / c = (c + r) / c := by field_simp
    have e2 : 1 + 2 * (r / c) = (c + 2 * r) / c := by field_simp
    rw [e1, e2]; field_simp
  · have h : Filter.Tendsto (fun t : ℝ => 1 + 2 * t) Filter.atTop Filter.atTop :=
      Filter.tendsto_atTop_add_const_left _ 1
        (Filter.Tendsto.const_mul_atTop (by norm_num) Filter.tendsto_id)
    have h' := (tendsto_const_nhds (x := (1 : ℝ))).add h.inv_tendsto_atTop
    rw [add_zero] at h'
    refine h'.congr' ?_
    filter_upwards [Filter.eventually_gt_atTop 0] with t ht
    have : 1 + 2 * t ≠ 0 := by linarith
    rw [Pi.inv_apply]
    field_simp
    ring
  · rw [add_zero, mul_zero, add_zero, mul_div_assoc, div_self hc.ne', mul_one]
  · rw [zero_add, zero_add, div_self (by positivity)]

/-- P10(iii)'s one-shot race with sanction `Q` on detection (probability `ν`, only after a
deviation, i.e. positive effort). -/
noncomputable def stageS (D c L θ ν Q x y : ℝ) : ℝ :=
  stage D c L θ x y - if 0 < x then ν * Q else 0

/-- **P10(iii), one-shot sanction.** Restraint `(0, 0)` is a Nash equilibrium of the one-shot race
with an expected sanction `νQ_det` **iff** `νQ_det ≥ D/2`. -/
theorem p10_iii_sanction_iff {D c L θ ν Q : ℝ} (hc : 0 < c + L * θ) :
    IsNE2 (stageS D c L θ ν Q) 0 0 ↔ D / 2 ≤ ν * Q := by
  have h00 : stageS D c L θ ν Q 0 0 = D / 2 := by
    simp only [stageS, lt_irrefl, ite_false, sub_zero]; exact UC_eq D c L θ
  have hBR : IsBR (fun x => stageS D c L θ ν Q x 0) 0 ↔ D / 2 ≤ ν * Q := by
    rw [← gain_iff hc]
    constructor
    · rintro ⟨-, h⟩ e he
      have := h e he.le
      simp only at this; rw [h00] at this
      simp only [stageS, he, ite_true] at this; linarith
    · intro h
      refine ⟨le_rfl, fun e he => ?_⟩
      simp only [h00]
      rcases eq_or_lt_of_le he with rfl | he'
      · exact h00.le
      · simp only [stageS, he', ite_true]; have := h e he'; linarith
  exact ⟨fun h => hBR.1 h.1, fun h => ⟨hBR.2 h, hBR.2 h⟩⟩

/-! ## P10(iv), bounds and best responses -/

/-- **P10(iv), dominance bound.** Any contest rule awarding `D > 0` with probability `p(x) ∈ [0,1]`,
linear cost `cx` with `c > 0`, and a loss term `ℓ` that does not fall with own effort: every
`x > D/c` earns strictly less than `x = 0`. (`K` collects terms not depending on own effort.) -/
theorem p10_iv_dominance {D c K : ℝ} (p ℓ : ℝ → ℝ) (hp : ∀ x, 0 ≤ p x ∧ p x ≤ 1)
    (hℓ : MonotoneOn ℓ (Set.Ici 0)) (hD : 0 < D) (hc : 0 < c) {x : ℝ} (hx : D / c < x) :
    p x * D - c * x - ℓ x + K < p 0 * D - c * 0 - ℓ 0 + K := by
  have hx0 : 0 ≤ x := le_trans (div_nonneg hD.le hc.le) hx.le
  have hℓx : ℓ 0 ≤ ℓ x := hℓ (Set.mem_Ici.2 le_rfl) (Set.mem_Ici.2 hx0) hx0
  have hcx : D < c * x := by rw [div_lt_iff₀ hc] at hx; linarith
  have := hp x; have := hp 0
  nlinarith

/-- **P10(iv), the payoff-gain bound** (A.6 L1132, Fig. 21 L432): for every effort `x ≥ 0`,
`u(x) − u(0) ≤ D − cx − p(0)D + ℓ(0) − ℓ(x) ≤ D − cx`. No sign on `c` is needed. -/
theorem p10_iv_gain_bound {D c K : ℝ} (p ℓ : ℝ → ℝ) (hp : ∀ x, 0 ≤ p x ∧ p x ≤ 1)
    (hℓ : MonotoneOn ℓ (Set.Ici 0)) (hD : 0 < D) {x : ℝ} (hx : 0 ≤ x) :
    (p x * D - c * x - ℓ x + K) - (p 0 * D - c * 0 - ℓ 0 + K)
        ≤ D - c * x - p 0 * D + ℓ 0 - ℓ x ∧
      D - c * x - p 0 * D + ℓ 0 - ℓ x ≤ D - c * x := by
  have hℓx : ℓ 0 ≤ ℓ x := hℓ (Set.mem_Ici.2 le_rfl) (Set.mem_Ici.2 hx) hx
  have h1 := mul_nonneg (sub_nonneg.2 (hp x).2) hD.le
  have h2 := mul_nonneg (hp 0).1 hD.le
  constructor <;> nlinarith

/-- **P10(iv): a cost that merely rises need not exclude any effort.** Tullock rule, rival
`y > 0`, no loss term, strictly rising cost `(D/2)(1 − e^{−x})`: every `x ≥ y` beats `x = 0`. -/
theorem p10_iv_rising_cost {D y : ℝ} (hD : 0 < D) (hy : 0 < y) :
    StrictMono (fun x : ℝ => D / 2 * (1 - Real.exp (-x))) ∧
      ∀ x, y ≤ x → D * winProb 0 y - D / 2 * (1 - Real.exp (-0))
        < D * winProb x y - D / 2 * (1 - Real.exp (-x)) := by
  refine ⟨fun a b hab => ?_, fun x hx => ?_⟩
  · have := Real.exp_lt_exp.2 (neg_lt_neg hab); simp only; nlinarith
  · rw [winProb_left_zero hy, winProb_pos _ _ (by linarith)]
    have h1 : 1 / 2 ≤ x / (x + y) := by
      rw [div_le_div_iff₀ (by norm_num) (by linarith)]; linarith
    have h2 := Real.exp_pos (-x)
    simp only [neg_zero, Real.exp_zero, sub_self, mul_zero]
    nlinarith

/-- **P10(iv): "→ D/2 > 0 as x → ∞"** for the rising-cost example. -/
theorem p10_iv_rising_cost_limit {D y : ℝ} (hy : 0 < y) :
    Filter.Tendsto (fun x => D * winProb x y - D / 2 * (1 - Real.exp (-x))
      - (D * winProb 0 y - D / 2 * (1 - Real.exp (-0)))) Filter.atTop (nhds (D / 2)) := by
  have h1 : Filter.Tendsto (fun x : ℝ => x / (x + y)) Filter.atTop (nhds 1) := by
    have h0 : Filter.Tendsto (fun x : ℝ => y / (x + y)) Filter.atTop (nhds 0) :=
      Filter.Tendsto.div_atTop tendsto_const_nhds
        (Filter.tendsto_atTop_add_const_right _ y Filter.tendsto_id)
    have h := (tendsto_const_nhds (x := (1 : ℝ))).sub h0
    rw [sub_zero] at h
    refine h.congr' ?_
    filter_upwards [Filter.eventually_gt_atTop 0] with x hx
    have hxy : x + y ≠ 0 := by linarith
    rw [one_sub_div hxy, add_sub_cancel_right]
  have h2 : Filter.Tendsto (fun x : ℝ => Real.exp (-x)) Filter.atTop (nhds 0) :=
    Real.tendsto_exp_neg_atTop_nhds_zero
  have hlim : D * 1 - D / 2 * (1 - 0) - (D * 0 - D / 2 * (1 - 1)) = D / 2 := by ring
  have T := ((h1.const_mul D).sub (((tendsto_const_nhds (x := (1 : ℝ))).sub h2).const_mul (D / 2))).sub
    (tendsto_const_nhds (x := D * 0 - D / 2 * (1 - 1)) (f := Filter.atTop))
  rw [hlim] at T
  refine T.congr' ?_
  filter_upwards [Filter.eventually_gt_atTop 0] with x hx
  rw [winProb_pos _ _ (by linarith), winProb_left_zero hy, neg_zero, Real.exp_zero]

/-- **P10(iv): the best response** to rival effort `y > 0` in the stage game is exactly
`BR(y) = max{0, √(Δv·y/ĉ) − y}` with `Δv = D`, `ĉ = c + Lθ`. -/
theorem p10_iv_br {D c L θ y x : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ) (hy : 0 < y) :
    IsBR (fun x' => stage D c L θ x' y) x ↔ x = br D (c + L * θ) y := by
  have := isBR_iff (vW := D) (vL := 0) (c := c) (L := L) (θ := θ) (x := x) hD hc hy
  simpa [stage] using this

lemma br_zero_at {D ch : ℝ} (hD : 0 < D) (hch : 0 < ch) : br D ch (D / ch) = 0 := by
  unfold br
  rw [show D * (D / ch) / ch = (D / ch) ^ 2 by ring, Real.sqrt_sq (by positivity), sub_self,
    max_self]

/-- **P10(iv): no effort is dominant** — none is a best response to every positive rival effort —
and **against `y = 0` no best response exists.** -/
theorem p10_iv_no_dominant {D c L θ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ) :
    (¬ ∃ e, ∀ y, 0 < y → IsBR (fun x => stage D c L θ x y) e) ∧
      ∀ e, ¬ IsBR (fun x => stage D c L θ x 0) e := by
  refine ⟨?_, ?_⟩
  · rintro ⟨e, he⟩
    have xs0 : 0 < D / (4 * (c + L * θ)) := by positivity
    have h1 := (p10_iv_br hD hc xs0).1 (he _ xs0)
    have h2 := (p10_iv_br hD hc (by positivity)).1 (he (D / (c + L * θ)) (by positivity))
    rw [br_xstar hD hc] at h1; rw [br_zero_at hD hc] at h2
    linarith
  · rintro e ⟨he0, hmax⟩
    rcases eq_or_lt_of_le he0 with rfl | he
    · have xs0 : 0 < D / (4 * (c + L * θ)) := by positivity
      have h := hmax _ xs0.le
      simp only [stage, pay, winProb_right_zero xs0, winProb_zero_zero] at h
      have : D / (4 * (c + L * θ)) * (c + L * θ) = D / 4 := by field_simp
      nlinarith
    · have h := hmax (e / 2) (by linarith)
      simp only [stage, pay, winProb_right_zero he, winProb_right_zero (by linarith : 0 < e / 2)] at h
      nlinarith

lemma br_branch {D ch y : ℝ} (hch : 0 < ch) (hy : 0 < y) (hy1 : y ≤ D / ch) :
    br D ch y = √(D * y / ch) - y := by
  have hyc : y * ch ≤ D := (le_div_iff₀ hch).1 hy1
  have hD : 0 < D := by nlinarith [mul_pos hy hch]
  unfold br
  apply max_eq_right
  have : y ≤ √(D * y / ch) := by
    rw [Real.le_sqrt' hy, le_div_iff₀ hch]; nlinarith
  linarith

/-- Facts about `u = √(D·y/ĉ)` for `0 < y < x* = D/(4ĉ)`. -/
lemma u_facts {D ch y : ℝ} (hD : 0 < D) (hch : 0 < ch) (hy : 0 < y) (hy1 : y < D / (4 * ch)) :
    √(D * y / ch) ^ 2 = D * y / ch ∧ 2 * y < √(D * y / ch) ∧ √(D * y / ch) < D / (2 * ch) ∧
      y = ch * √(D * y / ch) ^ 2 / D := by
  have hsq : √(D * y / ch) ^ 2 = D * y / ch := Real.sq_sqrt (by positivity)
  have h4 : 4 * ch * y < D := by rw [lt_div_iff₀ (by positivity)] at hy1; linarith
  refine ⟨hsq, ?_, ?_, ?_⟩
  · rw [Real.lt_sqrt (by linarith), lt_div_iff₀ hch]; nlinarith
  · rw [Real.sqrt_lt' (by positivity), div_pow, lt_div_iff₀ (by positivity)]
    field_simp; nlinarith
  · rw [hsq]; field_simp

lemma le_of_lt_xstar {D ch y : ℝ} (hD : 0 < D) (hch : 0 < ch) (hy : y < D / (4 * ch)) :
    y ≤ D / ch := by
  have : D / (4 * ch) ≤ D / ch := div_le_div_of_nonneg_left hD.le hch (by linarith)
  linarith

/-- **P10(iv): `BR` rises on `(0, x*)`.** -/
theorem p10_iv_br_strictMono {D ch : ℝ} (hD : 0 < D) (hch : 0 < ch) :
    StrictMonoOn (br D ch) (Set.Ioo 0 (D / (4 * ch))) := by
  intro y1 hy1 y2 hy2 hlt
  rw [br_branch hch hy1.1 (le_of_lt_xstar hD hch hy1.2),
    br_branch hch hy2.1 (le_of_lt_xstar hD hch hy2.2)]
  obtain ⟨-, -, hu1, e1⟩ := u_facts hD hch hy1.1 hy1.2
  obtain ⟨-, -, hu2, e2⟩ := u_facts hD hch hy2.1 hy2.2
  have hu : √(D * y1 / ch) < √(D * y2 / ch) := by
    have := hy1.1
    apply Real.sqrt_lt_sqrt (by positivity)
    apply div_lt_div_of_pos_right _ hch; nlinarith
  set u1 := √(D * y1 / ch)
  set u2 := √(D * y2 / ch)
  have key : (u2 - ch * u2 ^ 2 / D) - (u1 - ch * u1 ^ 2 / D)
      = (u2 - u1) * (D - ch * (u1 + u2)) / D := by
    field_simp; ring
  have hpos : 0 < (u2 - u1) * (D - ch * (u1 + u2)) / D := by
    apply div_pos (mul_pos (by linarith) ?_) hD
    have := (lt_div_iff₀ (by positivity : (0:ℝ) < 2 * ch)).1 hu1
    have := (lt_div_iff₀ (by positivity : (0:ℝ) < 2 * ch)).1 hu2
    nlinarith
  have : u2 - y2 - (u1 - y1) = (u2 - ch * u2 ^ 2 / D) - (u1 - ch * u1 ^ 2 / D) := by
    nth_rewrite 1 [e2]; nth_rewrite 1 [e1]; ring
  linarith

/-- **P10(iv): `x̄ < BR(x̄) < x*` for `0 < x̄ < x*`.** -/
theorem p10_iv_cap_br {D ch xb : ℝ} (hD : 0 < D) (hch : 0 < ch) (h0 : 0 < xb)
    (h1 : xb < D / (4 * ch)) : xb < br D ch xb ∧ br D ch xb < D / (4 * ch) := by
  rw [br_branch hch h0 (le_of_lt_xstar hD hch h1)]
  obtain ⟨-, h2, hu, e⟩ := u_facts hD hch h0 h1
  refine ⟨by linarith, ?_⟩
  set u := √(D * xb / ch)
  have key : D / (4 * ch) - (u - ch * u ^ 2 / D) = ch / D * (u - D / (2 * ch)) ^ 2 := by
    field_simp; ring
  have : 0 < ch / D * (u - D / (2 * ch)) ^ 2 := by
    apply mul_pos (by positivity)
    have : u - D / (2 * ch) ≠ 0 := by linarith
    positivity
  have : u - xb = u - ch * u ^ 2 / D := by nth_rewrite 1 [e]; ring
  linarith

/-- **P10(iv), a unilateral cap.** With `0 < x̄ < x*` and the rival at `BR(x̄)`: total effort is
`√(Δv·x̄/ĉ) < 2x*`, and the capper wins with probability `√(ĉx̄/Δv) < 1/2`. -/
theorem p10_iv_cap_total {D ch xb : ℝ} (hD : 0 < D) (hch : 0 < ch) (h0 : 0 < xb)
    (h1 : xb < D / (4 * ch)) :
    xb + br D ch xb = √(D * xb / ch) ∧ √(D * xb / ch) < 2 * (D / (4 * ch)) ∧
      winProb xb (br D ch xb) = √(ch * xb / D) ∧ √(ch * xb / D) < 1 / 2 := by
  obtain ⟨hsq, h2, hu, -⟩ := u_facts hD hch h0 h1
  have htot : xb + br D ch xb = √(D * xb / ch) := by
    rw [br_branch hch h0 (le_of_lt_xstar hD hch h1)]; ring
  have hupos : 0 < √(D * xb / ch) := by linarith
  have hwin : winProb xb (br D ch xb) = xb / √(D * xb / ch) := by
    rw [winProb_pos _ _ (by rw [htot]; exact hupos.ne'), htot]
  have hroot : √(ch * xb / D) = xb / √(D * xb / ch) := by
    rw [← Real.sqrt_sq (div_nonneg h0.le hupos.le)]
    congr 1
    rw [div_pow, hsq]; field_simp
  refine ⟨htot, by rw [show 2 * (D / (4 * ch)) = D / (2 * ch) by field_simp; ring]; exact hu,
    by rw [hwin, hroot], ?_⟩
  rw [hroot, div_lt_iff₀ hupos]; linarith

/-- **P10(iv): total effort under a cap rises in `x̄` on `(0, x*)`.** -/
theorem p10_iv_cap_total_mono {D ch : ℝ} (hD : 0 < D) (hch : 0 < ch) :
    StrictMonoOn (fun xb => xb + br D ch xb) (Set.Ioo 0 (D / (4 * ch))) := by
  intro a ha b hb hab
  simp only [(p10_iv_cap_total hD hch ha.1 ha.2).1, (p10_iv_cap_total hD hch hb.1 hb.2).1]
  have := ha.1
  apply Real.sqrt_lt_sqrt (by positivity)
  apply div_lt_div_of_pos_right _ hch; nlinarith

/-! ### P10(iv) restated for the stage game: `br` is the rival's actual best response -/

/-- **P10(iv): `BR` rises on `(0, x*)`, for the game's best responses.** -/
theorem p10_iv_br_rises_game {D c L θ a b za zb : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (ha : a ∈ Set.Ioo 0 (D / (4 * (c + L * θ)))) (hb : b ∈ Set.Ioo 0 (D / (4 * (c + L * θ))))
    (hab : a < b) (hza : IsBR (fun x => stage D c L θ x a) za)
    (hzb : IsBR (fun x => stage D c L θ x b) zb) : za < zb := by
  rw [(p10_iv_br hD hc ha.1).1 hza, (p10_iv_br hD hc hb.1).1 hzb]
  exact p10_iv_br_strictMono hD hc ha hb hab

/-- **P10(iv), a unilateral cap, for the game.** With `0 < x̄ < x*` and the rival at **any** best
response `z` to `x̄` in the stage game: `z = BR(x̄)`, `x̄ < z < x*`, total effort
`x̄ + z = √(Δv·x̄/ĉ) < 2x*`, and the capper wins with probability `√(ĉx̄/Δv) < 1/2`. -/
theorem p10_iv_cap_game {D c L θ xb z : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ) (h0 : 0 < xb)
    (h1 : xb < D / (4 * (c + L * θ))) (hz : IsBR (fun x => stage D c L θ x xb) z) :
    z = br D (c + L * θ) xb ∧ xb < z ∧ z < D / (4 * (c + L * θ)) ∧
      xb + z = √(D * xb / (c + L * θ)) ∧ √(D * xb / (c + L * θ)) < 2 * (D / (4 * (c + L * θ))) ∧
      winProb xb z = √((c + L * θ) * xb / D) ∧ √((c + L * θ) * xb / D) < 1 / 2 := by
  have hzb := (p10_iv_br hD hc h0).1 hz
  obtain ⟨a1, a2⟩ := p10_iv_cap_br hD hc h0 h1
  obtain ⟨t1, t2, t3, t4⟩ := p10_iv_cap_total hD hc h0 h1
  subst hzb
  exact ⟨rfl, a1, a2, t1, t2, t3, t4⟩

/-- **P10(iv): total effort under a cap rises in `x̄`, with the rival at its best response.** -/
theorem p10_iv_cap_game_mono {D c L θ a b za zb : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (ha : a ∈ Set.Ioo 0 (D / (4 * (c + L * θ)))) (hb : b ∈ Set.Ioo 0 (D / (4 * (c + L * θ))))
    (hab : a < b) (hza : IsBR (fun x => stage D c L θ x a) za)
    (hzb : IsBR (fun x => stage D c L θ x b) zb) : a + za < b + zb := by
  rw [(p10_iv_br hD hc ha.1).1 hza, (p10_iv_br hD hc hb.1).1 hzb]
  exact p10_iv_cap_total_mono hD hc ha hb hab

end RTTR.Contest

#print axioms RTTR.Contest.br_strict
#print axioms RTTR.Contest.br_le
#print axioms RTTR.Contest.isBR_iff
#print axioms RTTR.Contest.p9_i_nash_iff
#print axioms RTTR.Contest.p9_i_nplayer_nash_iff
#print axioms RTTR.Contest.p9_ii_window
#print axioms RTTR.Contest.p9_ii_winner_only
#print axioms RTTR.Contest.p9_ii_shared
#print axioms RTTR.Contest.p9_ii_loser_share
#print axioms RTTR.Contest.p9_iii_deltaW
#print axioms RTTR.Contest.p9_iii_harm_iff
#print axioms RTTR.Contest.p9_escalation_rises
#print axioms RTTR.Contest.p9_escalation_thresholds
#print axioms RTTR.Contest.p9_counterexample_shared
#print axioms RTTR.Contest.p9_counterexample_winner_only
#print axioms RTTR.Contest.p9_winner_only_rises
#print axioms RTTR.Contest.cvx_sym_ne
#print axioms RTTR.Contest.p9_convex_multiplier
#print axioms RTTR.Contest.p10_i_equilibrium
#print axioms RTTR.Contest.p10_i_joint_opt
#print axioms RTTR.Contest.p10_i_joint_opt_outsiders
#print axioms RTTR.Contest.p10_i_joint_needs_hyp
#print axioms RTTR.Contest.quad_sym_ne
#print axioms RTTR.Contest.p10_ii_equilibrium
#print axioms RTTR.Contest.p10_ii_sym_unique
#print axioms RTTR.Contest.p10_ii_unique
#print axioms RTTR.Contest.p10_ii_joint_opt
#print axioms RTTR.Contest.p10_ii_over_iff
#print axioms RTTR.Contest.p10_ii_under
#print axioms RTTR.Contest.p10_ii_example
#print axioms RTTR.Contest.p10_iii_restraint_iff
#print axioms RTTR.Contest.p10_iii_stationary_iff
#print axioms RTTR.Contest.p10_iii_punishment
#print axioms RTTR.Contest.p10_iii_nustar_gt_one_iff
#print axioms RTTR.Contest.p10_iii_small_rho
#print axioms RTTR.Contest.p10_iii_no_technology
#print axioms RTTR.Contest.p10_iii_secrecy_fails
#print axioms RTTR.Contest.p10_iii_half_nustar
#print axioms RTTR.Contest.p10_iii_half_example
#print axioms RTTR.Contest.p10_fig22_bounds
#print axioms RTTR.Contest.p10_fig22_zero_loss
#print axioms RTTR.Contest.p10_iii_sanction_iff
#print axioms RTTR.Contest.p10_iv_dominance
#print axioms RTTR.Contest.p10_iv_rising_cost
#print axioms RTTR.Contest.p10_iv_rising_cost_limit
#print axioms RTTR.Contest.p10_iv_br
#print axioms RTTR.Contest.p10_iv_no_dominant
#print axioms RTTR.Contest.p10_iv_br_strictMono
#print axioms RTTR.Contest.p10_iv_cap_br
#print axioms RTTR.Contest.p10_iv_cap_total
#print axioms RTTR.Contest.p10_iv_cap_total_mono
#print axioms RTTR.Contest.p9_ii_winner_only_raises
#print axioms RTTR.Contest.cvx_foc
#print axioms RTTR.Contest.cvx_unique
#print axioms RTTR.Contest.p9_convex_unique
#print axioms RTTR.Contest.p9_convex_index_ratio
#print axioms RTTR.Contest.p10_ii_over_game
#print axioms RTTR.Contest.p10_ii_under_game
#print axioms RTTR.Contest.p10_fig22_limits
#print axioms RTTR.Contest.p10_iv_gain_bound
#print axioms RTTR.Contest.p10_iv_br_rises_game
#print axioms RTTR.Contest.p10_iv_cap_game
#print axioms RTTR.Contest.p10_iv_cap_game_mono
#print axioms RTTR.Contest.h2_of_nuStar_pos
