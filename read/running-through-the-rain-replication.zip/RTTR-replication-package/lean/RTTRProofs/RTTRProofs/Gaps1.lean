import Mathlib

/-!
# GAP1: loss-index and window readings, Appendix B scope claims, the P8 rebuild remark

Paper: `PAPER-DRAFT-v8.md`. Rows (inventory `LEAN/INV-RTTR.md`): A7, A8, B24, B25 (A.2.2,
line 841; body line 96), A9, B93 (A.2.3, line 851; body line 292), X1 (B-S2, line 1178),
X2 (B-S5, line 1181), X3 and B116 (B-S6, line 1182; body lines 334, 396, 398), A6 (line 831).

## Modelling choices, and why they are faithful

* **Loss index.** `Rc H T S = H·T + S` is a definition (A.2.2, line 839; A1), so it is taken as
  one. The *cumulative hazard* of a hazard path `h : ℝ → ℝ` is defined as its integral over the
  whole time axis, `∫ t, h t` (a hazard of the transition is zero outside it). The rectangular
  hazard "at height `H` for duration `T`" is the indicator of `[0, T]` times `H`; a hazard of fixed
  shape is `t ↦ H·g(t/T)` for an arbitrary shape `g : ℝ → ℝ` (supported where the paper likes;
  nothing is assumed about its support). Both integrals are computed, not assumed.
* **The step term in a cumulative hazard.** `R_c` includes `S`, and a flow integral does not. For
  the identification "`R_c` = cumulative hazard / Poisson mean" to include `S`, `S` must enter the
  intensity measure. `intensityMeasure` is the flow `H·Leb|[0,T]` plus atoms `S_j·δ_{t_j}` at the
  step dates (the paper writes `S` as a sum over steps, body line 98); its total mass is proved to
  be `R_c` with `S = Σ S_j`. Without atoms (`S = 0`) `R_c` is the flow cumulative hazard. The
  same bridge is proved for a hazard of fixed shape (`shapeIntensityMeasure`: the flow enters as
  the density `H·g(t/T)` with `g ≥ 0` integrable), where the total mass is `(∫g)·HT + S`, which is
  `R_c` under `∫g = 1`.
* **Poisson readings.** Mathlib has the Poisson *distribution* (`poissonMeasure`) and the law of a
  sum of independent Poisson variables, but no Poisson *process*. The premise "harmful events
  arrive as a Poisson process" is therefore taken in the form it is used: the period's event
  count `N : Ω → ℕ` has law `Po(R_c)` (`HasLaw`), i.e. Poisson with mean the intensity measure's
  total mass; for two disjoint periods, counts are independent (the independent-increments
  property). The mean, the probability of at least one event, and the expected loss are then
  *computed* from that law (the Poisson mean is proved from the series, not assumed).
* **Competing exits (A.2.3).** A window is a random time `W : Ω → EReal` (extended-real, so a
  window may never end, `W = ⊤`; the paper's "a zero-rate component never arrives", line 1205) with
  a cause label `J` in a finite type; "mutually exclusive exits" is exactly that each path has one
  cause. The cause-`j`
  sub-distribution is `F_j(t) = P(W ≤ t, J = j)`, survival `S(t) = P(W > t)`, the cause-specific
  intensity is `f_j/S` with `f_j = F_j'`, and the total hazard is `−S'/S`. No independence is
  assumed anywhere. The exponential-window claim is proved from the ODE the survival satisfies.
* **Shared shock.** One break-in time `Z` with survival `e^{−0.2t}` both leaks the weights and
  enables theft: the two cause times are both `Z`. A concrete such `Z` is exhibited on
  `expMeasure 0.2`.
* **Appendix B paths.** Primitive first arrivals on a path are `s : Ev → ℝ≥0∞` (`⊤` = never),
  as in seat L8's `Copies.lean`, with two extra event kinds the scope table talks about:
  `Ts` (secret theft that arms attackers only, B-S5) and `Xr` (a release-induced attack-enabling
  access, B-S6). The first commercial and first attack-enabling events are `Finset.inf` over the
  event sets of B.2.1's table. "At fixed future hazards" is the coupling of E2 (line 1242): the
  same path `s` in both worlds.
* **Exposure (B.2.2) in `ℝ≥0∞`.** All dates and durations are nonnegative, measured from the
  start of the hold, and an attacker-access window may be `⊤`. In `ℝ≥0∞` truncated subtraction
  `D − A` is exactly the positive part `(D − A)⁺`, so `expo` is lines 1213–1221 verbatim, with
  nonnegative weights automatically and `π` the parallel-access share. The flaw–operator pairs
  are indexed by arbitrary types `P`, `U` (no finiteness), and the sums are `tsum`s in `ℝ≥0∞`, so
  infinitely many pairs are allowed, as line 1221's "finite expected total exposure" permits.
  Expectations are `lintegral`s, so no integrability is presupposed and no junk value arises on
  `{W = ⊤}`.
* **A6.** The rebuilt coalition objective replaces P8's `m(λ, τ_j)` by the restricted mean of the
  truncated window, `(1 − e^{−λ min(T, τ_j)})/λ` (line 831), with a release date `T(n)` that may
  depend on coalition size (any differentiable `T`, the optimal date being one).
-/

open MeasureTheory ProbabilityTheory Set Real
open scoped ENNReal NNReal

namespace RTTR.Gaps1

/-! ## A.2.2 — the loss index and cumulative hazard (A7, B24, B25) -/

/-- The loss index `R_c = H·T + S` (A.2.2, line 839; a definition, A1). -/
def Rc (H T S : ℝ) : ℝ := H * T + S

/-- Cumulative hazard of a hazard path: its integral over the time axis. -/
noncomputable def cumHazard (h : ℝ → ℝ) : ℝ := ∫ t, h t

/-- The rectangular hazard at height `H` for duration `T`. -/
noncomputable def rectHazard (H T : ℝ) : ℝ → ℝ := (Icc 0 T).indicator fun _ => H

/-- The hazard of fixed shape `g` scaled to height `H` and duration `T`: `t ↦ H·g(t/T)`. -/
noncomputable def shapeHazard (H T : ℝ) (g : ℝ → ℝ) : ℝ → ℝ := fun t => H * g (t / T)

/-- **A7, rectangular case** (line 841): the cumulative hazard of the rectangular hazard is `HT`. -/
theorem a7_rect_cumHazard (H T : ℝ) (hT : 0 ≤ T) : cumHazard (rectHazard H T) = H * T := by
  unfold cumHazard rectHazard
  rw [integral_indicator_const _ measurableSet_Icc, measureReal_def, Real.volume_Icc,
    ENNReal.toReal_ofReal (by linarith), smul_eq_mul, sub_zero, mul_comm]

/-- **A7, fixed shape** (line 841): for any shape `g`, the cumulative hazard of `H·g(t/T)` is
`(∫ g)·HT` — proportional to `HT` with constant `∫ g`. -/
theorem a7_shape_cumHazard (H T : ℝ) (hT : 0 < T) (g : ℝ → ℝ) :
    cumHazard (shapeHazard H T g) = (∫ x, g x) * (H * T) := by
  unfold cumHazard shapeHazard
  rw [integral_const_mul, Measure.integral_comp_div g T, abs_of_pos hT, smul_eq_mul]
  ring

/-- **A7 under the paper's normalization `∫ g = 1`**: the cumulative hazard *equals* `HT`
(inventory §14.7: "proportional" can read "equal"). -/
theorem a7_shape_cumHazard_eq (H T : ℝ) (hT : 0 < T) (g : ℝ → ℝ) (hg : ∫ x, g x = 1) :
    cumHazard (shapeHazard H T g) = H * T := by
  rw [a7_shape_cumHazard H T hT g, hg, one_mul]

/-- The rectangle is the fixed shape `1_{[0,1]}`, whose integral is one. -/
theorem a7_rect_is_shape (H T : ℝ) (hT : 0 < T) :
    shapeHazard H T ((Icc 0 1).indicator fun _ => 1) = rectHazard H T ∧
      ∫ x, (Icc (0:ℝ) 1).indicator (fun _ => (1:ℝ)) x = 1 := by
  refine ⟨?_, ?_⟩
  · funext t
    simp only [shapeHazard, rectHazard, indicator, mem_Icc]
    have h1 : (0 ≤ t / T ∧ t / T ≤ 1) ↔ (0 ≤ t ∧ t ≤ T) := by
      rw [div_nonneg_iff, div_le_one hT]
      constructor
      · rintro ⟨h | h, h'⟩
        · exact ⟨h.1, h'⟩
        · exact absurd h.2 (not_le.mpr hT)
      · rintro ⟨h, h'⟩; exact ⟨Or.inl ⟨h, hT.le⟩, h'⟩
    by_cases h : 0 ≤ t ∧ t ≤ T
    · simp only [h, h1.mpr h, and_self, ite_true, mul_one]
    · rw [ite_eq_right_iff.mpr (fun h' => absurd (h1.mp h') h), ite_eq_right_iff.mpr (fun h' => absurd h' h), mul_zero]
  · rw [integral_indicator_const _ measurableSet_Icc, measureReal_def, Real.volume_Icc]
    norm_num

/-- **A7 / A1, what "`R_c` equals cumulative hazard" means for the full index**: `R_c` is the
rectangular cumulative hazard plus `S`; it equals the cumulative hazard exactly when `S = 0`. -/
theorem a7_Rc_eq_cumHazard_iff (H T S : ℝ) (hT : 0 ≤ T) :
    Rc H T S = cumHazard (rectHazard H T) + S ∧ (Rc H T S = cumHazard (rectHazard H T) ↔ S = 0) := by
  rw [a7_rect_cumHazard H T hT, Rc]
  exact ⟨rfl, by constructor <;> intro h <;> linarith⟩

/-- The intensity measure of the near-peak period: the flow `H·Leb` on `[0, T]` plus atoms of
mass `S_j` at the step dates `t_j`. -/
noncomputable def intensityMeasure (H T : ℝ) {m : ℕ} (tj Sj : Fin m → ℝ) : Measure ℝ :=
  ENNReal.ofReal H • volume.restrict (Icc 0 T) + ∑ j, ENNReal.ofReal (Sj j) • Measure.dirac (tj j)

/-- **A8 premise made explicit**: with the step term entering as atoms, the total intensity mass
is `R_c = HT + S`, `S = Σ_j S_j`. -/
theorem a8_intensity_mass (H T : ℝ) {m : ℕ} (tj Sj : Fin m → ℝ) (hH : 0 ≤ H) (hT : 0 ≤ T)
    (hS : ∀ j, 0 ≤ Sj j) :
    intensityMeasure H T tj Sj univ = ENNReal.ofReal (Rc H T (∑ j, Sj j)) := by
  unfold intensityMeasure Rc
  rw [Measure.add_apply, Measure.coe_finsetSum, Finset.sum_apply]
  simp only [Measure.smul_apply, Measure.restrict_apply MeasurableSet.univ, univ_inter,
    Real.volume_Icc, sub_zero, measure_univ, smul_eq_mul, mul_one]
  rw [ENNReal.ofReal_add (mul_nonneg hH hT) (Finset.sum_nonneg fun j _ => hS j),
    ENNReal.ofReal_mul hH, ENNReal.ofReal_sum_of_nonneg fun j _ => hS j]

/-- The intensity measure for a hazard of fixed shape: the flow `H·g(t/T)` as a density plus
atoms of mass `S_j` at the step dates `t_j`. -/
noncomputable def shapeIntensityMeasure (H T : ℝ) (g : ℝ → ℝ) {m : ℕ} (tj Sj : Fin m → ℝ) :
    Measure ℝ :=
  volume.withDensity (fun t => ENNReal.ofReal (shapeHazard H T g t)) +
    ∑ j, ENNReal.ofReal (Sj j) • Measure.dirac (tj j)

/-- **A8 premise for a fixed shape**: with `g ≥ 0` integrable and the step term as atoms, the
total intensity mass is `(∫g)·HT + S`; under `∫g = 1` it is `R_c`. -/
theorem a8_shape_intensity_mass (H T : ℝ) (g : ℝ → ℝ) {m : ℕ} (tj Sj : Fin m → ℝ) (hH : 0 ≤ H)
    (hT : 0 < T) (hg0 : ∀ x, 0 ≤ g x) (hgi : Integrable g) (hS : ∀ j, 0 ≤ Sj j) :
    shapeIntensityMeasure H T g tj Sj univ =
      ENNReal.ofReal ((∫ x, g x) * (H * T) + ∑ j, Sj j) := by
  unfold shapeIntensityMeasure
  rw [Measure.add_apply, withDensity_apply _ MeasurableSet.univ, Measure.restrict_univ,
    Measure.coe_finsetSum, Finset.sum_apply]
  simp only [Measure.smul_apply, measure_univ, smul_eq_mul, mul_one]
  have hint : Integrable (shapeHazard H T g) := (hgi.comp_div hT.ne').const_mul H
  rw [← ofReal_integral_eq_lintegral_ofReal hint
    (Filter.Eventually.of_forall fun t => mul_nonneg hH (hg0 _))]
  have hc := a7_shape_cumHazard H T hT g
  unfold cumHazard at hc
  rw [hc, ENNReal.ofReal_add (mul_nonneg (integral_nonneg hg0) (mul_nonneg hH hT.le))
    (Finset.sum_nonneg fun j _ => hS j), ENNReal.ofReal_sum_of_nonneg fun j _ => hS j]

theorem a8_shape_intensity_mass_eq (H T : ℝ) (g : ℝ → ℝ) {m : ℕ} (tj Sj : Fin m → ℝ)
    (hH : 0 ≤ H) (hT : 0 < T) (hg0 : ∀ x, 0 ≤ g x) (hgi : Integrable g) (hg1 : ∫ x, g x = 1)
    (hS : ∀ j, 0 ≤ Sj j) :
    shapeIntensityMeasure H T g tj Sj univ = ENNReal.ofReal (Rc H T (∑ j, Sj j)) := by
  rw [a8_shape_intensity_mass H T g tj Sj hH hT hg0 hgi hS, hg1, one_mul, Rc]

/-! ## A.2.2 — Poisson readings (A8, B24) -/

/-- The Poisson mean, from the series. -/
theorem poisson_hasSum_mean (r : ℝ≥0) :
    HasSum (fun n : ℕ => (exp (-(r : ℝ)) * (r : ℝ) ^ n / (n.factorial : ℝ)) * (n : ℝ)) r := by
  set a : ℕ → ℝ := fun n => (exp (-(r : ℝ)) * (r : ℝ) ^ n / (n.factorial : ℝ)) * (n : ℝ) with ha
  have hshift : (fun n => a (n + 1)) =
      fun n => (r : ℝ) * (exp (-(r : ℝ)) * (r : ℝ) ^ n / (n.factorial : ℝ)) := by
    funext n
    simp only [ha, Nat.factorial_succ, Nat.cast_mul, Nat.cast_succ, pow_succ]
    have : (n.factorial : ℝ) ≠ 0 := by positivity
    field_simp
  have h1 : HasSum (fun n => a (n + 1)) (r : ℝ) := by
    rw [hshift]
    simpa using (hasSum_one_poissonMeasure r).mul_left (r : ℝ)
  have h2 := (hasSum_nat_add_iff' (f := a) 1).mp (by simpa [ha] using h1)
  exact h2

theorem poisson_integral_cast (r : ℝ≥0) : ∫ n, (n : ℝ) ∂(poissonMeasure r) = r := by
  rw [integral_poissonMeasure r (fun n => (n : ℝ))]
  simpa [smul_eq_mul] using (poisson_hasSum_mean r).tsum_eq

theorem poisson_integrable_cast (r : ℝ≥0) : Integrable (fun n : ℕ => (n : ℝ)) (poissonMeasure r) := by
  rw [integrable_poissonMeasure_iff]
  simpa [Real.norm_eq_abs] using (poisson_hasSum_mean r).summable

variable {Ω : Type*} [MeasurableSpace Ω]

/-- **A8, the expected count** (line 841): if the period's count has law `Po(R_c)`, its mean is
`R_c`. -/
theorem a8_expected_count (P : Measure Ω) {N : Ω → ℕ} {R : ℝ≥0}
    (hN : HasLaw N (poissonMeasure R) P) : ∫ ω, (N ω : ℝ) ∂P = R := by
  have := hN.integral_comp (f := fun n : ℕ => (n : ℝ)) measurable_from_nat.aestronglyMeasurable
  simpa [Function.comp_def, poisson_integral_cast] using this

/-- **A8, the probability of at least one event** (line 841): `1 − e^{−R_c}`. -/
theorem a8_prob_at_least_one (P : Measure Ω) {N : Ω → ℕ} {R : ℝ≥0}
    (hN : HasLaw N (poissonMeasure R) P) : P.real {ω | 1 ≤ N ω} = 1 - exp (-(R : ℝ)) := by
  have hpre : P {ω | 1 ≤ N ω} = poissonMeasure R {n | 1 ≤ n} := by
    rw [← hN.map_eq, Measure.map_apply_of_aemeasurable hN.aemeasurable (MeasurableSet.of_discrete)]
    rfl
  have hset : {n : ℕ | 1 ≤ n} = ({0} : Set ℕ)ᶜ := by
    ext n; simp [Nat.one_le_iff_ne_zero]
  rw [measureReal_def, hpre, hset, ← measureReal_def,
    probReal_compl_eq_one_sub (measurableSet_singleton 0), poissonMeasure_real_singleton]
  simp

/-- **A8, the expected loss** (line 841): `R_c` times the loss per event. -/
theorem a8_expected_loss (P : Measure Ω) {N : Ω → ℕ} {R : ℝ≥0}
    (hN : HasLaw N (poissonMeasure R) P) (ℓ : ℝ) : ∫ ω, ℓ * (N ω : ℝ) ∂P = ℓ * R := by
  rw [integral_const_mul, a8_expected_count P hN]

/-- **A8 with the step term as atoms**: a Poisson count with mean the intensity measure's total
mass has mean `R_c`, probability `1 − e^{−R_c}` of at least one event, expected loss `ℓR_c`. -/
theorem a8_readings_of_intensity (P : Measure Ω) (H T : ℝ) {m : ℕ} (tj Sj : Fin m → ℝ)
    (hH : 0 ≤ H) (hT : 0 ≤ T) (hS : ∀ j, 0 ≤ Sj j) {N : Ω → ℕ}
    (hN : HasLaw N (poissonMeasure (intensityMeasure H T tj Sj univ).toNNReal) P) (ℓ : ℝ) :
    ∫ ω, (N ω : ℝ) ∂P = Rc H T (∑ j, Sj j) ∧
      P.real {ω | 1 ≤ N ω} = 1 - exp (-Rc H T (∑ j, Sj j)) ∧
      ∫ ω, ℓ * (N ω : ℝ) ∂P = ℓ * Rc H T (∑ j, Sj j) := by
  have hR0 : 0 ≤ Rc H T (∑ j, Sj j) :=
    add_nonneg (mul_nonneg hH hT) (Finset.sum_nonneg fun j _ => hS j)
  have hR : (((intensityMeasure H T tj Sj univ).toNNReal : ℝ≥0) : ℝ) = Rc H T (∑ j, Sj j) := by
    rw [a8_intensity_mass H T tj Sj hH hT hS, ENNReal.coe_toNNReal_eq_toReal,
      ENNReal.toReal_ofReal hR0]
  refine ⟨?_, ?_, ?_⟩
  · rw [a8_expected_count P hN, hR]
  · rw [a8_prob_at_least_one P hN, hR]
  · rw [a8_expected_loss P hN, hR]

/-- **A8 with the step term as atoms, fixed shape**: as `a8_readings_of_intensity`, for the
intensity `H·g(t/T)` (`g ≥ 0` integrable, `∫g = 1`) plus atoms. -/
theorem a8_readings_of_shape_intensity (P : Measure Ω) (H T : ℝ) (g : ℝ → ℝ) {m : ℕ}
    (tj Sj : Fin m → ℝ) (hH : 0 ≤ H) (hT : 0 < T) (hg0 : ∀ x, 0 ≤ g x) (hgi : Integrable g)
    (hg1 : ∫ x, g x = 1) (hS : ∀ j, 0 ≤ Sj j) {N : Ω → ℕ}
    (hN : HasLaw N (poissonMeasure (shapeIntensityMeasure H T g tj Sj univ).toNNReal) P) (ℓ : ℝ) :
    ∫ ω, (N ω : ℝ) ∂P = Rc H T (∑ j, Sj j) ∧
      P.real {ω | 1 ≤ N ω} = 1 - exp (-Rc H T (∑ j, Sj j)) ∧
      ∫ ω, ℓ * (N ω : ℝ) ∂P = ℓ * Rc H T (∑ j, Sj j) := by
  have hR0 : 0 ≤ Rc H T (∑ j, Sj j) :=
    add_nonneg (mul_nonneg hH hT.le) (Finset.sum_nonneg fun j _ => hS j)
  have hR : (((shapeIntensityMeasure H T g tj Sj univ).toNNReal : ℝ≥0) : ℝ) =
      Rc H T (∑ j, Sj j) := by
    rw [a8_shape_intensity_mass_eq H T g tj Sj hH hT hg0 hgi hg1 hS,
      ENNReal.coe_toNNReal_eq_toReal, ENNReal.toReal_ofReal hR0]
  refine ⟨?_, ?_, ?_⟩
  · rw [a8_expected_count P hN, hR]
  · rw [a8_prob_at_least_one P hN, hR]
  · rw [a8_expected_loss P hN, hR]

/-- **A8, "the three move together in sign"**: for two values of the index, the changes in the
probability of at least one event and in the expected loss (loss per event `ℓ > 0`) have the sign
of the change in the expected count. -/
theorem a8_same_sign (R R' ℓ : ℝ) (hℓ : 0 < ℓ) :
    SignType.sign ((1 - exp (-R')) - (1 - exp (-R))) = SignType.sign (R' - R) ∧
      SignType.sign (ℓ * R' - ℓ * R) = SignType.sign (R' - R) := by
  rcases lt_trichotomy R R' with h | h | h
  · have e : exp (-R') < exp (-R) := exp_lt_exp.mpr (by linarith)
    rw [sign_pos (by linarith), sign_pos (by linarith), sign_pos (by nlinarith)]
    exact ⟨rfl, rfl⟩
  · subst h; simp
  · have e : exp (-R) < exp (-R') := exp_lt_exp.mpr (by linarith)
    rw [sign_neg (by linarith), sign_neg (by linarith), sign_neg (by nlinarith)]
    exact ⟨rfl, rfl⟩

/-- **A8, the same in derivatives**: if `R_c` has derivative `d` in speed, the probability and
the expected loss have derivatives of the same sign as `d`. -/
theorem a8_same_sign_deriv {R : ℝ → ℝ} {d s : ℝ} (hR : HasDerivAt R d s) (ℓ : ℝ) (hℓ : 0 < ℓ) :
    HasDerivAt (fun x => 1 - exp (-R x)) (exp (-R s) * d) s ∧
      HasDerivAt (fun x => ℓ * R x) (ℓ * d) s ∧
      SignType.sign (exp (-R s) * d) = SignType.sign d ∧ SignType.sign (ℓ * d) = SignType.sign d := by
  refine ⟨?_, hR.const_mul ℓ, ?_, ?_⟩
  · have := (hR.neg.exp).const_sub 1
    convert this using 1; simp only [Pi.neg_apply]; ring
  · rw [sign_mul, sign_pos (exp_pos _), one_mul]
  · rw [sign_mul, sign_pos hℓ, one_mul]

/-- **A8, "only the count and the expected loss add across periods"**: for two disjoint periods
with independent Poisson counts (the Poisson-process premise), the combined count has law
`Po(R₁ + R₂)`; its mean and its expected loss are the sums of the periods' ones, while the
probability of at least one event is strictly *less* than the sum when both indices are
positive. -/
theorem a8_add_across_periods (P : Measure Ω) [IsProbabilityMeasure P] {N₁ N₂ : Ω → ℕ}
    {R₁ R₂ : ℝ≥0} (hind : IndepFun N₁ N₂ P) (h₁ : HasLaw N₁ (poissonMeasure R₁) P)
    (h₂ : HasLaw N₂ (poissonMeasure R₂) P) (ℓ : ℝ) :
    ∫ ω, ((N₁ + N₂) ω : ℝ) ∂P = ∫ ω, (N₁ ω : ℝ) ∂P + ∫ ω, (N₂ ω : ℝ) ∂P ∧
      ∫ ω, ℓ * ((N₁ + N₂) ω : ℝ) ∂P = ∫ ω, ℓ * (N₁ ω : ℝ) ∂P + ∫ ω, ℓ * (N₂ ω : ℝ) ∂P ∧
      P.real {ω | 1 ≤ (N₁ + N₂) ω} = 1 - exp (-((R₁ : ℝ) + R₂)) ∧
      ((0 : ℝ) < R₁ → (0 : ℝ) < R₂ →
        P.real {ω | 1 ≤ (N₁ + N₂) ω} < P.real {ω | 1 ≤ N₁ ω} + P.real {ω | 1 ≤ N₂ ω}) := by
  have h12 := hind.hasLaw_add_poissonMeasure h₁ h₂
  have hc := a8_expected_count P h12
  have hp := a8_prob_at_least_one P h12
  push_cast at hc hp
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [hc, a8_expected_count P h₁, a8_expected_count P h₂]
  · rw [a8_expected_loss P h12, a8_expected_loss P h₁, a8_expected_loss P h₂]; push_cast; ring
  · exact hp
  · intro hr1 hr2
    rw [hp, a8_prob_at_least_one P h₁, a8_prob_at_least_one P h₂]
    have e1 : exp (-(R₁ : ℝ)) < 1 := exp_lt_one_iff.mpr (by linarith)
    have e2 : exp (-(R₂ : ℝ)) < 1 := exp_lt_one_iff.mpr (by linarith)
    have : exp (-((R₁ : ℝ) + R₂)) = exp (-(R₁ : ℝ)) * exp (-(R₂ : ℝ)) := by
      rw [← exp_add]; ring_nf
    rw [this]
    nlinarith [exp_pos (-(R₁ : ℝ)), exp_pos (-(R₂ : ℝ))]

/-- **A8, linearity of the count without independence**: whatever the dependence between two
periods, the expected combined count is the sum of the periods' means. -/
theorem a8_count_adds (P : Measure Ω) [IsProbabilityMeasure P] {N₁ N₂ : Ω → ℕ} {R₁ R₂ : ℝ≥0}
    (h₁ : HasLaw N₁ (poissonMeasure R₁) P) (h₂ : HasLaw N₂ (poissonMeasure R₂) P) :
    ∫ ω, ((N₁ ω : ℝ) + (N₂ ω : ℝ)) ∂P = (R₁ : ℝ) + R₂ := by
  have i₁ : Integrable (fun ω => (N₁ ω : ℝ)) P :=
    h₁.integrable_comp (f := fun n : ℕ => (n : ℝ)) (poisson_integrable_cast R₁)
  have i₂ : Integrable (fun ω => (N₂ ω : ℝ)) P :=
    h₂.integrable_comp (f := fun n : ℕ => (n : ℝ)) (poisson_integrable_cast R₂)
  rw [integral_add i₁ i₂, a8_expected_count P h₁, a8_expected_count P h₂]

/-- **B25 / line 841**: a spike can be higher and smaller in area — a rectangular hazard of
height 2 for duration 1/4 peaks above one of height 1 for duration 1 but has half the
cumulative hazard. -/
theorem b25_higher_smaller_area :
    (∀ t, rectHazard 1 1 t ≤ 1) ∧ rectHazard 2 (1/4) (1/8) = 2 ∧
      cumHazard (rectHazard 2 (1/4)) < cumHazard (rectHazard 1 1) := by
  refine ⟨?_, ?_, ?_⟩
  · intro t; unfold rectHazard indicator; split_ifs <;> norm_num
  · unfold rectHazard; rw [indicator_of_mem]; constructor <;> norm_num
  · rw [a7_rect_cumHazard _ _ (by norm_num), a7_rect_cumHazard _ _ (by norm_num)]; norm_num

/-! ## A.2.3 — competing exits (A9, B93) -/

section Competing

variable (P : Measure Ω) [IsProbabilityMeasure P] {ι : Type*} [Fintype ι]

/-- Cause-`j` sub-distribution `F_j(t) = P(W ≤ t, J = j)`. -/
noncomputable def subCDF (W : Ω → EReal) (J : Ω → ι) (j : ι) (t : ℝ) : ℝ :=
  P.real {ω | W ω ≤ t ∧ J ω = j}

/-- Survival `S(t) = P(W > t)`. -/
noncomputable def surv (W : Ω → EReal) (t : ℝ) : ℝ := P.real {ω | (t : EReal) < W ω}

/-- Exits are mutually exclusive (one cause per path), so `S = 1 − Σ_j F_j`. -/
theorem surv_eq_one_sub_sum {W : Ω → EReal} {J : Ω → ι} (hW : Measurable W)
    (hJ : ∀ j, MeasurableSet {ω | J ω = j}) (t : ℝ) :
    surv P W t = 1 - ∑ j, subCDF P W J j t := by
  have hle : MeasurableSet {ω | W ω ≤ t} := measurableSet_le hW measurable_const
  have hc : {ω | t < W ω} = {ω | W ω ≤ t}ᶜ := by ext ω; simp
  have hU : {ω | W ω ≤ t} = ⋃ j ∈ (Finset.univ : Finset ι), {ω | W ω ≤ t ∧ J ω = j} := by
    ext ω; simp
  unfold surv subCDF
  rw [hc, probReal_compl_eq_one_sub hle, hU, measureReal_biUnion_finset]
  · intro j _ k _ hjk
    exact Set.disjoint_left.mpr fun ω h1 h2 => hjk (h1.2.symm.trans h2.2)
  · intro j _
    exact hle.inter (hJ j)

/-- **A9 / B93, intensities of mutually exclusive exits add, with no independence assumption**:
if each cause's sub-distribution has density `f_j` at `t`, the survival has derivative `−Σ f_j`,
and the total hazard `−S'/S` equals the sum of the cause-specific intensities `f_j/S`. -/
theorem a9_intensities_add {W : Ω → EReal} {J : Ω → ι} (hW : Measurable W)
    (hJ : ∀ j, MeasurableSet {ω | J ω = j}) {f : ι → ℝ} {t : ℝ}
    (hf : ∀ j, HasDerivAt (subCDF P W J j) (f j) t) :
    HasDerivAt (surv P W) (-∑ j, f j) t ∧
      ∀ d, HasDerivAt (surv P W) d t → -d / surv P W t = ∑ j, f j / surv P W t := by
  have hfun : surv P W = fun x => 1 - ∑ j, subCDF P W J j x :=
    funext (surv_eq_one_sub_sum P hW hJ)
  have hd : HasDerivAt (surv P W) (-∑ j, f j) t := by
    rw [hfun]
    have := (HasDerivAt.sum (u := Finset.univ) fun j _ => hf j).const_sub 1
    simpa using this
  refine ⟨hd, fun d hd' => ?_⟩
  rw [hd'.unique hd, neg_neg, Finset.sum_div]

/-- **A9, the window is exponential when the total intensity is constant**: if the cause
densities sum to `c·S(t)` at every `t ≥ 0` (total intensity `c`) and `S(0) = 1`, then
`S(t) = e^{−ct}` for `t ≥ 0`. Regularity: two-sided derivatives for `t > 0`, a right derivative
at `0`. The premise `S(0) = P(W > 0) = 1` (no exit at time 0) is not idle: closed release gives
`W_A` an atom at zero (line 1240). Since `W` is extended-real, `c = 0` (a window that never ends)
is inside the domain (`a9_rate_zero_instance`). -/
theorem a9_exponential_window {W : Ω → EReal} {J : Ω → ι} (hW : Measurable W)
    (hJ : ∀ j, MeasurableSet {ω | J ω = j}) {f : ι → ℝ → ℝ} (c : ℝ)
    (hf0 : ∀ j, HasDerivWithinAt (subCDF P W J j) (f j 0) (Ici 0) 0)
    (hf : ∀ j, ∀ t, 0 < t → HasDerivAt (subCDF P W J j) (f j t) t)
    (hc : ∀ t, 0 ≤ t → ∑ j, f j t = c * surv P W t) (h0 : surv P W 0 = 1) :
    ∀ t, 0 ≤ t → surv P W t = exp (-(c * t)) := by
  have hfun : surv P W = fun x => 1 - ∑ j, subCDF P W J j x :=
    funext (surv_eq_one_sub_sum P hW hJ)
  -- right derivative of S on [0, ∞)
  have hS : ∀ x, 0 ≤ x → HasDerivWithinAt (surv P W) (-(c * surv P W x)) (Ici x) x := by
    intro x hx
    rw [← hc x hx]
    rcases hx.eq_or_lt with h | h
    · subst h
      rw [hfun]
      have := (HasDerivWithinAt.sum (u := Finset.univ) fun j _ => hf0 j).const_sub 1
      simpa using this
    · have : HasDerivAt (surv P W) (-∑ j, f j x) x := by
        rw [hfun]
        have := (HasDerivAt.sum (u := Finset.univ) fun j _ => hf j x h).const_sub 1
        simpa using this
      exact this.hasDerivWithinAt
  have hcont : ∀ x, 0 ≤ x → ContinuousWithinAt (surv P W) (Ici 0) x := by
    intro x hx
    rcases hx.eq_or_lt with h | h
    · subst h; exact (hS 0 le_rfl).continuousWithinAt
    · have : HasDerivAt (surv P W) (-∑ j, f j x) x := by
        rw [hfun]
        have := (HasDerivAt.sum (u := Finset.univ) fun j _ => hf j x h).const_sub 1
        simpa using this
      exact this.continuousAt.continuousWithinAt
  set g : ℝ → ℝ := fun x => surv P W x * exp (c * x) with hg
  intro t ht
  have hconst := constant_of_has_deriv_right_zero (f := g) (a := 0) (b := t)
    (fun x hx => ((hcont x hx.1).mono (Icc_subset_Ici_self)).mul
      ((continuous_exp.comp (continuous_const.mul continuous_id)).continuousWithinAt))
    (fun x hx => by
      have h1 := (hS x hx.1).mul
        (((hasDerivAt_id x).const_mul c).exp.hasDerivWithinAt (s := Ici x))
      convert h1 using 1
      · funext y; simp [hg]
      · simp only [id]; ring)
    t ⟨ht, le_rfl⟩
  simp only [hg, h0, mul_zero, exp_zero, mul_one] at hconst
  rw [exp_neg]
  exact eq_inv_of_mul_eq_one_left hconst

/-- **A9(b) at total intensity `0` is in the domain**: the window that never ends, `W = ⊤`, has
zero sub-distributions (so densities `0`, total `0 = 0·S`) and survival `1 = e^{−0·t}`. -/
theorem a9_rate_zero_instance (J : Ω → ι) :
    (∀ j t, HasDerivAt (subCDF P (fun _ => (⊤ : EReal)) J j) 0 t) ∧
      ∀ t, surv P (fun _ => (⊤ : EReal)) t = 1 := by
  have h0 : ∀ j, subCDF P (fun _ => (⊤ : EReal)) J j = fun _ => 0 :=
    fun j => funext fun t => by simp [subCDF]
  exact ⟨fun j t => by rw [h0 j]; exact hasDerivAt_const t 0, fun t => by simp [surv]⟩

/-- **A9, the shared-shock example** (line 851): if one break-in at time `Z`, with survival
`e^{−0.2t}`, both leaks the weights and enables theft, each cause has marginal survival
`e^{−0.2t}` and marginal hazard 0.2 (the derivative of the *defined* survival
`x ↦ P(Z > x)`, at every `t > 0`, divided by it); the first arrival of the two has survival
`e^{−0.2t}` (rate 0.2), which differs from `e^{−0.4t}` at every `t > 0`: the marginal rates do
not add. -/
theorem a9_shared_shock {Z : Ω → ℝ} (hZ : ∀ t, 0 ≤ t → P.real {ω | t < Z ω} = exp (-(0.2 * t))) :
    let leak := Z
    let theft := Z
    (∀ t, 0 ≤ t → P.real {ω | t < leak ω} = exp (-(0.2 * t)) ∧
        P.real {ω | t < theft ω} = exp (-(0.2 * t))) ∧
      (∀ t, 0 < t →
        HasDerivAt (fun x => P.real {ω | x < leak ω}) (-(0.2 : ℝ) * exp (-(0.2 * t))) t ∧
        HasDerivAt (fun x => P.real {ω | x < theft ω}) (-(0.2 : ℝ) * exp (-(0.2 * t))) t ∧
        -(-(0.2 : ℝ) * exp (-(0.2 * t))) / P.real {ω | t < leak ω} = 0.2 ∧
        -(-(0.2 : ℝ) * exp (-(0.2 * t))) / P.real {ω | t < theft ω} = 0.2) ∧
      (∀ t, 0 ≤ t → P.real {ω | t < min (leak ω) (theft ω)} = exp (-(0.2 * t))) ∧
      (∀ t, 0 < t → P.real {ω | t < min (leak ω) (theft ω)} ≠ exp (-((0.2 + 0.2) * t))) := by
  intro leak theft
  have hexp : ∀ t : ℝ,
      HasDerivAt (fun x => exp (-(0.2 * x))) (-(0.2 : ℝ) * exp (-(0.2 * t))) t := by
    intro t
    have h1 := (hasDerivAt_mul_const (x := t) (-(0.2:ℝ))).exp
    convert h1 using 1
    · funext x; congr 1; ring
    · rw [show -(0.2 * t) = t * -(0.2:ℝ) by ring]; ring
  have hsurv : ∀ t : ℝ, 0 < t →
      HasDerivAt (fun x => P.real {ω | x < Z ω}) (-(0.2 : ℝ) * exp (-(0.2 * t))) t := by
    intro t ht
    refine (hexp t).congr_of_eventuallyEq ?_
    filter_upwards [Ioi_mem_nhds ht] with x hx
    exact hZ x (le_of_lt hx)
  have hratio : ∀ t : ℝ, 0 < t →
      -(-(0.2 : ℝ) * exp (-(0.2 * t))) / P.real {ω | t < Z ω} = 0.2 := by
    intro t ht
    rw [hZ t ht.le]; field_simp
  refine ⟨fun t ht => ⟨hZ t ht, hZ t ht⟩,
    fun t ht => ⟨hsurv t ht, hsurv t ht, hratio t ht, hratio t ht⟩, fun t ht => ?_, fun t ht => ?_⟩
  · simp only [leak, theft, min_self]; exact hZ t ht
  · simp only [leak, theft, min_self]
    rw [hZ t ht.le]
    intro h
    have := exp_injective h
    nlinarith

/-- Nonvacuity of the shared-shock premise: an exponential break-in time with rate 0.2 exists. -/
theorem a9_shared_shock_exists :
    ∃ (Q : Measure ℝ), IsProbabilityMeasure Q ∧
      ∀ t, 0 ≤ t → Q.real {x | t < x} = exp (-(0.2 * t)) := by
  have hr : (0:ℝ) < 0.2 := by norm_num
  haveI := isProbabilityMeasure_expMeasure hr
  refine ⟨expMeasure 0.2, inferInstance, fun t ht => ?_⟩
  have hc : {x : ℝ | t < x} = (Iic t)ᶜ := by ext x; simp
  rw [hc, probReal_compl_eq_one_sub measurableSet_Iic, ← cdf_eq_real, cdf_expMeasure_eq hr,
    if_pos ht]
  ring

end Competing

/-! ## Appendix B scope claims (X1, X2, X3, B116) -/

/-- Event kinds: B.2.1's table, plus `Ts` (secret theft arming attackers only, B-S5) and `Xr`
(release-induced attack-enabling access, B-S6). -/
inductive Ev
  | O | C1 | C0 | Th | L | Ts | Xr
  deriving DecidableEq

/-- Events that end the commercial lead (B.2.1). -/
def commSet : Finset Ev := {.O, .C1, .C0, .Th, .L}

/-- Events that end attacker exclusion under B.2.1 (all but C0). -/
def attackSet : Finset Ev := {.O, .C1, .Th, .L}

/-- Attack-enabling events with a secret theft that supplies no commercial substitute (B-S5). -/
def attackSetCovert : Finset Ev := insert .Ts attackSet

/-- Attack-enabling events with an added release-induced hazard (B-S6). -/
def attackSetRel : Finset Ev := insert .Xr attackSet

/-- First arrival among an event set on a path of first-arrival times. -/
noncomputable def firstOf (E : Finset Ev) (s : Ev → ℝ≥0∞) : ℝ≥0∞ := E.inf s

theorem firstOf_anti {E E' : Finset Ev} (h : E ⊆ E') (s : Ev → ℝ≥0∞) :
    firstOf E' s ≤ firstOf E s := Finset.inf_mono h

/-- A defensive schedule (B.2.2) with nonnegative dates, durations and weights. -/
structure Sched (P U : Type*) where
  pub : P → ℝ≥0∞
  dep : P → ℝ≥0∞
  disc : P → ℝ≥0∞
  discPi : P → ℝ≥0∞
  w : P → ℝ≥0∞
  lag : ℝ≥0∞
  rem : U → ℝ≥0∞
  udisc : U → ℝ≥0∞
  udiscPi : U → ℝ≥0∞
  uw : U → ℝ≥0∞

variable {P U : Type*}

/-- `X(Σ, W)` of lines 1213–1221: patched pairs `(D − min(P + ℓ_x, W + d))⁺`, unfound pairs
`(ζ − W − d)⁺`, parallel-access terms independent of `W`, weighted by `1 − π` and `π`. The pair
families are arbitrary (possibly infinite); the sums are `tsum`s in `ℝ≥0∞`. -/
noncomputable def expo (pp : ℝ≥0∞) (σ : Sched P U) (W : ℝ≥0∞) : ℝ≥0∞ :=
  (∑' i, σ.w i * ((1 - pp) * ((σ.pub i + σ.dep i) - min (σ.pub i + σ.lag) (W + σ.disc i))
      + pp * ((σ.pub i + σ.dep i) - min (σ.pub i + σ.lag) (σ.discPi i))))
  + ∑' k, σ.uw k * ((1 - pp) * (σ.rem k - (W + σ.udisc k)) + pp * (σ.rem k - σ.udiscPi k))

/-- Exposure is antitone in the window (line 1295), here for every window in `[0, ∞]`. -/
theorem expo_antitone (pp : ℝ≥0∞) (σ : Sched P U) : Antitone (expo pp σ) := by
  intro W W' h
  unfold expo
  exact add_le_add (ENNReal.tsum_le_tsum fun i => by gcongr)
    (ENNReal.tsum_le_tsum fun k => by gcongr)

/-- **X1, the post-release window derived from an event set**: an attack-enabling release at
date `R`, entered as the stream `Xr` arriving at `R` on an otherwise unchanged path, makes the
first attack-enabling event `min(ω_A, R)`. -/
theorem x1_window_of_release_event (s : Ev → ℝ≥0∞) (R : ℝ≥0∞) :
    firstOf attackSetRel (Function.update s .Xr R) = min (firstOf attackSet s) R := by
  have h : firstOf attackSet (Function.update s .Xr R) = firstOf attackSet s :=
    Finset.inf_congr rfl fun e he =>
      Function.update_of_ne (by rintro rfl; simp [attackSet] at he) _ _
  simp only [firstOf, attackSetRel, Finset.inf_insert, Function.update_self] at h ⊢
  rw [h]
  exact min_comm _ _

/-- **X1, B-S2 (line 1178)**: allowing an attack-enabling release at a date `R` after
preemption (`ω_C ≤ R`) gives the attacker window `min(ω_A, R)` (`x1_window_of_release_event`),
which can only shorten exclusion on every path with the same future streams; and so, at a fixed
schedule, it weakly raises exposure pathwise. The content is order-theoretic (`min ≤`, and
exposure antitone): the bound holds for every `R`, so the preemption premise is not used; it
matters only for strictness (`x1_strict_possible`). -/
theorem x1_release_after_preemption_shortens (s : Ev → ℝ≥0∞) (R : ℝ≥0∞)
    (pp : ℝ≥0∞) (σ : Sched P U) :
    min (firstOf attackSet s) R ≤ firstOf attackSet s ∧
      expo pp σ (firstOf attackSet s) ≤ expo pp σ (min (firstOf attackSet s) R) :=
  ⟨min_le_left _ _, expo_antitone pp σ (min_le_left _ _)⟩

/-- X1 is not vacuous: a post-preemption release can strictly shorten exclusion. -/
theorem x1_strict_possible :
    ∃ (s : Ev → ℝ≥0∞) (R : ℝ≥0∞), firstOf commSet s ≤ R ∧
      min (firstOf attackSet s) R < firstOf attackSet s := by
  refine ⟨fun e => if e = .C0 then 1 else 3, 2, ?_, ?_⟩
  · simp [firstOf, commSet]
  · simp [firstOf, attackSet]
    norm_num

/-- **X1 in expectation**: at a fixed (possibly random) schedule, the expected exposure under
post-preemption release is at least that under committed holding. -/
theorem x1_expected (Ω : Type*) [MeasurableSpace Ω] (μ : Measure Ω) (S : Ω → Ev → ℝ≥0∞)
    (R : Ω → ℝ≥0∞) (pp : ℝ≥0∞) (σ : Ω → Sched P U) :
    ∫⁻ ω, expo pp (σ ω) (firstOf attackSet (S ω)) ∂μ ≤
      ∫⁻ ω, expo pp (σ ω) (min (firstOf attackSet (S ω)) (R ω)) ∂μ :=
  lintegral_mono fun ω => expo_antitone pp (σ ω) (min_le_left _ _)

/-- **X2, the role of B-S5's premise**: whenever every attack-enabling event also ends the
commercial lead, `ω_C ≤ ω_A` on every path. -/
theorem x2_order_of_premise {E : Finset Ev} (h : E ⊆ commSet) (s : Ev → ℝ≥0∞) :
    firstOf commSet s ≤ firstOf E s := firstOf_anti h s

/-- **X2, B-S5 (line 1181)**: a secret theft that only arms attackers can end attacker
exclusion before commercial leadership, so the ordering `ω_C ≤ ω_A` fails on some path. -/
theorem x2_secret_theft_breaks_order :
    ∃ s : Ev → ℝ≥0∞, firstOf attackSetCovert s < firstOf commSet s := by
  refine ⟨fun e => if e = .Ts then 1 else 2, ?_⟩
  simp [firstOf, attackSetCovert, attackSet, commSet]

/-- **X3 / B116, B-S6 (line 1182; body lines 334, 396, 398)**: an added attack-enabling hazard
(the stream `Xr`) shortens the attacker window on every path with the same primitive streams,
and so raises exposure weakly at a fixed schedule — pathwise and in expectation. -/
theorem x3_added_hazard_raises (s : Ev → ℝ≥0∞) (pp : ℝ≥0∞) (σ : Sched P U) :
    firstOf attackSetRel s ≤ firstOf attackSet s ∧
      expo pp σ (firstOf attackSet s) ≤ expo pp σ (firstOf attackSetRel s) := by
  have h := firstOf_anti (show attackSet ⊆ attackSetRel from Finset.subset_insert _ _) s
  exact ⟨h, expo_antitone pp σ h⟩

theorem x3_added_hazard_raises_expected (Ω : Type*) [MeasurableSpace Ω] (μ : Measure Ω)
    (S : Ω → Ev → ℝ≥0∞) (pp : ℝ≥0∞) (σ : Ω → Sched P U) :
    ∫⁻ ω, expo pp (σ ω) (firstOf attackSet (S ω)) ∂μ ≤
      ∫⁻ ω, expo pp (σ ω) (firstOf attackSetRel (S ω)) ∂μ :=
  lintegral_mono fun ω => (x3_added_hazard_raises (S ω) pp (σ ω)).2

/-- **B116, "would raise exposure further"** (body lines 334, 396): under immediate closed
release the attacker window is `0` if the safeguards fail (`b = true`) and `ω_A` otherwise
(E2, line 1252); adding the release-induced stream `Xr` replaces it by `min(W_cl, s Xr)`, which
is no longer on every path, so exposure at a fixed schedule rises weakly on top of E2's
comparison. On the failed-safeguards branch (`b = true`) the content is `min 0 x = 0`. -/
theorem b116_added_hazard_on_release (s : Ev → ℝ≥0∞) (b : Bool) (pp : ℝ≥0∞) (σ : Sched P U) :
    let Wcl : ℝ≥0∞ := if b then 0 else firstOf attackSet s
    min Wcl (s .Xr) ≤ Wcl ∧ expo pp σ Wcl ≤ expo pp σ (min Wcl (s .Xr)) ∧
      (b = false → min Wcl (s .Xr) = firstOf attackSetRel s) := by
  intro Wcl
  refine ⟨min_le_left _ _, expo_antitone pp σ (min_le_left _ _), fun hb => ?_⟩
  simp only [Wcl, hb, Bool.false_eq_true, if_false, firstOf, attackSetRel, Finset.inf_insert]
  exact min_comm _ _

/-- **B116 in expectation**: under closed release with a random safeguard indicator `B` and
random paths and schedules, the expected exposure `X_cl` rises weakly when the release-induced
stream is added. -/
theorem b116_added_hazard_on_release_expected (Ω : Type*) [MeasurableSpace Ω] (μ : Measure Ω)
    (S : Ω → Ev → ℝ≥0∞) (B : Ω → Bool) (pp : ℝ≥0∞) (σ : Ω → Sched P U) :
    ∫⁻ ω, expo pp (σ ω) (if B ω then 0 else firstOf attackSet (S ω)) ∂μ ≤
      ∫⁻ ω, expo pp (σ ω) (min (if B ω then 0 else firstOf attackSet (S ω)) (S ω .Xr)) ∂μ :=
  lintegral_mono fun ω => (b116_added_hazard_on_release (S ω) (B ω) pp (σ ω)).2.1

/-- **B116, the raise is weak, not strict**: with working safeguards, the added stream can
strictly shorten the attacker window while exposure is unchanged (`π = 1`: all attack effort
already has parallel access, so exposure does not depend on the window). -/
theorem b116_raise_not_strict :
    ∃ s : Ev → ℝ≥0∞, min (firstOf attackSet s) (s .Xr) < firstOf attackSet s ∧
      ∀ σ : Sched P U, expo 1 σ (min (firstOf attackSet s) (s .Xr)) = expo 1 σ (firstOf attackSet s) := by
  refine ⟨fun e => if e = .Xr then 1 else 2, ?_, fun σ => ?_⟩
  · simp [firstOf, attackSet]
  · simp [expo]

/-- **X3, "a defensive improvement can lower it"**: at the same window, an earlier deployment
date strictly lowers exposure (one patched pair, `π = 0`: deployment delay 10 → 2, lag 1,
discovery 1, window 5 gives exposure 9 → 1). -/
theorem x3_defensive_improvement_can_lower :
    let σH : Sched Unit Empty :=
      ⟨fun _ => 0, fun _ => 10, fun _ => 1, fun _ => 1, fun _ => 1, 1,
        Empty.elim, Empty.elim, Empty.elim, Empty.elim⟩
    let σcl : Sched Unit Empty := { σH with dep := fun _ => 2 }
    expo 0 σcl 5 < expo 0 σH 5 := by
  intro σH σcl
  have h1 : min (1:ℝ≥0∞) (5 + 1) = 1 := min_eq_left (by norm_num)
  have h2 : (2:ℝ≥0∞) - 1 = 1 := ENNReal.sub_eq_of_eq_add (by simp) (by norm_num)
  have h3 : (10:ℝ≥0∞) - 1 = 9 := ENNReal.sub_eq_of_eq_add (by simp) (by norm_num)
  simp only [expo, σcl, σH, tsum_fintype, Finset.univ_unique, Finset.sum_singleton, Finset.univ_eq_empty,
    Finset.sum_empty, add_zero, tsub_zero, one_mul, zero_mul, zero_add, h1]
  rw [h2, h3]; norm_num

/-! ## A6 — P8's coalition objective rebuilt with the truncated mean (line 831) -/

/-- P8's `m(λ, u) = (1 − e^{−λu})/λ`. -/
noncomputable def mR (lam u : ℝ) : ℝ := (1 - exp (-(lam * u))) / lam

/-- `∂m/∂λ` at horizon `u` (P8's `m_λ`, line 1129). -/
noncomputable def mLam (lam u : ℝ) : ℝ :=
  (lam * u * exp (-(lam * u)) - (1 - exp (-(lam * u)))) / lam ^ 2

/-- The rebuilt coalition objective: P8's `B(n)` with the restricted mean of `W_T = min(L, T)`,
`(1 − e^{−λ min(T, τ_j)})/λ`, and a release date `T(n)`. -/
noncomputable def Btr {J : Type*} [Fintype J] (pp : ℝ) (c : J → ℝ → ℝ) (w τ : J → ℝ)
    (lam T : ℝ → ℝ) (n : ℝ) : ℝ :=
  (1 - pp) * ∑ j, c j n * w j * mR (lam n) (min (T n) (τ j))

/-- **A6, "must be rebuilt"**: when the release date binds (`0 < T < τ`), the restricted mean
of the truncated window is strictly below P8's `m(λ, τ)`. -/
theorem a6_truncated_mean_lt (lam T τ : ℝ) (hlam : 0 < lam) (hT : T < τ) :
    mR lam (min T τ) < mR lam τ := by
  rw [min_eq_left hT.le]
  unfold mR
  apply div_lt_div_of_pos_right _ hlam
  have : exp (-(lam * τ)) < exp (-(lam * T)) := exp_lt_exp.mpr (by nlinarith)
  linarith

/-- One term's derivative in `n`, on each side of the date at which `T(n) = τ`. -/
theorem a6_term_deriv {lam T : ℝ → ℝ} {lam' T' n τ : ℝ} (hl : HasDerivAt lam lam' n)
    (hT : HasDerivAt T T' n) (hpos : lam n ≠ 0) (hne : T n ≠ τ) :
    HasDerivAt (fun x => mR (lam x) (min (T x) τ))
      (if T n < τ then mLam (lam n) (T n) * lam' + exp (-(lam n * T n)) * T'
        else mLam (lam n) τ * lam') n := by
  split_ifs with h
  · have hev : (fun x => mR (lam x) (min (T x) τ)) =ᶠ[nhds n] fun x => mR (lam x) (T x) := by
      filter_upwards [hT.continuousAt.eventually_lt continuousAt_const h] with x hx
      rw [min_eq_left hx.le]
    refine HasDerivAt.congr_of_eventuallyEq ?_ hev
    unfold mR mLam
    have hnum := ((hl.mul hT).neg.exp).const_sub 1
    have := hnum.div hl hpos
    convert this using 1
    simp only [Pi.neg_apply, Pi.mul_apply]
    field_simp
    ring
  · have hlt : τ < T n := lt_of_le_of_ne (not_lt.mp h) (Ne.symm hne)
    have hev : (fun x => mR (lam x) (min (T x) τ)) =ᶠ[nhds n] fun x => mR (lam x) τ := by
      filter_upwards [continuousAt_const.eventually_lt hT.continuousAt hlt] with x hx
      rw [min_eq_right hx.le]
    refine HasDerivAt.congr_of_eventuallyEq ?_ hev
    unfold mR mLam
    have hnum := ((hl.mul_const τ).neg.exp).const_sub 1
    have := hnum.div hl hpos
    convert this using 1
    simp only [Pi.neg_apply]
    field_simp

/-- **A6, the additional derivative term**: with a release date `T(n)` that varies with
coalition size, the rebuilt objective's derivative is P8(i)'s formula at the truncated horizons
`u_j = min(T, τ_j)` plus the term `(1 − π) Σ_{j : T < τ_j} c_j w_j e^{−λT} T′(n)`. -/
theorem a6_rebuilt_deriv {J : Type*} [Fintype J] (pp : ℝ) {c : J → ℝ → ℝ} {c' : J → ℝ}
    (w τ : J → ℝ) {lam T : ℝ → ℝ} {lam' T' n : ℝ} (hc : ∀ j, HasDerivAt (c j) (c' j) n)
    (hl : HasDerivAt lam lam' n) (hT : HasDerivAt T T' n) (hpos : lam n ≠ 0)
    (hne : ∀ j, T n ≠ τ j) :
    HasDerivAt (Btr pp c w τ lam T)
      ((1 - pp) * ∑ j, w j * (c' j * mR (lam n) (min (T n) (τ j))
          + c j n * (mLam (lam n) (min (T n) (τ j)) * lam'))
        + (1 - pp) * ∑ j, (if T n < τ j then c j n * w j * exp (-(lam n * T n)) * T' else 0)) n := by
  have hterm : ∀ j, HasDerivAt (fun x => c j x * w j * mR (lam x) (min (T x) (τ j)))
      (c' j * w j * mR (lam n) (min (T n) (τ j)) + c j n * w j *
        (if T n < τ j then mLam (lam n) (T n) * lam' + exp (-(lam n * T n)) * T'
          else mLam (lam n) (τ j) * lam')) n := fun j =>
    ((hc j).mul_const (w j)).mul (a6_term_deriv hl hT hpos (hne j))
  have hsum := (HasDerivAt.sum (u := Finset.univ) fun j _ => hterm j).const_mul (1 - pp)
  unfold Btr
  convert hsum using 1
  · funext y; simp only [Finset.sum_apply]
  rw [← mul_add, ← Finset.sum_add_distrib]
  congr 1
  refine Finset.sum_congr rfl fun j _ => ?_
  split_ifs with h
  · rw [min_eq_left h.le]; ring
  · rw [min_eq_right (not_lt.mp h)]; ring

/-- **A6, the term is genuinely additional**: with `π < 1`, `T′(n) ≠ 0`, nonnegative `c_j w_j`
and some operator with `T(n) < τ_j` and `c_j w_j > 0`, it is nonzero. -/
theorem a6_extra_ne_zero {J : Type*} [Fintype J] (pp : ℝ) (c : J → ℝ → ℝ) (w τ : J → ℝ)
    (lam T : ℝ → ℝ) (T' n : ℝ) (hpp : pp < 1) (hT' : T' ≠ 0)
    (hnn : ∀ j, 0 ≤ c j n * w j) (j₀ : J) (hj₀ : T n < τ j₀) (hpos : 0 < c j₀ n * w j₀) :
    (1 - pp) * ∑ j, (if T n < τ j then c j n * w j * exp (-(lam n * T n)) * T' else 0) ≠ 0 := by
  have hS : 0 < ∑ j, (if T n < τ j then c j n * w j * exp (-(lam n * T n)) else 0) := by
    apply Finset.sum_pos' (fun j _ => by
      split_ifs
      · exact mul_nonneg (hnn j) (exp_pos _).le
      · exact le_rfl)
    exact ⟨j₀, Finset.mem_univ _, by rw [if_pos hj₀]; exact mul_pos hpos (exp_pos _)⟩
  have : ∑ j, (if T n < τ j then c j n * w j * exp (-(lam n * T n)) * T' else 0) =
      (∑ j, (if T n < τ j then c j n * w j * exp (-(lam n * T n)) else 0)) * T' := by
    rw [Finset.sum_mul]
    refine Finset.sum_congr rfl fun j _ => ?_
    split_ifs <;> ring
  rw [this]
  exact mul_ne_zero (by linarith) (mul_ne_zero hS.ne' hT')

/-- **A6, and only when the date binds**: if `T(n) > τ_j` for every operator, the extra term
vanishes and the derivative is P8(i)'s formula with the untruncated `m(λ, τ_j)`. -/
theorem a6_no_extra_if_not_binding {J : Type*} [Fintype J] (pp : ℝ) (c : J → ℝ → ℝ) (w τ : J → ℝ)
    (lam T : ℝ → ℝ) (T' n : ℝ) (h : ∀ j, τ j < T n) :
    (1 - pp) * ∑ j, (if T n < τ j then c j n * w j * exp (-(lam n * T n)) * T' else 0) = 0 ∧
      ∀ j, min (T n) (τ j) = τ j := by
  refine ⟨?_, fun j => min_eq_right (h j).le⟩
  rw [Finset.sum_eq_zero fun j _ => if_neg (not_lt.mpr (h j).le), mul_zero]

end RTTR.Gaps1

section Axioms
open RTTR.Gaps1
#print axioms a7_rect_cumHazard
#print axioms a7_shape_cumHazard
#print axioms a7_shape_cumHazard_eq
#print axioms a7_rect_is_shape
#print axioms a7_Rc_eq_cumHazard_iff
#print axioms a8_intensity_mass
#print axioms a8_shape_intensity_mass
#print axioms a8_shape_intensity_mass_eq
#print axioms a8_readings_of_shape_intensity
#print axioms poisson_hasSum_mean
#print axioms poisson_integral_cast
#print axioms poisson_integrable_cast
#print axioms a8_expected_count
#print axioms a8_prob_at_least_one
#print axioms a8_expected_loss
#print axioms a8_readings_of_intensity
#print axioms a8_same_sign
#print axioms a8_same_sign_deriv
#print axioms a8_add_across_periods
#print axioms a8_count_adds
#print axioms b25_higher_smaller_area
#print axioms surv_eq_one_sub_sum
#print axioms a9_intensities_add
#print axioms a9_exponential_window
#print axioms a9_rate_zero_instance
#print axioms a9_shared_shock
#print axioms a9_shared_shock_exists
#print axioms firstOf_anti
#print axioms expo_antitone
#print axioms x1_window_of_release_event
#print axioms x1_release_after_preemption_shortens
#print axioms x1_strict_possible
#print axioms x1_expected
#print axioms x2_order_of_premise
#print axioms x2_secret_theft_breaks_order
#print axioms x3_added_hazard_raises
#print axioms x3_added_hazard_raises_expected
#print axioms b116_added_hazard_on_release
#print axioms b116_added_hazard_on_release_expected
#print axioms b116_raise_not_strict
#print axioms x3_defensive_improvement_can_lower
#print axioms a6_truncated_mean_lt
#print axioms a6_term_deriv
#print axioms a6_rebuilt_deriv
#print axioms a6_extra_ne_zero
#print axioms a6_no_extra_if_not_binding
end Axioms
