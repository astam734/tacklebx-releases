import Mathlib
import RTTRProofs.Contest
import RTTRProofs.Release
import RTTRProofs.Gaps2
import RTTRProofs.Copies
import RTTRProofs.Hold
import RTTRProofs.Program

/-!
# GAPS4 — the items Paper v14's status table still marks "not machine-checked"

Paper: `PEAKS-PAPER/PAPER/PAPER-DRAFT-v14.md`. Seat brief: `LEAN/V15/BRIEF-GAPS4.md`. This module
imports the existing modules `Contest`, `Release`, `Gaps2`, `Copies`, `Hold` and `Program` to
reuse their definitions (COMMON-V15's exception to the import rule); it edits none of them.

## 1. Proposition 10(iii), sufficiency: the one-shot deviation principle, proved (lines 984, 1191)

* **The full repeated game, not a menu of deviations.** A pure strategy of the racer whose
  incentives are checked (`Strat`) is *any* function from the public detection history (the
  chronological list of detection outcomes) to an effort `≥ 0`. Against the rival's grim-trigger
  strategy this is every pure strategy: the rival's past efforts are determined by the detection
  history (restraint `0` before detection, the stage equilibrium `x*` after), and the racer's own
  past efforts by its own strategy, so any strategy on full histories induces one on detection
  histories with the same outcome law. Detection is public: the paper's "permanent reversion to
  the stage equilibrium" from the next period requires both racers to know it.
* **Expected payoffs are defined, not assumed.** `expPay t ph σ` is the expected stage payoff in
  period `t`, by recursion on the binary tree of detection draws: after a period with effort
  `e`, detection with probability `ν` if `e ≠ 0` and `0` if `e = 0` (no false alarms, `detP`);
  in the punishment phase the rival plays `x*` for ever. Stage payoffs are Contest's `stage`
  (P10's stage game). `partialVal N` is the discounted sum of the first `N` periods.
* **Sufficiency** (`p10_iii_full_bound`): if `ν ≥ ν*`, every strategy's `N`-period value is at most
  `W − ϱ^N P`, with `W = U_C/(1−ϱ)` restraint's value and `P = U_N/(1−ϱ)` punishment's; proved by
  backward induction whose step is the one-shot deviation inequality (`one_step`). Hence every
  strategy with a summable payoff series is worth at most restraint (`p10_iii_full_sufficiency`),
  and every strategy's partial values are eventually below restraint's value plus any `ε`
  (`p10_iii_full_limsup`, no summability assumed). `p10_iii_full_iff` gives both directions in the
  full game (necessity via the one-shot deviation `oneShotS`, whose stream is Contest's
  `oneShotStream`). `p10_iii_punishment_best` and `p10_iii_subgame_coop` give the subgames:
  punishment is a best response in every punishment subgame, and every undetected history
  continues the original game, so restraint with grim trigger is subgame perfect.
* **Hypotheses:** the text's `D > 0`, `0 < ϱ < 1`, `L, θ ≥ 0`, P9's `c + Lθ > 0`, and
  `0 ≤ ν ≤ 1` (a probability). **Not covered:** behavioural mixing (a mixed deviation's payoff is
  an average of pure ones, which is not formalized).

## 2. Proposition 11(i), the jump-point clause (line 1029; proof line 1193)

* Rents may jump: `ρ` is measurable and bounded on `[0, g₀ + Δ]` and need not be continuous.
  `Pi`, `J`, `V`, `Phi` are Release's definitions (the integrals).
* `Pi_hasDerivAt_of_continuousAt`: for `κ_post > 0`, `Π` is differentiable at every lead where
  `ρ` is continuous, with `rΠ = ρ − κxΠ′` there (Release's shift argument, localized to a point).
* `p11i_jump_V_hasDerivAt`: `V′ = e^{−(r+λ)T}Φ` at every `T > 0` at which neither `g(T)` nor
  `g(T) + Δ` is a discontinuity of `ρ`.
* `p11i_jump_candidates`, `p11i_jump_optimum`: every interior local maximum, in particular every
  optimal interior release date, is a zero of `Φ` or a date at which `g(T)` or `g(T) + Δ` is a jump
  point: those dates join the candidates, and nothing else does. `p11i_jump_candidates_kpost0` is
  the `κ_post = 0` case (`Π = ρ/r`; the dates where `ρ` is not differentiable at `g(T) + Δ` join).
* `p11i_jump_example`: the paper's example (`ρ = x + 1{x ≥ 1}`, Gaps2's `p33_jump_kink_optimum`)
  satisfies the hypotheses, and its optimum `T₀ = ln 1.1` is exactly such a date. Gaps2 restates
  P11's objects in its own namespace; `toRel`, `bridge_V`, `bridge_Phi` prove they are Release's.
* **Not re-proved for jumping rents:** the comparison with holding until loss (`T → ∞`), which
  Release proves for continuous rents, and the kink conditions `Φ(T−) ≥ 0 ≥ Φ(T+)`.

## 3. Proposition 11(v), post-release copying for general rents, and the saturating reversal

* `qf ρ y = yρ′(y)` with `ρ′ = deriv ρ`. `I0 = ∫ e^{−rs}q(xe^{−κs})ds`,
  `I1 = ∫ se^{−rs}q(xe^{−κs})ds`.
* `Pi_hasDerivAt_kappa`: `∂Π/∂κ_post = −I₁`; `Pi_hasDerivAt_x`: `xΠ′(x) = I₀`; both by
  differentiation under the integral sign (Mathlib's dominated-derivative theorem), with `q`
  bounded. `rho_sub_rPi`: `ρ(x) − rΠ(x) = κI₀`.
* `I0_sub_rI1_nonneg`: `I₀ − rI₁ ≥ 0` when `q` is non-decreasing. This is `∂Π′/∂κ_post ≤ 0`; the
  proof uses only monotonicity of `q`, not its derivative (with `φ(s) = se^{−rs}`, `∫φ′ = 0`,
  `φ′ ≥ 0` exactly on `[0, 1/r]`, and `q(xe^{−κs})` non-increasing in `s`).
* `p11v_kpost_partial_general`: `∂Φ/∂κ_post = (r+λ)I₁ + κ_pre g(I₀ − rI₁)/(xκ_post)`, the derivative
  of the defined `Φ` under the record update `{p with kpost := k}`. `p11v_kpost_partial_general_pos`:
  it is positive for a strictly increasing rent, differentiable on `(0, g₀ + Δ)`, with `xρ′(x)`
  non-decreasing; the bound on `q` is derived. `p11v_kpost_later_general`: release comes later,
  through Release's `comp_statics` (the differentiable selection and joint differentiability of
  `Φ` are the implicit-function hypotheses, as in Release's (v) theorems). Hypotheses beyond the
  text: `κ_post > 0` (the paper's interior analysis at `κ_post = 0` would need one-sided
  derivatives), `κ_pre, g₀ > 0`, `T* > 0`.
* **The saturating reversal** (`ρ = 1 − e^{−4x}`, Release's `pSat`): `sat_Phi_kpost_partial`
  proves `∂Φ/∂κ_post = −12e^{−8}` at `κ_post = 0`, `T = 1`, by three dominated differentiations
  valid for `|κ_post| < 1/2` (the defined `Φ` extends to small negative `κ_post`; the two-sided
  derivative restricts to the right one); `sat_Phi_T_partial` proves `∂Φ/∂T = −4e^{−4}(1 + e^{−4})`;
  `comp_statics_right` is the one-sided comparative-statics step; `p11v_saturating_reversal`
  proves the right derivative of `T*` is `−3/(e⁴ + 1) < 0`, for any selection of zeros on
  `κ_post ≥ 0` through `T*(0) = 1` with a right derivative (implicit-function hypotheses).

## 4. B-S2: "the optimized responses have no general direction" (line 1241)

* The paper's event system, windows and exposure are Copies' (`Ev`, `Rates`, `FirstArrivals`,
  `omegaAOf`, `omegaCOf`, `WA`, `Schedule`, `exposure`). The response B-S2 sets aside is modelled as
  a fourth policy, `holdThenRel`: hold, then release openly at the first safeguarded rival
  preemption (`C0`). Its attacker window `min(ω_A, τ_C0)` is proved equal to `ω_C`
  (`WApol_holdThenRel`).
* **Private values.** B-S1 leaves them unmodelled, so they are the free inputs of the instances:
  holding is P11–P13's hold value `(F + λZ)/(r + λ)` (`Program.holdValue`) with the commercial
  hazard `λ_C` and continuation `0` (committed) or `Zpp` (the expected post-preemption release
  value), and immediate releases are worth constants. "Optimized response" = the unique maximizer
  of private value over the menu (`UniqueBest`), B-S2's menu or the menu with the option.
* **Two instances, opposite strict signs**, in every model of the event system with rates
  `λ_o = 0, λ_c = 1, p_c = 0, λ_θ = 1, λ_ℓ = 0` and one unfound flaw (`X(W) = (1 − W)⁺`):
  `bs2_instance_raises` (optimum moves from holding to the option; expected exposure rises from
  `1 − m(1, 1)` to `1 − m(2, 1)`) and `bs2_instance_lowers` (optimum moves from immediate open
  release to the option; expected exposure falls from `1` to `1 − m(2, 1)`). Expectations use the
  exponential laws E1 derives from `FirstArrivals` (Copies) and Hold's `p6ii_exp_real`.
  `bs2_model_exists` proves the premise is not vacuous (a product of exponential coordinates).
  `bs2_pathwise` gives the two pathwise orderings behind the signs.

-/

namespace RTTR.Gaps4

section P10
open Real Filter Topology RTTR.Contest


/-- Phase of the repeated race against grim trigger: no detection yet, or permanent punishment. -/
inductive Phase
  | coop
  | pun
  deriving DecidableEq

/-- A pure strategy of the racer whose incentives are checked: effort as a function of the public
detection history (the chronological list of detection outcomes so far). -/
abbrev Strat := List Bool → ℝ

/-- Probability that a period with effort `e` is followed by detection: `ν` after a deviation,
`0` otherwise (no false alarms). -/
noncomputable def detP (ν e : ℝ) : ℝ := if e = 0 then 0 else ν

/-- The stage equilibrium effort `x* = D/(4(c + Lθ))`. -/
noncomputable def xs (D c L θ : ℝ) : ℝ := D / (4 * (c + L * θ))

/-- Expected stage payoff in period `t` of the racer using `σ`, from phase `ph`, when the rival
plays grim trigger: restraint (`0`) until a detection, the stage equilibrium `x*` from the next
period on. The expectation is over the detection draws, defined on the binary tree of
outcomes. -/
noncomputable def expPay (D c L θ ν : ℝ) : ℕ → Phase → Strat → ℝ
  | 0, .coop, σ => stage D c L θ (σ []) 0
  | 0, .pun, σ => stage D c L θ (σ []) (xs D c L θ)
  | t + 1, .coop, σ => detP ν (σ []) * expPay D c L θ ν t .pun (fun h => σ (true :: h))
      + (1 - detP ν (σ [])) * expPay D c L θ ν t .coop (fun h => σ (false :: h))
  | t + 1, .pun, σ => expPay D c L θ ν t .pun (fun h => σ (false :: h))

/-- Discounted expected payoff over the first `N` periods. -/
noncomputable def partialVal (D c L θ ν ϱ : ℝ) (ph : Phase) (σ : Strat) (N : ℕ) : ℝ :=
  ∑ t ∈ Finset.range N, ϱ ^ t * expPay D c L θ ν t ph σ

/-- Restraint: effort zero at every history. -/
def restraintS : Strat := fun _ => 0

lemma partial_coop_succ (D c L θ ν ϱ : ℝ) (σ : Strat) (N : ℕ) :
    partialVal D c L θ ν ϱ .coop σ (N + 1) = stage D c L θ (σ []) 0 + ϱ *
      (detP ν (σ []) * partialVal D c L θ ν ϱ .pun (fun h => σ (true :: h)) N
        + (1 - detP ν (σ [])) * partialVal D c L θ ν ϱ .coop (fun h => σ (false :: h)) N) := by
  unfold partialVal
  rw [Finset.sum_range_succ']
  simp only [expPay, pow_zero, one_mul]
  rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib, Finset.mul_sum,
    add_comm (stage D c L θ (σ []) 0)]
  congr 1
  refine Finset.sum_congr rfl (fun t _ => ?_)
  rw [pow_succ]; ring

lemma partial_pun_succ (D c L θ ν ϱ : ℝ) (σ : Strat) (N : ℕ) :
    partialVal D c L θ ν ϱ .pun σ (N + 1) = stage D c L θ (σ []) (xs D c L θ) +
      ϱ * partialVal D c L θ ν ϱ .pun (fun h => σ (false :: h)) N := by
  unfold partialVal
  rw [Finset.sum_range_succ']
  simp only [expPay, pow_zero, one_mul]
  rw [Finset.mul_sum, add_comm (stage D c L θ (σ []) (xs D c L θ))]
  congr 1
  refine Finset.sum_congr rfl (fun t _ => ?_)
  rw [pow_succ]; ring

/-- In the punishment phase every stage payoff is at most `U_N`: `x*` is a best response to `x*`. -/
lemma expPay_pun_le {D c L θ ν : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ) :
    ∀ (t : ℕ) (σ : Strat), (∀ h, 0 ≤ σ h) → expPay D c L θ ν t .pun σ ≤ UN D c L θ := by
  intro t
  induction t with
  | zero =>
    intro σ hσ
    have hne := ((p10_i_equilibrium hD hc (xs D c L θ) (xs D c L θ)).1).2 ⟨rfl, rfl⟩
    exact hne.1.2 (σ []) (hσ [])
  | succ n ih =>
    intro σ hσ
    exact ih _ (fun h => hσ _)

lemma geom_partial {ϱ : ℝ} (h1 : ϱ < 1) (N : ℕ) :
    ∑ t ∈ Finset.range N, ϱ ^ t = (1 - ϱ ^ N) / (1 - ϱ) := by
  have : ϱ ≠ 1 := ne_of_lt h1
  rw [geom_sum_eq this]
  have : (ϱ - 1) ≠ 0 := sub_ne_zero.mpr this
  have : (1 - ϱ) ≠ 0 := by intro h; apply this; linarith
  field_simp; ring

/-- Punishment-phase partial values are at most `U_N` per period. -/
lemma partial_pun_le {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ) (h0 : 0 ≤ ϱ)
    (h1 : ϱ < 1) (σ : Strat) (hσ : ∀ h, 0 ≤ σ h) (N : ℕ) :
    partialVal D c L θ ν ϱ .pun σ N ≤ UN D c L θ / (1 - ϱ) - ϱ ^ N * (UN D c L θ / (1 - ϱ)) := by
  have hsum : partialVal D c L θ ν ϱ .pun σ N ≤ ∑ t ∈ Finset.range N, ϱ ^ t * UN D c L θ := by
    unfold partialVal
    exact Finset.sum_le_sum (fun t _ =>
      mul_le_mul_of_nonneg_left (expPay_pun_le hD hc t σ hσ) (pow_nonneg h0 t))
  rw [← Finset.sum_mul, geom_partial h1] at hsum
  have : (1 - ϱ) ≠ 0 := by linarith
  calc _ ≤ _ := hsum
    _ = _ := by field_simp

lemma UN_le_UC {D c L θ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ) (h2 : 0 < c + 2 * (L * θ)) :
    UN D c L θ ≤ UC D c L θ := by
  rw [UN_eq hD hc, UC_eq]
  have : 0 < D / (4 * (c + L * θ)) := by positivity
  nlinarith

/-- **One step of the backward induction.** If `ν ≥ ν*`, no single period's effort, followed by
continuation values `W` (undetected) and `P` (punished), beats `W`. This is the one-shot
deviation inequality, for every effort `e ≥ 0`. -/
lemma one_step {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ) (h2 : 0 < c + 2 * (L * θ))
    (h0 : 0 < ϱ) (h1 : ϱ < 1) (hν : nuStar ϱ c L θ ≤ ν) {e : ℝ} (he : 0 ≤ e) :
    stage D c L θ e 0 + ϱ * (detP ν e * (UN D c L θ / (1 - ϱ))
      + (1 - detP ν e) * (UC D c L θ / (1 - ϱ))) ≤ UC D c L θ / (1 - ϱ) := by
  have h1' : (1 - ϱ) ≠ 0 := by linarith
  have hpos : 0 < 1 - ϱ := by linarith
  rcases eq_or_lt_of_le he with rfl | he'
  · simp only [detP, ite_true, zero_mul, zero_add, sub_zero, one_mul]
    have : stage D c L θ 0 0 = UC D c L θ := rfl
    rw [this]
    have : UC D c L θ + ϱ * (UC D c L θ / (1 - ϱ)) = UC D c L θ / (1 - ϱ) := by
      field_simp; ring
    linarith
  · simp only [detP, he'.ne', ite_false]
    have hM := (M_iff hD hc h2 h0 h1).2 hν
    have hg := (gain_iff hc).2 hM e he'
    rw [UC_eq] at hM hg ⊢
    have key : D / 2 / (1 - ϱ) - (stage D c L θ e 0 + ϱ * (ν * (UN D c L θ / (1 - ϱ))
        + (1 - ν) * (D / 2 / (1 - ϱ))))
        = (ϱ * ν * (D / 2 - UN D c L θ) / (1 - ϱ)) - (stage D c L θ e 0 - D / 2) := by
      field_simp; ring
    linarith

/-- **P10(iii), sufficiency against every strategy (the one-shot deviation principle, proved).**
If `ν ≥ ν*`, then for **every** pure strategy `σ` of the repeated game (effort any function of
the public detection history) and every horizon `N`, the discounted expected payoff of the first
`N` periods, against a rival playing restraint with grim-trigger reversion, is at most
`W − ϱ^N P`, where `W = U_C/(1 − ϱ)` is restraint's value and `P = U_N/(1 − ϱ)` punishment's. -/
theorem p10_iii_full_bound {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (hL : 0 ≤ L) (hθ : 0 ≤ θ) (h0 : 0 < ϱ) (h1 : ϱ < 1) (hν0 : 0 ≤ ν) (hν1 : ν ≤ 1)
    (hν : nuStar ϱ c L θ ≤ ν) :
    ∀ (N : ℕ) (σ : Strat), (∀ h, 0 ≤ σ h) →
      partialVal D c L θ ν ϱ .coop σ N
        ≤ UC D c L θ / (1 - ϱ) - ϱ ^ N * (UN D c L θ / (1 - ϱ)) := by
  have h2 : 0 < c + 2 * (L * θ) := by nlinarith [mul_nonneg hL hθ]
  have hpos : 0 < 1 - ϱ := by linarith
  have hWP : UN D c L θ / (1 - ϱ) ≤ UC D c L θ / (1 - ϱ) :=
    div_le_div_of_nonneg_right (UN_le_UC hD hc h2) hpos.le
  intro N
  induction N with
  | zero =>
    intro σ _
    simp only [partialVal, Finset.range_zero, Finset.sum_empty, pow_zero, one_mul]
    linarith
  | succ n ih =>
    intro σ hσ
    rw [partial_coop_succ]
    set e := σ [] with he_def
    set q := detP ν e with hq
    have hq0 : 0 ≤ q := by simp only [hq, detP]; split_ifs <;> linarith
    have hq1 : q ≤ 1 := by simp only [hq, detP]; split_ifs <;> linarith
    have hP := partial_pun_le (ν := ν) hD hc h0.le h1 (fun h => σ (true :: h))
      (fun h => hσ _) n
    have hC := ih (fun h => σ (false :: h)) (fun h => hσ _)
    have hstep := one_step hD hc h2 h0 h1 hν (hσ [])
    rw [← he_def, ← hq] at hstep
    have hrn : 0 ≤ ϱ ^ n := pow_nonneg h0.le n
    set P := UN D c L θ / (1 - ϱ)
    set W := UC D c L θ / (1 - ϱ)
    have hbound : q * partialVal D c L θ ν ϱ .pun (fun h => σ (true :: h)) n
        + (1 - q) * partialVal D c L θ ν ϱ .coop (fun h => σ (false :: h)) n
        ≤ q * P + (1 - q) * W - ϱ ^ n * P := by
      have := mul_le_mul_of_nonneg_left hP hq0
      have := mul_le_mul_of_nonneg_left hC (by linarith : 0 ≤ 1 - q)
      nlinarith
    have := mul_le_mul_of_nonneg_left hbound h0.le
    rw [pow_succ]
    nlinarith

lemma expPay_restraint_coop (D c L θ ν : ℝ) :
    ∀ t, expPay D c L θ ν t .coop restraintS = UC D c L θ := by
  intro t
  induction t with
  | zero => rfl
  | succ n ih =>
    simp only [expPay, restraintS, detP, ite_true, zero_mul, zero_add, sub_zero, one_mul]
    exact ih

/-- Restraint's partial values: `W(1 − ϱ^N)`; they converge to `W = disc ϱ (restraint)`. -/
theorem p10_iii_restraint_value {D c L θ ν ϱ : ℝ} (h1 : ϱ < 1) (N : ℕ) :
    partialVal D c L θ ν ϱ .coop restraintS N = UC D c L θ / (1 - ϱ) - ϱ ^ N * (UC D c L θ / (1 - ϱ)) := by
  unfold partialVal
  simp only [expPay_restraint_coop]
  rw [← Finset.sum_mul, geom_partial h1]
  have : (1 - ϱ) ≠ 0 := by linarith
  field_simp

/-- The bound as an asymptotic statement, with no summability assumed: for every strategy and
every `ε > 0`, the partial values are eventually below restraint's value plus `ε`. -/
theorem p10_iii_full_limsup {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (hL : 0 ≤ L) (hθ : 0 ≤ θ) (h0 : 0 < ϱ) (h1 : ϱ < 1) (hν0 : 0 ≤ ν) (hν1 : ν ≤ 1)
    (hν : nuStar ϱ c L θ ≤ ν) (σ : Strat) (hσ : ∀ h, 0 ≤ σ h) {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ N in atTop, partialVal D c L θ ν ϱ .coop σ N ≤ disc ϱ (restraintStream D c L θ) + ε := by
  rw [show restraintStream D c L θ = fun _ => UC D c L θ from rfl, disc_const h0.le h1]
  have ht : Tendsto (fun N : ℕ => ϱ ^ N * (UN D c L θ / (1 - ϱ))) atTop (𝓝 0) := by
    simpa using (tendsto_pow_atTop_nhds_zero_of_lt_one h0.le h1).mul_const (UN D c L θ / (1 - ϱ))
  have hev : ∀ᶠ N in atTop, -ε < ϱ ^ N * (UN D c L θ / (1 - ϱ)) :=
    ht.eventually (lt_mem_nhds (by linarith))
  filter_upwards [hev] with N hN
  have := p10_iii_full_bound hD hc hL hθ h0 h1 hν0 hν1 hν N σ hσ
  linarith

/-- **P10(iii), sufficiency, as expected discounted values.** If `ν ≥ ν*`, every pure strategy
whose expected payoff series is summable is worth at most restraint. (Non-summable series diverge
to `−∞`, since stage payoffs are bounded above; `p10_iii_full_limsup` covers them.) -/
theorem p10_iii_full_sufficiency {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (hL : 0 ≤ L) (hθ : 0 ≤ θ) (h0 : 0 < ϱ) (h1 : ϱ < 1) (hν0 : 0 ≤ ν) (hν1 : ν ≤ 1)
    (hν : nuStar ϱ c L θ ≤ ν) (σ : Strat) (hσ : ∀ h, 0 ≤ σ h)
    (hs : Summable (fun t => ϱ ^ t * expPay D c L θ ν t .coop σ)) :
    ∑' t, ϱ ^ t * expPay D c L θ ν t .coop σ ≤ disc ϱ (restraintStream D c L θ) := by
  have hlim : Tendsto (fun N => partialVal D c L θ ν ϱ .coop σ N) atTop
      (𝓝 (∑' t, ϱ ^ t * expPay D c L θ ν t .coop σ)) := hs.hasSum.tendsto_sum_nat
  refine le_of_forall_pos_lt_add (fun ε hε => ?_)
  have hε2 : 0 < ε / 2 := by linarith
  have hev := p10_iii_full_limsup hD hc hL hθ h0 h1 hν0 hν1 hν σ hσ hε2
  have hev2 : ∀ᶠ N in atTop, ∑' t, ϱ ^ t * expPay D c L θ ν t .coop σ - ε / 2
      < partialVal D c L θ ν ϱ .coop σ N := hlim.eventually (lt_mem_nhds (by linarith))
  obtain ⟨N, hN1, hN2⟩ := (hev.and hev2).exists
  linarith

/-- The one-shot deviation to `e > 0`, as a strategy of the full game: `e` in period 0, then
restraint if undetected and the stage equilibrium if detected. -/
noncomputable def oneShotS (D c L θ e : ℝ) : Strat
  | [] => e
  | true :: _ => xs D c L θ
  | false :: _ => 0

lemma expPay_const_pun (D c L θ ν a : ℝ) :
    ∀ t, expPay D c L θ ν t .pun (fun _ => a) = stage D c L θ a (xs D c L θ) := by
  intro t; induction t with
  | zero => rfl
  | succ n ih => simp only [expPay]; exact ih

lemma expPay_oneShot {D c L θ ν e : ℝ} (he : e ≠ 0) (t : ℕ) :
    expPay D c L θ ν t .coop (oneShotS D c L θ e) = oneShotStream D c L θ ν e t := by
  cases t with
  | zero => simp [expPay, oneShotS, oneShotStream, he]
  | succ n =>
    have hT : (fun h => oneShotS D c L θ e (true :: h)) = fun _ => xs D c L θ := rfl
    have hF : (fun h => oneShotS D c L θ e (false :: h)) = restraintS := rfl
    have hd : detP ν (oneShotS D c L θ e []) = ν := by simp [detP, oneShotS, he]
    have hs : oneShotStream D c L θ ν e (n + 1) = ν * UN D c L θ + (1 - ν) * UC D c L θ := by
      simp [oneShotStream, he]
    rw [expPay, hd, hT, hF, expPay_const_pun, expPay_restraint_coop, hs]
    rfl

lemma hasSum_oneShot {D c L θ ν e ϱ : ℝ} (h0 : 0 ≤ ϱ) (h1 : ϱ < 1) (he : e ≠ 0) :
    HasSum (fun t => ϱ ^ t * oneShotStream D c L θ ν e t)
      (disc ϱ (oneShotStream D c L θ ν e)) := by
  set B := ν * UN D c L θ + (1 - ν) * UC D c L θ
  set A := stage D c L θ e 0
  have hB := (hasSum_geometric_of_lt_one h0 h1).mul_right B
  have hI := hasSum_ite_eq (0 : ℕ) (A - B)
  have hsum := hB.add hI
  have hfun : (fun t => ϱ ^ t * oneShotStream D c L θ ν e t)
      = fun t => ϱ ^ t * B + (if t = 0 then A - B else 0) := by
    funext t; rcases t with _ | n <;> simp [oneShotStream, he, A, B]
  rw [hfun]
  unfold disc
  rw [hfun, hsum.tsum_eq]
  exact hsum

/-- **P10(iii), both directions in the full game.** Restraint is worth at least every pure
strategy of the repeated game (every one whose expected payoff series is summable; the others are
covered by `p10_iii_full_limsup`) **iff** `ν ≥ ν*`. Hypotheses: the text's `D > 0`, `0 < ϱ < 1`,
`L, θ ≥ 0`, P9's `c + Lθ > 0`, and `ν ∈ [0, 1]` (a probability). -/
theorem p10_iii_full_iff {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (hL : 0 ≤ L) (hθ : 0 ≤ θ) (h0 : 0 < ϱ) (h1 : ϱ < 1) (hν0 : 0 ≤ ν) (hν1 : ν ≤ 1) :
    (∀ σ : Strat, (∀ h, 0 ≤ σ h) → Summable (fun t => ϱ ^ t * expPay D c L θ ν t .coop σ) →
        ∑' t, ϱ ^ t * expPay D c L θ ν t .coop σ ≤ disc ϱ (restraintStream D c L θ)) ↔
      nuStar ϱ c L θ ≤ ν := by
  have h2 : 0 < c + 2 * (L * θ) := by nlinarith [mul_nonneg hL hθ]
  constructor
  · intro H
    refine (p10_iii_restraint_iff hD hc h2 h0 h1).1 (fun e he => ?_)
    rcases eq_or_lt_of_le he with rfl | he'
    · rw [oneShot_zero]
    · have hfun : (fun t => ϱ ^ t * expPay D c L θ ν t .coop (oneShotS D c L θ e))
          = fun t => ϱ ^ t * oneShotStream D c L θ ν e t := by
        funext t; rw [expPay_oneShot he'.ne']
      have hnn : ∀ h, 0 ≤ oneShotS D c L θ e h := by
        intro h
        rcases h with _ | ⟨b, h⟩
        · exact he
        · cases b
          · exact le_rfl
          · exact (div_pos hD (by linarith)).le
      have hS := hasSum_oneShot (ν := ν) (D := D) (c := c) (L := L) (θ := θ) h0.le h1 he'.ne'
      have := H _ hnn (by rw [hfun]; exact hS.summable)
      rw [hfun, hS.tsum_eq] at this
      exact this
  · intro hν σ hσ hs
    exact p10_iii_full_sufficiency hD hc hL hθ h0 h1 hν0 hν1 hν σ hσ hs

/-- **Punishment subgames.** In every punishment subgame, playing the stage equilibrium is a best
response: no strategy beats `x*`-forever, whose partial values are `P(1 − ϱ^N)`. With the
coordination-phase subgames (identical to the whole game, so covered by `p10_iii_full_bound`
applied to the continuation strategy), restraint with grim trigger is subgame perfect. -/
theorem p10_iii_punishment_best {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (h0 : 0 < ϱ) (h1 : ϱ < 1) (σ : Strat) (hσ : ∀ h, 0 ≤ σ h) (N : ℕ) :
    partialVal D c L θ ν ϱ .pun σ N ≤ partialVal D c L θ ν ϱ .pun (fun _ => xs D c L θ) N := by
  have hx : partialVal D c L θ ν ϱ .pun (fun _ => xs D c L θ) N
      = UN D c L θ / (1 - ϱ) - ϱ ^ N * (UN D c L θ / (1 - ϱ)) := by
    unfold partialVal
    simp only [expPay_const_pun]
    rw [show stage D c L θ (xs D c L θ) (xs D c L θ) = UN D c L θ from rfl, ← Finset.sum_mul,
      geom_partial h1]
    have : (1 - ϱ) ≠ 0 := by linarith
    field_simp
  rw [hx]; exact partial_pun_le hD hc h0.le h1 σ hσ N

/-- Coordination-phase subgames after any undetected history are the original game: the bound
applies to every continuation strategy. -/
theorem p10_iii_subgame_coop {D c L θ ν ϱ : ℝ} (hD : 0 < D) (hc : 0 < c + L * θ)
    (hL : 0 ≤ L) (hθ : 0 ≤ θ) (h0 : 0 < ϱ) (h1 : ϱ < 1) (hν0 : 0 ≤ ν) (hν1 : ν ≤ 1)
    (hν : nuStar ϱ c L θ ≤ ν) (σ : Strat) (hσ : ∀ h, 0 ≤ σ h) (k N : ℕ) :
    partialVal D c L θ ν ϱ .coop (fun h => σ (List.replicate k false ++ h)) N
      ≤ UC D c L θ / (1 - ϱ) - ϱ ^ N * (UN D c L θ / (1 - ϱ)) :=
  p10_iii_full_bound hD hc hL hθ h0 h1 hν0 hν1 hν N _ (fun _ => hσ _)


end P10

section P11jump
open Real MeasureTheory Set Filter Topology intervalIntegral RTTR.Release


/-! ## P11(i), the jump-point clause: rents that jump -/

/-- Integrability of the post-release integrand for a rent that is merely measurable and bounded
on `[0, X]` (it may jump). -/
theorem f_integrableOn_bdd (ρ : ℝ → ℝ) {r κ x X a C : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) (hx : 0 ≤ x)
    (hρm : Measurable ρ) (hC : ∀ y ∈ Icc 0 X, |ρ y| ≤ C) (ha : x * exp (-κ * a) ≤ X) :
    IntegrableOn (fun s => exp (-r * s) * ρ (x * exp (-κ * s))) (Ioi a) := by
  have hmaps : MapsTo (fun s => x * exp (-κ * s)) (Ici a) (Icc 0 X) := fun s hs => by
    refine ⟨mul_nonneg hx (exp_pos _).le, le_trans ?_ ha⟩
    exact mul_le_mul_of_nonneg_left (exp_le_exp.mpr (by nlinarith [show a ≤ s from hs])) hx
  have hmeas : Measurable (fun s => exp (-r * s) * ρ (x * exp (-κ * s))) :=
    (by fun_prop : Measurable fun s : ℝ => exp (-r * s)).mul (hρm.comp (by fun_prop))
  refine Integrable.mono' ((exp_neg_integrableOn_Ioi a hr).const_mul C)
    hmeas.aestronglyMeasurable ?_
  refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
  rw [norm_mul, Real.norm_of_nonneg (exp_pos _).le, Real.norm_eq_abs]
  have := hC _ (hmaps (Set.mem_Ici.mpr (le_of_lt hs)))
  nlinarith [exp_pos (-r * s), abs_nonneg (ρ (x * exp (-κ * s)))]

/-- The shift identity for a bounded measurable rent. -/
theorem Pi_shift_bdd (ρ : ℝ → ℝ) {r κ x X h C : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) (hx : 0 ≤ x)
    (hρm : Measurable ρ) (hC : ∀ y ∈ Icc 0 X, |ρ y| ≤ C) (hh : x * exp (-κ * h) ≤ X)
    (h0 : x ≤ X) :
    Pi ρ r κ (x * exp (-κ * h)) =
      exp (r * h) * (Pi ρ r κ x - ∫ u in (0:ℝ)..h, exp (-r * u) * ρ (x * exp (-κ * u))) := by
  set f := fun u => exp (-r * u) * ρ (x * exp (-κ * u)) with hf
  have h1 : Pi ρ r κ (x * exp (-κ * h)) = exp (r * h) * ∫ s in Ioi (0:ℝ), f (s + h) := by
    unfold Pi
    rw [← MeasureTheory.integral_const_mul]
    refine setIntegral_congr_fun measurableSet_Ioi (fun s _ => ?_)
    simp only [hf]
    have e1 : exp (-r * s) = exp (r * h) * exp (-r * (s + h)) := by rw [← exp_add]; ring_nf
    have e2 : x * exp (-κ * h) * exp (-κ * s) = x * exp (-κ * (s + h)) := by
      rw [mul_assoc, ← exp_add]; ring_nf
    rw [e1, e2]; ring
  have hI0 : IntegrableOn f (Ioi 0) := f_integrableOn_bdd ρ hr hκ hx hρm hC (by simpa using h0)
  have hIh : IntegrableOn f (Ioi h) := f_integrableOn_bdd ρ hr hκ hx hρm hC hh
  have h2 := intervalIntegral.integral_interval_add_Ioi hI0 hIh
  rw [h1, integral_Ioi_shift f h]
  unfold Pi
  rw [← h2]; ring

/-- **`Π` is differentiable wherever the rent is continuous**, even if it jumps elsewhere
(`κ > 0`, rent measurable and bounded on `[0, X]`, `0 < x < X`), with `rΠ = ρ − κxΠ′` there. -/
theorem Pi_hasDerivAt_of_continuousAt (ρ : ℝ → ℝ) {r κ x X C : ℝ} (hr : 0 < r) (hκ : 0 < κ)
    (hx : 0 < x) (hX : x < X) (hρm : Measurable ρ) (hC : ∀ y ∈ Icc 0 X, |ρ y| ≤ C)
    (hρx : ContinuousAt ρ x) :
    HasDerivAt (Pi ρ r κ) ((ρ x - r * Pi ρ r κ x) / (κ * x)) x := by
  set f := fun u => exp (-r * u) * ρ (x * exp (-κ * u)) with hf
  set P := Pi ρ r κ x
  set hy := fun y => -Real.log (y / x) / κ with hhy
  have hyx : ∀ y, 0 < y → x * exp (-κ * hy y) = y := by
    intro y hy0
    simp only [hhy]
    rw [show -κ * (-Real.log (y / x) / κ) = Real.log (y / x) by field_simp,
      exp_log (div_pos hy0 hx)]
    field_simp
  have hev : Pi ρ r κ =ᶠ[𝓝 x] fun y => exp (r * hy y) * (P - ∫ u in (0:ℝ)..hy y, f u) := by
    filter_upwards [Ioo_mem_nhds hx hX] with y hy'
    have := Pi_shift_bdd ρ (h := hy y) hr hκ.le hx.le hρm hC
      (by rw [hyx y hy'.1]; exact hy'.2.le) hX.le
    rw [hyx y hy'.1] at this
    exact this
  have hh : HasDerivAt hy (-(1 / x) / κ) x := by
    have h1 : HasDerivAt (fun y => y / x) (1 / x) x := by
      simpa using (hasDerivAt_id x).div_const x
    have h2 := (h1.log (by simp [hx.ne'])).neg.div_const κ
    convert h2 using 1
    field_simp
  have hh0 : hy x = 0 := by simp [hhy, div_self hx.ne']
  have hfm : Measurable f :=
    (by fun_prop : Measurable fun s : ℝ => exp (-r * s)).mul (hρm.comp (by fun_prop))
  have hfc : ContinuousAt f 0 := by
    have hin : ContinuousAt (fun u : ℝ => x * exp (-κ * u)) 0 := by fun_prop
    have hρ0 : ContinuousAt ρ (x * exp (-κ * 0)) := by simpa using hρx
    exact (by fun_prop : ContinuousAt (fun u : ℝ => exp (-r * u)) 0).mul
      (ContinuousAt.comp (g := ρ) (f := fun u : ℝ => x * exp (-κ * u)) hρ0 hin)
  have hFTC : HasDerivAt (fun h => ∫ u in (0:ℝ)..h, f u) (f 0) 0 :=
    integral_hasDerivAt_right (by simp)
      (hfm.stronglyMeasurable.stronglyMeasurableAtFilter) hfc
  have hFTC' : HasDerivAt (fun h => ∫ u in (0:ℝ)..h, f u) (f 0) (hy x) := by
    rw [hh0]; exact hFTC
  have hF := hFTC'.comp x hh
  have hE := ((hh.const_mul r).exp)
  have hG := hE.mul (hF.const_sub P)
  have hG' : HasDerivAt (fun y => exp (r * hy y) * (P - ∫ u in (0:ℝ)..hy y, f u))
      (exp (r * hy x) * (r * (-(1 / x) / κ)) * (P - ∫ u in (0:ℝ)..hy x, f u) +
        exp (r * hy x) * (-(f 0 * (-(1 / x) / κ)))) x := hG
  refine (hG'.congr_of_eventuallyEq hev).congr_deriv ?_
  rw [hh0]
  simp only [hf, mul_zero, exp_zero, intervalIntegral.integral_same, sub_zero, one_mul, mul_one]
  field_simp
  ring

/-- `V′(T) = e^{−(r+λ)T}Φ(T)` at any date where the hold integrand is continuous and `J` is
differentiable, for a hold integrand that is merely integrable (the rent may jump). -/
theorem V_hasDerivAt_gen (ρ : ℝ → ℝ) (p : Prm) {T : ℝ}
    (hint : IntervalIntegrable (holdIntegrand ρ p) volume 0 T)
    (hmeas : Measurable (holdIntegrand ρ p)) (hcat : ContinuousAt (holdIntegrand ρ p) T)
    (hJ : DifferentiableAt ℝ (J ρ p) T) :
    HasDerivAt (V ρ p) (exp (-(p.r + p.lam) * T) * Phi ρ p T) T := by
  have h1 := integral_hasDerivAt_right hint
    (hmeas.stronglyMeasurable.stronglyMeasurableAtFilter) hcat
  have h2 : HasDerivAt (fun T => exp (-(p.r + p.lam) * T))
      (exp (-(p.r + p.lam) * T) * (-(p.r + p.lam) * 1)) T :=
    ((hasDerivAt_id T).const_mul _).exp
  have h3 := h2.mul hJ.hasDerivAt
  have h4 := h1.add h3
  unfold V
  convert h4 using 1
  unfold holdIntegrand Phi
  ring

theorem holdIntegrand_measurable (ρ : ℝ → ℝ) (p : Prm) (hρm : Measurable ρ) :
    Measurable (holdIntegrand ρ p) := by
  unfold holdIntegrand lead
  exact (by fun_prop : Measurable fun t : ℝ => exp (-(p.r + p.lam) * t)).mul
    (measurable_const.add (hρm.comp (by fun_prop)))

theorem holdIntegrand_intervalIntegrable (ρ : ℝ → ℝ) (p : Prm) (hρm : Measurable ρ)
    {C : ℝ} (hC : ∀ y ∈ Icc 0 (p.g0 + p.Δ), |ρ y| ≤ C) (ha : 0 ≤ p.r + p.lam)
    (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ) (hk : 0 ≤ p.kpre) {T : ℝ} (hT : 0 ≤ T) :
    IntervalIntegrable (holdIntegrand ρ p) volume 0 T := by
  rw [intervalIntegrable_iff_integrableOn_Icc_of_le hT]
  refine Integrable.mono' (integrableOn_const (C := |p.F + p.lam * p.Z| + C)
    (by simp [Real.volume_Icc])) (holdIntegrand_measurable ρ p hρm).aestronglyMeasurable ?_
  refine (ae_restrict_iff' measurableSet_Icc).mpr (Eventually.of_forall fun t ht => ?_)
  have hl := lead_mem p hg hk ht.1
  have hb := hC (lead p t) ⟨hl.1, by linarith [hl.2]⟩
  have he1 : exp (-(p.r + p.lam) * t) ≤ 1 := exp_le_one_iff.mpr (by nlinarith [ht.1])
  have he0 := exp_pos (-(p.r + p.lam) * t)
  unfold holdIntegrand
  rw [Real.norm_eq_abs, abs_mul, abs_of_pos he0]
  have : |p.F + p.lam * p.Z + ρ (lead p t)| ≤ |p.F + p.lam * p.Z| + C :=
    (abs_add_le _ _).trans (by linarith)
  have hnn : 0 ≤ |p.F + p.lam * p.Z + ρ (lead p t)| := abs_nonneg _
  nlinarith

/-- **P11(i), smoothness off the jump dates (`κ_post > 0`).** For a rent that is measurable and
bounded on `[0, g₀ + Δ]` and may jump, `V` is differentiable with `V′ = e^{−(r+λ)T}Φ` at every
date `T > 0` at which neither `g(T)` nor `g(T) + Δ` is a discontinuity of `ρ`. -/
theorem p11i_jump_V_hasDerivAt (ρ : ℝ → ℝ) (p : Prm) (hr : 0 < p.r) (hl : 0 ≤ p.lam)
    (hκ : 0 < p.kpost) (hg : 0 < p.g0) (hk : 0 < p.kpre) (hΔ : 0 ≤ p.Δ) (hρm : Measurable ρ)
    {C : ℝ} (hC : ∀ y ∈ Icc 0 (p.g0 + p.Δ), |ρ y| ≤ C) {T : ℝ} (hT : 0 < T)
    (hc1 : ContinuousAt ρ (lead p T)) (hc2 : ContinuousAt ρ (lead p T + p.Δ)) :
    HasDerivAt (V ρ p) (exp (-(p.r + p.lam) * T) * Phi ρ p T) T := by
  have hlt : lead p T < p.g0 := by have := lead_lt p hg hk hT; simpa [lead] using this
  have hl0 : 0 < lead p T := mul_pos hg (exp_pos _)
  have hPi := Pi_hasDerivAt_of_continuousAt ρ hr hκ (by linarith : 0 < lead p T + p.Δ)
    (by linarith : lead p T + p.Δ < p.g0 + p.Δ) hρm hC hc2
  have hJ : DifferentiableAt ℝ (J ρ p) T :=
    (hPi.comp T ((lead_hasDerivAt p T).add_const p.Δ)).differentiableAt
  have hcat : ContinuousAt (holdIntegrand ρ p) T := by
    unfold holdIntegrand
    exact (by fun_prop : ContinuousAt (fun t : ℝ => exp (-(p.r + p.lam) * t)) T).mul
      (continuousAt_const.add (hc1.comp (lead_continuous p).continuousAt))
  exact V_hasDerivAt_gen ρ p
    (holdIntegrand_intervalIntegrable ρ p hρm hC (by linarith) hg.le hΔ hk.le hT.le)
    (holdIntegrand_measurable ρ p hρm) hcat hJ

/-- **P11(i), the jump-point clause (`κ_post > 0`).** If the rent jumps, every interior local
maximum of `V`, in particular every optimal interior release date, is either a zero of `Φ` or a
date at which `g(T)` or `g(T) + Δ` is a jump point (a discontinuity) of `ρ`: those dates join
the candidate set, and no others do. -/
theorem p11i_jump_candidates (ρ : ℝ → ℝ) (p : Prm) (hr : 0 < p.r) (hl : 0 ≤ p.lam)
    (hκ : 0 < p.kpost) (hg : 0 < p.g0) (hk : 0 < p.kpre) (hΔ : 0 ≤ p.Δ) (hρm : Measurable ρ)
    {C : ℝ} (hC : ∀ y ∈ Icc 0 (p.g0 + p.Δ), |ρ y| ≤ C) {T : ℝ} (hT : 0 < T)
    (hmax : IsLocalMax (V ρ p) T) :
    Phi ρ p T = 0 ∨ ¬ ContinuousAt ρ (lead p T) ∨ ¬ ContinuousAt ρ (lead p T + p.Δ) := by
  by_contra hcon
  push Not at hcon
  obtain ⟨hΦ, hc1, hc2⟩ := hcon
  have hd := p11i_jump_V_hasDerivAt ρ p hr hl hκ hg hk hΔ hρm hC hT hc1 hc2
  have := hmax.hasDerivAt_eq_zero hd
  rcases mul_eq_zero.mp this with h | h
  · exact (exp_pos _).ne' h
  · exact hΦ h

/-- The same clause for the optimum over all release dates: an optimal date `T* > 0` is a zero
of `Φ` or a jump date. -/
theorem p11i_jump_optimum (ρ : ℝ → ℝ) (p : Prm) (hr : 0 < p.r) (hl : 0 ≤ p.lam)
    (hκ : 0 < p.kpost) (hg : 0 < p.g0) (hk : 0 < p.kpre) (hΔ : 0 ≤ p.Δ) (hρm : Measurable ρ)
    {C : ℝ} (hC : ∀ y ∈ Icc 0 (p.g0 + p.Δ), |ρ y| ≤ C) {T : ℝ} (hT : 0 < T)
    (hmax : IsMaxOn (V ρ p) (Ici 0) T) :
    Phi ρ p T = 0 ∨ ¬ ContinuousAt ρ (lead p T) ∨ ¬ ContinuousAt ρ (lead p T + p.Δ) :=
  p11i_jump_candidates ρ p hr hl hκ hg hk hΔ hρm hC hT
    (hmax.isLocalMax (Ici_mem_nhds hT))

/-- **The jump-point clause with `κ_post = 0`.** Then `Π = ρ/r`, so `J(T) = ρ(g(T) + Δ)/r` itself
jumps where `g(T) + Δ` crosses a jump point; at every other date where `ρ` is differentiable at
`g(T) + Δ` and continuous at `g(T)`, `V′ = e^{−(r+λ)T}Φ`, so interior optima are zeros of `Φ`
or dates at which `ρ` fails to be continuous at `g(T)` or differentiable at `g(T) + Δ`. -/
theorem p11i_jump_candidates_kpost0 (ρ : ℝ → ℝ) (p : Prm) (hr : 0 < p.r) (hl : 0 ≤ p.lam)
    (hκ : p.kpost = 0) (hg : 0 ≤ p.g0) (hk : 0 ≤ p.kpre) (hΔ : 0 ≤ p.Δ) (hρm : Measurable ρ)
    {C : ℝ} (hC : ∀ y ∈ Icc 0 (p.g0 + p.Δ), |ρ y| ≤ C) {T : ℝ} (hT : 0 < T)
    (hmax : IsLocalMax (V ρ p) T) :
    Phi ρ p T = 0 ∨ ¬ ContinuousAt ρ (lead p T) ∨
      ¬ DifferentiableAt ℝ ρ (lead p T + p.Δ) := by
  by_contra hcon
  push Not at hcon
  obtain ⟨hΦ, hc1, hd2⟩ := hcon
  have hJeq : J ρ p = fun T => ρ (lead p T + p.Δ) / p.r := by
    funext t; unfold J; rw [hκ]; exact (Pi_kpost_zero ρ hr _).1
  have hJ : DifferentiableAt ℝ (J ρ p) T := by
    rw [hJeq]
    exact ((hd2.hasDerivAt.comp T ((lead_hasDerivAt p T).add_const p.Δ)).div_const
      p.r).differentiableAt
  have hcat : ContinuousAt (holdIntegrand ρ p) T := by
    unfold holdIntegrand
    exact (by fun_prop : ContinuousAt (fun t : ℝ => exp (-(p.r + p.lam) * t)) T).mul
      (continuousAt_const.add (hc1.comp (lead_continuous p).continuousAt))
  have hd := V_hasDerivAt_gen ρ p
    (holdIntegrand_intervalIntegrable ρ p hρm hC (by linarith) hg hΔ hk hT.le)
    (holdIntegrand_measurable ρ p hρm) hcat hJ
  have := hmax.hasDerivAt_eq_zero hd
  rcases mul_eq_zero.mp this with h | h
  · exact (exp_pos _).ne' h
  · exact hΦ h

section JumpExample
open RTTR.Gaps2

theorem rhoJ_measurable : Measurable ρJ := by
  unfold ρJ
  exact measurable_id.add (Measurable.ite measurableSet_Ici measurable_const measurable_const)

theorem rhoJ_bdd : ∀ y ∈ Icc (0:ℝ) (pJ.g0 + pJ.Δ), |ρJ y| ≤ 4 := by
  intro y hy
  simp only [pJ] at hy
  unfold ρJ
  split_ifs <;> rw [abs_le] <;> constructor <;> linarith [hy.1, hy.2]

theorem rhoJ_not_continuousAt_one : ¬ ContinuousAt ρJ 1 := by
  intro h
  have h1 : Tendsto ρJ (𝓝[<] 1) (𝓝 (ρJ 1)) := h.tendsto.mono_left nhdsWithin_le_nhds
  have h2 : Tendsto ρJ (𝓝[<] 1) (𝓝 1) := by
    have : Tendsto (fun y : ℝ => y) (𝓝[<] 1) (𝓝 1) :=
      tendsto_id.mono_left nhdsWithin_le_nhds
    refine this.congr' ?_
    filter_upwards [self_mem_nhdsWithin] with y hy
    have : ¬ (1 ≤ y) := not_le.mpr hy
    simp [ρJ, this]
  have := tendsto_nhds_unique h1 h2
  norm_num [ρJ] at this

/-- Gaps2 restates P11's objects verbatim in its own namespace; `toRel` maps its parameters to
Release's, and the objects agree definitionally. -/
def toRel (p : Gaps2.Prm) : Release.Prm := ⟨p.r, p.lam, p.F, p.Z, p.kpre, p.kpost, p.g0, p.Δ⟩

theorem bridge_lead (p : Gaps2.Prm) : Gaps2.lead p = Release.lead (toRel p) := rfl
theorem bridge_V (ρ : ℝ → ℝ) (p : Gaps2.Prm) : Gaps2.V ρ p = Release.V ρ (toRel p) := rfl
theorem bridge_Phi (ρ : ℝ → ℝ) (p : Gaps2.Prm) : Gaps2.Phi ρ p = Release.Phi ρ (toRel p) := rfl

/-- **The paper's jump example meets the general clause.** The rent `ρ(x) = x + 1{x ≥ 1}` is
measurable and bounded, so `p11i_jump_optimum` applies; its strict global optimum `T₀ = ln 1.1`
(Gaps2, `p33_jump_kink_optimum`) is not a zero of `Φ` and is exactly a date at which `g(T)`
crosses the jump point `1`, as the clause says; it is the only positive date at which `g(T)`
equals `1`, and `g(T) + Δ` never does. -/
theorem p11i_jump_example :
    IsMaxOn (Release.V ρJ (toRel pJ)) (Ici 0) T0 ∧ Release.Phi ρJ (toRel pJ) T0 ≠ 0 ∧
    ¬ ContinuousAt ρJ (Release.lead (toRel pJ) T0) ∧
    (Release.Phi ρJ (toRel pJ) T0 = 0 ∨ ¬ ContinuousAt ρJ (Release.lead (toRel pJ) T0) ∨
      ¬ ContinuousAt ρJ (Release.lead (toRel pJ) T0 + (toRel pJ).Δ)) ∧
    (∀ T, 0 < T → Release.lead (toRel pJ) T = 1 → T = T0) ∧
    (∀ T, 0 ≤ T → Release.lead (toRel pJ) T + (toRel pJ).Δ ≠ 1) := by
  obtain ⟨hl, -, -, hne, -, -, -, hlt, -⟩ := p33_jump_kink_optimum
  rw [bridge_lead] at hl
  have hmax : IsMaxOn (Release.V ρJ (toRel pJ)) (Ici 0) T0 := by
    intro T hT
    show Release.V ρJ (toRel pJ) T ≤ Release.V ρJ (toRel pJ) T0
    rcases eq_or_ne T T0 with rfl | h
    · exact le_rfl
    · have := hlt T hT h
      rw [bridge_V] at this
      exact this.le
  have hbdd : ∀ y ∈ Icc (0:ℝ) ((toRel pJ).g0 + (toRel pJ).Δ), |ρJ y| ≤ 4 := rhoJ_bdd
  have hne0 : Release.Phi ρJ (toRel pJ) T0 ≠ 0 := by
    have := hne T0 T0_pos.le le_rfl; rwa [bridge_Phi] at this
  refine ⟨hmax, hne0, by rw [hl]; exact rhoJ_not_continuousAt_one,
    p11i_jump_optimum ρJ (toRel pJ) (by norm_num [toRel, pJ]) (by norm_num [toRel, pJ])
      (by norm_num [toRel, pJ]) (by norm_num [toRel, pJ]) (by norm_num [toRel, pJ])
      (by norm_num [toRel, pJ]) rhoJ_measurable hbdd T0_pos hmax, ?_, ?_⟩
  · intro T _ hT
    have h1 := (lead_pJ_ge_one_iff T).1 (by rw [bridge_lead]; exact hT.ge)
    by_contra hne'
    have hlt' : T < T0 := lt_of_le_of_ne h1 hne'
    have := Release.lead_lt (toRel pJ) (by norm_num [toRel, pJ]) (by norm_num [toRel, pJ]) hlt'
    rw [hl, hT] at this
    exact lt_irrefl _ this
  · intro T _
    have := lead_pJ_pos T
    rw [bridge_lead] at this
    simp only [toRel, pJ] at this ⊢; linarith

end JumpExample


end P11jump

section P11kpost
open Real MeasureTheory Set Filter Topology intervalIntegral RTTR.Release


/-! ## P11(v), post-release copying for general rents: `xρ′(x)` non-decreasing -/

/-- `q(y) = yρ′(y)`, with `ρ′` the derivative of the rent as a function. -/
noncomputable def qf (ρ : ℝ → ℝ) (y : ℝ) : ℝ := y * deriv ρ y

/-- `I₀ = ∫₀^∞ e^{−rs} q(xe^{−κs}) ds`; the proof shows `xΠ′(x) = I₀`. -/
noncomputable def I0 (ρ : ℝ → ℝ) (r κ x : ℝ) : ℝ :=
  ∫ s in Ioi (0:ℝ), exp (-r * s) * qf ρ (x * exp (-κ * s))

/-- `I₁ = ∫₀^∞ s e^{−rs} q(xe^{−κs}) ds`; the proof shows `∂Π/∂κ_post = −I₁`. -/
noncomputable def I1 (ρ : ℝ → ℝ) (r κ x : ℝ) : ℝ :=
  ∫ s in Ioi (0:ℝ), s * exp (-r * s) * qf ρ (x * exp (-κ * s))

theorem measurable_qf (ρ : ℝ → ℝ) : Measurable (qf ρ) :=
  measurable_id.mul (measurable_deriv ρ)

theorem integrableOn_id_mul_exp {r : ℝ} (hr : 0 < r) :
    IntegrableOn (fun s : ℝ => s * exp (-r * s)) (Ioi 0) := by
  have h := integrableOn_rpow_mul_exp_neg_mul_rpow (s := 1) (p := 1) (b := r)
    (by norm_num) one_pos hr
  refine h.congr_fun (fun s _ => ?_) measurableSet_Ioi
  simp only [rpow_one, neg_mul]

theorem integral_id_mul_exp {r : ℝ} (hr : 0 < r) :
    ∫ s in Ioi (0:ℝ), s * exp (-r * s) = 1 / r ^ 2 := by
  have h := integral_rpow_mul_exp_neg_mul_Ioi (a := 2) (r := r) two_pos hr
  rw [show (2:ℝ) - 1 = 1 by norm_num, Real.Gamma_two, mul_one] at h
  have e : ∫ s in Ioi (0:ℝ), s * exp (-r * s) = ∫ t in Ioi (0:ℝ), t ^ (1:ℝ) * exp (-(r * t)) :=
    setIntegral_congr_fun measurableSet_Ioi (fun s _ => by simp only [rpow_one, neg_mul])
  rw [e, h, show (2:ℝ) = ((2:ℕ):ℝ) by norm_num, rpow_natCast]
  field_simp

/-- The rent's composite stays in `(0, x)` for `s > 0`, `κ > 0`. -/
theorem scaled_mem_Ioo {x κ s : ℝ} (hx : 0 < x) (hκ : 0 < κ) (hs : 0 < s) :
    x * exp (-κ * s) ∈ Ioo 0 x := by
  have h1 : exp (-κ * s) < 1 := exp_lt_one_iff.mpr (by nlinarith)
  exact ⟨mul_pos hx (exp_pos _), by nlinarith [exp_pos (-κ * s)]⟩

/-- Differentiation under the integral over `(0, ∞)`, in the form used twice below. -/
theorem dom_deriv (G G' : ℝ → ℝ → ℝ) (b : ℝ → ℝ) (U : Set ℝ) (κ0 : ℝ) (hU : U ∈ 𝓝 κ0)
    (hmeas : ∀ᶠ κ in 𝓝 κ0, AEStronglyMeasurable (G κ) (volume.restrict (Ioi (0:ℝ))))
    (hint : Integrable (G κ0) (volume.restrict (Ioi (0:ℝ))))
    (hF'm : AEStronglyMeasurable (G' κ0) (volume.restrict (Ioi (0:ℝ))))
    (hbound : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ κ ∈ U, ‖G' κ s‖ ≤ b s)
    (hbint : Integrable b (volume.restrict (Ioi (0:ℝ))))
    (hdiff : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ κ ∈ U,
      HasDerivAt (fun κ => G κ s) (G' κ s) κ) :
    HasDerivAt (fun κ => ∫ s in Ioi (0:ℝ), G κ s) (∫ s in Ioi (0:ℝ), G' κ0 s) κ0 :=
  (_root_.hasDerivAt_integral_of_dominated_loc_of_deriv_le hU hmeas hint hF'm hbound hbint hdiff).2

/-- **`∂Π/∂κ_post = −I₁`**, by differentiation under the integral sign (`κ > 0`, rent continuous
on `[0, X]`, differentiable on `(0, X)`, `q` bounded there). -/
theorem Pi_hasDerivAt_kappa (ρ : ℝ → ℝ) {r κ0 x X Q : ℝ} (hr : 0 < r) (hκ : 0 < κ0)
    (hx : 0 < x) (hX : x < X) (hρc : ContinuousOn ρ (Icc 0 X))
    (hρd : ∀ y ∈ Ioo 0 X, DifferentiableAt ℝ ρ y) (hQ : ∀ y ∈ Ioo 0 X, |qf ρ y| ≤ Q) :
    HasDerivAt (fun κ => Pi ρ r κ x) (-I1 ρ r κ0 x) κ0 := by
  have hint : ∀ κ, 0 ≤ κ → IntegrableOn (fun s => exp (-r * s) * ρ (x * exp (-κ * s))) (Ioi 0) :=
    fun κ hk => f_integrableOn ρ hr hk hx.le hρc (by simp; exact hX.le)
  have hmeas : ∀ᶠ κ in 𝓝 κ0, AEStronglyMeasurable
      (fun s => exp (-r * s) * ρ (x * exp (-κ * s))) (volume.restrict (Ioi (0:ℝ))) := by
    filter_upwards [Ioi_mem_nhds hκ] with κ hk
    exact (hint κ (le_of_lt hk)).aestronglyMeasurable
  have hF'm : AEStronglyMeasurable (fun s => -(s * exp (-r * s) * qf ρ (x * exp (-κ0 * s))))
      (volume.restrict (Ioi (0:ℝ))) :=
    (((by fun_prop : Measurable fun s : ℝ => s * exp (-r * s)).mul
        ((measurable_qf ρ).comp (by fun_prop))).neg).aestronglyMeasurable
  have hbound : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ κ ∈ Ioi (0:ℝ),
      ‖-(s * exp (-r * s) * qf ρ (x * exp (-κ * s)))‖ ≤ s * exp (-r * s) * Q := by
    refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
    intro κ hk
    have hs' : 0 < s := hs
    have hm := scaled_mem_Ioo hx hk hs'
    have hq := hQ _ ⟨hm.1, hm.2.trans hX⟩
    have hs0 : 0 ≤ s * exp (-r * s) := mul_nonneg hs'.le (exp_pos _).le
    rw [norm_neg, Real.norm_eq_abs, abs_mul, abs_of_nonneg hs0]
    exact mul_le_mul_of_nonneg_left hq hs0
  have hbint : Integrable (fun s => s * exp (-r * s) * Q) (volume.restrict (Ioi (0:ℝ))) :=
    (integrableOn_id_mul_exp hr).mul_const Q
  have hdiff : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ κ ∈ Ioi (0:ℝ),
      HasDerivAt (fun κ => exp (-r * s) * ρ (x * exp (-κ * s)))
        (-(s * exp (-r * s) * qf ρ (x * exp (-κ * s)))) κ := by
    refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
    intro κ hk
    have hm := scaled_mem_Ioo hx hk (show (0:ℝ) < s from hs)
    have hd := (hρd _ ⟨hm.1, hm.2.trans hX⟩).hasDerivAt
    have hin : HasDerivAt (fun κ => x * exp (-κ * s)) (x * (exp (-κ * s) * (-1 * s))) κ := by
      have h1 : HasDerivAt (fun κ : ℝ => -κ * s) (-1 * s) κ := by
        simpa using ((hasDerivAt_id κ).neg.mul_const s)
      exact h1.exp.const_mul x
    have := (hd.comp κ hin).const_mul (exp (-r * s))
    refine this.congr_deriv ?_
    simp only [qf]; ring
  have h := dom_deriv (fun κ s => exp (-r * s) * ρ (x * exp (-κ * s)))
    (fun κ s => -(s * exp (-r * s) * qf ρ (x * exp (-κ * s))))
    (fun s => s * exp (-r * s) * Q) (Ioi 0) κ0 (Ioi_mem_nhds hκ) hmeas (hint κ0 hκ.le) hF'm
    hbound hbint hdiff
  rw [MeasureTheory.integral_neg] at h
  exact h

/-- **`xΠ′(x) = I₀`**: `Π` differentiated in the lead under the integral sign (`κ ≥ 0`). -/
theorem Pi_hasDerivAt_x (ρ : ℝ → ℝ) {r κ x X Q : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ)
    (hx : 0 < x) (hX : x < X) (hρc : ContinuousOn ρ (Icc 0 X))
    (hρd : ∀ y ∈ Ioo 0 X, DifferentiableAt ℝ ρ y) (hQ : ∀ y ∈ Ioo 0 X, |qf ρ y| ≤ Q) :
    HasDerivAt (Pi ρ r κ) (I0 ρ r κ x / x) x := by
  have hU : Ioo (x / 2) ((x + X) / 2) ∈ 𝓝 x := Ioo_mem_nhds (by linarith) (by linarith)
  have hint : ∀ x' ∈ Ioo (x / 2) ((x + X) / 2),
      IntegrableOn (fun s => exp (-r * s) * ρ (x' * exp (-κ * s))) (Ioi 0) := fun x' hx' =>
    f_integrableOn ρ hr hκ (by linarith [hx'.1]) hρc (by simp; linarith [hx'.2])
  have hmeas : ∀ᶠ x' in 𝓝 x, AEStronglyMeasurable
      (fun s => exp (-r * s) * ρ (x' * exp (-κ * s))) (volume.restrict (Ioi (0:ℝ))) := by
    filter_upwards [hU] with x' hx'
    exact (hint x' hx').aestronglyMeasurable
  have hF'm : AEStronglyMeasurable
      (fun s => exp (-r * s) * (deriv ρ (x * exp (-κ * s)) * exp (-κ * s)))
      (volume.restrict (Ioi (0:ℝ))) :=
    ((by fun_prop : Measurable fun s : ℝ => exp (-r * s)).mul
      (((measurable_deriv ρ).comp (by fun_prop)).mul (by fun_prop))).aestronglyMeasurable
  have hmem : ∀ x' ∈ Ioo (x / 2) ((x + X) / 2), ∀ s : ℝ, 0 ≤ s →
      x' * exp (-κ * s) ∈ Ioo 0 X := by
    intro x' hx' s hs
    have h1 : exp (-κ * s) ≤ 1 := exp_le_one_iff.mpr (by nlinarith)
    refine ⟨mul_pos (by linarith [hx'.1]) (exp_pos _), ?_⟩
    nlinarith [hx'.1, hx'.2, exp_pos (-κ * s)]
  have hbound : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ x' ∈ Ioo (x / 2) ((x + X) / 2),
      ‖exp (-r * s) * (deriv ρ (x' * exp (-κ * s)) * exp (-κ * s))‖
        ≤ exp (-r * s) * (2 * Q / x) := by
    refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
    intro x' hx'
    have hm := hmem x' hx' s (le_of_lt (show (0:ℝ) < s from hs))
    have hq := hQ _ hm
    have hx'0 : 0 < x' := by linarith [hx'.1]
    have hy : deriv ρ (x' * exp (-κ * s)) * exp (-κ * s) = qf ρ (x' * exp (-κ * s)) / x' := by
      simp only [qf]; field_simp
    rw [hy, Real.norm_eq_abs, abs_mul, abs_of_pos (exp_pos (-r * s)), abs_div, abs_of_pos hx'0]
    apply mul_le_mul_of_nonneg_left _ (exp_pos _).le
    rw [div_le_div_iff₀ hx'0 hx]
    have hQ0 : 0 ≤ Q := (abs_nonneg _).trans hq
    nlinarith [hx'.1, abs_nonneg (qf ρ (x' * exp (-κ * s)))]
  have hbint : Integrable (fun s => exp (-r * s) * (2 * Q / x)) (volume.restrict (Ioi (0:ℝ))) :=
    (exp_neg_integrableOn_Ioi 0 hr).mul_const _
  have hdiff : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ x' ∈ Ioo (x / 2) ((x + X) / 2),
      HasDerivAt (fun x' => exp (-r * s) * ρ (x' * exp (-κ * s)))
        (exp (-r * s) * (deriv ρ (x' * exp (-κ * s)) * exp (-κ * s))) x' := by
    refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
    intro x' hx'
    have hd := (hρd _ (hmem x' hx' s (le_of_lt (show (0:ℝ) < s from hs)))).hasDerivAt
    have hin : HasDerivAt (fun x' => x' * exp (-κ * s)) (1 * exp (-κ * s)) x' :=
      (hasDerivAt_id x').mul_const _
    have := (hd.comp x' hin).const_mul (exp (-r * s))
    refine this.congr_deriv ?_
    ring
  have h := dom_deriv (fun x' s => exp (-r * s) * ρ (x' * exp (-κ * s)))
    (fun x' s => exp (-r * s) * (deriv ρ (x' * exp (-κ * s)) * exp (-κ * s)))
    (fun s => exp (-r * s) * (2 * Q / x)) _ x hU hmeas (hint x ⟨by linarith, by linarith⟩) hF'm
    hbound hbint hdiff
  have hval : ∫ s in Ioi (0:ℝ), exp (-r * s) * (deriv ρ (x * exp (-κ * s)) * exp (-κ * s))
      = I0 ρ r κ x / x := by
    unfold I0
    rw [← MeasureTheory.integral_div]
    refine setIntegral_congr_fun measurableSet_Ioi (fun s _ => ?_)
    simp only [qf]; field_simp
  rw [hval] at h
  exact h

/-- **The identity `ρ(x) − rΠ(x) = κI₀`** (`κ > 0`), from the two expressions for `Π′`. -/
theorem rho_sub_rPi (ρ : ℝ → ℝ) {r κ x X Q : ℝ} (hr : 0 < r) (hκ : 0 < κ)
    (hx : 0 < x) (hX : x < X) (hρc : ContinuousOn ρ (Icc 0 X))
    (hρd : ∀ y ∈ Ioo 0 X, DifferentiableAt ℝ ρ y) (hQ : ∀ y ∈ Ioo 0 X, |qf ρ y| ≤ Q) :
    ρ x - r * Pi ρ r κ x = κ * I0 ρ r κ x := by
  have h1 := (p11ii_ode_general ρ hr hκ hx hX hρc).1
  have h2 := Pi_hasDerivAt_x ρ hr hκ.le hx hX hρc hρd hQ
  have := h1.unique h2
  field_simp at this
  linarith

theorem integrable_I0 (ρ : ℝ → ℝ) {r κ x X Q : ℝ} (hr : 0 < r) (hκ : 0 < κ) (hx : 0 < x)
    (hX : x < X) (hQ : ∀ y ∈ Ioo 0 X, |qf ρ y| ≤ Q) :
    IntegrableOn (fun s => exp (-r * s) * qf ρ (x * exp (-κ * s))) (Ioi 0) := by
  refine Integrable.mono' ((exp_neg_integrableOn_Ioi 0 hr).mul_const Q)
    (((by fun_prop : Measurable fun s : ℝ => exp (-r * s)).mul
      ((measurable_qf ρ).comp (by fun_prop))).aestronglyMeasurable) ?_
  refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
  have hm := scaled_mem_Ioo hx hκ hs
  have hq := hQ _ ⟨hm.1, hm.2.trans hX⟩
  rw [Real.norm_eq_abs, abs_mul, abs_of_pos (exp_pos _)]
  exact mul_le_mul_of_nonneg_left hq (exp_pos _).le

theorem integrable_I1 (ρ : ℝ → ℝ) {r κ x X Q : ℝ} (hr : 0 < r) (hκ : 0 < κ) (hx : 0 < x)
    (hX : x < X) (hQ : ∀ y ∈ Ioo 0 X, |qf ρ y| ≤ Q) :
    IntegrableOn (fun s => s * exp (-r * s) * qf ρ (x * exp (-κ * s))) (Ioi 0) := by
  refine Integrable.mono' ((integrableOn_id_mul_exp hr).mul_const Q)
    (((by fun_prop : Measurable fun s : ℝ => s * exp (-r * s)).mul
      ((measurable_qf ρ).comp (by fun_prop))).aestronglyMeasurable) ?_
  refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
  have hm := scaled_mem_Ioo hx hκ hs
  have hq := hQ _ ⟨hm.1, hm.2.trans hX⟩
  rw [Real.norm_eq_abs, abs_mul, abs_of_nonneg (mul_nonneg (le_of_lt hs) (exp_pos _).le)]
  exact mul_le_mul_of_nonneg_left hq (mul_nonneg (le_of_lt hs) (exp_pos _).le)

/-- **The sign step: `I₀ − rI₁ ≥ 0` when `q` is non-decreasing.** With `φ(s) = se^{−rs}`,
`I₀ − rI₁ = ∫ φ′(s) q(y(s)) ds`, `∫ φ′ = 0`, `φ′ ≥ 0` exactly on `[0, 1/r]`, and `q(y(s))` is
non-increasing in `s` because `y(s) = xe^{−κs}` falls; so `φ′(s)(q(y(s)) − q(y(1/r))) ≥ 0`. -/
theorem I0_sub_rI1_nonneg (ρ : ℝ → ℝ) {r κ x X Q : ℝ} (hr : 0 < r) (hκ : 0 < κ) (hx : 0 < x)
    (hX : x < X) (hQ : ∀ y ∈ Ioo 0 X, |qf ρ y| ≤ Q) (hmono : MonotoneOn (qf ρ) (Ioo 0 X)) :
    0 ≤ I0 ρ r κ x - r * I1 ρ r κ x := by
  set y := fun s => x * exp (-κ * s) with hy
  set c := qf ρ (y (1 / r)) with hc
  have hA := integrable_I0 ρ hr hκ hx hX hQ
  have hB := integrable_I1 ρ hr hκ hx hX hQ
  have hE : IntegrableOn (fun s : ℝ => exp (-r * s)) (Ioi 0) := exp_neg_integrableOn_Ioi 0 hr
  have hG := integrableOn_id_mul_exp hr
  have hymem : ∀ s, 0 ≤ s → y s ∈ Ioo 0 X := fun s hs => by
    have h1 : exp (-κ * s) ≤ 1 := exp_le_one_iff.mpr (by nlinarith)
    exact ⟨mul_pos hx (exp_pos _), by simp only [hy]; nlinarith [exp_pos (-κ * s)]⟩
  have hyanti : ∀ s t, s ≤ t → y t ≤ y s := fun s t hst => by
    simp only [hy]
    exact mul_le_mul_of_nonneg_left (exp_le_exp.mpr (by nlinarith)) hx.le
  have key : I0 ρ r κ x - r * I1 ρ r κ x =
      ∫ s in Ioi (0:ℝ), (exp (-r * s) - r * (s * exp (-r * s))) * (qf ρ (y s) - c) := by
    have e1 : ∫ s in Ioi (0:ℝ), (exp (-r * s) - r * (s * exp (-r * s))) * (qf ρ (y s) - c) =
        (∫ s in Ioi (0:ℝ), exp (-r * s) * qf ρ (y s)) -
          r * (∫ s in Ioi (0:ℝ), s * exp (-r * s) * qf ρ (y s)) -
          c * ((∫ s in Ioi (0:ℝ), exp (-r * s)) - r * ∫ s in Ioi (0:ℝ), s * exp (-r * s)) := by
      have hfun : (fun s => (exp (-r * s) - r * (s * exp (-r * s))) * (qf ρ (y s) - c)) =
          fun s => (exp (-r * s) * qf ρ (y s) - r * (s * exp (-r * s) * qf ρ (y s))) -
            c * (exp (-r * s) - r * (s * exp (-r * s))) := by
        funext s; ring
      have hA' : IntegrableOn (fun s => exp (-r * s) * qf ρ (y s)) (Ioi 0) := hA
      have hBr : IntegrableOn (fun s => r * (s * exp (-r * s) * qf ρ (y s))) (Ioi 0) :=
        hB.const_mul r
      have hGr : IntegrableOn (fun s => r * (s * exp (-r * s))) (Ioi 0) := hG.const_mul r
      have hAB : IntegrableOn (fun s => exp (-r * s) * qf ρ (y s)
          - r * (s * exp (-r * s) * qf ρ (y s))) (Ioi 0) := hA'.sub hBr
      have hEGc : IntegrableOn (fun s => c * (exp (-r * s) - r * (s * exp (-r * s)))) (Ioi 0) :=
        (hE.sub hGr).const_mul c
      rw [hfun, MeasureTheory.integral_sub hAB hEGc, MeasureTheory.integral_sub hA' hBr,
        MeasureTheory.integral_const_mul, MeasureTheory.integral_const_mul,
        MeasureTheory.integral_sub hE hGr, MeasureTheory.integral_const_mul]
    rw [e1, integral_exp_neg_Ioi_pos hr, integral_id_mul_exp hr]
    unfold I0 I1
    have : (1 / r - r * (1 / r ^ 2)) = 0 := by field_simp; ring
    rw [this, mul_zero, sub_zero]
  rw [key]
  refine setIntegral_nonneg measurableSet_Ioi (fun s hs => ?_)
  have hs0 : 0 ≤ s := le_of_lt hs
  have hfac : exp (-r * s) - r * (s * exp (-r * s)) = (1 - r * s) * exp (-r * s) := by ring
  rw [hfac]
  rcases le_total s (1 / r) with h | h
  · have h1 : 0 ≤ 1 - r * s := by
      have := mul_le_mul_of_nonneg_left h hr.le
      rw [mul_one_div_cancel hr.ne'] at this; linarith
    have h2 : c ≤ qf ρ (y s) :=
      hmono (hymem _ (by positivity)) (hymem s hs0) (hyanti s (1 / r) h)
    exact mul_nonneg (mul_nonneg h1 (exp_pos _).le) (by linarith)
  · have h1 : 1 - r * s ≤ 0 := by
      have := mul_le_mul_of_nonneg_left h hr.le
      rw [mul_one_div_cancel hr.ne'] at this; linarith
    have h2 : qf ρ (y s) ≤ c :=
      hmono (hymem s hs0) (hymem _ (by positivity)) (hyanti (1 / r) s h)
    exact mul_nonneg_of_nonpos_of_nonpos (mul_nonpos_of_nonpos_of_nonneg h1 (exp_pos _).le)
      (by linarith)

/-- `ρ′ ≥ 0` on `(0, X)` for a rent increasing on `[0, X]`, so `q ≥ 0` there. -/
theorem qf_nonneg_of_monotone (ρ : ℝ → ℝ) {X y : ℝ} (hmon : MonotoneOn ρ (Icc 0 X))
    (hy : y ∈ Ioo 0 X) : 0 ≤ qf ρ y := by
  have hn : Icc 0 X ∈ 𝓝 y := Icc_mem_nhds hy.1 hy.2
  have := hmon.derivWithin_nonneg (x := y)
  rw [derivWithin_of_mem_nhds hn] at this
  exact mul_nonneg hy.1.le this

/-- **`I₁ > 0`** for a strictly increasing rent with `q` non-decreasing. -/
theorem I1_pos (ρ : ℝ → ℝ) {r κ x X Q : ℝ} (hr : 0 < r) (hκ : 0 < κ) (hx : 0 < x)
    (hX : x < X) (hρc : ContinuousOn ρ (Icc 0 X)) (hρd : ∀ y ∈ Ioo 0 X, DifferentiableAt ℝ ρ y)
    (hQ : ∀ y ∈ Ioo 0 X, |qf ρ y| ≤ Q) (hmono : MonotoneOn (qf ρ) (Ioo 0 X))
    (hinc : StrictMonoOn ρ (Icc 0 X)) : 0 < I1 ρ r κ x := by
  -- a point `ξ ∈ (x/2, x)` with `ρ′(ξ) > 0`, by the mean value theorem
  obtain ⟨ξ, hξ, hξd⟩ := exists_deriv_eq_slope ρ (by linarith : x / 2 < x)
    (hρc.mono (Icc_subset_Icc (by linarith) hX.le))
    (fun y hy => (hρd y ⟨by linarith [hy.1], by linarith [hy.2]⟩).differentiableWithinAt)
  have hslope : 0 < (ρ x - ρ (x / 2)) / (x - x / 2) := by
    apply div_pos _ (by linarith)
    have := hinc ⟨by linarith, by linarith⟩ ⟨hx.le, hX.le⟩ (by linarith : x / 2 < x)
    linarith
  have hξpos : 0 < qf ρ ξ := by
    unfold qf; rw [hξd]; exact mul_pos (by linarith [hξ.1]) hslope
  have hξmem : ξ ∈ Ioo 0 X := ⟨by linarith [hξ.1], by linarith [hξ.2]⟩
  set s1 := Real.log (x / ξ) / κ with hs1
  have hs1pos : 0 < s1 := div_pos (Real.log_pos (by rw [one_lt_div (by linarith [hξ.1])]; exact hξ.2)) hκ
  have hB := integrable_I1 ρ hr hκ hx hX hQ
  have hnn : ∀ s ∈ Ioi (0:ℝ), 0 ≤ s * exp (-r * s) * qf ρ (x * exp (-κ * s)) := by
    intro s hs
    have hm := scaled_mem_Ioo hx hκ hs
    exact mul_nonneg (mul_nonneg (le_of_lt hs) (exp_pos _).le)
      (qf_nonneg_of_monotone ρ hinc.monotoneOn ⟨hm.1, hm.2.trans hX⟩)
  have hsub : ∫ s in Ioc 0 s1, s * exp (-r * s) * qf ρ ξ ≤
      ∫ s in Ioc 0 s1, s * exp (-r * s) * qf ρ (x * exp (-κ * s)) := by
    refine setIntegral_mono_on ?_ (hB.mono_set Ioc_subset_Ioi_self) measurableSet_Ioc ?_
    · exact (integrableOn_id_mul_exp hr).mono_set Ioc_subset_Ioi_self |>.mul_const _
    · intro s hs
      have hm := scaled_mem_Ioo hx hκ hs.1
      have hge : ξ ≤ x * exp (-κ * s) := by
        have : -κ * s1 ≤ -κ * s := by nlinarith [hs.2]
        have h2 : x * exp (-κ * s1) = ξ := by
          rw [hs1, show -κ * (Real.log (x / ξ) / κ) = -Real.log (x / ξ) by field_simp,
            exp_neg, exp_log (div_pos hx (by linarith [hξ.1]))]
          field_simp
        rw [← h2]; exact mul_le_mul_of_nonneg_left (exp_le_exp.mpr this) hx.le
      exact mul_le_mul_of_nonneg_left (hmono hξmem ⟨hm.1, hm.2.trans hX⟩ hge)
        (mul_nonneg (le_of_lt hs.1) (exp_pos _).le)
  have hmono_set : ∫ s in Ioc 0 s1, s * exp (-r * s) * qf ρ (x * exp (-κ * s)) ≤ I1 ρ r κ x := by
    unfold I1
    refine setIntegral_mono_set hB ?_ (Eventually.of_forall Ioc_subset_Ioi_self)
    exact (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall hnn)
  have hpos : 0 < ∫ s in Ioc 0 s1, s * exp (-r * s) * qf ρ ξ := by
    rw [MeasureTheory.integral_mul_const, ← intervalIntegral.integral_of_le hs1pos.le]
    refine mul_pos ?_ hξpos
    refine intervalIntegral.intervalIntegral_pos_of_pos_on ?_ (fun s hs => ?_) hs1pos
    · exact (by fun_prop : Continuous fun s : ℝ => s * exp (-r * s)).intervalIntegrable _ _
    · exact mul_pos hs.1 (exp_pos _)
  linarith

/-- The parameter record with `κ_post` replaced; the old lead does not depend on it. -/
theorem lead_kpost (p : Prm) (k t : ℝ) : lead { p with kpost := k } t = lead p t := rfl

/-- **P11(v), `∂Φ/∂κ_post` for a general rent** (`λ` fixed), at any date `T > 0`:
`∂Φ/∂κ_post = (r+λ)I₁ + κ_pre g (I₀ − rI₁)/(xκ_post)`, with `g = g(T)`, `x = g + Δ`. This is the
paper's `−(r+λ)∂Π/∂κ_post − κ_pre g ∂Π′/∂κ_post`. Hypotheses: A11 (`ρ` continuous on
`[0, g₀ + Δ]`), `ρ` differentiable on `(0, g₀ + Δ)` with `q = xρ′(x)` bounded there. -/
theorem p11v_kpost_partial_general (ρ : ℝ → ℝ) (p : Prm) {T Q : ℝ} (hr : 0 < p.r)
    (hκ : 0 < p.kpost) (hg : 0 < p.g0) (hk : 0 < p.kpre) (hΔ : 0 ≤ p.Δ) (hT : 0 < T)
    (hρc : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ)))
    (hρd : ∀ y ∈ Ioo 0 (p.g0 + p.Δ), DifferentiableAt ℝ ρ y)
    (hQ : ∀ y ∈ Ioo 0 (p.g0 + p.Δ), |qf ρ y| ≤ Q) :
    HasDerivAt (fun k => Phi ρ { p with kpost := k } T)
      ((p.r + p.lam) * I1 ρ p.r p.kpost (lead p T + p.Δ) +
        p.kpre * lead p T * (I0 ρ p.r p.kpost (lead p T + p.Δ)
          - p.r * I1 ρ p.r p.kpost (lead p T + p.Δ)) / ((lead p T + p.Δ) * p.kpost)) p.kpost := by
  have hlt : lead p T < p.g0 := by have := lead_lt p hg hk hT; simpa [lead] using this
  have hg0 : 0 < lead p T := mul_pos hg (exp_pos _)
  set g := lead p T with hgdef
  set x := lead p T + p.Δ with hxdef
  have hx : 0 < x := by linarith
  have hX : x < p.g0 + p.Δ := by linarith
  have hev : (fun k => Phi ρ { p with kpost := k } T) =ᶠ[𝓝 p.kpost] fun k =>
      p.F + p.lam * p.Z + ρ g - (p.r + p.lam) * Pi ρ p.r k x
        + (ρ x - p.r * Pi ρ p.r k x) / (k * x) * (-p.kpre * g) := by
    filter_upwards [Ioi_mem_nhds hκ] with k hk'
    have hPi := (p11ii_ode_general ρ hr hk' hx hX hρc).1
    have hJ : HasDerivAt (J ρ { p with kpost := k })
        ((ρ x - p.r * Pi ρ p.r k x) / (k * x) * (-p.kpre * g)) T :=
      hPi.comp T ((lead_hasDerivAt p T).add_const p.Δ)
    unfold Phi
    rw [hJ.deriv]
    rfl
  have hP := Pi_hasDerivAt_kappa ρ hr hκ hx hX hρc hρd hQ
  have hnum : HasDerivAt (fun k => ρ x - p.r * Pi ρ p.r k x) (-(p.r * -I1 ρ p.r p.kpost x))
      p.kpost := (hP.const_mul p.r).const_sub (ρ x)
  have hden : HasDerivAt (fun k : ℝ => k * x) (1 * x) p.kpost := (hasDerivAt_id _).mul_const x
  have hq := (hnum.div hden (mul_pos hκ hx).ne').mul_const (-p.kpre * g)
  have hall := ((hP.const_mul (p.r + p.lam)).const_sub (p.F + p.lam * p.Z + ρ g)).add hq
  have hid := rho_sub_rPi ρ hr hκ hx hX hρc hρd hQ
  refine (hall.congr_of_eventuallyEq hev).congr_deriv ?_
  rw [hid]
  field_simp
  ring

/-- **The sign.** If the rent is strictly increasing and `xρ′(x)` is non-decreasing on
`(0, g₀ + Δ)`, then `∂Φ/∂κ_post > 0` at every date `T > 0` (`r > 0`, `λ ≥ 0`). The bound on `q`
is derived, not assumed: `0 ≤ q ≤ q(X')` on `(0, X')` for any `X' < g₀ + Δ`. -/
theorem p11v_kpost_partial_general_pos (ρ : ℝ → ℝ) (p : Prm) {T : ℝ} (hr : 0 < p.r)
    (hl : 0 ≤ p.lam) (hκ : 0 < p.kpost) (hg : 0 < p.g0) (hk : 0 < p.kpre) (hΔ : 0 ≤ p.Δ)
    (hT : 0 < T) (hρc : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ)))
    (hρd : ∀ y ∈ Ioo 0 (p.g0 + p.Δ), DifferentiableAt ℝ ρ y)
    (hinc : StrictMonoOn ρ (Icc 0 (p.g0 + p.Δ)))
    (hmono : MonotoneOn (qf ρ) (Ioo 0 (p.g0 + p.Δ))) :
    ∃ A, 0 < A ∧ HasDerivAt (fun k => Phi ρ { p with kpost := k } T) A p.kpost := by
  have hlt : lead p T < p.g0 := by have := lead_lt p hg hk hT; simpa [lead] using this
  have hg0 : 0 < lead p T := mul_pos hg (exp_pos _)
  set g := lead p T with hgdef
  set x := lead p T + p.Δ with hxdef
  have hx : 0 < x := by linarith
  have hX : x < p.g0 + p.Δ := by linarith
  set X' := (x + (p.g0 + p.Δ)) / 2 with hX'
  have hxX' : x < X' := by linarith
  have hX'X : X' < p.g0 + p.Δ := by linarith
  have hX'mem : X' ∈ Ioo 0 (p.g0 + p.Δ) := ⟨by linarith, hX'X⟩
  -- the bound on `q`, derived from monotonicity
  have hQ' : ∀ y ∈ Ioo 0 X', |qf ρ y| ≤ qf ρ X' := by
    intro y hy
    have hy' : y ∈ Ioo 0 (p.g0 + p.Δ) := ⟨hy.1, hy.2.trans hX'X⟩
    rw [abs_of_nonneg (qf_nonneg_of_monotone ρ hinc.monotoneOn hy')]
    exact hmono hy' hX'mem hy.2.le
  -- work on `[0, X']`, inside the domain
  have hρc' : ContinuousOn ρ (Icc 0 X') := hρc.mono (Icc_subset_Icc le_rfl hX'X.le)
  have hρd' : ∀ y ∈ Ioo 0 X', DifferentiableAt ℝ ρ y :=
    fun y hy => hρd y ⟨hy.1, hy.2.trans hX'X⟩
  have hmono' : MonotoneOn (qf ρ) (Ioo 0 X') :=
    hmono.mono (Ioo_subset_Ioo le_rfl hX'X.le)
  have hinc' : StrictMonoOn ρ (Icc 0 X') := hinc.mono (Icc_subset_Icc le_rfl hX'X.le)
  -- apply the lemmas on `[0, X']`
  have hP := Pi_hasDerivAt_kappa ρ hr hκ hx hxX' hρc' hρd' hQ'
  have hid := rho_sub_rPi ρ hr hκ hx hxX' hρc' hρd' hQ'
  have hI1 := I1_pos ρ hr hκ hx hxX' hρc' hρd' hQ' hmono' hinc'
  have hI01 := I0_sub_rI1_nonneg ρ hr hκ hx hxX' hQ' hmono'
  refine ⟨(p.r + p.lam) * I1 ρ p.r p.kpost x +
      p.kpre * g * (I0 ρ p.r p.kpost x - p.r * I1 ρ p.r p.kpost x) / (x * p.kpost), ?_, ?_⟩
  · have h1 : 0 < (p.r + p.lam) * I1 ρ p.r p.kpost x := mul_pos (by linarith) hI1
    have h2 : 0 ≤ p.kpre * g * (I0 ρ p.r p.kpost x - p.r * I1 ρ p.r p.kpost x) / (x * p.kpost) :=
      div_nonneg (mul_nonneg (mul_nonneg hk.le hg0.le) hI01) (mul_pos hx hκ).le
    linarith
  · have hev : (fun k => Phi ρ { p with kpost := k } T) =ᶠ[𝓝 p.kpost] fun k =>
        p.F + p.lam * p.Z + ρ g - (p.r + p.lam) * Pi ρ p.r k x
          + (ρ x - p.r * Pi ρ p.r k x) / (k * x) * (-p.kpre * g) := by
      filter_upwards [Ioi_mem_nhds hκ] with k hk'
      have hPi := (p11ii_ode_general ρ hr hk' hx hxX' hρc').1
      have hJ : HasDerivAt (J ρ { p with kpost := k })
          ((ρ x - p.r * Pi ρ p.r k x) / (k * x) * (-p.kpre * g)) T :=
        hPi.comp T ((lead_hasDerivAt p T).add_const p.Δ)
      unfold Phi
      rw [hJ.deriv]
      rfl
    have hnum : HasDerivAt (fun k => ρ x - p.r * Pi ρ p.r k x) (-(p.r * -I1 ρ p.r p.kpost x))
        p.kpost := (hP.const_mul p.r).const_sub (ρ x)
    have hden : HasDerivAt (fun k : ℝ => k * x) (1 * x) p.kpost := (hasDerivAt_id _).mul_const x
    have hq := (hnum.div hden (mul_pos hκ hx).ne').mul_const (-p.kpre * g)
    have hall := ((hP.const_mul (p.r + p.lam)).const_sub (p.F + p.lam * p.Z + ρ g)).add hq
    refine (hall.congr_of_eventuallyEq hev).congr_deriv ?_
    rw [hid]
    field_simp
    ring

/-- **P11(v), general rents: release comes later with faster post-release copying** (`λ`
fixed), at a simple downward interior crossing, whenever the rent is strictly increasing and
`xρ′(x)` is non-decreasing. The differentiable selection `T*(κ_post)` and the joint
differentiability of `Φ` are the implicit-function hypotheses, as in Release's (v) theorems. -/
theorem p11v_kpost_later_general (ρ : ℝ → ℝ) (p : Prm) {Ts : ℝ → ℝ} {a d : ℝ}
    (hr : 0 < p.r) (hl : 0 ≤ p.lam) (hκ : 0 < p.kpost) (hg : 0 < p.g0) (hk : 0 < p.kpre)
    (hΔ : 0 ≤ p.Δ) (hTs : 0 < Ts p.kpost) (hρc : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ)))
    (hρd : ∀ y ∈ Ioo 0 (p.g0 + p.Δ), DifferentiableAt ℝ ρ y)
    (hinc : StrictMonoOn ρ (Icc 0 (p.g0 + p.Δ)))
    (hmono : MonotoneOn (qf ρ) (Ioo 0 (p.g0 + p.Δ)))
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ => Phi ρ { p with kpost := q.2 } q.1)
      (Ts p.kpost, p.kpost))
    (ha : HasDerivAt (fun T => Phi ρ { p with kpost := p.kpost } T) a (Ts p.kpost))
    (hd : HasDerivAt Ts d p.kpost)
    (hzero : ∀ᶠ k in 𝓝 p.kpost, Phi ρ { p with kpost := k } (Ts k) = 0)
    (hneg : a < 0) : 0 < d := by
  obtain ⟨A, hA, hb⟩ := p11v_kpost_partial_general_pos ρ p hr hl hκ hg hk hΔ hTs hρc hρd hinc
    hmono
  exact ((comp_statics (Φ := fun T k => Phi ρ { p with kpost := k } T)
    hΦ ha hb hd hzero hneg).2.1).mpr hA


/-- The general theorem's hypotheses are met by linear rents `ρ = My`, `M > 0`: they are not
vacuous. -/
theorem p11v_general_covers_linear {M X : ℝ} (hM : 0 < M) :
    ContinuousOn (fun y : ℝ => M * y) (Icc 0 X) ∧
    (∀ y ∈ Ioo 0 X, DifferentiableAt ℝ (fun y : ℝ => M * y) y) ∧
    StrictMonoOn (fun y : ℝ => M * y) (Icc 0 X) ∧ MonotoneOn (qf fun y : ℝ => M * y) (Ioo 0 X) := by
  have hd : ∀ y, deriv (fun y : ℝ => M * y) y = M := fun y => by
    simp
  refine ⟨(continuous_const.mul continuous_id).continuousOn, fun y _ => by fun_prop,
    fun a _ b _ hab => by nlinarith, fun a _ b _ hab => ?_⟩
  simp only [qf, hd]; nlinarith


end P11kpost

section P11sat
open Real MeasureTheory Set Filter Topology RTTR.Release

theorem integral_id_mul_exp_one : ∫ s in Ioi (0:ℝ), s * exp (-1 * s) = 1 := by
  have h := integral_rpow_mul_exp_neg_mul_Ioi (a := 2) (r := 1) two_pos one_pos
  rw [show (2:ℝ) - 1 = 1 by norm_num, Real.Gamma_two, mul_one] at h
  have e : ∫ s in Ioi (0:ℝ), s * exp (-1 * s) = ∫ t in Ioi (0:ℝ), t ^ (1:ℝ) * exp (-(1 * t)) :=
    setIntegral_congr_fun measurableSet_Ioi (fun s _ => by simp only [rpow_one, neg_mul])
  rw [e, h]; norm_num

/-! ### Elementary bounds -/

theorem u_exp_bound {c u : ℝ} (hc : 0 < c) (_hu : 0 ≤ u) : u * exp (-c * u) ≤ 1 / c := by
  have h := add_one_le_exp (c * u)
  have hp := exp_pos (c * u)
  have : u * exp (-c * u) = u / exp (c * u) := by
    rw [show -c * u = -(c * u) by ring, exp_neg]; field_simp
  rw [this, div_le_div_iff₀ hp hc]
  nlinarith

theorem u2_exp_bound {u : ℝ} (hu : 0 ≤ u) : u ^ 2 * exp (-8 * u) ≤ 1 / 16 := by
  have h := add_one_le_exp (4 * u)
  have hp := exp_pos (4 * u)
  have e8 : exp (8 * u) = exp (4 * u) ^ 2 := by rw [← exp_nat_mul]; ring_nf
  have : u ^ 2 * exp (-8 * u) = u ^ 2 / exp (8 * u) := by
    rw [show -8 * u = -(8 * u) by ring, exp_neg]; field_simp
  rw [this, div_le_div_iff₀ (exp_pos _) (by norm_num), e8]
  nlinarith

theorem rhoSat_bounds {y : ℝ} (hy : 0 ≤ y) : 0 ≤ ρSat y ∧ ρSat y ≤ 1 := by
  unfold ρSat
  have h1 : exp (-4 * y) ≤ 1 := exp_le_one_iff.mpr (by linarith)
  exact ⟨by linarith, by linarith [exp_pos (-4 * y)]⟩

theorem hasDerivAt_u (s k : ℝ) :
    HasDerivAt (fun k => exp (-k * s)) (exp (-k * s) * (-s)) k := by
  have h : HasDerivAt (fun k : ℝ => -k * s) (-s) k := by
    simpa using ((hasDerivAt_id k).neg.mul_const s)
  exact h.exp

/-! ### `Π` of the saturating rent, as a function of the lead and of `κ_post` near `0` -/

/-- The lead-derivative of `Π(·; k)` for the saturating rent, for `|k| < 1/2`, at `x ∈ (1, 3)`. -/
noncomputable def P1 (k x : ℝ) : ℝ :=
  ∫ s in Ioi (0:ℝ), exp (-1 * s) * (exp (-4 * (x * exp (-k * s))) * (4 * exp (-k * s)))

theorem sat_Pi_hasDerivAt_x {k x : ℝ} (hk : |k| < 1 / 2) (hx1 : 1 < x) (hx3 : x < 3) :
    HasDerivAt (Pi ρSat 1 k) (P1 k x) x := by
  have hU : Ioo (1:ℝ) 3 ∈ 𝓝 x := Ioo_mem_nhds hx1 hx3
  have hrk : 0 < 1 + k := by have := neg_abs_le k; linarith
  have hmeasF : ∀ x', Measurable (fun s => exp (-1 * s) * ρSat (x' * exp (-k * s))) := by
    intro x'; unfold ρSat; fun_prop
  have hint : ∀ x', 0 ≤ x' → Integrable (fun s => exp (-1 * s) * ρSat (x' * exp (-k * s)))
      (volume.restrict (Ioi (0:ℝ))) := by
    intro x' hx'
    refine Integrable.mono' (exp_neg_integrableOn_Ioi 0 one_pos) (hmeasF x').aestronglyMeasurable
      (Eventually.of_forall fun s => ?_)
    have hb := rhoSat_bounds (mul_nonneg hx' (exp_pos (-k * s)).le)
    rw [Real.norm_eq_abs, abs_mul, abs_of_pos (exp_pos _), abs_of_nonneg hb.1]
    have := mul_le_mul_of_nonneg_left hb.2 (exp_pos (-1 * s)).le
    simpa [neg_mul] using this
  have hmeas : ∀ᶠ x' in 𝓝 x, AEStronglyMeasurable
      (fun s => exp (-1 * s) * ρSat (x' * exp (-k * s))) (volume.restrict (Ioi (0:ℝ))) :=
    Eventually.of_forall fun x' => (hmeasF x').aestronglyMeasurable
  have hF'm : AEStronglyMeasurable
      (fun s => exp (-1 * s) * (exp (-4 * (x * exp (-k * s))) * (4 * exp (-k * s))))
      (volume.restrict (Ioi (0:ℝ))) := by
    apply Measurable.aestronglyMeasurable; fun_prop
  have hbound : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ x' ∈ Ioo (1:ℝ) 3,
      ‖exp (-1 * s) * (exp (-4 * (x' * exp (-k * s))) * (4 * exp (-k * s)))‖ ≤ exp (-1 * s) := by
    refine Eventually.of_forall fun s x' hx' => ?_
    have hu := exp_pos (-k * s)
    have h1 : exp (-4 * (x' * exp (-k * s))) ≤ exp (-4 * exp (-k * s)) :=
      exp_le_exp.mpr (by nlinarith [hx'.1])
    have h2 := u_exp_bound (c := 4) (by norm_num) hu.le
    rw [Real.norm_eq_abs, abs_of_pos (by positivity)]
    have : exp (-4 * (x' * exp (-k * s))) * (4 * exp (-k * s)) ≤ 1 := by
      have := mul_le_mul_of_nonneg_right h1 (by positivity : (0:ℝ) ≤ 4 * exp (-k * s))
      nlinarith
    have := mul_le_mul_of_nonneg_left this (exp_pos (-1 * s)).le
    linarith
  have hbint : Integrable (fun s => exp (-1 * s)) (volume.restrict (Ioi (0:ℝ))) :=
    exp_neg_integrableOn_Ioi 0 (one_pos : (0:ℝ) < 1)
  have hdiff : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ x' ∈ Ioo (1:ℝ) 3,
      HasDerivAt (fun x' => exp (-1 * s) * ρSat (x' * exp (-k * s)))
        (exp (-1 * s) * (exp (-4 * (x' * exp (-k * s))) * (4 * exp (-k * s)))) x' := by
    refine Eventually.of_forall fun s x' _ => ?_
    have hin : HasDerivAt (fun x' => -4 * (x' * exp (-k * s))) (-4 * (1 * exp (-k * s))) x' :=
      ((hasDerivAt_id x').mul_const _).const_mul (-4)
    have := ((hin.exp).const_sub 1).const_mul (exp (-1 * s))
    unfold ρSat
    refine this.congr_deriv ?_
    ring
  have h := dom_deriv (fun x' s => exp (-1 * s) * ρSat (x' * exp (-k * s)))
    (fun x' s => exp (-1 * s) * (exp (-4 * (x' * exp (-k * s))) * (4 * exp (-k * s))))
    (fun s => exp (-1 * s)) _ x hU hmeas (hint x (by linarith)) hF'm hbound hbint hdiff
  exact h

/-- `∂Π/∂κ_post` at `κ_post = 0`, lead `2`: `−8e^{−8}` (`= −q(2)/r²`). -/
theorem sat_Pi_hasDerivAt_k :
    HasDerivAt (fun k => Pi ρSat 1 k 2) (-(8 * exp (-8))) 0 := by
  have hU : Ioo (-1/2 : ℝ) (1/2) ∈ 𝓝 0 := Ioo_mem_nhds (by norm_num) (by norm_num)
  have hmeasF : ∀ k, Measurable (fun s => exp (-1 * s) * ρSat (2 * exp (-k * s))) := by
    intro k; unfold ρSat; fun_prop
  have hint : Integrable (fun s => exp (-1 * s) * ρSat (2 * exp (-0 * s)))
      (volume.restrict (Ioi (0:ℝ))) := by
    refine Integrable.mono' (exp_neg_integrableOn_Ioi 0 one_pos) (hmeasF 0).aestronglyMeasurable
      (Eventually.of_forall fun s => ?_)
    have hb := rhoSat_bounds (mul_nonneg (by norm_num : (0:ℝ) ≤ 2) (exp_pos (-0 * s)).le)
    rw [Real.norm_eq_abs, abs_mul, abs_of_pos (exp_pos _), abs_of_nonneg hb.1]
    have := mul_le_mul_of_nonneg_left hb.2 (exp_pos (-1 * s)).le
    simpa [neg_mul] using this
  have hF'm : AEStronglyMeasurable
      (fun s => exp (-1 * s) * -(exp (-4 * (2 * exp (-0 * s))) * (-4 * (2 * (exp (-0 * s) * -s)))))
      (volume.restrict (Ioi (0:ℝ))) := by
    apply Measurable.aestronglyMeasurable; fun_prop
  have hbound : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ k ∈ Ioo (-1/2 : ℝ) (1/2),
      ‖exp (-1 * s) * -(exp (-4 * (2 * exp (-k * s))) * (-4 * (2 * (exp (-k * s) * -s))))‖
        ≤ s * exp (-1 * s) := by
    refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs k _ => ?_)
    have hs' : 0 < s := hs
    have hu := exp_pos (-k * s)
    have hb := u_exp_bound (c := 8) (by norm_num) hu.le
    have e : exp (-1 * s) * -(exp (-4 * (2 * exp (-k * s))) * (-4 * (2 * (exp (-k * s) * -s))))
        = -(8 * s * exp (-1 * s) * (exp (-k * s) * exp (-8 * exp (-k * s)))) := by
      rw [show -4 * (2 * exp (-k * s)) = -8 * exp (-k * s) by ring]; ring
    rw [e, norm_neg, Real.norm_eq_abs, abs_of_pos (by positivity)]
    have := mul_le_mul_of_nonneg_left hb (by positivity : (0:ℝ) ≤ 8 * s * exp (-1 * s))
    nlinarith
  have hbint : Integrable (fun s => s * exp (-1 * s)) (volume.restrict (Ioi (0:ℝ))) :=
    integrableOn_id_mul_exp one_pos
  have hdiff : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ k ∈ Ioo (-1/2 : ℝ) (1/2),
      HasDerivAt (fun k => exp (-1 * s) * ρSat (2 * exp (-k * s)))
        (exp (-1 * s) * -(exp (-4 * (2 * exp (-k * s))) * (-4 * (2 * (exp (-k * s) * -s))))) k := by
    refine Eventually.of_forall fun s k _ => ?_
    have hin := (((hasDerivAt_u s k).const_mul 2).const_mul (-4))
    have := ((hin.exp).const_sub 1).const_mul (exp (-1 * s))
    unfold ρSat
    exact this
  have h := dom_deriv (fun k s => exp (-1 * s) * ρSat (2 * exp (-k * s)))
    (fun k s => exp (-1 * s) * -(exp (-4 * (2 * exp (-k * s))) * (-4 * (2 * (exp (-k * s) * -s)))))
    (fun s => s * exp (-1 * s)) _ 0 hU (Eventually.of_forall fun k =>
      (hmeasF k).aestronglyMeasurable) hint hF'm hbound hbint hdiff
  have hval : ∫ s in Ioi (0:ℝ),
      exp (-1 * s) * -(exp (-4 * (2 * exp (-0 * s))) * (-4 * (2 * (exp (-0 * s) * -s))))
      = -(8 * exp (-8)) := by
    have : (fun s : ℝ => exp (-1 * s) * -(exp (-4 * (2 * exp (-0 * s))) *
        (-4 * (2 * (exp (-0 * s) * -s))))) = fun s => (-(8 * exp (-8))) * (s * exp (-1 * s)) := by
      funext s; simp only [neg_zero, zero_mul, exp_zero, mul_one]; norm_num; ring
    rw [this, MeasureTheory.integral_const_mul, integral_id_mul_exp_one, mul_one]
  rw [hval] at h
  exact h

/-- `∂P₁/∂κ_post` at `κ_post = 0`, lead `2`: `28e^{−8}` (`= −q′(2)·(−1)`, `q′(2) = −28e^{−8}`). -/
theorem sat_P1_hasDerivAt_k : HasDerivAt (fun k => P1 k 2) (28 * exp (-8)) 0 := by
  have hU : Ioo (-1/2 : ℝ) (1/2) ∈ 𝓝 0 := Ioo_mem_nhds (by norm_num) (by norm_num)
  set G : ℝ → ℝ → ℝ := fun k s =>
    exp (-1 * s) * (exp (-4 * (2 * exp (-k * s))) * (4 * exp (-k * s))) with hG
  set G' : ℝ → ℝ → ℝ := fun k s =>
    exp (-1 * s) * ((exp (-4 * (2 * exp (-k * s))) * (-4 * (2 * (exp (-k * s) * -s)))) *
      (4 * exp (-k * s)) + exp (-4 * (2 * exp (-k * s))) * (4 * (exp (-k * s) * -s))) with hG'
  have hGm : ∀ k, Measurable (G k) := by intro k; simp only [hG]; fun_prop
  have hint : Integrable (G 0) (volume.restrict (Ioi (0:ℝ))) := by
    refine Integrable.mono' ((exp_neg_integrableOn_Ioi 0 one_pos).const_mul 4)
      (hGm 0).aestronglyMeasurable (Eventually.of_forall fun s => ?_)
    simp only [hG, neg_zero, zero_mul, exp_zero, mul_one]
    rw [Real.norm_eq_abs, abs_of_pos (by positivity)]
    have : exp (-4 * 2) ≤ 1 := exp_le_one_iff.mpr (by norm_num)
    have := mul_le_mul_of_nonneg_left this (exp_pos (-1 * s)).le
    nlinarith [exp_pos (-1 * s), exp_pos (-s)]
  have hG'm : AEStronglyMeasurable (G' 0) (volume.restrict (Ioi (0:ℝ))) := by
    apply Measurable.aestronglyMeasurable; simp only [hG']; fun_prop
  have hbound : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ k ∈ Ioo (-1/2 : ℝ) (1/2),
      ‖G' k s‖ ≤ 4 * (s * exp (-1 * s)) := by
    refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs k _ => ?_)
    have hs' : 0 < s := hs
    set u := exp (-k * s) with hu_def
    have hu := exp_pos (-k * s)
    have h1 := u_exp_bound (c := 8) (by norm_num) hu.le
    have h2 := u2_exp_bound hu.le
    have e : G' k s = 4 * s * exp (-1 * s) * (8 * (u ^ 2 * exp (-8 * u)) - u * exp (-8 * u)) := by
      simp only [hG', ← hu_def]
      rw [show -4 * (2 * u) = -8 * u by ring]; ring
    rw [e, Real.norm_eq_abs, abs_mul, abs_of_pos (by positivity)]
    have hpos1 : 0 ≤ u ^ 2 * exp (-8 * u) := by positivity
    have hpos2 : 0 ≤ u * exp (-8 * u) := by positivity
    have : |8 * (u ^ 2 * exp (-8 * u)) - u * exp (-8 * u)| ≤ 1 := by
      rw [abs_le]; constructor <;> nlinarith
    have hsp : 0 < 4 * s * exp (-1 * s) := by positivity
    nlinarith
  have hbint : Integrable (fun s => 4 * (s * exp (-1 * s))) (volume.restrict (Ioi (0:ℝ))) :=
    (integrableOn_id_mul_exp one_pos).const_mul 4
  have hdiff : ∀ᵐ s ∂(volume.restrict (Ioi (0:ℝ))), ∀ k ∈ Ioo (-1/2 : ℝ) (1/2),
      HasDerivAt (fun k => G k s) (G' k s) k := by
    refine Eventually.of_forall fun s k _ => ?_
    have hu := hasDerivAt_u s k
    have hin := ((hu.const_mul 2).const_mul (-4)).exp
    have := ((hin.mul (hu.const_mul 4))).const_mul (exp (-1 * s))
    exact this
  have h := dom_deriv G G' (fun s => 4 * (s * exp (-1 * s))) _ 0 hU
    (Eventually.of_forall fun k => (hGm k).aestronglyMeasurable) hint hG'm hbound hbint hdiff
  have hval : ∫ s in Ioi (0:ℝ), G' 0 s = 28 * exp (-8) := by
    have : G' 0 = fun s => (28 * exp (-8)) * (s * exp (-1 * s)) := by
      funext s; simp only [hG', neg_zero, zero_mul, exp_zero, mul_one]; norm_num; ring
    rw [this, MeasureTheory.integral_const_mul, integral_id_mul_exp_one, mul_one]
  rw [hval] at h
  exact h

/-- **`Φ` of the saturating example near `κ_post = 0`, at `T = 1`.** For `|k| < 1/2`,
`Φ(1; k) = F + ρ(1) − 2Π(2; k) − P₁(k, 2)`, with `Φ` the defined stopping function (its `J′`
the derivative of the defined `J`). -/
theorem sat_Phi_near {k : ℝ} (hk : |k| < 1 / 2) :
    Phi ρSat { pSat with kpost := k } 1 = pSat.F + ρSat 1 - 2 * Pi ρSat 1 k 2 - P1 k 2 := by
  have hl1 : lead pSat 1 = 1 := by simp only [lead, pSat]; rw [← exp_add]; norm_num
  have hl : lead { pSat with kpost := k } 1 = 1 := hl1
  have hPi := sat_Pi_hasDerivAt_x hk (by norm_num : (1:ℝ) < 1 + 1) (by norm_num : (1:ℝ) + 1 < 3)
  have hJ : HasDerivAt (J ρSat { pSat with kpost := k })
      (P1 k (1 + 1) * (-{ pSat with kpost := k }.kpre * lead { pSat with kpost := k } 1)) 1 := by
    have hlead := (lead_hasDerivAt { pSat with kpost := k } 1).add_const ({ pSat with kpost := k }.Δ)
    have hx : lead { pSat with kpost := k } 1 + { pSat with kpost := k }.Δ = 1 + 1 := by
      rw [hl]; rfl
    have hPi' : HasDerivAt (Pi ρSat { pSat with kpost := k }.r { pSat with kpost := k }.kpost)
        (P1 k (1 + 1)) (lead { pSat with kpost := k } 1 + { pSat with kpost := k }.Δ) := by
      rw [hx]; exact hPi
    exact HasDerivAt.comp (h := fun x => lead { pSat with kpost := k } x
      + { pSat with kpost := k }.Δ) 1 hPi' hlead
  unfold Phi
  rw [hJ.deriv]
  unfold J
  rw [hl]
  simp only [pSat]
  norm_num
  ring

/-- **`∂Φ/∂κ_post = −12e^{−8}` at `κ_post = 0`, `T = 1`**, from the defined `Φ`:
`−(r+λ)∂Π/∂κ − κ_pre g ∂Π′/∂κ = 2·8e^{−8} − 28e^{−8}`. -/
theorem sat_Phi_kpost_partial :
    HasDerivAt (fun k => Phi ρSat { pSat with kpost := k } 1) (-(12 * exp (-8))) 0 := by
  have hev : (fun k => Phi ρSat { pSat with kpost := k } 1) =ᶠ[𝓝 0]
      fun k => pSat.F + ρSat 1 - 2 * Pi ρSat 1 k 2 - P1 k 2 := by
    have : {k : ℝ | |k| < 1 / 2} ∈ 𝓝 (0:ℝ) :=
      (isOpen_lt continuous_abs continuous_const).mem_nhds
        (show (0:ℝ) ∈ {k : ℝ | |k| < 1 / 2} by norm_num)
    filter_upwards [this] with k hk
    exact sat_Phi_near hk
  have h := ((sat_Pi_hasDerivAt_k.const_mul 2).const_sub (pSat.F + ρSat 1)).sub sat_P1_hasDerivAt_k
  refine (h.congr_of_eventuallyEq hev).congr_deriv ?_
  ring

/-- **`∂Φ/∂T = −4e^{−4}(1 + e^{−4}) < 0` at `T* = 1`, `κ_post = 0`**: the crossing is simple and
from above. -/
theorem sat_Phi_T_partial :
    HasDerivAt (fun T => Phi ρSat pSat T) (-(4 * exp (-4) * (1 + exp (-4)))) 1 := by
  have hl1 : lead pSat 1 = 1 := by simp only [lead, pSat]; rw [← exp_add]; norm_num
  have hd : ∀ g, HasDerivAt hSat (exp (-4 * g) * (-4 + 12 * exp (-4) - 16 * exp (-4) * g)) g := by
    intro g
    have h1 : HasDerivAt (fun g => exp (-4 * g)) (exp (-4 * g) * (-4 * 1)) g :=
      ((hasDerivAt_id g).const_mul (-4)).exp
    have h2 : HasDerivAt (fun g => 1 - 2 * exp (-4) + 4 * exp (-4) * g) (4 * exp (-4) * 1) g :=
      ((hasDerivAt_id g).const_mul (4 * exp (-4))).const_add _
    exact (h1.mul h2).congr_deriv (by ring)
  have hcomp := ((hd (lead pSat 1)).comp 1 (lead_hasDerivAt pSat 1)).const_sub (hSat 1)
  have hfun : (fun T => Phi ρSat pSat T) = fun T => hSat 1 - hSat (lead pSat T) :=
    funext pSat_Phi
  rw [hfun]
  refine hcomp.congr_deriv ?_
  rw [hl1]
  simp only [pSat]
  norm_num
  ring

/-- **One-sided comparative statics.** As Release's `comp_statics`, for a selection `T*(θ)` of
zeros defined for `θ ≥ θ₀` only, with a right derivative at `θ₀`. -/
theorem comp_statics_right {Φ : ℝ → ℝ → ℝ} {Ts : ℝ → ℝ} {θ0 a b d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ => Φ q.1 q.2) (Ts θ0, θ0))
    (ha : HasDerivAt (fun T => Φ T θ0) a (Ts θ0))
    (hb : HasDerivAt (fun θ => Φ (Ts θ0) θ) b θ0)
    (hd : HasDerivWithinAt Ts d (Ici θ0) θ0)
    (hzero : ∀ᶠ θ in 𝓝[≥] θ0, Φ (Ts θ) θ = 0) (hne : a ≠ 0) : d = -b / a := by
  have hL := hΦ.hasFDerivAt
  set L := fderiv ℝ (fun q : ℝ × ℝ => Φ q.1 q.2) (Ts θ0, θ0)
  have h1 : HasDerivAt (fun T => Φ T θ0) (L ((1:ℝ), (0:ℝ))) (Ts θ0) :=
    hL.comp_hasDerivAt (Ts θ0) (f := fun T : ℝ => (T, θ0))
      ((hasDerivAt_id _).prodMk (hasDerivAt_const _ _))
  have h2 : HasDerivAt (fun θ => Φ (Ts θ0) θ) (L ((0:ℝ), (1:ℝ))) θ0 :=
    hL.comp_hasDerivAt θ0 (f := fun θ : ℝ => (Ts θ0, θ))
      ((hasDerivAt_const _ _).prodMk (hasDerivAt_id _))
  have h3 : HasDerivWithinAt (fun θ => Φ (Ts θ) θ) (L (d, (1:ℝ))) (Ici θ0) θ0 :=
    hL.comp_hasDerivWithinAt θ0 (f := fun θ : ℝ => (Ts θ, θ))
      (hd.prodMk (hasDerivAt_id _).hasDerivWithinAt)
  have ea : L ((1:ℝ), (0:ℝ)) = a := h1.unique ha
  have eb : L ((0:ℝ), (1:ℝ)) = b := h2.unique hb
  have hz0 : Φ (Ts θ0) θ0 = 0 := hzero.self_of_nhdsWithin self_mem_Ici
  have h0 : HasDerivWithinAt (fun θ => Φ (Ts θ) θ) 0 (Ici θ0) θ0 :=
    (hasDerivWithinAt_const θ0 (Ici θ0) (0:ℝ)).congr_of_eventuallyEq hzero hz0
  have e0 : L (d, (1:ℝ)) = 0 := (uniqueDiffWithinAt_Ici θ0).eq_deriv _ h3 h0
  have hlin : L (d, (1:ℝ)) = d * L ((1:ℝ), (0:ℝ)) + L ((0:ℝ), (1:ℝ)) := by
    have : ((d, (1:ℝ)) : ℝ × ℝ) = d • ((1:ℝ), (0:ℝ)) + ((0:ℝ), (1:ℝ)) := by simp
    rw [this, map_add, map_smul, smul_eq_mul]
  rw [ea, eb, e0] at hlin
  rw [eq_div_iff hne]; linarith

/-- **P11(v), the saturating reversal, machine-checked.** For `ρ = 1 − e^{−4x}`, `r = λ = κ_pre =
Δ = 1`, `g₀ = e`, `Z = 0`, `F = 1 + e^{−4} + 2e^{−8}`: at `κ_post = 0` the optimum is `T* = 1`
(Release, `p11v_saturating_optimum`), and for any selection `T*(κ_post)` of zeros of `Φ` on
`κ_post ≥ 0` through `T*(0) = 1` with a right derivative, that derivative is
`−3/(e⁴ + 1) < 0`: faster copying of the released model brings release sooner. The selection and
the joint differentiability of `Φ` are the implicit-function hypotheses, as in Release's (v). -/
theorem p11v_saturating_reversal {Ts : ℝ → ℝ} {d : ℝ} (hT0 : Ts 0 = 1)
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ => Phi ρSat { pSat with kpost := q.2 } q.1)
      (Ts 0, 0))
    (hd : HasDerivWithinAt Ts d (Ici 0) 0)
    (hzero : ∀ᶠ k in 𝓝[≥] (0:ℝ), Phi ρSat { pSat with kpost := k } (Ts k) = 0) :
    d = -3 / (exp 4 + 1) ∧ d < 0 := by
  have ha : HasDerivAt (fun T => Phi ρSat { pSat with kpost := 0 } T)
      (-(4 * exp (-4) * (1 + exp (-4)))) (Ts 0) := by
    rw [hT0]; exact sat_Phi_T_partial
  have hb : HasDerivAt (fun k => Phi ρSat { pSat with kpost := k } (Ts 0)) (-(12 * exp (-8))) 0 := by
    rw [hT0]; exact sat_Phi_kpost_partial
  have hne : -(4 * exp (-4) * (1 + exp (-4))) ≠ 0 := by
    have := exp_pos (-4); nlinarith
  have hdv := comp_statics_right (Φ := fun T k => Phi ρSat { pSat with kpost := k } T)
    hΦ ha hb hd hzero hne
  have e8 : exp (-8) = exp (-4) * exp (-4) := by rw [← exp_add]; norm_num
  have e4 : exp (-4) = 1 / exp 4 := by rw [exp_neg, inv_eq_one_div]
  have hval : -(-(12 * exp (-8))) / -(4 * exp (-4) * (1 + exp (-4))) = -3 / (exp 4 + 1) := by
    rw [e8, e4]
    have := exp_pos 4
    field_simp
    ring
  rw [hval] at hdv
  refine ⟨hdv, ?_⟩
  rw [hdv]
  exact div_neg_of_neg_of_pos (by norm_num) (by linarith [exp_pos 4])


/-- For the saturating rent, `xρ′(x) = 4xe^{−4x}`, which falls strictly for `x ≥ 1/4`: the
general condition of `p11v_kpost_later_general` fails there (proof of P11, line 1193). -/
theorem sat_qf_falls :
    (∀ x, qf ρSat x = 4 * x * exp (-4 * x)) ∧ StrictAntiOn (qf ρSat) (Ici (1 / 4)) := by
  have hd : ∀ x, deriv ρSat x = 4 * exp (-4 * x) := by
    intro x
    have h : HasDerivAt ρSat (-(exp (-4 * x) * (-4 * 1))) x := by
      unfold ρSat; exact (((hasDerivAt_id x).const_mul (-4)).exp).const_sub 1
    rw [h.deriv]; ring
  have hq : ∀ x, qf ρSat x = 4 * x * exp (-4 * x) := by intro x; simp only [qf, hd]; ring
  refine ⟨hq, ?_⟩
  have hfun : qf ρSat = fun x => 4 * x * exp (-4 * x) := funext hq
  rw [hfun]
  apply strictAntiOn_of_deriv_neg (convex_Ici _) (Continuous.continuousOn (by fun_prop))
  intro x hx
  rw [interior_Ici] at hx
  have hx' : 1 / 4 < x := hx
  have h : HasDerivAt (fun x => 4 * x * exp (-4 * x))
      (4 * exp (-4 * x) * (1 - 4 * x)) x := by
    have h1 : HasDerivAt (fun x : ℝ => 4 * x) (4 * 1) x := (hasDerivAt_id x).const_mul 4
    have h2 : HasDerivAt (fun x => exp (-4 * x)) (exp (-4 * x) * (-4 * 1)) x :=
      ((hasDerivAt_id x).const_mul (-4)).exp
    exact (h1.mul h2).congr_deriv (by ring)
  rw [h.deriv]
  exact mul_neg_of_pos_of_neg (by positivity) (by linarith)

end P11sat

section BS2
open MeasureTheory ProbabilityTheory Set RTTR.Copies
open scoped ENNReal


/-! ## B-S2: "the optimized responses have no general direction"

B-S2 fixes committed holding and immediate release, and sets aside, among others,
post-preemption release. Allowing that option to a holder who optimizes its private value is an
"optimized response". The claim is that its effect on outsiders' exposure has no general sign.
It is proved by two instances, in Appendix B's own event system, windows and exposure, with
opposite strict signs. -/

/-- The holder's policies: B-S2's committed ones, plus the option B-S2 sets aside, holding and
then releasing openly at the first safeguarded rival preemption (`C0`). -/
inductive Pol
  | hold
  | openRel
  | closedRel
  | holdThenRel
  deriving DecidableEq

/-- The attacker-access window of each policy on a path of first arrivals `s` (failure bit `b`
for closed release). The first three are Copies' `WA`; the fourth ends exclusion at the first
attack-enabling event or at the holder's own open release at the first `C0` arrival. -/
noncomputable def WApol (a : Pol) (b : Bool) (s : Ev → ℝ≥0∞) : ℝ≥0∞ :=
  match a with
  | .hold => WA .hold b (omegaAOf s)
  | .openRel => WA .openRel b (omegaAOf s)
  | .closedRel => WA .closedRel b (omegaAOf s)
  | .holdThenRel => min (omegaAOf s) (s .C0)

/-- Releasing at the first safeguarded preemption ends exclusion exactly at `ω_C`. -/
theorem WApol_holdThenRel (b : Bool) (s : Ev → ℝ≥0∞) :
    WApol .holdThenRel b s = omegaCOf s := by
  have hset : commSet = insert Ev.C0 attackSet := by decide
  simp only [WApol, omegaCOf, omegaAOf, hset, Finset.inf_insert]
  exact min_comm _ _

/-- Pathwise, the option can only shorten exclusion relative to holding (Gaps1's X1), and can
only lengthen it relative to immediate open release. -/
theorem bs2_pathwise (b : Bool) (s : Ev → ℝ≥0∞) :
    WApol .holdThenRel b s ≤ WApol .hold b s ∧ WApol .openRel b s ≤ WApol .holdThenRel b s := by
  rw [WApol_holdThenRel]
  refine ⟨?_, ?_⟩
  · simp only [WApol, WA, holderAttackDate, min_top_right]; exact e1_omegaC_le_omegaA s
  · simp [WApol, WA, holderAttackDate]

/-- Private values. Holding earns `F` until the commercial lead ends, at rate `λ_C`, then the
continuation `Z`: zero for committed holding, the expected value `Zpp` of the post-preemption
release for the option (P11–P13's hold value `(F + λZ)/(r + λ)`, `Program.holdValue`).
Immediate releases are worth `Jo` and `Jc`. B-S1 leaves these values unmodelled; they are the
free inputs of the instances. -/
noncomputable def privVal (r lamC F Jo Jc Zpp : ℝ) : Pol → ℝ
  | .hold => RTTR.Program.holdValue r lamC F 0
  | .openRel => Jo
  | .closedRel => Jc
  | .holdThenRel => RTTR.Program.holdValue r lamC F Zpp

/-- B-S2's committed menu, and the menu with the post-preemption option. -/
def baseMenu : Finset Pol := {.hold, .openRel, .closedRel}
def extMenu : Finset Pol := {.hold, .openRel, .closedRel, .holdThenRel}

/-- `a` is the unique optimized response over menu `M`. -/
def UniqueBest (v : Pol → ℝ) (M : Finset Pol) (a : Pol) : Prop :=
  a ∈ M ∧ ∀ b ∈ M, b ≠ a → v b < v a

/-- The instance rates: no open rivals, closed rivals at rate 1 whose safeguards always work
(`p_c = 0`, so `C0` has rate 1), theft at rate 1, no leaks: `λ_C = 2`, `λ_A = 1`. -/
def qInst : Rates := ⟨0, 1, 0, 1, 0⟩

theorem qInst_adm : qInst.Admissible := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩ <;> norm_num [qInst]

theorem qInst_lamC : qInst.lamC = 2 := by norm_num [qInst, Rates.lamC]
theorem qInst_lamA : qInst.lamA = 1 := by norm_num [qInst, Rates.lamA]

/-- Exposure of one unfound flaw with removal date 1 and discovery delay 0, `π = 0`, unit weight:
`X(W) = (1 − W)⁺` (Copies' `exposure`, lines 1213–1221). -/
def schedInst : Schedule Empty Unit :=
  ⟨Empty.elim, Empty.elim, Empty.elim, Empty.elim, Empty.elim, 0, fun _ => 1, fun _ => 0,
    fun _ => 0, fun _ => 1⟩

theorem exposure_inst (W : ℝ) :
    exposure 0 schedInst W = 1 - min W 1 := by
  simp only [exposure, patchedTerm, unfoundTerm, schedInst, Finset.univ_eq_empty,
    Finset.sum_empty, Finset.univ_unique, Finset.sum_singleton, zero_add, sub_zero, one_mul,
    zero_mul, add_zero]
  rcases le_total W 1 with h | h
  · rw [min_eq_left h, max_eq_left (by linarith)]
  · rw [min_eq_right h, max_eq_right (by linarith)]; ring

/-- An extended exponential time has the real exponential survival law after `toReal`. -/
theorem real_survival {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {X : Ω → ℝ≥0∞} (hX : Measurable X) {r : ℝ} (hr : 0 < r) (h : HasExpSurvival μ X r) :
    ∀ t, 0 ≤ t → μ {ω | t < (X ω).toReal} = ENNReal.ofReal (Real.exp (-r * t)) := by
  intro t ht
  have hset : {ω | t < (X ω).toReal} = {ω | ENNReal.ofReal t < X ω} ∩ {ω | X ω ≠ ⊤} := by
    ext ω
    simp only [mem_ofPred_eq, mem_inter_iff]
    constructor
    · intro h1
      have hne : X ω ≠ ⊤ := by intro htop; rw [htop] at h1; simp at h1; linarith
      exact ⟨(ENNReal.ofReal_lt_iff_lt_toReal ht hne).2 h1, hne⟩
    · rintro ⟨h1, hne⟩
      exact (ENNReal.ofReal_lt_iff_lt_toReal ht hne).1 h1
  have hnull : μ {ω | X ω ≠ ⊤}ᶜ = 0 := by
    have := HasExpSurvival.ae_lt_top hX hr h
    rw [ae_iff] at this
    convert this using 2
    ext ω; simp [lt_top_iff_ne_top]
  rw [hset, measure_inter_conull hnull, h t ht, neg_mul]

/-- Expected exposure under an exponential window with rate `λ`: `1 − m(λ, 1)`. -/
theorem expected_exposure_exp {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] {X : Ω → ℝ≥0∞} (hX : Measurable X) {r : ℝ} (hr : 0 < r)
    (h : HasExpSurvival μ X r) :
    ∫ ω, exposure 0 schedInst (X ω).toReal ∂μ = 1 - RTTR.Hold.m r 1 := by
  have hW : Measurable fun ω => (X ω).toReal := hX.ennreal_toReal
  have hmin := RTTR.Hold.p6ii_exp_real μ (fun ω => (X ω).toReal) hW r 1 hr zero_le_one
    (real_survival hX hr h)
  have hcongr : (fun ω => exposure 0 schedInst (X ω).toReal) = fun ω => 1 - min (X ω).toReal 1 :=
    funext fun ω => exposure_inst _
  have hint : Integrable (fun ω => min (X ω).toReal 1) μ := by
    refine Integrable.mono' (integrable_const (1:ℝ)) (hW.min measurable_const).aestronglyMeasurable
      (Filter.Eventually.of_forall fun ω => ?_)
    rw [Real.norm_eq_abs, abs_of_nonneg (le_min ENNReal.toReal_nonneg zero_le_one)]
    exact min_le_right _ _
  rw [hcongr, integral_sub (integrable_const 1) hint, integral_const, hmin]
  simp

theorem m_two_lt_m_one : RTTR.Hold.m 2 1 < RTTR.Hold.m 1 1 := by
  unfold RTTR.Hold.m
  have h1 : Real.exp (-1) < 1 := by rw [Real.exp_lt_one_iff]; norm_num
  have h2 : Real.exp (-2 * 1) = Real.exp (-1) ^ 2 := by rw [← Real.exp_nat_mul]; norm_num
  have h3 : 0 < Real.exp (-1) := Real.exp_pos _
  rw [h2]; simp only [neg_mul, one_mul, div_one]
  nlinarith

theorem m_two_pos : 0 < RTTR.Hold.m 2 1 := by
  unfold RTTR.Hold.m
  have : Real.exp (-2 * 1) < 1 := by rw [Real.exp_lt_one_iff]; norm_num
  exact div_pos (by linarith) (by norm_num)

/-- **B-S2, instance A: the optimized response raises exposure.** With `r = 1`, `F = 2`,
immediate releases worth `1/2` and the post-preemption release worth `Zpp = 1/2` in expectation,
the committed optimum is holding (`2/3`), the optimum with the option is to hold and release at
preemption (`1`), and outsiders' expected exposure rises strictly, from `E[(1 − ω_A)⁺]` to
`E[(1 − ω_C)⁺]`, in every model of Appendix B's event system with these rates. -/
theorem bs2_instance_raises {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] {τ : Ev → Ω → ℝ≥0∞} (h : FirstArrivals μ τ qInst.rate) :
    UniqueBest (privVal 1 qInst.lamC 2 (1/2) (1/2) (1/2)) baseMenu .hold ∧
    UniqueBest (privVal 1 qInst.lamC 2 (1/2) (1/2) (1/2)) extMenu .holdThenRel ∧
    (∫ ω, exposure 0 schedInst (WApol .hold false (fun e => τ e ω)).toReal ∂μ <
      ∫ ω, exposure 0 schedInst (WApol .holdThenRel false (fun e => τ e ω)).toReal ∂μ) := by
  have hv0 : RTTR.Program.holdValue 1 qInst.lamC 2 0 = 2 / 3 := by
    rw [RTTR.Program.holdValue_eq (by rw [qInst_lamC]; norm_num), qInst_lamC]; norm_num
  have hv1 : RTTR.Program.holdValue 1 qInst.lamC 2 (1/2) = 1 := by
    rw [RTTR.Program.holdValue_eq (by rw [qInst_lamC]; norm_num), qInst_lamC]; norm_num
  have hS : Measurable fun ω e => τ e ω := measurable_pi_iff.mpr h.meas
  refine ⟨⟨by decide, ?_⟩, ⟨by decide, ?_⟩, ?_⟩
  · intro b hb hne
    fin_cases hb <;> simp_all [privVal] <;> norm_num
  · intro b hb hne
    fin_cases hb <;> simp_all [privVal] <;> norm_num
  · have hA : ∀ ω, WApol .hold false (fun e => τ e ω) = omegaAOf (fun e => τ e ω) := by
      intro ω; simp [WApol, WA, holderAttackDate]
    have hC : ∀ ω, WApol .holdThenRel false (fun e => τ e ω) = omegaCOf (fun e => τ e ω) :=
      fun ω => WApol_holdThenRel _ _
    simp only [hA, hC]
    have eA := expected_exposure_exp (measurable_omegaAOf.comp hS) (by rw [qInst_lamA]; norm_num)
      (e1_omegaA_exp h)
    have eC := expected_exposure_exp (measurable_omegaCOf.comp hS) (by rw [qInst_lamC]; norm_num)
      (e1_omegaC_exp h)
    simp only [Function.comp_def] at eA eC
    rw [eA, eC, qInst_lamA, qInst_lamC]
    linarith [m_two_lt_m_one]

/-- **B-S2, instance B: the optimized response lowers exposure.** Same rates, `r = 1`, `F = 2`,
`Zpp = 1/2`, but immediate open release worth `9/10` (closed `1/2`): the committed optimum is
immediate open release, the optimum with the option is to hold and release at preemption, and
outsiders' expected exposure falls strictly, from `X(0) = 1` to `E[(1 − ω_C)⁺]`. -/
theorem bs2_instance_lowers {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] {τ : Ev → Ω → ℝ≥0∞} (h : FirstArrivals μ τ qInst.rate) :
    UniqueBest (privVal 1 qInst.lamC 2 (9/10) (1/2) (1/2)) baseMenu .openRel ∧
    UniqueBest (privVal 1 qInst.lamC 2 (9/10) (1/2) (1/2)) extMenu .holdThenRel ∧
    (∫ ω, exposure 0 schedInst (WApol .holdThenRel false (fun e => τ e ω)).toReal ∂μ <
      ∫ ω, exposure 0 schedInst (WApol .openRel false (fun e => τ e ω)).toReal ∂μ) := by
  have hv0 : RTTR.Program.holdValue 1 qInst.lamC 2 0 = 2 / 3 := by
    rw [RTTR.Program.holdValue_eq (by rw [qInst_lamC]; norm_num), qInst_lamC]; norm_num
  have hv1 : RTTR.Program.holdValue 1 qInst.lamC 2 (1/2) = 1 := by
    rw [RTTR.Program.holdValue_eq (by rw [qInst_lamC]; norm_num), qInst_lamC]; norm_num
  have hS : Measurable fun ω e => τ e ω := measurable_pi_iff.mpr h.meas
  refine ⟨⟨by decide, ?_⟩, ⟨by decide, ?_⟩, ?_⟩
  · intro b hb hne
    fin_cases hb <;> simp_all [privVal] <;> norm_num
  · intro b hb hne
    fin_cases hb <;> simp_all [privVal] <;> norm_num
  · have hO : ∀ ω, WApol .openRel false (fun e => τ e ω) = 0 := by
      intro ω; simp [WApol, WA, holderAttackDate]
    have hC : ∀ ω, WApol .holdThenRel false (fun e => τ e ω) = omegaCOf (fun e => τ e ω) :=
      fun ω => WApol_holdThenRel _ _
    simp only [hO, hC, ENNReal.toReal_zero]
    have eC := expected_exposure_exp (measurable_omegaCOf.comp hS) (by rw [qInst_lamC]; norm_num)
      (e1_omegaC_exp h)
    simp only [Function.comp_def] at eC
    rw [eC, qInst_lamC, exposure_inst 0, integral_const]
    simp only [min_eq_left zero_le_one, sub_zero, probReal_univ, smul_eq_mul, one_mul]
    linarith [m_two_pos]

/-! ### Nonvacuity: a model of the event system with the instance rates exists -/

instance instFintypeEv : Fintype Ev :=
  ⟨{.O, .C1, .C0, .Th, .L}, by intro e; cases e <;> decide⟩

/-- Coordinate model: `Ω = Ev → ℝ` with independent unit-rate exponential coordinates; the
streams of positive rate (`C0`, theft) read their coordinate, the zero-rate ones never arrive. -/
noncomputable def instTime (e : Ev) (x : ℝ) : ℝ≥0∞ :=
  if qInst.rate e = 0 then ⊤ else ENNReal.ofReal x

theorem bs2_model_exists :
    ∃ (μ : Measure (Ev → ℝ)) (_ : IsProbabilityMeasure μ),
      FirstArrivals μ (fun e ω => instTime e (ω e)) qInst.rate := by
  have h1 : (0:ℝ) < 1 := one_pos
  have : IsProbabilityMeasure (expMeasure (1:ℝ)) := isProbabilityMeasure_expMeasure h1
  refine ⟨Measure.pi (fun _ => expMeasure 1), inferInstance, ?_⟩
  have hmeas : ∀ e, Measurable (instTime e) := by
    intro e; unfold instTime; split_ifs
    · exact measurable_const
    · exact ENNReal.measurable_ofReal
  refine ⟨fun e => (hmeas e).comp (measurable_pi_apply e), ?_, ?_, ?_, ?_⟩
  · exact iIndepFun_pi (fun e => (hmeas e).aemeasurable)
  · exact qInst.rate_nonneg qInst_adm
  · intro e he t ht
    have hrate : qInst.rate e = 1 := by
      cases e <;> simp_all [Rates.rate, qInst]
    have hne : qInst.rate e ≠ 0 := by rw [hrate]; norm_num
    have hset : {ω : Ev → ℝ | ENNReal.ofReal t < instTime e (ω e)} =
        (fun ω : Ev → ℝ => ω e) ⁻¹' Ioi t := by
      ext ω
      simp only [instTime, hne, ↓reduceIte, mem_ofPred_eq, mem_preimage, mem_Ioi]
      rw [ENNReal.ofReal_lt_ofReal_iff']
      constructor
      · exact fun h => h.1
      · exact fun h => ⟨h, lt_of_le_of_lt ht h⟩
    rw [hset, hrate]
    rw [(measurePreserving_eval (fun _ : Ev => expMeasure (1:ℝ)) e).measure_preimage
      measurableSet_Ioi.nullMeasurableSet]
    have hc : Ioi t = (Iic t)ᶜ := by ext x; simp
    rw [hc, prob_compl_eq_one_sub measurableSet_Iic]
    have hcdf : cdf (expMeasure 1) t = 1 - Real.exp (-(1 * t)) := by
      rw [cdf_expMeasure_eq h1]; simp only [ht, ↓reduceIte]
    rw [← ENNReal.ofReal_one, ← ofReal_cdf, hcdf,
      ← ENNReal.ofReal_sub _ (by
        have := Real.exp_le_one_iff.mpr (by nlinarith : -(1 * t) ≤ 0)
        linarith : (0:ℝ) ≤ 1 - Real.exp (-(1 * t)))]
    congr 1; ring
  · intro e he ω
    simp [instTime, he]


end BS2

end RTTR.Gaps4

#print axioms RTTR.Gaps4.partial_coop_succ
#print axioms RTTR.Gaps4.partial_pun_succ
#print axioms RTTR.Gaps4.expPay_pun_le
#print axioms RTTR.Gaps4.geom_partial
#print axioms RTTR.Gaps4.partial_pun_le
#print axioms RTTR.Gaps4.UN_le_UC
#print axioms RTTR.Gaps4.one_step
#print axioms RTTR.Gaps4.p10_iii_full_bound
#print axioms RTTR.Gaps4.expPay_restraint_coop
#print axioms RTTR.Gaps4.p10_iii_restraint_value
#print axioms RTTR.Gaps4.p10_iii_full_limsup
#print axioms RTTR.Gaps4.p10_iii_full_sufficiency
#print axioms RTTR.Gaps4.expPay_const_pun
#print axioms RTTR.Gaps4.expPay_oneShot
#print axioms RTTR.Gaps4.hasSum_oneShot
#print axioms RTTR.Gaps4.p10_iii_full_iff
#print axioms RTTR.Gaps4.p10_iii_punishment_best
#print axioms RTTR.Gaps4.p10_iii_subgame_coop
#print axioms RTTR.Gaps4.f_integrableOn_bdd
#print axioms RTTR.Gaps4.Pi_shift_bdd
#print axioms RTTR.Gaps4.Pi_hasDerivAt_of_continuousAt
#print axioms RTTR.Gaps4.V_hasDerivAt_gen
#print axioms RTTR.Gaps4.holdIntegrand_measurable
#print axioms RTTR.Gaps4.holdIntegrand_intervalIntegrable
#print axioms RTTR.Gaps4.p11i_jump_V_hasDerivAt
#print axioms RTTR.Gaps4.p11i_jump_candidates
#print axioms RTTR.Gaps4.p11i_jump_optimum
#print axioms RTTR.Gaps4.p11i_jump_candidates_kpost0
#print axioms RTTR.Gaps4.rhoJ_measurable
#print axioms RTTR.Gaps4.rhoJ_bdd
#print axioms RTTR.Gaps4.rhoJ_not_continuousAt_one
#print axioms RTTR.Gaps4.bridge_lead
#print axioms RTTR.Gaps4.bridge_V
#print axioms RTTR.Gaps4.bridge_Phi
#print axioms RTTR.Gaps4.p11i_jump_example
#print axioms RTTR.Gaps4.measurable_qf
#print axioms RTTR.Gaps4.integrableOn_id_mul_exp
#print axioms RTTR.Gaps4.integral_id_mul_exp
#print axioms RTTR.Gaps4.scaled_mem_Ioo
#print axioms RTTR.Gaps4.dom_deriv
#print axioms RTTR.Gaps4.Pi_hasDerivAt_kappa
#print axioms RTTR.Gaps4.Pi_hasDerivAt_x
#print axioms RTTR.Gaps4.rho_sub_rPi
#print axioms RTTR.Gaps4.integrable_I0
#print axioms RTTR.Gaps4.integrable_I1
#print axioms RTTR.Gaps4.I0_sub_rI1_nonneg
#print axioms RTTR.Gaps4.qf_nonneg_of_monotone
#print axioms RTTR.Gaps4.I1_pos
#print axioms RTTR.Gaps4.lead_kpost
#print axioms RTTR.Gaps4.p11v_kpost_partial_general
#print axioms RTTR.Gaps4.p11v_kpost_partial_general_pos
#print axioms RTTR.Gaps4.p11v_kpost_later_general
#print axioms RTTR.Gaps4.p11v_general_covers_linear
#print axioms RTTR.Gaps4.integral_id_mul_exp_one
#print axioms RTTR.Gaps4.u_exp_bound
#print axioms RTTR.Gaps4.u2_exp_bound
#print axioms RTTR.Gaps4.rhoSat_bounds
#print axioms RTTR.Gaps4.hasDerivAt_u
#print axioms RTTR.Gaps4.sat_Pi_hasDerivAt_x
#print axioms RTTR.Gaps4.sat_Pi_hasDerivAt_k
#print axioms RTTR.Gaps4.sat_P1_hasDerivAt_k
#print axioms RTTR.Gaps4.sat_Phi_near
#print axioms RTTR.Gaps4.sat_Phi_kpost_partial
#print axioms RTTR.Gaps4.sat_Phi_T_partial
#print axioms RTTR.Gaps4.comp_statics_right
#print axioms RTTR.Gaps4.p11v_saturating_reversal
#print axioms RTTR.Gaps4.sat_qf_falls
#print axioms RTTR.Gaps4.WApol_holdThenRel
#print axioms RTTR.Gaps4.bs2_pathwise
#print axioms RTTR.Gaps4.qInst_adm
#print axioms RTTR.Gaps4.qInst_lamC
#print axioms RTTR.Gaps4.qInst_lamA
#print axioms RTTR.Gaps4.exposure_inst
#print axioms RTTR.Gaps4.real_survival
#print axioms RTTR.Gaps4.expected_exposure_exp
#print axioms RTTR.Gaps4.m_two_lt_m_one
#print axioms RTTR.Gaps4.m_two_pos
#print axioms RTTR.Gaps4.bs2_instance_raises
#print axioms RTTR.Gaps4.bs2_instance_lowers
#print axioms RTTR.Gaps4.bs2_model_exists
