import Mathlib

/-!
# RTTR v8, seat L2: Proposition 3 (the existence of a peak) and A.7's two P3 extensions

Paper: `PAPER-DRAFT-v8.md`, P3 at lines 899–911, proof A.6 line 1118, A.7 lines 1156–1157,
main text §4.5 (141–156).

## How each paper object is represented, and why that is faithful

* **The stock and its equation (A5).** `E : ℝ → ℝ` is *not* defined by a closed form. It is any
  function satisfying `∀ t ∈ I, HasDerivWithinAt E (ι t - μ t * E t) I t` on the domain `I`. This
  is A5's `dE/dt = ι(t) − μ(t)E` as a hypothesis, which is what the paper's set-up is. The
  derivative is taken *within* the domain, so at `t = 0` it is the right derivative: this is
  "differentiable on `[0, T_A)`" exactly, not a two-sided derivative at 0. Where `μ` is constant
  (P3(ii), (iii), A.7) it is a real `μ`.
* **Domains.** The pre-ASI domain `[0, T_A)` is `Ico 0 TA` (`TA : ℝ`). The "untruncated path,
  continued past `T_A`" is `Ici 0`. The core lemmas are stated for an arbitrary convex `I`
  (an interval) and then specialised to both.
* **The hazard** `h = φE` with constant `φ > 0` is `fun t => φ * E t`.
* **"Rises and later falls"** is `RisesFalls h I`: there are `a < b < c` in `I` with
  `h b > h a` and `h b > h c`. This is function-value content; P3(i)'s derivative-sign condition
  is proved *equivalent* to it (`p3i_risesFalls_iff`), not used as its definition.
* **"A peak exists" (P3(iii), A.7)** is `RisesFalls` of the hazard on the continued trajectory
  `Ici 0`; **"an intermediate pre-ASI peak"** is `RisesFalls` on `Ico 0 TA`. For the latter the
  paper says "if `t̂ < T_A`"; we prove the iff (criterion and `t̂ < T_A`). The peak *date* is
  proved to be the unique maximizer of `E` on the domain, with strict rise before and strict fall
  after.
* **"Interior maximum"** is `IsLocalMax` of the hazard at a point of `interior I` (and, as a
  corollary, `IsMaxOn` over `I` attained at an interior point).
* **P3(ii)'s conclusion** "`E` is non-decreasing up to some date and non-increasing after it,
  and a monotone rise is allowed" is the disjunction: `E` strictly increasing on all of `I`, or
  some `d > 0` with `E` strictly increasing on `I ∩ [0, d]` and non-increasing on `I ∩ [d, ∞)`.
  (Strict increase before `d` is stronger than the paper's "non-decreasing".)
* **P3(iii)'s inflow** is `iotaP ι₀ ι₁ γ t = ι₁ + (ι₀ − ι₁)e^{−γt}`. The paper's closed forms
  `EsolNe` (`μ ≠ γ`) and `EsolEq` (`μ = γ`) are proved to solve the equation
  (`esolNe_hasDerivAt`, `esolEq_hasDerivAt`) and to be the *only* solution with the given
  `E(0)` on any interval containing 0 (`p3iii_solution_unique`, via `ode_unique`).
  All peak statements are then about an *arbitrary* solution `E`.
* **The sign of `E′`.** `e^{μt}E′(t)` equals the closed form `GNe` (`μ ≠ γ`) or `GEq` (`μ = γ`),
  which is strictly decreasing; the A.7 quantity `q` is `qS`. A.7's non-empty stock `E(0) = E₀`
  is done in general and P3(iii) is its case `E₀ = 0` (`qS_zero`, `tHatNe_zero`, `tHatEq_zero`
  recover the paper's formulas for `q` and `t̂`).
* **"Settles to the plateau `φι₁/μ`"** is `Tendsto (φ * E) atTop (𝓝 (φ * ι₁ / μ))`.
* **"As first stated"** claims are formalised as universally quantified statements over
  models `(ι, μ, E)` satisfying A5 (with `μ > 0`, `ι ≥ 0`, the equation, `E(0) = 0`), and their
  negations are proved by exhibiting the paper's examples. "Grows without limit, no plateau" is
  `Tendsto E atTop atTop` and the absence of any finite limit.
* **"Plateau" has two readings, and both are formalised.** P3(iii) itself calls the limit
  `φι₁/μ` "the plateau" for every `ι₁ ≥ 0`, so a limit of 0 counts (reading 1: any finite
  limit). Figure 6 contrasts "falls toward zero" with a plateau (reading 2: a positive limit).
  Under reading 1 the finite example `E = t(1 − t)` *has* a plateau (`origF_has_limit`); under
  reading 2 it has none (`origF_no_positive_plateau`).
* **A.7 triage cap.** The capped path is any `EQ` with
  `HasDerivWithinAt EQ (ι t − min (μ * EQ t) Q) (Ici 0) t` on `t ≥ 0`, and every claim is proved
  for *every* such path. From an empty stock with P3(iii)'s inflow (`μ > 0`, `γ ≥ 0`,
  `0 ≤ ι₁ < ι₀`, any `Q`) the path exists (`a7_triage_exists`) and is unique
  (`a7_triage_unique`). Existence: Picard–Lindelöf on each `[0, n]` for the field with `E`
  clamped below at 0 (bounded and globally Lipschitz), glued by uniqueness; the clamp never
  binds because the path stays `≥ 0`. "Any peak is no lower than without the cap" is proved as
  pointwise domination `E ≤ EQ`, so the capped path's highest level is no lower than the
  uncapped peak; a reading over every *local* peak of the capped path is not proved.
* **Line 276's "second rise".** Within P3(iii) (constant `φ`) a peak is never followed by a
  second rise (strict fall after `t̂`), so the second rise is formalised outside A5, with a
  time-varying intensity per flaw. The explicit intensity path
  `phiRise φ c t = φ(1 + max(t − c, 0)²)` (continuous, positive, non-decreasing, equal to `φ`
  before `c`, strictly rising after), on P3(iii)'s path with a residue, turns peak-then-plateau
  into peak, decline, unbounded second rise (`line276_second_rise`). Without a residue, the same
  intensity path gives a hazard tending to zero (`line276_no_residue_falls`). The exponential path
  `phiExp φ 2 2 t = φe^{2 max(t − 2, 0)}` gives a second rise on the residue-free path `te^{−t}`
  (`line276_second_rise_no_residue`), so a residue is not necessary for a second rise. These are
  existence instances, not a characterisation over all intensity paths.
-/

open Set Filter Topology Real

namespace RTTR.Peak

/-! ## Shared vocabulary -/

/-- "Rises and later falls" on a domain `I`: function-value content, not derivative witnesses. -/
def RisesFalls (h : ℝ → ℝ) (I : Set ℝ) : Prop :=
  ∃ a b c, a ∈ I ∧ b ∈ I ∧ c ∈ I ∧ a < b ∧ b < c ∧ h a < h b ∧ h c < h b

lemma risesFalls_const_mul {φ : ℝ} (hφ : 0 < φ) (E : ℝ → ℝ) (I : Set ℝ) :
    RisesFalls (fun t => φ * E t) I ↔ RisesFalls E I := by
  constructor
  · rintro ⟨a, b, c, ha, hb, hc, hab, hbc, h1, h2⟩
    exact ⟨a, b, c, ha, hb, hc, hab, hbc, lt_of_mul_lt_mul_left h1 hφ.le,
      lt_of_mul_lt_mul_left h2 hφ.le⟩
  · rintro ⟨a, b, c, ha, hb, hc, hab, hbc, h1, h2⟩
    exact ⟨a, b, c, ha, hb, hc, hab, hbc, mul_lt_mul_of_pos_left h1 hφ,
      mul_lt_mul_of_pos_left h2 hφ⟩

lemma not_risesFalls_of_strictMonoOn {E : ℝ → ℝ} {I : Set ℝ} (h : StrictMonoOn E I) :
    ¬ RisesFalls E I := by
  rintro ⟨a, b, c, _, hb, hc, _, hbc, _, h2⟩
  exact lt_asymm h2 (h hb hc hbc)

lemma not_risesFalls_of_strictAntiOn {E : ℝ → ℝ} {I : Set ℝ} (h : StrictAntiOn E I) :
    ¬ RisesFalls E I := by
  rintro ⟨a, b, c, ha, hb, _, hab, _, h1, _⟩
  exact lt_asymm h1 (h ha hb hab)

lemma hasDerivAt_of_interior {E g : ℝ → ℝ} {I : Set ℝ}
    (hE : ∀ t ∈ I, HasDerivWithinAt E (g t) I t) {x : ℝ} (hx : x ∈ interior I) :
    HasDerivAt E (g x) x :=
  (hE x (interior_subset hx)).hasDerivAt (mem_interior_iff_mem_nhds.mp hx)

lemma continuousOn_of_hasDerivWithinAt {E g : ℝ → ℝ} {I : Set ℝ}
    (hE : ∀ t ∈ I, HasDerivWithinAt E (g t) I t) : ContinuousOn E I :=
  fun x hx => (hE x hx).continuousWithinAt

/-- A positive (right) derivative within `s` gives larger values just to the right. -/
lemma eventually_right_gt {f : ℝ → ℝ} {f' x u : ℝ} {s : Set ℝ}
    (hf : HasDerivWithinAt f f' s x) (hpos : 0 < f') (hxu : x < u) (hsub : Ioo x u ⊆ s) :
    ∀ᶠ y in 𝓝[>] x, f x < f y := by
  have h1 := (hasDerivWithinAt_iff_tendsto_slope.mp hf).eventually (lt_mem_nhds hpos)
  have h2 : 𝓝[>] x ≤ 𝓝[s \ {x}] x := by
    rw [← nhdsWithin_Ioo_eq_nhdsGT hxu]
    exact nhdsWithin_mono _ (fun y hy => ⟨hsub hy, by simpa using hy.1.ne'⟩)
  filter_upwards [h2 h1, self_mem_nhdsWithin] with y hy hyx
  rw [slope_def_field] at hy
  have hpos' : 0 < y - x := sub_pos.mpr hyx
  have := (lt_div_iff₀ hpos').mp hy
  linarith

/-- A negative derivative within `s` gives larger values just to the left. -/
lemma eventually_left_gt {f : ℝ → ℝ} {f' x l : ℝ} {s : Set ℝ}
    (hf : HasDerivWithinAt f f' s x) (hneg : f' < 0) (hlx : l < x) (hsub : Ioo l x ⊆ s) :
    ∀ᶠ y in 𝓝[<] x, f x < f y := by
  have h1 := (hasDerivWithinAt_iff_tendsto_slope.mp hf).eventually (gt_mem_nhds hneg)
  have h2 : 𝓝[<] x ≤ 𝓝[s \ {x}] x := by
    rw [← nhdsWithin_Ioo_eq_nhdsLT hlx]
    exact nhdsWithin_mono _ (fun y hy => ⟨hsub hy, by simpa using hy.2.ne⟩)
  filter_upwards [h2 h1, self_mem_nhdsWithin] with y hy hyx
  rw [slope_def_field] at hy
  have hneg' : y - x < 0 := sub_neg.mpr hyx
  by_contra hc
  replace hc := not_lt.mp hc
  have : 0 ≤ (f y - f x) / (y - x) := div_nonneg_of_nonpos (by linarith) hneg'.le
  linarith

/-- A derivative at an interior point of a set on which the function is antitone is `≤ 0`. -/
lemma deriv_nonpos_of_antitoneOn {f : ℝ → ℝ} {f' x : ℝ} {I : Set ℝ} (hf : HasDerivAt f f' x)
    (hI : I ∈ 𝓝 x) (hanti : AntitoneOn f I) : f' ≤ 0 := by
  by_contra hc
  replace hc := not_le.mp hc
  have h1 := eventually_right_gt hf.hasDerivWithinAt hc (lt_add_one x) (subset_univ _)
  have h3 : ∀ᶠ y in 𝓝[>] x, y ∈ I := mem_nhdsWithin_of_mem_nhds hI
  have h4 : ∀ᶠ y in 𝓝[>] x, x < y := self_mem_nhdsWithin
  obtain ⟨y, hy, hyI, hxy⟩ := (h1.and (h3.and h4)).exists
  exact absurd (hanti (mem_of_mem_nhds hI) hyI (le_of_lt hxy)) (not_le.mpr hy)

/-! ## P3(i): a time-varying removal rate -/

lemma Icc_subset_of_convex {I : Set ℝ} (hI : Convex ℝ I) {x y : ℝ} (hx : x ∈ I) (hy : y ∈ I) :
    Icc x y ⊆ I :=
  (convex_iff_ordConnected.mp hI).out hx hy

lemma Ioo_subset_interior_of_convex {I : Set ℝ} (hI : Convex ℝ I) {x y : ℝ} (hx : x ∈ I)
    (hy : y ∈ I) : Ioo x y ⊆ interior I :=
  isOpen_Ioo.subset_interior_iff.mpr (Ioo_subset_Icc_self.trans (Icc_subset_of_convex hI hx hy))

/-- P3(i), forward: if the stock rises and later falls on `I`, there are ordered dates with
`ι > μE` (so `E′ > 0`) and then `ι < μE` (so `E′ < 0`). Mean value theorem on each leg. -/
theorem p3i_witnesses_of_risesFalls {ι μ E : ℝ → ℝ} {I : Set ℝ} (hI : Convex ℝ I)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ t * E t) I t) (h : RisesFalls E I) :
    ∃ t₀ t₁, t₀ ∈ I ∧ t₁ ∈ I ∧ t₀ < t₁ ∧ μ t₀ * E t₀ < ι t₀ ∧ ι t₁ < μ t₁ * E t₁ := by
  obtain ⟨a, b, c, ha, hb, hc, hab, hbc, h1, h2⟩ := h
  have hcont := continuousOn_of_hasDerivWithinAt hE
  obtain ⟨t₀, ht₀, hd₀⟩ := exists_hasDerivAt_eq_slope E (fun t => ι t - μ t * E t) hab
    (hcont.mono (Icc_subset_of_convex hI ha hb))
    (fun x hx => hasDerivAt_of_interior hE (Ioo_subset_interior_of_convex hI ha hb hx))
  obtain ⟨t₁, ht₁, hd₁⟩ := exists_hasDerivAt_eq_slope E (fun t => ι t - μ t * E t) hbc
    (hcont.mono (Icc_subset_of_convex hI hb hc))
    (fun x hx => hasDerivAt_of_interior hE (Ioo_subset_interior_of_convex hI hb hc hx))
  refine ⟨t₀, t₁, Icc_subset_of_convex hI ha hb (Ioo_subset_Icc_self ht₀),
    Icc_subset_of_convex hI hb hc (Ioo_subset_Icc_self ht₁), ht₀.2.trans ht₁.1, ?_, ?_⟩
  · have : 0 < (E b - E a) / (b - a) := div_pos (sub_pos.mpr h1) (sub_pos.mpr hab)
    linarith
  · have : (E c - E b) / (c - b) < 0 := div_neg_of_neg_of_pos (sub_neg.mpr h2) (sub_pos.mpr hbc)
    linarith

/-- P3(i), the interior maximizer between the witnesses: the maximum of `E` on `[t₀, t₁]` is
attained strictly inside, strictly above both endpoint values. -/
theorem p3i_interior_max {ι μ E : ℝ → ℝ} {I : Set ℝ} (hI : Convex ℝ I)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ t * E t) I t) {t₀ t₁ : ℝ}
    (h₀ : t₀ ∈ I) (h₁ : t₁ ∈ I) (h01 : t₀ < t₁)
    (hup : μ t₀ * E t₀ < ι t₀) (hdown : ι t₁ < μ t₁ * E t₁) :
    ∃ b ∈ Ioo t₀ t₁, IsMaxOn E (Icc t₀ t₁) b ∧ E t₀ < E b ∧ E t₁ < E b := by
  have hIcc : Icc t₀ t₁ ⊆ I := Icc_subset_of_convex hI h₀ h₁
  have hIoo : Ioo t₀ t₁ ⊆ I := Ioo_subset_Icc_self.trans hIcc
  obtain ⟨b, hb, hmax⟩ := isCompact_Icc.exists_isMaxOn (nonempty_Icc.2 h01.le)
    ((continuousOn_of_hasDerivWithinAt hE).mono hIcc)
  have hr := eventually_right_gt (hE t₀ h₀) (sub_pos.mpr hup) h01 hIoo
  have hl := eventually_left_gt (hE t₁ h₁) (by linarith) h01 hIoo
  have hr' : ∀ᶠ y in 𝓝[>] t₀, y ∈ Ioo t₀ t₁ := Ioo_mem_nhdsGT h01
  have hl' : ∀ᶠ y in 𝓝[<] t₁, y ∈ Ioo t₀ t₁ := Ioo_mem_nhdsLT h01
  obtain ⟨y, hy, hyI⟩ := (hr.and hr').exists
  obtain ⟨y', hy', hyI'⟩ := (hl.and hl').exists
  have hEy : E y ≤ E b := hmax (Ioo_subset_Icc_self hyI)
  have hEy' : E y' ≤ E b := hmax (Ioo_subset_Icc_self hyI')
  refine ⟨b, ⟨lt_of_le_of_ne hb.1 ?_, lt_of_le_of_ne hb.2 ?_⟩, hmax, by linarith, by linarith⟩
  · rintro rfl; linarith
  · rintro rfl; linarith

/-- **P3(i), the iff** on any interval domain `I`: the hazard `φE` rises and later falls on `I`
iff there are dates `t₀ < t₁` in `I` with `ι(t₀) > μ(t₀)E(t₀)` and `ι(t₁) < μ(t₁)E(t₁)`. -/
theorem p3i_risesFalls_iff {ι μ E : ℝ → ℝ} {φ : ℝ} {I : Set ℝ} (hφ : 0 < φ) (hI : Convex ℝ I)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ t * E t) I t) :
    RisesFalls (fun t => φ * E t) I ↔
      ∃ t₀ t₁, t₀ ∈ I ∧ t₁ ∈ I ∧ t₀ < t₁ ∧ μ t₀ * E t₀ < ι t₀ ∧ ι t₁ < μ t₁ * E t₁ := by
  rw [risesFalls_const_mul hφ]
  constructor
  · exact p3i_witnesses_of_risesFalls hI hE
  · rintro ⟨t₀, t₁, h₀, h₁, h01, hup, hdown⟩
    obtain ⟨b, hb, -, hb0, hb1⟩ := p3i_interior_max hI hE h₀ h₁ h01 hup hdown
    exact ⟨t₀, b, t₁, h₀, Icc_subset_of_convex hI h₀ h₁ (Ioo_subset_Icc_self hb), h₁, hb.1, hb.2,
      hb0, hb1⟩

/-- **P3(i)** on the paper's pre-ASI domain `[0, T_A)`, in the paper's wording
"dates `t₀ < t₁ < T_A` with `ι(t₀) > μE(t₀)` and `ι(t₁) < μE(t₁)`". -/
theorem p3i_rises_falls_iff_preASI {ι μ E : ℝ → ℝ} {φ TA : ℝ} (hφ : 0 < φ)
    (hE : ∀ t ∈ Ico 0 TA, HasDerivWithinAt E (ι t - μ t * E t) (Ico 0 TA) t) :
    RisesFalls (fun t => φ * E t) (Ico 0 TA) ↔
      ∃ t₀ t₁, 0 ≤ t₀ ∧ t₀ < t₁ ∧ t₁ < TA ∧ μ t₀ * E t₀ < ι t₀ ∧ ι t₁ < μ t₁ * E t₁ := by
  rw [p3i_risesFalls_iff hφ (convex_Ico 0 TA) hE]
  constructor
  · rintro ⟨t₀, t₁, h₀, h₁, h01, hu, hd⟩
    exact ⟨t₀, t₁, h₀.1, h01, h₁.2, hu, hd⟩
  · rintro ⟨t₀, t₁, h0, h01, h1, hu, hd⟩
    exact ⟨t₀, t₁, ⟨h0, h01.trans h1⟩, ⟨h0.trans h01.le, h1⟩, h01, hu, hd⟩

/-- **P3(i), first-order condition**: at any interior local maximum of the hazard, `ι = μE`. -/
theorem p3i_foc {ι μ E : ℝ → ℝ} {φ : ℝ} {I : Set ℝ} (hφ : 0 < φ)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ t * E t) I t) {t : ℝ} (ht : t ∈ interior I)
    (hmax : IsLocalMax (fun s => φ * E s) t) : ι t = μ t * E t := by
  have hmaxE : IsLocalMax E t :=
    Filter.Eventually.mono hmax (fun s hs => le_of_mul_le_mul_left hs hφ)
  have := hmaxE.hasDerivAt_eq_zero (hasDerivAt_of_interior hE ht)
  linarith

/-- The same, for a maximum of the hazard over the whole domain attained at an interior date. -/
theorem p3i_foc_of_isMaxOn {ι μ E : ℝ → ℝ} {φ : ℝ} {I : Set ℝ} (hφ : 0 < φ)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ t * E t) I t) {t : ℝ} (ht : t ∈ interior I)
    (hmax : IsMaxOn (fun s => φ * E s) I t) : ι t = μ t * E t :=
  p3i_foc hφ hE ht (hmax.isLocalMax (mem_interior_iff_mem_nhds.mp ht))

/-- **P3(i), second-order condition**: at an interior local maximum, if `ι` and `μ` are
differentiable there, `ι′ ≤ μ′E`. -/
theorem p3i_soc {ι μ E : ℝ → ℝ} {φ ι' μ' : ℝ} {I : Set ℝ} (hφ : 0 < φ)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ t * E t) I t) {t : ℝ} (ht : t ∈ interior I)
    (hmax : IsLocalMax (fun s => φ * E s) t) (hι : HasDerivAt ι ι' t) (hμ : HasDerivAt μ μ' t) :
    ι' ≤ μ' * E t := by
  have hmaxE : IsLocalMax E t :=
    Filter.Eventually.mono hmax (fun s hs => le_of_mul_le_mul_left hs hφ)
  have hfoc := p3i_foc hφ hE ht hmax
  have hEt := hasDerivAt_of_interior hE ht
  have hgd : HasDerivAt (fun s => ι s - μ s * E s)
      (ι' - (μ' * E t + μ t * (ι t - μ t * E t))) t := hι.sub (hμ.mul hEt)
  by_contra hc
  have hpos : 0 < ι' - (μ' * E t + μ t * (ι t - μ t * E t)) := by
    rw [show ι t - μ t * E t = 0 by linarith]; linarith [not_le.mp hc]
  have h1 := eventually_right_gt hgd.hasDerivWithinAt hpos (lt_add_one t) (subset_univ _)
  have hint : interior I ∈ 𝓝 t := isOpen_interior.mem_nhds ht
  have h2 : ∀ᶠ s in 𝓝[>] t, E s ≤ E t ∧ s ∈ interior I :=
    nhdsWithin_le_nhds (Filter.Eventually.and hmaxE hint)
  obtain ⟨u, hu, hsub⟩ := mem_nhdsGT_iff_exists_Ioo_subset.mp (h1.and h2)
  have hu' : t < u := hu
  have hts : t < (t + u) / 2 := by linarith
  have hsu : (t + u) / 2 < u := by linarith
  have hs₁ := hsub ⟨hts, hsu⟩
  have hmemI : ∀ x ∈ Icc t ((t + u) / 2), x ∈ interior I := by
    intro x hx
    rcases eq_or_lt_of_le hx.1 with h | h
    · exact h ▸ ht
    · exact (hsub ⟨h, lt_of_le_of_lt hx.2 hsu⟩).2.2
  have hcont : ContinuousOn E (Icc t ((t + u) / 2)) := fun x hx =>
    (hasDerivAt_of_interior hE (hmemI x hx)).continuousAt.continuousWithinAt
  obtain ⟨ξ, hξ, hξd⟩ := exists_hasDerivAt_eq_slope E (fun s => ι s - μ s * E s) hts hcont
    (fun x hx => hasDerivAt_of_interior hE (hmemI x (Ioo_subset_Icc_self hx)))
  have hgξ := (hsub ⟨hξ.1, hξ.2.trans hsu⟩).1
  have hpos' : 0 < (E ((t + u) / 2) - E t) / ((t + u) / 2 - t) := by linarith
  have := (lt_div_iff₀ (by linarith : (0:ℝ) < (t + u) / 2 - t)).mp hpos'
  linarith [hs₁.2.1]

/-! ## P3(ii): constant removal, non-increasing introduction -/

/-- **P3(ii)** on any interval domain `I ⊆ [0, ∞)` containing `0`: with `μ > 0` constant,
`ι` differentiable and non-increasing on `I`, and `E(0) < ι(0)/μ`, either `E` rises strictly
throughout `I` (a monotone rise), or there is a date `d > 0` with `E` strictly increasing on
`I ∩ [0, d]` and non-increasing on `I ∩ [d, ∞)`. -/
theorem p3ii_unimodal {ι ι' E : ℝ → ℝ} {μ : ℝ} {I : Set ℝ} (hI : Convex ℝ I) (h0I : (0:ℝ) ∈ I)
    (hIpos : ∀ t ∈ I, 0 ≤ t) (hμ : 0 < μ)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ * E t) I t)
    (hι : ∀ t ∈ I, HasDerivWithinAt ι (ι' t) I t) (hanti : AntitoneOn ι I)
    (hE0 : E 0 < ι 0 / μ) :
    StrictMonoOn E I ∨ ∃ d, 0 < d ∧ StrictMonoOn E (I ∩ Iic d) ∧ AntitoneOn E (I ∩ Ici d) := by
  set G : ℝ → ℝ := fun t => exp (μ * t) * (ι t - μ * E t) with hGdef
  have hexpd : ∀ t, HasDerivAt (fun t => exp (μ * t)) (exp (μ * t) * μ) t := fun t => by
    simpa using ((hasDerivAt_id t).const_mul μ).exp
  have hGd : ∀ t ∈ I, HasDerivWithinAt G (exp (μ * t) * ι' t) I t := by
    intro t ht
    have := ((hexpd t).hasDerivWithinAt (s := I)).mul ((hι t ht).sub ((hE t ht).const_mul μ))
    convert this using 1; simp only [Pi.sub_apply]; ring
  have hGcont := continuousOn_of_hasDerivWithinAt hGd
  have hGanti : AntitoneOn G I := by
    apply antitoneOn_of_deriv_nonpos hI hGcont
    · intro x hx
      exact (hasDerivAt_of_interior hGd hx).differentiableAt.differentiableWithinAt
    · intro x hx
      rw [(hasDerivAt_of_interior hGd hx).deriv]
      have := deriv_nonpos_of_antitoneOn (hasDerivAt_of_interior hι hx)
        (mem_interior_iff_mem_nhds.mp hx) hanti
      nlinarith [exp_pos (μ * x)]
  have hsignpos : ∀ t, 0 < G t ↔ 0 < ι t - μ * E t := fun t => by
    simp only [hGdef]; exact mul_pos_iff_of_pos_left (exp_pos _)
  have hsignnonpos : ∀ t, G t ≤ 0 ↔ ι t - μ * E t ≤ 0 := fun t => by
    rw [← not_lt, ← not_lt, hsignpos]
  have hG0 : 0 < G 0 := by
    rw [hsignpos]; have := (lt_div_iff₀ hμ).mp hE0; linarith
  have hEcont := continuousOn_of_hasDerivWithinAt hE
  by_cases hall : ∀ t ∈ I, 0 < G t
  · left
    apply strictMonoOn_of_deriv_pos hI hEcont
    intro x hx
    rw [(hasDerivAt_of_interior hE hx).deriv]
    exact (hsignpos x).mp (hall x (interior_subset hx))
  · right
    obtain ⟨t₂, ht₂I, ht₂⟩ : ∃ t ∈ I, G t ≤ 0 := by
      by_contra hc
      exact hall (fun t ht => not_le.mp (fun h => hc ⟨t, ht, h⟩))
    set S : Set ℝ := {t | t ∈ I ∧ G t ≤ 0} with hSdef
    have hSne : S.Nonempty := ⟨t₂, ht₂I, ht₂⟩
    have hSbdd : BddBelow S := ⟨0, fun t ht => hIpos t ht.1⟩
    have hlt : ∀ t ∈ I, t < sInf S → 0 < G t := fun t ht htd => by
      by_contra hc
      exact absurd (csInf_le hSbdd ⟨ht, not_lt.mp hc⟩) (not_le.mpr htd)
    have hgt : ∀ t ∈ I, sInf S < t → G t ≤ 0 := fun t ht hdt => by
      obtain ⟨s, hs, hst⟩ := exists_lt_of_csInf_lt hSne hdt
      exact (hGanti hs.1 ht hst.le).trans hs.2
    have hdpos : 0 < sInf S := by
      have hev : ∀ᶠ t in 𝓝[I] 0, 0 < G t := (hGcont 0 h0I).eventually (lt_mem_nhds hG0)
      obtain ⟨ε, hε, hball⟩ := Metric.mem_nhdsWithin_iff.mp hev
      refine lt_of_lt_of_le hε (le_csInf hSne ?_)
      intro s hs
      by_contra hc
      have hmem : s ∈ Metric.ball 0 ε ∩ I := by
        refine ⟨?_, hs.1⟩
        rw [Metric.mem_ball, Real.dist_eq, sub_zero, abs_of_nonneg (hIpos s hs.1)]
        exact not_le.mp hc
      exact absurd hs.2 (not_le.mpr (hball hmem))
    refine ⟨sInf S, hdpos, ?_, ?_⟩
    · apply strictMonoOn_of_deriv_pos (hI.inter (convex_Iic _)) (hEcont.mono inter_subset_left)
      intro x hx
      rw [interior_inter, interior_Iic] at hx
      rw [(hasDerivAt_of_interior hE hx.1).deriv]
      exact (hsignpos x).mp (hlt x (interior_subset hx.1) hx.2)
    · apply antitoneOn_of_deriv_nonpos (hI.inter (convex_Ici _)) (hEcont.mono inter_subset_left)
      · intro x hx
        rw [interior_inter] at hx
        exact (hasDerivAt_of_interior hE hx.1).differentiableAt.differentiableWithinAt
      · intro x hx
        rw [interior_inter, interior_Ici] at hx
        rw [(hasDerivAt_of_interior hE hx.1).deriv]
        exact (hsignnonpos x).mp (hgt x (interior_subset hx.1) hx.2)

/-- **P3(ii)** on the pre-ASI domain `[0, T_A)`. -/
theorem p3ii_unimodal_preASI {ι ι' E : ℝ → ℝ} {μ TA : ℝ} (hTA : 0 < TA) (hμ : 0 < μ)
    (hE : ∀ t ∈ Ico 0 TA, HasDerivWithinAt E (ι t - μ * E t) (Ico 0 TA) t)
    (hι : ∀ t ∈ Ico 0 TA, HasDerivWithinAt ι (ι' t) (Ico 0 TA) t)
    (hanti : AntitoneOn ι (Ico 0 TA)) (hE0 : E 0 < ι 0 / μ) :
    StrictMonoOn E (Ico 0 TA) ∨
      ∃ d, 0 < d ∧ StrictMonoOn E (Ico 0 TA ∩ Iic d) ∧ AntitoneOn E (Ico 0 TA ∩ Ici d) :=
  p3ii_unimodal (convex_Ico 0 TA) ⟨le_rfl, hTA⟩ (fun _ ht => ht.1) hμ hE hι hanti hE0

/-- **P3(ii)** on the untruncated horizon `[0, ∞)`. -/
theorem p3ii_unimodal_untruncated {ι ι' E : ℝ → ℝ} {μ : ℝ} (hμ : 0 < μ)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (ι t - μ * E t) (Ici 0) t)
    (hι : ∀ t ∈ Ici 0, HasDerivWithinAt ι (ι' t) (Ici 0) t)
    (hanti : AntitoneOn ι (Ici 0)) (hE0 : E 0 < ι 0 / μ) :
    StrictMonoOn E (Ici 0) ∨
      ∃ d, 0 < d ∧ StrictMonoOn E (Ici 0 ∩ Iic d) ∧ AntitoneOn E (Ici 0 ∩ Ici d) :=
  p3ii_unimodal (convex_Ici 0) (mem_Ici.mpr le_rfl) (fun _ ht => ht) hμ hE hι hanti hE0

/-! ## Constant removal: uniqueness of solutions -/

lemma hasDerivAt_exp_mul (c t : ℝ) : HasDerivAt (fun t => exp (c * t)) (exp (c * t) * c) t := by
  have h : HasDerivAt (fun t => c * t) c t := by simpa using (hasDerivAt_id t).const_mul c
  exact h.exp

lemma hasDerivAt_exp_neg_mul (c t : ℝ) :
    HasDerivAt (fun t => exp (-(c * t))) (-(c * exp (-(c * t)))) t := by
  have h : HasDerivAt (fun t => -(c * t)) (-c) t := by
    simpa [neg_mul] using (hasDerivAt_id' t).const_mul (-c)
  convert h.exp using 1; ring

/-- Two solutions of `E′ = ι − μE` (constant `μ`) on an interval `I` differ by `C·e^{−μt}`. -/
theorem ode_diff {ι E₁ E₂ : ℝ → ℝ} {μ : ℝ} {I : Set ℝ} (hI : Convex ℝ I)
    (h1 : ∀ t ∈ I, HasDerivWithinAt E₁ (ι t - μ * E₁ t) I t)
    (h2 : ∀ t ∈ I, HasDerivWithinAt E₂ (ι t - μ * E₂ t) I t) {t₀ : ℝ} (ht₀ : t₀ ∈ I) :
    ∀ t ∈ I, exp (μ * t) * (E₁ t - E₂ t) = exp (μ * t₀) * (E₁ t₀ - E₂ t₀) := by
  set F : ℝ → ℝ := fun t => exp (μ * t) * (E₁ t - E₂ t) with hF
  have hFd : ∀ t ∈ I, HasDerivWithinAt F 0 I t := by
    intro t ht
    have := ((hasDerivAt_exp_mul μ t).hasDerivWithinAt (s := I)).mul ((h1 t ht).sub (h2 t ht))
    convert this using 1; simp only [Pi.sub_apply]; ring
  have hFc := continuousOn_of_hasDerivWithinAt hFd
  have hmono : MonotoneOn F I := monotoneOn_of_deriv_nonneg hI hFc
    (fun x hx => (hasDerivAt_of_interior hFd hx).differentiableAt.differentiableWithinAt)
    (fun x hx => by simp [(hasDerivAt_of_interior hFd hx).deriv])
  have hanti : AntitoneOn F I := antitoneOn_of_deriv_nonpos hI hFc
    (fun x hx => (hasDerivAt_of_interior hFd hx).differentiableAt.differentiableWithinAt)
    (fun x hx => by simp [(hasDerivAt_of_interior hFd hx).deriv])
  intro t ht
  show F t = F t₀
  rcases le_total t t₀ with h | h
  · exact le_antisymm (hmono ht ht₀ h) (hanti ht ht₀ h)
  · exact le_antisymm (hanti ht₀ ht h) (hmono ht₀ ht h)

/-- Uniqueness: two solutions of `E′ = ι − μE` on an interval that agree at one date agree. -/
theorem ode_unique {ι E₁ E₂ : ℝ → ℝ} {μ : ℝ} {I : Set ℝ} (hI : Convex ℝ I)
    (h1 : ∀ t ∈ I, HasDerivWithinAt E₁ (ι t - μ * E₁ t) I t)
    (h2 : ∀ t ∈ I, HasDerivWithinAt E₂ (ι t - μ * E₂ t) I t) {t₀ : ℝ} (ht₀ : t₀ ∈ I)
    (heq : E₁ t₀ = E₂ t₀) : ∀ t ∈ I, E₁ t = E₂ t := by
  intro t ht
  have h := ode_diff hI h1 h2 ht₀ t ht
  rw [heq, sub_self, mul_zero] at h
  have := (mul_eq_zero.mp h).resolve_left (exp_pos _).ne'
  linarith

/-! ## P3(iii) and A.7's non-empty starting stock: the explicit path -/

/-- Residual introduction under protection spreading at rate `γ`: `ι(t) = ι₁ + (ι₀ − ι₁)e^{−γt}`. -/
noncomputable def iotaP (ι₀ ι₁ γ t : ℝ) : ℝ := ι₁ + (ι₀ - ι₁) * exp (-(γ * t))

/-- The paper's closed form for `μ ≠ γ`, from `E(0) = E₀` (`E₀ = 0` is P3(iii)). -/
noncomputable def EsolNe (μ γ ι₀ ι₁ E₀ t : ℝ) : ℝ :=
  ι₁ / μ * (1 - exp (-(μ * t))) + (ι₀ - ι₁) * (exp (-(γ * t)) - exp (-(μ * t))) / (μ - γ)
    + E₀ * exp (-(μ * t))

/-- The paper's closed form for `μ = γ`, from `E(0) = E₀`. -/
noncomputable def EsolEq (μ ι₀ ι₁ E₀ t : ℝ) : ℝ :=
  ι₁ / μ * (1 - exp (-(μ * t))) + (ι₀ - ι₁) * t * exp (-(μ * t)) + E₀ * exp (-(μ * t))

noncomputable def Esol (μ γ ι₀ ι₁ E₀ : ℝ) : ℝ → ℝ :=
  if μ = γ then EsolEq μ ι₀ ι₁ E₀ else EsolNe μ γ ι₀ ι₁ E₀

/-- The `μ ≠ γ` closed form solves `E′ = ι − μE` at every date. -/
theorem esolNe_hasDerivAt {μ γ ι₀ ι₁ E₀ : ℝ} (hμ : μ ≠ 0) (hne : μ ≠ γ) (t : ℝ) :
    HasDerivAt (EsolNe μ γ ι₀ ι₁ E₀) (iotaP ι₀ ι₁ γ t - μ * EsolNe μ γ ι₀ ι₁ E₀ t) t := by
  have hm := hasDerivAt_exp_neg_mul μ t
  have hg := hasDerivAt_exp_neg_mul γ t
  have hsub : μ - γ ≠ 0 := sub_ne_zero.mpr hne
  have h := ((((hasDerivAt_const t (1:ℝ)).sub hm).const_mul (ι₁ / μ)).add
    (((hg.sub hm).const_mul (ι₀ - ι₁)).div_const (μ - γ))).add (hm.const_mul E₀)
  exact h.congr_deriv (by simp only [iotaP, EsolNe]; field_simp; ring)

/-- The `μ = γ` closed form solves `E′ = ι − μE` at every date. -/
theorem esolEq_hasDerivAt {μ ι₀ ι₁ E₀ : ℝ} (hμ : μ ≠ 0) (t : ℝ) :
    HasDerivAt (EsolEq μ ι₀ ι₁ E₀) (iotaP ι₀ ι₁ μ t - μ * EsolEq μ ι₀ ι₁ E₀ t) t := by
  have hm := hasDerivAt_exp_neg_mul μ t
  have h := ((((hasDerivAt_const t (1:ℝ)).sub hm).const_mul (ι₁ / μ)).add
    (((hasDerivAt_id' t).const_mul (ι₀ - ι₁)).mul hm)).add (hm.const_mul E₀)
  exact h.congr_deriv (by simp only [iotaP, EsolEq]; field_simp; ring)

theorem esol_hasDerivAt {μ γ ι₀ ι₁ E₀ : ℝ} (hμ : μ ≠ 0) (t : ℝ) :
    HasDerivAt (Esol μ γ ι₀ ι₁ E₀) (iotaP ι₀ ι₁ γ t - μ * Esol μ γ ι₀ ι₁ E₀ t) t := by
  unfold Esol
  split_ifs with h
  · subst h; exact esolEq_hasDerivAt hμ t
  · exact esolNe_hasDerivAt hμ h t

theorem esol_zero (μ γ ι₀ ι₁ E₀ : ℝ) : Esol μ γ ι₀ ι₁ E₀ 0 = E₀ := by
  unfold Esol; split_ifs <;> simp [EsolEq, EsolNe]

/-- **P3(iii) / A.7, the solution**: every solution of `E′ = ι − μE` with this inflow on an
interval containing `0`, with `E(0) = E₀`, is the closed form there (both `μ ≠ γ` and `μ = γ`). -/
theorem p3iii_solution_unique {E : ℝ → ℝ} {μ γ ι₀ ι₁ E₀ : ℝ} {I : Set ℝ} (hI : Convex ℝ I)
    (h0I : (0:ℝ) ∈ I) (hμ : μ ≠ 0)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) I t) (hE0 : E 0 = E₀) :
    ∀ t ∈ I, E t = Esol μ γ ι₀ ι₁ E₀ t :=
  ode_unique hI hE (fun s _ => (esol_hasDerivAt hμ s).hasDerivWithinAt) h0I
    (by rw [hE0, esol_zero])

/-! ### The sign of `E′`: `e^{μt}E′(t)` in closed form -/

/-- `q = μ[ι₀ − (μ − γ)E₀] − γι₁` (A.7); with `E₀ = 0` it is `μι₀ − γι₁`. -/
noncomputable def qS (μ γ ι₀ ι₁ E₀ : ℝ) : ℝ := μ * (ι₀ - (μ - γ) * E₀) - γ * ι₁

/-- `e^{μt}E′(t)` for `μ ≠ γ`. -/
noncomputable def GNe (μ γ ι₀ ι₁ E₀ t : ℝ) : ℝ :=
  (qS μ γ ι₀ ι₁ E₀ - γ * (ι₀ - ι₁) * exp ((μ - γ) * t)) / (μ - γ)

/-- `e^{μt}E′(t)` for `μ = γ`. -/
def GEq (μ ι₀ ι₁ E₀ t : ℝ) : ℝ := (ι₀ - μ * E₀) - μ * (ι₀ - ι₁) * t

/-- The peak date for `μ ≠ γ`: `t̂ = ln[q/(γ(ι₀ − ι₁))]/(μ − γ)`. -/
noncomputable def tHatNe (μ γ ι₀ ι₁ E₀ : ℝ) : ℝ :=
  log (qS μ γ ι₀ ι₁ E₀ / (γ * (ι₀ - ι₁))) / (μ - γ)

/-- The peak date for `μ = γ`: `t̂ = (ι₀ − μE₀)/(μ(ι₀ − ι₁))`. -/
noncomputable def tHatEq (μ ι₀ ι₁ E₀ : ℝ) : ℝ := (ι₀ - μ * E₀) / (μ * (ι₀ - ι₁))

lemma gap_ne {μ γ ι₀ ι₁ E₀ : ℝ} (hμ : μ ≠ 0) (hne : μ ≠ γ) (t : ℝ) :
    exp (μ * t) * (iotaP ι₀ ι₁ γ t - μ * EsolNe μ γ ι₀ ι₁ E₀ t) = GNe μ γ ι₀ ι₁ E₀ t := by
  have hsub : μ - γ ≠ 0 := sub_ne_zero.mpr hne
  have e1 : exp ((μ - γ) * t) = exp (μ * t) / exp (γ * t) := by rw [← exp_sub]; ring_nf
  have ha := (exp_pos (μ * t)).ne'
  have hb := (exp_pos (γ * t)).ne'
  simp only [GNe, qS, iotaP, EsolNe, e1, exp_neg]
  field_simp
  ring

lemma gap_eq {μ ι₀ ι₁ E₀ : ℝ} (hμ : μ ≠ 0) (t : ℝ) :
    exp (μ * t) * (iotaP ι₀ ι₁ μ t - μ * EsolEq μ ι₀ ι₁ E₀ t) = GEq μ ι₀ ι₁ E₀ t := by
  have ha := (exp_pos (μ * t)).ne'
  simp only [GEq, iotaP, EsolEq, exp_neg]
  field_simp
  ring

lemma gNe_zero {μ γ ι₀ ι₁ E₀ : ℝ} (hne : μ ≠ γ) : GNe μ γ ι₀ ι₁ E₀ 0 = ι₀ - μ * E₀ := by
  have hsub : μ - γ ≠ 0 := sub_ne_zero.mpr hne
  simp only [GNe, qS, mul_zero, exp_zero, mul_one]
  field_simp
  ring

lemma gNe_strictAnti {μ γ ι₀ ι₁ E₀ : ℝ} (hne : μ ≠ γ) (hB : 0 < γ * (ι₀ - ι₁)) :
    StrictAnti (GNe μ γ ι₀ ι₁ E₀) := by
  intro s t hst
  have key : 0 < (exp ((μ - γ) * t) - exp ((μ - γ) * s)) / (μ - γ) := by
    rcases lt_or_gt_of_ne (sub_ne_zero.mpr hne) with h | h
    · apply div_pos_of_neg_of_neg _ h
      rw [sub_neg, exp_lt_exp]; nlinarith
    · apply div_pos _ h
      rw [sub_pos, exp_lt_exp]; nlinarith
  have hd : GNe μ γ ι₀ ι₁ E₀ t - GNe μ γ ι₀ ι₁ E₀ s =
      -(γ * (ι₀ - ι₁)) * ((exp ((μ - γ) * t) - exp ((μ - γ) * s)) / (μ - γ)) := by
    simp only [GNe]; ring
  have := mul_pos hB key
  linarith

lemma gNe_continuous (μ γ ι₀ ι₁ E₀ : ℝ) : Continuous (GNe μ γ ι₀ ι₁ E₀) := by
  unfold GNe; fun_prop

lemma gNe_tHat {μ γ ι₀ ι₁ E₀ : ℝ} (hne : μ ≠ γ) (hB : 0 < γ * (ι₀ - ι₁))
    (hq : 0 < qS μ γ ι₀ ι₁ E₀) : GNe μ γ ι₀ ι₁ E₀ (tHatNe μ γ ι₀ ι₁ E₀) = 0 := by
  have hsub : μ - γ ≠ 0 := sub_ne_zero.mpr hne
  have h1 : (μ - γ) * tHatNe μ γ ι₀ ι₁ E₀ = log (qS μ γ ι₀ ι₁ E₀ / (γ * (ι₀ - ι₁))) := by
    simp only [tHatNe]; field_simp
  have h2 : γ * (ι₀ - ι₁) * (qS μ γ ι₀ ι₁ E₀ / (γ * (ι₀ - ι₁))) = qS μ γ ι₀ ι₁ E₀ :=
    mul_div_cancel₀ _ hB.ne'
  simp only [GNe]
  rw [h1, exp_log (div_pos hq hB), h2, sub_self, zero_div]

lemma gEq_strictAnti {μ ι₀ ι₁ E₀ : ℝ} (hB : 0 < μ * (ι₀ - ι₁)) :
    StrictAnti (GEq μ ι₀ ι₁ E₀) := by
  intro s t hst
  simp only [GEq]
  nlinarith

lemma gEq_continuous (μ ι₀ ι₁ E₀ : ℝ) : Continuous (GEq μ ι₀ ι₁ E₀) := by
  unfold GEq; fun_prop

lemma gEq_tHat {μ ι₀ ι₁ E₀ : ℝ} (hB : 0 < μ * (ι₀ - ι₁)) :
    GEq μ ι₀ ι₁ E₀ (tHatEq μ ι₀ ι₁ E₀) = 0 := by
  simp only [GEq, tHatEq]
  rw [mul_div_cancel₀ _ hB.ne', sub_self]

/-- For a solution on `I`, `e^{μt}(ι − μE)` is the closed form `GNe` (case `μ ≠ γ`). -/
lemma gap_solution_ne {E : ℝ → ℝ} {μ γ ι₀ ι₁ E₀ : ℝ} {I : Set ℝ} (hI : Convex ℝ I)
    (h0I : (0:ℝ) ∈ I) (hμ : μ ≠ 0) (hne : μ ≠ γ)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) I t) (hE0 : E 0 = E₀) :
    ∀ t ∈ I, exp (μ * t) * (iotaP ι₀ ι₁ γ t - μ * E t) = GNe μ γ ι₀ ι₁ E₀ t := by
  intro t ht
  rw [p3iii_solution_unique hI h0I hμ hE hE0 t ht, Esol]
  simp only [hne, ↓reduceIte]
  exact gap_ne hμ hne t

/-- The same for `μ = γ`. -/
lemma gap_solution_eq {E : ℝ → ℝ} {μ ι₀ ι₁ E₀ : ℝ} {I : Set ℝ} (hI : Convex ℝ I)
    (h0I : (0:ℝ) ∈ I) (hμ : μ ≠ 0)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (iotaP ι₀ ι₁ μ t - μ * E t) I t) (hE0 : E 0 = E₀) :
    ∀ t ∈ I, exp (μ * t) * (iotaP ι₀ ι₁ μ t - μ * E t) = GEq μ ι₀ ι₁ E₀ t := by
  intro t ht
  rw [p3iii_solution_unique hI h0I hμ hE hE0 t ht, Esol]
  simp only [↓reduceIte]
  exact gap_eq hμ t

/-! ### Generic shape results, from a strictly decreasing `G = e^{μt}E′` -/

section Generic

variable {ι E G : ℝ → ℝ} {μ : ℝ} {I : Set ℝ}

lemma sign_pos_iff (hgap : ∀ t ∈ I, exp (μ * t) * (ι t - μ * E t) = G t) {t : ℝ} (ht : t ∈ I) :
    0 < ι t - μ * E t ↔ 0 < G t := by
  rw [← hgap t ht]; exact (mul_pos_iff_of_pos_left (exp_pos _)).symm

lemma sign_neg_iff (hgap : ∀ t ∈ I, exp (μ * t) * (ι t - μ * E t) = G t) {t : ℝ} (ht : t ∈ I) :
    ι t - μ * E t < 0 ↔ G t < 0 := by
  rw [← hgap t ht]
  constructor
  · intro h; exact mul_neg_of_pos_of_neg (exp_pos _) h
  · intro h; by_contra hc
    exact absurd h (not_lt.mpr (mul_nonneg (exp_pos _).le (not_lt.mp hc)))

theorem shape_of_zero (hI : Convex ℝ I)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ * E t) I t)
    (hgap : ∀ t ∈ I, exp (μ * t) * (ι t - μ * E t) = G t) (hG : StrictAnti G) {th : ℝ}
    (hth : G th = 0) : StrictMonoOn E (I ∩ Iic th) ∧ StrictAntiOn E (I ∩ Ici th) := by
  have hEc := continuousOn_of_hasDerivWithinAt hE
  constructor
  · apply strictMonoOn_of_deriv_pos (hI.inter (convex_Iic _)) (hEc.mono inter_subset_left)
    intro x hx
    rw [interior_inter, interior_Iic] at hx
    rw [(hasDerivAt_of_interior hE hx.1).deriv]
    exact (sign_pos_iff hgap (interior_subset hx.1)).mpr (hth ▸ hG hx.2)
  · apply strictAntiOn_of_deriv_neg (hI.inter (convex_Ici _)) (hEc.mono inter_subset_left)
    intro x hx
    rw [interior_inter, interior_Ici] at hx
    rw [(hasDerivAt_of_interior hE hx.1).deriv]
    exact (sign_neg_iff hgap (interior_subset hx.1)).mpr (hth ▸ hG hx.2)

theorem shape_of_pos (hI : Convex ℝ I)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ * E t) I t)
    (hgap : ∀ t ∈ I, exp (μ * t) * (ι t - μ * E t) = G t) (hpos : ∀ t ∈ I, 0 < G t) :
    StrictMonoOn E I := by
  apply strictMonoOn_of_deriv_pos hI (continuousOn_of_hasDerivWithinAt hE)
  intro x hx
  rw [(hasDerivAt_of_interior hE hx).deriv]
  exact (sign_pos_iff hgap (interior_subset hx)).mpr (hpos x (interior_subset hx))

theorem shape_of_start_nonpos (hI : Convex ℝ I) (hIpos : ∀ t ∈ I, 0 ≤ t)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ * E t) I t)
    (hgap : ∀ t ∈ I, exp (μ * t) * (ι t - μ * E t) = G t) (hG : StrictAnti G)
    (h0 : G 0 ≤ 0) : StrictAntiOn E I := by
  apply strictAntiOn_of_deriv_neg hI (continuousOn_of_hasDerivWithinAt hE)
  intro x hx
  have hx0 : 0 < x := by
    have : x ∈ interior (Ici (0:ℝ)) := interior_mono (fun t ht => hIpos t ht) hx
    rw [interior_Ici] at this; exact this
  rw [(hasDerivAt_of_interior hE hx).deriv]
  exact (sign_neg_iff hgap (interior_subset hx)).mpr (lt_of_lt_of_le (hG hx0) h0)

/-- Rises-and-falls on `I` iff `G` has a zero `t̂ > 0` with a later date of `I`. -/
theorem risesFalls_iff_zero (hI : Convex ℝ I) (h0I : (0:ℝ) ∈ I) (hIpos : ∀ t ∈ I, 0 ≤ t)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ * E t) I t)
    (hgap : ∀ t ∈ I, exp (μ * t) * (ι t - μ * E t) = G t) (hG : StrictAnti G)
    (hGc : Continuous G) :
    RisesFalls E I ↔ ∃ th, 0 < th ∧ G th = 0 ∧ ∃ c ∈ I, th < c := by
  constructor
  · intro h
    obtain ⟨t₀, t₁, h₀, h₁, h01, hup, hdown⟩ :=
      p3i_witnesses_of_risesFalls (μ := fun _ => μ) hI hE h
    have hG0 : 0 < G t₀ := (sign_pos_iff hgap h₀).mp (by linarith)
    have hG1 : G t₁ < 0 := (sign_neg_iff hgap h₁).mp (by linarith)
    obtain ⟨th, hth, hz⟩ : (0:ℝ) ∈ G '' Icc t₀ t₁ :=
      intermediate_value_Icc' h01.le hGc.continuousOn ⟨hG1.le, hG0.le⟩
    have hne0 : th ≠ t₀ := by rintro rfl; linarith
    have hne1 : th ≠ t₁ := by rintro rfl; linarith
    exact ⟨th, lt_of_le_of_lt (hIpos t₀ h₀) (lt_of_le_of_ne hth.1 (Ne.symm hne0)), hz,
      t₁, h₁, lt_of_le_of_ne hth.2 hne1⟩
  · rintro ⟨th, hth, hz, c, hc, htc⟩
    have hthI : th ∈ I := Icc_subset_of_convex hI h0I hc ⟨hth.le, htc.le⟩
    obtain ⟨hmono, hanti⟩ := shape_of_zero hI hE hgap hG hz
    exact ⟨0, th, c, h0I, hthI, hc, hth, htc,
      hmono ⟨h0I, mem_Iic.mpr hth.le⟩ ⟨hthI, mem_Iic.mpr le_rfl⟩ hth,
      hanti ⟨hthI, mem_Ici.mpr le_rfl⟩ ⟨hc, htc.le⟩ htc⟩

/-- At a zero `t̂ ∈ I` of `G`, `t̂` is the unique maximizer of `E` on `I`. -/
theorem unique_max_of_zero (hI : Convex ℝ I)
    (hE : ∀ t ∈ I, HasDerivWithinAt E (ι t - μ * E t) I t)
    (hgap : ∀ t ∈ I, exp (μ * t) * (ι t - μ * E t) = G t) (hG : StrictAnti G) {th : ℝ}
    (hthI : th ∈ I) (hz : G th = 0) : ∀ t ∈ I, t ≠ th → E t < E th := by
  obtain ⟨hmono, hanti⟩ := shape_of_zero hI hE hgap hG hz
  intro t ht hne
  rcases lt_or_gt_of_ne hne with h | h
  · exact hmono ⟨ht, h.le⟩ ⟨hthI, mem_Iic.mpr le_rfl⟩ h
  · exact hanti ⟨hthI, mem_Ici.mpr le_rfl⟩ ⟨ht, h.le⟩ h

end Generic

/-! ### Zeros of the closed-form `G` -/

lemma qS_sub {μ γ ι₀ ι₁ E₀ : ℝ} :
    qS μ γ ι₀ ι₁ E₀ - γ * (ι₀ - ι₁) = (μ - γ) * (ι₀ - μ * E₀) := by
  simp only [qS]; ring

lemma gNe_pos_zero_iff {μ γ ι₀ ι₁ E₀ : ℝ} (hne : μ ≠ γ) (hB : 0 < γ * (ι₀ - ι₁)) :
    (∃ th, 0 < th ∧ GNe μ γ ι₀ ι₁ E₀ th = 0) ↔ μ * E₀ < ι₀ ∧ 0 < qS μ γ ι₀ ι₁ E₀ := by
  have hG := gNe_strictAnti (E₀ := E₀) hne hB
  have hsub : μ - γ ≠ 0 := sub_ne_zero.mpr hne
  constructor
  · rintro ⟨th, hth, hz⟩
    refine ⟨?_, ?_⟩
    · have := hG hth; rw [hz, gNe_zero hne] at this; linarith
    · have hz' : qS μ γ ι₀ ι₁ E₀ - γ * (ι₀ - ι₁) * exp ((μ - γ) * th) = 0 := by
        simp only [GNe] at hz
        rcases div_eq_zero_iff.mp hz with h | h
        · exact h
        · exact absurd h hsub
      have := mul_pos hB (exp_pos ((μ - γ) * th))
      linarith
  · rintro ⟨h1, h2⟩
    refine ⟨tHatNe μ γ ι₀ ι₁ E₀, ?_, gNe_tHat hne hB h2⟩
    by_contra hc
    have := hG.antitone (not_lt.mp hc)
    rw [gNe_tHat hne hB h2, gNe_zero hne] at this
    linarith

lemma gNe_pos_of_no_zero {μ γ ι₀ ι₁ E₀ : ℝ} (hne : μ ≠ γ) (hB : 0 < γ * (ι₀ - ι₁))
    (h1 : μ * E₀ < ι₀) (h2 : qS μ γ ι₀ ι₁ E₀ ≤ 0) : ∀ t, 0 < GNe μ γ ι₀ ι₁ E₀ t := by
  have hlt : μ < γ := by
    by_contra hc
    have hgt : γ < μ := lt_of_le_of_ne (not_lt.mp hc) (Ne.symm hne)
    have := mul_pos (sub_pos.mpr hgt) (sub_pos.mpr h1)
    have := (qS_sub (μ := μ) (γ := γ) (ι₀ := ι₀) (ι₁ := ι₁) (E₀ := E₀))
    linarith
  intro t
  simp only [GNe]
  apply div_pos_of_neg_of_neg _ (by linarith)
  have := mul_pos hB (exp_pos ((μ - γ) * t))
  linarith

lemma gEq_pos_zero_iff {μ ι₀ ι₁ E₀ : ℝ} (hB : 0 < μ * (ι₀ - ι₁)) :
    (∃ th, 0 < th ∧ GEq μ ι₀ ι₁ E₀ th = 0) ↔ μ * E₀ < ι₀ := by
  constructor
  · rintro ⟨th, hth, hz⟩
    simp only [GEq] at hz
    nlinarith
  · intro h
    exact ⟨tHatEq μ ι₀ ι₁ E₀, div_pos (by linarith) hB, gEq_tHat hB⟩

/-! ### A.7, a non-empty starting stock `E(0) = E₀` (P3(iii) is `E₀ = 0`) -/

section Stock

variable {E : ℝ → ℝ} {φ μ γ ι₀ ι₁ E₀ : ℝ}

/-- **A.7 non-empty stock, `μ ≠ γ`**: on the continued trajectory `t ≥ 0`, the hazard rises
and later falls iff `μE₀ < ι₀` and `q > 0`. -/
theorem a7_stock_ne_peak_iff (hφ : 0 < φ) (hμ : 0 < μ) (hγ : 0 < γ) (hι : ι₁ < ι₀)
    (hne : μ ≠ γ)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = E₀) :
    RisesFalls (fun t => φ * E t) (Ici 0) ↔ μ * E₀ < ι₀ ∧ 0 < qS μ γ ι₀ ι₁ E₀ := by
  have hB : 0 < γ * (ι₀ - ι₁) := mul_pos hγ (sub_pos.mpr hι)
  have h0I : (0:ℝ) ∈ Ici 0 := mem_Ici.mpr le_rfl
  rw [risesFalls_const_mul hφ, risesFalls_iff_zero (convex_Ici 0) h0I (fun _ h => h) hE
    (gap_solution_ne (convex_Ici 0) h0I hμ.ne' hne hE hE0) (gNe_strictAnti hne hB)
    (gNe_continuous _ _ _ _ _), ← gNe_pos_zero_iff hne hB]
  constructor
  · rintro ⟨th, h1, h2, -⟩; exact ⟨th, h1, h2⟩
  · rintro ⟨th, h1, h2⟩; exact ⟨th, h1, h2, th + 1, mem_Ici.mpr (by linarith), by linarith⟩

/-- **A.7 non-empty stock, `μ ≠ γ`**: the peak is at `t̂ = ln[q/(γ(ι₀ − ι₁))]/(μ − γ) > 0`, the
unique maximizer of `E` on `t ≥ 0`; `E` rises strictly before it and falls strictly after. -/
theorem a7_stock_ne_peak_date (hμ : 0 < μ) (hγ : 0 < γ) (hι : ι₁ < ι₀) (hne : μ ≠ γ)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = E₀) (h1 : μ * E₀ < ι₀) (h2 : 0 < qS μ γ ι₀ ι₁ E₀) :
    0 < tHatNe μ γ ι₀ ι₁ E₀ ∧
      (∀ t ∈ Ici 0, t ≠ tHatNe μ γ ι₀ ι₁ E₀ → E t < E (tHatNe μ γ ι₀ ι₁ E₀)) ∧
      StrictMonoOn E (Icc 0 (tHatNe μ γ ι₀ ι₁ E₀)) ∧
      StrictAntiOn E (Ici (tHatNe μ γ ι₀ ι₁ E₀)) := by
  have hB : 0 < γ * (ι₀ - ι₁) := mul_pos hγ (sub_pos.mpr hι)
  have h0I : (0:ℝ) ∈ Ici 0 := mem_Ici.mpr le_rfl
  have hgap := gap_solution_ne (convex_Ici 0) h0I hμ.ne' hne hE hE0
  have hG := gNe_strictAnti (E₀ := E₀) hne hB
  have hz := gNe_tHat hne hB h2
  have hpos : 0 < tHatNe μ γ ι₀ ι₁ E₀ := by
    obtain ⟨th, hth, hzth⟩ := (gNe_pos_zero_iff hne hB).mpr ⟨h1, h2⟩
    rw [hG.injective (hzth.trans hz.symm)] at hth; exact hth
  obtain ⟨hmono, hanti⟩ := shape_of_zero (convex_Ici 0) hE hgap hG hz
  refine ⟨hpos, unique_max_of_zero (convex_Ici 0) hE hgap hG (mem_Ici.mpr hpos.le) hz, ?_, ?_⟩
  · rwa [Ici_inter_Iic] at hmono
  · rwa [Ici_inter_Ici, sup_of_le_right hpos.le] at hanti

/-- **A.7 non-empty stock, `μ ≠ γ`, pre-ASI**: on `[0, T_A)` the hazard rises and later falls iff
the peak conditions hold and `t̂ < T_A`. -/
theorem a7_stock_ne_preASI_iff {TA : ℝ} (hφ : 0 < φ) (hTA : 0 < TA) (hμ : 0 < μ) (hγ : 0 < γ)
    (hι : ι₁ < ι₀) (hne : μ ≠ γ)
    (hE : ∀ t ∈ Ico 0 TA, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ico 0 TA) t)
    (hE0 : E 0 = E₀) :
    RisesFalls (fun t => φ * E t) (Ico 0 TA) ↔
      μ * E₀ < ι₀ ∧ 0 < qS μ γ ι₀ ι₁ E₀ ∧ tHatNe μ γ ι₀ ι₁ E₀ < TA := by
  have hB : 0 < γ * (ι₀ - ι₁) := mul_pos hγ (sub_pos.mpr hι)
  have h0I : (0:ℝ) ∈ Ico 0 TA := ⟨le_rfl, hTA⟩
  have hG := gNe_strictAnti (E₀ := E₀) hne hB
  rw [risesFalls_const_mul hφ, risesFalls_iff_zero (convex_Ico 0 TA) h0I (fun _ h => h.1) hE
    (gap_solution_ne (convex_Ico 0 TA) h0I hμ.ne' hne hE hE0) hG (gNe_continuous _ _ _ _ _)]
  constructor
  · rintro ⟨th, h1, h2, c, hc, htc⟩
    obtain ⟨hA, hq⟩ := (gNe_pos_zero_iff hne hB).mp ⟨th, h1, h2⟩
    have heq : th = tHatNe μ γ ι₀ ι₁ E₀ := hG.injective (h2.trans (gNe_tHat hne hB hq).symm)
    exact ⟨hA, hq, by rw [← heq]; exact htc.trans hc.2⟩
  · rintro ⟨hA, hq, hT⟩
    obtain ⟨th, h1, h2⟩ := (gNe_pos_zero_iff hne hB).mpr ⟨hA, hq⟩
    have heq : th = tHatNe μ γ ι₀ ι₁ E₀ := hG.injective (h2.trans (gNe_tHat hne hB hq).symm)
    rw [heq] at h1 h2
    exact ⟨_, h1, h2, (tHatNe μ γ ι₀ ι₁ E₀ + TA) / 2, ⟨by linarith, by linarith⟩, by linarith⟩

/-- **A.7 non-empty stock, `μ = γ`**: a future peak exists iff `μE₀ < ι₀`. -/
theorem a7_stock_eq_peak_iff (hφ : 0 < φ) (hμ : 0 < μ) (hι : ι₁ < ι₀)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ μ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = E₀) :
    RisesFalls (fun t => φ * E t) (Ici 0) ↔ μ * E₀ < ι₀ := by
  have hB : 0 < μ * (ι₀ - ι₁) := mul_pos hμ (sub_pos.mpr hι)
  have h0I : (0:ℝ) ∈ Ici 0 := mem_Ici.mpr le_rfl
  rw [risesFalls_const_mul hφ, risesFalls_iff_zero (convex_Ici 0) h0I (fun _ h => h) hE
    (gap_solution_eq (convex_Ici 0) h0I hμ.ne' hE hE0) (gEq_strictAnti hB)
    (gEq_continuous _ _ _ _), ← gEq_pos_zero_iff hB]
  constructor
  · rintro ⟨th, h1, h2, -⟩; exact ⟨th, h1, h2⟩
  · rintro ⟨th, h1, h2⟩; exact ⟨th, h1, h2, th + 1, mem_Ici.mpr (by linarith), by linarith⟩

/-- **A.7 non-empty stock, `μ = γ`**: the peak is at `t̂ = (ι₀ − μE₀)/(μ(ι₀ − ι₁))`, the unique
maximizer on `t ≥ 0`. -/
theorem a7_stock_eq_peak_date (hμ : 0 < μ) (hι : ι₁ < ι₀)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ μ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = E₀) (h1 : μ * E₀ < ι₀) :
    0 < tHatEq μ ι₀ ι₁ E₀ ∧
      (∀ t ∈ Ici 0, t ≠ tHatEq μ ι₀ ι₁ E₀ → E t < E (tHatEq μ ι₀ ι₁ E₀)) ∧
      StrictMonoOn E (Icc 0 (tHatEq μ ι₀ ι₁ E₀)) ∧ StrictAntiOn E (Ici (tHatEq μ ι₀ ι₁ E₀)) := by
  have hB : 0 < μ * (ι₀ - ι₁) := mul_pos hμ (sub_pos.mpr hι)
  have h0I : (0:ℝ) ∈ Ici 0 := mem_Ici.mpr le_rfl
  have hgap := gap_solution_eq (convex_Ici 0) h0I hμ.ne' hE hE0
  have hG := gEq_strictAnti (E₀ := E₀) hB
  have hz := gEq_tHat (E₀ := E₀) hB
  have hpos : 0 < tHatEq μ ι₀ ι₁ E₀ := div_pos (by linarith) hB
  obtain ⟨hmono, hanti⟩ := shape_of_zero (convex_Ici 0) hE hgap hG hz
  refine ⟨hpos, unique_max_of_zero (convex_Ici 0) hE hgap hG (mem_Ici.mpr hpos.le) hz, ?_, ?_⟩
  · rwa [Ici_inter_Iic] at hmono
  · rwa [Ici_inter_Ici, sup_of_le_right hpos.le] at hanti

/-- **A.7 non-empty stock, `μ = γ`, pre-ASI**. -/
theorem a7_stock_eq_preASI_iff {TA : ℝ} (hφ : 0 < φ) (hTA : 0 < TA) (hμ : 0 < μ)
    (hι : ι₁ < ι₀)
    (hE : ∀ t ∈ Ico 0 TA, HasDerivWithinAt E (iotaP ι₀ ι₁ μ t - μ * E t) (Ico 0 TA) t)
    (hE0 : E 0 = E₀) :
    RisesFalls (fun t => φ * E t) (Ico 0 TA) ↔ μ * E₀ < ι₀ ∧ tHatEq μ ι₀ ι₁ E₀ < TA := by
  have hB : 0 < μ * (ι₀ - ι₁) := mul_pos hμ (sub_pos.mpr hι)
  have h0I : (0:ℝ) ∈ Ico 0 TA := ⟨le_rfl, hTA⟩
  have hG := gEq_strictAnti (E₀ := E₀) hB
  rw [risesFalls_const_mul hφ, risesFalls_iff_zero (convex_Ico 0 TA) h0I (fun _ h => h.1) hE
    (gap_solution_eq (convex_Ico 0 TA) h0I hμ.ne' hE hE0) hG (gEq_continuous _ _ _ _)]
  constructor
  · rintro ⟨th, h1, h2, c, hc, htc⟩
    have heq : th = tHatEq μ ι₀ ι₁ E₀ := hG.injective (h2.trans (gEq_tHat hB).symm)
    exact ⟨(gEq_pos_zero_iff hB).mp ⟨th, h1, h2⟩, by rw [← heq]; exact htc.trans hc.2⟩
  · rintro ⟨hA, hT⟩
    have hpos : 0 < tHatEq μ ι₀ ι₁ E₀ := div_pos (by linarith) hB
    exact ⟨_, hpos, gEq_tHat hB, (tHatEq μ ι₀ ι₁ E₀ + TA) / 2, ⟨by linarith, by linarith⟩,
      by linarith⟩

/-- **A.7**: "If today's stock already exceeds `ι₀/μ`, no peak lies ahead" — proved for
`E₀ ≥ ι₀/μ`: the stock then falls strictly for all `t ≥ 0`. -/
theorem a7_stock_no_peak_ahead (hφ : 0 < φ) (hμ : 0 < μ) (hγ : 0 < γ) (hι : ι₁ < ι₀)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = E₀) (hbig : ι₀ / μ ≤ E₀) :
    StrictAntiOn E (Ici 0) ∧ ¬ RisesFalls (fun t => φ * E t) (Ici 0) := by
  have h0I : (0:ℝ) ∈ Ici 0 := mem_Ici.mpr le_rfl
  have hle : ι₀ - μ * E₀ ≤ 0 := by
    have := (div_le_iff₀ hμ).mp hbig; linarith
  have hanti : StrictAntiOn E (Ici 0) := by
    by_cases hne : μ = γ
    · subst hne
      exact shape_of_start_nonpos (convex_Ici 0) (fun _ h => h) hE
        (gap_solution_eq (convex_Ici 0) h0I hμ.ne' hE hE0)
        (gEq_strictAnti (mul_pos hμ (sub_pos.mpr hι))) (by simp [GEq, hle])
    · exact shape_of_start_nonpos (convex_Ici 0) (fun _ h => h) hE
        (gap_solution_ne (convex_Ici 0) h0I hμ.ne' hne hE hE0)
        (gNe_strictAnti hne (mul_pos hγ (sub_pos.mpr hι))) (by rw [gNe_zero hne]; exact hle)
  exact ⟨hanti, by rw [risesFalls_const_mul hφ]; exact not_risesFalls_of_strictAntiOn hanti⟩

end Stock

/-! ### The plateau -/

lemma tendsto_exp_neg_mul {c : ℝ} (hc : 0 < c) :
    Tendsto (fun t => exp (-(c * t))) atTop (𝓝 0) :=
  Real.tendsto_exp_neg_atTop_nhds_zero.comp (tendsto_id.const_mul_atTop hc)

lemma tendsto_mul_exp_neg_mul {c : ℝ} (hc : 0 < c) :
    Tendsto (fun t => t * exp (-(c * t))) atTop (𝓝 0) := by
  have h := ((tendsto_pow_mul_exp_neg_atTop_nhds_zero 1).comp
    (tendsto_id.const_mul_atTop hc)).const_mul (1 / c)
  rw [mul_zero] at h
  refine h.congr (fun t => ?_)
  simp only [Function.comp_apply, id, pow_one]
  field_simp

lemma iotaP_tendsto {ι₀ ι₁ γ : ℝ} (hγ : 0 < γ) :
    Tendsto (iotaP ι₀ ι₁ γ) atTop (𝓝 ι₁) := by
  have h := (tendsto_const_nhds (x := ι₁)).add
    ((tendsto_const_nhds (x := ι₀ - ι₁)).mul (tendsto_exp_neg_mul hγ))
  rw [mul_zero, add_zero] at h
  exact h

lemma esol_tendsto {μ γ ι₀ ι₁ E₀ : ℝ} (hμ : 0 < μ) (hγ : 0 < γ) :
    Tendsto (Esol μ γ ι₀ ι₁ E₀) atTop (𝓝 (ι₁ / μ)) := by
  have hm := tendsto_exp_neg_mul hμ
  unfold Esol
  split_ifs with h
  · have h' := (((tendsto_const_nhds (x := ι₁ / μ)).mul ((tendsto_const_nhds (x := (1:ℝ))).sub hm)).add
      ((tendsto_const_nhds (x := ι₀ - ι₁)).mul (tendsto_mul_exp_neg_mul hμ))).add
      ((tendsto_const_nhds (x := E₀)).mul hm)
    rw [show ι₁ / μ * (1 - 0) + (ι₀ - ι₁) * 0 + E₀ * 0 = ι₁ / μ by ring] at h'
    refine h'.congr (fun t => ?_)
    simp only [EsolEq]; ring
  · have hg := tendsto_exp_neg_mul hγ
    have h' := (((tendsto_const_nhds (x := ι₁ / μ)).mul ((tendsto_const_nhds (x := (1:ℝ))).sub hm)).add
      (((tendsto_const_nhds (x := ι₀ - ι₁)).mul (hg.sub hm)).div_const (μ - γ))).add
      ((tendsto_const_nhds (x := E₀)).mul hm)
    rw [show ι₁ / μ * (1 - 0) + (ι₀ - ι₁) * (0 - 0) / (μ - γ) + E₀ * 0 = ι₁ / μ by ring] at h'
    exact h'

/-- **P3(iii) / A.7, the plateau**: from any starting stock, the untruncated hazard tends to
`φι₁/μ`, whatever `γ` and `ι₀`. -/
theorem p3iii_plateau {E : ℝ → ℝ} {φ μ γ ι₀ ι₁ E₀ : ℝ} (hμ : 0 < μ) (hγ : 0 < γ)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = E₀) :
    Tendsto (fun t => φ * E t) atTop (𝓝 (φ * ι₁ / μ)) := by
  have hu := p3iii_solution_unique (convex_Ici 0) (mem_Ici.mpr le_rfl) hμ.ne' hE hE0
  have hEl : Tendsto E atTop (𝓝 (ι₁ / μ)) :=
    (esol_tendsto hμ hγ).congr' (eventually_atTop.2 ⟨0, fun t ht => (hu t ht).symm⟩)
  rw [mul_div_assoc]
  exact hEl.const_mul φ

lemma limit_lt_of_strictAntiOn {E : ℝ → ℝ} {L a : ℝ} (ha : StrictAntiOn E (Ici a))
    (hl : Tendsto E atTop (𝓝 L)) : L < E a := by
  have h1 : E (a + 1) < E a := ha (mem_Ici.mpr le_rfl) (mem_Ici.mpr (by linarith)) (by linarith)
  have h2 : L ≤ E (a + 1) := le_of_tendsto hl (eventually_atTop.2 ⟨a + 1, fun s hs =>
    ha.antitoneOn (mem_Ici.mpr (by linarith)) (mem_Ici.mpr (by linarith)) hs⟩)
  linarith

lemma lt_of_strictMonoOn_tendsto {E : ℝ → ℝ} {L : ℝ} (hm : StrictMonoOn E (Ici 0))
    (hl : Tendsto E atTop (𝓝 L)) : ∀ t ∈ Ici (0:ℝ), E t < L := by
  intro t ht
  have ht0 : (0:ℝ) ≤ t := ht
  have h1 : E t < E (t + 1) := hm ht (mem_Ici.mpr (by linarith)) (by linarith)
  have h2 : E (t + 1) ≤ L := ge_of_tendsto hl (eventually_atTop.2 ⟨t + 1, fun s hs =>
    hm.monotoneOn (mem_Ici.mpr (by linarith)) (mem_Ici.mpr (by linarith)) hs⟩)
  linarith

/-! ## P3(iii) proper: the empty starting stock `E(0) = 0` -/

section Empty

variable {E : ℝ → ℝ} {φ μ γ ι₀ ι₁ : ℝ}

lemma qS_zero : qS μ γ ι₀ ι₁ 0 = μ * ι₀ - γ * ι₁ := by simp [qS]

/-- The paper's peak date for `μ ≠ γ`. -/
lemma tHatNe_zero :
    tHatNe μ γ ι₀ ι₁ 0 = log ((μ * ι₀ - γ * ι₁) / (γ * (ι₀ - ι₁))) / (μ - γ) := by
  simp [tHatNe, qS]

/-- The paper's peak date for `μ = γ`. -/
lemma tHatEq_zero : tHatEq μ ι₀ ι₁ 0 = ι₀ / (μ * (ι₀ - ι₁)) := by simp [tHatEq]

/-- **P3(iii), the peak criterion** on the continued trajectory `t ≥ 0`: with `μ, γ > 0`,
`ι₀ > ι₁ ≥ 0` and `E(0) = 0`, the hazard rises and later falls iff `μι₀ > γι₁`. -/
theorem p3iii_peak_iff (hφ : 0 < φ) (hμ : 0 < μ) (hγ : 0 < γ) (h1 : 0 ≤ ι₁) (hι : ι₁ < ι₀)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    RisesFalls (fun t => φ * E t) (Ici 0) ↔ γ * ι₁ < μ * ι₀ := by
  have hι0 : 0 < ι₀ := by linarith
  by_cases hne : μ = γ
  · subst hne
    rw [a7_stock_eq_peak_iff hφ hμ hι hE hE0, mul_zero]
    constructor
    · intro _; exact mul_lt_mul_of_pos_left hι hμ
    · intro _; exact hι0
  · rw [a7_stock_ne_peak_iff hφ hμ hγ hι hne hE hE0, qS_zero, mul_zero]
    constructor
    · rintro ⟨-, h⟩; linarith
    · intro h; exact ⟨hι0, by linarith⟩

/-- **P3(iii), `μ ≠ γ`**: under `μι₀ > γι₁` the peak is at
`t̂ = ln[(μι₀ − γι₁)/(γ(ι₀ − ι₁))]/(μ − γ) > 0` (see `tHatNe_zero`), the unique maximizer of `E`
on `t ≥ 0`, with a strict rise before and a strict fall after. -/
theorem p3iii_peak_date_ne (hμ : 0 < μ) (hγ : 0 < γ) (hι : ι₁ < ι₀) (hne : μ ≠ γ)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) (hcrit : γ * ι₁ < μ * ι₀) (h1 : 0 ≤ ι₁) :
    0 < tHatNe μ γ ι₀ ι₁ 0 ∧
      (∀ t ∈ Ici 0, t ≠ tHatNe μ γ ι₀ ι₁ 0 → E t < E (tHatNe μ γ ι₀ ι₁ 0)) ∧
      StrictMonoOn E (Icc 0 (tHatNe μ γ ι₀ ι₁ 0)) ∧ StrictAntiOn E (Ici (tHatNe μ γ ι₀ ι₁ 0)) :=
  a7_stock_ne_peak_date hμ hγ hι hne hE hE0 (by rw [mul_zero]; linarith)
    (by rw [qS_zero]; linarith)

/-- **P3(iii), `μ = γ`**: the peak is at `t̂ = ι₀/(μ(ι₀ − ι₁))` (see `tHatEq_zero`). -/
theorem p3iii_peak_date_eq (hμ : 0 < μ) (hι : ι₁ < ι₀) (h1 : 0 ≤ ι₁)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ μ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    0 < tHatEq μ ι₀ ι₁ 0 ∧
      (∀ t ∈ Ici 0, t ≠ tHatEq μ ι₀ ι₁ 0 → E t < E (tHatEq μ ι₀ ι₁ 0)) ∧
      StrictMonoOn E (Icc 0 (tHatEq μ ι₀ ι₁ 0)) ∧ StrictAntiOn E (Ici (tHatEq μ ι₀ ι₁ 0)) :=
  a7_stock_eq_peak_date hμ hι hE hE0 (by rw [mul_zero]; linarith)

/-- **P3(iii), "an intermediate pre-ASI peak if `t̂ < T_A`"** (`μ ≠ γ`), proved as an iff for the
path on `[0, T_A)`. -/
theorem p3iii_preASI_iff_ne {TA : ℝ} (hφ : 0 < φ) (hTA : 0 < TA) (hμ : 0 < μ) (hγ : 0 < γ)
    (h1 : 0 ≤ ι₁) (hι : ι₁ < ι₀) (hne : μ ≠ γ)
    (hE : ∀ t ∈ Ico 0 TA, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ico 0 TA) t)
    (hE0 : E 0 = 0) :
    RisesFalls (fun t => φ * E t) (Ico 0 TA) ↔ γ * ι₁ < μ * ι₀ ∧ tHatNe μ γ ι₀ ι₁ 0 < TA := by
  rw [a7_stock_ne_preASI_iff hφ hTA hμ hγ hι hne hE hE0, qS_zero, mul_zero]
  constructor
  · rintro ⟨-, h, hT⟩; exact ⟨by linarith, hT⟩
  · rintro ⟨h, hT⟩; exact ⟨by linarith, by linarith, hT⟩

/-- The same for `μ = γ` (the criterion holds automatically). -/
theorem p3iii_preASI_iff_eq {TA : ℝ} (hφ : 0 < φ) (hTA : 0 < TA) (hμ : 0 < μ) (h1 : 0 ≤ ι₁)
    (hι : ι₁ < ι₀)
    (hE : ∀ t ∈ Ico 0 TA, HasDerivWithinAt E (iotaP ι₀ ι₁ μ t - μ * E t) (Ico 0 TA) t)
    (hE0 : E 0 = 0) :
    RisesFalls (fun t => φ * E t) (Ico 0 TA) ↔ tHatEq μ ι₀ ι₁ 0 < TA := by
  rw [a7_stock_eq_preASI_iff hφ hTA hμ hι hE hE0, mul_zero]
  exact ⟨fun h => h.2, fun h => ⟨by linarith, h⟩⟩

/-- **P3(iii), no peak**: if `μι₀ ≤ γι₁` the stock rises strictly on `t ≥ 0` and stays below the
plateau `ι₁/μ` (a monotone rise, no overshoot). -/
theorem p3iii_no_peak_monotone (hμ : 0 < μ) (hγ : 0 < γ) (h1 : 0 ≤ ι₁) (hι : ι₁ < ι₀)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) (hno : μ * ι₀ ≤ γ * ι₁) :
    StrictMonoOn E (Ici 0) ∧ ∀ t ∈ Ici 0, E t < ι₁ / μ := by
  have hι0 : 0 < ι₀ := by linarith
  have hne : μ ≠ γ := by
    rintro rfl; nlinarith
  have hB : 0 < γ * (ι₀ - ι₁) := mul_pos hγ (sub_pos.mpr hι)
  have h0I : (0:ℝ) ∈ Ici 0 := mem_Ici.mpr le_rfl
  have hpos := gNe_pos_of_no_zero (E₀ := 0) hne hB (by rw [mul_zero]; exact hι0)
    (by rw [qS_zero]; linarith)
  have hm := shape_of_pos (convex_Ici 0) hE (gap_solution_ne (convex_Ici 0) h0I hμ.ne' hne hE hE0)
    (fun t _ => hpos t)
  have hl := p3iii_plateau (φ := 1) hμ hγ hE hE0
  simp only [one_mul] at hl
  exact ⟨hm, lt_of_strictMonoOn_tendsto hm hl⟩

/-- **P3 policy reading**: full protection (`ι₁ = 0`) always gives a peak. -/
theorem p3iii_full_protection_peak (hφ : 0 < φ) (hμ : 0 < μ) (hγ : 0 < γ) (hι0 : 0 < ι₀)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ 0 γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) : RisesFalls (fun t => φ * E t) (Ici 0) :=
  (p3iii_peak_iff hφ hμ hγ le_rfl hι0 hE hE0).mpr (by rw [mul_zero]; exact mul_pos hμ hι0)

/-- **P3, plain terms**: "a peak is guaranteed when protection spreads more slowly than removal
works" (`γ ≤ μ`). -/
theorem p3iii_slow_protection_peak (hφ : 0 < φ) (hμ : 0 < μ) (hγ : 0 < γ) (h1 : 0 ≤ ι₁)
    (hι : ι₁ < ι₀) (hγμ : γ ≤ μ)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) : RisesFalls (fun t => φ * E t) (Ici 0) :=
  (p3iii_peak_iff hφ hμ hγ h1 hι hE hE0).mpr (by nlinarith)

/-- **P3 policy reading**: with a residue `ι₁ > 0`, fast enough protection (`γ ≥ μι₀/ι₁`) removes
the peak, leaving a monotone rise to the same plateau `φι₁/μ`, with no overshoot. -/
theorem p3iii_fast_protection_removes_peak (hφ : 0 < φ) (hμ : 0 < μ) (hγ : 0 < γ)
    (h1 : 0 < ι₁) (hι : ι₁ < ι₀) (hfast : μ * ι₀ / ι₁ ≤ γ)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    ¬ RisesFalls (fun t => φ * E t) (Ici 0) ∧ StrictMonoOn E (Ici 0) ∧
      (∀ t ∈ Ici 0, E t < ι₁ / μ) ∧ Tendsto (fun t => φ * E t) atTop (𝓝 (φ * ι₁ / μ)) := by
  have hno : μ * ι₀ ≤ γ * ι₁ := by
    have := (div_le_iff₀ h1).mp hfast; linarith
  refine ⟨?_, (p3iii_no_peak_monotone hμ hγ h1.le hι hE hE0 hno).1,
    (p3iii_no_peak_monotone hμ hγ h1.le hι hE hE0 hno).2, p3iii_plateau hμ hγ hE hE0⟩
  rw [p3iii_peak_iff hφ hμ hγ h1.le hι hE hE0]
  exact not_lt.mpr hno

/-- **P3, "peak and plateau are not alternatives"**: in (iii), for every `ι₁ ≥ 0`, under the
criterion the hazard peaks and then tends to the plateau `φι₁/μ`; the plateau is positive iff a
residue remains (`ι₁ > 0`), and it is zero under full protection. -/
theorem p3iii_peak_then_plateau (hφ : 0 < φ) (hμ : 0 < μ) (hγ : 0 < γ) (h1 : 0 ≤ ι₁)
    (hι : ι₁ < ι₀) (hcrit : γ * ι₁ < μ * ι₀)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    RisesFalls (fun t => φ * E t) (Ici 0) ∧
      Tendsto (fun t => φ * E t) atTop (𝓝 (φ * ι₁ / μ)) ∧ (0 < ι₁ → 0 < φ * ι₁ / μ) :=
  ⟨(p3iii_peak_iff hφ hμ hγ h1 hι hE hE0).mpr hcrit, p3iii_plateau hμ hγ hE hE0,
    fun h => div_pos (mul_pos hφ h) hμ⟩

/-- **Line 276, "a peak is followed by a lower plateau"** (`μ ≠ γ`): the plateau `φι₁/μ` lies
strictly below the peak height `φE(t̂)`. -/
theorem p3iii_peak_above_plateau_ne (hφ : 0 < φ) (hμ : 0 < μ) (hγ : 0 < γ) (hι : ι₁ < ι₀)
    (hne : μ ≠ γ)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) (hcrit : γ * ι₁ < μ * ι₀) (h1 : 0 ≤ ι₁) :
    φ * ι₁ / μ < φ * E (tHatNe μ γ ι₀ ι₁ 0) := by
  obtain ⟨-, -, -, hanti⟩ := p3iii_peak_date_ne hμ hγ hι hne hE hE0 hcrit h1
  exact limit_lt_of_strictAntiOn (E := fun t => φ * E t)
    (fun x hx y hy hxy => mul_lt_mul_of_pos_left (hanti hx hy hxy) hφ)
    (p3iii_plateau hμ hγ hE hE0)

/-- The same for `μ = γ`. -/
theorem p3iii_peak_above_plateau_eq (hφ : 0 < φ) (hμ : 0 < μ) (hι : ι₁ < ι₀) (h1 : 0 ≤ ι₁)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ μ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    φ * ι₁ / μ < φ * E (tHatEq μ ι₀ ι₁ 0) := by
  obtain ⟨-, -, -, hanti⟩ := p3iii_peak_date_eq hμ hι h1 hE hE0
  exact limit_lt_of_strictAntiOn (E := fun t => φ * E t)
    (fun x hx y hy hxy => mul_lt_mul_of_pos_left (hanti hx hy hxy) hφ)
    (p3iii_plateau hμ hμ hE hE0)

/-- **Non-vacuity of P3(iii)**: `μ = γ = φ = ι₀ = 1`, `ι₁ = 0`, `E(t) = te^{−t}` satisfies the
hypotheses from `E(0) = 0`, with its unique maximizer at `t̂ = 1`; with `Q = 1` the same path
also solves the triage-capped equation. -/
theorem p3iii_witness :
    (∀ t ∈ Ici (0:ℝ), HasDerivWithinAt (fun s => s * exp (-s))
        (iotaP 1 0 1 t - 1 * (t * exp (-t))) (Ici 0) t) ∧
      (∀ t ∈ Ici (0:ℝ), HasDerivWithinAt (fun s => s * exp (-s))
        (iotaP 1 0 1 t - min (1 * (t * exp (-t))) 1) (Ici 0) t) ∧
      (∀ t ∈ Ici (0:ℝ), t ≠ 1 → t * exp (-t) < 1 * exp (-1)) := by
  have hd : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt (fun s => s * exp (-s))
      (iotaP 1 0 1 t - 1 * (t * exp (-t))) (Ici 0) t := fun t _ =>
    ((hasDerivAt_id' t).mul (hasDerivAt_neg t).exp).hasDerivWithinAt.congr_deriv
      (by simp only [iotaP, one_mul]; ring)
  have hle : ∀ t : ℝ, t * exp (-t) ≤ 1 := fun t => by
    have hp : exp t * exp (-t) = 1 := by rw [← exp_add]; simp
    nlinarith [add_one_le_exp t, exp_pos (-t)]
  refine ⟨hd, fun t ht => ?_, ?_⟩
  · rw [one_mul, min_eq_left (hle t), ← one_mul (t * exp (-t))]
    exact hd t ht
  · have hpk := (p3iii_peak_date_eq (E := fun s => s * exp (-s)) (μ := 1) (ι₀ := 1) (ι₁ := 0)
      one_pos one_pos le_rfl hd (by simp)).2.1
    have ht1 : tHatEq 1 1 0 0 = 1 := by simp [tHatEq]
    rw [ht1] at hpk
    exact hpk

/-! ### Line 276: second-rise constructions with a rising intensity per flaw, with a positive
residue (`line276_second_rise`) and without one (`line276_second_rise_no_residue`). These are
sufficient constructions, not necessary conditions. -/

/-- A per-flaw exploitation intensity equal to `φ₀` up to the date `c` and rising after it:
`φ(t) = φ₀(1 + max(t − c, 0)²)`. It lies outside A5, which holds `φ` constant. -/
noncomputable def phiRise (φ₀ c t : ℝ) : ℝ := φ₀ * (1 + (max (t - c) 0) ^ 2)

lemma phiRise_eq_of_le {φ₀ c t : ℝ} (ht : t ≤ c) : phiRise φ₀ c t = φ₀ := by
  simp [phiRise, max_eq_right (sub_nonpos.mpr ht)]

lemma phiRise_eq_of_ge {φ₀ c t : ℝ} (ht : c ≤ t) :
    phiRise φ₀ c t = φ₀ * (1 + (t - c) ^ 2) := by
  simp [phiRise, max_eq_left (sub_nonneg.mpr ht)]

lemma phiRise_pos {φ₀ : ℝ} (hφ : 0 < φ₀) (c t : ℝ) : 0 < phiRise φ₀ c t :=
  mul_pos hφ (by positivity)

lemma phiRise_continuous (φ₀ c : ℝ) : Continuous (phiRise φ₀ c) := by
  unfold phiRise; fun_prop

lemma phiRise_monotone {φ₀ : ℝ} (hφ : 0 < φ₀) (c : ℝ) : Monotone (phiRise φ₀ c) := by
  intro s t hst
  have h0 : 0 ≤ max (s - c) 0 := le_max_right _ _
  have h1 : max (s - c) 0 ≤ max (t - c) 0 := max_le_max (by linarith) le_rfl
  have h2 : (max (s - c) 0) ^ 2 ≤ (max (t - c) 0) ^ 2 := by nlinarith
  exact mul_le_mul_of_nonneg_left (by linarith) hφ.le

lemma phiRise_strictMonoOn {φ₀ : ℝ} (hφ : 0 < φ₀) (c : ℝ) :
    StrictMonoOn (phiRise φ₀ c) (Ici c) := by
  intro s hs t ht hst
  have hs' : c ≤ s := hs
  have ht' : c ≤ t := ht
  rw [phiRise_eq_of_ge hs', phiRise_eq_of_ge ht']
  have : (s - c) ^ 2 < (t - c) ^ 2 := by nlinarith
  exact mul_lt_mul_of_pos_left (by linarith) hφ

lemma phiRise_tendsto {φ₀ : ℝ} (hφ : 0 < φ₀) (c : ℝ) : Tendsto (phiRise φ₀ c) atTop atTop := by
  have hs : Tendsto (fun t : ℝ => t - c) atTop atTop := by
    simpa [sub_eq_add_neg] using tendsto_atTop_add_const_right atTop (-c) tendsto_id
  have h : Tendsto (fun t : ℝ => φ₀ * (1 + (t - c) ^ 2)) atTop atTop :=
    Tendsto.const_mul_atTop hφ (tendsto_atTop_add_const_left _ 1
      ((tendsto_pow_atTop two_ne_zero).comp hs))
  exact h.congr' (eventually_atTop.2 ⟨c, fun t ht => (phiRise_eq_of_ge ht).symm⟩)

lemma pow_mul_exp_neg_mul_tendsto (k : ℕ) {a : ℝ} (ha : 0 < a) :
    Tendsto (fun t => t ^ k * exp (-(a * t))) atTop (𝓝 0) := by
  have h := ((tendsto_pow_mul_exp_neg_atTop_nhds_zero k).comp
    (tendsto_id.const_mul_atTop ha)).const_mul ((a ^ k)⁻¹)
  rw [mul_zero] at h
  refine h.congr (fun t => ?_)
  simp only [Function.comp_apply, id, mul_pow]
  field_simp

lemma quad_mul_exp_tendsto (c : ℝ) {a : ℝ} (ha : 0 < a) :
    Tendsto (fun t => (1 + (t - c) ^ 2) * exp (-(a * t))) atTop (𝓝 0) := by
  have h := (((pow_mul_exp_neg_mul_tendsto 0 ha).const_mul (1 + c ^ 2)).sub
    ((pow_mul_exp_neg_mul_tendsto 1 ha).const_mul (2 * c))).add (pow_mul_exp_neg_mul_tendsto 2 ha)
  simp only [mul_zero, sub_zero, add_zero] at h
  refine h.congr (fun t => ?_)
  ring

lemma quad_mul_t_exp_tendsto (c : ℝ) {a : ℝ} (ha : 0 < a) :
    Tendsto (fun t => (1 + (t - c) ^ 2) * t * exp (-(a * t))) atTop (𝓝 0) := by
  have h := (((pow_mul_exp_neg_mul_tendsto 1 ha).const_mul (1 + c ^ 2)).sub
    ((pow_mul_exp_neg_mul_tendsto 2 ha).const_mul (2 * c))).add (pow_mul_exp_neg_mul_tendsto 3 ha)
  simp only [mul_zero, sub_zero, add_zero] at h
  refine h.congr (fun t => ?_)
  ring

/-- **Line 276, the second-rise branch** (the capability half lies outside A5). On P3(iii)'s
path from an empty stock with a residue `ι₁ > 0` and the peak criterion:
with constant intensity `φ` the hazard settles to the plateau `φι₁/μ` (below its peak:
`p3iii_peak_above_plateau_ne/_eq`); with an intensity `phiRise φ c` that equals `φ` until a date
`c` after the hazard has peaked and fallen, and rises strictly after it, the hazard has the same
rise (`a → b`) and fall (`b → c`), then rises without bound: a peak, a decline, a second rise. -/
theorem line276_second_rise (hφ : 0 < φ) (hμ : 0 < μ) (hγ : 0 < γ) (h1 : 0 < ι₁)
    (hι : ι₁ < ι₀) (hcrit : γ * ι₁ < μ * ι₀)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ ι₁ γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    Tendsto (fun t => φ * E t) atTop (𝓝 (φ * ι₁ / μ)) ∧
      ∃ a b c, 0 ≤ a ∧ a < b ∧ b < c ∧ φ * E a < φ * E b ∧ φ * E c < φ * E b ∧
        (∀ t ∈ Icc 0 c, phiRise φ c t = φ) ∧ StrictMonoOn (phiRise φ c) (Ici c) ∧
        phiRise φ c a * E a < phiRise φ c b * E b ∧
        phiRise φ c c * E c < phiRise φ c b * E b ∧
        Tendsto (fun t => phiRise φ c t * E t) atTop atTop := by
  obtain ⟨a, b, c, ha, -, -, hab, hbc, hlo, hhi⟩ :=
    (p3iii_peak_iff hφ hμ hγ h1.le hι hE hE0).mpr hcrit
  have hu := p3iii_solution_unique (convex_Ici 0) (mem_Ici.mpr le_rfl) hμ.ne' hE hE0
  have hEl : Tendsto E atTop (𝓝 (ι₁ / μ)) :=
    (esol_tendsto hμ hγ).congr' (eventually_atTop.2 ⟨0, fun t ht => (hu t ht).symm⟩)
  have ha' : phiRise φ c a = φ := phiRise_eq_of_le (by linarith)
  have hb' : phiRise φ c b = φ := phiRise_eq_of_le hbc.le
  have hc' : phiRise φ c c = φ := phiRise_eq_of_le le_rfl
  refine ⟨p3iii_plateau hμ hγ hE hE0, a, b, c, ha, hab, hbc, hlo, hhi,
    fun t ht => phiRise_eq_of_le ht.2, phiRise_strictMonoOn hφ c,
    by rw [ha', hb']; exact hlo, by rw [hc', hb']; exact hhi, ?_⟩
  exact (phiRise_tendsto hφ c).atTop_mul_pos (div_pos h1 hμ) hEl

/-- **Line 276, "depends on the residue"**: under full protection (`ι₁ = 0`) the *same* rising
intensity `phiRise φ c` (any `c`, any `γ`, `μ > 0`) gives no long-run second rise: the hazard
tends to zero. With `line276_second_rise`, the outcome after a peak changes with the residue at a
fixed intensity path, and with the intensity path at a fixed residue. -/
theorem line276_no_residue_falls (hμ : 0 < μ) (hγ : 0 < γ) (c : ℝ)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP ι₀ 0 γ t - μ * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    Tendsto (fun t => phiRise φ c t * E t) atTop (𝓝 0) := by
  have hu := p3iii_solution_unique (convex_Ici 0) (mem_Ici.mpr le_rfl) hμ.ne' hE hE0
  have hev : ∀ᶠ t in atTop,
      φ * ((1 + (t - c) ^ 2) * Esol μ γ ι₀ 0 0 t) = phiRise φ c t * E t :=
    eventually_atTop.2 ⟨max c 0, fun t ht => by
      rw [phiRise_eq_of_ge (le_of_max_le_left ht), hu t (le_of_max_le_right ht)]; ring⟩
  refine Tendsto.congr' hev ?_
  rw [← mul_zero φ]
  refine Tendsto.const_mul φ ?_
  unfold Esol
  split_ifs with h
  · subst h
    have h' := (quad_mul_t_exp_tendsto c hμ).const_mul ι₀
    rw [mul_zero] at h'
    refine h'.congr (fun t => ?_)
    simp only [EsolEq]; ring
  · have h' := ((quad_mul_exp_tendsto c hγ).sub (quad_mul_exp_tendsto c hμ)).const_mul
      (ι₀ / (μ - γ))
    rw [sub_zero, mul_zero] at h'
    refine h'.congr (fun t => ?_)
    simp only [EsolNe]; ring

/-- A per-flaw exploitation intensity equal to `φ₀` up to the date `c` and growing at
exponential rate `κ` after it: `φ(t) = φ₀ e^{κ max(t − c, 0)}`. Outside A5. -/
noncomputable def phiExp (φ₀ κ c t : ℝ) : ℝ := φ₀ * exp (κ * max (t - c) 0)

lemma phiExp_eq_of_le {φ₀ κ c t : ℝ} (ht : t ≤ c) : phiExp φ₀ κ c t = φ₀ := by
  simp [phiExp, max_eq_right (sub_nonpos.mpr ht)]

lemma phiExp_eq_of_ge {φ₀ κ c t : ℝ} (ht : c ≤ t) :
    phiExp φ₀ κ c t = φ₀ * exp (κ * (t - c)) := by
  simp [phiExp, max_eq_left (sub_nonneg.mpr ht)]

lemma phiExp_pos {φ₀ : ℝ} (hφ : 0 < φ₀) (κ c t : ℝ) : 0 < phiExp φ₀ κ c t :=
  mul_pos hφ (exp_pos _)

lemma phiExp_continuous (φ₀ κ c : ℝ) : Continuous (phiExp φ₀ κ c) := by
  unfold phiExp; fun_prop

lemma phiExp_monotone {φ₀ κ : ℝ} (hφ : 0 < φ₀) (hκ : 0 < κ) (c : ℝ) :
    Monotone (phiExp φ₀ κ c) := by
  intro s t hst
  have h1 : max (s - c) 0 ≤ max (t - c) 0 := max_le_max (by linarith) le_rfl
  exact mul_le_mul_of_nonneg_left (exp_le_exp.mpr (mul_le_mul_of_nonneg_left h1 hκ.le)) hφ.le

lemma phiExp_strictMonoOn {φ₀ κ : ℝ} (hφ : 0 < φ₀) (hκ : 0 < κ) (c : ℝ) :
    StrictMonoOn (phiExp φ₀ κ c) (Ici c) := by
  intro s hs t ht hst
  rw [phiExp_eq_of_ge (mem_Ici.mp hs), phiExp_eq_of_ge (mem_Ici.mp ht)]
  exact mul_lt_mul_of_pos_left (exp_lt_exp.mpr (by nlinarith)) hφ

/-- **Line 276, a second rise without a residue** (Sol focus r2, finding 1). On P3(iii)'s path
with full protection (`μ = γ = ι₀ = 1`, `ι₁ = 0`, `E(0) = 0`, so `E = te^{−t}`): with constant
`φ` the hazard rises (`0 → 1`), falls (`1 → 2`) and tends to zero; with the intensity
`phiExp φ 2 2`, equal to `φ` on `[0, 2]` and strictly rising after, the hazard has the same rise
and fall and then tends to `+∞`. So a residue is not necessary for a second rise; together with
`line276_no_residue_falls`, at zero residue the outcome depends on the intensity path. -/
theorem line276_second_rise_no_residue (hφ : 0 < φ)
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP 1 0 1 t - 1 * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    Tendsto (fun t => φ * E t) atTop (𝓝 0) ∧
      φ * E 0 < φ * E 1 ∧ φ * E 2 < φ * E 1 ∧
      (∀ t ∈ Icc 0 2, phiExp φ 2 2 t = φ) ∧ StrictMonoOn (phiExp φ 2 2) (Ici 2) ∧
      phiExp φ 2 2 0 * E 0 < phiExp φ 2 2 1 * E 1 ∧
      phiExp φ 2 2 2 * E 2 < phiExp φ 2 2 1 * E 1 ∧
      Tendsto (fun t => phiExp φ 2 2 t * E t) atTop atTop := by
  have hu := p3iii_solution_unique (convex_Ici 0) (mem_Ici.mpr le_rfl) one_ne_zero hE hE0
  have hEt : ∀ t : ℝ, 0 ≤ t → E t = t * exp (-t) := fun t ht => by
    rw [hu t ht]; simp [Esol, EsolEq]
  have hlim : Tendsto E atTop (𝓝 0) := by
    have h := (esol_tendsto (ι₀ := 1) (ι₁ := 0) (E₀ := 0) one_pos one_pos)
    rw [zero_div] at h
    exact h.congr' (eventually_atTop.2 ⟨0, fun t ht => (hu t ht).symm⟩)
  have e1 : E 1 = exp (-1) := by rw [hEt 1 zero_le_one, one_mul]
  have e2 : E 2 = 2 * exp (-2) := by rw [hEt 2 zero_le_two]
  have h01 : E 0 < E 1 := by rw [hE0, e1]; exact exp_pos _
  have h21 : E 2 < E 1 := by
    have hsq : exp (-2) = exp (-1) * exp (-1) := by rw [← exp_add]; norm_num
    have hinv : exp (-1) * exp 1 = 1 := by rw [← exp_add]; simp
    have he := Real.exp_one_gt_d9
    rw [e1, e2, hsq]
    nlinarith [exp_pos (-1)]
  have p0 : phiExp φ 2 2 0 = φ := phiExp_eq_of_le (by norm_num)
  have p1 : phiExp φ 2 2 1 = φ := phiExp_eq_of_le (by norm_num)
  have p2 : phiExp φ 2 2 2 = φ := phiExp_eq_of_le le_rfl
  refine ⟨by simpa using hlim.const_mul φ, mul_lt_mul_of_pos_left h01 hφ,
    mul_lt_mul_of_pos_left h21 hφ, fun t ht => phiExp_eq_of_le ht.2,
    phiExp_strictMonoOn hφ two_pos 2, by rw [p0, p1]; exact mul_lt_mul_of_pos_left h01 hφ,
    by rw [p2, p1]; exact mul_lt_mul_of_pos_left h21 hφ, ?_⟩
  have hev : ∀ᶠ t in atTop, φ * (t * exp (t - 4)) = phiExp φ 2 2 t * E t :=
    eventually_atTop.2 ⟨2, fun t ht => by
      rw [phiExp_eq_of_ge ht, hEt t (by linarith), mul_assoc, mul_left_comm (exp _),
        ← exp_add]
      ring_nf⟩
  refine Tendsto.congr' hev (Tendsto.const_mul_atTop hφ ?_)
  have hs : Tendsto (fun t : ℝ => t - 4) atTop atTop := by
    simpa [sub_eq_add_neg] using tendsto_atTop_add_const_right atTop (-4) tendsto_id
  exact tendsto_id.atTop_mul_atTop₀ (tendsto_exp_atTop.comp hs)

end Empty

/-! ## Figure 6's illustrative cases (`μ = ι₀ = φ = 1`, `T_A = 6`) -/

/-- Arithmetic side condition for slow protection with a residue (`γ = 0.3`, `ι₁ = 0.4`): the
criterion and `t̂ < T_A = 6`. The statement about the path is `fig6_slow_residue_path`. -/
theorem fig6_slow_residue :
    (3/10 : ℝ) * (2/5) < 1 * 1 ∧ tHatNe 1 (3/10) 1 (2/5) 0 < 6 := by
  refine ⟨by norm_num, ?_⟩
  rw [tHatNe_zero, div_lt_iff₀ (by norm_num), Real.log_lt_iff_lt_exp (by norm_num)]
  have := add_one_le_exp (6 * (1 - 3/10))
  norm_num at this ⊢
  linarith

/-- Arithmetic side condition for fast protection with a residue (`γ = 3`, `ι₁ = 0.4`): the
criterion fails. The statement about the path is `fig6_fast_residue_path`. -/
theorem fig6_fast_residue : ¬ ((3 : ℝ) * (2/5) < 1 * 1) := by norm_num

/-- Arithmetic side condition for full protection (`ι₁ = 0`) at either rate in the figure:
`t̂ < T_A = 6`. The statements about the path are `fig6_full_slow_path`, `fig6_full_fast_path`. -/
theorem fig6_full_protection :
    tHatNe 1 (3/10) 1 0 0 < 6 ∧ tHatNe 1 3 1 0 0 < 6 := by
  constructor
  · rw [tHatNe_zero, div_lt_iff₀ (by norm_num), Real.log_lt_iff_lt_exp (by norm_num)]
    have := add_one_le_exp (6 * (1 - 3/10))
    norm_num at this ⊢
    linarith
  · rw [tHatNe_zero, div_lt_iff_of_neg (by norm_num), Real.lt_log_iff_exp_lt (by norm_num)]
    have h12 := add_one_le_exp 12
    have hp : exp (-12) * exp 12 = 1 := by rw [← exp_add]; norm_num
    have hpos := exp_pos (-12)
    norm_num
    nlinarith

/-- **Figure 6, slow protection with a residue**, on the path (`μ = ι₀ = φ = 1`, `γ = 0.3`,
`ι₁ = 0.4`, `T_A = 6`, empty stock): the hazard has a pre-ASI peak and settles to `φι₁/μ`. -/
theorem fig6_slow_residue_path {E : ℝ → ℝ}
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP 1 (2/5) (3/10) t - 1 * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    RisesFalls (fun t => 1 * E t) (Ico 0 6) ∧
      Tendsto (fun t => 1 * E t) atTop (𝓝 (1 * (2/5) / 1)) :=
  ⟨(p3iii_preASI_iff_ne (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
      (by norm_num) (by norm_num) (fun t ht => (hE t ht.1).mono Ico_subset_Ici_self) hE0).mpr
      fig6_slow_residue,
    p3iii_plateau (by norm_num) (by norm_num) hE hE0⟩

/-- **Figure 6, fast protection with a residue** (`γ = 3`, `ι₁ = 0.4`): no peak, before or
after `T_A`; a strict rise, below and toward the same plateau. -/
theorem fig6_fast_residue_path {E : ℝ → ℝ}
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP 1 (2/5) 3 t - 1 * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    ¬ RisesFalls (fun t => 1 * E t) (Ici 0) ∧ ¬ RisesFalls (fun t => 1 * E t) (Ico 0 6) ∧
      StrictMonoOn E (Ici 0) ∧ (∀ t ∈ Ici 0, E t < (2/5) / 1) ∧
      Tendsto (fun t => 1 * E t) atTop (𝓝 (1 * (2/5) / 1)) := by
  obtain ⟨hno, hm, hlt, hl⟩ := p3iii_fast_protection_removes_peak (φ := 1) (by norm_num)
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hE hE0
  refine ⟨hno, ?_, hm, hlt, hl⟩
  rw [risesFalls_const_mul one_pos]
  exact not_risesFalls_of_strictMonoOn (hm.mono Ico_subset_Ici_self)

/-- **Figure 6, full protection, slow rate** (`ι₁ = 0`, `γ = 0.3`): a pre-ASI peak, and the
hazard falls toward zero. -/
theorem fig6_full_slow_path {E : ℝ → ℝ}
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP 1 0 (3/10) t - 1 * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    RisesFalls (fun t => 1 * E t) (Ico 0 6) ∧ Tendsto (fun t => 1 * E t) atTop (𝓝 (1 * 0 / 1)) :=
  ⟨(p3iii_preASI_iff_ne (by norm_num) (by norm_num) (by norm_num) (by norm_num) le_rfl
      (by norm_num) (by norm_num) (fun t ht => (hE t ht.1).mono Ico_subset_Ici_self) hE0).mpr
      ⟨by norm_num, fig6_full_protection.1⟩,
    p3iii_plateau (by norm_num) (by norm_num) hE hE0⟩

/-- **Figure 6, full protection, fast rate** (`ι₁ = 0`, `γ = 3`): a pre-ASI peak, and the
hazard falls toward zero. -/
theorem fig6_full_fast_path {E : ℝ → ℝ}
    (hE : ∀ t ∈ Ici 0, HasDerivWithinAt E (iotaP 1 0 3 t - 1 * E t) (Ici 0) t)
    (hE0 : E 0 = 0) :
    RisesFalls (fun t => 1 * E t) (Ico 0 6) ∧ Tendsto (fun t => 1 * E t) atTop (𝓝 (1 * 0 / 1)) :=
  ⟨(p3iii_preASI_iff_ne (by norm_num) (by norm_num) (by norm_num) (by norm_num) le_rfl
      (by norm_num) (by norm_num) (fun t ht => (hE t ht.1).mono Ico_subset_Ici_self) hE0).mpr
      ⟨by norm_num, fig6_full_protection.2⟩,
    p3iii_plateau (by norm_num) (by norm_num) hE hE0⟩

/-! ## Helpers for divergence -/

lemma tendsto_affine {a b : ℝ} (ha : 0 < a) : Tendsto (fun t => a * t + b) atTop atTop :=
  tendsto_atTop_atTop.mpr fun c => ⟨(c - b) / a, fun t ht => by
    have := (div_le_iff₀ ha).mp ht; linarith⟩

lemma no_limit_of_atTop {f : ℝ → ℝ} (h : Tendsto f atTop atTop) :
    ¬ ∃ L, Tendsto f atTop (𝓝 L) := by
  rintro ⟨L, hL⟩
  have h1 := hL.eventually (gt_mem_nhds (lt_add_one L))
  have h2 := h.eventually (eventually_ge_atTop (L + 1))
  obtain ⟨x, hx1, hx2⟩ := (h1.and h2).exists
  linarith

/-! ## P3 "as first stated": the counterexamples -/

section Orig

/-- Finite-horizon example (`T_A = 1`): `ι = 1 − 2t + t/(1 − t)`. -/
noncomputable def ιF (t : ℝ) : ℝ := 1 - 2 * t + t / (1 - t)
/-- `μ = (1 − t)^{−2}`. -/
noncomputable def μF (t : ℝ) : ℝ := 1 / (1 - t) ^ 2
/-- `E = t(1 − t)`. -/
def EF (t : ℝ) : ℝ := t * (1 - t)

lemma ιF_eq {t : ℝ} (ht : t < 1) : ιF t = 2 * (1 - t) + 1 / (1 - t) - 2 := by
  have h : (1:ℝ) - t ≠ 0 := (sub_pos.mpr ht).ne'
  simp only [ιF]; field_simp; ring

theorem origF_solves : ∀ t ∈ Ico (0:ℝ) 1, HasDerivAt EF (ιF t - μF t * EF t) t := by
  intro t ht
  have h : (1:ℝ) - t ≠ 0 := (sub_pos.mpr ht.2).ne'
  have hd : HasDerivAt EF (1 * (1 - t) + t * (0 - 1)) t :=
    (hasDerivAt_id' t).mul ((hasDerivAt_const t (1:ℝ)).sub (hasDerivAt_id' t))
  exact hd.congr_deriv (by simp only [ιF, μF, EF]; field_simp; ring)

theorem origF_mu_pos : ∀ t ∈ Ico (0:ℝ) 1, 0 < μF t := fun _ ht =>
  div_pos one_pos (pow_pos (sub_pos.mpr ht.2) 2)

/-- `ι ≥ 2√2 − 2` on `[0, 1)`. -/
theorem origF_iota_min : ∀ t ∈ Ico (0:ℝ) 1, 2 * √2 - 2 ≤ ιF t := by
  intro t ht
  have hu : 0 < 1 - t := sub_pos.mpr ht.2
  rw [ιF_eq ht.2]
  have hs : √2 ^ 2 = 2 := Real.sq_sqrt (by norm_num)
  have key : 2 * √2 - 2 * (1 - t) ≤ 1 / (1 - t) := by
    rw [le_div_iff₀ hu]
    have hs' : √2 ^ 2 * (1 - t) ^ 2 = 2 * (1 - t) ^ 2 := by rw [hs]
    nlinarith [sq_nonneg (√2 * (1 - t) - 1)]
  linarith

/-- The minimum `2√2 − 2` is attained at `1 − t = 1/√2`. -/
theorem origF_iota_min_attained : ιF (1 - 1 / √2) = 2 * √2 - 2 := by
  have hlt : 1 - 1 / √2 < 1 := by
    have : 0 < 1 / √2 := by positivity
    linarith
  rw [ιF_eq hlt, show (1:ℝ) - (1 - 1 / √2) = 1 / √2 by ring, one_div_one_div, mul_one_div,
    Real.div_sqrt]
  ring

theorem origF_iota_pos : ∀ t ∈ Ico (0:ℝ) 1, 0 < ιF t := by
  intro t ht
  have : 1 < √2 := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  linarith [origF_iota_min t ht]

theorem origF_iota_unbounded : ¬ BddAbove (ιF '' Ico 0 1) := by
  rintro ⟨M, hM⟩
  have hA : 0 < |M| + 3 := by positivity
  have hu0 : 0 < 1 / (|M| + 3) := by positivity
  have hu1 : 1 / (|M| + 3) < 1 := by rw [div_lt_one hA]; linarith [abs_nonneg M]
  have hmem : 1 - 1 / (|M| + 3) ∈ Ico (0:ℝ) 1 := ⟨by linarith, by linarith⟩
  have hval : ιF (1 - 1 / (|M| + 3)) = 2 * (1 / (|M| + 3)) + (|M| + 3) - 2 := by
    rw [ιF_eq (by linarith), show (1:ℝ) - (1 - 1 / (|M| + 3)) = 1 / (|M| + 3) by ring,
      one_div_one_div]
  have := hM ⟨1 - 1 / (|M| + 3), hmem, rfl⟩
  rw [hval] at this
  linarith [le_abs_self M]

/-- `ι → ∞` as `t → 1⁻`. -/
theorem origF_iota_tendsto : Tendsto ιF (𝓝[<] 1) atTop := by
  have h1 : Tendsto (fun t : ℝ => 1 - t) (𝓝[<] 1) (𝓝[>] 0) := by
    apply tendsto_nhdsWithin_of_tendsto_nhds_of_eventually_within
    · have h0 : Tendsto (fun t : ℝ => 1 - t) (𝓝 1) (𝓝 (1 - 1)) :=
        (continuous_const.sub continuous_id).tendsto 1
      rw [sub_self] at h0
      exact h0.mono_left nhdsWithin_le_nhds
    · filter_upwards [self_mem_nhdsWithin] with t ht
      exact sub_pos.mpr (mem_Iio.mp ht)
  have h2 := tendsto_inv_nhdsGT_zero.comp h1
  rw [Filter.tendsto_atTop]
  intro b
  filter_upwards [Filter.tendsto_atTop.mp h2 (b + 2), self_mem_nhdsWithin] with t ht htl
  have htl' : t < 1 := htl
  simp only [Function.comp_apply] at ht
  rw [ιF_eq htl', one_div]
  linarith [sub_pos.mpr htl']

theorem origF_risesFalls : RisesFalls EF (Ico 0 1) :=
  ⟨0, 1/2, 3/4, ⟨le_rfl, by norm_num⟩, ⟨by norm_num, by norm_num⟩, ⟨by norm_num, by norm_num⟩,
    by norm_num, by norm_num, by norm_num [EF], by norm_num [EF]⟩

theorem origF_unique_max : ∀ t ∈ Ico (0:ℝ) 1, t ≠ 1/2 → EF t < EF (1/2) := by
  intro t _ hne
  have : 0 < (t - 1/2) ^ 2 :=
    lt_of_le_of_ne (sq_nonneg _) (Ne.symm (pow_ne_zero 2 (sub_ne_zero.mpr hne)))
  simp only [EF]; nlinarith

theorem origF_tendsto_zero : Tendsto EF (𝓝[<] 1) (𝓝 0) := by
  have hc : Continuous EF := by unfold EF; fun_prop
  have := (hc.tendsto 1).mono_left (nhdsWithin_le_nhds (s := Iio 1))
  simpa [EF] using this

/-- **1118, "falls back toward zero, with no plateau"**, under reading 1 (a plateau is any finite
limit, as P3(iii) uses the word, where `φι₁/μ = 0` for `ι₁ = 0`): false, since `E = t(1 − t)`
has the finite limit 0 at `T_A = 1`. -/
theorem origF_has_limit : ∃ L, Tendsto EF (𝓝[<] 1) (𝓝 L) := ⟨0, origF_tendsto_zero⟩

/-- The same sentence under reading 2 (a plateau is a positive limit): true. -/
theorem origF_no_positive_plateau : ¬ ∃ L, 0 < L ∧ Tendsto EF (𝓝[<] 1) (𝓝 L) := by
  rintro ⟨L, hL, h⟩
  have := tendsto_nhds_unique h origF_tendsto_zero
  linarith

/-- **P3 "as first stated", second half, on a finite horizon, reading 2**: with the paper's own
example, "unbounded introduction ⇒ risk plateaus at a positive level" is false on `[0, 1)`. -/
theorem p3_orig_second_half_false_finite_pos :
    ¬ ∀ (ι μ E : ℝ → ℝ),
      (∀ t ∈ Ico (0:ℝ) 1, 0 < μ t ∧ 0 ≤ ι t ∧ HasDerivAt E (ι t - μ t * E t) t) →
      E 0 = 0 → ¬ BddAbove (ι '' Ico 0 1) → ∃ L, 0 < L ∧ Tendsto E (𝓝[<] 1) (𝓝 L) := by
  intro h
  exact origF_no_positive_plateau (h ιF μF EF
    (fun t ht => ⟨origF_mu_pos t ht, (origF_iota_pos t ht).le, origF_solves t ht⟩)
    (by simp [EF]) origF_iota_unbounded)

/-- **P3 "as first stated", first half, on a finite horizon**: "an interior pre-ASI maximum exists
only if residual flaw introduction stays bounded" is false on `[0, T_A) = [0, 1)`. -/
theorem p3_orig_first_half_false_finite :
    ¬ ∀ (ι μ E : ℝ → ℝ),
      (∀ t ∈ Ico (0:ℝ) 1, 0 < μ t ∧ 0 ≤ ι t ∧ HasDerivAt E (ι t - μ t * E t) t) →
      E 0 = 0 → RisesFalls E (Ico 0 1) → BddAbove (ι '' Ico 0 1) := by
  intro h
  exact origF_iota_unbounded (h ιF μF EF
    (fun t ht => ⟨origF_mu_pos t ht, (origF_iota_pos t ht).le, origF_solves t ht⟩)
    (by simp [EF]) origF_risesFalls)

/-- The `e^t` example's stock from `E(0) = 0`:
`E(t) = e^{−e^{2t}/2} ∫₀ᵗ e^{s + e^{2s}/2} ds`. -/
noncomputable def EX (t : ℝ) : ℝ :=
  exp (-(exp (2 * t) / 2)) * ∫ s in (0:ℝ)..t, exp (s + exp (2 * s) / 2)

theorem origX_solves (t : ℝ) : HasDerivAt EX (exp t - exp (2 * t) * EX t) t := by
  have hc : Continuous (fun s : ℝ => exp (s + exp (2 * s) / 2)) := by fun_prop
  have hI := (hc.integral_hasStrictDerivAt 0 t).hasDerivAt
  have h3 : HasDerivAt (fun t => -(exp (2 * t) / 2)) (-(exp (2 * t) * 2 / 2)) t :=
    ((hasDerivAt_exp_mul 2 t).div_const 2).fun_neg
  have h := h3.exp.mul hI
  refine h.congr_deriv ?_
  simp only [EX]
  have e : exp (-(exp (2 * t) / 2)) * exp (t + exp (2 * t) / 2) = exp t := by
    rw [← exp_add]; ring_nf
  rw [e]; ring

theorem origX_zero : EX 0 = 0 := by simp [EX]

lemma origX_continuous : Continuous EX :=
  continuous_iff_continuousAt.2 fun s => (origX_solves s).continuousAt

/-- `EX t > 0` for `t > 0`. -/
theorem origX_pos {t : ℝ} (ht : 0 < t) : 0 < EX t := by
  have hc : Continuous (fun s : ℝ => exp (s + exp (2 * s) / 2)) := by fun_prop
  exact mul_pos (exp_pos _) (intervalIntegral.intervalIntegral_pos_of_pos_on
    (hc.intervalIntegrable 0 t) (fun x _ => exp_pos _) ht)

/-- `EX ≤ 1` on `t ≥ 0` (barrier: at `E = 1`, `E′ = e^t − e^{2t} < 0` for `t > 0`). -/
theorem origX_le_one : ∀ t ∈ Ici (0:ℝ), EX t ≤ 1 := by
  intro t ht
  have := image_le_of_deriv_right_lt_deriv_boundary (f := EX)
    (f' := fun s => exp s - exp (2 * s) * EX s) (a := 0) (b := t)
    origX_continuous.continuousOn (fun s _ => (origX_solves s).hasDerivWithinAt)
    (B := fun _ => 1) (B' := fun _ => 0) (by simp [origX_zero]) (fun s => hasDerivAt_const s 1)
    (fun s hs heq => by
      rcases eq_or_lt_of_le hs.1 with h0 | h0
      · subst h0; rw [origX_zero] at heq; norm_num at heq
      · rw [heq, mul_one, sub_neg]; exact exp_lt_exp.mpr (by linarith))
  exact this ⟨ht, le_rfl⟩

/-- `EX ≤ 3e^{−t}` for `t ≥ 1` (barrier: at `E = 3e^{−t}`, `E′ = −2e^t < −3e^{−t}`). -/
theorem origX_le_exp : ∀ t, 1 ≤ t → EX t ≤ 3 * exp (-t) := by
  intro t ht
  have he1 : exp (-1) * exp 1 = 1 := by rw [← exp_add]; norm_num
  have hstart : EX 1 ≤ 3 * exp (-1) := by
    have := origX_le_one 1 (mem_Ici.mpr zero_le_one)
    have := Real.exp_one_lt_d9
    nlinarith [exp_pos (-1)]
  have := image_le_of_deriv_right_lt_deriv_boundary (f := EX)
    (f' := fun s => exp s - exp (2 * s) * EX s) (a := 1) (b := t)
    origX_continuous.continuousOn (fun s _ => (origX_solves s).hasDerivWithinAt)
    (B := fun s => 3 * exp (-s)) (B' := fun s => 3 * (-exp (-s))) hstart
    (fun s => ((hasDerivAt_neg s).exp).const_mul 3 |>.congr_deriv (by ring))
    (fun s hs heq => by
      have hab : exp s * exp (-s) = 1 := by rw [← exp_add]; simp
      have h2 : exp (2 * s) = exp s * exp s := by rw [← exp_add]; ring_nf
      have hs2 : 2 ≤ exp s := by linarith [add_one_le_exp s, hs.1]
      rw [heq, h2]
      nlinarith [exp_pos (-s), exp_pos s])
  exact this ⟨ht, le_rfl⟩

/-- The `e^t` example's stock falls back toward zero: `EX → 0` (squeezed by `0 < EX ≤ 3e^{−t}`). -/
theorem origX_tendsto_zero : Tendsto EX atTop (𝓝 0) := by
  have hup : Tendsto (fun t => 3 * exp (-t)) atTop (𝓝 0) := by
    simpa using (Real.tendsto_exp_neg_atTop_nhds_zero).const_mul 3
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds hup ?_ ?_
  · exact eventually_atTop.2 ⟨1, fun t ht => (origX_pos (by linarith)).le⟩
  · exact eventually_atTop.2 ⟨1, fun t ht => origX_le_exp t ht⟩

/-- The `e^t` example's stock has an interior *global* maximizer on `[0, ∞)`. -/
theorem origX_global_max : ∃ tm, 0 < tm ∧ IsMaxOn EX (Ici 0) tm := by
  have hb0 : 0 < EX 1 := origX_pos one_pos
  obtain ⟨T₀, hT₀⟩ := eventually_atTop.mp (origX_tendsto_zero.eventually (gt_mem_nhds hb0))
  obtain ⟨tm, htm, hmax⟩ := isCompact_Icc.exists_isMaxOn
    (nonempty_Icc.2 (show (0:ℝ) ≤ max T₀ 1 by positivity)) origX_continuous.continuousOn
  have h1 : EX 1 ≤ EX tm := isMaxOn_iff.mp hmax 1 ⟨zero_le_one, le_max_right _ _⟩
  refine ⟨tm, lt_of_le_of_ne htm.1 (fun h => ?_), isMaxOn_iff.mpr fun t ht => ?_⟩
  · rw [← h, origX_zero] at h1; linarith
  · by_cases htT : t ≤ max T₀ 1
    · exact isMaxOn_iff.mp hmax t ⟨ht, htT⟩
    · have := hT₀ t (le_trans (le_max_left _ _) (not_le.mp htT).le)
      linarith

/-- The `e^t` example (`ι = e^t`, `μ = e^{2t}`): every solution from `0 ≤ E(0) < 1` rises and
later falls on `[0, ∞)`. The dates 0.73 and the 90% fall are numerical. -/
theorem origX_risesFalls {E : ℝ → ℝ}
    (hE : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt E (exp t - exp (2 * t) * E t) (Ici 0) t)
    (h0 : 0 ≤ E 0) (h1 : E 0 < 1) : RisesFalls E (Ici 0) := by
  have hE' : ∀ t ∈ Ici (0:ℝ),
      HasDerivWithinAt E (exp t - (fun s => exp (2 * s)) t * E t) (Ici 0) t := hE
  obtain ⟨t₁, ht₁, hdown⟩ : ∃ t₁, 0 < t₁ ∧ exp t₁ < exp (2 * t₁) * E t₁ := by
    by_contra hc
    have hc' : ∀ t, 0 < t → exp (2 * t) * E t ≤ exp t :=
      fun t ht => not_lt.mp (fun h => hc ⟨t, ht, h⟩)
    have hmono : MonotoneOn E (Ici 0) := by
      apply monotoneOn_of_deriv_nonneg (convex_Ici 0) (continuousOn_of_hasDerivWithinAt hE)
      · intro x hx; exact (hasDerivAt_of_interior hE hx).differentiableAt.differentiableWithinAt
      · intro x hx
        rw [(hasDerivAt_of_interior hE hx).deriv]
        rw [interior_Ici] at hx
        linarith [hc' x hx]
    have hr := eventually_right_gt (hE 0 (mem_Ici.mpr le_rfl))
      (by simp only [mul_zero, exp_zero, one_mul]; linarith) zero_lt_one
      (fun x hx => mem_Ici.mpr hx.1.le)
    have hself : ∀ᶠ x in 𝓝[>] (0:ℝ), 0 < x := self_mem_nhdsWithin
    obtain ⟨y, hy, hy0⟩ := (hr.and hself).exists
    have hEy : 0 < E y := by linarith
    have hty : y ≤ max y (-log (E y)) + 1 := by linarith [le_max_left y (-log (E y))]
    have htpos : 0 < max y (-log (E y)) + 1 := by linarith
    have hEt : E y ≤ E (max y (-log (E y)) + 1) :=
      hmono (mem_Ici.mpr hy0.le) (mem_Ici.mpr htpos.le) hty
    have hlt : exp (-(max y (-log (E y)) + 1)) < E y :=
      (Real.lt_log_iff_exp_lt hEy).mp (by linarith [le_max_right y (-log (E y))])
    have hprod : exp (2 * (max y (-log (E y)) + 1)) * exp (-(max y (-log (E y)) + 1)) =
        exp (max y (-log (E y)) + 1) := by rw [← exp_add]; ring_nf
    have hc'' := hc' _ htpos
    have h2pos := exp_pos (2 * (max y (-log (E y)) + 1))
    nlinarith [mul_lt_mul_of_pos_left hlt h2pos, mul_le_mul_of_nonneg_left hEt h2pos.le]
  obtain ⟨b, hb, -, h0b, h1b⟩ := p3i_interior_max (ι := exp) (μ := fun s => exp (2 * s))
    (convex_Ici 0) hE' (mem_Ici.mpr le_rfl) (mem_Ici.mpr ht₁.le) ht₁
    (by show exp (2 * 0) * E 0 < exp 0; simp only [mul_zero, exp_zero, one_mul]; exact h1)
    hdown
  exact ⟨0, b, t₁, mem_Ici.mpr le_rfl, mem_Ici.mpr (by linarith [hb.1]), mem_Ici.mpr ht₁.le,
    hb.1, hb.2, h0b, h1b⟩

/-- **P3 "as first stated", first half, on the unbounded horizon**: false, by the `e^t` example. -/
theorem p3_orig_first_half_false_unbounded :
    ¬ ∀ (ι μ E : ℝ → ℝ),
      (∀ t ∈ Ici (0:ℝ), 0 < μ t ∧ 0 ≤ ι t ∧ HasDerivAt E (ι t - μ t * E t) t) →
      E 0 = 0 → RisesFalls E (Ici 0) → BddAbove (ι '' Ici 0) := by
  intro h
  obtain ⟨M, hM⟩ := h exp (fun s => exp (2 * s)) EX
    (fun t _ => ⟨exp_pos _, (exp_pos _).le, origX_solves t⟩) origX_zero
    (origX_risesFalls (fun t _ => (origX_solves t).hasDerivWithinAt) (le_of_eq origX_zero.symm)
      (by rw [origX_zero]; norm_num))
  have := hM ⟨max M 0 + 1, mem_Ici.mpr (by linarith [le_max_right M 0]), rfl⟩
  linarith [add_one_le_exp (max M 0 + 1), le_max_left M 0]

/-- **909, "introduction can be unbounded while the stock peaks and falls back toward zero"**, on
the unbounded horizon: the `e^t` model from an empty stock has unbounded introduction, rises and
later falls, has an interior global maximum, and its stock tends to 0. -/
theorem p3_orig_unbounded_peak_falls_to_zero :
    ∃ ι μ E : ℝ → ℝ, (∀ t ∈ Ici (0:ℝ), 0 < μ t ∧ 0 ≤ ι t ∧ HasDerivAt E (ι t - μ t * E t) t) ∧
      E 0 = 0 ∧ ¬ BddAbove (ι '' Ici 0) ∧ RisesFalls E (Ici 0) ∧
      (∃ tm, 0 < tm ∧ IsMaxOn E (Ici 0) tm) ∧ Tendsto E atTop (𝓝 0) := by
  refine ⟨exp, fun s => exp (2 * s), EX, fun t _ => ⟨exp_pos _, (exp_pos _).le, origX_solves t⟩,
    origX_zero, ?_, origX_risesFalls (fun t _ => (origX_solves t).hasDerivWithinAt)
      (le_of_eq origX_zero.symm) (by rw [origX_zero]; norm_num), origX_global_max,
    origX_tendsto_zero⟩
  rintro ⟨M, hM⟩
  have := hM ⟨max M 0 + 1, mem_Ici.mpr (by linarith [le_max_right M 0]), rfl⟩
  linarith [add_one_le_exp (max M 0 + 1), le_max_left M 0]

/-- The `ι = 1 + t`, `μ = 0.1` example from `E(0) = E₀`: `E = 10t − 90 + (E₀ + 90)e^{−t/10}`. -/
theorem origL_solution (E₀ t : ℝ) :
    HasDerivAt (fun t => 10 * t - 90 + (E₀ + 90) * exp (-((1/10) * t)))
      ((1 + t) - 1/10 * (10 * t - 90 + (E₀ + 90) * exp (-((1/10) * t)))) t := by
  have h := (((hasDerivAt_id' t).const_mul 10).sub_const 90).add
    ((hasDerivAt_exp_neg_mul (1/10) t).const_mul (E₀ + 90))
  exact h.congr_deriv (by ring)

/-- With `ι = 1 + t` and `μ = 0.1`, every solution grows without limit, from any `E(0)`:
no plateau. -/
theorem origL_grows {E : ℝ → ℝ}
    (hE : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt E ((1 + t) - 1/10 * E t) (Ici 0) t) :
    Tendsto E atTop atTop ∧ ¬ ∃ L, Tendsto E atTop (𝓝 L) := by
  have heq := ode_unique (ι := fun t => 1 + t) (μ := 1/10) (convex_Ici 0) hE
    (fun s _ => (origL_solution (E 0) s).hasDerivWithinAt) (mem_Ici.mpr le_rfl)
    (by simp only [mul_zero, neg_zero, exp_zero, mul_one]; ring)
  have hlow : ∀ t ∈ Ici (0:ℝ), 10 * t + (-90 - |E 0 + 90|) ≤ E t := by
    intro t ht
    rw [heq t ht]
    have ht0 : (0:ℝ) ≤ t := ht
    have h1 : |(E 0 + 90) * exp (-((1/10) * t))| ≤ |E 0 + 90| := by
      rw [abs_mul, abs_of_pos (exp_pos _)]
      exact mul_le_of_le_one_right (abs_nonneg _) (exp_le_one_iff.mpr (by linarith))
    linarith [neg_abs_le ((E 0 + 90) * exp (-((1/10) * t)))]
  have hT : Tendsto E atTop atTop :=
    tendsto_atTop_mono' atTop (eventually_atTop.2 ⟨0, fun t ht => hlow t ht⟩)
      (tendsto_affine (by norm_num))
  exact ⟨hT, no_limit_of_atTop hT⟩

/-- **P3 "as first stated", second half**: "otherwise [unbounded introduction] risk plateaus" is
false: `ι = 1 + t`, `μ = 0.1` from an empty stock has no limit. -/
theorem p3_orig_second_half_false :
    ¬ ∀ (ι μ E : ℝ → ℝ),
      (∀ t ∈ Ici (0:ℝ), 0 < μ t ∧ 0 ≤ ι t ∧ HasDerivWithinAt E (ι t - μ t * E t) (Ici 0) t) →
      E 0 = 0 → ¬ BddAbove (ι '' Ici 0) → ∃ L, Tendsto E atTop (𝓝 L) := by
  intro h
  have hunb : ¬ BddAbove ((fun t : ℝ => 1 + t) '' Ici 0) := by
    rintro ⟨M, hM⟩
    have := hM ⟨max M 0 + 1, mem_Ici.mpr (by linarith [le_max_right M 0]), rfl⟩
    simp only at this
    linarith [le_max_left M 0]
  have hE : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt
      (fun t => 10 * t - 90 + ((0:ℝ) + 90) * exp (-((1/10) * t)))
      ((1 + t) - 1/10 * (10 * t - 90 + ((0:ℝ) + 90) * exp (-((1/10) * t)))) (Ici 0) t :=
    fun t _ => (origL_solution 0 t).hasDerivWithinAt
  exact (origL_grows hE).2 (h (fun t => 1 + t) (fun _ => 1/10) _
    (fun t ht => ⟨by norm_num, by linarith [mem_Ici.mp ht], hE t ht⟩) (by simp) hunb)

/-- A finite-horizon witness for the second half (ours, not the paper's): on `[0, 1)` with
`μ = 1`, `ι = (1 − t)^{−2} + (1 − t)^{−1} − 1 ≥ 1`, the stock `E = (1 − t)^{−1} − 1` from
`E(0) = 0` grows without limit as `t → 1⁻`. -/
noncomputable def ιG (t : ℝ) : ℝ := ((1 - t) ^ 2)⁻¹ + (1 - t)⁻¹ - 1
noncomputable def EG (t : ℝ) : ℝ := (1 - t)⁻¹ - 1

theorem origG_solves : ∀ t ∈ Ico (0:ℝ) 1, HasDerivAt EG (ιG t - 1 * EG t) t := by
  intro t ht
  have h : (1:ℝ) - t ≠ 0 := (sub_pos.mpr ht.2).ne'
  have hd := (((hasDerivAt_const t (1:ℝ)).sub (hasDerivAt_id' t)).inv h).sub_const 1
  exact hd.congr_deriv (by simp only [ιG, EG, Pi.sub_apply]; field_simp; ring)

theorem origG_iota_ge_one : ∀ t ∈ Ico (0:ℝ) 1, 1 ≤ ιG t := by
  intro t ht
  have hu : 0 < 1 - t := sub_pos.mpr ht.2
  have hu1 : 1 - t ≤ 1 := by linarith [ht.1]
  have h1 : 1 ≤ (1 - t)⁻¹ := (one_le_inv₀ hu).mpr hu1
  have h2 : 1 ≤ ((1 - t) ^ 2)⁻¹ := (one_le_inv₀ (pow_pos hu 2)).mpr (pow_le_one₀ hu.le hu1)
  simp only [ιG]; linarith

theorem origG_tendsto : Tendsto EG (𝓝[<] 1) atTop := by
  have h1 : Tendsto (fun t : ℝ => 1 - t) (𝓝[<] 1) (𝓝[>] 0) := by
    apply tendsto_nhdsWithin_of_tendsto_nhds_of_eventually_within
    · have h0 : Tendsto (fun t : ℝ => 1 - t) (𝓝 1) (𝓝 (1 - 1)) :=
        (continuous_const.sub continuous_id).tendsto 1
      rw [sub_self] at h0
      exact h0.mono_left nhdsWithin_le_nhds
    · filter_upwards [self_mem_nhdsWithin] with t ht
      exact sub_pos.mpr (mem_Iio.mp ht)
  have h2 := tendsto_inv_nhdsGT_zero.comp h1
  rw [Filter.tendsto_atTop]
  intro b
  filter_upwards [Filter.tendsto_atTop.mp h2 (b + 1)] with t ht
  simp only [Function.comp_apply] at ht
  simp only [EG]; linarith

/-- **P3 "as first stated", second half, on a finite horizon** (with the witness above):
unbounded introduction on `[0, 1)` need not give a plateau — the stock has no finite limit at
`T_A = 1`. -/
theorem p3_orig_second_half_false_finite :
    ¬ ∀ (ι μ E : ℝ → ℝ),
      (∀ t ∈ Ico (0:ℝ) 1, 0 < μ t ∧ 0 ≤ ι t ∧ HasDerivAt E (ι t - μ t * E t) t) →
      E 0 = 0 → ¬ BddAbove (ι '' Ico 0 1) → ∃ L, Tendsto E (𝓝[<] 1) (𝓝 L) := by
  intro h
  have hmem : ∀ᶠ t in 𝓝[<] (1:ℝ), t ∈ Ioo (0:ℝ) 1 := Ioo_mem_nhdsLT zero_lt_one
  have hunb : ¬ BddAbove (ιG '' Ico 0 1) := by
    rintro ⟨M, hM⟩
    obtain ⟨t, ht, htI⟩ :=
      ((Filter.tendsto_atTop.mp origG_tendsto (M + 1)).and hmem).exists
    have hle := hM ⟨t, Ioo_subset_Ico_self htI, rfl⟩
    have hu : 0 < 1 - t := sub_pos.mpr htI.2
    have : 0 ≤ ((1 - t) ^ 2)⁻¹ := inv_nonneg.mpr (pow_pos hu 2).le
    simp only [ιG, EG] at hle ht
    linarith
  obtain ⟨L, hL⟩ := h ιG (fun _ => 1) EG
    (fun t ht => ⟨one_pos, by linarith [origG_iota_ge_one t ht], origG_solves t ht⟩)
    (by simp [EG]) hunb
  obtain ⟨t, h1, h2⟩ :=
    ((hL.eventually (gt_mem_nhds (lt_add_one L))).and
      (Filter.tendsto_atTop.mp origG_tendsto (L + 1))).exists
  linarith

/-- **§4.5 (line 153)**: with a time-varying exploitation intensity `φ`, the hazard `φE` rises at
`t` iff `φ′E + φE′ > 0`; with `φ, E > 0` this is `φ′/φ > −E′/E`, so it can rise while the stock
falls. Algebraic content (one product rule). -/
theorem body153_hazard_rises_iff {φ E : ℝ → ℝ} {φ' E' t : ℝ} (hφ : HasDerivAt φ φ' t)
    (hE : HasDerivAt E E' t) (hφp : 0 < φ t) (hEp : 0 < E t) :
    HasDerivAt (fun s => φ s * E s) (φ' * E t + φ t * E') t ∧
      (0 < φ' * E t + φ t * E' ↔ -(E' / E t) < φ' / φ t) := by
  refine ⟨hφ.mul hE, ?_⟩
  rw [neg_lt_iff_pos_add, div_add_div _ _ hφp.ne' hEp.ne',
    div_pos_iff_of_pos_right (mul_pos hφp hEp)]

/-- **Line 153's "can"**, an instance: with `φ = e^{2t}` and `E = e^{−t}` (which solves A5 with
`ι = 0`, `μ = 1`), the stock falls while the hazard `φE = e^t` rises, at every date. -/
theorem body153_example (t : ℝ) :
    HasDerivAt (fun s => exp (-s)) (0 - 1 * exp (-t)) t ∧ 0 - 1 * exp (-t) < 0 ∧
      HasDerivAt (fun s => exp (2 * s) * exp (-s)) (exp t) t ∧ 0 < exp t := by
  refine ⟨(hasDerivAt_neg t).exp.congr_deriv (by ring), by linarith [exp_pos (-t)], ?_,
    exp_pos t⟩
  have e : exp (2 * t) * exp (-t) = exp t := by rw [← exp_add]; ring_nf
  refine ((hasDerivAt_exp_mul 2 t).mul (hasDerivAt_neg t).exp).congr_deriv ?_
  rw [← e]; ring

/-- **899, plain terms, first sentence**: the hazard `h = φE` has derivative `φ(ι − μE)`, so it
rises at a date iff new flaws arrive faster than removal takes them out (`ι > μE`), and falls iff
slower. Algebraic content: the sign of `h′` read off A5. -/
theorem p3_plain_sign {ι μ E : ℝ → ℝ} {φ t : ℝ} {I : Set ℝ} (hφ : 0 < φ)
    (hE : HasDerivWithinAt E (ι t - μ t * E t) I t) :
    HasDerivWithinAt (fun s => φ * E s) (φ * (ι t - μ t * E t)) I t ∧
      (0 < φ * (ι t - μ t * E t) ↔ μ t * E t < ι t) ∧
      (φ * (ι t - μ t * E t) < 0 ↔ ι t < μ t * E t) := by
  refine ⟨hE.const_mul φ, ⟨fun h => ?_, fun h => ?_⟩, ⟨fun h => ?_, fun h => ?_⟩⟩
  · by_contra hc; nlinarith [not_lt.mp hc]
  · nlinarith
  · by_contra hc; nlinarith [not_lt.mp hc]
  · nlinarith

/-- **"Bounded introduction is not enough for a peak"**: with `ι = 1`, `μ = 0.5` no solution
rises and later falls; from `E(0) < 2` (e.g. an empty stock) it rises strictly to the plateau 2. -/
theorem origC_no_peak {E : ℝ → ℝ}
    (hE : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt E (1 - 1/2 * E t) (Ici 0) t) :
    ¬ RisesFalls E (Ici 0) ∧
      (E 0 < 2 → StrictMonoOn E (Ici 0) ∧ Tendsto E atTop (𝓝 2) ∧ ∀ t ∈ Ici (0:ℝ), E t < 2) := by
  have h2 : ∀ t ∈ Ici (0:ℝ),
      HasDerivWithinAt (fun _ => (2:ℝ)) (1 - 1/2 * (fun _ => (2:ℝ)) t) (Ici 0) t :=
    fun t _ => (hasDerivWithinAt_const t _ (2:ℝ)).congr_deriv (by norm_num)
  have hd := ode_diff (ι := fun _ => 1) (convex_Ici 0) hE h2 (mem_Ici.mpr le_rfl)
  have hform : ∀ t ∈ Ici (0:ℝ), E t = 2 + (E 0 - 2) * exp (-(1/2 * t)) := by
    intro t ht
    have h := hd t ht
    simp only [mul_zero, exp_zero, one_mul] at h
    have hp : exp (1/2 * t) * exp (-(1/2 * t)) = 1 := by rw [← exp_add]; simp
    have : E t - 2 = (E 0 - 2) * exp (-(1/2 * t)) := by
      rw [← h, mul_comm (exp (1/2 * t)), mul_assoc, hp, mul_one]
    linarith
  have hdec : ∀ s t : ℝ, s < t → exp (-(1/2 * t)) < exp (-(1/2 * s)) :=
    fun s t h => exp_lt_exp.mpr (by linarith)
  refine ⟨?_, ?_⟩
  · rintro ⟨a, b, c, ha, hb, hc, hab, hbc, h1, h2⟩
    rw [hform a ha, hform b hb] at h1
    rw [hform c hc, hform b hb] at h2
    have e1 := hdec a b hab
    have e2 := hdec b c hbc
    by_cases hk : 0 ≤ E 0 - 2
    · nlinarith [mul_nonneg hk (sub_pos.mpr e1).le]
    · nlinarith [mul_pos (neg_pos.mpr (not_le.mp hk)) (sub_pos.mpr e2)]
  · intro hlt
    have hk : E 0 - 2 < 0 := by linarith
    refine ⟨?_, ?_, ?_⟩
    · intro s hs t ht hst
      rw [hform s hs, hform t ht]
      nlinarith [mul_lt_mul_of_neg_left (hdec s t hst) hk]
    · have hl := (tendsto_const_nhds (x := (2:ℝ))).add
        ((tendsto_exp_neg_mul (by norm_num : (0:ℝ) < 1/2)).const_mul (E 0 - 2))
      rw [mul_zero, add_zero] at hl
      exact hl.congr' (eventually_atTop.2 ⟨0, fun t ht => (hform t ht).symm⟩)
    · intro t ht
      rw [hform t ht]
      nlinarith [mul_neg_of_neg_of_pos hk (exp_pos (-(1/2 * t)))]

end Orig

/-! ## A.7, removal limited by triage capacity: `E′ = ι − min(μE, Q)` -/

section Triage

variable {EQ : ℝ → ℝ} {φ μ γ ι₀ ι₁ Q : ℝ}

lemma iotaP_gt (hι : ι₁ < ι₀) (t : ℝ) : ι₁ < iotaP ι₀ ι₁ γ t := by
  simp only [iotaP]
  have := mul_pos (sub_pos.mpr hι) (exp_pos (-(γ * t)))
  linarith

/-- **A.7 triage, `ι₁ > Q`**: every capped path grows without limit; no plateau. -/
theorem a7_triage_unbounded (hι : ι₁ < ι₀) (hQ : Q < ι₁)
    (hE : ∀ t ∈ Ici (0:ℝ),
      HasDerivWithinAt EQ (iotaP ι₀ ι₁ γ t - min (μ * EQ t) Q) (Ici 0) t) :
    Tendsto EQ atTop atTop ∧ ¬ ∃ L, Tendsto EQ atTop (𝓝 L) := by
  set F : ℝ → ℝ := fun t => EQ t - (ι₁ - Q) * t with hF
  have hFd : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt F
      (iotaP ι₀ ι₁ γ t - min (μ * EQ t) Q - (ι₁ - Q)) (Ici 0) t := fun t ht =>
    ((hE t ht).sub (((hasDerivAt_id' t).const_mul (ι₁ - Q)).hasDerivWithinAt)).congr_deriv
      (by ring)
  have hmono : MonotoneOn F (Ici 0) := monotoneOn_of_deriv_nonneg (convex_Ici 0)
    (continuousOn_of_hasDerivWithinAt hFd)
    (fun x hx => (hasDerivAt_of_interior hFd hx).differentiableAt.differentiableWithinAt)
    (fun x hx => by
      rw [(hasDerivAt_of_interior hFd hx).deriv]
      linarith [iotaP_gt (γ := γ) hι x, min_le_right (μ * EQ x) Q])
  have hlow : ∀ t ∈ Ici (0:ℝ), (ι₁ - Q) * t + EQ 0 ≤ EQ t := fun t ht => by
    have := hmono (mem_Ici.mpr le_rfl) ht (mem_Ici.mp ht)
    simp only [hF, mul_zero, sub_zero] at this
    linarith
  have hT : Tendsto EQ atTop atTop :=
    tendsto_atTop_mono' atTop (eventually_atTop.2 ⟨0, fun t ht => hlow t ht⟩)
      (tendsto_affine (sub_pos.mpr hQ))
  exact ⟨hT, no_limit_of_atTop hT⟩

/-- **A.7 triage, "no lower"**: a capped path lies on or above the uncapped one with the same
inflow from the same (or a lower) start, at every date. -/
theorem a7_triage_no_lower {E : ℝ → ℝ} {ι : ℝ → ℝ}
    (hE : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt E (ι t - μ * E t) (Ici 0) t)
    (hEQ : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt EQ (ι t - min (μ * EQ t) Q) (Ici 0) t)
    (h0 : E 0 ≤ EQ 0) : ∀ t ∈ Ici (0:ℝ), E t ≤ EQ t := by
  set F : ℝ → ℝ := fun t => exp (μ * t) * (EQ t - E t) with hF
  have hFd : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt F
      (exp (μ * t) * (μ * EQ t - min (μ * EQ t) Q)) (Ici 0) t := by
    intro t ht
    have := ((hasDerivAt_exp_mul μ t).hasDerivWithinAt (s := Ici 0)).mul
      ((hEQ t ht).sub (hE t ht))
    convert this using 1; simp only [Pi.sub_apply]; ring
  have hmono : MonotoneOn F (Ici 0) := monotoneOn_of_deriv_nonneg (convex_Ici 0)
    (continuousOn_of_hasDerivWithinAt hFd)
    (fun x hx => (hasDerivAt_of_interior hFd hx).differentiableAt.differentiableWithinAt)
    (fun x hx => by
      rw [(hasDerivAt_of_interior hFd hx).deriv]
      exact mul_nonneg (exp_pos _).le (sub_nonneg.mpr (min_le_left _ _)))
  intro t ht
  have := hmono (mem_Ici.mpr le_rfl) ht (mem_Ici.mp ht)
  simp only [hF, mul_zero, exp_zero, one_mul] at this
  have hpos := exp_pos (μ * t)
  by_contra hc
  have : exp (μ * t) * (EQ t - E t) < 0 := mul_neg_of_pos_of_neg hpos (by linarith [not_le.mp hc])
  linarith

/-- **A.7 triage, "any peak is no lower than without the cap"**: the capped path's maximum (if
attained) is at least every value of the uncapped path, its peak included. -/
theorem a7_triage_peak_no_lower {E : ℝ → ℝ} {ι : ℝ → ℝ}
    (hE : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt E (ι t - μ * E t) (Ici 0) t)
    (hEQ : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt EQ (ι t - min (μ * EQ t) Q) (Ici 0) t)
    (h0 : E 0 ≤ EQ 0) {tq : ℝ} (hmax : IsMaxOn EQ (Ici 0) tq) :
    ∀ t ∈ Ici (0:ℝ), E t ≤ EQ tq :=
  fun t ht => (a7_triage_no_lower hE hEQ h0 t ht).trans (hmax ht)

/-- **A.7 triage, "no lower", without any premise on the capped path**: every upper bound of the
capped path bounds the uncapped one, so the capped path's highest level (its supremum) is no lower
than the uncapped peak. -/
theorem a7_triage_sup_no_lower {E : ℝ → ℝ} {ι : ℝ → ℝ}
    (hE : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt E (ι t - μ * E t) (Ici 0) t)
    (hEQ : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt EQ (ι t - min (μ * EQ t) Q) (Ici 0) t)
    (h0 : E 0 ≤ EQ 0) {M : ℝ} (hM : ∀ t ∈ Ici (0:ℝ), EQ t ≤ M) : ∀ t ∈ Ici (0:ℝ), E t ≤ M :=
  fun t ht => (a7_triage_no_lower hE hEQ h0 t ht).trans (hM t ht)

/-- **A.7 triage**: at the uncapped peak date the capped path is at least the uncapped peak
height (the premise is on the uncapped path, which P3(iii) proves: `p3iii_peak_date_ne/_eq`). -/
theorem a7_triage_reaches_uncapped_peak {E : ℝ → ℝ} {ι : ℝ → ℝ}
    (hE : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt E (ι t - μ * E t) (Ici 0) t)
    (hEQ : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt EQ (ι t - min (μ * EQ t) Q) (Ici 0) t)
    (h0 : E 0 ≤ EQ 0) {tp : ℝ} (htp : tp ∈ Ici (0:ℝ)) (hmax : IsMaxOn E (Ici 0) tp) :
    ∀ s ∈ Ici (0:ℝ), E s ≤ EQ tp :=
  fun s hs => (isMaxOn_iff.mp hmax s hs).trans (a7_triage_no_lower hE hEQ h0 tp htp)

/-- **A.7 triage, `ι₁ < Q`**: the plateau `φι₁/μ` is unchanged by the cap. -/
theorem a7_triage_plateau (hμ : 0 < μ) (hγ : 0 < γ) (hQ : ι₁ < Q)
    (hE : ∀ t ∈ Ici (0:ℝ),
      HasDerivWithinAt EQ (iotaP ι₀ ι₁ γ t - min (μ * EQ t) Q) (Ici 0) t) :
    Tendsto (fun t => φ * EQ t) atTop (𝓝 (φ * ι₁ / μ)) := by
  have haQ : (ι₁ + Q) / 2 < Q := by linarith
  have hιa : ι₁ < (ι₁ + Q) / 2 := by linarith
  obtain ⟨T₀', hT₀'⟩ := eventually_atTop.mp
    ((iotaP_tendsto (ι₀ := ι₀) hγ).eventually (gt_mem_nhds hιa))
  have hT₀0 : (0:ℝ) ≤ max T₀' 0 := le_max_right _ _
  have hiota : ∀ t, max T₀' 0 ≤ t → iotaP ι₀ ι₁ γ t < (ι₁ + Q) / 2 :=
    fun t ht => hT₀' t (le_trans (le_max_left _ _) ht)
  have hEc : ContinuousOn EQ (Ici 0) := continuousOn_of_hasDerivWithinAt hE
  have hQa : 0 < Q - (ι₁ + Q) / 2 := sub_pos.mpr haQ
  -- Step 1: the cap stops binding at some date after `T₀`.
  obtain ⟨T₁, hT₁, hcap⟩ : ∃ T₁, max T₀' 0 ≤ T₁ ∧ μ * EQ T₁ ≤ Q := by
    by_contra hc
    have hc' : ∀ t, max T₀' 0 ≤ t → Q < μ * EQ t :=
      fun t ht => not_le.mp (fun h => hc ⟨t, ht, h⟩)
    set T₀ := max T₀' 0 with hT₀
    set F : ℝ → ℝ := fun t => EQ t + (Q - (ι₁ + Q) / 2) * t with hF
    have hFd : ∀ t ∈ Ici T₀, HasDerivWithinAt F
        (iotaP ι₀ ι₁ γ t - min (μ * EQ t) Q + (Q - (ι₁ + Q) / 2)) (Ici T₀) t := fun t ht =>
      (((hE t (le_trans hT₀0 ht)).mono (Ici_subset_Ici.mpr hT₀0)).add
        (((hasDerivAt_id' t).const_mul (Q - (ι₁ + Q) / 2)).hasDerivWithinAt)).congr_deriv
        (by ring)
    have hanti : AntitoneOn F (Ici T₀) := antitoneOn_of_deriv_nonpos (convex_Ici _)
      (continuousOn_of_hasDerivWithinAt hFd)
      (fun x hx => (hasDerivAt_of_interior hFd hx).differentiableAt.differentiableWithinAt)
      (fun x hx => by
        rw [(hasDerivAt_of_interior hFd hx).deriv]
        rw [interior_Ici] at hx
        have h1 := hc' x (le_of_lt hx)
        have h2 := hiota x (le_of_lt hx)
        rw [min_eq_right h1.le]; linarith)
    set D := |EQ T₀| + |Q / μ| with hD
    have hdiv : 0 ≤ D / (Q - (ι₁ + Q) / 2) := div_nonneg (by positivity) hQa.le
    have htT : T₀ ≤ T₀ + D / (Q - (ι₁ + Q) / 2) + 1 := by linarith
    have hF' := hanti (mem_Ici.mpr le_rfl) (mem_Ici.mpr htT) htT
    simp only [hF] at hF'
    have hkey : (Q - (ι₁ + Q) / 2) * (D / (Q - (ι₁ + Q) / 2)) = D := mul_div_cancel₀ _ hQa.ne'
    have hEt : EQ (T₀ + D / (Q - (ι₁ + Q) / 2) + 1) ≤ Q / μ := by
      nlinarith [le_abs_self (EQ T₀), neg_abs_le (Q / μ)]
    have h3 := hc' _ htT
    rw [le_div_iff₀ hμ] at hEt
    linarith
  have hT₁0 : 0 ≤ T₁ := le_trans hT₀0 hT₁
  -- Step 2: once `μE ≤ Q`, it stays so.
  have hstay : ∀ t, T₁ ≤ t → μ * EQ t ≤ Q := by
    intro t ht
    have := image_le_of_deriv_right_lt_deriv_boundary (f := fun s => μ * EQ s)
      (f' := fun s => μ * (iotaP ι₀ ι₁ γ s - min (μ * EQ s) Q)) (a := T₁) (b := t)
      (B := fun _ => Q) (B' := fun _ => 0)
      (continuousOn_const.mul (hEc.mono (fun s hs => mem_Ici.mpr (le_trans hT₁0 hs.1))))
      (fun s hs => ((hE s (le_trans hT₁0 hs.1)).mono
        (Ici_subset_Ici.mpr (le_trans hT₁0 hs.1))).const_mul μ)
      hcap (fun s => hasDerivAt_const s Q)
      (fun s hs heq => by
        rw [heq, min_self]
        exact mul_neg_of_pos_of_neg hμ (by linarith [hiota s (le_trans hT₁ hs.1)]))
    exact this ⟨ht, le_rfl⟩
  -- Step 3: from `T₁` on the path solves the uncapped equation.
  have hlin : ∀ t ∈ Ici T₁, HasDerivWithinAt EQ (iotaP ι₀ ι₁ γ t - μ * EQ t) (Ici T₁) t := by
    intro t ht
    have := (hE t (le_trans hT₁0 ht)).mono (Ici_subset_Ici.mpr hT₁0)
    rwa [min_eq_left (hstay t ht)] at this
  have hd := ode_diff (convex_Ici T₁) hlin
    (fun s _ => (esol_hasDerivAt (E₀ := 0) hμ.ne' s).hasDerivWithinAt) (mem_Ici.mpr le_rfl)
  have hform : ∀ t ∈ Ici T₁, EQ t = Esol μ γ ι₀ ι₁ 0 t +
      exp (μ * T₁) * (EQ T₁ - Esol μ γ ι₀ ι₁ 0 T₁) * exp (-(μ * t)) := by
    intro t ht
    have h := hd t ht
    have hp : exp (μ * t) * exp (-(μ * t)) = 1 := by rw [← exp_add]; simp
    rw [← h, mul_comm (exp (μ * t)), mul_assoc, hp, mul_one]
    ring
  have hl := (esol_tendsto (E₀ := 0) (ι₀ := ι₀) (ι₁ := ι₁) hμ hγ).add
    ((tendsto_exp_neg_mul hμ).const_mul (exp (μ * T₁) * (EQ T₁ - Esol μ γ ι₀ ι₁ 0 T₁)))
  rw [mul_zero, add_zero] at hl
  have hEl : Tendsto EQ atTop (𝓝 (ι₁ / μ)) :=
    hl.congr' (eventually_atTop.2 ⟨T₁, fun t ht => (hform t ht).symm⟩)
  rw [mul_div_assoc]
  exact hEl.const_mul φ

/-! ### Existence and uniqueness of the capped path -/

/-- The capped field `ι(t) − min(μx, Q)`. -/
noncomputable def capField (μ γ ι₀ ι₁ Q : ℝ) (t x : ℝ) : ℝ := iotaP ι₀ ι₁ γ t - min (μ * x) Q

/-- The capped field with `x` clamped below at 0: bounded, and equal to `capField` for `x ≥ 0`. -/
noncomputable def capFieldC (μ γ ι₀ ι₁ Q : ℝ) (t x : ℝ) : ℝ := capField μ γ ι₀ ι₁ Q t (max x 0)

lemma capField_lipschitz (hμ : 0 ≤ μ) (t : ℝ) :
    LipschitzWith (Real.toNNReal μ) (capField μ γ ι₀ ι₁ Q t) := by
  refine LipschitzWith.of_dist_le_mul fun x y => ?_
  rw [Real.coe_toNNReal _ hμ, Real.dist_eq, Real.dist_eq]
  simp only [capField]
  have h := abs_min_sub_min_le_max (μ * x) Q (μ * y) Q
  rw [sub_self, abs_zero, max_eq_left (abs_nonneg _), ← mul_sub, abs_mul, abs_of_nonneg hμ] at h
  rw [show iotaP ι₀ ι₁ γ t - min (μ * x) Q - (iotaP ι₀ ι₁ γ t - min (μ * y) Q) =
    -(min (μ * x) Q - min (μ * y) Q) by ring, abs_neg]
  exact h

lemma capFieldC_lipschitz (hμ : 0 ≤ μ) (t : ℝ) :
    LipschitzWith (Real.toNNReal μ) (capFieldC μ γ ι₀ ι₁ Q t) := by
  have h1 : LipschitzWith 1 (fun x : ℝ => max x 0) := LipschitzWith.id.max_const 0
  have := (capField_lipschitz (γ := γ) (ι₀ := ι₀) (ι₁ := ι₁) (Q := Q) hμ t).comp h1
  rw [mul_one] at this
  exact this

lemma capFieldC_norm_le (hμ : 0 ≤ μ) (hγ : 0 ≤ γ) (h1 : 0 ≤ ι₁) (hι : ι₁ < ι₀)
    {t : ℝ} (ht : 0 ≤ t) (x : ℝ) : ‖capFieldC μ γ ι₀ ι₁ Q t x‖ ≤ ι₀ + |Q| := by
  have hlo := iotaP_gt (γ := γ) hι t
  have hhi : iotaP ι₀ ι₁ γ t ≤ ι₀ := by
    simp only [iotaP]
    have : exp (-(γ * t)) ≤ 1 := exp_le_one_iff.mpr (by nlinarith)
    nlinarith [sub_pos.mpr hι]
  have hm0 : -|Q| ≤ min (μ * max x 0) Q :=
    le_min (by linarith [mul_nonneg hμ (le_max_right x 0), abs_nonneg Q]) (neg_abs_le Q)
  have hmQ : min (μ * max x 0) Q ≤ |Q| := (min_le_right _ _).trans (le_abs_self Q)
  rw [Real.norm_eq_abs, abs_le]
  simp only [capFieldC, capField]
  constructor <;> linarith

/-- Picard–Lindelöf on `[0, T]` for the clamped field, from an empty stock. -/
lemma capC_exists_Icc (hμ : 0 ≤ μ) (hγ : 0 ≤ γ) (h1 : 0 ≤ ι₁) (hι : ι₁ < ι₀)
    {T : ℝ} (hT : 0 ≤ T) :
    ∃ α : ℝ → ℝ, α 0 = 0 ∧
      ∀ t ∈ Icc 0 T, HasDerivWithinAt α (capFieldC μ γ ι₀ ι₁ Q t (α t)) (Icc 0 T) t := by
  have hL : 0 ≤ ι₀ + |Q| := by linarith [abs_nonneg Q]
  let t₀ : Icc (0:ℝ) T := ⟨0, le_rfl, hT⟩
  have hPL : IsPicardLindelof (capFieldC μ γ ι₀ ι₁ Q) t₀ (0:ℝ) (Real.toNNReal ((ι₀ + |Q|) * T)) 0
      (Real.toNNReal (ι₀ + |Q|)) (Real.toNNReal μ) :=
    { lipschitzOnWith := fun t _ => (capFieldC_lipschitz hμ t).lipschitzOnWith
      continuousOn := fun x _ => by
        apply Continuous.continuousOn
        simp only [capFieldC, capField, iotaP]
        fun_prop
      norm_le := fun t ht x _ => by
        rw [Real.coe_toNNReal _ hL]; exact capFieldC_norm_le hμ hγ h1 hι ht.1 x
      mul_max_le := by
        simp only [t₀, sub_zero, NNReal.coe_zero, Real.coe_toNNReal _ hL,
          Real.coe_toNNReal _ (mul_nonneg hL hT)]
        rw [max_eq_left (by linarith)] }
  obtain ⟨α, hα0, hα⟩ := IsPicardLindelof.exists_eq_forall_mem_Icc_hasDerivWithinAt₀ hPL
  exact ⟨α, hα0, hα⟩

lemma hasDerivWithinAt_Ici_of_Icc {f : ℝ → ℝ} {f' a b t : ℝ}
    (h : HasDerivWithinAt f f' (Icc a b) t) (ht : t ∈ Ico a b) :
    HasDerivWithinAt f f' (Ici t) t :=
  h.mono_of_mem_nhdsWithin (mem_of_superset (Icc_mem_nhdsGE ht.2) (Icc_subset_Icc ht.1 le_rfl))

/-- **A.7 triage, existence of the capped path**: from an empty stock, with P3(iii)'s inflow,
constant `μ > 0` and any `Q`, a solution of `E′ = ι − min(μE, Q)` exists on the untruncated
horizon `t ≥ 0`. -/
theorem a7_triage_exists (hμ : 0 < μ) (hγ : 0 ≤ γ) (h1 : 0 ≤ ι₁) (hι : ι₁ < ι₀) :
    ∃ P : ℝ → ℝ, P 0 = 0 ∧ ∀ t ∈ Ici (0:ℝ),
      HasDerivWithinAt P (iotaP ι₀ ι₁ γ t - min (μ * P t) Q) (Ici 0) t := by
  choose sol hsol0 hsol using fun n : ℕ =>
    capC_exists_Icc (Q := Q) hμ.le hγ h1 hι (T := n) n.cast_nonneg
  -- Any two pieces agree where both are defined (uniqueness for a Lipschitz field).
  have hagree : ∀ m n : ℕ, EqOn (sol m) (sol n) (Icc 0 (min (m:ℝ) n)) := by
    intro m n
    have hm : Icc (0:ℝ) (min m n) ⊆ Icc 0 m := Icc_subset_Icc le_rfl (min_le_left _ _)
    have hn : Icc (0:ℝ) (min m n) ⊆ Icc 0 n := Icc_subset_Icc le_rfl (min_le_right _ _)
    refine ODE_solution_unique (fun t => capFieldC_lipschitz (γ := γ) (ι₀ := ι₀) (ι₁ := ι₁)
      (Q := Q) hμ.le t)
      (fun t ht => ((hsol m t (hm ht)).continuousWithinAt).mono hm)
      (fun t ht => hasDerivWithinAt_Ici_of_Icc (hsol m t (hm (Ico_subset_Icc_self ht)))
        ⟨ht.1, lt_of_lt_of_le ht.2 (min_le_left _ _)⟩)
      (fun t ht => ((hsol n t (hn ht)).continuousWithinAt).mono hn)
      (fun t ht => hasDerivWithinAt_Ici_of_Icc (hsol n t (hn (Ico_subset_Icc_self ht)))
        ⟨ht.1, lt_of_lt_of_le ht.2 (min_le_right _ _)⟩)
      (by rw [hsol0, hsol0])
  set P : ℝ → ℝ := fun t => sol (⌈t⌉₊ + 1) t with hP
  have hloc : ∀ t, 0 ≤ t → ∀ s ∈ Icc (0:ℝ) (t + 1), P s = sol (⌈t⌉₊ + 2) s := by
    intro t ht s hs
    simp only [hP]
    apply hagree
    refine ⟨hs.1, le_min ?_ ?_⟩
    · push_cast; linarith [Nat.le_ceil s]
    · push_cast; linarith [Nat.le_ceil t, hs.2]
  -- `P` solves the clamped equation on `t ≥ 0`.
  have hC : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt P (capFieldC μ γ ι₀ ι₁ Q t (P t)) (Ici 0) t := by
    intro t ht
    have ht0 : (0:ℝ) ≤ t := ht
    have hN : t < ((⌈t⌉₊ + 2 : ℕ) : ℝ) := by push_cast; linarith [Nat.le_ceil t]
    have hd := hsol (⌈t⌉₊ + 2) t ⟨ht0, hN.le⟩
    rw [← Ici_inter_Iic, hasDerivWithinAt_inter (Iic_mem_nhds hN)] at hd
    have heq : P t = sol (⌈t⌉₊ + 2) t := hloc t ht0 t ⟨ht0, by linarith⟩
    rw [heq]
    refine hd.congr_of_eventuallyEq ?_ heq
    filter_upwards [inter_mem_nhdsWithin (Ici (0:ℝ)) (Iio_mem_nhds (lt_add_one t))] with s hs
    exact hloc t ht0 s ⟨hs.1, hs.2.le⟩
  have hP0 : P 0 = 0 := by simp only [hP]; exact hsol0 _
  -- The clamped path never goes negative, so the clamp never binds.
  have hnn : ∀ t ∈ Ici (0:ℝ), 0 ≤ P t := by
    intro t ht
    have hcont : ContinuousOn P (Ici 0) := fun s hs => (hC s hs).continuousWithinAt
    have := image_le_of_deriv_right_lt_deriv_boundary (f := fun s => -P s)
      (f' := fun s => -capFieldC μ γ ι₀ ι₁ Q s (P s)) (a := 0) (b := t)
      (hcont.neg.mono Icc_subset_Ici_self)
      (fun s hs => ((hC s hs.1).mono (Ici_subset_Ici.mpr hs.1)).neg)
      (B := fun _ => 0) (B' := fun _ => 0) (by simp [hP0]) (fun s => hasDerivAt_const s 0)
      (fun s _ heq => by
        have h0 : P s = 0 := by linarith
        rw [h0]
        simp only [capFieldC, capField, max_self, mul_zero]
        linarith [iotaP_gt (γ := γ) hι s, min_le_left (0:ℝ) Q])
    have := this ⟨ht, le_rfl⟩
    linarith
  refine ⟨P, hP0, fun t ht => ?_⟩
  have := hC t ht
  simpa only [capFieldC, capField, max_eq_left (hnn t ht)] using this

/-- **A.7 triage, uniqueness**: two capped paths with the same starting stock agree on `t ≥ 0`. -/
theorem a7_triage_unique (hμ : 0 ≤ μ) {E₁ E₂ : ℝ → ℝ}
    (h₁ : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt E₁ (iotaP ι₀ ι₁ γ t - min (μ * E₁ t) Q) (Ici 0) t)
    (h₂ : ∀ t ∈ Ici (0:ℝ), HasDerivWithinAt E₂ (iotaP ι₀ ι₁ γ t - min (μ * E₂ t) Q) (Ici 0) t)
    (h0 : E₁ 0 = E₂ 0) : ∀ t ∈ Ici (0:ℝ), E₁ t = E₂ t := by
  intro t ht
  have := ODE_solution_unique (v := capField μ γ ι₀ ι₁ Q) (a := 0) (b := t)
    (fun s => capField_lipschitz hμ s)
    (fun s hs => (h₁ s hs.1).continuousWithinAt.mono Icc_subset_Ici_self)
    (fun s hs => (h₁ s hs.1).mono (Ici_subset_Ici.mpr hs.1))
    (fun s hs => (h₂ s hs.1).continuousWithinAt.mono Icc_subset_Ici_self)
    (fun s hs => (h₂ s hs.1).mono (Ici_subset_Ici.mpr hs.1)) h0
  exact this ⟨ht, le_rfl⟩

end Triage

/-! ## Axiom audit -/

#print axioms risesFalls_const_mul
#print axioms not_risesFalls_of_strictMonoOn
#print axioms not_risesFalls_of_strictAntiOn
#print axioms hasDerivAt_of_interior
#print axioms continuousOn_of_hasDerivWithinAt
#print axioms eventually_right_gt
#print axioms eventually_left_gt
#print axioms deriv_nonpos_of_antitoneOn
#print axioms Icc_subset_of_convex
#print axioms Ioo_subset_interior_of_convex
#print axioms p3i_witnesses_of_risesFalls
#print axioms p3i_interior_max
#print axioms p3i_risesFalls_iff
#print axioms p3i_rises_falls_iff_preASI
#print axioms p3i_foc
#print axioms p3i_foc_of_isMaxOn
#print axioms p3i_soc
#print axioms p3ii_unimodal
#print axioms p3ii_unimodal_preASI
#print axioms p3ii_unimodal_untruncated
#print axioms hasDerivAt_exp_mul
#print axioms hasDerivAt_exp_neg_mul
#print axioms ode_diff
#print axioms ode_unique
#print axioms esolNe_hasDerivAt
#print axioms esolEq_hasDerivAt
#print axioms esol_hasDerivAt
#print axioms esol_zero
#print axioms p3iii_solution_unique
#print axioms gap_ne
#print axioms gap_eq
#print axioms gNe_zero
#print axioms gNe_strictAnti
#print axioms gNe_continuous
#print axioms gNe_tHat
#print axioms gEq_strictAnti
#print axioms gEq_continuous
#print axioms gEq_tHat
#print axioms gap_solution_ne
#print axioms gap_solution_eq
#print axioms sign_pos_iff
#print axioms sign_neg_iff
#print axioms shape_of_zero
#print axioms shape_of_pos
#print axioms shape_of_start_nonpos
#print axioms risesFalls_iff_zero
#print axioms unique_max_of_zero
#print axioms qS_sub
#print axioms gNe_pos_zero_iff
#print axioms gNe_pos_of_no_zero
#print axioms gEq_pos_zero_iff
#print axioms a7_stock_ne_peak_iff
#print axioms a7_stock_ne_peak_date
#print axioms a7_stock_ne_preASI_iff
#print axioms a7_stock_eq_peak_iff
#print axioms a7_stock_eq_peak_date
#print axioms a7_stock_eq_preASI_iff
#print axioms a7_stock_no_peak_ahead
#print axioms tendsto_exp_neg_mul
#print axioms tendsto_mul_exp_neg_mul
#print axioms iotaP_tendsto
#print axioms esol_tendsto
#print axioms p3iii_plateau
#print axioms lt_of_strictMonoOn_tendsto
#print axioms qS_zero
#print axioms tHatNe_zero
#print axioms tHatEq_zero
#print axioms p3iii_peak_iff
#print axioms p3iii_peak_date_ne
#print axioms p3iii_peak_date_eq
#print axioms p3iii_preASI_iff_ne
#print axioms p3iii_preASI_iff_eq
#print axioms p3iii_no_peak_monotone
#print axioms p3iii_full_protection_peak
#print axioms p3iii_slow_protection_peak
#print axioms p3iii_fast_protection_removes_peak
#print axioms p3iii_peak_then_plateau
#print axioms fig6_slow_residue
#print axioms fig6_fast_residue
#print axioms fig6_full_protection
#print axioms tendsto_affine
#print axioms no_limit_of_atTop
#print axioms ιF_eq
#print axioms origF_solves
#print axioms origF_mu_pos
#print axioms origF_iota_min
#print axioms origF_iota_min_attained
#print axioms origF_iota_pos
#print axioms origF_iota_unbounded
#print axioms origF_iota_tendsto
#print axioms origF_risesFalls
#print axioms origF_unique_max
#print axioms origF_tendsto_zero
#print axioms p3_orig_first_half_false_finite
#print axioms origX_solves
#print axioms origX_zero
#print axioms origX_risesFalls
#print axioms p3_orig_first_half_false_unbounded
#print axioms origL_solution
#print axioms origL_grows
#print axioms p3_orig_second_half_false
#print axioms origG_solves
#print axioms origG_iota_ge_one
#print axioms origG_tendsto
#print axioms p3_orig_second_half_false_finite
#print axioms body153_hazard_rises_iff
#print axioms origC_no_peak
#print axioms iotaP_gt
#print axioms a7_triage_unbounded
#print axioms a7_triage_no_lower
#print axioms a7_triage_peak_no_lower
#print axioms a7_triage_plateau
-- Fix round 1
#print axioms limit_lt_of_strictAntiOn
#print axioms p3iii_peak_above_plateau_ne
#print axioms p3iii_peak_above_plateau_eq
#print axioms p3iii_witness
#print axioms fig6_slow_residue_path
#print axioms fig6_fast_residue_path
#print axioms fig6_full_slow_path
#print axioms fig6_full_fast_path
#print axioms origF_has_limit
#print axioms origF_no_positive_plateau
#print axioms p3_orig_second_half_false_finite_pos
#print axioms origX_continuous
#print axioms origX_pos
#print axioms origX_le_one
#print axioms origX_le_exp
#print axioms origX_tendsto_zero
#print axioms origX_global_max
#print axioms p3_orig_unbounded_peak_falls_to_zero
#print axioms body153_example
#print axioms p3_plain_sign
#print axioms a7_triage_sup_no_lower
#print axioms a7_triage_reaches_uncapped_peak
#print axioms capField_lipschitz
#print axioms capFieldC_lipschitz
#print axioms capFieldC_norm_le
#print axioms capC_exists_Icc
#print axioms hasDerivWithinAt_Ici_of_Icc
#print axioms a7_triage_exists
#print axioms a7_triage_unique
-- Fix round 2
#print axioms phiRise_eq_of_le
#print axioms phiRise_eq_of_ge
#print axioms phiRise_pos
#print axioms phiRise_continuous
#print axioms phiRise_monotone
#print axioms phiRise_strictMonoOn
#print axioms phiRise_tendsto
#print axioms pow_mul_exp_neg_mul_tendsto
#print axioms quad_mul_exp_tendsto
#print axioms quad_mul_t_exp_tendsto
#print axioms line276_second_rise
#print axioms line276_no_residue_falls
#print axioms phiExp_eq_of_le
#print axioms phiExp_eq_of_ge
#print axioms phiExp_pos
#print axioms phiExp_continuous
#print axioms phiExp_monotone
#print axioms phiExp_strictMonoOn
#print axioms line276_second_rise_no_residue

end RTTR.Peak
