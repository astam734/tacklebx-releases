import Mathlib

/-!
# Proposition 11 (release timing) and its two A.7 extensions — RTTR v8, seat L5

Paper: `PAPER-DRAFT-v8.md`, set-up line 979, Proposition 11 lines 981–985, "the sign of κ"
987, "as first stated" 989, proof in A.6 (P11 paragraph), A.7 entries "A loss hazard rising
with copy speed" and "Internal research whose value survives release".

## How each paper object is represented, and why that is faithful

* **Parameters.** `Prm` holds `r, λ (lam), F, Z, κ_pre, κ_post, g₀, Δ`. A perturbation of one
  primitive is a record update `{ p with θ := … }`, so "other primitives fixed" is literal.
* **The old lead** `g(t) = g₀ e^{−κ_pre t}` is `lead p t` (A12).
* **Post-release value** `Π(x) = ∫₀^∞ e^{−rs} ρ(x e^{−κ_post s}) ds` is `Pi ρ r κ x`, the Bochner
  integral over `(0, ∞)`. Lean returns `0` for a non-integrable integrand, so `Pi` is the paper's
  improper integral exactly where the integrand is integrable. `Pi_integrableOn` and
  `f_integrableOn` prove integrability for every rent continuous on the relevant interval
  (`r > 0`), so on the model's domain the two agree. Every closed form for `Π` (linear, power,
  `x²`, saturating) is **proved from this integral**, never assumed.
* **Release value** `J(T) = Π(g(T) + Δ)` is `J`; **the planned-release value**
  `V(T) = ∫₀^T e^{−(r+λ)t}[F + λZ + ρ(g(t))]dt + e^{−(r+λ)T}J(T)` is `V`, with the interval
  integral; **the stopping function** `Φ(T) = F + λZ + ρ(g(T)) − (r+λ)J(T) + J′(T)` is `Phi`,
  with `J′ = deriv J`, the derivative of the defined function.
* **`V` is derived, not assumed.** The paper derives `V` as an expectation (A.6: hold earns
  `F + ρ(g)` until release or loss, loss at rate `λ` yields `Z`, release yields `J(T)`).
  `payoff h r Zl c T τ` is the realized payoff when loss strikes at `τ`, and `expVal` averages
  it against the exponential density `λe^{−λτ}` on `(0, ∞)`. `p11i_V_is_expectation` proves
  `Vexp = V` for `λ > 0`; `p11i_V_no_hazard` gives the deterministic payoff at `λ = 0`. The A.7
  values `Vboth`, `Vrel` are certified the same way (`a7_Vboth_is_expectation`,
  `a7_Vrel_is_expectation`).
* **`J` near `T = 0`.** `J_contWithin0` derives continuity of `J` at `0⁺` from A11 (dominated
  convergence), so the optimality theorems take only the paper's hypotheses plus `r > 0` and
  `κ_post ≥ 0`; "J differentiable" (L1134) stays a hypothesis, discharged by
  `p11i_J_differentiable` when `κ_post > 0`.
* **Rents** are functions `ℝ → ℝ`; only values on `[0, g₀ + Δ]` enter. A11's continuity is the
  hypothesis `ContinuousOn ρ (Icc 0 (g₀ + Δ))`; "increasing" is `MonotoneOn`/`StrictMonoOn`
  where a result uses it, and `ρ(0) = 0` is stated where used.
* **Release dates** range over `[0, ∞)` (`Ici 0`). "Interior release" = a maximizer `T* > 0` of
  `V` on `[0, ∞)` (`IsMaxOn`). "Strict interior maximum" = a strict local maximum at `T > 0`.
  "Holding until involuntary loss" = `T → ∞`, as A.6 compares candidates ("with `T = 0` and
  `T → ∞`"): `Vhold = ∫₀^∞ e^{−(r+λ)t}[F + λZ + ρ(g(t))]dt`, which `V` converges to
  (`p11i_hold_limit`) and which beats every date when no date is optimal (`p11i_hold_optimal`).
* **The realized window** is `window L T`, the first date at which the capability is public
  (leaked at `L` or released at `T`); `p11_window_eq_min` checks it is `min L T`.
* **"Φ crosses zero once, from above"** = `Φ > 0` on `(0, T*)` and `Φ < 0` on `(T*, ∞)`.
  **"Zeros of Φ isolated"** = each zero in `(0, ∞)` has a punctured neighbourhood free of zeros.
* **Comparative statics** (part (v), A.7). The paper writes `dT*/dθ` at a simple downward
  crossing. Every date claim is composed to a statement about `d = dT*/dθ`. `comp_statics` proves `dT*/dθ = −(∂Φ/∂θ)/(∂Φ/∂T)` for any differentiable selection
  `T*(θ)` of zeros of `Φ(·, θ)`, given joint differentiability of `(T, θ) ↦ Φ`. Both are
  *hypotheses*: the paper's own `C¹` assumption on `Φ̃` (A.6, "Smoothness") and the implicit
  function theorem, which is not re-proved here. Each parameter's `∂Φ/∂θ` is then proved as a
  `HasDerivAt` of the **defined** `Φ` under the record update, and its sign is proved.
* **A.7, surviving research.** `Vboth` and `Vrel` are the release values, defined as integrals,
  when a flow `F_post` survives both release and loss, or release only.

## What is not formalised here (see `../LEAN/L5-ROWS.md`)

Not attempted: the jump-rent kink example (`ρ = x + 1{x ≥ 1}`), the general-rent statement
"release later whenever `xρ′(x)` is non-decreasing" (linear and power rents are proved), and the
right derivative `−3/(e⁴+1)` of the saturating example. Numerical only: `+86`, `−45.5`, `+122`,
the 56-case grid, the 161-draw scan, `T* = 9.6470`, the Fig. 18 perturbations. The integral
representation `Π(x) = κ⁻¹x^{−r/κ}∫₀^x u^{r/κ−1}ρ(u)du` *is* proved (`Pi_integral_rep`).
-/

open Real MeasureTheory Set Filter Topology intervalIntegral

namespace RTTR.Release

/-- Parameters of P11. -/
structure Prm where
  r : ℝ
  lam : ℝ
  F : ℝ
  Z : ℝ
  kpre : ℝ
  kpost : ℝ
  g0 : ℝ
  Δ : ℝ

noncomputable def lead (p : Prm) (t : ℝ) : ℝ := p.g0 * exp (-p.kpre * t)

noncomputable def Pi (ρ : ℝ → ℝ) (r κ x : ℝ) : ℝ :=
  ∫ s in Ioi (0:ℝ), exp (-r * s) * ρ (x * exp (-κ * s))

noncomputable def J (ρ : ℝ → ℝ) (p : Prm) (T : ℝ) : ℝ := Pi ρ p.r p.kpost (lead p T + p.Δ)

noncomputable def holdIntegrand (ρ : ℝ → ℝ) (p : Prm) (t : ℝ) : ℝ :=
  exp (-(p.r + p.lam) * t) * (p.F + p.lam * p.Z + ρ (lead p t))

noncomputable def V (ρ : ℝ → ℝ) (p : Prm) (T : ℝ) : ℝ :=
  (∫ t in (0:ℝ)..T, holdIntegrand ρ p t) + exp (-(p.r + p.lam) * T) * J ρ p T

noncomputable def Phi (ρ : ℝ → ℝ) (p : Prm) (T : ℝ) : ℝ :=
  p.F + p.lam * p.Z + ρ (lead p T) - (p.r + p.lam) * J ρ p T + deriv (J ρ p) T

theorem lead_continuous (p : Prm) : Continuous (lead p) := by
  unfold lead; fun_prop

theorem lead_hasDerivAt (p : Prm) (t : ℝ) :
    HasDerivAt (lead p) (-p.kpre * lead p t) t := by
  have h : HasDerivAt (fun y => p.g0 * exp (-p.kpre * y))
      (p.g0 * (exp (-p.kpre * t) * (-p.kpre * 1))) t :=
    (((hasDerivAt_id t).const_mul (-p.kpre)).exp).const_mul p.g0
  unfold lead
  convert h using 1
  ring

theorem lead_mem (p : Prm) (hg : 0 ≤ p.g0) (hk : 0 ≤ p.kpre) {t : ℝ} (ht : 0 ≤ t) :
    lead p t ∈ Icc 0 p.g0 := by
  have h1 : exp (-p.kpre * t) ≤ 1 := exp_le_one_iff.mpr (by nlinarith)
  have h2 := exp_pos (-p.kpre * t)
  unfold lead
  constructor <;> nlinarith

theorem holdIntegrand_continuousOn (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) : ContinuousOn (holdIntegrand ρ p) (Ici 0) := by
  have hmaps : MapsTo (lead p) (Ici 0) (Icc 0 (p.g0 + p.Δ)) := fun t ht => by
    have := lead_mem p hg hk ht; exact ⟨this.1, by linarith [this.2]⟩
  have hc : ContinuousOn (fun t => ρ (lead p t)) (Ici 0) :=
    hρ.comp (lead_continuous p).continuousOn hmaps
  unfold holdIntegrand
  exact (Continuous.continuousOn (by fun_prop)).mul (continuousOn_const.add hc)

theorem p11i_V_hasDerivAt (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) {T : ℝ} (hT : 0 < T) (hJ : DifferentiableAt ℝ (J ρ p) T) :
    HasDerivAt (V ρ p) (exp (-(p.r + p.lam) * T) * Phi ρ p T) T := by
  have hcont := holdIntegrand_continuousOn ρ p hρ hg hΔ hk
  have hint : IntervalIntegrable (holdIntegrand ρ p) volume 0 T := by
    apply ContinuousOn.intervalIntegrable
    apply hcont.mono
    intro x hx
    rw [uIcc_of_le hT.le] at hx
    exact hx.1
  have hopen : ContinuousOn (holdIntegrand ρ p) (Ioi 0) := hcont.mono Ioi_subset_Ici_self
  have hmeas := hopen.stronglyMeasurableAtFilter (μ := volume) isOpen_Ioi T hT
  have hcat : ContinuousAt (holdIntegrand ρ p) T := hopen.continuousAt (Ioi_mem_nhds hT)
  have h1 := integral_hasDerivAt_right hint hmeas hcat
  have h2 : HasDerivAt (fun T => exp (-(p.r + p.lam) * T))
      (exp (-(p.r + p.lam) * T) * (-(p.r + p.lam) * 1)) T :=
    ((hasDerivAt_id T).const_mul _).exp
  have h3 := h2.mul hJ.hasDerivAt
  have h4 := h1.add h3
  unfold V
  convert h4 using 1
  unfold holdIntegrand Phi
  ring

/-! ### Real-analysis helpers: sign of the derivative and optimality -/

theorem contOn_Ici_of {V D : ℝ → ℝ} (hc0 : ContinuousWithinAt V (Ici 0) 0)
    (hd : ∀ T, 0 < T → HasDerivAt V (D T) T) : ContinuousOn V (Ici 0) := by
  intro x hx
  rcases eq_or_lt_of_le (show (0:ℝ) ≤ x from hx) with h | h
  · subst h; exact hc0
  · exact (hd x h).continuousAt.continuousWithinAt

/-- Positive derivative before `Ts`, negative after: `Ts` is the strict global maximum on
`[0, ∞)`, and it also beats any limit of `V` at infinity. -/
theorem strict_max_of_sign {V D : ℝ → ℝ} {Ts : ℝ} (hTs : 0 < Ts)
    (hc0 : ContinuousWithinAt V (Ici 0) 0) (hd : ∀ T, 0 < T → HasDerivAt V (D T) T)
    (hpos : ∀ T, 0 < T → T < Ts → 0 < D T) (hneg : ∀ T, Ts < T → D T < 0) :
    (∀ T, 0 ≤ T → T ≠ Ts → V T < V Ts) ∧
      (∀ L, Tendsto V atTop (𝓝 L) → L ≤ V Ts) := by
  have hcont := contOn_Ici_of hc0 hd
  have hmono : StrictMonoOn V (Icc 0 Ts) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc 0 Ts) (hcont.mono Icc_subset_Ici_self)
    intro x hx
    rw [interior_Icc] at hx
    rw [(hd x hx.1).deriv]; exact hpos x hx.1 hx.2
  have hanti : StrictAntiOn V (Ici Ts) := by
    apply strictAntiOn_of_deriv_neg (convex_Ici Ts)
      (hcont.mono (Ici_subset_Ici.mpr hTs.le))
    intro x hx
    rw [interior_Ici] at hx
    rw [(hd x (lt_trans hTs hx)).deriv]; exact hneg x hx
  have key : ∀ T, 0 ≤ T → T ≠ Ts → V T < V Ts := by
    intro T hT hne
    rcases lt_or_gt_of_ne hne with h | h
    · exact hmono ⟨hT, h.le⟩ ⟨hTs.le, le_rfl⟩ h
    · exact hanti (Set.mem_Ici.mpr le_rfl) (Set.mem_Ici.mpr h.le) h
  refine ⟨key, fun L hL => ?_⟩
  apply le_of_tendsto hL
  filter_upwards [eventually_ge_atTop 0] with T hT
  rcases eq_or_ne T Ts with h | h
  · rw [h]
  · exact (key T hT h).le

/-- Darboux: a derivative that never vanishes on an interval keeps one sign there. -/
theorem deriv_sign_const {V D : ℝ → ℝ} {a b : ℝ}
    (hd : ∀ x ∈ Ioo a b, HasDerivAt V (D x) x) (hne : ∀ x ∈ Ioo a b, D x ≠ 0) :
    (∀ x ∈ Ioo a b, 0 < D x) ∨ (∀ x ∈ Ioo a b, D x < 0) := by
  have hoc : OrdConnected (D '' Ioo a b) :=
    ordConnected_Ioo.image_hasDerivWithinAt (fun x hx => (hd x hx).hasDerivWithinAt)
  by_contra hcon
  push Not at hcon
  obtain ⟨⟨x1, hx1, h1⟩, ⟨x2, hx2, h2⟩⟩ := hcon
  have h1' : D x1 < 0 := lt_of_le_of_ne h1 (hne x1 hx1)
  have h2' : 0 < D x2 := lt_of_le_of_ne h2 (hne x2 hx2).symm
  have : (0:ℝ) ∈ D '' Ioo a b :=
    hoc.out ⟨x1, hx1, rfl⟩ ⟨x2, hx2, rfl⟩ ⟨h1'.le, h2'.le⟩
  obtain ⟨x, hx, hx0⟩ := this
  exact hne x hx hx0

/-- At a local maximum whose punctured neighbourhood has no critical point, the derivative is
positive just before and negative just after: a crossing from above. -/
theorem localMax_crossing {V D : ℝ → ℝ} {T ε : ℝ} (hε : 0 < ε)
    (hd : ∀ x ∈ Ioo (T - ε) (T + ε), HasDerivAt V (D x) x)
    (hiso : ∀ x ∈ Ioo (T - ε) (T + ε), x ≠ T → D x ≠ 0)
    (hmax : IsLocalMax V T) :
    (∀ x ∈ Ioo (T - ε) T, 0 < D x) ∧ (∀ x ∈ Ioo T (T + ε), D x < 0) := by
  have hcont : ∀ x ∈ Ioo (T - ε) (T + ε), ContinuousAt V x :=
    fun x hx => (hd x hx).continuousAt
  constructor
  · have hL : ∀ x ∈ Ioo (T - ε) T, x ∈ Ioo (T - ε) (T + ε) :=
      fun x hx => ⟨hx.1, by linarith [hx.2]⟩
    rcases deriv_sign_const (fun x hx => hd x (hL x hx))
        (fun x hx => hiso x (hL x hx) (ne_of_lt hx.2)) with h | h
    · exact h
    · exfalso
      have hev : ∀ᶠ y in 𝓝[<] T, V y ≤ V T := hmax.filter_mono nhdsWithin_le_nhds
      obtain ⟨y, hy1, hy2⟩ :=
        (hev.and (Ioo_mem_nhdsLT (show T - ε < T by linarith))).exists
      have hanti : StrictAntiOn V (Icc y T) := by
        apply strictAntiOn_of_deriv_neg (convex_Icc y T)
        · intro x hx
          apply (hcont x ⟨by linarith [hy2.1, hx.1], by linarith [hx.2]⟩).continuousWithinAt
        · intro x hx
          rw [interior_Icc] at hx
          have hx' : x ∈ Ioo (T - ε) T := ⟨by linarith [hy2.1, hx.1], hx.2⟩
          rw [(hd x (hL x hx')).deriv]; exact h x hx'
      have := hanti ⟨le_rfl, hy2.2.le⟩ ⟨hy2.2.le, le_rfl⟩ hy2.2
      linarith
  · have hR : ∀ x ∈ Ioo T (T + ε), x ∈ Ioo (T - ε) (T + ε) :=
      fun x hx => ⟨by linarith [hx.1], hx.2⟩
    rcases deriv_sign_const (fun x hx => hd x (hR x hx))
        (fun x hx => hiso x (hR x hx) (ne_of_gt hx.1)) with h | h
    · exfalso
      have hev : ∀ᶠ y in 𝓝[>] T, V y ≤ V T := hmax.filter_mono nhdsWithin_le_nhds
      obtain ⟨y, hy1, hy2⟩ :=
        (hev.and (Ioo_mem_nhdsGT (show T < T + ε by linarith))).exists
      have hmono : StrictMonoOn V (Icc T y) := by
        apply strictMonoOn_of_deriv_pos (convex_Icc T y)
        · intro x hx
          apply (hcont x ⟨by linarith [hx.1], by linarith [hy2.2, hx.2]⟩).continuousWithinAt
        · intro x hx
          rw [interior_Icc] at hx
          have hx' : x ∈ Ioo T (T + ε) := ⟨hx.1, by linarith [hy2.2, hx.2]⟩
          rw [(hd x (hR x hx')).deriv]; exact h x hx'
      have := hmono ⟨le_rfl, hy2.1.le⟩ ⟨hy2.1.le, le_rfl⟩ hy2.1
      linarith
    · exact h

/-- If no date in `[0, ∞)` maximizes a continuous `V`, its supremum is approached only as
`T → ∞`: every bounded stretch `[0, M]` is beaten by a later date. -/
theorem sup_at_infinity {V : ℝ → ℝ} (hc : ContinuousOn V (Ici 0))
    (hno : ¬ ∃ T, 0 ≤ T ∧ IsMaxOn V (Ici 0) T) :
    ∀ M, 0 ≤ M → ∃ T, M < T ∧ ∀ t ∈ Icc 0 M, V t < V T := by
  intro M hM
  obtain ⟨t0, ht0, hmax⟩ := isCompact_Icc.exists_isMaxOn (nonempty_Icc.mpr hM)
    (hc.mono Icc_subset_Ici_self)
  have : ¬ IsMaxOn V (Ici 0) t0 := fun h => hno ⟨t0, ht0.1, h⟩
  simp only [IsMaxOn, IsMaxFilter, eventually_principal, not_forall, not_le] at this
  obtain ⟨T, hT, hTv⟩ := this
  refine ⟨T, ?_, fun t ht => lt_of_le_of_lt (hmax ht) hTv⟩
  by_contra hle
  push Not at hle
  have := hmax (show T ∈ Icc 0 M from ⟨hT, hle⟩)
  simp at this
  linarith

/-! ### Integral helpers -/

theorem integral_exp_neg_mul {a : ℝ} (ha : a ≠ 0) (T : ℝ) :
    ∫ t in (0:ℝ)..T, exp (-a * t) = (1 - exp (-a * T)) / a := by
  have hd : ∀ x ∈ uIcc (0:ℝ) T,
      HasDerivAt (fun t => -exp (-a * t) / a) (exp (-a * x)) x := by
    intro x _
    have h : HasDerivAt (fun t => exp (-a * t)) (exp (-a * x) * (-a * 1)) x :=
      ((hasDerivAt_id x).const_mul (-a)).exp
    convert (h.neg).div_const a using 1
    field_simp
  rw [integral_eq_sub_of_hasDerivAt hd (by apply Continuous.intervalIntegrable; fun_prop)]
  simp only [mul_zero, exp_zero]
  field_simp
  ring

theorem integral_exp_neg_Ioi_pos {c : ℝ} (hc : 0 < c) :
    ∫ s in Ioi (0:ℝ), exp (-c * s) = 1 / c := by
  rw [integral_exp_mul_Ioi (by linarith : -c < 0) 0]
  simp only [mul_zero, exp_zero]
  field_simp

theorem scaled_mem {x κ s : ℝ} (hx : 0 ≤ x) (hκ : 0 ≤ κ) (hs : 0 ≤ s) :
    x * exp (-κ * s) ∈ Icc 0 x := by
  have h1 : exp (-κ * s) ≤ 1 := exp_le_one_iff.mpr (by nlinarith)
  exact ⟨mul_nonneg hx (exp_pos _).le, by nlinarith [exp_pos (-κ * s)]⟩

/-- The integrand of `Π` is integrable on `(0, ∞)` for any rent continuous on `[0, x]`. -/
theorem Pi_integrableOn (ρ : ℝ → ℝ) {r κ x : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) (hx : 0 ≤ x)
    (hρ : ContinuousOn ρ (Icc 0 x)) :
    IntegrableOn (fun s => exp (-r * s) * ρ (x * exp (-κ * s))) (Ioi 0) := by
  obtain ⟨C, hC⟩ := isCompact_Icc.exists_bound_of_continuousOn hρ
  have hmaps : MapsTo (fun s => x * exp (-κ * s)) (Ici 0) (Icc 0 x) :=
    fun s hs => scaled_mem hx hκ hs
  have hcont : ContinuousOn (fun s => exp (-r * s) * ρ (x * exp (-κ * s))) (Ici 0) :=
    (Continuous.continuousOn (by fun_prop)).mul
      (hρ.comp (Continuous.continuousOn (by fun_prop)) hmaps)
  refine Integrable.mono' ((exp_neg_integrableOn_Ioi 0 hr).const_mul C)
    ((hcont.mono Ioi_subset_Ici_self).aestronglyMeasurable measurableSet_Ioi) ?_
  refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
  rw [norm_mul, Real.norm_of_nonneg (exp_pos _).le]
  have := hC _ (hmaps (Set.mem_Ici.mpr (le_of_lt hs)))
  nlinarith [exp_pos (-r * s), norm_nonneg (ρ (x * exp (-κ * s)))]

/-! ### `J` is continuous at `0⁺` and bounded (from A11 by dominated convergence) -/

theorem lead_add_mem (p : Prm) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ) (hk : 0 ≤ p.kpre) {t : ℝ}
    (ht : 0 ≤ t) : lead p t + p.Δ ∈ Icc 0 (p.g0 + p.Δ) := by
  have := lead_mem p hg hk ht; exact ⟨by linarith [this.1], by linarith [this.2]⟩

theorem J_contWithin0 (ρ : ℝ → ℝ) (p : Prm) (hr : 0 < p.r) (hκ : 0 ≤ p.kpost)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) : ContinuousWithinAt (J ρ p) (Ici 0) 0 := by
  obtain ⟨C, hC⟩ := isCompact_Icc.exists_bound_of_continuousOn hρ
  have hX : 0 ≤ p.g0 + p.Δ := add_nonneg hg hΔ
  have hmaps : ∀ T, 0 ≤ T → ∀ s, 0 ≤ s → (lead p T + p.Δ) * exp (-p.kpost * s) ∈ Icc 0 (p.g0 + p.Δ) := by
    intro T hT s hs
    have h1 := lead_add_mem p hg hΔ hk hT
    have h2 := scaled_mem h1.1 hκ hs
    exact ⟨h2.1, le_trans h2.2 h1.2⟩
  unfold J Pi
  apply continuousWithinAt_of_dominated (bound := fun s => C * exp (-p.r * s))
  · filter_upwards [self_mem_nhdsWithin] with T hT
    have hc : ContinuousOn (fun s => exp (-p.r * s) * ρ ((lead p T + p.Δ) * exp (-p.kpost * s)))
        (Ici 0) :=
      (Continuous.continuousOn (by fun_prop)).mul
        (hρ.comp (Continuous.continuousOn (by fun_prop)) (fun s hs => hmaps T hT s hs))
    exact (hc.mono Ioi_subset_Ici_self).aestronglyMeasurable measurableSet_Ioi
  · filter_upwards [self_mem_nhdsWithin] with T hT
    refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
    rw [norm_mul, Real.norm_of_nonneg (exp_pos _).le]
    have := hC _ (hmaps T hT s (le_of_lt hs))
    nlinarith [exp_pos (-p.r * s), norm_nonneg (ρ ((lead p T + p.Δ) * exp (-p.kpost * s)))]
  · exact (exp_neg_integrableOn_Ioi 0 hr).const_mul C
  · refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
    apply ContinuousWithinAt.mul continuousWithinAt_const
    have hm0 := hmaps 0 le_rfl s (le_of_lt hs)
    have hcw : ContinuousWithinAt ρ (Icc 0 (p.g0 + p.Δ)) ((lead p 0 + p.Δ) * exp (-p.kpost * s)) :=
      hρ _ hm0
    exact hcw.comp (f := fun T => (lead p T + p.Δ) * exp (-p.kpost * s))
      (Continuous.continuousWithinAt (by unfold lead; fun_prop))
      (fun T hT => hmaps T hT s (le_of_lt hs))

/-! ### NEW: holding until involuntary loss is the limit T → ∞ -/

theorem J_bounded (ρ : ℝ → ℝ) (p : Prm) (hr : 0 < p.r) (hκ : 0 ≤ p.kpost)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) : ∃ B, ∀ T, 0 ≤ T → |J ρ p T| ≤ B := by
  obtain ⟨C, hC⟩ := isCompact_Icc.exists_bound_of_continuousOn hρ
  refine ⟨C * (1 / p.r), fun T hT => ?_⟩
  have h1 := lead_add_mem p hg hΔ hk hT
  have hI : ∫ s in Ioi (0:ℝ), C * exp (-p.r * s) = C * (1 / p.r) := by
    rw [MeasureTheory.integral_const_mul, integral_exp_mul_Ioi (by linarith : -p.r < 0) 0]
    simp only [mul_zero, exp_zero]; field_simp
  unfold J Pi
  rw [← Real.norm_eq_abs, ← hI]
  apply MeasureTheory.norm_integral_le_of_norm_le ((exp_neg_integrableOn_Ioi 0 hr).const_mul C)
  refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
  have h2 := scaled_mem h1.1 hκ (le_of_lt hs)
  rw [norm_mul, Real.norm_of_nonneg (exp_pos _).le]
  have := hC _ ⟨h2.1, le_trans h2.2 h1.2⟩
  nlinarith [exp_pos (-p.r * s), norm_nonneg (ρ ((lead p T + p.Δ) * exp (-p.kpost * s)))]

theorem holdIntegrand_integrableOn (ρ : ℝ → ℝ) (p : Prm) (ha : 0 < p.r + p.lam)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) : IntegrableOn (holdIntegrand ρ p) (Ioi 0) := by
  obtain ⟨C, hC⟩ := isCompact_Icc.exists_bound_of_continuousOn hρ
  have hcont := holdIntegrand_continuousOn ρ p hρ hg hΔ hk
  refine Integrable.mono' ((exp_neg_integrableOn_Ioi 0 ha).const_mul (|p.F + p.lam * p.Z| + C))
    ((hcont.mono Ioi_subset_Ici_self).aestronglyMeasurable measurableSet_Ioi) ?_
  refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
  have hm := lead_mem p hg hk (le_of_lt hs)
  have := hC _ ⟨hm.1, by linarith [hm.2]⟩
  unfold holdIntegrand
  rw [norm_mul, Real.norm_of_nonneg (exp_pos _).le, Real.norm_eq_abs]
  have h3 : |p.F + p.lam * p.Z + ρ (lead p s)| ≤ |p.F + p.lam * p.Z| + C := by
    have := abs_add_le (p.F + p.lam * p.Z) (ρ (lead p s))
    rw [Real.norm_eq_abs] at *; linarith
  nlinarith [exp_pos (-(p.r + p.lam) * s)]

/-! ### P11(i) -/

theorem integral_contWithin0 (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) :
    ContinuousWithinAt (fun T => ∫ t in (0:ℝ)..T, holdIntegrand ρ p t) (Ici 0) 0 := by
  have hcont := holdIntegrand_continuousOn ρ p hρ hg hΔ hk
  have hI : IntegrableOn (holdIntegrand ρ p) (uIcc 0 1) := by
    rw [uIcc_of_le zero_le_one]
    exact (hcont.mono Icc_subset_Ici_self).integrableOn_Icc
  have h := continuousOn_primitive_interval hI
  rw [uIcc_of_le zero_le_one] at h
  exact (h 0 ⟨le_rfl, zero_le_one⟩).mono_of_mem_nhdsWithin (Icc_mem_nhdsGE zero_lt_one)

theorem V_contWithin0 (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (hJc : ContinuousWithinAt (J ρ p) (Ici 0) 0) :
    ContinuousWithinAt (V ρ p) (Ici 0) 0 := by
  have h1 := integral_contWithin0 ρ p hρ hg hΔ hk
  have h2 : ContinuousWithinAt (fun T => exp (-(p.r + p.lam) * T)) (Ici 0) 0 :=
    (Continuous.continuousWithinAt (by fun_prop))
  exact h1.add (h2.mul hJc)

/-- **P11(i), first-order condition.** At an interior local maximum of the release value,
`Φ(T) = 0`, i.e. `F + λZ + ρ(g(T)) = (r + λ)J(T) − J′(T)`. -/
theorem p11i_foc (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) {T : ℝ} (hT : 0 < T) (hJ : DifferentiableAt ℝ (J ρ p) T)
    (hmax : IsLocalMax (V ρ p) T) :
    Phi ρ p T = 0 ∧
      p.F + p.lam * p.Z + ρ (lead p T) = (p.r + p.lam) * J ρ p T - deriv (J ρ p) T := by
  have h := hmax.hasDerivAt_eq_zero (p11i_V_hasDerivAt ρ p hρ hg hΔ hk hT hJ)
  have hP : Phi ρ p T = 0 := by
    rcases mul_eq_zero.mp h with h | h
    · exact absurd h (exp_pos _).ne'
    · exact h
  refine ⟨hP, ?_⟩
  unfold Phi at hP; linarith

/-- **P11(i), the reduced condition.** With `Z = 0` and no old public model (`g₀ = 0`,
`ρ(0) = 0`), an interior local maximum satisfies `F = (r + λ)J(T) − J′(T)`. -/
theorem p11i_foc_reduced (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg0 : p.g0 = 0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (hZ : p.Z = 0) (hρ0 : ρ 0 = 0) {T : ℝ} (hT : 0 < T)
    (hJ : DifferentiableAt ℝ (J ρ p) T) (hmax : IsLocalMax (V ρ p) T) :
    p.F = (p.r + p.lam) * J ρ p T - deriv (J ρ p) T := by
  have h := (p11i_foc ρ p hρ hg0.ge hΔ hk hT hJ hmax).2
  have hl : lead p T = 0 := by simp [lead, hg0]
  rw [hl, hρ0, hZ] at h
  linarith

/-- **P11(i), global optimality under single crossing.** If `Φ` is positive before `T*` and
negative after, `T*` is the strict global maximum of `V` on `[0, ∞)` and beats holding until
involuntary loss (any limit of `V` at infinity). -/
theorem p11i_global (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (hr : 0 < p.r) (hκ : 0 ≤ p.kpost)
    (hJd : ∀ T, 0 < T → DifferentiableAt ℝ (J ρ p) T) {Ts : ℝ} (hTs : 0 < Ts)
    (hpos : ∀ T, 0 < T → T < Ts → 0 < Phi ρ p T) (hneg : ∀ T, Ts < T → Phi ρ p T < 0) :
    (∀ T, 0 ≤ T → T ≠ Ts → V ρ p T < V ρ p Ts) ∧
      (∀ L, Tendsto (V ρ p) atTop (𝓝 L) → L ≤ V ρ p Ts) := by
  apply strict_max_of_sign hTs
    (V_contWithin0 ρ p hρ hg hΔ hk (J_contWithin0 ρ p hr hκ hρ hg hΔ hk))
    (fun T hT => p11i_V_hasDerivAt ρ p hρ hg hΔ hk hT (hJd T hT))
  · intro T h0 h1; exact mul_pos (exp_pos _) (hpos T h0 h1)
  · intro T h; exact mul_neg_of_pos_of_neg (exp_pos _) (hneg T h)

/-- **P11(i), the candidate set (isolated zeros).** If the zeros of `Φ` on `(0, ∞)` are
isolated, every maximizer of `V` on `[0, ∞)` is `T = 0` or a date where `Φ` crosses zero from
above (positive just before, zero at, negative just after). -/
theorem p11i_candidates (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (hJd : ∀ T, 0 < T → DifferentiableAt ℝ (J ρ p) T)
    (hiso : ∀ T, 0 < T → Phi ρ p T = 0 →
      ∃ ε > 0, ∀ x ∈ Ioo (T - ε) (T + ε), x ≠ T → Phi ρ p x ≠ 0)
    {T : ℝ} (hT : 0 ≤ T) (hmax : IsMaxOn (V ρ p) (Ici 0) T) :
    T = 0 ∨ (Phi ρ p T = 0 ∧ ∃ ε > 0, (∀ x ∈ Ioo (T - ε) T, 0 < Phi ρ p x) ∧
      (∀ x ∈ Ioo T (T + ε), Phi ρ p x < 0)) := by
  rcases eq_or_lt_of_le hT with h | hT'
  · left; exact h.symm
  right
  have hloc : IsLocalMax (V ρ p) T := hmax.isLocalMax (Ici_mem_nhds hT')
  have hP := (p11i_foc ρ p hρ hg hΔ hk hT' (hJd T hT') hloc).1
  refine ⟨hP, ?_⟩
  obtain ⟨ε0, hε0, hiso0⟩ := hiso T hT' hP
  have hε : 0 < min ε0 T := lt_min hε0 hT'
  have hεT : min ε0 T ≤ T := min_le_right _ _
  have hεε : min ε0 T ≤ ε0 := min_le_left _ _
  have hsub : ∀ x ∈ Ioo (T - min ε0 T) (T + min ε0 T), x ∈ Ioo (T - ε0) (T + ε0) :=
    fun x hx => ⟨by linarith [hx.1], by linarith [hx.2]⟩
  have hpos0 : ∀ x ∈ Ioo (T - min ε0 T) (T + min ε0 T), 0 < x :=
    fun x hx => by linarith [hx.1]
  have hc := localMax_crossing (D := fun x => exp (-(p.r + p.lam) * x) * Phi ρ p x) hε
    (fun x hx => p11i_V_hasDerivAt ρ p hρ hg hΔ hk (hpos0 x hx) (hJd x (hpos0 x hx)))
    (fun x hx hne => mul_ne_zero (exp_pos _).ne' (hiso0 x (hsub x hx) hne)) hloc
  refine ⟨min ε0 T, hε, fun x hx => ?_, fun x hx => ?_⟩
  · have := hc.1 x hx
    exact pos_of_mul_pos_right this (exp_pos _).le
  · have := hc.2 x hx
    by_contra hge; push Not at hge
    exact absurd this (not_lt.mpr (mul_nonneg (exp_pos _).le hge))

/-- **P11(i), holding until involuntary loss.** If no date maximizes `V`, the supremum is
approached only as `T → ∞`. -/
theorem p11i_no_max_hold (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (hr : 0 < p.r) (hκ : 0 ≤ p.kpost)
    (hJd : ∀ T, 0 < T → DifferentiableAt ℝ (J ρ p) T)
    (hno : ¬ ∃ T, 0 ≤ T ∧ IsMaxOn (V ρ p) (Ici 0) T) :
    ∀ M, 0 ≤ M → ∃ T, M < T ∧ ∀ t ∈ Icc 0 M, V ρ p t < V ρ p T :=
  sup_at_infinity (contOn_Ici_of
    (V_contWithin0 ρ p hρ hg hΔ hk (J_contWithin0 ρ p hr hκ hρ hg hΔ hk))
    (fun T hT => p11i_V_hasDerivAt ρ p hρ hg hΔ hk hT (hJd T hT))) hno

/-! ### P11(i): holding until involuntary loss is the limit `T → ∞` -/

/-- **P11(i), holding until involuntary loss.** `V(T)` converges, as `T → ∞`, to the value of
never releasing, `∫₀^∞ e^{−(r+λ)t}[F + λZ + ρ(g(t))]dt`. -/
theorem p11i_hold_limit (ρ : ℝ → ℝ) (p : Prm) (hr : 0 < p.r) (hl : 0 ≤ p.lam)
    (hκ : 0 ≤ p.kpost) (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0)
    (hΔ : 0 ≤ p.Δ) (hk : 0 ≤ p.kpre) :
    Tendsto (V ρ p) atTop (𝓝 (∫ t in Ioi 0, holdIntegrand ρ p t)) := by
  have ha : 0 < p.r + p.lam := by linarith
  have h1 := intervalIntegral_tendsto_integral_Ioi 0
    (holdIntegrand_integrableOn ρ p ha hρ hg hΔ hk) tendsto_id
  obtain ⟨B, hB⟩ := J_bounded ρ p hr hκ hρ hg hΔ hk
  have hlim : Tendsto (fun T => exp (-(p.r + p.lam) * T)) atTop (𝓝 0) :=
    tendsto_exp_atBot.comp (tendsto_id.const_mul_atTop_of_neg (by linarith))
  have h2 : Tendsto (fun T => exp (-(p.r + p.lam) * T) * J ρ p T) atTop (𝓝 0) := by
    have hz : Tendsto (fun T => exp (-(p.r + p.lam) * T) * B) atTop (𝓝 0) := by
      simpa using hlim.mul_const B
    apply squeeze_zero_norm' _ hz
    · filter_upwards [eventually_ge_atTop 0] with T hT
      rw [norm_mul, Real.norm_of_nonneg (exp_pos _).le, Real.norm_eq_abs]
      exact mul_le_mul_of_nonneg_left (hB T hT) (exp_pos _).le
  have := h1.add h2
  rw [add_zero] at this
  exact this

/-- **P11(i): when no date is optimal, holding until involuntary loss is.** If `V` converges to
`L` and no date maximizes it on `[0, ∞)`, every date is strictly worse than `L`. -/
theorem no_max_lt_limit {Vf : ℝ → ℝ} {L : ℝ} (hc : ContinuousOn Vf (Ici 0))
    (hL : Tendsto Vf atTop (𝓝 L)) (hno : ¬ ∃ T, 0 ≤ T ∧ IsMaxOn Vf (Ici 0) T) :
    ∀ T, 0 ≤ T → Vf T < L := by
  intro T0 hT0
  by_contra hge
  push Not at hge
  apply hno
  by_cases hab : ∃ T1, 0 ≤ T1 ∧ L < Vf T1
  · obtain ⟨T1, hT1, hLT⟩ := hab
    obtain ⟨M, hM⟩ := eventually_atTop.mp (hL.eventually (gt_mem_nhds hLT))
    set M' := max M T1
    have hM'0 : 0 ≤ M' := le_trans hT1 (le_max_right _ _)
    obtain ⟨t0, ht0, hmax⟩ := isCompact_Icc.exists_isMaxOn (nonempty_Icc.mpr hM'0)
      (hc.mono Icc_subset_Ici_self)
    have h1 : Vf T1 ≤ Vf t0 := hmax ⟨hT1, le_max_right _ _⟩
    refine ⟨t0, ht0.1, fun T hT => ?_⟩
    by_cases hTM : T ≤ M'
    · exact hmax ⟨hT, hTM⟩
    · push Not at hTM
      have := hM T (le_trans (le_max_left _ _) hTM.le)
      show Vf T ≤ Vf t0
      linarith
  · push Not at hab
    exact ⟨T0, hT0, fun T hT => by
      have := hab T hT; have := hab T0 hT0; show Vf T ≤ Vf T0; linarith⟩

/-- The value of holding until involuntary loss (never releasing voluntarily). -/
noncomputable def Vhold (ρ : ℝ → ℝ) (p : Prm) : ℝ := ∫ t in Ioi 0, holdIntegrand ρ p t

/-- **P11(i), the third candidate.** If no date maximizes `V` on `[0, ∞)`, holding until
involuntary loss is optimal: `V(T) → Vhold` as `T → ∞` and every date is strictly worse. -/
theorem p11i_hold_optimal (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (hr : 0 < p.r) (hl : 0 ≤ p.lam) (hκ : 0 ≤ p.kpost)
    (hJd : ∀ T, 0 < T → DifferentiableAt ℝ (J ρ p) T)
    (hno : ¬ ∃ T, 0 ≤ T ∧ IsMaxOn (V ρ p) (Ici 0) T) :
    Tendsto (V ρ p) atTop (𝓝 (Vhold ρ p)) ∧ ∀ T, 0 ≤ T → V ρ p T < Vhold ρ p := by
  have hL := p11i_hold_limit ρ p hr hl hκ hρ hg hΔ hk
  refine ⟨hL, no_max_lt_limit (contOn_Ici_of
    (V_contWithin0 ρ p hρ hg hΔ hk (J_contWithin0 ρ p hr hκ hρ hg hΔ hk))
    (fun T hT => p11i_V_hasDerivAt ρ p hρ hg hΔ hk hT (hJd T hT))) hL hno⟩

/-! ### P11(i): the release value is an expectation over the loss time -/

/-- Realized payoff of planning release at `T` when involuntary loss strikes at `τ`: the
discounted running flow `h` until `min τ T`, then `e^{−rτ}·Zl` if loss comes first, or
`e^{−rT}·c` at release. -/
noncomputable def payoff (h : ℝ → ℝ) (r Zl c T τ : ℝ) : ℝ :=
  (∫ t in (0:ℝ)..min τ T, h t) + if τ ≤ T then exp (-r * τ) * Zl else exp (-r * T) * c

/-- Expected payoff with an exponential loss time of rate `λ` (density `λe^{−λτ}` on `(0, ∞)`). -/
noncomputable def expVal (h : ℝ → ℝ) (r lam Zl c T : ℝ) : ℝ :=
  ∫ τ in Ioi (0:ℝ), lam * exp (-lam * τ) * payoff h r Zl c T τ

theorem expVal_eq {h : ℝ → ℝ} {r lam Zl c T : ℝ} (hl : 0 < lam) (hT : 0 ≤ T)
    (hh : ContinuousOn h (Icc 0 T)) :
    expVal h r lam Zl c T = (∫ t in (0:ℝ)..T, exp (-lam * t) * h t)
      + lam * Zl * (∫ t in (0:ℝ)..T, exp (-(r + lam) * t))
      + exp (-(r + lam) * T) * c := by
  set A : ℝ → ℝ := fun s => ∫ t in (0:ℝ)..s, h t with hA
  have hIh : IntegrableOn h (uIcc 0 T) := by rw [uIcc_of_le hT]; exact hh.integrableOn_Icc
  have hAc : ContinuousOn A (Icc 0 T) := by
    have := continuousOn_primitive_interval hIh; rwa [uIcc_of_le hT] at this
  have hAd : ∀ x ∈ Ioo 0 T, HasDerivAt A (h x) x := by
    intro x hx
    have hio : IntervalIntegrable h volume 0 x := by
      apply ContinuousOn.intervalIntegrable
      apply hh.mono; rw [uIcc_of_le hx.1.le]; exact Icc_subset_Icc le_rfl hx.2.le
    exact integral_hasDerivAt_right hio
      ((hh.mono Ioo_subset_Icc_self).stronglyMeasurableAtFilter isOpen_Ioo x hx)
      (hh.continuousAt (Icc_mem_nhds hx.1 hx.2))
  -- the integrand on each piece
  set f1 : ℝ → ℝ := fun τ => lam * exp (-lam * τ) * (A τ + exp (-r * τ) * Zl) with hf1
  set K : ℝ := A T + exp (-r * T) * c with hK
  have heq1 : ∀ τ ∈ Ioc (0:ℝ) T, lam * exp (-lam * τ) * payoff h r Zl c T τ = f1 τ := by
    intro τ hτ
    simp only [payoff, hf1, A, min_eq_left hτ.2, ite_eq_left hτ.2]
  have heq2 : ∀ τ ∈ Ioi T, lam * exp (-lam * τ) * payoff h r Zl c T τ =
      lam * K * exp (-lam * τ) := by
    intro τ hτ
    have hτ' : ¬ τ ≤ T := not_le.mpr hτ
    simp only [payoff, hK, A, min_eq_right (le_of_lt (show T < τ from hτ)), ite_eq_right hτ']; ring
  have hf1c : ContinuousOn f1 (Icc 0 T) := by
    simp only [hf1]
    exact (Continuous.continuousOn (by fun_prop)).mul
      (hAc.add (Continuous.continuousOn (by fun_prop)))
  have hi1 : IntegrableOn (fun τ => lam * exp (-lam * τ) * payoff h r Zl c T τ) (Ioc 0 T) :=
    ((hf1c.integrableOn_Icc).mono_set Ioc_subset_Icc_self).congr_fun
      (fun τ hτ => (heq1 τ hτ).symm) measurableSet_Ioc
  have hi2 : IntegrableOn (fun τ => lam * exp (-lam * τ) * payoff h r Zl c T τ) (Ioi T) :=
    IntegrableOn.congr_fun (((exp_neg_integrableOn_Ioi T hl).const_mul (lam * K) :
      IntegrableOn (fun τ => lam * K * exp (-lam * τ)) (Ioi T) volume))
      (fun τ hτ => (heq2 τ hτ).symm) measurableSet_Ioi
  unfold expVal
  rw [← Ioc_union_Ioi_eq_Ioi hT, setIntegral_union Ioc_disjoint_Ioi_same measurableSet_Ioi hi1 hi2,
    setIntegral_congr_fun measurableSet_Ioc heq1, setIntegral_congr_fun measurableSet_Ioi heq2,
    ← intervalIntegral.integral_of_le hT, MeasureTheory.integral_const_mul,
    integral_exp_mul_Ioi (by linarith : -lam < 0) T]
  -- integration by parts on `[0, T]`
  have hibp : ∫ τ in (0:ℝ)..T, (lam * exp (-lam * τ) * A τ - exp (-lam * τ) * h τ) =
      -exp (-lam * T) * A T - (-exp (-lam * 0) * A 0) := by
    apply intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le hT
    · exact (Continuous.continuousOn (by fun_prop)).mul hAc
    · intro x hx
      have he : HasDerivAt (fun τ => -exp (-lam * τ)) (-(exp (-lam * x) * (-lam * 1))) x :=
        (((hasDerivAt_id x).const_mul (-lam)).exp).neg
      exact (he.mul (hAd x hx)).congr_deriv (by ring)
    · apply ContinuousOn.intervalIntegrable
      rw [uIcc_of_le hT]
      exact ((Continuous.continuousOn (by fun_prop)).mul hAc).sub
        ((Continuous.continuousOn (by fun_prop)).mul hh)
  have hA0 : A 0 = 0 := by simp [A]
  have hcI : IntervalIntegrable (fun τ => exp (-lam * τ) * h τ) volume 0 T := by
    apply ContinuousOn.intervalIntegrable; rw [uIcc_of_le hT]
    exact (Continuous.continuousOn (by fun_prop)).mul hh
  have hAI : IntervalIntegrable (fun τ => lam * exp (-lam * τ) * A τ) volume 0 T := by
    apply ContinuousOn.intervalIntegrable; rw [uIcc_of_le hT]
    exact (Continuous.continuousOn (by fun_prop)).mul hAc
  have hZI : IntervalIntegrable (fun τ => lam * exp (-lam * τ) * (exp (-r * τ) * Zl)) volume 0 T := by
    apply Continuous.intervalIntegrable; fun_prop
  rw [intervalIntegral.integral_sub hAI hcI, hA0] at hibp
  have hsplit : ∫ τ in (0:ℝ)..T, f1 τ = (∫ τ in (0:ℝ)..T, lam * exp (-lam * τ) * A τ) +
      ∫ τ in (0:ℝ)..T, lam * exp (-lam * τ) * (exp (-r * τ) * Zl) := by
    rw [← intervalIntegral.integral_add hAI hZI]
    congr 1; funext τ; simp only [hf1]; ring
  have hZ : ∫ τ in (0:ℝ)..T, lam * exp (-lam * τ) * (exp (-r * τ) * Zl) =
      lam * Zl * (∫ t in (0:ℝ)..T, exp (-(r + lam) * t)) := by
    rw [← intervalIntegral.integral_const_mul]
    congr 1; funext τ
    have : exp (-(r + lam) * τ) = exp (-lam * τ) * exp (-r * τ) := by rw [← exp_add]; ring_nf
    rw [this]; ring
  rw [hsplit, hZ]
  have e1 : exp (-(r + lam) * T) = exp (-lam * T) * exp (-r * T) := by rw [← exp_add]; ring_nf
  have hk2 : lam * K * (-exp (-lam * T) / -lam) = K * exp (-lam * T) := by
    field_simp
  rw [hk2, e1, hK]
  linear_combination hibp

/-- The running discounted flow while holding, before the loss factor: `e^{−rt}(F + ρ(g(t)))`. -/
noncomputable def flow (ρ : ℝ → ℝ) (p : Prm) (t : ℝ) : ℝ := exp (-p.r * t) * (p.F + ρ (lead p t))

/-- The planned-release value as the paper derives it (A.6): the expected discounted payoff when
involuntary loss arrives at rate `λ`. -/
noncomputable def Vexp (ρ : ℝ → ℝ) (p : Prm) (T : ℝ) : ℝ :=
  expVal (flow ρ p) p.r p.lam p.Z (J ρ p T) T

theorem flow_continuousOn (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (T : ℝ) : ContinuousOn (flow ρ p) (Icc 0 T) := by
  have hmaps : MapsTo (lead p) (Icc 0 T) (Icc 0 (p.g0 + p.Δ)) := fun t ht => by
    have := lead_mem p hg hk ht.1; exact ⟨this.1, by linarith [this.2]⟩
  unfold flow
  exact (Continuous.continuousOn (by fun_prop)).mul
    (continuousOn_const.add (hρ.comp (lead_continuous p).continuousOn hmaps))

/-- The expected payoff of the model's running flow, for any loss value `Zl` and release
value `c`: `∫₀^T e^{−(r+λ)t}[F + λZl + ρ(g(t))]dt + e^{−(r+λ)T}c`. -/
theorem expVal_flow (ρ : ℝ → ℝ) (p : Prm) (hl : 0 < p.lam)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) {T : ℝ} (hT : 0 ≤ T) (Zl c : ℝ) :
    expVal (flow ρ p) p.r p.lam Zl c T =
      (∫ t in (0:ℝ)..T, exp (-(p.r + p.lam) * t) * (p.F + p.lam * Zl + ρ (lead p t)))
        + exp (-(p.r + p.lam) * T) * c := by
  rw [expVal_eq hl hT (flow_continuousOn ρ p hρ hg hΔ hk T), ← intervalIntegral.integral_const_mul]
  have hI1 : IntervalIntegrable (fun t => exp (-p.lam * t) * flow ρ p t) volume 0 T := by
    apply ContinuousOn.intervalIntegrable; rw [uIcc_of_le hT]
    exact (Continuous.continuousOn (by fun_prop)).mul (flow_continuousOn ρ p hρ hg hΔ hk T)
  have hI2 : IntervalIntegrable (fun t => p.lam * Zl * exp (-(p.r + p.lam) * t)) volume 0 T := by
    apply Continuous.intervalIntegrable; fun_prop
  rw [← intervalIntegral.integral_add hI1 hI2]
  congr 2
  funext t
  simp only [flow]
  have : exp (-(p.r + p.lam) * t) = exp (-p.lam * t) * exp (-p.r * t) := by
    rw [← exp_add]; ring_nf
  rw [this]; ring

/-- **P11(i), "a planned release at `T` is worth `V(T)`".** The expected discounted payoff
when involuntary loss arrives at rate `λ > 0` (A.6: "holding to `T` earns `F + ρ(g)` while
neither release nor loss has occurred … loss at rate `λ` yields `Z` … release at `T` yields
`J(T)`") equals the closed expression `V(T)` used everywhere else in this file. -/
theorem p11i_V_is_expectation (ρ : ℝ → ℝ) (p : Prm) (hl : 0 < p.lam)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) {T : ℝ} (hT : 0 ≤ T) : Vexp ρ p T = V ρ p T := by
  unfold Vexp
  rw [expVal_flow ρ p hl hρ hg hΔ hk hT]
  rfl

/-- With no loss hazard (`λ = 0`) there is no loss time to average over: `V(T)` is the
deterministic payoff `∫₀^T e^{−rt}(F + ρ(g(t)))dt + e^{−rT}J(T)`. -/
theorem p11i_V_no_hazard (ρ : ℝ → ℝ) (p : Prm) (hl : p.lam = 0) (T : ℝ) :
    V ρ p T = (∫ t in (0:ℝ)..T, flow ρ p t) + exp (-p.r * T) * J ρ p T := by
  simp [V, holdIntegrand, flow, hl]

/-! ### P11(ii): constant flows -/

theorem lead_noOld (p : Prm) (hg0 : p.g0 = 0) (t : ℝ) : lead p t = 0 := by
  simp [lead, hg0]

theorem J_noOld (ρ : ℝ → ℝ) (p : Prm) (hg0 : p.g0 = 0) :
    J ρ p = fun _ => Pi ρ p.r p.kpost p.Δ := by
  funext t; simp [J, lead_noOld p hg0]

/-- With no old public model the release value has the closed form
`V(T) = (F + λZ)(1 − e^{−(r+λ)T})/(r+λ) + e^{−(r+λ)T} Π(Δ)`. -/
theorem V_noOld (ρ : ℝ → ℝ) (p : Prm) (hg0 : p.g0 = 0) (hρ0 : ρ 0 = 0)
    (ha : p.r + p.lam ≠ 0) (T : ℝ) :
    V ρ p T = (p.F + p.lam * p.Z) * (1 - exp (-(p.r + p.lam) * T)) / (p.r + p.lam)
      + exp (-(p.r + p.lam) * T) * Pi ρ p.r p.kpost p.Δ := by
  have hI : (fun t => holdIntegrand ρ p t) =
      fun t => exp (-(p.r + p.lam) * t) * (p.F + p.lam * p.Z) := by
    funext t; simp [holdIntegrand, lead_noOld p hg0, hρ0]
  unfold V
  rw [hI, intervalIntegral.integral_mul_const, integral_exp_neg_mul ha, J_noOld ρ p hg0]
  ring

/-- **P11(ii): `Φ` is constant** with no old public model. -/
theorem p11ii_Phi_const (ρ : ℝ → ℝ) (p : Prm) (hg0 : p.g0 = 0) (hρ0 : ρ 0 = 0) (T : ℝ) :
    Phi ρ p T = p.F + p.lam * p.Z - (p.r + p.lam) * Pi ρ p.r p.kpost p.Δ := by
  simp [Phi, J_noOld ρ p hg0, lead_noOld p hg0, hρ0]

/-- The bang-bang trichotomy for any value of the form `c/a + e^{−aT}(P − c/a)`. -/
theorem bangbang_core {Vf : ℝ → ℝ} {a c P : ℝ} (ha : 0 < a)
    (hV : ∀ T, Vf T = c / a + exp (-a * T) * (P - c / a)) :
    (c < a * P → ∀ T, 0 < T → Vf T < Vf 0) ∧
      (a * P < c → (∀ T, Vf T < Vf (T + 1)) ∧ (∀ T, Vf T < c / a) ∧
        Tendsto Vf atTop (𝓝 (c / a))) ∧
      (c = a * P → ∀ T, Vf T = Vf 0) := by
  refine ⟨fun h T hT => ?_, fun h => ⟨fun T => ?_, fun T => ?_, ?_⟩, fun h T => ?_⟩
  · have hPc : c / a < P := by rw [div_lt_iff₀ ha]; linarith
    have he : exp (-a * T) < 1 := exp_lt_one_iff.mpr (by nlinarith)
    rw [hV T, hV 0, mul_zero, exp_zero]
    nlinarith
  · have hPc : P < c / a := by rw [lt_div_iff₀ ha]; linarith
    have he : exp (-a * (T + 1)) < exp (-a * T) := exp_lt_exp.mpr (by nlinarith)
    rw [hV T, hV (T + 1)]
    nlinarith
  · have hPc : P < c / a := by rw [lt_div_iff₀ ha]; linarith
    rw [hV T]
    nlinarith [exp_pos (-a * T)]
  · have hlim : Tendsto (fun T => exp (-a * T)) atTop (𝓝 0) :=
      tendsto_exp_atBot.comp (tendsto_id.const_mul_atTop_of_neg (by linarith))
    have := (tendsto_const_nhds (x := c / a)).add (hlim.mul_const (P - c / a))
    simp only [zero_mul, add_zero] at this
    exact this.congr (fun T => (hV T).symm)
  · have hPc : P = c / a := by field_simp; linarith
    rw [hV T, hV 0, hPc]; ring

/-- **P11(ii), the bang-bang trichotomy.** With no old public model and `r + λ > 0`:
release at once is the unique optimum if `F + λZ < (r+λ)Π(Δ)`; if the inequality is
reversed, every date is beaten by a later one and `V` rises to the value of holding until
involuntary loss, `(F + λZ)/(r + λ)`, which no date attains; at equality every date gives
the same value. -/
theorem p11ii_bangbang (ρ : ℝ → ℝ) (p : Prm) (hg0 : p.g0 = 0) (hρ0 : ρ 0 = 0)
    (ha : 0 < p.r + p.lam) :
    (p.F + p.lam * p.Z < (p.r + p.lam) * Pi ρ p.r p.kpost p.Δ →
        ∀ T, 0 < T → V ρ p T < V ρ p 0) ∧
      ((p.r + p.lam) * Pi ρ p.r p.kpost p.Δ < p.F + p.lam * p.Z →
        (∀ T, V ρ p T < V ρ p (T + 1)) ∧
        (∀ T, V ρ p T < (p.F + p.lam * p.Z) / (p.r + p.lam)) ∧
        Tendsto (V ρ p) atTop (𝓝 ((p.F + p.lam * p.Z) / (p.r + p.lam)))) ∧
      (p.F + p.lam * p.Z = (p.r + p.lam) * Pi ρ p.r p.kpost p.Δ →
        ∀ T, V ρ p T = V ρ p 0) := by
  have hV : ∀ T, V ρ p T = (p.F + p.lam * p.Z) / (p.r + p.lam) +
      exp (-(p.r + p.lam) * T) *
        (Pi ρ p.r p.kpost p.Δ - (p.F + p.lam * p.Z) / (p.r + p.lam)) := by
    intro T; rw [V_noOld ρ p hg0 hρ0 ha.ne' T]; field_simp; ring
  exact bangbang_core ha hV

/-- **P11(ii): faster post-release copying lowers `Π(Δ)`** (weakly, for a non-decreasing
rent continuous on `[0, Δ]`). -/
theorem p11ii_Pi_antitone (ρ : ℝ → ℝ) {r κ1 κ2 x : ℝ} (hr : 0 < r) (hκ1 : 0 ≤ κ1)
    (h12 : κ1 ≤ κ2) (hx : 0 ≤ x) (hρc : ContinuousOn ρ (Icc 0 x))
    (hρm : MonotoneOn ρ (Icc 0 x)) : Pi ρ r κ2 x ≤ Pi ρ r κ1 x := by
  unfold Pi
  apply setIntegral_mono_on (Pi_integrableOn ρ hr (by linarith) hx hρc)
    (Pi_integrableOn ρ hr hκ1 hx hρc) measurableSet_Ioi
  intro s hs
  have hs' : (0:ℝ) ≤ s := le_of_lt hs
  apply mul_le_mul_of_nonneg_left _ (exp_pos _).le
  apply hρm (scaled_mem hx (by linarith) hs') (scaled_mem hx hκ1 hs')
  exact mul_le_mul_of_nonneg_left (exp_le_exp.mpr (by nlinarith)) hx

/-- **P11(ii): faster post-release copying strictly lowers `Π(Δ)`** for a strictly
increasing rent and `Δ > 0`. -/
theorem p11ii_Pi_strictAnti (ρ : ℝ → ℝ) {r κ1 κ2 x : ℝ} (hr : 0 < r) (hκ1 : 0 ≤ κ1)
    (h12 : κ1 < κ2) (hx : 0 < x) (hρc : ContinuousOn ρ (Icc 0 x))
    (hρm : StrictMonoOn ρ (Icc 0 x)) : Pi ρ r κ2 x < Pi ρ r κ1 x := by
  have i1 := Pi_integrableOn ρ hr hκ1 hx.le hρc
  have i2 := Pi_integrableOn ρ hr (by linarith : 0 ≤ κ2) hx.le hρc
  have hpos : ∀ s ∈ Ioi (0:ℝ), 0 < exp (-r * s) * ρ (x * exp (-κ1 * s)) -
      exp (-r * s) * ρ (x * exp (-κ2 * s)) := by
    intro s hs
    have hs' : (0:ℝ) ≤ s := le_of_lt hs
    have hlt : x * exp (-κ2 * s) < x * exp (-κ1 * s) :=
      mul_lt_mul_of_pos_left (exp_lt_exp.mpr (by nlinarith [show (0:ℝ) < s from hs])) hx
    have := hρm (scaled_mem hx.le (by linarith) hs') (scaled_mem hx.le hκ1 hs') hlt
    nlinarith [exp_pos (-r * s)]
  have hdiff : Pi ρ r κ1 x - Pi ρ r κ2 x = ∫ s in Ioi (0:ℝ),
      (exp (-r * s) * ρ (x * exp (-κ1 * s)) - exp (-r * s) * ρ (x * exp (-κ2 * s))) :=
    (integral_sub i1 i2).symm
  have hsub := setIntegral_mono_set (s := Ioc (0:ℝ) 1) (i1.sub i2)
    ((ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => (hpos s hs).le))
    (Ioc_subset_Ioi_self.eventuallyLE)
  have hii : IntervalIntegrable (fun s => exp (-r * s) * ρ (x * exp (-κ1 * s)) -
      exp (-r * s) * ρ (x * exp (-κ2 * s))) volume 0 1 :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le zero_le_one).mpr
      ((i1.sub i2).mono_set Ioc_subset_Ioi_self)
  have hpos1 := intervalIntegral_pos_of_pos_on hii (fun s hs => hpos s hs.1) zero_lt_one
  rw [intervalIntegral.integral_of_le zero_le_one] at hpos1
  simp only [_root_.Pi.sub_apply] at hsub
  linarith

/-- **P11(ii): faster post-release copying pushes toward holding.** If holding is strictly
optimal at post-release copy rate `κ`, it stays strictly optimal at any faster rate. -/
theorem p11ii_faster_post_keeps_hold (ρ : ℝ → ℝ) (p : Prm) {κ2 : ℝ} (hr : 0 < p.r)
    (ha : 0 < p.r + p.lam) (hκ : 0 ≤ p.kpost) (h12 : p.kpost ≤ κ2) (hΔ : 0 ≤ p.Δ)
    (hρc : ContinuousOn ρ (Icc 0 p.Δ)) (hρm : MonotoneOn ρ (Icc 0 p.Δ))
    (hhold : (p.r + p.lam) * Pi ρ p.r p.kpost p.Δ < p.F + p.lam * p.Z) :
    (p.r + p.lam) * Pi ρ p.r κ2 p.Δ < p.F + p.lam * p.Z := by
  have := p11ii_Pi_antitone ρ hr hκ h12 hΔ hρc hρm
  nlinarith

/-! ### A constant old lead (`κ_pre = 0`): also bang-bang -/

theorem lead_constLead (p : Prm) (hk0 : p.kpre = 0) (t : ℝ) : lead p t = p.g0 := by
  simp [lead, hk0]

/-- With `κ_pre = 0` the old lead stays at `g₀`, and `V` has the bang-bang form with flow
`F + λZ + ρ(g₀)` and release value `Π(g₀ + Δ)`. -/
theorem V_constLead (ρ : ℝ → ℝ) (p : Prm) (hk0 : p.kpre = 0) (ha : p.r + p.lam ≠ 0) (T : ℝ) :
    V ρ p T = (p.F + p.lam * p.Z + ρ p.g0) * (1 - exp (-(p.r + p.lam) * T)) / (p.r + p.lam)
      + exp (-(p.r + p.lam) * T) * Pi ρ p.r p.kpost (p.g0 + p.Δ) := by
  have hI : (fun t => holdIntegrand ρ p t) =
      fun t => exp (-(p.r + p.lam) * t) * (p.F + p.lam * p.Z + ρ p.g0) := by
    funext t; simp [holdIntegrand, lead_constLead p hk0]
  unfold V
  rw [hI, intervalIntegral.integral_mul_const, integral_exp_neg_mul ha]
  simp only [J, lead_constLead p hk0]
  ring

/-- **A constant old lead is bang-bang.** With `κ_pre = 0`: release at once is the unique
optimum if `F + λZ + ρ(g₀) < (r+λ)Π(g₀+Δ)`; if reversed, `V` rises strictly to the value of
holding, which no date attains; at equality every date gives the same value. -/
theorem p11_constLead_bangbang (ρ : ℝ → ℝ) (p : Prm) (hk0 : p.kpre = 0)
    (ha : 0 < p.r + p.lam) :
    (p.F + p.lam * p.Z + ρ p.g0 < (p.r + p.lam) * Pi ρ p.r p.kpost (p.g0 + p.Δ) →
        ∀ T, 0 < T → V ρ p T < V ρ p 0) ∧
      ((p.r + p.lam) * Pi ρ p.r p.kpost (p.g0 + p.Δ) < p.F + p.lam * p.Z + ρ p.g0 →
        (∀ T, V ρ p T < V ρ p (T + 1)) ∧
        (∀ T, V ρ p T < (p.F + p.lam * p.Z + ρ p.g0) / (p.r + p.lam)) ∧
        Tendsto (V ρ p) atTop (𝓝 ((p.F + p.lam * p.Z + ρ p.g0) / (p.r + p.lam)))) ∧
      (p.F + p.lam * p.Z + ρ p.g0 = (p.r + p.lam) * Pi ρ p.r p.kpost (p.g0 + p.Δ) →
        ∀ T, V ρ p T = V ρ p 0) :=
  bangbang_core ha (fun T => by rw [V_constLead ρ p hk0 ha.ne' T]; field_simp; ring)

/-! ### Linear and power rents: `Π` from its integral, and `rΠ = ρ − κxΠ′` -/

/-- `Π(x) = Mx/(r+κ)` for linear rents, computed from the integral. -/
theorem Pi_linear (M : ℝ) {r κ : ℝ} (h : 0 < r + κ) (x : ℝ) :
    Pi (fun y => M * y) r κ x = M * x / (r + κ) := by
  unfold Pi
  rw [setIntegral_congr_fun measurableSet_Ioi
    (g := fun s => (M * x) * exp (-(r + κ) * s)) (fun s _ => by
      have : exp (-(r + κ) * s) = exp (-r * s) * exp (-κ * s) := by
        rw [← exp_add]; ring_nf
      simp only [this]; ring)]
  rw [MeasureTheory.integral_const_mul, integral_exp_neg_Ioi_pos h]
  field_simp

/-- `Π(x) = Mx^η/(r+ηκ)` for power rents (`x ≥ 0`), computed from the integral. -/
theorem Pi_power (M η : ℝ) {r κ x : ℝ} (h : 0 < r + η * κ) (hx : 0 ≤ x) :
    Pi (fun y => M * y ^ η) r κ x = M * x ^ η / (r + η * κ) := by
  unfold Pi
  rw [setIntegral_congr_fun measurableSet_Ioi
    (g := fun s => (M * x ^ η) * exp (-(r + η * κ) * s)) (fun s _ => by
      have : exp (-(r + η * κ) * s) = exp (-r * s) * exp (-κ * s * η) := by
        rw [← exp_add]; ring_nf
      simp only [mul_rpow hx (exp_pos _).le, ← exp_mul, this]; ring)]
  rw [MeasureTheory.integral_const_mul, integral_exp_neg_Ioi_pos h]
  field_simp

/-- **P11(ii), `rΠ = ρ − κxΠ′` for linear rents**, with `Π′` the derivative of the integral. -/
theorem p11ii_ode_linear (M : ℝ) {r κ : ℝ} (h : 0 < r + κ) (x : ℝ) :
    HasDerivAt (Pi (fun y => M * y) r κ) (M / (r + κ)) x ∧
      r * Pi (fun y => M * y) r κ x = M * x - κ * x * (M / (r + κ)) := by
  have hf : Pi (fun y => M * y) r κ = fun x => M * x / (r + κ) := funext (Pi_linear M h)
  refine ⟨?_, ?_⟩
  · rw [hf]
    have := ((hasDerivAt_id x).const_mul M).div_const (r + κ)
    simpa using this
  · rw [Pi_linear M h]; field_simp; ring

/-- **P11(ii), `rΠ = ρ − κxΠ′` for power rents** at every lead `x > 0`, with `Π′` the
derivative of the integral. -/
theorem p11ii_ode_power (M η : ℝ) {r κ x : ℝ} (h : 0 < r + η * κ) (hx : 0 < x) :
    HasDerivAt (Pi (fun y => M * y ^ η) r κ) (M * η * x ^ (η - 1) / (r + η * κ)) x ∧
      r * Pi (fun y => M * y ^ η) r κ x =
        M * x ^ η - κ * x * (M * η * x ^ (η - 1) / (r + η * κ)) := by
  have hev : Pi (fun y => M * y ^ η) r κ =ᶠ[𝓝 x] fun y => M * y ^ η / (r + η * κ) := by
    filter_upwards [Ioi_mem_nhds hx] with y hy
    exact Pi_power M η h (le_of_lt hy)
  refine ⟨?_, ?_⟩
  · have h1 : HasDerivAt (fun y => M * y ^ η / (r + η * κ))
        (M * (η * x ^ (η - 1)) / (r + η * κ)) x :=
      ((hasDerivAt_rpow_const (Or.inl hx.ne')).const_mul M).div_const _
    have := h1.congr_of_eventuallyEq hev
    convert this using 1; ring
  · have hxx : x * x ^ (η - 1) = x ^ η := by
      have := rpow_add hx 1 (η - 1)
      rw [rpow_one] at this
      rw [← this]; congr 1; ring
    rw [Pi_power M η h hx.le, ← hxx]
    field_simp
    ring

/-- **`rΠ = ρ − κxΠ′` at `κ_post = 0`, any rent.** Then `Π(x) = ρ(x)/r` from the integral,
and the identity reads `rΠ = ρ` (the `κ_post·x·Π′` term vanishes). -/
theorem Pi_kpost_zero (ρ : ℝ → ℝ) {r : ℝ} (hr : 0 < r) (x : ℝ) :
    Pi ρ r 0 x = ρ x / r ∧ r * Pi ρ r 0 x = ρ x - 0 * x * deriv (Pi ρ r 0) x := by
  have h : Pi ρ r 0 x = ρ x / r := by
    unfold Pi
    rw [setIntegral_congr_fun measurableSet_Ioi (g := fun s => ρ x * exp (-r * s))
      (fun s _ => by simp only [neg_zero, zero_mul, exp_zero, mul_one]; ring)]
    rw [MeasureTheory.integral_const_mul, integral_exp_neg_Ioi_pos hr]; ring
  refine ⟨h, ?_⟩
  rw [h, zero_mul, zero_mul, sub_zero]
  field_simp

/-! ### The current lead falls over time -/

theorem lead_nonneg (p : Prm) (hg : 0 ≤ p.g0) (t : ℝ) : 0 ≤ lead p t :=
  mul_nonneg hg (exp_pos _).le

theorem lead_le (p : Prm) (hg : 0 ≤ p.g0) (hk : 0 ≤ p.kpre) {T t : ℝ} (h : T ≤ t) :
    lead p t ≤ lead p T :=
  mul_le_mul_of_nonneg_left (exp_le_exp.mpr (by nlinarith)) hg

theorem lead_lt (p : Prm) (hg : 0 < p.g0) (hk : 0 < p.kpre) {T t : ℝ} (h : T < t) :
    lead p t < lead p T :=
  mul_lt_mul_of_pos_left (exp_lt_exp.mpr (by nlinarith)) hg

/-! ### P11(iii): linear rents -/

theorem J_linear (M : ℝ) (p : Prm) (h : 0 < p.r + p.kpost) :
    J (fun y => M * y) p = fun T => M * (lead p T + p.Δ) / (p.r + p.kpost) := by
  funext T; exact Pi_linear M h _

theorem J_linear_hasDerivAt (M : ℝ) (p : Prm) (h : 0 < p.r + p.kpost) (T : ℝ) :
    HasDerivAt (J (fun y => M * y) p) (M * (-p.kpre * lead p T) / (p.r + p.kpost)) T := by
  rw [J_linear M p h]
  exact (((lead_hasDerivAt p T).add_const p.Δ).const_mul M).div_const (p.r + p.kpost)

/-- **P11(iii), the stopping function for linear rents**, from the defined `Φ`:
`Φ = F + λZ − (r+λ)MΔ/(r+κ_post) + M g(T)(κ_post − κ_pre − λ)/(r+κ_post)`. -/
theorem p11iii_Phi (M : ℝ) (p : Prm) (h : 0 < p.r + p.kpost) (T : ℝ) :
    Phi (fun y => M * y) p T = p.F + p.lam * p.Z - (p.r + p.lam) * M * p.Δ / (p.r + p.kpost)
      + M * lead p T * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost) := by
  unfold Phi
  rw [(J_linear_hasDerivAt M p h T).deriv]
  simp only [J_linear M p h]
  field_simp
  ring

theorem linρ_cont (M : ℝ) (s : Set ℝ) : ContinuousOn (fun y : ℝ => M * y) s :=
  (continuous_const.mul continuous_id).continuousOn

theorem linV_hasDerivAt (M : ℝ) (p : Prm) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ) (hk : 0 ≤ p.kpre)
    (h : 0 < p.r + p.kpost) {T : ℝ} (hT : 0 < T) :
    HasDerivAt (V (fun y => M * y) p)
      (exp (-(p.r + p.lam) * T) * Phi (fun y => M * y) p T) T :=
  p11i_V_hasDerivAt _ p (linρ_cont M _) hg hΔ hk hT
    (J_linear_hasDerivAt M p h T).differentiableAt

theorem linJ_contWithin0 (M : ℝ) (p : Prm) (h : 0 < p.r + p.kpost) :
    ContinuousWithinAt (J (fun y => M * y) p) (Ici 0) 0 := by
  rw [J_linear M p h]
  exact Continuous.continuousWithinAt (by unfold lead; fun_prop)

theorem linV_contOn (M : ℝ) (p : Prm) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ) (hk : 0 ≤ p.kpre)
    (h : 0 < p.r + p.kpost) : ContinuousOn (V (fun y => M * y) p) (Ici 0) :=
  contOn_Ici_of (V_contWithin0 _ p (linρ_cont M _) hg hΔ hk (linJ_contWithin0 M p h))
    (fun _ hT => linV_hasDerivAt M p hg hΔ hk h hT)

/-- **P11(iii): a strict interior maximum requires `κ_post > κ_pre + λ`.** A strict local
maximum of `V` at an interior date is impossible when `κ_post ≤ κ_pre + λ`. -/
theorem p11iii_strict_interior_requires (M : ℝ) (p : Prm) (hM : 0 ≤ M) (hg : 0 ≤ p.g0)
    (hΔ : 0 ≤ p.Δ) (hk : 0 ≤ p.kpre) (h : 0 < p.r + p.kpost) {T : ℝ} (hT : 0 < T)
    (hstrict : ∀ᶠ t in 𝓝[≠] T, V (fun y => M * y) p t < V (fun y => M * y) p T) :
    p.kpre + p.lam < p.kpost := by
  by_contra hcon
  push Not at hcon
  have hloc : IsLocalMax (V (fun y => M * y) p) T := by
    have := eventually_nhdsWithin_iff.mp hstrict
    filter_upwards [this] with t ht
    by_cases htT : t = T
    · rw [htT]
    · exact (ht htT).le
  have hP0 := (p11i_foc _ p (linρ_cont M _) hg hΔ hk hT
    (J_linear_hasDerivAt M p h T).differentiableAt hloc).1
  rw [p11iii_Phi M p h T] at hP0
  have hPnn : ∀ t, T ≤ t → 0 ≤ Phi (fun y => M * y) p t := by
    intro t ht
    have hl := lead_le p hg hk ht
    rw [p11iii_Phi M p h t]
    have h1 : 0 ≤ M * (lead p t - lead p T) * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost) :=
      div_nonneg (mul_nonneg_of_nonpos_of_nonpos
        (mul_nonpos_of_nonneg_of_nonpos hM (by linarith)) (by linarith)) h.le
    have e : M * lead p t * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost) =
        M * lead p T * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost) +
        M * (lead p t - lead p T) * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost) := by ring
    linarith
  have hmono : MonotoneOn (V (fun y => M * y) p) (Icc T (T + 1)) := by
    apply monotoneOn_of_deriv_nonneg (convex_Icc _ _)
    · exact (linV_contOn M p hg hΔ hk h).mono (fun x hx => le_trans hT.le hx.1)
    · intro x hx; rw [interior_Icc] at hx
      exact (linV_hasDerivAt M p hg hΔ hk h (lt_trans hT hx.1)).differentiableAt.differentiableWithinAt
    · intro x hx; rw [interior_Icc] at hx
      rw [(linV_hasDerivAt M p hg hΔ hk h (lt_trans hT hx.1)).deriv]
      exact mul_nonneg (exp_pos _).le (hPnn x hx.1.le)
  have hev : ∀ᶠ t in 𝓝[>] T, V (fun y => M * y) p t < V (fun y => M * y) p T :=
    hstrict.filter_mono (nhdsWithin_mono T (fun x hx => ne_of_gt hx))
  obtain ⟨t, _, ht2⟩ := (hev.and (Ioo_mem_nhdsGT (show T < T + 1 by linarith))).exists
  have := hmono ⟨le_rfl, by linarith⟩ ⟨ht2.1.le, ht2.2.le⟩ ht2.1.le
  linarith

/-- **P11(iii), the equality case.** With `κ_post = κ_pre + λ` and
`F + λZ = (r+λ)MΔ/(r+κ_post)`, `Φ ≡ 0` and every release date gives the same value. -/
theorem p11iii_equality (M : ℝ) (p : Prm) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ) (hk : 0 ≤ p.kpre)
    (h : 0 < p.r + p.kpost) (hkk : p.kpost = p.kpre + p.lam)
    (hF : p.F + p.lam * p.Z = (p.r + p.lam) * M * p.Δ / (p.r + p.kpost)) :
    (∀ T, Phi (fun y => M * y) p T = 0) ∧
      ∀ T, 0 ≤ T → V (fun y => M * y) p T = V (fun y => M * y) p 0 := by
  have hP : ∀ T, Phi (fun y => M * y) p T = 0 := by
    intro T; rw [p11iii_Phi M p h T, hF, hkk]; ring
  refine ⟨hP, fun T hT => ?_⟩
  rcases eq_or_lt_of_le hT with h0 | h0
  · rw [← h0]
  have hc := (linV_contOn M p hg hΔ hk h).mono
    (show Icc (0:ℝ) T ⊆ Ici 0 from Icc_subset_Ici_self)
  have hd : DifferentiableOn ℝ (V (fun y => M * y) p) (interior (Icc 0 T)) := by
    intro x hx; rw [interior_Icc] at hx
    exact (linV_hasDerivAt M p hg hΔ hk h hx.1).differentiableAt.differentiableWithinAt
  have hz : ∀ x ∈ interior (Icc 0 T), deriv (V (fun y => M * y) p) x = 0 := by
    intro x hx; rw [interior_Icc] at hx
    rw [(linV_hasDerivAt M p hg hΔ hk h hx.1).deriv, hP x, mul_zero]
  have h1 := monotoneOn_of_deriv_nonneg (convex_Icc 0 T) hc hd (fun x hx => (hz x hx).ge)
  have h2 := antitoneOn_of_deriv_nonpos (convex_Icc 0 T) hc hd (fun x hx => (hz x hx).le)
  have a1 := h1 ⟨le_rfl, hT⟩ ⟨hT, le_rfl⟩ hT
  have a2 := h2 ⟨le_rfl, hT⟩ ⟨hT, le_rfl⟩ hT
  linarith

/-- **P11(iii), below the line `κ_post = κ_pre + λ` no interior date is even a local
maximum** (old model present, `M, κ_pre > 0`). -/
theorem p11iii_no_interior_localMax (M : ℝ) (p : Prm) (hM : 0 < M) (hg : 0 < p.g0)
    (hΔ : 0 ≤ p.Δ) (hk : 0 < p.kpre) (h : 0 < p.r + p.kpost)
    (hlt : p.kpost < p.kpre + p.lam) {T : ℝ} (hT : 0 < T) :
    ¬ IsLocalMax (V (fun y => M * y) p) T := by
  intro hloc
  have hP0 := (p11i_foc _ p (linρ_cont M _) hg.le hΔ hk.le hT
    (J_linear_hasDerivAt M p h T).differentiableAt hloc).1
  rw [p11iii_Phi M p h T] at hP0
  have hPpos : ∀ t, T < t → 0 < Phi (fun y => M * y) p t := by
    intro t ht
    have hl := lead_lt p hg hk ht
    rw [p11iii_Phi M p h t]
    have h1 : 0 < M * (lead p t - lead p T) * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost) :=
      div_pos (mul_pos_of_neg_of_neg (mul_neg_of_pos_of_neg hM (by linarith)) (by linarith)) h
    have e : M * lead p t * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost) =
        M * lead p T * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost) +
        M * (lead p t - lead p T) * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost) := by ring
    linarith
  have hmono : StrictMonoOn (V (fun y => M * y) p) (Icc T (T + 1)) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc _ _)
    · exact (linV_contOn M p hg.le hΔ hk.le h).mono (fun x hx => le_trans hT.le hx.1)
    · intro x hx; rw [interior_Icc] at hx
      rw [(linV_hasDerivAt M p hg.le hΔ hk.le h (lt_trans hT hx.1)).deriv]
      exact mul_pos (exp_pos _) (hPpos x hx.1)
  have hev : ∀ᶠ t in 𝓝[>] T, V (fun y => M * y) p t ≤ V (fun y => M * y) p T :=
    hloc.filter_mono nhdsWithin_le_nhds
  obtain ⟨t, ht1, ht2⟩ := (hev.and (Ioo_mem_nhdsGT (show T < T + 1 by linarith))).exists
  have := hmono ⟨le_rfl, by linarith⟩ ⟨ht2.1.le, ht2.2.le⟩ ht2.1
  linarith

/-- **P11(iii): with one copy rate the optimum is a corner.** With `κ_pre = κ_post` and
`λ > 0`, every maximizer of `V` on `[0, ∞)` is `T = 0`. -/
theorem p11iii_one_rate_corner (M : ℝ) (p : Prm) (hM : 0 < M) (hg : 0 < p.g0)
    (hΔ : 0 ≤ p.Δ) (hk : 0 < p.kpre) (h : 0 < p.r + p.kpost) (hκ : p.kpost = p.kpre)
    (hlam : 0 < p.lam) {T : ℝ} (hT : 0 ≤ T) (hmax : IsMaxOn (V (fun y => M * y) p) (Ici 0) T) :
    T = 0 := by
  rcases eq_or_lt_of_le hT with h0 | h0
  · exact h0.symm
  exact absurd (hmax.isLocalMax (Ici_mem_nhds h0))
    (p11iii_no_interior_localMax M p hM hg hΔ hk h (by linarith) h0)

/-- **P11(iii) / §8.3: below the line a corner is optimal** (linear rents, eroding old model,
`M, g₀, κ_pre > 0`, `κ_post < κ_pre + λ`). Every maximizer of `V` on `[0, ∞)` is `T = 0`; if
no date maximizes `V`, holding until involuntary loss is optimal (`V → Vhold`, every date
strictly worse). The non-eroding cases are bang-bang: `p11ii_bangbang` (`g₀ = 0`) and
`p11_constLead_bangbang` (`κ_pre = 0`). -/
theorem p11iii_below_line_corner (M : ℝ) (p : Prm) (hM : 0 < M) (hg : 0 < p.g0)
    (hΔ : 0 ≤ p.Δ) (hk : 0 < p.kpre) (hr : 0 < p.r) (hl : 0 ≤ p.lam) (hκ : 0 ≤ p.kpost)
    (hlt : p.kpost < p.kpre + p.lam) :
    (∀ T, 0 ≤ T → IsMaxOn (V (fun y => M * y) p) (Ici 0) T → T = 0) ∧
      ((¬ ∃ T, 0 ≤ T ∧ IsMaxOn (V (fun y => M * y) p) (Ici 0) T) →
        Tendsto (V (fun y => M * y) p) atTop (𝓝 (Vhold (fun y => M * y) p)) ∧
        ∀ T, 0 ≤ T → V (fun y => M * y) p T < Vhold (fun y => M * y) p) := by
  have h : 0 < p.r + p.kpost := by linarith
  refine ⟨fun T hT hmax => ?_, fun hno => p11i_hold_optimal _ p (linρ_cont M _) hg.le hΔ hk.le
    hr hl hκ (fun T _ => (J_linear_hasDerivAt M p h T).differentiableAt) hno⟩
  rcases eq_or_lt_of_le hT with h0 | h0
  · exact h0.symm
  · exact absurd (hmax.isLocalMax (Ici_mem_nhds h0))
      (p11iii_no_interior_localMax M p hM hg hΔ hk h hlt h0)

/-- Linear rents on the line `κ_post = κ_pre + λ`: `M = r = λ = κ_pre = g₀ = Δ = 1`,
`κ_post = 2`, `Z = 0`, `F = 2/3`. -/
noncomputable def pEq : Prm :=
  { r := 1, lam := 1, F := 2/3, Z := 0, kpre := 1, kpost := 2, g0 := 1, Δ := 1 }

/-- **Counterexample to the §1 wording (L30).** An interior optimum need not have
`κ_post > κ_pre + λ`: in `pEq`, `κ_post = κ_pre + λ`, every date gives the same value, so the
interior date `T = 1` is a (non-strict) global optimum. -/
theorem l30_equality_counterexample :
    pEq.kpost = pEq.kpre + pEq.lam ∧ IsMaxOn (V (fun y => 1 * y) pEq) (Ici 0) 1 ∧
      ∀ T, 0 ≤ T → V (fun y => 1 * y) pEq T = V (fun y => 1 * y) pEq 1 := by
  have h := (p11iii_equality 1 pEq (by norm_num [pEq]) (by norm_num [pEq]) (by norm_num [pEq])
    (by norm_num [pEq]) (by norm_num [pEq]) (by norm_num [pEq])).2
  refine ⟨by norm_num [pEq], isMaxOn_iff.mpr (fun T hT => ?_), fun T hT => ?_⟩
  · rw [h T hT, h 1 zero_le_one]
  · rw [h T hT, h 1 zero_le_one]

/-! ### Power rents: closed forms -/

/-- `V` for power rents, computed from the defining integrals. -/
theorem V_power (M η : ℝ) (p : Prm) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (ha : 0 < p.r + p.lam) (hb : 0 < p.r + p.lam + η * p.kpre) (hc : 0 < p.r + η * p.kpost)
    (T : ℝ) :
    V (fun y => M * y ^ η) p T =
      (p.F + p.lam * p.Z) * (1 - exp (-(p.r + p.lam) * T)) / (p.r + p.lam)
      + M * p.g0 ^ η * (1 - exp (-(p.r + p.lam + η * p.kpre) * T)) / (p.r + p.lam + η * p.kpre)
      + exp (-(p.r + p.lam) * T) * (M * (lead p T + p.Δ) ^ η / (p.r + η * p.kpost)) := by
  have hI : (fun t => holdIntegrand (fun y => M * y ^ η) p t) = fun t =>
      exp (-(p.r + p.lam) * t) * (p.F + p.lam * p.Z) +
        (M * p.g0 ^ η) * exp (-(p.r + p.lam + η * p.kpre) * t) := by
    funext t
    simp only [holdIntegrand, lead]
    rw [mul_rpow hg (exp_pos _).le, ← exp_mul]
    have : exp (-(p.r + p.lam + η * p.kpre) * t) =
        exp (-(p.r + p.lam) * t) * exp (-p.kpre * t * η) := by rw [← exp_add]; ring_nf
    rw [this]; ring
  unfold V
  rw [hI, intervalIntegral.integral_add (by apply Continuous.intervalIntegrable; fun_prop)
      (by apply Continuous.intervalIntegrable; fun_prop),
    intervalIntegral.integral_mul_const, intervalIntegral.integral_const_mul,
    integral_exp_neg_mul ha.ne', integral_exp_neg_mul hb.ne']
  simp only [J, Pi_power M η hc (add_nonneg (lead_nonneg p hg T) hΔ)]
  ring

/-! ### P11(iv): concave rents, an interior release -/

/-- The example of (iv): `ρ = √x` (`M = 1`, `η = 1/2`), `r = λ = 1/4`, `κ_pre = κ_post = 1`,
`g₀ = 36`, `Δ = 160`, `F = 6`, `Z = 0`. -/
noncomputable def pIV : Prm :=
  { r := 1/4, lam := 1/4, F := 6, Z := 0, kpre := 1, kpost := 1, g0 := 36, Δ := 160 }

theorem rpow_half_eq_sqrt (x : ℝ) : x ^ (1/2 : ℝ) = Real.sqrt x := (Real.sqrt_eq_rpow x).symm

theorem pIV_V (T : ℝ) :
    V (fun y => 1 * y ^ (1/2 : ℝ)) pIV T =
      12 * (1 - exp (-T / 2)) + 6 * (1 - exp (-T / 2) ^ 2) +
        4 / 3 * exp (-T / 2) * Real.sqrt (36 * exp (-T / 2) ^ 2 + 160) := by
  rw [V_power 1 (1/2) pIV (by norm_num [pIV]) (by norm_num [pIV]) (by norm_num [pIV])
    (by norm_num [pIV]) (by norm_num [pIV]) T]
  have e1 : exp (-T) = exp (-T / 2) ^ 2 := by rw [← exp_nat_mul]; ring_nf
  have e2 : (36:ℝ) ^ (1/2 : ℝ) = 6 := by
    rw [rpow_half_eq_sqrt, show (36:ℝ) = 6 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  simp only [pIV, lead, rpow_half_eq_sqrt] at *
  rw [show Real.sqrt 36 = 6 by rw [show (36:ℝ) = 6 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]]
  have e3 : -(1/4 + 1/4 : ℝ) * T = -T / 2 := by ring
  have e4 : -(1/4 + 1/4 + 1/2 * 1 : ℝ) * T = -T := by ring
  have e5 : -(1:ℝ) * T = -T := by ring
  rw [e3, e4, e5, e1]
  ring

/-- **P11(iv): interior releases can arise under concave rents.** In the example `pIV`, a date
`T* > 0` maximizes `V` over all of `[0, ∞)`; it strictly beats releasing at once, and beats every
date `T ≥ 2 ln 56`, hence also holding until involuntary loss. -/
theorem p11iv_interior_release :
    ∃ Ts, 0 < Ts ∧ IsMaxOn (V (fun y => 1 * y ^ (1/2 : ℝ)) pIV) (Ici 0) Ts ∧
      V (fun y => 1 * y ^ (1/2 : ℝ)) pIV 0 < V (fun y => 1 * y ^ (1/2 : ℝ)) pIV Ts ∧
      ∀ T, 2 * Real.log 56 ≤ T →
        V (fun y => 1 * y ^ (1/2 : ℝ)) pIV T < V (fun y => 1 * y ^ (1/2 : ℝ)) pIV Ts := by
  set Vf := V (fun y => 1 * y ^ (1/2 : ℝ)) pIV with hVf
  have hcont : Continuous Vf := by
    have : Vf = fun T => 12 * (1 - exp (-T / 2)) + 6 * (1 - exp (-T / 2) ^ 2) +
        4 / 3 * exp (-T / 2) * Real.sqrt (36 * exp (-T / 2) ^ 2 + 160) := funext pIV_V
    rw [this]; fun_prop
  set B := 2 * Real.log 56 with hB
  have hB0 : 0 ≤ B := by have := Real.log_nonneg (show (1:ℝ) ≤ 56 by norm_num); linarith
  -- value at T₁ = 2 ln 2
  have hT1 : Vf (2 * Real.log 2) = 115 / 6 := by
    rw [hVf, pIV_V]
    have : exp (-(2 * Real.log 2) / 2) = 1 / 2 := by
      rw [show -(2 * Real.log 2) / 2 = -Real.log 2 by ring, exp_neg, exp_log (by norm_num)]
      norm_num
    rw [this, show (36:ℝ) * (1/2) ^ 2 + 160 = 13 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
    norm_num
  have hV0 : Vf 0 = 56 / 3 := by
    rw [hVf, pIV_V]
    simp only [neg_zero, zero_div, exp_zero]
    rw [show (36:ℝ) * 1 ^ 2 + 160 = 14 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
    norm_num
  have htail : ∀ T, B ≤ T → Vf T ≤ 55 / 3 := by
    intro T hT
    rw [hVf, pIV_V]
    set E := exp (-T / 2) with hE
    have hE0 : 0 ≤ E := (exp_pos _).le
    have hE1 : E ≤ 1 / 56 := by
      rw [hE, show (1:ℝ) / 56 = exp (-Real.log 56) by rw [exp_neg, exp_log (by norm_num)]; norm_num]
      exact exp_le_exp.mpr (by linarith)
    have hs : Real.sqrt (36 * E ^ 2 + 160) ≤ 14 := by
      rw [show (14:ℝ) = Real.sqrt (14 ^ 2) by rw [Real.sqrt_sq (by norm_num)]]
      exact Real.sqrt_le_sqrt (by nlinarith)
    have hs0 := Real.sqrt_nonneg (36 * E ^ 2 + 160)
    nlinarith
  have hT1mem : 2 * Real.log 2 ∈ Icc 0 B := by
    refine ⟨by have := Real.log_nonneg (show (1:ℝ) ≤ 2 by norm_num); linarith, ?_⟩
    have := Real.log_le_log (by norm_num : (0:ℝ) < 2) (by norm_num : (2:ℝ) ≤ 56)
    linarith
  obtain ⟨Ts, hTs, hmax⟩ := isCompact_Icc.exists_isMaxOn (nonempty_Icc.mpr hB0)
    hcont.continuousOn
  have hge : 115 / 6 ≤ Vf Ts := by rw [← hT1]; exact hmax hT1mem
  have hTs0 : 0 < Ts := by
    rcases eq_or_lt_of_le hTs.1 with h | h
    · rw [← h, hV0] at hge; norm_num at hge
    · exact h
  refine ⟨Ts, hTs0, fun T hT => ?_, by rw [hV0]; linarith, fun T hT => ?_⟩
  · by_cases hTB : T ≤ B
    · exact hmax ⟨hT, hTB⟩
    · push Not at hTB
      have := htail T hTB.le
      show Vf T ≤ Vf Ts
      linarith
  · have := htail T hT
    linarith

/-- **P11(iv), the mechanism.** For `ρ = Mx^η` with `0 < η < 1`, the gain from releasing,
`ρ(g + Δ) − ρ(g)`, is strictly decreasing in the old lead `g ≥ 0`. -/
theorem p11iv_gain_grows (M η Δ : ℝ) (hM : 0 < M) (hη0 : 0 < η) (hη1 : η < 1) (hΔ : 0 < Δ) :
    StrictAntiOn (fun g => M * (g + Δ) ^ η - M * g ^ η) (Ici 0) := by
  have hc : Continuous (fun x : ℝ => x ^ η) := Real.continuous_rpow_const hη0.le
  apply strictAntiOn_of_deriv_neg (convex_Ici 0)
  · exact ((continuous_const.mul (hc.comp (continuous_id.add continuous_const))).sub
      (continuous_const.mul hc)).continuousOn
  · intro g hg
    rw [interior_Ici] at hg
    have hg' : (0:ℝ) < g := hg
    have a1 : HasDerivAt (fun x => (x + Δ) ^ η) (η * (g + Δ) ^ (η - 1)) g := by
      have := (hasDerivAt_rpow_const (p := η) (Or.inl (by linarith : g + Δ ≠ 0))).comp g
        ((hasDerivAt_id g).add_const Δ)
      exact this.congr_deriv (by simp)
    have a2 : HasDerivAt (fun x => x ^ η) (η * g ^ (η - 1)) g :=
      hasDerivAt_rpow_const (Or.inl hg'.ne')
    have hd : HasDerivAt (fun g => M * (g + Δ) ^ η - M * g ^ η)
        (M * (η * (g + Δ) ^ (η - 1)) - M * (η * g ^ (η - 1))) g :=
      (a1.const_mul M).sub (a2.const_mul M)
    rw [hd.deriv]
    have h1 : (g + Δ) ^ (η - 1) < g ^ (η - 1) :=
      Real.rpow_lt_rpow_of_neg hg' (by linarith) (by linarith)
    have h2 : 0 < M * η := mul_pos hM hη0
    nlinarith

/-- **P11(iv), the mechanism in time.** Along the path, as copying erodes the old lead
(`g₀, κ_pre > 0`), the gain `ρ(g(T) + Δ) − ρ(g(T))` strictly rises with `T`. -/
theorem p11iv_gain_grows_in_T (M η : ℝ) (p : Prm) (hM : 0 < M) (hη0 : 0 < η) (hη1 : η < 1)
    (hΔ : 0 < p.Δ) (hg : 0 < p.g0) (hk : 0 < p.kpre) :
    StrictMonoOn (fun T => M * (lead p T + p.Δ) ^ η - M * lead p T ^ η) (Ici 0) :=
  fun _ _ _ _ hab => p11iv_gain_grows M η p.Δ hM hη0 hη1 hΔ
    (Set.mem_Ici.mpr (lead_nonneg p hg.le _)) (Set.mem_Ici.mpr (lead_nonneg p hg.le _))
    (lead_lt p hg hk hab)

/-! ### Convex rents can also give an interior release (proof of P11(iii)) -/

/-- The example: `ρ = x²`, `r = λ = κ_pre = 1`, `κ_post = 3`, `Δ = 1`, `g₀ = 3`, `F = 1/7`,
`Z = 0`. -/
noncomputable def pSq : Prm :=
  { r := 1, lam := 1, F := 1/7, Z := 0, kpre := 1, kpost := 3, g0 := 3, Δ := 1 }

theorem Pi_sq (x : ℝ) : Pi (fun y => y ^ 2) 1 3 x = x ^ 2 / 7 := by
  unfold Pi
  rw [setIntegral_congr_fun measurableSet_Ioi
    (g := fun s => x ^ 2 * exp (-7 * s)) (fun s _ => by
      have : exp (-7 * s) = exp (-1 * s) * exp (-3 * s) ^ 2 := by
        rw [← exp_nat_mul, ← exp_add]; ring_nf
      simp only [this]; ring)]
  rw [MeasureTheory.integral_const_mul, integral_exp_neg_Ioi_pos (by norm_num : (0:ℝ) < 7)]
  ring

theorem pSq_J : J (fun y => y ^ 2) pSq = fun T => (lead pSq T + 1) ^ 2 / 7 := by
  funext T; simp only [J, pSq]; exact Pi_sq _

theorem pSq_J_hasDerivAt (T : ℝ) :
    HasDerivAt (J (fun y => y ^ 2) pSq) (2 * (lead pSq T + 1) * (-1 * lead pSq T) / 7) T := by
  rw [pSq_J]
  have h := (((lead_hasDerivAt pSq T).add_const 1).pow 2).div_const 7
  convert h using 1
  simp [pSq]

theorem pSq_Phi (T : ℝ) :
    Phi (fun y => y ^ 2) pSq T = (3 * lead pSq T ^ 2 - 6 * lead pSq T - 1) / 7 := by
  unfold Phi
  rw [(pSq_J_hasDerivAt T).deriv]
  simp only [pSq_J]
  simp only [pSq]
  ring

/-- **Convex rents: a strict global interior release.** In `pSq`, `Φ` crosses zero once,
downward, at the date where `g = 1 + 2/√3`; that date is the strict global optimum. -/
theorem p11iii_convex_interior :
    ∃ Ts, 0 < Ts ∧ lead pSq Ts = 1 + 2 * Real.sqrt 3 / 3 ∧
      (∀ T, 0 ≤ T → T ≠ Ts → V (fun y => y ^ 2) pSq T < V (fun y => y ^ 2) pSq Ts) ∧
      (∀ L, Tendsto (V (fun y => y ^ 2) pSq) atTop (𝓝 L) → L ≤ V (fun y => y ^ 2) pSq Ts) := by
  set s := Real.sqrt 3 with hs_def
  have hs2 : s ^ 2 = 3 := Real.sq_sqrt (by norm_num)
  have hs0 : 0 ≤ s := Real.sqrt_nonneg 3
  have hs1 : 3 / 2 < s := by nlinarith
  have hs3 : s < 3 := by nlinarith
  set gs := 1 + 2 * s / 3 with hgs
  have hgs0 : 0 < gs := by rw [hgs]; linarith
  have hgs3 : gs < 3 := by rw [hgs]; linarith
  set Ts := Real.log (3 / gs) with hTs_def
  have hTs : 0 < Ts := Real.log_pos (by rw [lt_div_iff₀ hgs0]; linarith)
  have hlead : lead pSq Ts = gs := by
    simp only [lead, pSq]
    rw [show -(1:ℝ) * Ts = -Ts by ring, hTs_def, exp_neg, exp_log (by positivity)]
    field_simp
  have hfac : ∀ g : ℝ, 3 * g ^ 2 - 6 * g - 1 = 3 * (g - gs) * (g - (1 - 2 * s / 3)) := by
    intro g; rw [hgs]; linear_combination (4/3 : ℝ) * hs2
  have hpk : (0:ℝ) < pSq.kpre := by norm_num [pSq]
  have hpg : (0:ℝ) < pSq.g0 := by norm_num [pSq]
  refine ⟨Ts, hTs, hlead, ?_⟩
  apply p11i_global (fun y => y ^ 2) pSq (Continuous.continuousOn (by fun_prop))
    hpg.le (by norm_num [pSq]) hpk.le (by norm_num [pSq]) (by norm_num [pSq])
    (fun T _ => (pSq_J_hasDerivAt T).differentiableAt) hTs
  · intro T _ hT
    rw [pSq_Phi, hfac]
    have h1 := lead_lt pSq hpg hpk hT
    rw [hlead] at h1
    have h2 : 0 < lead pSq T - (1 - 2 * s / 3) := by linarith
    have h3 : 0 < lead pSq T - gs := by linarith
    positivity
  · intro T hT
    rw [pSq_Phi, hfac]
    have h1 := lead_lt pSq hpg hpk hT
    rw [hlead] at h1
    have h0 : 0 < lead pSq T := mul_pos hpg (exp_pos _)
    have h2 : 0 < lead pSq T - (1 - 2 * s / 3) := by linarith
    have h3 : lead pSq T - gs < 0 := by linarith
    have : 3 * (lead pSq T - gs) * (lead pSq T - (1 - 2 * s / 3)) < 0 := by
      have := mul_neg_of_neg_of_pos h3 h2; nlinarith
    linarith [div_neg_of_neg_of_pos this (by norm_num : (0:ℝ) < 7)]

/-! ### P11(v): comparative statics at a simple crossing -/

/-- **The comparative-statics step.** If `T*(θ)` is a differentiable selection of zeros of
`Φ(·, θ)` through `T*(θ₀)`, `Φ` is differentiable at `(T*(θ₀), θ₀)`, and the crossing is simple
and from above (`∂Φ/∂T = a < 0`), then `dT*/dθ = −(∂Φ/∂θ)/a`: release comes later exactly when
`∂Φ/∂θ > 0`. -/
theorem comp_statics {Φ : ℝ → ℝ → ℝ} {Ts : ℝ → ℝ} {θ0 a b d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ => Φ q.1 q.2) (Ts θ0, θ0))
    (ha : HasDerivAt (fun T => Φ T θ0) a (Ts θ0))
    (hb : HasDerivAt (fun θ => Φ (Ts θ0) θ) b θ0)
    (hd : HasDerivAt Ts d θ0)
    (hzero : ∀ᶠ θ in 𝓝 θ0, Φ (Ts θ) θ = 0) (hneg : a < 0) :
    d = -b / a ∧ (0 < d ↔ 0 < b) ∧ (d < 0 ↔ b < 0) := by
  have hL := hΦ.hasFDerivAt
  set L := fderiv ℝ (fun q : ℝ × ℝ => Φ q.1 q.2) (Ts θ0, θ0)
  have h1 : HasDerivAt (fun T => Φ T θ0) (L ((1:ℝ), (0:ℝ))) (Ts θ0) :=
    hL.comp_hasDerivAt (Ts θ0) (f := fun T : ℝ => (T, θ0))
      ((hasDerivAt_id _).prodMk (hasDerivAt_const _ _))
  have h2 : HasDerivAt (fun θ => Φ (Ts θ0) θ) (L ((0:ℝ), (1:ℝ))) θ0 :=
    hL.comp_hasDerivAt θ0 (f := fun θ : ℝ => (Ts θ0, θ))
      ((hasDerivAt_const _ _).prodMk (hasDerivAt_id _))
  have h3 : HasDerivAt (fun θ => Φ (Ts θ) θ) (L (d, (1:ℝ))) θ0 :=
    hL.comp_hasDerivAt θ0 (f := fun θ : ℝ => (Ts θ, θ)) (hd.prodMk (hasDerivAt_id _))
  have ea : L ((1:ℝ), (0:ℝ)) = a := h1.unique ha
  have eb : L ((0:ℝ), (1:ℝ)) = b := h2.unique hb
  have e0 : L (d, (1:ℝ)) = 0 :=
    h3.unique ((hasDerivAt_const θ0 (0:ℝ)).congr_of_eventuallyEq hzero)
  have hlin : L (d, (1:ℝ)) = d * L ((1:ℝ), (0:ℝ)) + L ((0:ℝ), (1:ℝ)) := by
    have : ((d, (1:ℝ)) : ℝ × ℝ) = d • ((1:ℝ), (0:ℝ)) + ((0:ℝ), (1:ℝ)) := by simp
    rw [this, map_add, map_smul, smul_eq_mul]
  rw [ea, eb, e0] at hlin
  have hdv : d = -b / a := by rw [eq_div_iff hneg.ne]; linarith
  have hb' : b = d * (-a) := by linarith
  have hna : 0 < -a := by linarith
  refine ⟨hdv, ⟨fun h => ?_, fun h => ?_⟩, ⟨fun h => ?_, fun h => ?_⟩⟩
  · rw [hb']; positivity
  · by_contra h'; push Not at h'; nlinarith
  · rw [hb']; nlinarith
  · by_contra h'; push Not at h'; nlinarith

/-! Partial derivatives of the defined `Φ` in each primitive, at a fixed date `T`. -/

/-- **(v) internal use.** `∂Φ/∂f_u = 1`: adding `u` to the held flow `F` (with no hazard)
adds `u` to `Φ` at every date. -/
theorem p11v_fu_partial (ρ : ℝ → ℝ) (p : Prm) (T : ℝ) :
    HasDerivAt (fun u => Phi ρ { p with F := p.F + u } T) 1 0 := by
  have : (fun u => Phi ρ { p with F := p.F + u } T) = fun u => Phi ρ p T + u := by
    funext u
    change (p.F + u) + p.lam * p.Z + ρ (lead p T) - (p.r + p.lam) * J ρ p T +
      deriv (J ρ p) T = Phi ρ p T + u
    unfold Phi; ring
  rw [this]
  simpa using (hasDerivAt_id (0:ℝ)).const_add (Phi ρ p T)

/-- **(v) the loss hazard.** `∂Φ/∂λ = Z − J(T)`. -/
theorem p11v_lam_partial (ρ : ℝ → ℝ) (p : Prm) (T : ℝ) :
    HasDerivAt (fun l => Phi ρ { p with lam := l } T) (p.Z - J ρ p T) p.lam := by
  have : (fun l => Phi ρ { p with lam := l } T) = fun l =>
      (p.F + ρ (lead p T) - p.r * J ρ p T + deriv (J ρ p) T) + l * (p.Z - J ρ p T) := by
    funext l
    change p.F + l * p.Z + ρ (lead p T) - (p.r + l) * J ρ p T + deriv (J ρ p) T = _
    ring
  rw [this]
  simpa using ((hasDerivAt_id p.lam).mul_const (p.Z - J ρ p T)).const_add
    (p.F + ρ (lead p T) - p.r * J ρ p T + deriv (J ρ p) T)

/-- **(v) artifact sales.** A unit of artifact flow `x` adds `x` to `F` and `Λ(x)` to the
hazard (`Λ(0) = 0`, `Λ′(0) = λ′`): `∂Φ/∂f_a = 1 − λ′(J(T) − Z)`. -/
theorem p11v_fa_partial (ρ : ℝ → ℝ) (p : Prm) (Λ : ℝ → ℝ) {Λ' : ℝ}
    (hΛ : HasDerivAt Λ Λ' 0) (T : ℝ) :
    HasDerivAt (fun x => Phi ρ { p with F := p.F + x, lam := p.lam + Λ x } T)
      (1 - Λ' * (J ρ p T - p.Z)) 0 := by
  have : (fun x => Phi ρ { p with F := p.F + x, lam := p.lam + Λ x } T) = fun x =>
      Phi ρ p T + x + Λ x * (p.Z - J ρ p T) := by
    funext x
    change (p.F + x) + (p.lam + Λ x) * p.Z + ρ (lead p T) - (p.r + (p.lam + Λ x)) * J ρ p T +
      deriv (J ρ p) T = _
    unfold Phi; ring
  rw [this]
  have h := (((hasDerivAt_id (0:ℝ)).const_add (Phi ρ p T)).add
    (hΛ.mul_const (p.Z - J ρ p T)))
  convert h using 1
  · funext x; simp
  · ring

/-- **(v) internal use: release comes later**, at any simple downward crossing. -/
theorem p11v_fu_later (ρ : ℝ → ℝ) (p : Prm) {Ts : ℝ → ℝ} {a d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ => Phi ρ { p with F := p.F + q.2 } q.1) (Ts 0, 0))
    (ha : HasDerivAt (fun T => Phi ρ { p with F := p.F + 0 } T) a (Ts 0))
    (hd : HasDerivAt Ts d 0) (hzero : ∀ᶠ u in 𝓝 0, Phi ρ { p with F := p.F + u } (Ts u) = 0)
    (hneg : a < 0) : 0 < d :=
  ((comp_statics (Φ := fun T u => Phi ρ { p with F := p.F + u } T) hΦ ha
    (p11v_fu_partial ρ p (Ts 0)) hd hzero hneg).2.1).mpr one_pos

/-- **(v) artifact sales: release comes later iff `λ′(J(T*) − Z) < 1`**, at any simple
downward crossing. -/
theorem p11v_fa_later_iff (ρ : ℝ → ℝ) (p : Prm) (Λ : ℝ → ℝ) {Λ' : ℝ}
    (hΛ : HasDerivAt Λ Λ' 0) {Ts : ℝ → ℝ} {a d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ =>
      Phi ρ { p with F := p.F + q.2, lam := p.lam + Λ q.2 } q.1) (Ts 0, 0))
    (ha : HasDerivAt (fun T => Phi ρ { p with F := p.F + 0, lam := p.lam + Λ 0 } T) a (Ts 0))
    (hd : HasDerivAt Ts d 0)
    (hzero : ∀ᶠ x in 𝓝 0, Phi ρ { p with F := p.F + x, lam := p.lam + Λ x } (Ts x) = 0)
    (hneg : a < 0) : 0 < d ↔ Λ' * (J ρ p (Ts 0) - p.Z) < 1 := by
  rw [(comp_statics (Φ := fun T x => Phi ρ { p with F := p.F + x, lam := p.lam + Λ x } T)
    hΦ ha (p11v_fa_partial ρ p Λ hΛ (Ts 0)) hd hzero hneg).2.1]
  constructor <;> intro h <;> linarith

/-- **(v) the loss hazard: release comes sooner iff `J(T*) > Z`**, at any simple downward
crossing. -/
theorem p11v_lam_sooner_iff (ρ : ℝ → ℝ) (p : Prm) {Ts : ℝ → ℝ} {a d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ => Phi ρ { p with lam := q.2 } q.1)
      (Ts p.lam, p.lam))
    (ha : HasDerivAt (fun T => Phi ρ { p with lam := p.lam } T) a (Ts p.lam))
    (hd : HasDerivAt Ts d p.lam)
    (hzero : ∀ᶠ l in 𝓝 p.lam, Phi ρ { p with lam := l } (Ts l) = 0) (hneg : a < 0) :
    d < 0 ↔ p.Z < J ρ p (Ts p.lam) := by
  rw [(comp_statics (Φ := fun T l => Phi ρ { p with lam := l } T) hΦ ha
    (p11v_lam_partial ρ p (Ts p.lam)) hd hzero hneg).2.2]
  constructor <;> intro h <;> linarith

/-- `Φ` written through the lead: `Φ(T) = A(g) − κ_pre·g·Π′(g + Δ)` with `g = g(T)`. -/
theorem Phi_AB (ρ : ℝ → ℝ) (q : Prm) (t : ℝ)
    (hPd : DifferentiableAt ℝ (Pi ρ q.r q.kpost) (lead q t + q.Δ)) :
    Phi ρ q t = q.F + q.lam * q.Z + ρ (lead q t) - (q.r + q.lam) * Pi ρ q.r q.kpost (lead q t + q.Δ)
      - q.kpre * (lead q t * deriv (Pi ρ q.r q.kpost) (lead q t + q.Δ)) := by
  have hJ : HasDerivAt (J ρ q) (deriv (Pi ρ q.r q.kpost) (lead q t + q.Δ) * (-q.kpre * lead q t)) t :=
    hPd.hasDerivAt.comp t ((lead_hasDerivAt q t).add_const q.Δ)
  unfold Phi
  rw [hJ.deriv]
  simp only [J]
  ring

/-- **(v) copying before release.** With `Π` differentiable on `(0, ∞)` and `A`, `B` the
lead-functions of `Phi_AB` differentiable at `g(T)`, the date- and `κ_pre`-derivatives of `Φ`
satisfy `∂Φ/∂κ_pre = (T/κ_pre)·∂Φ/∂T − g·Π′(g + Δ)`. -/
theorem p11v_kpre_partial (ρ : ℝ → ℝ) (p : Prm) {T A' B' : ℝ} (hg : 0 ≤ p.g0) (hΔ : 0 < p.Δ)
    (hPd : ∀ x, 0 < x → DifferentiableAt ℝ (Pi ρ p.r p.kpost) x)
    (hA : HasDerivAt (fun g => p.F + p.lam * p.Z + ρ g - (p.r + p.lam) *
      Pi ρ p.r p.kpost (g + p.Δ)) A' (lead p T))
    (hB : HasDerivAt (fun g => g * deriv (Pi ρ p.r p.kpost) (g + p.Δ)) B' (lead p T)) :
    HasDerivAt (fun t => Phi ρ p t) ((A' - p.kpre * B') * (-p.kpre * lead p T)) T ∧
      HasDerivAt (fun k => Phi ρ { p with kpre := k } T)
        ((A' - p.kpre * B') * (-T * lead p T) -
          lead p T * deriv (Pi ρ p.r p.kpost) (lead p T + p.Δ)) p.kpre := by
  set A := fun g => p.F + p.lam * p.Z + ρ g - (p.r + p.lam) * Pi ρ p.r p.kpost (g + p.Δ)
  set B := fun g => g * deriv (Pi ρ p.r p.kpost) (g + p.Δ)
  have hpos : ∀ q : Prm, q.g0 = p.g0 → q.Δ = p.Δ → ∀ t, 0 < lead q t + q.Δ := by
    intro q h1 h2 t
    have := mul_nonneg (h1 ▸ hg) (exp_pos (-q.kpre * t)).le
    simp only [lead]; rw [h2]; linarith
  constructor
  · have hfun : (fun t => Phi ρ p t) = fun t => A (lead p t) - p.kpre * B (lead p t) := by
      funext t; rw [Phi_AB ρ p t (hPd _ (hpos p rfl rfl t))]
    rw [hfun]
    have h := (hA.comp T (lead_hasDerivAt p T)).sub ((hB.comp T (lead_hasDerivAt p T)).const_mul p.kpre)
    have h' : HasDerivAt (fun t => A (lead p t) - p.kpre * B (lead p t))
        (A' * (-p.kpre * lead p T) - p.kpre * (B' * (-p.kpre * lead p T))) T := h
    exact h'.congr_deriv (by ring)
  · have hfun : (fun k => Phi ρ { p with kpre := k } T) =
        fun k => A (p.g0 * exp (-k * T)) - k * B (p.g0 * exp (-k * T)) := by
      funext k
      rw [Phi_AB ρ { p with kpre := k } T (hPd _ (hpos { p with kpre := k } rfl rfl T))]
      rfl
    rw [hfun]
    have hl : HasDerivAt (fun k => p.g0 * exp (-k * T)) (p.g0 * (exp (-p.kpre * T) * (-1 * T)))
        p.kpre := (((hasDerivAt_id p.kpre).neg.mul_const T).exp).const_mul p.g0
    have hA' : HasDerivAt A A' (p.g0 * exp (-p.kpre * T)) := hA
    have hB' : HasDerivAt B B' (p.g0 * exp (-p.kpre * T)) := hB
    have h := (hA'.comp p.kpre hl).sub ((hasDerivAt_id p.kpre).mul (hB'.comp p.kpre hl))
    have h' : HasDerivAt (fun k => A (p.g0 * exp (-k * T)) - k * B (p.g0 * exp (-k * T)))
        (A' * (p.g0 * (exp (-p.kpre * T) * (-1 * T))) -
          (1 * B (p.g0 * exp (-p.kpre * T)) +
            p.kpre * (B' * (p.g0 * (exp (-p.kpre * T) * (-1 * T)))))) p.kpre := h
    exact h'.congr_deriv (by simp only [lead, B]; ring)

/-- **(v) copying before release: release comes sooner.** At a simple downward crossing with
`Π′(g* + Δ) ≥ 0`, `∂Φ/∂κ_pre < 0`. -/
theorem p11v_kpre_sooner {a b T g P' κ : ℝ} (hT : 0 < T) (hκ : 0 < κ) (hg : 0 < g)
    (hP' : 0 ≤ P') (ha : a < 0) (hb : b = (T / κ) * a - g * P') : b < 0 := by
  have : (T / κ) * a < 0 := mul_neg_of_pos_of_neg (div_pos hT hκ) ha
  nlinarith [mul_nonneg hg.le hP']

theorem p11v_kpre_identity {A' B' κ T g P' : ℝ} (hκ : κ ≠ 0) :
    (A' - κ * B') * (-T * g) - g * P' = (T / κ) * ((A' - κ * B') * (-κ * g)) - g * P' := by
  field_simp

/-- **(v) copying before release, for the model: release comes earlier.** At a simple
downward crossing `T* > 0` (`∂Φ/∂T < 0`) of the defined `Φ`, with `Π′(g* + Δ) ≥ 0`, a
differentiable crossing selection `T*(κ_pre)` has `dT*/dκ_pre < 0`. -/
theorem p11v_kpre_earlier (ρ : ℝ → ℝ) (p : Prm) {Ts : ℝ → ℝ} {d A' B' : ℝ}
    (hk : 0 < p.kpre) (hg : 0 < p.g0) (hΔ : 0 < p.Δ)
    (hPd : ∀ x, 0 < x → DifferentiableAt ℝ (Pi ρ p.r p.kpost) x) (hTs : 0 < Ts p.kpre)
    (hA : HasDerivAt (fun g => p.F + p.lam * p.Z + ρ g - (p.r + p.lam) *
      Pi ρ p.r p.kpost (g + p.Δ)) A' (lead p (Ts p.kpre)))
    (hB : HasDerivAt (fun g => g * deriv (Pi ρ p.r p.kpost) (g + p.Δ)) B' (lead p (Ts p.kpre)))
    (hP' : 0 ≤ deriv (Pi ρ p.r p.kpost) (lead p (Ts p.kpre) + p.Δ))
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ => Phi ρ { p with kpre := q.2 } q.1)
      (Ts p.kpre, p.kpre))
    (hd : HasDerivAt Ts d p.kpre)
    (hzero : ∀ᶠ k in 𝓝 p.kpre, Phi ρ { p with kpre := k } (Ts k) = 0)
    (hneg : (A' - p.kpre * B') * (-p.kpre * lead p (Ts p.kpre)) < 0) : d < 0 := by
  have hpart := p11v_kpre_partial ρ p hg.le hΔ hPd hA hB
  have hb : (A' - p.kpre * B') * (-Ts p.kpre * lead p (Ts p.kpre)) -
      lead p (Ts p.kpre) * deriv (Pi ρ p.r p.kpost) (lead p (Ts p.kpre) + p.Δ) < 0 := by
    rw [p11v_kpre_identity hk.ne']
    exact p11v_kpre_sooner hTs hk (mul_pos hg (exp_pos _)) hP' hneg rfl
  exact ((comp_statics (Φ := fun T k => Phi ρ { p with kpre := k } T) hΦ hpart.1 hpart.2 hd
    hzero hneg).2.2).mpr hb

/-! Power rents: the explicit stopping function and its parameter derivatives. -/

theorem rpow_mul_pred {x η : ℝ} (hx : 0 < x) : x * x ^ (η - 1) = x ^ η := by
  have := rpow_add hx 1 (η - 1)
  rw [rpow_one] at this
  rw [← this]; congr 1; ring

theorem J_power_hasDerivAt (M η : ℝ) (p : Prm) (hc : 0 < p.r + η * p.kpost) {T : ℝ}
    (hx : 0 < lead p T + p.Δ) :
    HasDerivAt (J (fun y => M * y ^ η) p)
      (M * η * (lead p T + p.Δ) ^ (η - 1) / (p.r + η * p.kpost) * (-p.kpre * lead p T)) T :=
  (p11ii_ode_power M η hc hx).1.comp T ((lead_hasDerivAt p T).add_const p.Δ)

/-- `Φ` for power rents, from the defined `Φ`. -/
theorem Phi_power (M η : ℝ) (p : Prm) (hc : 0 < p.r + η * p.kpost) {T : ℝ}
    (hx : 0 < lead p T + p.Δ) :
    Phi (fun y => M * y ^ η) p T = p.F + p.lam * p.Z + M * lead p T ^ η
      - (p.r + p.lam) * (M * (lead p T + p.Δ) ^ η / (p.r + η * p.kpost))
      - p.kpre * lead p T * (M * η * (lead p T + p.Δ) ^ (η - 1) / (p.r + η * p.kpost)) := by
  unfold Phi
  rw [(J_power_hasDerivAt M η p hc hx).deriv]
  simp only [J, Pi_power M η hc hx.le]
  ring

/-- **(v) copying after release, power rents (any `η`), `λ` fixed.**
`∂Φ/∂κ_post = Mηx^{η−1}[(r+λ)x + κ_pre η g]/(r+ηκ_post)²` with `x = g + Δ`. -/
theorem p11v_kpost_partial_power (M η : ℝ) (p : Prm) (hc : 0 < p.r + η * p.kpost) {T : ℝ}
    (hx : 0 < lead p T + p.Δ) :
    HasDerivAt (fun k => Phi (fun y => M * y ^ η) { p with kpost := k } T)
      (M * η * (lead p T + p.Δ) ^ (η - 1) *
        ((p.r + p.lam) * (lead p T + p.Δ) + p.kpre * η * lead p T) /
          (p.r + η * p.kpost) ^ 2) p.kpost := by
  set g := lead p T
  set x := lead p T + p.Δ
  have hev : (fun k => Phi (fun y => M * y ^ η) { p with kpost := k } T) =ᶠ[𝓝 p.kpost]
      fun k => p.F + p.lam * p.Z + M * g ^ η -
        ((p.r + p.lam) * (M * x ^ η) + p.kpre * g * (M * η * x ^ (η - 1))) / (p.r + η * k) := by
    have hopen : {k : ℝ | 0 < p.r + η * k} ∈ 𝓝 p.kpost :=
      (isOpen_lt continuous_const (by fun_prop)).mem_nhds hc
    filter_upwards [hopen] with k hk
    rw [Phi_power M η { p with kpost := k } hk hx]
    simp only [g, x, lead]; field_simp; ring
  have hden : HasDerivAt (fun k => p.r + η * k) η p.kpost := by
    simpa using ((hasDerivAt_id p.kpost).const_mul η).const_add p.r
  have h := (hasDerivAt_const p.kpost
      ((p.r + p.lam) * (M * x ^ η) + p.kpre * g * (M * η * x ^ (η - 1)))).div hden hc.ne'
  have h2 := (h.const_sub (p.F + p.lam * p.Z + M * g ^ η)).congr_of_eventuallyEq hev
  convert h2 using 1
  rw [rpow_sub_one hx.ne']
  generalize x ^ η = z
  field_simp
  ring

theorem p11v_kpost_partial_power_pos (M η : ℝ) (p : Prm) {T : ℝ} (hM : 0 < M) (hη : 0 < η)
    (hx : 0 < lead p T + p.Δ) (hrl : 0 < p.r + p.lam) (hk : 0 ≤ p.kpre) (hg : 0 ≤ lead p T)
    (hc : 0 < p.r + η * p.kpost) :
    0 < M * η * (lead p T + p.Δ) ^ (η - 1) *
        ((p.r + p.lam) * (lead p T + p.Δ) + p.kpre * η * lead p T) /
          (p.r + η * p.kpost) ^ 2 := by
  have h1 : 0 < (lead p T + p.Δ) ^ (η - 1) := rpow_pos_of_pos hx _
  have h2 : 0 ≤ p.kpre * η * lead p T := by positivity
  have h3 : 0 < (p.r + p.lam) * (lead p T + p.Δ) := mul_pos hrl hx
  positivity

/-- **(v) copying after release, power rents: release comes later** at any simple downward
crossing (`λ` fixed). -/
theorem p11v_kpost_later_power (M η : ℝ) (p : Prm) {Ts : ℝ → ℝ} {a d : ℝ} (hM : 0 < M)
    (hη : 0 < η) (hrl : 0 < p.r + p.lam) (hk : 0 ≤ p.kpre) (hg : 0 ≤ p.g0) (hΔ : 0 < p.Δ)
    (hc : 0 < p.r + η * p.kpost)
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ =>
      Phi (fun y => M * y ^ η) { p with kpost := q.2 } q.1) (Ts p.kpost, p.kpost))
    (ha : HasDerivAt (fun T => Phi (fun y => M * y ^ η) { p with kpost := p.kpost } T) a
      (Ts p.kpost))
    (hd : HasDerivAt Ts d p.kpost)
    (hzero : ∀ᶠ k in 𝓝 p.kpost, Phi (fun y => M * y ^ η) { p with kpost := k } (Ts k) = 0)
    (hneg : a < 0) : 0 < d := by
  have hx : 0 < lead p (Ts p.kpost) + p.Δ := by
    have := lead_nonneg p hg (Ts p.kpost); linarith
  exact ((comp_statics (Φ := fun T k => Phi (fun y => M * y ^ η) { p with kpost := k } T)
    hΦ ha (p11v_kpost_partial_power M η p hc hx) hd hzero hneg).2.1).mpr
    (p11v_kpost_partial_power_pos M η p hM hη hx hrl hk (lead_nonneg p hg _) hc)

/-- **(v) the discount rate, power rents.**
`∂Φ/∂r = Mx^{η−1}[κ_pre η g − (ηκ_post − λ)x]/(r+ηκ_post)²`. -/
theorem p11v_r_partial_power (M η : ℝ) (p : Prm) (hc : 0 < p.r + η * p.kpost) {T : ℝ}
    (hx : 0 < lead p T + p.Δ) :
    HasDerivAt (fun r => Phi (fun y => M * y ^ η) { p with r := r } T)
      (M * (lead p T + p.Δ) ^ (η - 1) *
        (p.kpre * η * lead p T - (η * p.kpost - p.lam) * (lead p T + p.Δ)) /
          (p.r + η * p.kpost) ^ 2) p.r := by
  set g := lead p T
  set x := lead p T + p.Δ
  have hev : (fun r => Phi (fun y => M * y ^ η) { p with r := r } T) =ᶠ[𝓝 p.r]
      fun r => p.F + p.lam * p.Z + M * g ^ η -
        ((r + p.lam) * (M * x ^ η) + p.kpre * g * (M * η * x ^ (η - 1))) / (r + η * p.kpost) := by
    have hopen : {r : ℝ | 0 < r + η * p.kpost} ∈ 𝓝 p.r :=
      (isOpen_lt continuous_const (by fun_prop)).mem_nhds hc
    filter_upwards [hopen] with r hr
    rw [Phi_power M η { p with r := r } hr hx]
    simp only [g, x, lead]; field_simp; ring
  have hnum : HasDerivAt (fun r => (r + p.lam) * (M * x ^ η) + p.kpre * g * (M * η * x ^ (η - 1)))
      (M * x ^ η) p.r := by
    simpa using (((hasDerivAt_id p.r).add_const p.lam).mul_const (M * x ^ η)).add_const
      (p.kpre * g * (M * η * x ^ (η - 1)))
  have hden : HasDerivAt (fun r => r + η * p.kpost) 1 p.r := (hasDerivAt_id p.r).add_const _
  have h := hnum.div hden hc.ne'
  have h2 := (h.const_sub (p.F + p.lam * p.Z + M * g ^ η)).congr_of_eventuallyEq hev
  convert h2 using 1
  rw [rpow_sub_one hx.ne']
  generalize x ^ η = z
  field_simp
  ring

/-- **(v) the discount rate, linear rents.**
`∂Φ/∂r = −M[Δ(κ_post − λ) + g(κ_post − κ_pre − λ)]/(r+κ_post)²`. -/
theorem p11v_r_partial_linear (M : ℝ) (p : Prm) (h : 0 < p.r + p.kpost) (T : ℝ) :
    HasDerivAt (fun r => Phi (fun y => M * y) { p with r := r } T)
      (-(M * (p.Δ * (p.kpost - p.lam) + lead p T * (p.kpost - p.kpre - p.lam))) /
        (p.r + p.kpost) ^ 2) p.r := by
  set g := lead p T
  have hev : (fun r => Phi (fun y => M * y) { p with r := r } T) =ᶠ[𝓝 p.r]
      fun r => p.F + p.lam * p.Z -
        ((r + p.lam) * M * p.Δ - M * g * (p.kpost - p.kpre - p.lam)) / (r + p.kpost) := by
    have hopen : {r : ℝ | 0 < r + p.kpost} ∈ 𝓝 p.r :=
      (isOpen_lt continuous_const (by fun_prop)).mem_nhds h
    filter_upwards [hopen] with r hr
    rw [p11iii_Phi M { p with r := r } hr T]
    simp only [g, lead]; field_simp; ring
  have hnum : HasDerivAt (fun r => (r + p.lam) * M * p.Δ - M * g * (p.kpost - p.kpre - p.lam))
      (M * p.Δ) p.r := by
    have := ((((hasDerivAt_id p.r).add_const p.lam).mul_const M).mul_const p.Δ).sub_const
      (M * g * (p.kpost - p.kpre - p.lam))
    exact this.congr_deriv (by ring)
  have hden : HasDerivAt (fun r => r + p.kpost) 1 p.r := (hasDerivAt_id p.r).add_const _
  have h1 := hnum.div hden h.ne'
  have h2 := (h1.const_sub (p.F + p.lam * p.Z)).congr_of_eventuallyEq hev
  convert h2 using 1
  field_simp
  ring

/-- **(v) the discount rate, linear rents: release comes sooner at any simple downward
crossing.** The crossing's slope `∂Φ/∂T < 0` forces `κ_post > κ_pre + λ`, and then
`∂Φ/∂r < 0`. -/
theorem p11v_r_linear_negative (M : ℝ) (p : Prm) (hM : 0 < M) (hg : 0 < p.g0) (hk : 0 < p.kpre)
    (hΔ : 0 ≤ p.Δ) (h : 0 < p.r + p.kpost) {T a : ℝ}
    (ha : HasDerivAt (fun t => Phi (fun y => M * y) p t) a T) (hneg : a < 0) :
    p.kpre + p.lam < p.kpost ∧
      -(M * (p.Δ * (p.kpost - p.lam) + lead p T * (p.kpost - p.kpre - p.lam))) /
        (p.r + p.kpost) ^ 2 < 0 := by
  have hfun : (fun t => Phi (fun y => M * y) p t) = fun t =>
      p.F + p.lam * p.Z - (p.r + p.lam) * M * p.Δ / (p.r + p.kpost)
        + M * lead p t * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost) := by
    funext t; exact p11iii_Phi M p h t
  have hT : HasDerivAt (fun t => Phi (fun y => M * y) p t)
      (M * (-p.kpre * lead p T) * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost)) T := by
    rw [hfun]
    have := ((((lead_hasDerivAt p T).const_mul M).mul_const (p.kpost - p.kpre - p.lam)).div_const
      (p.r + p.kpost)).const_add (p.F + p.lam * p.Z - (p.r + p.lam) * M * p.Δ / (p.r + p.kpost))
    convert this using 1
  have hae := ha.unique hT
  have hl : 0 < lead p T := mul_pos hg (exp_pos _)
  have hc : p.kpre + p.lam < p.kpost := by
    by_contra hcon; push Not at hcon
    have : 0 ≤ M * (-p.kpre * lead p T) * (p.kpost - p.kpre - p.lam) / (p.r + p.kpost) := by
      apply div_nonneg _ h.le
      apply mul_nonneg_of_nonpos_of_nonpos _ (by linarith)
      have : 0 < p.kpre * lead p T := mul_pos hk hl
      nlinarith
    linarith
  refine ⟨hc, ?_⟩
  apply div_neg_of_neg_of_pos _ (by positivity)
  have h1 : 0 ≤ p.Δ * (p.kpost - p.lam) := mul_nonneg hΔ (by linarith)
  have h2 : 0 < lead p T * (p.kpost - p.kpre - p.lam) := mul_pos hl (by linarith)
  have : 0 < M * (p.Δ * (p.kpost - p.lam) + lead p T * (p.kpost - p.kpre - p.lam)) :=
    mul_pos hM (by linarith)
  linarith

/-- **(v) the discount rate, linear rents: `dT*/dr < 0`** for a differentiable crossing
selection at any simple downward crossing (IFT hypotheses as in `comp_statics`). -/
theorem p11v_r_linear_sooner (M : ℝ) (p : Prm) (hM : 0 < M) (hg : 0 < p.g0) (hk : 0 < p.kpre)
    (hΔ : 0 ≤ p.Δ) (h : 0 < p.r + p.kpost) {Ts : ℝ → ℝ} {a d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ => Phi (fun y => M * y) { p with r := q.2 } q.1)
      (Ts p.r, p.r))
    (ha : HasDerivAt (fun T => Phi (fun y => M * y) { p with r := p.r } T) a (Ts p.r))
    (hd : HasDerivAt Ts d p.r)
    (hzero : ∀ᶠ r in 𝓝 p.r, Phi (fun y => M * y) { p with r := r } (Ts r) = 0)
    (hneg : a < 0) : d < 0 :=
  ((comp_statics (Φ := fun T r => Phi (fun y => M * y) { p with r := r } T) hΦ ha
    (p11v_r_partial_linear M p h (Ts p.r)) hd hzero hneg).2.2).mpr
    (p11v_r_linear_negative M p hM hg hk hΔ h ha hneg).2

/-! ### A.7: a loss hazard rising with post-release copying -/

/-- **A.7, first extension (power rents).** With `λ = Λ(κ_post)` rising in the post-release
copy rate, `∂Φ/∂κ_post = A_κ + Λ′(Z − J(T))`, where `A_κ` is the fixed-`λ` derivative of
`p11v_kpost_partial_power`. -/
theorem a7_kpost_hazard_partial (M η : ℝ) (p : Prm) (Λ : ℝ → ℝ) {Λ' : ℝ}
    (hΛ : HasDerivAt Λ Λ' p.kpost) (hΛ0 : Λ p.kpost = p.lam) (hc : 0 < p.r + η * p.kpost)
    {T : ℝ} (hx : 0 < lead p T + p.Δ) :
    HasDerivAt (fun k => Phi (fun y => M * y ^ η) { p with kpost := k, lam := Λ k } T)
      (M * η * (lead p T + p.Δ) ^ (η - 1) *
          ((p.r + p.lam) * (lead p T + p.Δ) + p.kpre * η * lead p T) / (p.r + η * p.kpost) ^ 2
        + Λ' * (p.Z - J (fun y => M * y ^ η) p T)) p.kpost := by
  set g := lead p T
  set x := lead p T + p.Δ
  have hev : (fun k => Phi (fun y => M * y ^ η) { p with kpost := k, lam := Λ k } T)
      =ᶠ[𝓝 p.kpost] fun k => p.F + Λ k * p.Z + M * g ^ η -
        ((p.r + Λ k) * (M * x ^ η) + p.kpre * g * (M * η * x ^ (η - 1))) / (p.r + η * k) := by
    have hopen : {k : ℝ | 0 < p.r + η * k} ∈ 𝓝 p.kpost :=
      (isOpen_lt continuous_const (by fun_prop)).mem_nhds hc
    filter_upwards [hopen] with k hk
    rw [Phi_power M η { p with kpost := k, lam := Λ k } hk hx]
    simp only [g, x, lead]; field_simp; ring
  have hnum : HasDerivAt (fun k => (p.r + Λ k) * (M * x ^ η) + p.kpre * g * (M * η * x ^ (η - 1)))
      (Λ' * (M * x ^ η)) p.kpost := by
    simpa using ((hΛ.const_add p.r).mul_const (M * x ^ η)).add_const
      (p.kpre * g * (M * η * x ^ (η - 1)))
  have hden : HasDerivAt (fun k => p.r + η * k) η p.kpost := by
    simpa using ((hasDerivAt_id p.kpost).const_mul η).const_add p.r
  have h1 := hnum.div hden hc.ne'
  have h0 := ((hΛ.mul_const p.Z).const_add (p.F)).add_const (M * g ^ η)
  have hG : HasDerivAt (fun k => p.F + Λ k * p.Z + M * g ^ η -
      ((p.r + Λ k) * (M * x ^ η) + p.kpre * g * (M * η * x ^ (η - 1))) / (p.r + η * k))
      (Λ' * p.Z - (Λ' * (M * x ^ η) * (p.r + η * p.kpost) -
        ((p.r + Λ p.kpost) * (M * x ^ η) + p.kpre * g * (M * η * x ^ (η - 1))) * η) /
          (p.r + η * p.kpost) ^ 2) p.kpost := h0.sub h1
  have h2 := hG.congr_of_eventuallyEq hev
  have hJ : J (fun y => M * y ^ η) p T = M * x ^ η / (p.r + η * p.kpost) := by
    simp only [J, x]; exact Pi_power M η hc hx.le
  rw [hJ]
  refine h2.congr_deriv ?_
  rw [hΛ0, ← rpow_mul_pred hx]
  generalize x ^ (η - 1) = y
  field_simp
  ring

/-- **A.7, first extension: the condition.** With `Z = 0` and power rents, the total
`κ_post`-derivative is positive (release later, at a simple downward crossing) iff
`λ′ < η[(r+λ) + ηκ_pre g/(g + Δ)]/(r + ηκ_post)`. -/
theorem a7_kpost_hazard_condition (M η : ℝ) (p : Prm) {Λ' : ℝ} (hM : 0 < M)
    (hc : 0 < p.r + η * p.kpost) {T : ℝ} (hx : 0 < lead p T + p.Δ) (hZ : p.Z = 0) :
    0 < M * η * (lead p T + p.Δ) ^ (η - 1) *
          ((p.r + p.lam) * (lead p T + p.Δ) + p.kpre * η * lead p T) / (p.r + η * p.kpost) ^ 2
        + Λ' * (p.Z - J (fun y => M * y ^ η) p T) ↔
      Λ' < η * ((p.r + p.lam) + η * p.kpre * lead p T / (lead p T + p.Δ)) /
        (p.r + η * p.kpost) := by
  have hJ : J (fun y => M * y ^ η) p T = M * (lead p T + p.Δ) ^ η / (p.r + η * p.kpost) := by
    simp only [J]; exact Pi_power M η hc hx.le
  rw [hJ, hZ]
  set x := lead p T + p.Δ
  set g := lead p T
  set c := p.r + η * p.kpost
  have hxe : x ^ η = x * x ^ (η - 1) := (rpow_mul_pred hx).symm
  have hpx : 0 < x ^ (η - 1) := rpow_pos_of_pos hx _
  have key : M * η * x ^ (η - 1) * ((p.r + p.lam) * x + p.kpre * η * g) / c ^ 2 +
      Λ' * (0 - M * x ^ η / c) =
      (M * x * x ^ (η - 1) / c) *
        (η * ((p.r + p.lam) + η * p.kpre * g / x) / c - Λ') := by
    rw [hxe]; field_simp; ring
  rw [key]
  have hpos : 0 < M * x * x ^ (η - 1) / c := by positivity
  constructor
  · intro h; have := (pos_iff_pos_of_mul_pos h).mp hpos; linarith
  · intro h; exact mul_pos hpos (by linarith)

/-- **A.7, first extension (power rents): the date conclusion.** At a simple downward crossing,
with `λ = Λ(κ_post)`, release comes later iff `A_κ > λ′(J(T*) − Z)`. -/
theorem a7_kpost_later_iff (M η : ℝ) (p : Prm) (Λ : ℝ → ℝ) {Λ' : ℝ}
    (hΛ : HasDerivAt Λ Λ' p.kpost) (hΛ0 : Λ p.kpost = p.lam) (hc : 0 < p.r + η * p.kpost)
    (hg : 0 ≤ p.g0) (hΔ : 0 < p.Δ) {Ts : ℝ → ℝ} {a d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ =>
      Phi (fun y => M * y ^ η) { p with kpost := q.2, lam := Λ q.2 } q.1) (Ts p.kpost, p.kpost))
    (ha : HasDerivAt
      (fun T => Phi (fun y => M * y ^ η) { p with kpost := p.kpost, lam := Λ p.kpost } T) a
      (Ts p.kpost))
    (hd : HasDerivAt Ts d p.kpost)
    (hzero : ∀ᶠ k in 𝓝 p.kpost,
      Phi (fun y => M * y ^ η) { p with kpost := k, lam := Λ k } (Ts k) = 0)
    (hneg : a < 0) :
    0 < d ↔ Λ' * (J (fun y => M * y ^ η) p (Ts p.kpost) - p.Z) <
      M * η * (lead p (Ts p.kpost) + p.Δ) ^ (η - 1) *
        ((p.r + p.lam) * (lead p (Ts p.kpost) + p.Δ) + p.kpre * η * lead p (Ts p.kpost)) /
          (p.r + η * p.kpost) ^ 2 := by
  have hx : 0 < lead p (Ts p.kpost) + p.Δ := by
    have := lead_nonneg p hg (Ts p.kpost); linarith
  rw [(comp_statics (Φ := fun T k => Phi (fun y => M * y ^ η) { p with kpost := k, lam := Λ k } T)
    hΦ ha (a7_kpost_hazard_partial M η p Λ hΛ hΛ0 hc hx) hd hzero hneg).2.1]
  constructor <;> intro h <;> linarith

/-- **A.7, first extension, general rents.** For any rent, if `Φ` at fixed `λ` has
`κ_post`-derivative `A_κ` and `J` is differentiable in `κ_post`, then with `λ = Λ(κ_post)` the
`κ_post`-derivative of `Φ` is `A_κ + λ′(Z − J(T))`. -/
theorem a7_kpost_hazard_partial_general (ρ : ℝ → ℝ) (p : Prm) (Λ : ℝ → ℝ) {Λ' Aκ T : ℝ}
    (hΛ : HasDerivAt Λ Λ' p.kpost) (hΛ0 : Λ p.kpost = p.lam)
    (hA : HasDerivAt (fun k => Phi ρ { p with kpost := k } T) Aκ p.kpost)
    (hJk : DifferentiableAt ℝ (fun k => J ρ { p with kpost := k } T) p.kpost) :
    HasDerivAt (fun k => Phi ρ { p with kpost := k, lam := Λ k } T)
      (Aκ + Λ' * (p.Z - J ρ p T)) p.kpost := by
  have hfun : (fun k => Phi ρ { p with kpost := k, lam := Λ k } T) = fun k =>
      Phi ρ { p with kpost := k } T + (Λ k - p.lam) * (p.Z - J ρ { p with kpost := k } T) := by
    funext k
    change p.F + Λ k * p.Z + ρ (lead p T) - (p.r + Λ k) * J ρ { p with kpost := k } T +
        deriv (J ρ { p with kpost := k }) T =
      p.F + p.lam * p.Z + ρ (lead p T) - (p.r + p.lam) * J ρ { p with kpost := k } T +
        deriv (J ρ { p with kpost := k }) T +
        (Λ k - p.lam) * (p.Z - J ρ { p with kpost := k } T)
    ring
  rw [hfun]
  have h3 := hA.add ((hΛ.sub_const p.lam).mul (hJk.hasDerivAt.const_sub p.Z))
  convert h3 using 1
  rw [hΛ0, sub_self, zero_mul, add_zero]

/-- **A.7, first extension, general rents: the date conclusion.** At a simple downward
crossing, release still comes later iff `A_κ > λ′(J(T*) − Z)`. -/
theorem a7_kpost_later_iff_general (ρ : ℝ → ℝ) (p : Prm) (Λ : ℝ → ℝ) {Λ' Aκ : ℝ}
    (hΛ : HasDerivAt Λ Λ' p.kpost) (hΛ0 : Λ p.kpost = p.lam) {Ts : ℝ → ℝ} {a d : ℝ}
    (hA : HasDerivAt (fun k => Phi ρ { p with kpost := k } (Ts p.kpost)) Aκ p.kpost)
    (hJk : DifferentiableAt ℝ (fun k => J ρ { p with kpost := k } (Ts p.kpost)) p.kpost)
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ =>
      Phi ρ { p with kpost := q.2, lam := Λ q.2 } q.1) (Ts p.kpost, p.kpost))
    (ha : HasDerivAt (fun T => Phi ρ { p with kpost := p.kpost, lam := Λ p.kpost } T) a
      (Ts p.kpost))
    (hd : HasDerivAt Ts d p.kpost)
    (hzero : ∀ᶠ k in 𝓝 p.kpost, Phi ρ { p with kpost := k, lam := Λ k } (Ts k) = 0)
    (hneg : a < 0) : 0 < d ↔ Λ' * (J ρ p (Ts p.kpost) - p.Z) < Aκ := by
  rw [(comp_statics (Φ := fun T k => Phi ρ { p with kpost := k, lam := Λ k } T) hΦ ha
    (a7_kpost_hazard_partial_general ρ p Λ hΛ hΛ0 hA hJk) hd hzero hneg).2.1]
  constructor <;> intro h <;> linarith

/-! ### A.7: internal research whose value survives release -/

/-- Release value when a flow `Fp` survives both release and involuntary loss. -/
noncomputable def Vboth (ρ : ℝ → ℝ) (p : Prm) (Fp T : ℝ) : ℝ :=
  (∫ t in (0:ℝ)..T, exp (-(p.r + p.lam) * t) *
      (p.F + p.lam * (p.Z + Fp / p.r) + ρ (lead p t)))
    + exp (-(p.r + p.lam) * T) * (J ρ p T + Fp / p.r)

/-- Release value when a flow `Fp` survives release only. -/
noncomputable def Vrel (ρ : ℝ → ℝ) (p : Prm) (Fp T : ℝ) : ℝ :=
  (∫ t in (0:ℝ)..T, exp (-(p.r + p.lam) * t) * (p.F + p.lam * p.Z + ρ (lead p t)))
    + exp (-(p.r + p.lam) * T) * (J ρ p T + Fp / p.r)

/-- **A.7, research surviving both release and loss:** the problem is the base problem with
`F` replaced by `F − F_post`, plus the constant `F_post/r`. -/
theorem a7_Vboth_eq (ρ : ℝ → ℝ) (p : Prm) (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ)))
    (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ) (hk : 0 ≤ p.kpre) (hr : p.r ≠ 0) (ha : p.r + p.lam ≠ 0)
    (Fp : ℝ) {T : ℝ} (hT : 0 ≤ T) :
    Vboth ρ p Fp T = V ρ { p with F := p.F - Fp } T + Fp / p.r := by
  have hq : ContinuousOn (holdIntegrand ρ { p with F := p.F - Fp }) (Ici 0) :=
    holdIntegrand_continuousOn ρ { p with F := p.F - Fp } hρ hg hΔ hk
  have hi1 : IntervalIntegrable (holdIntegrand ρ { p with F := p.F - Fp }) volume 0 T :=
    (hq.mono (by rw [uIcc_of_le hT]; exact Icc_subset_Ici_self)).intervalIntegrable
  have hi2 : IntervalIntegrable (fun t => (p.r + p.lam) * Fp / p.r * exp (-(p.r + p.lam) * t))
      volume 0 T := by
    apply Continuous.intervalIntegrable; fun_prop
  have hfun : (fun t => exp (-(p.r + p.lam) * t) *
      (p.F + p.lam * (p.Z + Fp / p.r) + ρ (lead p t))) = fun t =>
        holdIntegrand ρ { p with F := p.F - Fp } t +
          (p.r + p.lam) * Fp / p.r * exp (-(p.r + p.lam) * t) := by
    funext t; simp only [holdIntegrand, lead]; field_simp; ring
  unfold Vboth V
  rw [hfun, intervalIntegral.integral_add hi1 hi2, intervalIntegral.integral_const_mul,
    integral_exp_neg_mul ha]
  simp only [J, lead]
  field_simp
  ring

/-- **A.7, research surviving release only:** the problem is the base problem with `F`
replaced by `F − (r+λ)F_post/r`, plus the constant `F_post/r`. -/
theorem a7_Vrel_eq (ρ : ℝ → ℝ) (p : Prm) (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ)))
    (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ) (hk : 0 ≤ p.kpre) (hr : p.r ≠ 0) (ha : p.r + p.lam ≠ 0)
    (Fp : ℝ) {T : ℝ} (hT : 0 ≤ T) :
    Vrel ρ p Fp T = V ρ { p with F := p.F - (p.r + p.lam) * Fp / p.r } T + Fp / p.r := by
  have hq : ContinuousOn (holdIntegrand ρ { p with F := p.F - (p.r + p.lam) * Fp / p.r })
      (Ici 0) := holdIntegrand_continuousOn ρ _ hρ hg hΔ hk
  have hi1 : IntervalIntegrable (holdIntegrand ρ { p with F := p.F - (p.r + p.lam) * Fp / p.r })
      volume 0 T :=
    (hq.mono (by rw [uIcc_of_le hT]; exact Icc_subset_Ici_self)).intervalIntegrable
  have hi2 : IntervalIntegrable (fun t => (p.r + p.lam) * Fp / p.r * exp (-(p.r + p.lam) * t))
      volume 0 T := by
    apply Continuous.intervalIntegrable; fun_prop
  have hfun : (fun t => exp (-(p.r + p.lam) * t) * (p.F + p.lam * p.Z + ρ (lead p t))) =
      fun t => holdIntegrand ρ { p with F := p.F - (p.r + p.lam) * Fp / p.r } t +
          (p.r + p.lam) * Fp / p.r * exp (-(p.r + p.lam) * t) := by
    funext t; simp only [holdIntegrand, lead]; ring
  unfold Vrel V
  rw [hfun, intervalIntegral.integral_add hi1 hi2, intervalIntegral.integral_const_mul,
    integral_exp_neg_mul ha]
  simp only [J, lead]
  field_simp
  ring

/-- **A.7: research that survives both becomes neutral for timing.** If the research flow
`u` is part of `F` and survives both release and loss, the release value at every date is the
value without it plus `u/r`, so the optimal date does not depend on `u`. -/
theorem a7_research_both_neutral (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (hr : p.r ≠ 0) (ha : p.r + p.lam ≠ 0) (u : ℝ) {T : ℝ} (hT : 0 ≤ T) :
    Vboth ρ { p with F := p.F + u } u T = V ρ p T + u / p.r := by
  rw [a7_Vboth_eq ρ { p with F := p.F + u } hρ hg hΔ hk hr ha u hT]
  simp only [add_sub_cancel_right]

/-- **A.7: research that survives release only brings release sooner.** If the research flow
`u` is part of `F` and survives release only, the problem is the base problem with `F`
lowered by `λu/r` (plus a constant), so its stopping function is `Φ − λu/r`: a unit of it
moves the stopping condition by `−λ/r`. -/
theorem a7_research_release_only (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (hr : p.r ≠ 0) (ha : p.r + p.lam ≠ 0) (u : ℝ) :
    (∀ T, 0 ≤ T → Vrel ρ { p with F := p.F + u } u T =
      V ρ { p with F := p.F - p.lam * u / p.r } T + u / p.r) ∧
    (∀ T, Phi ρ { p with F := p.F - p.lam * u / p.r } T = Phi ρ p T - p.lam * u / p.r) ∧
    (∀ T, HasDerivAt (fun u => Phi ρ { p with F := p.F - p.lam * u / p.r } T)
      (-(p.lam / p.r)) 0) := by
  refine ⟨fun T hT => ?_, fun T => ?_, fun T => ?_⟩
  · rw [a7_Vrel_eq ρ { p with F := p.F + u } hρ hg hΔ hk hr ha u hT]
    congr 3
    field_simp
    ring
  · change (p.F - p.lam * u / p.r) + p.lam * p.Z + ρ (lead p T) - (p.r + p.lam) * J ρ p T +
      deriv (J ρ p) T = _
    unfold Phi; ring
  · have : (fun u => Phi ρ { p with F := p.F - p.lam * u / p.r } T) =
        fun u => Phi ρ p T + u * (-(p.lam / p.r)) := by
      funext u
      change (p.F - p.lam * u / p.r) + p.lam * p.Z + ρ (lead p T) - (p.r + p.lam) * J ρ p T +
        deriv (J ρ p) T = _
      unfold Phi; ring
    rw [this]
    simpa using ((hasDerivAt_id (0:ℝ)).mul_const (-(p.lam / p.r))).const_add (Phi ρ p T)

/-- The release-only research flow moves the stopping function by `−λ/r` per unit. -/
theorem a7_release_only_partial (ρ : ℝ → ℝ) (p : Prm) (T : ℝ) :
    HasDerivAt (fun u => Phi ρ { p with F := p.F - p.lam * u / p.r } T) (-(p.lam / p.r)) 0 := by
  have : (fun u => Phi ρ { p with F := p.F - p.lam * u / p.r } T) =
      fun u => Phi ρ p T + u * (-(p.lam / p.r)) := by
    funext u
    change (p.F - p.lam * u / p.r) + p.lam * p.Z + ρ (lead p T) - (p.r + p.lam) * J ρ p T +
      deriv (J ρ p) T = _
    unfold Phi; ring
  rw [this]
  simpa using ((hasDerivAt_id (0:ℝ)).mul_const (-(p.lam / p.r))).const_add (Phi ρ p T)

/-- **A.7: research surviving release only, the date conclusion.** At a simple downward
crossing, a differentiable crossing selection `T*(u)` of the release-only problem has
`dT*/du < 0` when `λ > 0` (release sooner) and `dT*/du = 0` when `λ = 0` (neutral). -/
theorem a7_research_release_only_sooner (ρ : ℝ → ℝ) (p : Prm) (hr : 0 < p.r)
    {Ts : ℝ → ℝ} {a d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ => Phi ρ { p with F := p.F - p.lam * q.2 / p.r } q.1)
      (Ts 0, 0))
    (ha : HasDerivAt (fun T => Phi ρ { p with F := p.F - p.lam * 0 / p.r } T) a (Ts 0))
    (hd : HasDerivAt Ts d 0)
    (hzero : ∀ᶠ u in 𝓝 0, Phi ρ { p with F := p.F - p.lam * u / p.r } (Ts u) = 0)
    (hneg : a < 0) : (0 < p.lam → d < 0) ∧ (p.lam = 0 → d = 0) := by
  have hcs := comp_statics (Φ := fun T u => Phi ρ { p with F := p.F - p.lam * u / p.r } T) hΦ ha
    (a7_release_only_partial ρ p (Ts 0)) hd hzero hneg
  refine ⟨fun hl => hcs.2.2.mpr (by have := div_pos hl hr; linarith), fun hl => ?_⟩
  rw [hcs.1, hl]; simp

/-- **A.7: research surviving both is neutral for timing**, as a statement about optima: the
release dates that maximize the value with the research flow are exactly those without it. -/
theorem a7_research_both_same_optima (ρ : ℝ → ℝ) (p : Prm)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (hr : p.r ≠ 0) (ha : p.r + p.lam ≠ 0) (u : ℝ) {T : ℝ} (hT : 0 ≤ T) :
    IsMaxOn (fun t => Vboth ρ { p with F := p.F + u } u t) (Ici 0) T ↔
      IsMaxOn (V ρ p) (Ici 0) T := by
  have e := fun t (ht : 0 ≤ t) => a7_research_both_neutral ρ p hρ hg hΔ hk hr ha u ht
  simp only [isMaxOn_iff]
  constructor
  · intro h x hx
    have := h x hx
    rw [e x hx, e T hT] at this
    linarith
  · intro h x hx
    show Vboth ρ { p with F := p.F + u } u x ≤ Vboth ρ { p with F := p.F + u } u T
    rw [e x hx, e T hT]
    linarith [h x hx]

/-- The A.7 values as expectations over the loss time: the surviving flow `F_post` adds
`F_post/r` to what is kept after loss (survives both) and to the release value. -/
noncomputable def VbothExp (ρ : ℝ → ℝ) (p : Prm) (Fp T : ℝ) : ℝ :=
  expVal (flow ρ p) p.r p.lam (p.Z + Fp / p.r) (J ρ p T + Fp / p.r) T

noncomputable def VrelExp (ρ : ℝ → ℝ) (p : Prm) (Fp T : ℝ) : ℝ :=
  expVal (flow ρ p) p.r p.lam p.Z (J ρ p T + Fp / p.r) T

/-- **A.7: `Vboth` is the expected payoff** when `F_post` survives both release and loss. -/
theorem a7_Vboth_is_expectation (ρ : ℝ → ℝ) (p : Prm) (hl : 0 < p.lam)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (Fp : ℝ) {T : ℝ} (hT : 0 ≤ T) : VbothExp ρ p Fp T = Vboth ρ p Fp T := by
  unfold VbothExp
  rw [expVal_flow ρ p hl hρ hg hΔ hk hT]
  rfl

/-- **A.7: `Vrel` is the expected payoff** when `F_post` survives release only. -/
theorem a7_Vrel_is_expectation (ρ : ℝ → ℝ) (p : Prm) (hl : 0 < p.lam)
    (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ))) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ)
    (hk : 0 ≤ p.kpre) (Fp : ℝ) {T : ℝ} (hT : 0 ≤ T) : VrelExp ρ p Fp T = Vrel ρ p Fp T := by
  unfold VrelExp
  rw [expVal_flow ρ p hl hρ hg hΔ hk hT]
  rfl

/-! ### "As first stated": a forgone flow above `F` with holding optimal -/

/-- The constant-flow counterexample: linear rents `M = 1`, `Δ = 1` (forgone flow `MΔ = 1`),
`F = 0.4`, `r = 0.05`, `λ = 0.2`, `Z = 0`, no old public model, post-release copy rate `κ`. -/
noncomputable def pCF (κ : ℝ) : Prm :=
  { r := 1/20, lam := 1/5, F := 2/5, Z := 0, kpre := 0, kpost := κ, g0 := 0, Δ := 1 }

/-- **P11 as first stated is false.** The forgone flow `MΔ = 1` exceeds `F = 0.4`, yet at
`κ = 1` holding is optimal: every date is beaten by a later one and no date reaches the
value of holding until loss. At `κ = 0.5` the optimum is immediate release. -/
theorem p11_asfirst_counterexample :
    (2/5 : ℝ) < 1 * 1 ∧
      (∀ T, V (fun y => 1 * y) (pCF 1) T < V (fun y => 1 * y) (pCF 1) (T + 1)) ∧
      (∀ T, V (fun y => 1 * y) (pCF 1) T < (2/5) / (1/20 + 1/5)) ∧
      (∀ T, 0 < T → V (fun y => 1 * y) (pCF (1/2)) T < V (fun y => 1 * y) (pCF (1/2)) 0) := by
  have h1 := p11ii_bangbang (fun y => 1 * y) (pCF 1) rfl (by simp) (by norm_num [pCF])
  have h2 := p11ii_bangbang (fun y => 1 * y) (pCF (1/2)) rfl (by simp) (by norm_num [pCF])
  rw [show (pCF 1).Δ = 1 from rfl, Pi_linear 1 (by norm_num [pCF])] at h1
  rw [show (pCF (1/2)).Δ = 1 from rfl, Pi_linear 1 (by norm_num [pCF])] at h2
  have hh := (h1.2.1 (by norm_num [pCF]))
  refine ⟨by norm_num, hh.1, fun T => ?_, h2.1 (by norm_num [pCF])⟩
  have := hh.2.1 T
  simpa [pCF] using this

/-! ### "The realized window is the shorter of the leak and release times" -/

/-- The capability is public at `t` once it has leaked (`L ≤ t`) or been released (`T ≤ t`). -/
def publicAt (L T t : ℝ) : Prop := L ≤ t ∨ T ≤ t

/-- The realized security window: the first date at which the capability is public. -/
noncomputable def window (L T : ℝ) : ℝ := sInf {t | publicAt L T t}

/-- **"True by definition."** The window ends at whichever comes first: `W = min(L, T)`. The
content is definitional (A.2.1); the theorem checks that "first public date" is `min`. -/
theorem p11_window_eq_min (L T : ℝ) : window L T = min L T := by
  have : {t | publicAt L T t} = Ici (min L T) := by
    ext t; simp [publicAt, min_le_iff]
  rw [window, this, csInf_Ici]

/-! ### The saturating reversal at `κ_post = 0` (proof of P11(v)) -/

/-- The example: `ρ = 1 − e^{−4x}`, `r = λ = κ_pre = Δ = 1`, `g₀ = e`, `Z = 0`,
`κ_post = 0`, `F = 1 + e^{−4} + 2e^{−8}`. -/
noncomputable def pSat : Prm :=
  { r := 1, lam := 1, F := 1 + exp (-4) + 2 * exp (-8), Z := 0, kpre := 1, kpost := 0,
    g0 := exp 1, Δ := 1 }

noncomputable def ρSat (y : ℝ) : ℝ := 1 - exp (-4 * y)

theorem Pi_sat (x : ℝ) : Pi ρSat 1 0 x = ρSat x := by
  unfold Pi
  rw [setIntegral_congr_fun measurableSet_Ioi (g := fun s => ρSat x * exp (-1 * s))
    (fun s _ => by simp only [neg_zero, zero_mul, exp_zero, mul_one]; ring)]
  rw [MeasureTheory.integral_const_mul, integral_exp_neg_Ioi_pos (by norm_num : (0:ℝ) < 1)]
  ring

theorem pSat_J : J ρSat pSat = fun T => ρSat (lead pSat T + 1) := by
  funext T; simp only [J, pSat]; exact Pi_sat _

theorem pSat_J_hasDerivAt (T : ℝ) :
    HasDerivAt (J ρSat pSat)
      (4 * exp (-4 * (lead pSat T + 1)) * (-1 * lead pSat T)) T := by
  rw [pSat_J]
  have hl : HasDerivAt (fun t => lead pSat t + 1) (-1 * lead pSat T) T := by
    have := (lead_hasDerivAt pSat T).add_const 1
    simpa [pSat] using this
  have h := ((hl.const_mul (-4)).exp).const_sub 1
  have h' : HasDerivAt (fun t => ρSat (lead pSat t + 1))
      (-(exp (-4 * (lead pSat T + 1)) * (-4 * (-1 * lead pSat T)))) T := h
  exact h'.congr_deriv (by ring)

noncomputable def hSat (g : ℝ) : ℝ := exp (-4 * g) * (1 - 2 * exp (-4) + 4 * exp (-4) * g)

theorem pSat_Phi (T : ℝ) : Phi ρSat pSat T = hSat 1 - hSat (lead pSat T) := by
  unfold Phi
  rw [(pSat_J_hasDerivAt T).deriv, pSat_J]
  have hF : pSat.F = 1 + exp (-4) + 2 * exp (-8) := rfl
  have hZ : pSat.Z = 0 := rfl
  have hr : pSat.r = 1 := rfl
  have hlam : pSat.lam = 1 := rfl
  rw [hF, hZ, hr, hlam]
  simp only [ρSat, hSat]
  have e1 : exp (-4 * (lead pSat T + 1)) = exp (-4 * lead pSat T) * exp (-4) := by
    rw [← exp_add]; ring_nf
  have e2 : exp (-8) = exp (-4) * exp (-4) := by rw [← exp_add]; norm_num
  have e3 : exp (-4 * 1) = exp (-4) := by norm_num
  rw [e1, e2, e3]
  ring

theorem hSat_strictAnti : StrictAntiOn hSat (Ici 0) := by
  have hc : exp (-4) < 1 / 3 := by
    have h5 : (5:ℝ) ≤ exp 4 := by have := add_one_le_exp (4:ℝ); linarith
    rw [exp_neg, inv_eq_one_div, div_lt_div_iff₀ (by positivity) (by norm_num)]
    linarith
  have hd : ∀ g, HasDerivAt hSat (exp (-4 * g) * (-4 + 12 * exp (-4) - 16 * exp (-4) * g)) g := by
    intro g
    have h1 : HasDerivAt (fun g => exp (-4 * g)) (exp (-4 * g) * (-4 * 1)) g :=
      ((hasDerivAt_id g).const_mul (-4)).exp
    have h2 : HasDerivAt (fun g => 1 - 2 * exp (-4) + 4 * exp (-4) * g) (4 * exp (-4) * 1) g :=
      ((hasDerivAt_id g).const_mul (4 * exp (-4))).const_add _
    exact (h1.mul h2).congr_deriv (by ring)
  apply strictAntiOn_of_deriv_neg (convex_Ici 0)
    (Continuous.continuousOn (by unfold hSat; fun_prop))
  intro x hx
  rw [interior_Ici] at hx
  rw [(hd x).deriv]
  have hx' : (0:ℝ) < x := hx
  have : -4 + 12 * exp (-4) - 16 * exp (-4) * x < 0 := by
    nlinarith [exp_pos (-4)]
  exact mul_neg_of_pos_of_neg (exp_pos _) this

/-- **The saturating example: `T* = 1` is the strict global optimum.** `Φ` falls strictly in
`T` and crosses zero once, at `g = 1`; release at `T* = 1` beats every other date and holding
until loss. -/
theorem p11v_saturating_optimum :
    lead pSat 1 = 1 ∧
      (∀ T, 0 ≤ T → T ≠ 1 → V ρSat pSat T < V ρSat pSat 1) ∧
      (∀ L, Tendsto (V ρSat pSat) atTop (𝓝 L) → L ≤ V ρSat pSat 1) := by
  have hl1 : lead pSat 1 = 1 := by
    simp only [lead, pSat]; rw [← exp_add]; norm_num
  have hpg : (0:ℝ) < pSat.g0 := exp_pos 1
  have hpk : (0:ℝ) < pSat.kpre := by norm_num [pSat]
  refine ⟨hl1, ?_⟩
  apply p11i_global ρSat pSat (Continuous.continuousOn (by unfold ρSat; fun_prop))
    hpg.le (by norm_num [pSat]) hpk.le (by norm_num [pSat]) (by norm_num [pSat])
    (fun T _ => (pSat_J_hasDerivAt T).differentiableAt) one_pos
  · intro T hT0 hT1
    rw [pSat_Phi]
    have h := lead_lt pSat hpg hpk hT1
    rw [hl1] at h
    have := hSat_strictAnti (Set.mem_Ici.mpr zero_le_one)
      (Set.mem_Ici.mpr (by linarith : (0:ℝ) ≤ lead pSat T)) h
    linarith
  · intro T hT
    rw [pSat_Phi]
    have h := lead_lt pSat hpg hpk hT
    rw [hl1] at h
    have h0 : 0 < lead pSat T := mul_pos hpg (exp_pos _)
    have := hSat_strictAnti (Set.mem_Ici.mpr h0.le) (Set.mem_Ici.mpr zero_le_one) h
    linarith

/-! ### The discount rate under power rents: either sign at a simple downward crossing -/

/-- **Single crossing from a monotone lead-function.** If `Φ(T) = φ(g(T))` with `φ` strictly
increasing on `[0, g₀]` (positive derivative inside), `φ(0) < 0 < φ(g₀)`, and the old lead
erodes (`g₀, κ_pre > 0`), then `Φ` has exactly one zero `T* > 0`, crosses it from above, and
the crossing is simple: `∂Φ/∂T(T*) = φ′(g*)·(−κ_pre g*) < 0`. -/
theorem single_crossing {ρ : ℝ → ℝ} {p : Prm} (φ φ' : ℝ → ℝ) (hk : 0 < p.kpre) (hg : 0 < p.g0)
    (hΦ : ∀ T, Phi ρ p T = φ (lead p T)) (hφc : ContinuousOn φ (Icc 0 p.g0))
    (hφd : ∀ g ∈ Ioo 0 p.g0, HasDerivAt φ (φ' g) g) (hφ' : ∀ g ∈ Ioo 0 p.g0, 0 < φ' g)
    (h0 : φ 0 < 0) (h1 : 0 < φ p.g0) :
    ∃ Ts, 0 < Ts ∧ Phi ρ p Ts = 0 ∧ (∀ T, 0 < T → T < Ts → 0 < Phi ρ p T) ∧
      (∀ T, Ts < T → Phi ρ p T < 0) ∧ ∃ a < 0, HasDerivAt (fun T => Phi ρ p T) a Ts := by
  have hmono : StrictMonoOn φ (Icc 0 p.g0) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc 0 p.g0) hφc
    intro x hx; rw [interior_Icc] at hx
    rw [(hφd x hx).deriv]; exact hφ' x hx
  obtain ⟨gs, hgs, hφgs⟩ := intermediate_value_Ioo hg.le hφc ⟨h0, h1⟩
  set Ts := Real.log (p.g0 / gs) / p.kpre with hTs
  have hlead : lead p Ts = gs := by
    simp only [lead, hTs]
    rw [show -p.kpre * (Real.log (p.g0 / gs) / p.kpre) = -Real.log (p.g0 / gs) by field_simp,
      exp_neg, exp_log (div_pos hg hgs.1)]
    field_simp
  have hTs0 : 0 < Ts := div_pos (Real.log_pos (by rw [one_lt_div hgs.1]; exact hgs.2)) hk
  have hmem : ∀ T, 0 ≤ T → lead p T ∈ Icc 0 p.g0 := fun T hT => lead_mem p hg.le hk.le hT
  have hgsm : gs ∈ Icc 0 p.g0 := ⟨hgs.1.le, hgs.2.le⟩
  refine ⟨Ts, hTs0, by rw [hΦ, hlead, hφgs], fun T hT0 hT1 => ?_, fun T hT => ?_, ?_⟩
  · rw [hΦ, ← hφgs]
    have := lead_lt p hg hk hT1
    rw [hlead] at this
    exact hmono hgsm (hmem T hT0.le) this
  · rw [hΦ, ← hφgs]
    have := lead_lt p hg hk hT
    rw [hlead] at this
    exact hmono (hmem T (by linarith)) hgsm this
  · refine ⟨φ' gs * (-p.kpre * gs), ?_, ?_⟩
    · have := hφ' gs hgs
      have := mul_pos hk hgs.1
      nlinarith
    · have hf : (fun T => Phi ρ p T) = fun T => φ (lead p T) := funext hΦ
      rw [hf]
      have hd : HasDerivAt φ (φ' gs) (lead p Ts) := by rw [hlead]; exact hφd gs hgs
      have := hd.comp Ts (lead_hasDerivAt p Ts)
      rw [hlead] at this
      exact this

/-- `Φ` for `ρ = √x` (`M = 1`, `η = 1/2`) in closed form through the lead: with `c = r + κ_post/2`,
`Φ = F + λZ + √g − (r+λ)√(g+Δ)/c − κ_pre g/(2c√(g+Δ))`. -/
theorem Phi_sqrt (p : Prm) (hc : 0 < p.r + 1/2 * p.kpost) {T : ℝ} (hx : 0 < lead p T + p.Δ) :
    Phi (fun y => 1 * y ^ (1/2 : ℝ)) p T = p.F + p.lam * p.Z + Real.sqrt (lead p T)
      - (p.r + p.lam) * Real.sqrt (lead p T + p.Δ) / (p.r + 1/2 * p.kpost)
      - p.kpre * lead p T / (2 * (p.r + 1/2 * p.kpost) * Real.sqrt (lead p T + p.Δ)) := by
  rw [Phi_power 1 (1/2) p hc hx]
  have hs : 0 < Real.sqrt (lead p T + p.Δ) := Real.sqrt_pos.mpr hx
  have e1 : (lead p T + p.Δ) ^ ((1:ℝ)/2 - 1) = (Real.sqrt (lead p T + p.Δ))⁻¹ := by
    rw [show (1:ℝ)/2 - 1 = -(1/2) by norm_num, Real.rpow_neg hx.le, rpow_half_eq_sqrt]
  rw [e1, rpow_half_eq_sqrt, rpow_half_eq_sqrt]
  field_simp

/-- The first example's lead-function: `pIV` (`κ_pre = κ_post = 1`, `g₀ = 36`, `Δ = 160`). -/
noncomputable def φIV (g : ℝ) : ℝ :=
  6 + Real.sqrt g - 2 / 3 * ((2 * g + 160) / Real.sqrt (g + 160))

noncomputable def φIV' (g : ℝ) : ℝ :=
  1 / (2 * Real.sqrt g) - 2 / 3 * ((2 * Real.sqrt (g + 160) -
    (2 * g + 160) * (1 / (2 * Real.sqrt (g + 160)))) / Real.sqrt (g + 160) ^ 2)

theorem pIV_Phi_eq (T : ℝ) : Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIV T = φIV (lead pIV T) := by
  have hg := lead_nonneg pIV (by norm_num [pIV]) T
  have hx : 0 < lead pIV T + pIV.Δ := by rw [show pIV.Δ = 160 from rfl]; linarith
  rw [Phi_sqrt pIV (by norm_num [pIV]) hx]
  have hs : 0 < Real.sqrt (lead pIV T + 160) := Real.sqrt_pos.mpr (by linarith)
  have hsq := Real.sq_sqrt (show 0 ≤ lead pIV T + 160 by linarith)
  simp only [φIV, show pIV.F = 6 from rfl, show pIV.lam = 1/4 from rfl, show pIV.Z = 0 from rfl,
    show pIV.r = 1/4 from rfl, show pIV.kpost = 1 from rfl, show pIV.kpre = 1 from rfl,
    show pIV.Δ = 160 from rfl]
  field_simp
  nlinarith [hsq]

theorem φIV_hasDeriv {g : ℝ} (hg : 0 < g) : HasDerivAt φIV (φIV' g) g := by
  have h1 : HasDerivAt (fun y => Real.sqrt y) (1 / (2 * Real.sqrt g)) g :=
    Real.hasDerivAt_sqrt hg.ne'
  have hx : HasDerivAt (fun y => y + 160) 1 g := (hasDerivAt_id g).add_const 160
  have h2 : HasDerivAt (fun y => Real.sqrt (y + 160)) (1 / (2 * Real.sqrt (g + 160))) g :=
    hx.sqrt (by linarith)
  have h3 : HasDerivAt (fun y => 2 * y + 160) 2 g := by
    simpa using ((hasDerivAt_id g).const_mul 2).add_const 160
  have h4 := h3.div h2 (Real.sqrt_pos.mpr (by linarith)).ne'
  have h5 := (h1.const_add 6).sub (h4.const_mul (2 / 3))
  exact h5

theorem φIV'_pos {g : ℝ} (hg : 0 < g) (hg36 : g < 36) : 0 < φIV' g := by
  have hs : 0 < Real.sqrt g := Real.sqrt_pos.mpr hg
  have hs6 : Real.sqrt g < 6 := by
    rw [show (6:ℝ) = Real.sqrt 36 by rw [show (36:ℝ) = 6 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]]
    exact Real.sqrt_lt_sqrt hg.le hg36
  set w := Real.sqrt (g + 160) with hw
  have hw2 : w ^ 2 = g + 160 := Real.sq_sqrt (by linarith)
  have hw0 : 0 < w := Real.sqrt_pos.mpr (by linarith)
  have hw1 : 63 / 5 ≤ w := by nlinarith
  have key : φIV' g = 1 / (2 * Real.sqrt g) - 2 / 3 * (g + 240) / ((g + 160) * w) := by
    simp only [φIV', ← hw]
    field_simp
    rw [show g = w ^ 2 - 160 by linarith]
    ring
  rw [key, sub_pos, div_lt_div_iff₀ (by positivity) (by positivity)]
  nlinarith [mul_le_mul_of_nonneg_left hw1 (show 0 ≤ g + 160 by linarith),
    mul_lt_mul_of_pos_left hs6 (show 0 < g + 240 by linarith)]

theorem φIV_cont : ContinuousOn φIV (Icc 0 36) := by
  unfold φIV
  apply ContinuousOn.sub (by fun_prop)
  apply ContinuousOn.mul continuousOn_const
  apply ContinuousOn.div (by fun_prop) (by fun_prop)
  intro x hx; exact (Real.sqrt_pos.mpr (by linarith [hx.1])).ne'

/-- `pIV`: `Φ` crosses zero exactly once, from above, and the crossing is simple. -/
theorem pIV_crossing :
    ∃ Ts, 0 < Ts ∧ Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIV Ts = 0 ∧
      (∀ T, 0 < T → T < Ts → 0 < Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIV T) ∧
      (∀ T, Ts < T → Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIV T < 0) ∧
      ∃ a < 0, HasDerivAt (fun T => Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIV T) a Ts := by
  have hg0 : pIV.g0 = 36 := rfl
  apply single_crossing φIV φIV' (by norm_num [pIV]) (by norm_num [pIV]) pIV_Phi_eq
    (by rw [hg0]; exact φIV_cont) (fun g hg => φIV_hasDeriv hg.1)
    (fun g hg => φIV'_pos hg.1 (by rw [hg0] at hg; exact hg.2))
  · -- φ(0) = 6 − (2/3)·160/√160 < 0
    have hs : Real.sqrt 160 < 13 := by
      rw [show (13:ℝ) = Real.sqrt (13 ^ 2) by rw [Real.sqrt_sq (by norm_num)]]
      exact Real.sqrt_lt_sqrt (by norm_num) (by norm_num)
    have hs0 : 0 < Real.sqrt 160 := Real.sqrt_pos.mpr (by norm_num)
    simp only [φIV, Real.sqrt_zero, mul_zero, zero_add, add_zero]
    rw [show (160:ℝ) / Real.sqrt 160 = Real.sqrt 160 by
      field_simp; rw [Real.sq_sqrt (by norm_num)]]
    have h2 := Real.sq_sqrt (show (0:ℝ) ≤ 160 by norm_num)
    nlinarith
  · -- φ(36) = 12 − (2/3)·232/14 > 0
    rw [hg0]
    simp only [φIV]
    rw [show Real.sqrt 36 = 6 by rw [show (36:ℝ) = 6 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)],
      show (36:ℝ) + 160 = 14 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
    norm_num

/-- A second concave example, with `λ > ηκ_post`: `ρ = √x`, `r = λ = 1/4`, `κ_pre = 1`,
`κ_post = 0`, `g₀ = 25`, `Δ = 1344`, `F = 71`, `Z = 0`. -/
noncomputable def pIVb : Prm :=
  { r := 1/4, lam := 1/4, F := 71, Z := 0, kpre := 1, kpost := 0, g0 := 25, Δ := 1344 }

noncomputable def φIVb (g : ℝ) : ℝ :=
  71 + Real.sqrt g - 2 * ((2 * g + 1344) / Real.sqrt (g + 1344))

noncomputable def φIVb' (g : ℝ) : ℝ :=
  1 / (2 * Real.sqrt g) - 2 * ((2 * Real.sqrt (g + 1344) -
    (2 * g + 1344) * (1 / (2 * Real.sqrt (g + 1344)))) / Real.sqrt (g + 1344) ^ 2)

theorem pIVb_Phi_eq (T : ℝ) : Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIVb T = φIVb (lead pIVb T) := by
  have hg := lead_nonneg pIVb (by norm_num [pIVb]) T
  have hx : 0 < lead pIVb T + pIVb.Δ := by rw [show pIVb.Δ = 1344 from rfl]; linarith
  rw [Phi_sqrt pIVb (by norm_num [pIVb]) hx]
  have hs : 0 < Real.sqrt (lead pIVb T + 1344) := Real.sqrt_pos.mpr (by linarith)
  have hsq := Real.sq_sqrt (show 0 ≤ lead pIVb T + 1344 by linarith)
  simp only [φIVb, show pIVb.F = 71 from rfl, show pIVb.lam = 1/4 from rfl,
    show pIVb.Z = 0 from rfl, show pIVb.r = 1/4 from rfl, show pIVb.kpost = 0 from rfl,
    show pIVb.kpre = 1 from rfl, show pIVb.Δ = 1344 from rfl]
  field_simp
  nlinarith [hsq]

theorem φIVb_hasDeriv {g : ℝ} (hg : 0 < g) : HasDerivAt φIVb (φIVb' g) g := by
  have h1 : HasDerivAt (fun y => Real.sqrt y) (1 / (2 * Real.sqrt g)) g :=
    Real.hasDerivAt_sqrt hg.ne'
  have hx : HasDerivAt (fun y => y + 1344) 1 g := (hasDerivAt_id g).add_const 1344
  have h2 : HasDerivAt (fun y => Real.sqrt (y + 1344)) (1 / (2 * Real.sqrt (g + 1344))) g :=
    hx.sqrt (by linarith)
  have h3 : HasDerivAt (fun y => 2 * y + 1344) 2 g := by
    simpa using ((hasDerivAt_id g).const_mul 2).add_const 1344
  have h4 := h3.div h2 (Real.sqrt_pos.mpr (by linarith)).ne'
  exact (h1.const_add 71).sub (h4.const_mul 2)

theorem φIVb'_pos {g : ℝ} (hg : 0 < g) (hg25 : g < 25) : 0 < φIVb' g := by
  have hs : 0 < Real.sqrt g := Real.sqrt_pos.mpr hg
  have hs5 : Real.sqrt g < 5 := by
    rw [show (5:ℝ) = Real.sqrt 25 by rw [show (25:ℝ) = 5 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]]
    exact Real.sqrt_lt_sqrt hg.le hg25
  set w := Real.sqrt (g + 1344) with hw
  have hw2 : w ^ 2 = g + 1344 := Real.sq_sqrt (by linarith)
  have hw0 : 0 < w := Real.sqrt_pos.mpr (by linarith)
  have hw1 : 183 / 5 ≤ w := by nlinarith
  have key : φIVb' g = 1 / (2 * Real.sqrt g) - 2 * (g + 2016) / ((g + 1344) * w) := by
    simp only [φIVb', ← hw]
    field_simp
    rw [show g = w ^ 2 - 1344 by linarith]
    ring
  rw [key, sub_pos, div_lt_div_iff₀ (by positivity) (by positivity)]
  nlinarith [mul_le_mul_of_nonneg_left hw1 (show 0 ≤ g + 1344 by linarith),
    mul_lt_mul_of_pos_left hs5 (show 0 < g + 2016 by linarith)]

theorem φIVb_cont : ContinuousOn φIVb (Icc 0 25) := by
  unfold φIVb
  apply ContinuousOn.sub (by fun_prop)
  apply ContinuousOn.mul continuousOn_const
  apply ContinuousOn.div (by fun_prop) (by fun_prop)
  intro x hx; exact (Real.sqrt_pos.mpr (by linarith [hx.1])).ne'

/-- `pIVb`: `Φ` crosses zero exactly once, from above, and the crossing is simple. -/
theorem pIVb_crossing :
    ∃ Ts, 0 < Ts ∧ Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIVb Ts = 0 ∧
      (∀ T, 0 < T → T < Ts → 0 < Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIVb T) ∧
      (∀ T, Ts < T → Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIVb T < 0) ∧
      ∃ a < 0, HasDerivAt (fun T => Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIVb T) a Ts := by
  have hg0 : pIVb.g0 = 25 := rfl
  apply single_crossing φIVb φIVb' (by norm_num [pIVb]) (by norm_num [pIVb]) pIVb_Phi_eq
    (by rw [hg0]; exact φIVb_cont) (fun g hg => φIVb_hasDeriv hg.1)
    (fun g hg => φIVb'_pos hg.1 (by rw [hg0] at hg; exact hg.2))
  · -- φ(0) = 71 − 2√1344 < 0
    have hs : 71 / 2 < Real.sqrt 1344 := by
      rw [show (71:ℝ) / 2 = Real.sqrt ((71 / 2) ^ 2) by rw [Real.sqrt_sq (by norm_num)]]
      exact Real.sqrt_lt_sqrt (by norm_num) (by norm_num)
    simp only [φIVb, Real.sqrt_zero, mul_zero, zero_add, add_zero]
    rw [show (1344:ℝ) / Real.sqrt 1344 = Real.sqrt 1344 by
      field_simp; rw [Real.sq_sqrt (by norm_num)]]
    linarith
  · -- φ(25) = 76 − 2·1394/37 = 24/37 > 0
    rw [hg0]
    simp only [φIVb]
    rw [show Real.sqrt 25 = 5 by rw [show (25:ℝ) = 5 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)],
      show (25:ℝ) + 1344 = 37 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
    norm_num

theorem sqrt_rent_cont (X : ℝ) : ContinuousOn (fun y : ℝ => 1 * y ^ (1/2 : ℝ)) (Icc 0 X) :=
  (continuous_const.mul (Real.continuous_rpow_const (by norm_num))).continuousOn

/-- **P11(v): under power rents the discount rate's effect on the release date can have either
sign.** In each example `Φ` crosses zero once, from above, at a simple crossing `T* > 0`, which
is the strict global optimum. At `pIV` `∂Φ/∂r < 0`, so any differentiable crossing selection
has `dT*/dr < 0`; at `pIVb` (`λ > ηκ_post`) `∂Φ/∂r > 0` and `dT*/dr > 0` (IFT hypotheses as in
`comp_statics`). -/
theorem p11v_r_power_either_sign :
    (∃ Ts, 0 < Ts ∧
      (∀ T, 0 ≤ T → T ≠ Ts →
        V (fun y => 1 * y ^ (1/2 : ℝ)) pIV T < V (fun y => 1 * y ^ (1/2 : ℝ)) pIV Ts) ∧
      Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIV Ts = 0 ∧
      (∃ a < 0, HasDerivAt (fun T => Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIV T) a Ts) ∧
      (∃ b < 0, HasDerivAt (fun r => Phi (fun y => 1 * y ^ (1/2 : ℝ)) { pIV with r := r } Ts) b
        pIV.r) ∧
      ∀ (Tsel : ℝ → ℝ) (d : ℝ), Tsel pIV.r = Ts →
        DifferentiableAt ℝ (fun q : ℝ × ℝ =>
          Phi (fun y => 1 * y ^ (1/2 : ℝ)) { pIV with r := q.2 } q.1) (Tsel pIV.r, pIV.r) →
        HasDerivAt Tsel d pIV.r →
        (∀ᶠ r in 𝓝 pIV.r, Phi (fun y => 1 * y ^ (1/2 : ℝ)) { pIV with r := r } (Tsel r) = 0) →
        d < 0) ∧
    (∃ Ts, 0 < Ts ∧
      (∀ T, 0 ≤ T → T ≠ Ts →
        V (fun y => 1 * y ^ (1/2 : ℝ)) pIVb T < V (fun y => 1 * y ^ (1/2 : ℝ)) pIVb Ts) ∧
      Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIVb Ts = 0 ∧
      (∃ a < 0, HasDerivAt (fun T => Phi (fun y => 1 * y ^ (1/2 : ℝ)) pIVb T) a Ts) ∧
      (∃ b > 0, HasDerivAt (fun r => Phi (fun y => 1 * y ^ (1/2 : ℝ)) { pIVb with r := r } Ts) b
        pIVb.r) ∧
      ∀ (Tsel : ℝ → ℝ) (d : ℝ), Tsel pIVb.r = Ts →
        DifferentiableAt ℝ (fun q : ℝ × ℝ =>
          Phi (fun y => 1 * y ^ (1/2 : ℝ)) { pIVb with r := q.2 } q.1) (Tsel pIVb.r, pIVb.r) →
        HasDerivAt Tsel d pIVb.r →
        (∀ᶠ r in 𝓝 pIVb.r, Phi (fun y => 1 * y ^ (1/2 : ℝ)) { pIVb with r := r } (Tsel r) = 0) →
        0 < d) := by
  constructor
  · obtain ⟨Ts, hTs, hz, hpos, hneg, a, ha, hda⟩ := pIV_crossing
    have hmax := p11i_global (fun y => 1 * y ^ (1/2 : ℝ)) pIV (sqrt_rent_cont _)
      (by norm_num [pIV]) (by norm_num [pIV]) (by norm_num [pIV]) (by norm_num [pIV])
      (by norm_num [pIV])
      (fun T _ => (J_power_hasDerivAt 1 (1/2) pIV (by norm_num [pIV])
        (by have := lead_nonneg pIV (by norm_num [pIV]) T; rw [show pIV.Δ = 160 from rfl]; linarith)).differentiableAt)
      hTs hpos hneg
    have hm := lead_mem pIV (by norm_num [pIV]) (by norm_num [pIV]) hTs.le
    have hx : 0 < lead pIV Ts + pIV.Δ := by have := hm.1; norm_num [pIV] at *; linarith
    have hb := p11v_r_partial_power 1 (1/2) pIV (by norm_num [pIV]) hx
    have hbneg : 1 * (lead pIV Ts + pIV.Δ) ^ ((1:ℝ)/2 - 1) *
        (pIV.kpre * (1/2) * lead pIV Ts - ((1/2) * pIV.kpost - pIV.lam) * (lead pIV Ts + pIV.Δ)) /
          (pIV.r + (1/2) * pIV.kpost) ^ 2 < 0 := by
      have hp := rpow_pos_of_pos hx ((1:ℝ)/2 - 1)
      apply div_neg_of_neg_of_pos _ (by norm_num [pIV])
      apply mul_neg_of_pos_of_neg (by positivity)
      have := hm.2
      simp only [pIV] at *
      nlinarith [hm.1]
    refine ⟨Ts, hTs, hmax.1, hz, ⟨a, ha, hda⟩, ⟨_, hbneg, hb⟩, fun Tsel d hsel hΦ hd hzero => ?_⟩
    subst hsel
    exact ((comp_statics (Φ := fun T r => Phi (fun y => 1 * y ^ (1/2 : ℝ)) { pIV with r := r } T)
      hΦ hda hb hd hzero ha).2.2).mpr hbneg
  · obtain ⟨Ts, hTs, hz, hpos, hneg, a, ha, hda⟩ := pIVb_crossing
    have hmax := p11i_global (fun y => 1 * y ^ (1/2 : ℝ)) pIVb (sqrt_rent_cont _)
      (by norm_num [pIVb]) (by norm_num [pIVb]) (by norm_num [pIVb]) (by norm_num [pIVb])
      (by norm_num [pIVb])
      (fun T _ => (J_power_hasDerivAt 1 (1/2) pIVb (by norm_num [pIVb])
        (by have := lead_nonneg pIVb (by norm_num [pIVb]) T; rw [show pIVb.Δ = 1344 from rfl]; linarith)).differentiableAt)
      hTs hpos hneg
    have hm := lead_mem pIVb (by norm_num [pIVb]) (by norm_num [pIVb]) hTs.le
    have hx : 0 < lead pIVb Ts + pIVb.Δ := by have := hm.1; norm_num [pIVb] at *; linarith
    have hb := p11v_r_partial_power 1 (1/2) pIVb (by norm_num [pIVb]) hx
    have hbpos : 0 < 1 * (lead pIVb Ts + pIVb.Δ) ^ ((1:ℝ)/2 - 1) *
        (pIVb.kpre * (1/2) * lead pIVb Ts -
          ((1/2) * pIVb.kpost - pIVb.lam) * (lead pIVb Ts + pIVb.Δ)) /
          (pIVb.r + (1/2) * pIVb.kpost) ^ 2 := by
      have hp := rpow_pos_of_pos hx ((1:ℝ)/2 - 1)
      apply div_pos _ (by norm_num [pIVb])
      apply mul_pos (by positivity)
      have := hm.1
      simp only [pIVb] at *
      nlinarith [hm.1]
    refine ⟨Ts, hTs, hmax.1, hz, ⟨a, ha, hda⟩, ⟨_, hbpos, hb⟩, fun Tsel d hsel hΦ hd hzero => ?_⟩
    subst hsel
    exact ((comp_statics (Φ := fun T r => Phi (fun y => 1 * y ^ (1/2 : ℝ)) { pIVb with r := r } T)
      hΦ hda hb hd hzero ha).2.1).mpr hbpos

/-! ### General continuous rents: `Π` is differentiable and `rΠ = ρ − κxΠ′` (κ > 0) -/

theorem f_integrableOn (ρ : ℝ → ℝ) {r κ x X a : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) (hx : 0 ≤ x)
    (hρ : ContinuousOn ρ (Icc 0 X)) (ha : x * exp (-κ * a) ≤ X) :
    IntegrableOn (fun s => exp (-r * s) * ρ (x * exp (-κ * s))) (Ioi a) := by
  obtain ⟨C, hC⟩ := isCompact_Icc.exists_bound_of_continuousOn hρ
  have hmaps : MapsTo (fun s => x * exp (-κ * s)) (Ici a) (Icc 0 X) := fun s hs => by
    refine ⟨mul_nonneg hx (exp_pos _).le, le_trans ?_ ha⟩
    exact mul_le_mul_of_nonneg_left (exp_le_exp.mpr (by nlinarith [show a ≤ s from hs])) hx
  have hcont : ContinuousOn (fun s => exp (-r * s) * ρ (x * exp (-κ * s))) (Ici a) :=
    (Continuous.continuousOn (by fun_prop)).mul
      (hρ.comp (Continuous.continuousOn (by fun_prop)) hmaps)
  refine Integrable.mono' ((exp_neg_integrableOn_Ioi a hr).const_mul C)
    ((hcont.mono Ioi_subset_Ici_self).aestronglyMeasurable measurableSet_Ioi) ?_
  refine (ae_restrict_iff' measurableSet_Ioi).mpr (Eventually.of_forall fun s hs => ?_)
  rw [norm_mul, Real.norm_of_nonneg (exp_pos _).le]
  have := hC _ (hmaps (Set.mem_Ici.mpr (le_of_lt hs)))
  nlinarith [exp_pos (-r * s), norm_nonneg (ρ (x * exp (-κ * s)))]

theorem integral_Ioi_shift (g : ℝ → ℝ) (h : ℝ) :
    ∫ s in Ioi (0:ℝ), g (s + h) = ∫ u in Ioi h, g u := by
  rw [← MeasureTheory.integral_indicator measurableSet_Ioi,
    ← MeasureTheory.integral_indicator measurableSet_Ioi, ← integral_add_right_eq_self (μ := volume) (fun u => (Ioi h).indicator g u) h]
  congr 1; ext s
  simp only [indicator, mem_Ioi]
  by_cases hs : 0 < s
  · simp [hs, show h < s + h by linarith]
  · simp [hs, show ¬ (h < s + h) by linarith]

/-- The shift identity: `Π(x e^{−κh}) = e^{rh}(Π(x) − ∫₀^h e^{−ru}ρ(x e^{−κu})du)`. -/
theorem Pi_shift (ρ : ℝ → ℝ) {r κ x X h : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) (hx : 0 ≤ x)
    (hρ : ContinuousOn ρ (Icc 0 X)) (hh : x * exp (-κ * h) ≤ X) (h0 : x ≤ X) :
    Pi ρ r κ (x * exp (-κ * h)) =
      exp (r * h) * (Pi ρ r κ x - ∫ u in (0:ℝ)..h, exp (-r * u) * ρ (x * exp (-κ * u))) := by
  set f := fun u => exp (-r * u) * ρ (x * exp (-κ * u)) with hf
  have h1 : Pi ρ r κ (x * exp (-κ * h)) = exp (r * h) * ∫ s in Ioi (0:ℝ), f (s + h) := by
    unfold Pi
    rw [← MeasureTheory.integral_const_mul]
    refine setIntegral_congr_fun measurableSet_Ioi (fun s _ => ?_)
    simp only [hf]
    have e1 : exp (-r * s) = exp (r * h) * exp (-r * (s + h)) := by rw [← exp_add]; ring_nf
    have e2 : x * exp (-κ * h) * exp (-κ * s) = x * exp (-κ * (s + h)) := by
      rw [mul_assoc, ← exp_add]; ring_nf
    rw [e1, e2]; ring
  have hI0 : IntegrableOn f (Ioi 0) := f_integrableOn ρ hr hκ hx hρ (by simpa using h0)
  have hIh : IntegrableOn f (Ioi h) := f_integrableOn ρ hr hκ hx hρ hh
  have h2 := intervalIntegral.integral_interval_add_Ioi hI0 hIh
  rw [h1, integral_Ioi_shift f h]
  unfold Pi
  rw [← h2]; ring

/-- **P11(ii) and the smoothness remark of P11's proof, general rents.** For `κ > 0` and a
rent merely continuous on `[0, X]`, `Π` is differentiable at every `x ∈ (0, X)` and satisfies
`rΠ = ρ − κxΠ′` there. -/
theorem p11ii_ode_general (ρ : ℝ → ℝ) {r κ x X : ℝ} (hr : 0 < r) (hκ : 0 < κ) (hx : 0 < x)
    (hX : x < X) (hρ : ContinuousOn ρ (Icc 0 X)) :
    HasDerivAt (Pi ρ r κ) ((ρ x - r * Pi ρ r κ x) / (κ * x)) x ∧
      r * Pi ρ r κ x = ρ x - κ * x * ((ρ x - r * Pi ρ r κ x) / (κ * x)) := by
  refine ⟨?_, by field_simp; ring⟩
  set f := fun u => exp (-r * u) * ρ (x * exp (-κ * u)) with hf
  set P := Pi ρ r κ x
  set hy := fun y => -Real.log (y / x) / κ with hhy
  -- the change of variable `y = x e^{−κ h(y)}`
  have hyx : ∀ y, 0 < y → x * exp (-κ * hy y) = y := by
    intro y hy0
    simp only [hhy]
    rw [show -κ * (-Real.log (y / x) / κ) = Real.log (y / x) by field_simp,
      exp_log (div_pos hy0 hx)]
    field_simp
  -- `Π` agrees near `x` with `G(y) = e^{r h(y)}(Π(x) − ∫₀^{h(y)} f)`
  have hev : Pi ρ r κ =ᶠ[𝓝 x] fun y => exp (r * hy y) * (P - ∫ u in (0:ℝ)..hy y, f u) := by
    filter_upwards [Ioo_mem_nhds hx hX] with y hy'
    have := Pi_shift ρ (h := hy y) hr hκ.le hx.le hρ (by rw [hyx y hy'.1]; exact hy'.2.le) hX.le
    rw [hyx y hy'.1] at this
    exact this
  -- derivative of `h(y)` at `x`
  have hh : HasDerivAt hy (-(1 / x) / κ) x := by
    have h1 : HasDerivAt (fun y => y / x) (1 / x) x := by
      simpa using (hasDerivAt_id x).div_const x
    have h2 := (h1.log (by simp [hx.ne'])).neg.div_const κ
    convert h2 using 1
    field_simp
  have hh0 : hy x = 0 := by simp [hhy, div_self hx.ne']
  -- FTC for `∫₀^h f` at `h = 0`
  set U := Ioi (-Real.log (X / x) / κ) with hU
  have hU0 : (0:ℝ) ∈ U := by
    have : 0 < Real.log (X / x) := Real.log_pos (by rw [one_lt_div hx]; exact hX)
    simp only [hU, mem_Ioi]
    have : 0 < Real.log (X / x) / κ := div_pos this hκ
    rw [neg_div]; linarith
  have hfU : ContinuousOn f U := by
    have hmaps : MapsTo (fun u => x * exp (-κ * u)) U (Icc 0 X) := by
      intro u hu
      refine ⟨mul_nonneg hx.le (exp_pos _).le, ?_⟩
      have hu' : -Real.log (X / x) / κ < u := hu
      have : -κ * u < Real.log (X / x) := by
        have := (div_lt_iff₀ hκ).mp hu'; linarith
      have := exp_lt_exp.mpr this
      rw [exp_log (div_pos (by linarith) hx)] at this
      have := mul_lt_mul_of_pos_left this hx
      rw [mul_div_cancel₀ _ hx.ne'] at this
      linarith
    exact (Continuous.continuousOn (by fun_prop)).mul
      (hρ.comp (Continuous.continuousOn (by fun_prop)) hmaps)
  have hFTC : HasDerivAt (fun h => ∫ u in (0:ℝ)..h, f u) (f 0) 0 :=
    integral_hasDerivAt_right (by simp)
      (hfU.stronglyMeasurableAtFilter (μ := volume) isOpen_Ioi 0 hU0)
      (hfU.continuousAt (isOpen_Ioi.mem_nhds hU0))
  have hFTC' : HasDerivAt (fun h => ∫ u in (0:ℝ)..h, f u) (f 0) (hy x) := by
    rw [hh0]; exact hFTC
  have hF := hFTC'.comp x hh
  have hE := ((hh.const_mul r).exp)
  have hG := hE.mul (hF.const_sub P)
  have hG' : HasDerivAt (fun y => exp (r * hy y) * (P - ∫ u in (0:ℝ)..hy y, f u))
      (exp (r * hy x) * (r * (-(1 / x) / κ)) * (P - ∫ u in (0:ℝ)..hy x, f u) +
        exp (r * hy x) * (-(f 0 * (-(1 / x) / κ)))) x := hG
  refine (hG'.congr_of_eventuallyEq hev).congr_deriv ?_
  rw [hh0]
  simp only [hf, mul_zero, exp_zero, intervalIntegral.integral_same, sub_zero, one_mul, mul_one]
  field_simp
  ring

/-- **P11(i), smoothness: `J` is differentiable under continuity alone when `κ_post > 0`.** At
any date `T > 0` with an eroding old model (`g₀, κ_pre > 0`), a rent continuous on
`[0, g₀ + Δ]` makes `J` differentiable, as P11's proof states. -/
theorem p11i_J_differentiable (ρ : ℝ → ℝ) (p : Prm) (hr : 0 < p.r) (hκ : 0 < p.kpost)
    (hg : 0 < p.g0) (hk : 0 < p.kpre) (hΔ : 0 ≤ p.Δ) (hρ : ContinuousOn ρ (Icc 0 (p.g0 + p.Δ)))
    {T : ℝ} (hT : 0 < T) : DifferentiableAt ℝ (J ρ p) T := by
  have hl : lead p T < p.g0 := by
    have := lead_lt p hg hk hT; simpa [lead] using this
  have hl0 : 0 < lead p T := mul_pos hg (exp_pos _)
  have hd := (p11ii_ode_general ρ hr hκ (by linarith : 0 < lead p T + p.Δ)
    (by linarith : lead p T + p.Δ < p.g0 + p.Δ) hρ).1
  exact (hd.comp T ((lead_hasDerivAt p T).add_const p.Δ)).differentiableAt

/-- **The integral representation of `Π` (P11's proof, `κ_post > 0`).** For any rent and
`x > 0`, `Π(x) = κ⁻¹x^{−r/κ}∫₀^x u^{r/κ−1}ρ(u)du`, by the substitution `u = xe^{−κs}`. (No
integrability is needed: the change-of-variables formula holds for every integrand.) -/
theorem Pi_integral_rep (ρ : ℝ → ℝ) {r κ x : ℝ} (hκ : 0 < κ) (hx : 0 < x) :
    Pi ρ r κ x = κ⁻¹ * x ^ (-(r / κ)) * ∫ u in (0:ℝ)..x, u ^ (r / κ - 1) * ρ u := by
  set f : ℝ → ℝ := fun s => x * exp (-κ * s) with hf
  have himg : f '' Ioi 0 = Ioo 0 x := by
    ext u; constructor
    · rintro ⟨s, hs, rfl⟩
      have hs' : (0:ℝ) < s := hs
      have : exp (-κ * s) < 1 := exp_lt_one_iff.mpr (by nlinarith)
      exact ⟨mul_pos hx (exp_pos _), by simp only [hf]; nlinarith⟩
    · rintro ⟨hu0, hux⟩
      refine ⟨-Real.log (u / x) / κ, ?_, ?_⟩
      · have : Real.log (u / x) < 0 :=
          Real.log_neg (div_pos hu0 hx) (by rw [div_lt_one hx]; exact hux)
        show 0 < -Real.log (u / x) / κ
        exact div_pos (by linarith) hκ
      · simp only [hf]
        rw [show -κ * (-Real.log (u / x) / κ) = Real.log (u / x) by field_simp,
          exp_log (div_pos hu0 hx)]
        field_simp
  have hderiv : ∀ s ∈ Ioi (0:ℝ), HasDerivWithinAt f (x * (exp (-κ * s) * (-κ * 1))) (Ioi 0) s :=
    fun s _ => ((((hasDerivAt_id s).const_mul (-κ)).exp).const_mul x).hasDerivWithinAt
  have hinj : InjOn f (Ioi 0) := by
    intro a _ b _ hab
    simp only [hf] at hab
    have h1 := Real.exp_injective (mul_left_cancel₀ hx.ne' hab)
    have : κ * a = κ * b := by linarith
    exact mul_left_cancel₀ hκ.ne' this
  have hcv := integral_image_eq_integral_abs_deriv_smul measurableSet_Ioi hderiv hinj
    (fun u => u ^ (r / κ - 1) * ρ u)
  rw [himg] at hcv
  rw [intervalIntegral.integral_of_le hx.le, integral_Ioc_eq_integral_Ioo, hcv]
  have hpt : ∀ s ∈ Ioi (0:ℝ), |x * (exp (-κ * s) * (-κ * 1))| • ((f s) ^ (r / κ - 1) * ρ (f s)) =
      (κ * x ^ (r / κ)) * (exp (-r * s) * ρ (x * exp (-κ * s))) := by
    intro s _
    have hfs : 0 < f s := mul_pos hx (exp_pos _)
    rw [smul_eq_mul, show x * (exp (-κ * s) * (-κ * 1)) = -(κ * f s) by simp only [hf]; ring,
      abs_neg, abs_of_pos (mul_pos hκ hfs)]
    have h1 : κ * f s * (f s ^ (r / κ - 1) * ρ (f s)) = κ * (f s * f s ^ (r / κ - 1)) * ρ (f s) := by
      ring
    rw [h1, rpow_mul_pred hfs]
    simp only [hf]
    rw [mul_rpow hx.le (exp_pos _).le, ← exp_mul, show -κ * s * (r / κ) = -r * s by field_simp]
    ring
  rw [setIntegral_congr_fun measurableSet_Ioi hpt, MeasureTheory.integral_const_mul]
  unfold Pi
  set I := ∫ s in Ioi (0:ℝ), exp (-r * s) * ρ (x * exp (-κ * s))
  have hxr : x ^ (-(r / κ)) * x ^ (r / κ) = 1 := by
    rw [Real.rpow_neg hx.le, inv_mul_cancel₀ (rpow_pos_of_pos hx _).ne']
  rw [show κ⁻¹ * x ^ (-(r / κ)) * (κ * x ^ (r / κ) * I) =
      (κ⁻¹ * κ) * (x ^ (-(r / κ)) * x ^ (r / κ)) * I by ring, inv_mul_cancel₀ hκ.ne', hxr]
  ring

end RTTR.Release

section Audit
open RTTR.Release
#print axioms lead_continuous
#print axioms lead_hasDerivAt
#print axioms lead_mem
#print axioms holdIntegrand_continuousOn
#print axioms p11i_V_hasDerivAt
#print axioms contOn_Ici_of
#print axioms strict_max_of_sign
#print axioms deriv_sign_const
#print axioms localMax_crossing
#print axioms sup_at_infinity
#print axioms integral_exp_neg_mul
#print axioms integral_exp_neg_Ioi_pos
#print axioms scaled_mem
#print axioms Pi_integrableOn
#print axioms lead_add_mem
#print axioms J_contWithin0
#print axioms J_bounded
#print axioms holdIntegrand_integrableOn
#print axioms integral_contWithin0
#print axioms V_contWithin0
#print axioms p11i_foc
#print axioms p11i_foc_reduced
#print axioms p11i_global
#print axioms p11i_candidates
#print axioms p11i_no_max_hold
#print axioms p11i_hold_limit
#print axioms no_max_lt_limit
#print axioms p11i_hold_optimal
#print axioms expVal_eq
#print axioms flow_continuousOn
#print axioms expVal_flow
#print axioms p11i_V_is_expectation
#print axioms p11i_V_no_hazard
#print axioms lead_noOld
#print axioms J_noOld
#print axioms V_noOld
#print axioms p11ii_Phi_const
#print axioms bangbang_core
#print axioms p11ii_bangbang
#print axioms p11ii_Pi_antitone
#print axioms p11ii_Pi_strictAnti
#print axioms p11ii_faster_post_keeps_hold
#print axioms lead_constLead
#print axioms V_constLead
#print axioms p11_constLead_bangbang
#print axioms Pi_linear
#print axioms Pi_power
#print axioms p11ii_ode_linear
#print axioms p11ii_ode_power
#print axioms Pi_kpost_zero
#print axioms lead_nonneg
#print axioms lead_le
#print axioms lead_lt
#print axioms J_linear
#print axioms J_linear_hasDerivAt
#print axioms p11iii_Phi
#print axioms linρ_cont
#print axioms linV_hasDerivAt
#print axioms linJ_contWithin0
#print axioms linV_contOn
#print axioms p11iii_strict_interior_requires
#print axioms p11iii_equality
#print axioms p11iii_no_interior_localMax
#print axioms p11iii_one_rate_corner
#print axioms p11iii_below_line_corner
#print axioms l30_equality_counterexample
#print axioms V_power
#print axioms rpow_half_eq_sqrt
#print axioms pIV_V
#print axioms p11iv_interior_release
#print axioms p11iv_gain_grows
#print axioms p11iv_gain_grows_in_T
#print axioms Pi_sq
#print axioms pSq_J
#print axioms pSq_J_hasDerivAt
#print axioms pSq_Phi
#print axioms p11iii_convex_interior
#print axioms comp_statics
#print axioms p11v_fu_partial
#print axioms p11v_lam_partial
#print axioms p11v_fa_partial
#print axioms p11v_fu_later
#print axioms p11v_fa_later_iff
#print axioms p11v_lam_sooner_iff
#print axioms Phi_AB
#print axioms p11v_kpre_partial
#print axioms p11v_kpre_sooner
#print axioms p11v_kpre_identity
#print axioms p11v_kpre_earlier
#print axioms rpow_mul_pred
#print axioms J_power_hasDerivAt
#print axioms Phi_power
#print axioms p11v_kpost_partial_power
#print axioms p11v_kpost_partial_power_pos
#print axioms p11v_kpost_later_power
#print axioms p11v_r_partial_power
#print axioms p11v_r_partial_linear
#print axioms p11v_r_linear_negative
#print axioms p11v_r_linear_sooner
#print axioms a7_kpost_hazard_partial
#print axioms a7_kpost_hazard_condition
#print axioms a7_kpost_later_iff
#print axioms a7_kpost_hazard_partial_general
#print axioms a7_kpost_later_iff_general
#print axioms a7_Vboth_eq
#print axioms a7_Vrel_eq
#print axioms a7_research_both_neutral
#print axioms a7_research_release_only
#print axioms a7_release_only_partial
#print axioms a7_research_release_only_sooner
#print axioms a7_research_both_same_optima
#print axioms a7_Vboth_is_expectation
#print axioms a7_Vrel_is_expectation
#print axioms p11_asfirst_counterexample
#print axioms p11_window_eq_min
#print axioms Pi_sat
#print axioms pSat_J
#print axioms pSat_J_hasDerivAt
#print axioms pSat_Phi
#print axioms hSat_strictAnti
#print axioms p11v_saturating_optimum
#print axioms single_crossing
#print axioms Phi_sqrt
#print axioms pIV_Phi_eq
#print axioms φIV_hasDeriv
#print axioms φIV'_pos
#print axioms φIV_cont
#print axioms pIV_crossing
#print axioms pIVb_Phi_eq
#print axioms φIVb_hasDeriv
#print axioms φIVb'_pos
#print axioms φIVb_cont
#print axioms pIVb_crossing
#print axioms sqrt_rent_cont
#print axioms p11v_r_power_either_sign
#print axioms f_integrableOn
#print axioms integral_Ioi_shift
#print axioms Pi_shift
#print axioms p11ii_ode_general
#print axioms p11i_J_differentiable
#print axioms Pi_integral_rep
end Audit
