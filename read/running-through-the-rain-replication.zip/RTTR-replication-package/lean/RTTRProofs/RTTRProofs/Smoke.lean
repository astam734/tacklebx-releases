import Mathlib
theorem smoke (x : ℝ) (h : 0 < x) : 0 < x ^ 2 := by positivity
