import Mathlib

/-!
# GAP2 — body-only algebra, cited theorems, negative-generality claims (RTTR v8)

Paper: `ARXIV/paper/PAPER-DRAFT-v8.md`. Brief: `LEAN/COMMON-LEAN.md` and block GAP2 of
`LEAN/SEATS-GAP.md`. This file imports only Mathlib. Every row of GAP2's inventory that a writer
seat already proves is cited in `LEAN/GAP2-ROWS.md`, not restated here. This file proves the rows
no writer file covers:

* **B132** (line 390): a higher loss hazard shortens the involuntary-loss time.
* **B86** (line 227): Rice's theorem in the paper's r.e.-set phrasing.
* **P36** (line 1134, fix round 1): the identity `∂Φ̃/∂κ_pre = −gΠ′` for the paper's `Φ̃`, and
  a counterexample to its strict sign `< 0` at an admissible interior optimum.
* **B106** (line 312, fix round 1): the zero-length exposure at which the strict fall fails.
* **B8** (line 11): a toy model of the cited rain physics. It illustrates the citation and does
  not formalize it.
* **B158, B162** (lines 454, 459): P11(v)'s artifact rule restated for theft-inducing flow and
  for contract flow.
* **A96** (line 987): with one copy rate, the sign of `dT*/dκ` is not determined.
* **P33** (line 1134): the jump-rent kink example, which seat L5 routed here as UNATTEMPTED.
* **B84 / C13** (lines 213, 1337): discounting moves P16's net sign in either direction.
  Seat L7 already covers this; the examples here use two positive rates and an active benefit.

## How each paper object is represented, and why that is faithful

* **Involuntary-loss time** (B132). Under A7 the hazard is constant, so the loss time has the
  exponential law, Mathlib's `ProbabilityTheory.expMeasure λ`. "Shortens" is proved as
  first-order stochastic dominance, through the CDF from `cdf_expMeasure_eq`, for `λ₁ > 0`.
  It is also proved pathwise, under the coupling `L_λ = E/λ` on the probability space
  `(ℝ, expMeasure 1)`; `b132_coupling_law` proves that `E/λ` has law `expMeasure λ`. A zero
  baseline hazard (allowed by A7) has no real-valued exponential law; there the loss time is
  `∞`, and `b132_pathwise_ext` covers `0 ≤ λ₁ < λ₂` in `[0, ∞]`.
* **Rice** (B86). A "total algorithm" is a computable predicate on codes
  (`ComputablePred` over `Nat.Partrec.Code`). "The set a partial recursive function
  enumerates" is its range (`enumSet`) in `b86_rice_range` and its domain in
  `b86_rice_domain`. For the domain reading, `b86_domain_re` proves that the sets so named are
  exactly Mathlib's r.e. predicates (`REPred`). For the range reading this is the standard
  fact, not machine-checked here. "A property possessed by some but
  not all r.e. sets" is a predicate `P` with a code whose set has `P` and a code whose set lacks
  it. Both theorems follow from Mathlib's `ComputablePred.rice`.
* **Rain** (B8). `wet` is wetness in the textbook model: vertical rain of density `n` falling at
  speed `u`, wind `w` along the runner's direction, top area `A`, front area `B`, distance `d`.
  This is an illustrative model, not the cited physics (Bell 1976 uses measured body shapes).
* **Sub-model Program** (B158, B162, A96, P33). `Prm`, `lead`, `Pi`, `J`, `holdIntegrand`, `V`
  and `Phi` are textually the same as seat L5's definitions in `Release.lean`:
  * `Π(x) = ∫₀^∞ e^{−rs}ρ(xe^{−κ_post s})ds` is the Bochner integral over `(0, ∞)`.
  * `V(T)` is the paper's planned-release value: an interval integral plus the discounted `J`.
  * `Φ(T) = F + λZ + ρ(g(T)) − (r+λ)J(T) + J′(T)`, where `J′` is `deriv` of the defined `J`.

  Every closed form for `Π` (`√x`, the jump rent) is proved from the integral.
* **Comparative statics** (B158, B162, A96). These are stated as L5 states them:
  * `comp_statics` gives `dT*/dθ = −(∂Φ/∂θ)/(∂Φ/∂T)` for a differentiable crossing selection
    `T*(θ)`.
  * The selection is a hypothesis: the implicit-function premise, as in L5.
  * In A96, joint differentiability of `Φ` is **proved**, not assumed.
  * In A96, `zero_displacement` also gives the direction with no selection and no implicit
    function theorem: every zero of `Φ(·, κ)` near `T*` moves to the predicted side.
* **"Other primitives fixed"** is a record update of the one primitive that varies:
  * the theft term or the hazard function in B158 and B162;
  * `κ_pre = κ_post = k` together in A96 (the paper's "one copy rate for both phases");
  * `r` in C13.
* **Admissible interior optimum** (A96). In each example `Φ` crosses zero exactly once, from
  above, simply (`∂Φ/∂T < 0`), at `T* = ln g₀`. `V_sqrt_strict_max` proves from
  `V′ = e^{−(r+λ)T}Φ` that `T*` is the strict global maximum of the defined `V` on `[0, ∞)`.
  `F` is chosen so that the crossing lead is `g* = 1`, the same way A.6's grid fixes `F` by a
  selection rule. These are chosen inputs, not inputs recovered from the paper.
* **P33.**
  * The rent is `ρJ(y) = y + 1{y ≥ 1}`, at the paper's stated primitives.
  * "Φ jumps from +1/2 to −1/2" is proved as one-sided limits at `T₀ = ln 1.1`.
  * `V(∞)` is the limit of `V` as `T → ∞`.
  * "The sign of Φ establishes this" is `V′ = e^{−2T}Φ` off the kink (`p33_V_deriv`, fix round
    2). "V rises up to T₀" is `StrictMonoOn` on `[0, T₀]`; "a local minimum of V" is a strict
    local minimum (`∀ᶠ T in 𝓝[≠] T₁, V(T₁) < V(T)`); "beyond which V rises toward V(∞)" is
    `StrictMonoOn` on `[T₁, ∞)` with the limit.
  * The decimals 1.6129, 1.5738 and 1.5784 are the exact rationals 2129/1320, 661/420 and
    22919/14520, each within 5·10⁻⁵ of the printed value.
* **P16** (C13). `A_r(u) = (1 − e^{−ru})/r`, `B_r = (y/r)e^{−rt_B}`, `C_{c,r} = HA_r(T) + S_r`,
  and the clocks `max(D/s, (1−m)t₀) + mt₀` are P16(ii)'s own definitions (lines 1021, 1031).
  `W13` is `W_r` at stated illustrative primitives, and its speed derivative is that of the
  defined function. The primitives are chosen; they are not the paper's.
-/

open Real MeasureTheory Set Filter Topology intervalIntegral

namespace RTTR.Gaps2

/-! ## B132: a higher loss hazard shortens the involuntary-loss time -/

/-- **B132 (line 390), in distribution.** The involuntary-loss time under a constant hazard `λ`
is exponential (A7), `expMeasure λ`. A higher hazard raises its CDF at every date and strictly
at every positive date: the loss time is stochastically shorter. -/
theorem b132_stochastic_order {l₁ l₂ : ℝ} (h₁ : 0 < l₁) (h12 : l₁ < l₂) :
    (∀ t, ProbabilityTheory.cdf (ProbabilityTheory.expMeasure l₁) t ≤
      ProbabilityTheory.cdf (ProbabilityTheory.expMeasure l₂) t) ∧
    (∀ t, 0 < t → ProbabilityTheory.cdf (ProbabilityTheory.expMeasure l₁) t <
      ProbabilityTheory.cdf (ProbabilityTheory.expMeasure l₂) t) := by
  have h₂ : 0 < l₂ := h₁.trans h12
  have key : ∀ t, 0 < t → exp (-(l₂ * t)) < exp (-(l₁ * t)) := fun t ht =>
    exp_lt_exp.2 (by nlinarith)
  refine ⟨fun t => ?_, fun t ht => ?_⟩
  · rw [ProbabilityTheory.cdf_expMeasure_eq h₁, ProbabilityTheory.cdf_expMeasure_eq h₂]
    split_ifs with h
    · rcases h.eq_or_lt with h0 | h0
      · subst h0; simp
      · linarith [key t h0]
    · exact le_rfl
  · rw [ProbabilityTheory.cdf_expMeasure_eq h₁, ProbabilityTheory.cdf_expMeasure_eq h₂]
    simp only [ht.le, ↓reduceIte]
    linarith [key t ht]

/-- **B132, pathwise: auxiliary arithmetic.** With one unit-rate draw `E > 0`, `E/λ₂ < E/λ₁`.
That `E/λ` has law `expMeasure λ` is `b132_coupling_law`. -/
theorem b132_pathwise {E l₁ l₂ : ℝ} (hE : 0 < E) (h₁ : 0 < l₁) (h12 : l₁ < l₂) :
    E / l₂ < E / l₁ :=
  div_lt_div_of_pos_left hE h₁ h12

/-- **B132, the coupling's law.** If `E` has the unit-rate exponential law, `E/λ` has law
`expMeasure λ` for every `λ > 0`. So on the probability space `(ℝ, expMeasure 1)` the loss
times `L_λ = E/λ` have the model's laws, and `b132_pathwise` shortens every path with `E > 0`
(which holds almost surely). -/
theorem b132_coupling_law {l : ℝ} (hl : 0 < l) :
    (ProbabilityTheory.expMeasure 1).map (fun x => x / l) = ProbabilityTheory.expMeasure l := by
  have := ProbabilityTheory.isProbabilityMeasure_expMeasure (r := 1) one_pos
  have := ProbabilityTheory.isProbabilityMeasure_expMeasure hl
  have hm : Measurable fun x : ℝ => x / l := measurable_id.div_const l
  refine Measure.ext_of_Iic _ _ fun a => ?_
  rw [Measure.map_apply hm measurableSet_Iic]
  have hpre : (fun x : ℝ => x / l) ⁻¹' Iic a = Iic (a * l) := by
    ext x; simp [div_le_iff₀ hl]
  rw [hpre, ← ProbabilityTheory.ofReal_cdf, ← ProbabilityTheory.ofReal_cdf,
    ProbabilityTheory.cdf_expMeasure_eq one_pos, ProbabilityTheory.cdf_expMeasure_eq hl]
  congr 1
  by_cases ha : 0 ≤ a
  · simp only [ha, mul_nonneg ha hl.le, ↓reduceIte, one_mul]; ring_nf
  · have : ¬ 0 ≤ a * l := fun h => ha (nonneg_of_mul_nonneg_left h hl)
    simp [ha, this]

/-- **B132, pathwise, including a zero baseline hazard.** In `[0, ∞]`, with the loss time
`E/λ` (which is `∞` when `λ = 0`: no loss ever), a higher hazard shortens it strictly on every
path with `E > 0`, for every `0 ≤ λ₁ < λ₂`. -/
theorem b132_pathwise_ext {E l₁ l₂ : ℝ} (hE : 0 < E) (h₁ : 0 ≤ l₁) (h12 : l₁ < l₂) :
    ENNReal.ofReal E / ENNReal.ofReal l₂ < ENNReal.ofReal E / ENNReal.ofReal l₁ := by
  have h₂ : 0 < l₂ := h₁.trans_lt h12
  rcases h₁.eq_or_lt with h0 | h0
  · subst h0
    rw [ENNReal.ofReal_zero, ENNReal.div_zero (ENNReal.ofReal_pos.2 hE).ne']
    exact ENNReal.div_lt_top ENNReal.ofReal_ne_top (ENNReal.ofReal_pos.2 h₂).ne'
  · rw [← ENNReal.ofReal_div_of_pos h₂, ← ENNReal.ofReal_div_of_pos h0,
      ENNReal.ofReal_lt_ofReal_iff (div_pos hE h0)]
    exact div_lt_div_of_pos_left hE h0 h12

/-! ## B86: Rice's theorem, in the paper's r.e.-set phrasing -/

open Nat.Partrec in
/-- The set enumerated by a code: the range of the partial recursive function it computes. -/
def enumSet (c : Code) : Set ℕ := {m | ∃ n, m ∈ Code.eval c n}

open Nat.Partrec in
/-- **B86 (line 227), Rice's theorem.** Let `P` be a property of sets of naturals possessed by
some but not all recursively enumerable sets (r.e. sets are exactly the ranges of partial
recursive functions, each given by a code). Then no total algorithm decides, from a code of an
arbitrary partial recursive function, whether the set it enumerates has `P`. Proved from
Mathlib's `ComputablePred.rice`. -/
theorem b86_rice_range (P : Set ℕ → Prop) {c₁ c₂ : Code} (h₁ : P (enumSet c₁))
    (h₂ : ¬ P (enumSet c₂)) : ¬ ComputablePred fun c : Code => P (enumSet c) := by
  intro hc
  let C : Set (ℕ →. ℕ) := {f | P {m | ∃ n, m ∈ f n}}
  have hC : ComputablePred fun c => Code.eval c ∈ C := hc
  exact h₂ (ComputablePred.rice C hC (Code.exists_code.2 ⟨c₁, rfl⟩)
    (Code.exists_code.2 ⟨c₂, rfl⟩) h₁)

open Nat.Partrec in
/-- **B86, domain form.** The same with r.e. sets as domains of partial recursive functions. -/
theorem b86_rice_domain (P : Set ℕ → Prop) {c₁ c₂ : Code} (h₁ : P {n | (Code.eval c₁ n).Dom})
    (h₂ : ¬ P {n | (Code.eval c₂ n).Dom}) :
    ¬ ComputablePred fun c : Code => P {n | (Code.eval c n).Dom} := by
  intro hc
  let C : Set (ℕ →. ℕ) := {f | P {n | (f n).Dom}}
  have hC : ComputablePred fun c => Code.eval c ∈ C := hc
  exact h₂ (ComputablePred.rice C hC (Code.exists_code.2 ⟨c₁, rfl⟩)
    (Code.exists_code.2 ⟨c₂, rfl⟩) h₁)

open Nat.Partrec in
/-- **B86, the identification behind the domain reading.** A predicate on `ℕ` is r.e. in
Mathlib's sense (`REPred`) iff it is the domain of the function computed by some code. So the
hypotheses of `b86_rice_domain` say exactly "some but not all r.e. sets have `P`". -/
theorem b86_domain_re (p : ℕ → Prop) :
    REPred p ↔ ∃ c : Code, ∀ n, p n ↔ (Code.eval c n).Dom := by
  constructor
  · intro hp
    have hf : Partrec fun n : ℕ => (Part.assert (p n) fun _ => Part.some ()).map fun _ => (0:ℕ) :=
      Partrec.map hp (Computable.const 0).to₂
    obtain ⟨c, hc⟩ := Code.exists_code.1 (Partrec.nat_iff.1 hf)
    refine ⟨c, fun n => ?_⟩
    rw [hc]
    exact ⟨fun h => ⟨h, trivial⟩, fun ⟨h, _⟩ => h⟩
  · rintro ⟨c, hc⟩
    have h := Partrec.dom_re (Partrec.nat_iff.2 (Code.exists_code.2 ⟨c, rfl⟩))
    have e : p = fun n => (Code.eval c n).Dom := funext fun n => propext (hc n)
    rw [e]; exact h

/-! ## B8: a toy model of the cited rain physics (illustration only) -/

/-- Wetness of a runner crossing distance `d` at speed `v > 0` in rain of density `n`, falling
at speed `u`, with a horizontal wind `w` along the direction of motion: top area `A` collects
`n u A` per unit time, front area `B` collects `n |v − w| B`, for time `d/v`. -/
noncomputable def wet (n u A B d w v : ℝ) : ℝ := d / v * (n * u * A + n * |v - w| * B)

/-- Toy model, no wind: the front contribution `d·n·B` does not depend on speed ("the same
curtain of rain in front of you at any speed"), and total wetness falls strictly with speed. -/
theorem b8_toy_no_wind {n u A B d : ℝ} (hn : 0 < n) (hu : 0 < u) (hA : 0 < A) (hd : 0 < d) :
    (∀ v, 0 < v → d / v * (n * |v - 0| * B) = d * n * B) ∧
    StrictAntiOn (wet n u A B d 0) (Ioi 0) := by
  refine ⟨fun v hv => ?_, fun v hv v' hv' hvv' => ?_⟩
  · rw [sub_zero, abs_of_pos hv]; field_simp
  · simp only [wet, sub_zero, abs_of_pos (show (0:ℝ) < v from hv),
      abs_of_pos (show (0:ℝ) < v' from hv')]
    have hv0 : (0:ℝ) < v := hv
    have hv0' : (0:ℝ) < v' := hv'
    have e : ∀ x : ℝ, 0 < x → d / x * (n * u * A + n * x * B) = d * n * u * A / x + d * n * B :=
      fun x hx => by field_simp
    rw [e v' hv0', e v hv0]
    have : d * n * u * A / v' < d * n * u * A / v :=
      div_lt_div_of_pos_left (by positivity) hv0 hvv'
    linarith

/-- Toy model, the tailwind exception: with a tailwind `w > 0` strong enough that
`w·B > u·A`, running faster than the wind strictly raises wetness. -/
theorem b8_toy_tailwind {n u A B d w : ℝ} (hn : 0 < n) (hd : 0 < d) (hw : 0 < w)
    (hstrong : u * A < w * B) : StrictMonoOn (wet n u A B d w) (Ioi w) := by
  intro v hv v' hv' hvv'
  have hv0 : (0:ℝ) < v := hw.trans hv
  have hv0' : (0:ℝ) < v' := hw.trans hv'
  simp only [wet, abs_of_pos (sub_pos.2 (show w < v from hv)),
    abs_of_pos (sub_pos.2 (show w < v' from hv'))]
  have e : ∀ x : ℝ, 0 < x →
      d / x * (n * u * A + n * (x - w) * B) = d * n * B - d * n * (w * B - u * A) / x :=
    fun x hx => by field_simp; ring
  rw [e v hv0, e v' hv0']
  have hk : 0 < d * n * (w * B - u * A) := by have := sub_pos.2 hstrong; positivity
  have : d * n * (w * B - u * A) / v' < d * n * (w * B - u * A) / v :=
    div_lt_div_of_pos_left hk hv0 hvv'
  linarith

/-! ## Sub-model Program (P11): the objects, defined as in the paper

These definitions are textually the same as seat L5's (`Release.lean`), restated here because
this file imports nothing from the project. -/

/-- Parameters of P11: `r, λ, F, Z, κ_pre, κ_post, g₀, Δ`. A perturbation of one primitive is a
record update, so "other primitives fixed" is literal. -/
structure Prm where
  r : ℝ
  lam : ℝ
  F : ℝ
  Z : ℝ
  kpre : ℝ
  kpost : ℝ
  g0 : ℝ
  Δ : ℝ

/-- The old lead `g(t) = g₀e^{−κ_pre t}`. -/
noncomputable def lead (p : Prm) (t : ℝ) : ℝ := p.g0 * exp (-p.kpre * t)

/-- `Π(x) = ∫₀^∞ e^{−rs} ρ(x e^{−κ_post s}) ds`, the Bochner integral over `(0, ∞)`. -/
noncomputable def Pi (ρ : ℝ → ℝ) (r κ x : ℝ) : ℝ :=
  ∫ s in Ioi (0:ℝ), exp (-r * s) * ρ (x * exp (-κ * s))

/-- The release value `J(T) = Π(g(T) + Δ)`. -/
noncomputable def J (ρ : ℝ → ℝ) (p : Prm) (T : ℝ) : ℝ := Pi ρ p.r p.kpost (lead p T + p.Δ)

noncomputable def holdIntegrand (ρ : ℝ → ℝ) (p : Prm) (t : ℝ) : ℝ :=
  exp (-(p.r + p.lam) * t) * (p.F + p.lam * p.Z + ρ (lead p t))

/-- `V(T) = ∫₀^T e^{−(r+λ)t}[F + λZ + ρ(g(t))]dt + e^{−(r+λ)T}J(T)`. -/
noncomputable def V (ρ : ℝ → ℝ) (p : Prm) (T : ℝ) : ℝ :=
  (∫ t in (0:ℝ)..T, holdIntegrand ρ p t) + exp (-(p.r + p.lam) * T) * J ρ p T

/-- `Φ(T) = F + λZ + ρ(g(T)) − (r+λ)J(T) + J′(T)`, with `J′` the derivative of the defined `J`. -/
noncomputable def Phi (ρ : ℝ → ℝ) (p : Prm) (T : ℝ) : ℝ :=
  p.F + p.lam * p.Z + ρ (lead p T) - (p.r + p.lam) * J ρ p T + deriv (J ρ p) T

theorem lead_hasDerivAt (p : Prm) (t : ℝ) :
    HasDerivAt (lead p) (-p.kpre * lead p t) t := by
  have h : HasDerivAt (fun y => p.g0 * exp (-p.kpre * y))
      (p.g0 * (exp (-p.kpre * t) * (-p.kpre * 1))) t :=
    (((hasDerivAt_id t).const_mul (-p.kpre)).exp).const_mul p.g0
  unfold lead
  convert h using 1
  ring

/-- **The comparative-statics step** (as in `Release.comp_statics`). If `T*(θ)` is a
differentiable selection of zeros of `Φ(·, θ)`, `Φ` is jointly differentiable at
`(T*(θ₀), θ₀)` and the crossing is simple and from above (`∂Φ/∂T = a < 0`), then
`dT*/dθ = −(∂Φ/∂θ)/a`. -/
theorem comp_statics {Φ : ℝ → ℝ → ℝ} {Ts : ℝ → ℝ} {θ0 a b d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ => Φ q.1 q.2) (Ts θ0, θ0))
    (ha : HasDerivAt (fun T => Φ T θ0) a (Ts θ0))
    (hb : HasDerivAt (fun θ => Φ (Ts θ0) θ) b θ0)
    (hd : HasDerivAt Ts d θ0)
    (hzero : ∀ᶠ θ in 𝓝 θ0, Φ (Ts θ) θ = 0) (hneg : a < 0) :
    d = -b / a ∧ (0 < d ↔ 0 < b) ∧ (d < 0 ↔ b < 0) := by
  have hL := hΦ.hasFDerivAt
  set L := fderiv ℝ (fun q : ℝ × ℝ => Φ q.1 q.2) (Ts θ0, θ0)
  have h1 : HasDerivAt (fun T => Φ T θ0) (L ((1:ℝ), (0:ℝ))) (Ts θ0) :=
    hL.comp_hasDerivAt (Ts θ0) (f := fun T : ℝ => (T, θ0))
      ((hasDerivAt_id _).prodMk (hasDerivAt_const _ _))
  have h2 : HasDerivAt (fun θ => Φ (Ts θ0) θ) (L ((0:ℝ), (1:ℝ))) θ0 :=
    hL.comp_hasDerivAt θ0 (f := fun θ : ℝ => (Ts θ0, θ))
      ((hasDerivAt_const _ _).prodMk (hasDerivAt_id _))
  have h3 : HasDerivAt (fun θ => Φ (Ts θ) θ) (L (d, (1:ℝ))) θ0 :=
    hL.comp_hasDerivAt θ0 (f := fun θ : ℝ => (Ts θ, θ)) (hd.prodMk (hasDerivAt_id _))
  have ea : L ((1:ℝ), (0:ℝ)) = a := h1.unique ha
  have eb : L ((0:ℝ), (1:ℝ)) = b := h2.unique hb
  have e0 : L (d, (1:ℝ)) = 0 :=
    h3.unique ((hasDerivAt_const θ0 (0:ℝ)).congr_of_eventuallyEq hzero)
  have hlin : L (d, (1:ℝ)) = d * L ((1:ℝ), (0:ℝ)) + L ((0:ℝ), (1:ℝ)) := by
    have : ((d, (1:ℝ)) : ℝ × ℝ) = d • ((1:ℝ), (0:ℝ)) + ((0:ℝ), (1:ℝ)) := by simp
    rw [this, map_add, map_smul, smul_eq_mul]
  rw [ea, eb, e0] at hlin
  have hdv : d = -b / a := by rw [eq_div_iff hneg.ne]; linarith
  have hb' : b = d * (-a) := by linarith
  have hna : 0 < -a := by linarith
  refine ⟨hdv, ⟨fun h => ?_, fun h => ?_⟩, ⟨fun h => ?_, fun h => ?_⟩⟩
  · rw [hb']; positivity
  · by_contra h'; push Not at h'; nlinarith
  · rw [hb']; nlinarith
  · by_contra h'; push Not at h'; nlinarith

/-! ## B158, B162: added flow that raises the hazard (P11(v)'s artifact rule, restated) -/

/-- A flow `x` added to the held flow `F` while the hazard moves to `H x` (a family through `p` when `H 0 = λ`):
`∂Φ/∂x = 1 + H′(0)(Z − J(T))` at every date. `J` and `J′` depend on neither `F` nor `λ`. -/
theorem flow_hazard_partial (ρ : ℝ → ℝ) (p : Prm) (H : ℝ → ℝ) {H' : ℝ}
    (hH : HasDerivAt H H' 0) (T : ℝ) :
    HasDerivAt (fun x => Phi ρ { p with F := p.F + x, lam := H x } T)
      (1 - H' * (J ρ p T - p.Z)) 0 := by
  have e : (fun x => Phi ρ { p with F := p.F + x, lam := H x } T) = fun x =>
      (p.F + ρ (lead p T) - p.r * J ρ p T + deriv (J ρ p) T) + x + H x * (p.Z - J ρ p T) := by
    funext x
    change (p.F + x) + H x * p.Z + ρ (lead p T) - (p.r + H x) * J ρ p T + deriv (J ρ p) T = _
    ring
  rw [e]
  have h := (((hasDerivAt_id (0:ℝ)).const_add
    (p.F + ρ (lead p T) - p.r * J ρ p T + deriv (J ρ p) T)).add (hH.mul_const (p.Z - J ρ p T)))
  convert h using 1
  · funext x; simp
  · ring

/-- **B158, first clause (line 454): a higher theft hazard at fixed `F` brings release sooner
iff `J(T*) > Z`.** The hazard is `λ = λ_rest + λ_θ`; raising the theft term by `x` (flow fixed)
raises `λ` by `x`. At a simple downward crossing, for any differentiable crossing selection,
`dT*/dx < 0 ⇔ Z < J(T*)`. -/
theorem b158_theft_hazard_sooner_iff (ρ : ℝ → ℝ) (p : Prm) {Ts : ℝ → ℝ} {a d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ => Phi ρ { p with lam := p.lam + q.2 } q.1)
      (Ts 0, 0))
    (ha : HasDerivAt (fun T => Phi ρ p T) a (Ts 0))
    (hd : HasDerivAt Ts d 0)
    (hzero : ∀ᶠ x in 𝓝 0, Phi ρ { p with lam := p.lam + x } (Ts x) = 0) (hneg : a < 0) :
    d < 0 ↔ p.Z < J ρ p (Ts 0) := by
  have hp : ({ p with lam := p.lam + 0 } : Prm) = p := by cases p; simp
  have ha' : HasDerivAt (fun T => Phi ρ { p with lam := p.lam + 0 } T) a (Ts 0) := by
    rw [hp]; exact ha
  have hb : HasDerivAt (fun x => Phi ρ { p with lam := p.lam + x } (Ts 0))
      (p.Z - J ρ p (Ts 0)) 0 := by
    have e : (fun x => Phi ρ { p with lam := p.lam + x } (Ts 0)) = fun x =>
        (p.F + ρ (lead p (Ts 0)) - p.r * J ρ p (Ts 0) + deriv (J ρ p) (Ts 0)) +
          (p.lam + x) * (p.Z - J ρ p (Ts 0)) := by
      funext x
      change p.F + (p.lam + x) * p.Z + ρ (lead p (Ts 0)) - (p.r + (p.lam + x)) * J ρ p (Ts 0) +
        deriv (J ρ p) (Ts 0) = _
      ring
    rw [e]
    have h := (((hasDerivAt_id (0:ℝ)).const_add p.lam).mul_const (p.Z - J ρ p (Ts 0))).const_add
      (p.F + ρ (lead p (Ts 0)) - p.r * J ρ p (Ts 0) + deriv (J ρ p) (Ts 0))
    simpa only [id, one_mul] using h
  rw [(comp_statics (Φ := fun T x => Phi ρ { p with lam := p.lam + x } T) hΦ ha' hb hd hzero
    hneg).2.2]
  constructor <;> intro h <;> linarith

/-- **B158, second clause (line 454): a higher `F` with induced theft delays release iff
`λ_θ′(F)[J(T*) − Z] < 1`.** The hazard is `λ = λ_rest + λ_θ(F)` (A.2.3); raising the flow to
`F + x` moves it to `λ_rest + λ_θ(F + x)`. At a simple downward crossing, for any
differentiable crossing selection, `dT*/dx > 0 ⇔ λ_θ′(F)(J(T*) − Z) < 1`. -/
theorem b158_theft_flow_later_iff (ρ : ℝ → ℝ) (p : Prm) (lrest : ℝ) (lθ : ℝ → ℝ) {lθ' : ℝ}
    (hlam : p.lam = lrest + lθ p.F) (hθ : HasDerivAt lθ lθ' p.F) {Ts : ℝ → ℝ} {a d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ =>
      Phi ρ { p with F := p.F + q.2, lam := lrest + lθ (p.F + q.2) } q.1) (Ts 0, 0))
    (ha : HasDerivAt (fun T => Phi ρ p T) a (Ts 0))
    (hd : HasDerivAt Ts d 0)
    (hzero : ∀ᶠ x in 𝓝 0, Phi ρ { p with F := p.F + x, lam := lrest + lθ (p.F + x) } (Ts x) = 0)
    (hneg : a < 0) : 0 < d ↔ lθ' * (J ρ p (Ts 0) - p.Z) < 1 := by
  have hp : ({ p with F := p.F + 0, lam := lrest + lθ (p.F + 0) } : Prm) = p := by
    cases p; simp_all
  have ha' : HasDerivAt (fun T => Phi ρ { p with F := p.F + 0, lam := lrest + lθ (p.F + 0) } T)
      a (Ts 0) := by rw [hp]; exact ha
  have hH : HasDerivAt (fun x => lrest + lθ (p.F + x)) lθ' 0 := by
    have h3 : HasDerivAt lθ lθ' (p.F + 0) := by simpa using hθ
    exact (h3.comp_const_add p.F 0).const_add lrest
  have hb := flow_hazard_partial ρ p (fun x => lrest + lθ (p.F + x)) hH (Ts 0)
  rw [(comp_statics (Φ := fun T x => Phi ρ { p with F := p.F + x, lam := lrest + lθ (p.F + x) } T)
    hΦ ha' hb hd hzero hneg).2.1]
  constructor <;> intro h <;> linarith

/-- **B162 (line 459): contract flow.** Contract flow `f_σ` is part of the held flow `F` and so
ends at release (A.2.1); the hazard is a function `Λ(f_σ)` of it. Raising `f_σ` by `x` adds `x`
to `F` and moves the hazard to `Λ(f_σ + x)`. At a simple downward crossing, for any
differentiable crossing selection, `dT*/dx > 0 ⇔ Λ′(f_σ)(J(T*) − Z) < 1`. -/
theorem b162_contract_later_iff (ρ : ℝ → ℝ) (p : Prm) (fσ : ℝ) (Λ : ℝ → ℝ) {Λ' : ℝ}
    (hlam : p.lam = Λ fσ) (hΛ : HasDerivAt Λ Λ' fσ) {Ts : ℝ → ℝ} {a d : ℝ}
    (hΦ : DifferentiableAt ℝ (fun q : ℝ × ℝ =>
      Phi ρ { p with F := p.F + q.2, lam := Λ (fσ + q.2) } q.1) (Ts 0, 0))
    (ha : HasDerivAt (fun T => Phi ρ p T) a (Ts 0))
    (hd : HasDerivAt Ts d 0)
    (hzero : ∀ᶠ x in 𝓝 0, Phi ρ { p with F := p.F + x, lam := Λ (fσ + x) } (Ts x) = 0)
    (hneg : a < 0) : 0 < d ↔ Λ' * (J ρ p (Ts 0) - p.Z) < 1 := by
  have hp : ({ p with F := p.F + 0, lam := Λ (fσ + 0) } : Prm) = p := by cases p; simp_all
  have ha' : HasDerivAt (fun T => Phi ρ { p with F := p.F + 0, lam := Λ (fσ + 0) } T) a (Ts 0) := by
    rw [hp]; exact ha
  have hH : HasDerivAt (fun x => Λ (fσ + x)) Λ' 0 := by
    have h3 : HasDerivAt Λ Λ' (fσ + 0) := by simpa using hΛ
    exact h3.comp_const_add fσ 0
  have hb := flow_hazard_partial ρ p (fun x => Λ (fσ + x)) hH (Ts 0)
  rw [(comp_statics (Φ := fun T x => Phi ρ { p with F := p.F + x, lam := Λ (fσ + x) } T)
    hΦ ha' hb hd hzero hneg).2.1]
  constructor <;> intro h <;> linarith

/-! ## A96: with one copy rate for both phases, the sign of `dT*/dκ` is not determined

Square-root rents `ρ(x) = √x` (power rents with `M = 1`, `η = 1/2`, A.6's family). -/

theorem sqrt_exp_half (y : ℝ) : √(exp y) = exp (y / 2) := by
  rw [show exp y = exp (y / 2) ^ 2 by rw [← exp_nat_mul]; ring_nf]
  exact Real.sqrt_sq (exp_pos _).le

/-- `Π` for `ρ = √x`, computed from its integral: `Π(x) = √x/(r + κ_post/2)`. -/
theorem Pi_sqrt {r κ x : ℝ} (hc : 0 < r + κ / 2) (hx : 0 ≤ x) :
    Pi Real.sqrt r κ x = √x / (r + κ / 2) := by
  unfold Pi
  have e : ∀ s : ℝ, exp (-r * s) * √(x * exp (-κ * s)) = √x * exp (-(r + κ / 2) * s) := by
    intro s
    rw [Real.sqrt_mul hx, sqrt_exp_half, mul_left_comm, ← exp_add]; ring_nf
  simp_rw [e]
  rw [MeasureTheory.integral_const_mul, integral_exp_mul_Ioi (by linarith) 0]
  simp only [mul_zero, exp_zero]
  field_simp

theorem lead_nonneg (p : Prm) (hg : 0 ≤ p.g0) (t : ℝ) : 0 ≤ lead p t :=
  mul_nonneg hg (exp_pos _).le

theorem J_sqrt (p : Prm) (hc : 0 < p.r + p.kpost / 2) (hg : 0 ≤ p.g0) (hΔ : 0 ≤ p.Δ) :
    J Real.sqrt p = fun T => √(lead p T + p.Δ) / (p.r + p.kpost / 2) := by
  funext T
  exact Pi_sqrt hc (by have := lead_nonneg p hg T; linarith)

theorem J_sqrt_hasDerivAt (p : Prm) (hc : 0 < p.r + p.kpost / 2) (hg : 0 ≤ p.g0)
    (hΔ : 0 < p.Δ) (T : ℝ) :
    HasDerivAt (J Real.sqrt p)
      (-p.kpre * lead p T / (2 * √(lead p T + p.Δ)) / (p.r + p.kpost / 2)) T := by
  rw [J_sqrt p hc hg hΔ.le]
  have hx : lead p T + p.Δ ≠ 0 := by have := lead_nonneg p hg T; linarith
  exact (((lead_hasDerivAt p T).add_const p.Δ).sqrt hx).div_const _

/-- `Φ` for `ρ = √x` through the lead `g = g(T)`, with `x = g + Δ`, `c = r + κ_post/2`:
`Φ = F + λZ + √g − (r+λ)√x/c − κ_pre g/(2c√x)`. -/
theorem Phi_sqrt (p : Prm) (hc : 0 < p.r + p.kpost / 2) (hg : 0 ≤ p.g0) (hΔ : 0 < p.Δ)
    (T : ℝ) :
    Phi Real.sqrt p T = p.F + p.lam * p.Z + √(lead p T) -
      (p.r + p.lam) * √(lead p T + p.Δ) / (p.r + p.kpost / 2) -
      p.kpre * lead p T / (2 * (p.r + p.kpost / 2) * √(lead p T + p.Δ)) := by
  unfold Phi
  rw [(J_sqrt_hasDerivAt p hc hg hΔ T).deriv, J_sqrt p hc hg hΔ.le]
  have hs : 0 < √(lead p T + p.Δ) := Real.sqrt_pos.2 (by have := lead_nonneg p hg T; linarith)
  field_simp
  ring

theorem holdIntegrand_sqrt_continuous (p : Prm) : Continuous (holdIntegrand Real.sqrt p) := by
  unfold holdIntegrand lead
  exact (continuous_exp.comp (continuous_const.mul continuous_id)).mul
    (continuous_const.add (Real.continuous_sqrt.comp
      (continuous_const.mul (continuous_exp.comp (continuous_const.mul continuous_id)))))

/-- **`V′ = e^{−(r+λ)T}Φ(T)`** for `ρ = √x`, at every date, for the defined `V` and `Φ`. -/
theorem V_sqrt_hasDerivAt (p : Prm) (hc : 0 < p.r + p.kpost / 2) (hg : 0 ≤ p.g0)
    (hΔ : 0 < p.Δ) (T : ℝ) :
    HasDerivAt (V Real.sqrt p) (exp (-(p.r + p.lam) * T) * Phi Real.sqrt p T) T := by
  have hcont := holdIntegrand_sqrt_continuous p
  have h1 := intervalIntegral.integral_hasDerivAt_right (a := 0) (b := T)
    (hcont.intervalIntegrable _ _) (hcont.stronglyMeasurableAtFilter _ _) hcont.continuousAt
  have hJ := J_sqrt_hasDerivAt p hc hg hΔ T
  have h2 : HasDerivAt (fun T => exp (-(p.r + p.lam) * T))
      (exp (-(p.r + p.lam) * T) * (-(p.r + p.lam))) T := by
    have := ((hasDerivAt_id T).const_mul (-(p.r + p.lam))).exp
    simpa [mul_comm] using this
  have h := h1.add (h2.mul hJ)
  unfold V
  refine h.congr_deriv ?_
  unfold Phi holdIntegrand
  rw [hJ.deriv]
  ring

/-- **P11(i) for `ρ = √x`: a single crossing from above gives the strict global optimum** on
`[0, ∞)`, from the sign of `V′ = e^{−(r+λ)T}Φ`. -/
theorem V_sqrt_strict_max (p : Prm) (hc : 0 < p.r + p.kpost / 2) (hg : 0 ≤ p.g0)
    (hΔ : 0 < p.Δ) {Ts : ℝ} (hTs : 0 < Ts)
    (hpos : ∀ T, 0 < T → T < Ts → 0 < Phi Real.sqrt p T)
    (hneg : ∀ T, Ts < T → Phi Real.sqrt p T < 0) :
    ∀ T, 0 ≤ T → T ≠ Ts → V Real.sqrt p T < V Real.sqrt p Ts := by
  have hd := V_sqrt_hasDerivAt p hc hg hΔ
  have hcont : Continuous (V Real.sqrt p) :=
    continuous_iff_continuousAt.2 fun T => (hd T).continuousAt
  have hup : StrictMonoOn (V Real.sqrt p) (Icc 0 Ts) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc 0 Ts) hcont.continuousOn
    intro x hx; rw [interior_Icc] at hx
    rw [(hd x).deriv]; exact mul_pos (exp_pos _) (hpos x hx.1 hx.2)
  have hdown : StrictAntiOn (V Real.sqrt p) (Ici Ts) := by
    apply strictAntiOn_of_deriv_neg (convex_Ici Ts) hcont.continuousOn
    intro x hx; rw [interior_Ici] at hx
    rw [(hd x).deriv]; exact mul_neg_of_pos_of_neg (exp_pos _) (hneg x hx)
  intro T hT hne
  rcases lt_or_gt_of_ne hne with h | h
  · exact hup ⟨hT, h.le⟩ ⟨hTs.le, le_rfl⟩ h
  · exact hdown (le_refl Ts) h.le h

/-- The examples: `ρ = √x`, `r = 1/20`, `λ = 1/100`, `κ_pre = κ_post = 1`, `Δ = 80`,
`F = 41/495`, `Z = 0`, and starting lead `g₀`. `F` is chosen so that the crossing lead is
`g* = 1` (A.6's own grid fixes `F` by a selection rule in the same way). -/
noncomputable def p96 (g0 : ℝ) : Prm :=
  { r := 1/20, lam := 1/100, F := 41/495, Z := 0, kpre := 1, kpost := 1, g0 := g0, Δ := 80 }

/-- The lead function of `Φ` in the examples: `Φ(T) = φ₉₆(g(T))`. -/
noncomputable def φ96 (g : ℝ) : ℝ := 41/495 + √g - 6/55 * √(g + 80) - 10/11 * (g / √(g + 80))

noncomputable def φ96' (g : ℝ) : ℝ :=
  1 / (2 * √g) - 6/55 * (1 / (2 * √(g + 80))) -
    10/11 * ((1 * √(g + 80) - g * (1 / (2 * √(g + 80)))) / √(g + 80) ^ 2)

theorem p96_Phi (g0 : ℝ) (hg : 0 ≤ g0) (T : ℝ) :
    Phi Real.sqrt (p96 g0) T = φ96 (lead (p96 g0) T) := by
  rw [Phi_sqrt (p96 g0) (by norm_num [p96]) hg (by norm_num [p96])]
  have hs : 0 < √(lead (p96 g0) T + 80) :=
    Real.sqrt_pos.2 (by have := lead_nonneg (p96 g0) hg T; linarith)
  simp only [φ96, show (p96 g0).F = 41/495 from rfl, show (p96 g0).lam = 1/100 from rfl,
    show (p96 g0).Z = 0 from rfl, show (p96 g0).r = 1/20 from rfl,
    show (p96 g0).kpost = 1 from rfl, show (p96 g0).kpre = 1 from rfl,
    show (p96 g0).Δ = 80 from rfl]
  field_simp
  ring

theorem φ96_hasDerivAt {g : ℝ} (hg : 0 < g) : HasDerivAt φ96 (φ96' g) g := by
  have h1 : HasDerivAt (fun y => √y) (1 / (2 * √g)) g := Real.hasDerivAt_sqrt hg.ne'
  have hx : HasDerivAt (fun y => y + 80) 1 g := (hasDerivAt_id g).add_const 80
  have h2 : HasDerivAt (fun y => √(y + 80)) (1 / (2 * √(g + 80))) g := by
    have := hx.sqrt (by linarith); simpa using this
  have h4 := (hasDerivAt_id g).div h2 (Real.sqrt_pos.2 (by linarith)).ne'
  exact ((h1.const_add (41/495)).sub (h2.const_mul (6/55))).sub (h4.const_mul (10/11))

theorem φ96'_pos {g : ℝ} (hg : 0 < g) (hg16 : g < 16) : 0 < φ96' g := by
  have hs : 0 < √g := Real.sqrt_pos.2 hg
  have hs4 : √g < 4 := by
    rw [show (4:ℝ) = √16 by rw [show (16:ℝ) = 4 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]]
    exact Real.sqrt_lt_sqrt hg.le hg16
  set w := √(g + 80) with hw
  have hw2 : w ^ 2 = g + 80 := Real.sq_sqrt (by linarith)
  have hw0 : 0 < w := Real.sqrt_pos.2 (by linarith)
  have hw1 : 424 / 55 < w := by nlinarith
  have key : φ96' g = 1 / (2 * √g) - (3 / 55 * (g + 80) + 5 / 11 * (g + 160)) / ((g + 80) * w) := by
    simp only [φ96', ← hw]
    field_simp
    rw [show g = w ^ 2 - 80 by linarith]
    ring
  rw [key, sub_pos, div_lt_div_iff₀ (by positivity) (by positivity)]
  nlinarith [mul_lt_mul_of_pos_left hs4 (show 0 < 3 / 55 * (g + 80) + 5 / 11 * (g + 160) by
    positivity), mul_lt_mul_of_pos_left hw1 (show 0 < g + 80 by linarith)]

theorem φ96_cont : ContinuousOn φ96 (Icc 0 16) := by
  unfold φ96
  apply ContinuousOn.sub (by fun_prop)
  apply ContinuousOn.mul continuousOn_const
  apply ContinuousOn.div (by fun_prop) (by fun_prop)
  intro x hx; exact (Real.sqrt_pos.2 (by linarith [hx.1])).ne'

theorem φ96_strictMono : StrictMonoOn φ96 (Icc 0 16) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc 0 16) φ96_cont
  intro x hx; rw [interior_Icc] at hx
  rw [(φ96_hasDerivAt hx.1).deriv]; exact φ96'_pos hx.1 hx.2

theorem φ96_one : φ96 1 = 0 := by
  have h81 : √(1 + 80 : ℝ) = 9 := by
    rw [show (1 + 80 : ℝ) = 9 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  simp only [φ96, Real.sqrt_one, h81]; norm_num

theorem φ96'_one : φ96' 1 = 31559 / 80190 := by
  have h81 : √(1 + 80 : ℝ) = 9 := by
    rw [show (1 + 80 : ℝ) = 9 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  simp only [φ96', Real.sqrt_one, h81]; norm_num

theorem lead_p96 (g0 T : ℝ) : lead (p96 g0) T = g0 * exp (-T) := by
  simp [lead, p96]

theorem lead_p96_log {g0 : ℝ} (hg : 0 < g0) : lead (p96 g0) (Real.log g0) = 1 := by
  rw [lead_p96, exp_neg, exp_log hg]; field_simp

/-- **The crossing in the examples** (`1 < g₀ ≤ 16`): `Φ` crosses zero exactly once, from
above, at `T* = ln g₀`, and the crossing is simple: `∂Φ/∂T(T*) = −31559/80190 < 0`. -/
theorem p96_crossing {g0 : ℝ} (hg1 : 1 < g0) (hg16 : g0 ≤ 16) :
    0 < Real.log g0 ∧ Phi Real.sqrt (p96 g0) (Real.log g0) = 0 ∧
    (∀ T, 0 ≤ T → T < Real.log g0 → 0 < Phi Real.sqrt (p96 g0) T) ∧
    (∀ T, Real.log g0 < T → Phi Real.sqrt (p96 g0) T < 0) ∧
    HasDerivAt (fun T => Phi Real.sqrt (p96 g0) T) (-(31559 / 80190)) (Real.log g0) := by
  have hg0 : 0 < g0 := by linarith
  have hmem : ∀ T, 0 ≤ T → lead (p96 g0) T ∈ Icc (0:ℝ) 16 := fun T hT => by
    rw [lead_p96]
    have h1 : exp (-T) ≤ 1 := exp_le_one_iff.2 (by linarith)
    have h2 := exp_pos (-T)
    constructor <;> nlinarith
  have hanti : ∀ T T', T < T' → lead (p96 g0) T' < lead (p96 g0) T := fun T T' h => by
    rw [lead_p96, lead_p96]
    exact mul_lt_mul_of_pos_left (exp_lt_exp.2 (by linarith)) hg0
  have h1m : (1:ℝ) ∈ Icc (0:ℝ) 16 := ⟨by norm_num, by norm_num⟩
  have hL := lead_p96_log hg0
  refine ⟨Real.log_pos hg1, ?_, fun T hT hlt => ?_, fun T hlt => ?_, ?_⟩
  · rw [p96_Phi g0 hg0.le, hL, φ96_one]
  · rw [p96_Phi g0 hg0.le, ← φ96_one]
    have := hanti T _ hlt; rw [hL] at this
    exact φ96_strictMono h1m (hmem T hT) this
  · rw [p96_Phi g0 hg0.le, ← φ96_one]
    have := hanti _ T hlt; rw [hL] at this
    have hT : 0 ≤ T := by linarith [Real.log_pos hg1]
    exact φ96_strictMono (hmem T hT) h1m this
  · have hf : (fun T => Phi Real.sqrt (p96 g0) T) = fun T => φ96 (lead (p96 g0) T) :=
      funext (p96_Phi g0 hg0.le)
    rw [hf]
    have hd : HasDerivAt φ96 (φ96' 1) (lead (p96 g0) (Real.log g0)) := by
      rw [hL]; exact φ96_hasDerivAt one_pos
    have := hd.comp (Real.log g0) (lead_hasDerivAt (p96 g0) (Real.log g0))
    rw [hL, φ96'_one] at this
    convert this using 1
    · rfl
    · simp [p96]

/-- **The examples' optimum**: `T* = ln g₀` is the strict global optimum of the defined `V`
on `[0, ∞)`. -/
theorem p96_optimum {g0 : ℝ} (hg1 : 1 < g0) (hg16 : g0 ≤ 16) :
    ∀ T, 0 ≤ T → T ≠ Real.log g0 → V Real.sqrt (p96 g0) T < V Real.sqrt (p96 g0) (Real.log g0) := by
  obtain ⟨h0, -, hpos, hneg, -⟩ := p96_crossing hg1 hg16
  exact V_sqrt_strict_max (p96 g0) (by norm_num [p96]) (by norm_num [p96]; linarith)
    (by norm_num [p96]) h0 (fun T hT hlt => hpos T hT.le hlt) hneg

/-- The common-rate family: `κ_pre = κ_post = k`, every other primitive fixed. -/
noncomputable def pk (g0 k : ℝ) : Prm := { p96 g0 with kpre := k, kpost := k }

/-- `Φ` of the common-rate family in closed form (valid for `1/20 + k/2 > 0`). -/
noncomputable def ΨK (g0 T k : ℝ) : ℝ :=
  41/495 + 1/100 * 0 + √(g0 * exp (-k * T)) -
    (1/20 + 1/100) * √(g0 * exp (-k * T) + 80) / (1/20 + k / 2) -
    k * (g0 * exp (-k * T)) / (2 * (1/20 + k / 2) * √(g0 * exp (-k * T) + 80))

theorem pk_Phi {g0 k : ℝ} (hg : 0 ≤ g0) (hk : -1/10 < k) (T : ℝ) :
    Phi Real.sqrt (pk g0 k) T = ΨK g0 T k := by
  rw [Phi_sqrt (pk g0 k) (by simp only [pk, p96]; linarith) hg (by norm_num [pk, p96])]
  rfl

theorem pk_one (g0 : ℝ) : pk g0 1 = p96 g0 := rfl

/-- **`∂Φ/∂κ` at a common rate**, at the examples' crossing `T* = ln g₀`, `κ = 1`:
`962/1089 − (31559/80190)·ln g₀`. Derivative of the defined `Φ` along the record update
`κ_pre = κ_post = k`. -/
theorem pk_kappa_partial {g0 : ℝ} (hg : 0 < g0) :
    HasDerivAt (fun k => Phi Real.sqrt (pk g0 k) (Real.log g0))
      (962 / 1089 - 31559 / 80190 * Real.log g0) 1 := by
  set T := Real.log g0 with hT
  set G : ℝ → ℝ := fun k => g0 * exp (-k * T) with hGdef
  have hG1 : G 1 = 1 := by
    simp only [hGdef, hT, neg_mul, one_mul, exp_neg, exp_log hg]; field_simp
  have hG1' : g0 * exp (-1 * T) = 1 := hG1
  have hlin : HasDerivAt (fun k : ℝ => -k * T) (-T) 1 := by
    have h := (hasDerivAt_id (1:ℝ)).mul_const (-T)
    simp only [id, one_mul] at h
    exact h.congr_of_eventuallyEq (Eventually.of_forall fun k => by ring)
  have hG : HasDerivAt G (-T) 1 := by
    have h := hlin.exp.const_mul g0
    convert h using 1
    rw [← mul_assoc, hG1']; ring
  have h81 : √(G 1 + 80) = 9 := by
    rw [hG1, show (1 + 80 : ℝ) = 9 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  have hs1 : √(G 1) = 1 := by rw [hG1, Real.sqrt_one]
  have hc : HasDerivAt (fun k : ℝ => 1/20 + k / 2) (1 / 2) 1 := by
    simpa using ((hasDerivAt_id (1:ℝ)).div_const 2).const_add (1/20)
  have hA : HasDerivAt (fun k => √(G k)) (-T / (2 * √(G 1))) 1 :=
    hG.sqrt (by rw [hG1]; norm_num)
  have hB : HasDerivAt (fun k => √(G k + 80)) (-T / (2 * √(G 1 + 80))) 1 := by
    have := (hG.add_const 80).sqrt (by rw [hG1]; norm_num); simpa using this
  have hB' := (hB.const_mul (1/20 + 1/100)).div hc (by norm_num)
  have hC := (hasDerivAt_id (1:ℝ)).mul hG
  have hD := (hc.const_mul 2).mul hB
  have hCD := hC.div hD (by simp only [Pi.mul_apply]; rw [h81]; norm_num)
  have htot := ((hA.const_add (41/495 + 1/100 * 0)).sub hB').sub hCD
  have heq : (fun k => Phi Real.sqrt (pk g0 k) T) =ᶠ[𝓝 1] fun k => ΨK g0 T k := by
    filter_upwards [Ioi_mem_nhds (show (-1/10 : ℝ) < 1 by norm_num)] with k hk
    exact pk_Phi hg.le hk T
  refine (HasDerivAt.congr_of_eventuallyEq ?_ heq)
  convert htot using 1
  · rfl
  · simp only [Pi.mul_apply, id, hG1]; ring

/-- **Joint differentiability** of `(T, k) ↦ Φ` at the examples' crossing `(ln g₀, 1)`. -/
theorem pk_joint_diff {g0 : ℝ} (hg : 0 < g0) :
    DifferentiableAt ℝ (fun q : ℝ × ℝ => Phi Real.sqrt (pk g0 q.2) q.1) (Real.log g0, 1) := by
  have heq : (fun q : ℝ × ℝ => Phi Real.sqrt (pk g0 q.2) q.1) =ᶠ[𝓝 (Real.log g0, 1)]
      fun q => ΨK g0 q.1 q.2 := by
    have : {q : ℝ × ℝ | -1/10 < q.2} ∈ 𝓝 (Real.log g0, (1:ℝ)) :=
      (isOpen_lt continuous_const continuous_snd).mem_nhds (by norm_num)
    filter_upwards [this] with q hq
    exact pk_Phi hg.le hq q.1
  refine DifferentiableAt.congr_of_eventuallyEq ?_ heq
  have hG1 : g0 * exp (-(1:ℝ) * Real.log g0) = 1 := by
    rw [neg_mul, one_mul, exp_neg, exp_log hg]; field_simp
  have hG : DifferentiableAt ℝ (fun q : ℝ × ℝ => g0 * exp (-q.2 * q.1)) (Real.log g0, 1) := by
    fun_prop
  have hGpos : g0 * exp (-(Real.log g0, (1:ℝ)).2 * (Real.log g0, (1:ℝ)).1) ≠ 0 := by
    simp only; rw [hG1]; norm_num
  have hG80 : g0 * exp (-(Real.log g0, (1:ℝ)).2 * (Real.log g0, (1:ℝ)).1) + 80 ≠ 0 := by
    simp only; rw [hG1]; norm_num
  have hc : DifferentiableAt ℝ (fun q : ℝ × ℝ => 1/20 + q.2 / 2) (Real.log g0, 1) := by fun_prop
  have hsA := hG.sqrt hGpos
  have hsB := (hG.add_const 80).sqrt hG80
  have hsB80 : √(g0 * exp (-(1:ℝ) * Real.log g0) + 80) = 9 := by
    rw [hG1, show (1 + 80 : ℝ) = 9 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  have hform : (fun q : ℝ × ℝ => ΨK g0 q.1 q.2) = fun q =>
      41/495 + 1/100 * 0 + √(g0 * exp (-q.2 * q.1)) -
        (1/20 + 1/100) * √(g0 * exp (-q.2 * q.1) + 80) * (1/20 + q.2 / 2)⁻¹ -
        q.2 * (g0 * exp (-q.2 * q.1)) *
          (2 * (1/20 + q.2 / 2) * √(g0 * exp (-q.2 * q.1) + 80))⁻¹ := by
    funext q; simp only [ΨK, div_eq_mul_inv]
  rw [hform]
  have hi1 : DifferentiableAt ℝ (fun q : ℝ × ℝ => (1/20 + q.2 / 2)⁻¹) (Real.log g0, 1) :=
    hc.inv (by norm_num)
  have hD : DifferentiableAt ℝ
      (fun q : ℝ × ℝ => 2 * (1/20 + q.2 / 2) * √(g0 * exp (-q.2 * q.1) + 80)) (Real.log g0, 1) :=
    (hc.const_mul 2).mul hsB
  have hi2 : DifferentiableAt ℝ
      (fun q : ℝ × ℝ => (2 * (1/20 + q.2 / 2) * √(g0 * exp (-q.2 * q.1) + 80))⁻¹)
      (Real.log g0, 1) := hD.inv (by simp only; rw [hsB80]; norm_num)
  exact (((differentiableAt_const (41/495 + 1/100 * 0 : ℝ)).add hsA).sub
    ((hsB.const_mul (1/20 + 1/100)).mul hi1)).sub ((differentiableAt_snd.mul hG).mul hi2)

/-- **Selection-free local comparative statics.** If `Φ` is differentiable at `(T₀, θ₀)` with
`Φ(T₀, θ₀) = 0`, `∂Φ/∂T = a < 0` (a simple crossing from above) and `∂Φ/∂θ = b ≠ 0`, then near
`(T₀, θ₀)`: when `b(θ − θ₀) > 0`, `Φ(T, θ) > 0` for every `T ≤ T₀`; when `b(θ − θ₀) < 0`,
`Φ(T, θ) < 0` for every `T ≥ T₀`. So every nearby zero of `Φ(·, θ)` moves later in the first
case and earlier in the second; no implicit-function theorem or crossing selection is used. -/
theorem zero_displacement {Φ : ℝ × ℝ → ℝ} {T0 θ0 a b : ℝ} (hΦ : DifferentiableAt ℝ Φ (T0, θ0))
    (h0 : Φ (T0, θ0) = 0) (ha : HasDerivAt (fun T => Φ (T, θ0)) a T0)
    (hb : HasDerivAt (fun θ => Φ (T0, θ)) b θ0) (ha0 : a < 0) (hb0 : b ≠ 0) :
    ∃ ε > 0, ∀ T θ, |T - T0| < ε → |θ - θ0| < ε →
      (0 < b * (θ - θ0) → T ≤ T0 → 0 < Φ (T, θ)) ∧
      (b * (θ - θ0) < 0 → T0 ≤ T → Φ (T, θ) < 0) := by
  have hL := hΦ.hasFDerivAt
  set L := fderiv ℝ Φ (T0, θ0)
  have e1 : L ((1:ℝ), (0:ℝ)) = a :=
    (hL.comp_hasDerivAt T0 (f := fun T : ℝ => (T, θ0))
      ((hasDerivAt_id _).prodMk (hasDerivAt_const _ _))).unique ha
  have e2 : L ((0:ℝ), (1:ℝ)) = b :=
    (hL.comp_hasDerivAt θ0 (f := fun θ : ℝ => (T0, θ))
      ((hasDerivAt_const _ _).prodMk (hasDerivAt_id _))).unique hb
  have hlin : ∀ x y : ℝ, L (x, y) = x * a + y * b := by
    intro x y
    have : ((x, y) : ℝ × ℝ) = x • ((1:ℝ), (0:ℝ)) + y • ((0:ℝ), (1:ℝ)) := by simp
    rw [this, map_add, map_smul, map_smul, smul_eq_mul, smul_eq_mul, e1, e2]
  set c := min (-a) |b| / 2 with hcdef
  have hb' : 0 < |b| := abs_pos.2 hb0
  have hc : 0 < c := by
    have : 0 < min (-a) |b| := lt_min (by linarith) hb'
    rw [hcdef]; positivity
  have hca : 2 * c ≤ -a := by have := min_le_left (-a) |b|; rw [hcdef]; linarith
  have hcb : 2 * c ≤ |b| := by have := min_le_right (-a) |b|; rw [hcdef]; linarith
  have hlo := hL.isLittleO.def hc
  obtain ⟨ε, hε, hball⟩ := Metric.eventually_nhds_iff.1 hlo
  refine ⟨ε, hε, fun T θ hT hθ => ?_⟩
  have hdist : dist (T, θ) (T0, θ0) < ε := by
    rw [Prod.dist_eq, Real.dist_eq, Real.dist_eq]; exact max_lt hT hθ
  have hbd := hball hdist
  simp only [Prod.mk_sub_mk, h0, sub_zero, hlin, Prod.norm_def, Real.norm_eq_abs] at hbd
  have hm1 : |T - T0| ≤ max |T - T0| |θ - θ0| := le_max_left _ _
  have hm2 : |θ - θ0| ≤ max |T - T0| |θ - θ0| := le_max_right _ _
  have hmsum : max |T - T0| |θ - θ0| ≤ |T - T0| + |θ - θ0| :=
    max_le (by linarith [abs_nonneg (θ - θ0)]) (by linarith [abs_nonneg (T - T0)])
  have habs := abs_le.1 hbd
  constructor
  · intro hpos hle
    have hTa : (T - T0) * a = (-a) * |T - T0| := by
      rw [abs_of_nonpos (by linarith)]; ring
    have hθb : (θ - θ0) * b = |b| * |θ - θ0| := by
      rw [← abs_mul, abs_of_pos (by linarith)]; ring
    have hθ0 : 0 < |θ - θ0| := by
      rcases (abs_nonneg (θ - θ0)).eq_or_lt with h | h
      · exfalso; rw [eq_comm, abs_eq_zero] at h; rw [h, mul_zero] at hpos; exact lt_irrefl _ hpos
      · exact h
    nlinarith [mul_le_mul_of_nonneg_right hca (abs_nonneg (T - T0)),
      mul_le_mul_of_nonneg_right hcb (abs_nonneg (θ - θ0))]
  · intro hneg hle
    have hTa : (T - T0) * a = -((-a) * |T - T0|) := by
      rw [abs_of_nonneg (by linarith)]; ring
    have hθb : (θ - θ0) * b = -(|b| * |θ - θ0|) := by
      rw [← abs_mul, abs_of_neg (by linarith)]; ring
    have hθ0 : 0 < |θ - θ0| := by
      rcases (abs_nonneg (θ - θ0)).eq_or_lt with h | h
      · exfalso; rw [eq_comm, abs_eq_zero] at h; rw [h, mul_zero] at hneg; exact lt_irrefl _ hneg
      · exact h
    nlinarith [mul_le_mul_of_nonneg_right hca (abs_nonneg (T - T0)),
      mul_le_mul_of_nonneg_right hcb (abs_nonneg (θ - θ0))]

/-- **A96 (line 987): with one copy rate for both phases the net sign of `dT*/dκ` is not
determined.** Two exact examples share every primitive (`ρ = √x`, `r = 1/20`, `λ = 1/100`,
`κ_pre = κ_post = 1`, `Δ = 80`, `F = 41/495`, `Z = 0`) except the starting lead `g₀`. In each,
`Φ` crosses zero once, from above, simply, at `T* = ln g₀`, the strict global optimum of `V`.
At `g₀ = 4`, `∂Φ/∂κ > 0`: every nearby crossing moves later when the common rate rises, and any
differentiable crossing selection has `dT*/dκ > 0`. At `g₀ = 16`, `∂Φ/∂κ < 0` and the release
moves earlier, `dT*/dκ < 0`. -/
theorem a96_common_kappa_either_sign :
    ((∀ T, 0 ≤ T → T ≠ Real.log 4 →
        V Real.sqrt (pk 4 1) T < V Real.sqrt (pk 4 1) (Real.log 4)) ∧
      Phi Real.sqrt (pk 4 1) (Real.log 4) = 0 ∧
      HasDerivAt (fun T => Phi Real.sqrt (pk 4 1) T) (-(31559 / 80190)) (Real.log 4) ∧
      (∃ b > 0, HasDerivAt (fun k => Phi Real.sqrt (pk 4 k) (Real.log 4)) b 1) ∧
      (∃ ε > 0, ∀ T k, |T - Real.log 4| < ε → |k - 1| < ε →
        Phi Real.sqrt (pk 4 k) T = 0 → (1 < k → Real.log 4 < T) ∧ (k < 1 → T < Real.log 4)) ∧
      ∀ (Tsel : ℝ → ℝ) (d : ℝ), Tsel 1 = Real.log 4 → HasDerivAt Tsel d 1 →
        (∀ᶠ k in 𝓝 1, Phi Real.sqrt (pk 4 k) (Tsel k) = 0) → 0 < d) ∧
    ((∀ T, 0 ≤ T → T ≠ Real.log 16 →
        V Real.sqrt (pk 16 1) T < V Real.sqrt (pk 16 1) (Real.log 16)) ∧
      Phi Real.sqrt (pk 16 1) (Real.log 16) = 0 ∧
      HasDerivAt (fun T => Phi Real.sqrt (pk 16 1) T) (-(31559 / 80190)) (Real.log 16) ∧
      (∃ b < 0, HasDerivAt (fun k => Phi Real.sqrt (pk 16 k) (Real.log 16)) b 1) ∧
      (∃ ε > 0, ∀ T k, |T - Real.log 16| < ε → |k - 1| < ε →
        Phi Real.sqrt (pk 16 k) T = 0 → (1 < k → T < Real.log 16) ∧ (k < 1 → Real.log 16 < T)) ∧
      ∀ (Tsel : ℝ → ℝ) (d : ℝ), Tsel 1 = Real.log 16 → HasDerivAt Tsel d 1 →
        (∀ᶠ k in 𝓝 1, Phi Real.sqrt (pk 16 k) (Tsel k) = 0) → d < 0) := by
  have l2 := Real.log_two_gt_d9
  have l2' := Real.log_two_lt_d9
  have h4 : Real.log 4 = 2 * Real.log 2 := by
    rw [show (4:ℝ) = 2 ^ 2 by norm_num, Real.log_pow]; norm_num
  have h16 : Real.log 16 = 4 * Real.log 2 := by
    rw [show (16:ℝ) = 2 ^ 4 by norm_num, Real.log_pow]; norm_num
  have bpos : 0 < 962 / 1089 - 31559 / 80190 * Real.log 4 := by rw [h4]; nlinarith
  have bneg : 962 / 1089 - 31559 / 80190 * Real.log 16 < 0 := by rw [h16]; nlinarith
  constructor
  · obtain ⟨-, hz, -, -, ha⟩ := p96_crossing (g0 := 4) (by norm_num) (by norm_num)
    have hb := pk_kappa_partial (g0 := 4) (by norm_num)
    have hΦ := pk_joint_diff (g0 := 4) (by norm_num)
    rw [← pk_one] at hz ha
    obtain ⟨ε, hε, hdisp⟩ := zero_displacement
      (Φ := fun q : ℝ × ℝ => Phi Real.sqrt (pk 4 q.2) q.1) hΦ hz ha hb (by norm_num) bpos.ne'
    refine ⟨by rw [pk_one]; exact p96_optimum (by norm_num) (by norm_num), hz, ha,
      ⟨_, bpos, hb⟩, ⟨ε, hε, fun T k hT hk hzero => ⟨fun h1 => ?_, fun h1 => ?_⟩⟩,
      fun Tsel d hsel hd hzero => ?_⟩
    · by_contra hc; push Not at hc
      have := (hdisp T k hT hk).1 (by nlinarith) hc; simp only at this; linarith
    · by_contra hc; push Not at hc
      have := (hdisp T k hT hk).2 (by nlinarith) hc; simp only at this; linarith
    · have ha' : HasDerivAt (fun T => Phi Real.sqrt (pk 4 1) T) (-(31559 / 80190)) (Tsel 1) := by
        rw [hsel]; exact ha
      have hb' : HasDerivAt (fun k => Phi Real.sqrt (pk 4 k) (Tsel 1))
          (962 / 1089 - 31559 / 80190 * Real.log 4) 1 := by rw [hsel]; exact hb
      have hΦ' : DifferentiableAt ℝ (fun q : ℝ × ℝ => Phi Real.sqrt (pk 4 q.2) q.1)
          (Tsel 1, 1) := by rw [hsel]; exact hΦ
      exact ((comp_statics (Φ := fun T k => Phi Real.sqrt (pk 4 k) T) hΦ' ha' hb' hd hzero
        (by norm_num)).2.1).2 bpos
  · obtain ⟨-, hz, -, -, ha⟩ := p96_crossing (g0 := 16) (by norm_num) (by norm_num)
    have hb := pk_kappa_partial (g0 := 16) (by norm_num)
    have hΦ := pk_joint_diff (g0 := 16) (by norm_num)
    rw [← pk_one] at hz ha
    obtain ⟨ε, hε, hdisp⟩ := zero_displacement
      (Φ := fun q : ℝ × ℝ => Phi Real.sqrt (pk 16 q.2) q.1) hΦ hz ha hb (by norm_num) bneg.ne
    refine ⟨by rw [pk_one]; exact p96_optimum (by norm_num) (by norm_num), hz, ha,
      ⟨_, bneg, hb⟩, ⟨ε, hε, fun T k hT hk hzero => ⟨fun h1 => ?_, fun h1 => ?_⟩⟩,
      fun Tsel d hsel hd hzero => ?_⟩
    · by_contra hc; push Not at hc
      have := (hdisp T k hT hk).2 (by nlinarith) hc; simp only at this; linarith
    · by_contra hc; push Not at hc
      have := (hdisp T k hT hk).1 (by nlinarith) hc; simp only at this; linarith
    · have ha' : HasDerivAt (fun T => Phi Real.sqrt (pk 16 1) T) (-(31559 / 80190)) (Tsel 1) := by
        rw [hsel]; exact ha
      have hb' : HasDerivAt (fun k => Phi Real.sqrt (pk 16 k) (Tsel 1))
          (962 / 1089 - 31559 / 80190 * Real.log 16) 1 := by rw [hsel]; exact hb
      have hΦ' : DifferentiableAt ℝ (fun q : ℝ × ℝ => Phi Real.sqrt (pk 16 q.2) q.1)
          (Tsel 1, 1) := by rw [hsel]; exact hΦ
      exact ((comp_statics (Φ := fun T k => Phi Real.sqrt (pk 16 k) T) hΦ' ha' hb' hd hzero
        (by norm_num)).2.2).2 bneg

/-! ## P33: a jump in the rent makes the optimum a kink the smooth candidate set misses -/

/-- The jump rent `ρ(x) = x + 1{x ≥ 1}`. -/
noncomputable def ρJ (y : ℝ) : ℝ := y + if 1 ≤ y then 1 else 0

/-- The example: `r = λ = κ_pre = κ_post = Δ = 1`, `g₀ = 1.1`, `F = 9/4`, `Z = 0`. -/
noncomputable def pJ : Prm :=
  { r := 1, lam := 1, F := 9/4, Z := 0, kpre := 1, kpost := 1, g0 := 11/10, Δ := 1 }

/-- The kink date `T₀ = ln 1.1`, where `g = 1`. -/
noncomputable def T0 : ℝ := Real.log (11/10)

theorem T0_pos : 0 < T0 := Real.log_pos (by norm_num)

theorem integral_exp_neg_interval {c : ℝ} (hc : c ≠ 0) (b : ℝ) :
    ∫ t in (0:ℝ)..b, exp (-c * t) = (1 - exp (-c * b)) / c := by
  have hd : ∀ t, HasDerivAt (fun t => -exp (-c * t) / c) (exp (-c * t)) t := fun t => by
    have h := (((hasDerivAt_id t).const_mul (-c)).exp.neg).div_const c
    refine h.congr_deriv ?_
    simp only [id]; field_simp
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hd t)
    ((by fun_prop : Continuous fun t => exp (-c * t)).intervalIntegrable _ _)]
  simp only [mul_zero, exp_zero]; field_simp; ring

/-- `1 ≤ x e^{−s}` iff `s ≤ ln x`, for `x > 0`. -/
theorem le_mul_exp_neg_iff {x s : ℝ} (hx : 0 < x) : 1 ≤ x * exp (-s) ↔ s ≤ Real.log x := by
  rw [Real.le_log_iff_exp_le hx]
  have he := exp_pos s
  have : x * exp (-s) * exp s = x := by rw [mul_assoc, ← exp_add]; simp
  constructor
  · intro h; nlinarith
  · intro h
    by_contra hc; push Not at hc
    nlinarith [exp_pos (-s)]

/-- **`Π` of the jump rent, from its integral** (`r = κ_post = 1`): for `x > 0`,
`Π(x) = x/2 + (1 − 1/x)⁺`, as the paper states. -/
theorem Pi_jump {x : ℝ} (hx : 0 < x) :
    Pi ρJ 1 1 x = x / 2 + max (1 - 1 / x) 0 := by
  unfold Pi
  have e : ∀ s : ℝ, exp (-1 * s) * ρJ (x * exp (-1 * s)) =
      x * exp (-2 * s) + (Iic (Real.log x)).indicator (fun s => exp (-1 * s)) s := by
    intro s
    simp only [ρJ, Set.indicator, mem_Iic, neg_mul, one_mul]
    have h2 : exp (-s) * (x * exp (-s)) = x * exp (-(2 * s)) := by
      rw [mul_left_comm, ← exp_add]; ring_nf
    by_cases hs : s ≤ Real.log x
    · have hc := (le_mul_exp_neg_iff hx).2 hs
      simp only [hc, hs, ↓reduceIte]
      rw [mul_add, h2, mul_one]
    · have hc : ¬ 1 ≤ x * exp (-s) := fun h => hs ((le_mul_exp_neg_iff hx).1 h)
      simp only [hc, hs, ↓reduceIte]
      rw [mul_add, h2, mul_zero]
  simp_rw [e]
  have i1 : IntegrableOn (fun s : ℝ => x * exp (-2 * s)) (Ioi 0) :=
    (exp_neg_integrableOn_Ioi 0 (by norm_num : (0:ℝ) < 2)).const_mul x
  have i2 : IntegrableOn ((Iic (Real.log x)).indicator (fun s : ℝ => exp (-1 * s))) (Ioi 0) :=
    (exp_neg_integrableOn_Ioi 0 (by norm_num : (0:ℝ) < 1)).indicator measurableSet_Iic
  rw [integral_add i1 i2, MeasureTheory.integral_const_mul,
    integral_exp_mul_Ioi (by norm_num : (-2:ℝ) < 0) 0, setIntegral_indicator measurableSet_Iic,
    Ioi_inter_Iic]
  simp only [mul_zero, exp_zero]
  rcases le_or_gt 1 x with h1 | h1
  · have hL : 0 ≤ Real.log x := Real.log_nonneg h1
    rw [← intervalIntegral.integral_of_le hL, integral_exp_neg_interval one_ne_zero,
      max_eq_left (by rw [sub_nonneg, div_le_one hx]; exact h1)]
    rw [show -1 * Real.log x = -Real.log x by ring, exp_neg, exp_log hx]
    field_simp
  · have hL : Real.log x < 0 := Real.log_neg hx h1
    rw [Ioc_eq_empty (not_lt.2 hL.le), Measure.restrict_empty, integral_zero_measure,
      max_eq_right (by rw [sub_nonpos, le_div_iff₀ hx]; linarith)]
    ring

theorem lead_pJ (T : ℝ) : lead pJ T = 11/10 * exp (-T) := by simp [lead, pJ]

theorem lead_pJ_pos (T : ℝ) : 0 < lead pJ T := by rw [lead_pJ]; positivity

theorem lead_pJ_T0 : lead pJ T0 = 1 := by
  rw [lead_pJ, T0, exp_neg, exp_log (by norm_num)]; norm_num

/-- `g(T) ≥ 1` iff `T ≤ T₀`. -/
theorem lead_pJ_ge_one_iff (T : ℝ) : 1 ≤ lead pJ T ↔ T ≤ T0 := by
  rw [lead_pJ, T0]; exact le_mul_exp_neg_iff (by norm_num)

theorem J_pJ : J ρJ pJ = fun T => (lead pJ T + 1) / 2 + (1 - (lead pJ T + 1)⁻¹) := by
  funext T
  have hx : 0 < lead pJ T + 1 := by linarith [lead_pJ_pos T]
  simp only [J, show pJ.r = 1 from rfl, show pJ.kpost = 1 from rfl, show pJ.Δ = 1 from rfl]
  rw [Pi_jump hx, max_eq_left, one_div]
  rw [sub_nonneg, one_div, inv_le_one₀ hx]; linarith [lead_pJ_pos T]

theorem J_pJ_hasDerivAt (T : ℝ) :
    HasDerivAt (J ρJ pJ)
      (-lead pJ T / 2 - -(-lead pJ T) / (lead pJ T + 1) ^ 2) T := by
  rw [J_pJ]
  have hl := (lead_hasDerivAt pJ T).add_const 1
  have hx : lead pJ T + 1 ≠ 0 := by linarith [lead_pJ_pos T]
  have h := (hl.div_const 2).add ((hl.inv hx).const_sub 1)
  refine h.congr_deriv ?_
  simp only [show pJ.kpre = 1 from rfl]; ring

/-- **`Φ` in the example**, through the lead `g = g(T)`: `Φ = c − g/2 + (g + 2)/(g + 1)²`,
with `c = 1/4` where `g ≥ 1` (before the kink) and `c = −3/4` where `g < 1` (after it). -/
theorem Phi_pJ (T : ℝ) :
    Phi ρJ pJ T = (if 1 ≤ lead pJ T then 1/4 else -3/4) - lead pJ T / 2 +
      (lead pJ T + 2) / (lead pJ T + 1) ^ 2 := by
  have hx : 0 < lead pJ T + 1 := by linarith [lead_pJ_pos T]
  unfold Phi
  rw [(J_pJ_hasDerivAt T).deriv, J_pJ]
  simp only [ρJ, show pJ.F = 9/4 from rfl, show pJ.lam = 1 from rfl, show pJ.Z = 0 from rfl,
    show pJ.r = 1 from rfl]
  split_ifs <;> field_simp <;> ring

/-- The two branches of `Φ` as functions of the date. -/
noncomputable def Φplus (T : ℝ) : ℝ := 1/4 - lead pJ T / 2 + (lead pJ T + 2) / (lead pJ T + 1) ^ 2
noncomputable def Φminus (T : ℝ) : ℝ :=
  -3/4 - lead pJ T / 2 + (lead pJ T + 2) / (lead pJ T + 1) ^ 2

theorem Φplus_cont : Continuous Φplus := by
  have hl : Continuous (lead pJ) := by unfold lead; fun_prop
  unfold Φplus
  exact (continuous_const.sub (hl.div_const 2)).add ((hl.add continuous_const).div
    ((hl.add continuous_const).pow 2) fun T => by have := lead_pJ_pos T; positivity)

theorem Φminus_cont : Continuous Φminus := by
  have hl : Continuous (lead pJ) := by unfold lead; fun_prop
  unfold Φminus
  exact (continuous_const.sub (hl.div_const 2)).add ((hl.add continuous_const).div
    ((hl.add continuous_const).pow 2) fun T => by have := lead_pJ_pos T; positivity)

/-- **`Φ` jumps from `+1/2` to `−1/2` at `T₀`.** -/
theorem p33_Phi_jump :
    Tendsto (Phi ρJ pJ) (𝓝[<] T0) (𝓝 (1/2)) ∧ Tendsto (Phi ρJ pJ) (𝓝[>] T0) (𝓝 (-1/2)) := by
  have v1 : Φplus T0 = 1/2 := by simp only [Φplus, lead_pJ_T0]; norm_num
  have v2 : Φminus T0 = -1/2 := by simp only [Φminus, lead_pJ_T0]; norm_num
  constructor
  · have h := (Φplus_cont.tendsto T0).mono_left (nhdsWithin_le_nhds (s := Iio T0))
    rw [v1] at h
    refine h.congr' ?_
    filter_upwards [self_mem_nhdsWithin] with T hT
    rw [Phi_pJ]; simp only [(lead_pJ_ge_one_iff T).2 (le_of_lt hT), ↓reduceIte]; rfl
  · have h := (Φminus_cont.tendsto T0).mono_left (nhdsWithin_le_nhds (s := Ioi T0))
    rw [v2] at h
    refine h.congr' ?_
    filter_upwards [self_mem_nhdsWithin] with T hT
    have hn : ¬ 1 ≤ lead pJ T := by rw [lead_pJ_ge_one_iff]; exact not_le.2 hT
    rw [Phi_pJ]; simp only [hn, ↓reduceIte]; rfl

/-- **Before and at the kink `Φ > 0.40`** (`Φ ≥ Φ(g = 1.1) > 0.40`): no zero of `Φ`, so no
smooth candidate, lies in `[0, T₀]`, and `Φ(T₀) = 1/2 ≠ 0`. -/
theorem p33_Phi_pos_before : (∀ T, 0 ≤ T → T ≤ T0 → 2/5 < Phi ρJ pJ T) ∧ Phi ρJ pJ T0 = 1/2 := by
  refine ⟨fun T hT hle => ?_, ?_⟩
  · rw [Phi_pJ]; simp only [(lead_pJ_ge_one_iff T).2 hle, ↓reduceIte]
    have hg1 : 1 ≤ lead pJ T := (lead_pJ_ge_one_iff T).2 hle
    have hg2 : lead pJ T ≤ 11/10 := by
      rw [lead_pJ]; have : exp (-T) ≤ 1 := exp_le_one_iff.2 (by linarith); nlinarith
    set g := lead pJ T
    rw [show (2:ℝ)/5 < 1/4 - g/2 + (g + 2)/(g + 1)^2 ↔
        (2/5 - 1/4 + g/2) * (g + 1)^2 < g + 2 by
      rw [← sub_pos, ← sub_pos (a := g + 2)]
      constructor <;> intro h
      · have : 0 < (g+1)^2 := by positivity
        have e : (1/4 - g/2 + (g + 2)/(g + 1)^2 - 2/5) * (g+1)^2 =
            g + 2 - (2/5 - 1/4 + g/2) * (g + 1)^2 := by field_simp; ring
        nlinarith
      · have : 0 < (g+1)^2 := by positivity
        have e : (1/4 - g/2 + (g + 2)/(g + 1)^2 - 2/5) =
            (g + 2 - (2/5 - 1/4 + g/2) * (g + 1)^2) / (g+1)^2 := by field_simp; ring
        rw [e]; positivity]
    nlinarith [mul_nonneg (sub_nonneg.2 hg2) (sub_nonneg.2 hg1)]
  · rw [Phi_pJ, lead_pJ_T0]; norm_num

/-- The hold integrand splits into a continuous part and the indicator of the dates before the
kink, where `ρ(g(t))` carries its jump. -/
theorem holdIntegrand_pJ (t : ℝ) :
    holdIntegrand ρJ pJ t = 9/4 * exp (-2 * t) + 11/10 * exp (-3 * t) +
      (Iic T0).indicator (fun t => exp (-2 * t)) t := by
  have hiff : 1 ≤ 11/10 * exp (-t) ↔ t ≤ T0 := le_mul_exp_neg_iff (by norm_num)
  simp only [holdIntegrand, lead, ρJ, Set.indicator, mem_Iic, show pJ.r = 1 from rfl,
    show pJ.lam = 1 from rfl, show pJ.F = 9/4 from rfl, show pJ.Z = 0 from rfl,
    show pJ.kpre = 1 from rfl, show pJ.g0 = 11/10 from rfl, neg_mul, one_mul]
  have e3 : exp (-((1 + 1) * t)) * (11/10 * exp (-t)) = 11/10 * exp (-(3 * t)) := by
    rw [mul_left_comm, ← exp_add]; ring_nf
  have e2 : exp (-((1 + 1) * t)) = exp (-(2 * t)) := by ring_nf
  by_cases h2 : t ≤ T0
  · have h1 := hiff.2 h2
    simp only [h1, h2, ↓reduceIte]
    linear_combination (13/4 : ℝ) * e2 + e3
  · have h1 : ¬ 1 ≤ 11/10 * exp (-t) := fun h => h2 (hiff.1 h)
    simp only [h1, h2, ↓reduceIte]
    linear_combination (9/4 : ℝ) * e2 + e3

theorem integral_indicator_T0 {T : ℝ} (hT : 0 ≤ T) :
    ∫ t in (0:ℝ)..T, (Iic T0).indicator (fun t => exp (-2 * t)) t =
      ∫ t in (0:ℝ)..min T T0, exp (-2 * t) := by
  rw [intervalIntegral.integral_of_le hT, intervalIntegral.integral_of_le (le_min hT T0_pos.le),
    setIntegral_indicator measurableSet_Iic, Ioc_inter_Iic]

/-- **`V` in closed form**, for `T ≥ 0`, with `u = e^{−T}` and `m = min(T, T₀)`. -/
theorem V_pJ {T : ℝ} (hT : 0 ≤ T) :
    V ρJ pJ T = 9/8 * (1 - exp (-2 * T)) + 11/30 * (1 - exp (-3 * T)) +
      (1 - exp (-2 * min T T0)) / 2 +
      exp (-2 * T) * ((lead pJ T + 1) / 2 + (1 - (lead pJ T + 1)⁻¹)) := by
  have c1 : Continuous fun t : ℝ => 9/4 * exp (-2 * t) := by fun_prop
  have c2 : Continuous fun t : ℝ => 11/10 * exp (-3 * t) := by fun_prop
  have i3 : IntervalIntegrable ((Iic T0).indicator fun t : ℝ => exp (-2 * t)) volume 0 T := by
    rw [intervalIntegrable_iff]
    exact ((by fun_prop : Continuous fun t : ℝ => exp (-2 * t)).integrableOn_uIoc).indicator
      measurableSet_Iic
  unfold V
  simp_rw [holdIntegrand_pJ]
  rw [intervalIntegral.integral_add ((c1.intervalIntegrable _ _).add (c2.intervalIntegrable _ _)) i3,
    intervalIntegral.integral_add (c1.intervalIntegrable _ _) (c2.intervalIntegrable _ _),
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul,
    integral_exp_neg_interval (by norm_num : (2:ℝ) ≠ 0),
    integral_exp_neg_interval (by norm_num : (3:ℝ) ≠ 0), integral_indicator_T0 hT,
    integral_exp_neg_interval (by norm_num : (2:ℝ) ≠ 0), J_pJ]
  simp only [show pJ.r = 1 from rfl, show pJ.lam = 1 from rfl]
  ring_nf

theorem exp_pow_eq {T : ℝ} (n : ℕ) : exp (-(n:ℝ) * T) = exp (-T) ^ n := by
  rw [← exp_nat_mul]; ring_nf

/-- The value before the kink, as a function of `u = e^{−T} ∈ [10/11, 1]`. -/
noncomputable def v1 (u : ℝ) : ℝ := 13/8 + 11/30 - u^2/8 + 11/60 * u^3 - u^2 / (1 + 11/10 * u)
/-- The value after the kink, `u ∈ (0, 10/11]`. -/
noncomputable def v2 (u : ℝ) : ℝ :=
  9/8 + 11/30 + 21/242 + 3/8 * u^2 + 11/60 * u^3 - u^2 / (1 + 11/10 * u)

theorem V_pJ_before {T : ℝ} (hT : 0 ≤ T) (hle : T ≤ T0) : V ρJ pJ T = v1 (exp (-T)) := by
  rw [V_pJ hT, min_eq_left hle, lead_pJ]
  have e2 := exp_pow_eq (T := T) 2
  have e3 := exp_pow_eq (T := T) 3
  push_cast at e2 e3
  rw [e2, e3]
  have hu := exp_pos (-T)
  unfold v1
  field_simp
  ring

theorem exp_neg_two_T0 : exp (-2 * T0) = 100/121 := by
  rw [show -2 * T0 = -(2:ℕ) * T0 by norm_num, exp_pow_eq, T0, exp_neg, exp_log (by norm_num)]
  norm_num

theorem V_pJ_after {T : ℝ} (hle : T0 ≤ T) : V ρJ pJ T = v2 (exp (-T)) := by
  have hT : 0 ≤ T := T0_pos.le.trans hle
  rw [V_pJ hT, min_eq_right hle, lead_pJ, exp_neg_two_T0]
  have e2 := exp_pow_eq (T := T) 2
  have e3 := exp_pow_eq (T := T) 3
  push_cast at e2 e3
  rw [e2, e3]
  have hu := exp_pos (-T)
  unfold v2
  field_simp
  ring

theorem exp_neg_T0 : exp (-T0) = 10/11 := by
  rw [T0, exp_neg, exp_log (by norm_num)]; norm_num

/-- **P33 (A.6 proof of P11, line 1134).** With the jump rent `ρ(x) = x + 1{x ≥ 1}`,
`r = λ = κ_pre = κ_post = Δ = 1`, `g₀ = 1.1`, `F = 9/4`, `Z = 0`:
(a) `Π(x) = x/2 + (1 − 1/x)⁺` (from the integral; `Pi_jump`);
(b) `Φ` jumps from `+1/2` to `−1/2` at `T₀ = ln 1.1`, where `g = 1`;
(c) on `[0, T₀]`, `Φ > 0.40`, so no zero of `Φ` lies there and `Φ(T₀) = 1/2 ≠ 0`;
(d) `V(T₀) = 2129/1320 ≈ 1.6129` exceeds `V(0) = 661/420 ≈ 1.5738`, the hold-until-loss limit
`V(∞) = 22919/14520 ≈ 1.5784`, and the value at every other date `T ≥ 0`. The strict global
optimum is the kink `T₀`, which is not a zero of `Φ`. -/
theorem p33_jump_kink_optimum :
    lead pJ T0 = 1 ∧
    Tendsto (Phi ρJ pJ) (𝓝[<] T0) (𝓝 (1/2)) ∧ Tendsto (Phi ρJ pJ) (𝓝[>] T0) (𝓝 (-1/2)) ∧
    (∀ T, 0 ≤ T → T ≤ T0 → Phi ρJ pJ T ≠ 0) ∧
    V ρJ pJ T0 = 2129 / 1320 ∧ V ρJ pJ 0 = 661 / 420 ∧
    Tendsto (V ρJ pJ) atTop (𝓝 (22919 / 14520)) ∧
    (∀ T, 0 ≤ T → T ≠ T0 → V ρJ pJ T < V ρJ pJ T0) ∧ (22919 / 14520 : ℝ) < 2129 / 1320 ∧
    |(2129 / 1320 : ℝ) - 1.6129| < 0.00005 ∧ |(661 / 420 : ℝ) - 1.5738| < 0.00005 ∧
    |(22919 / 14520 : ℝ) - 1.5784| < 0.00005 := by
  have hVT0 : V ρJ pJ T0 = 2129 / 1320 := by
    rw [V_pJ_after le_rfl, exp_neg_T0]; unfold v2; norm_num
  obtain ⟨hpos, -⟩ := p33_Phi_pos_before
  refine ⟨lead_pJ_T0, p33_Phi_jump.1, p33_Phi_jump.2,
    fun T hT hle => (lt_trans (by norm_num) (hpos T hT hle)).ne', hVT0, ?_, ?_, ?_,
    by norm_num, by norm_num [abs_lt], by norm_num [abs_lt], by norm_num [abs_lt]⟩
  · rw [V_pJ_before le_rfl T0_pos.le]; simp only [neg_zero, exp_zero]; unfold v1; norm_num
  · have hcont : ContinuousAt v2 0 := by
      unfold v2
      refine ContinuousAt.sub (by fun_prop) (ContinuousAt.div (by fun_prop) (by fun_prop)
        (by norm_num))
    have h0 : v2 0 = 22919 / 14520 := by unfold v2; norm_num
    have h : Tendsto (fun T => v2 (exp (-T))) atTop (𝓝 (v2 0)) :=
      hcont.tendsto.comp tendsto_exp_neg_atTop_nhds_zero
    rw [h0] at h
    refine h.congr' ?_
    filter_upwards [eventually_ge_atTop T0] with T hT
    exact (V_pJ_after hT).symm
  · intro T hT hne
    rw [hVT0]
    rcases lt_or_gt_of_ne hne with h | h
    · rw [V_pJ_before hT h.le]
      set u := exp (-T) with hu
      have hu1 : u ≤ 1 := exp_le_one_iff.2 (by linarith)
      have hu0 : 10/11 < u := by
        rw [← exp_neg_T0, hu]; exact exp_lt_exp.2 (by linarith)
      have hd : 0 < 1 + 11/10 * u := by linarith
      have key : (2129/1320 - v1 u) * (1 + 11/10 * u) =
          (u - 10/11) * (5/12 + 11/12 * u - 11/48 * u^2 - 121/600 * u^3) := by
        unfold v1; field_simp; ring
      have hq : 0 < 5/12 + 11/12 * u - 11/48 * u^2 - 121/600 * u^3 := by nlinarith
      have : 0 < (2129/1320 - v1 u) * (1 + 11/10 * u) := by
        rw [key]; exact mul_pos (by linarith) hq
      have := (pos_of_mul_pos_left this hd.le)
      linarith
    · rw [V_pJ_after h.le]
      set u := exp (-T) with hu
      have hu0 : 0 < u := exp_pos _
      have hu1 : u < 10/11 := by
        rw [← exp_neg_T0, hu]; exact exp_lt_exp.2 (by linarith)
      have hd : 0 < 1 + 11/10 * u := by linarith
      have key : (2129/1320 - v2 u) * (1 + 11/10 * u) =
          (u - 10/11) * (-5/132 - 1/12 * u - 187/240 * u^2 - 121/600 * u^3) := by
        unfold v2; field_simp; ring
      have hq : -5/132 - 1/12 * u - 187/240 * u^2 - 121/600 * u^3 < 0 := by nlinarith
      have : 0 < (2129/1320 - v2 u) * (1 + 11/10 * u) := by
        rw [key]; exact mul_pos_of_neg_of_neg (by linarith) hq
      have := (pos_of_mul_pos_left this hd.le)
      linarith

/-! ## B84, C13: discounting moves P16's net sign in either direction (both `r > 0`) -/

/-- `A_r(u) = (1 − e^{−ru})/r` (P16(ii), line 1031). -/
noncomputable def Ar (r u : ℝ) : ℝ := (1 - exp (-r * u)) / r

/-- A P16 clock, `max(D/s, (1 − m)t₀) + m t₀` (line 1021). -/
noncomputable def clock (D t₀ m s : ℝ) : ℝ := max (D / s) ((1 - m) * t₀) + m * t₀

/-- P16(ii)'s perpetual discounted balance `W_r = B_r − V_c C_{c,r}`, with
`B_r = (y/r)e^{−r t_B}` and `C_{c,r} = H A_r(T) + S_r`, at the illustrative primitives
`K = 1`, `T_a = 4`, `m = 0` (parallel cyber clock), `K_B = 1`, `T_b = 1/2`, `m_B = 0` (parallel
benefit clock), `H(s) = s`, `V_c = 1`, `S_r = 0`; only `y` and `r` vary. -/
noncomputable def W13 (y r s : ℝ) : ℝ :=
  y / r * exp (-r * clock 1 (1/2) 0 s) - 1 * (s * Ar r (clock 1 4 0 s) + 0)

/-- At `s = 1` adoption sets the cyber clock (`T = 4`) and capability sets the benefit's
(`t_B = 1/s`), so `sW_r′ = y·q·e^{−r t_B} − V_c H ε_H A_r(T_a) = y e^{−r} − A_r(4)`. -/
theorem W13_hasDerivAt (y : ℝ) {r : ℝ} (hr : r ≠ 0) :
    HasDerivAt (W13 y r) (y * exp (-r) - Ar r 4) 1 := by
  have heq : W13 y r =ᶠ[𝓝 1] fun s => y / r * exp (-r * (1 / s)) - s * Ar r 4 := by
    filter_upwards [Ioo_mem_nhds (show (1/4 : ℝ) < 1 by norm_num) (show (1:ℝ) < 2 by norm_num)]
      with s hs
    have hs0 : 0 < s := by linarith [hs.1]
    have hT : clock 1 4 0 s = 4 := by
      unfold clock
      rw [max_eq_right (by rw [div_le_iff₀ hs0]; linarith [hs.1])]; ring
    have hB : clock 1 (1/2) 0 s = 1 / s := by
      unfold clock
      rw [max_eq_left (by rw [le_div_iff₀ hs0]; linarith [hs.2])]; ring
    simp only [W13, hT, hB]; ring
  refine HasDerivAt.congr_of_eventuallyEq ?_ heq
  have hinv : HasDerivAt (fun s : ℝ => 1 / s) (-1) 1 := by
    have := hasDerivAt_inv (one_ne_zero (α := ℝ)); simpa [one_div] using this
  have h1 := ((hinv.const_mul (-r)).exp.const_mul (y / r)).sub ((hasDerivAt_id (1:ℝ)).mul_const
    (Ar r 4))
  refine h1.congr_deriv ?_
  simp only [div_one, mul_one, one_mul]
  field_simp

theorem Ar_four (r : ℝ) : Ar r 4 = (1 - exp (-4 * r)) / r := by
  unfold Ar; ring_nf

/-- **B84 (line 213), C13 (line 1337): discounting's effect on P16's net sign has no general
direction.** In each example every primitive but `r` is fixed, and both rates are positive, with
the benefit term active. With `y = 19/5`, raising `r` from `1/100` to `1` turns `sW_r′` at
`s = 1` from negative (acceleration worsens the balance) to positive. With `y = 3`, raising `r`
from `1` to `2` turns it from positive to negative. -/
theorem c13_discount_either_direction :
    (∃ d₁ d₂, HasDerivAt (W13 (19/5) (1/100)) d₁ 1 ∧ d₁ < 0 ∧
      HasDerivAt (W13 (19/5) 1) d₂ 1 ∧ 0 < d₂) ∧
    (∃ d₁ d₂, HasDerivAt (W13 3 1) d₁ 1 ∧ 0 < d₁ ∧ HasDerivAt (W13 3 2) d₂ 1 ∧ d₂ < 0) := by
  have e1 := Real.exp_one_gt_d9
  have e1' := Real.exp_one_lt_d9
  have em1 : exp (-1) = (exp 1)⁻¹ := by rw [exp_neg]
  have em2 : exp (-2) = ((exp 1)^2)⁻¹ := by
    rw [exp_neg, show (2:ℝ) = (2:ℕ) * 1 by norm_num, exp_nat_mul]
  have hpos1 := exp_pos (1:ℝ)
  have hlo1 : 1 + 1/100 ≤ exp (1/100) := by linarith [add_one_le_exp (1/100 : ℝ)]
  have hlo4 : 1 + 4/100 ≤ exp (4/100) := by linarith [add_one_le_exp (4/100 : ℝ)]
  have hlo8 : 1 + 8 ≤ exp 8 := by linarith [add_one_le_exp (8 : ℝ)]
  have hm4 : 0 < exp (-4) := exp_pos _
  refine ⟨⟨_, _, W13_hasDerivAt _ (by norm_num), ?_, W13_hasDerivAt _ (by norm_num), ?_⟩,
    ⟨_, _, W13_hasDerivAt _ (by norm_num), ?_, W13_hasDerivAt _ (by norm_num), ?_⟩⟩
  · -- 19/5·e^{−1/100} − 100(1 − e^{−4/100}) < 0
    rw [Ar_four]
    have a : exp (-(1/100 : ℝ)) ≤ (1 + 1/100)⁻¹ := by
      rw [exp_neg]; exact inv_anti₀ (by norm_num) hlo1
    have b : exp (-4 * (1/100 : ℝ)) ≤ (1 + 4/100)⁻¹ := by
      rw [show -4 * (1/100 : ℝ) = -(4/100) by norm_num, exp_neg]
      exact inv_anti₀ (by norm_num) hlo4
    norm_num at a b ⊢
    nlinarith
  · -- 19/5·e^{−1} − (1 − e^{−4}) > 0
    rw [Ar_four, em1]
    have : (19/5 : ℝ) * (exp 1)⁻¹ > 1 := by
      rw [gt_iff_lt, ← div_eq_mul_inv, lt_div_iff₀ hpos1]; linarith
    norm_num; linarith
  · -- 3·e^{−1} − (1 − e^{−4}) > 0
    rw [Ar_four, em1]
    have : (3 : ℝ) * (exp 1)⁻¹ > 1 := by
      rw [gt_iff_lt, ← div_eq_mul_inv, lt_div_iff₀ hpos1]; linarith
    norm_num; linarith
  · -- 3·e^{−2} − (1 − e^{−8})/2 < 0
    rw [Ar_four, show -(2:ℝ) = -2 by rfl, em2]
    have h8 : exp (-4 * 2) ≤ (1 + 8 : ℝ)⁻¹ := by
      rw [show -4 * (2:ℝ) = -8 by norm_num, exp_neg]; exact inv_anti₀ (by norm_num) hlo8
    have hsq : (2.7182818283 : ℝ) ^ 2 < exp 1 ^ 2 := by
      exact pow_lt_pow_left₀ e1 (by norm_num) (by norm_num)
    have h2 : 3 * ((exp 1) ^ 2)⁻¹ < 3 * ((2.7182818283 : ℝ) ^ 2)⁻¹ :=
      mul_lt_mul_of_pos_left (inv_strictAnti₀ (by positivity) hsq) (by norm_num)
    norm_num at h8 h2 ⊢
    nlinarith

/-- The branch of `Φ` as a function of the lead, `φ_c(g) = c − g/2 + (g + 2)/(g + 1)²`. -/
noncomputable def φc (c g : ℝ) : ℝ := c - g / 2 + (g + 2) / (g + 1) ^ 2

/-- **"`dΦ/dg = −1/2 − (g + 3)/(g + 1)³ < 0`, so `Φ` rises in `T` on each side"** (line 1134). -/
theorem p33_dPhi_dg (c : ℝ) {g : ℝ} (hg : 0 ≤ g) :
    HasDerivAt (φc c) (-1/2 - (g + 3) / (g + 1) ^ 3) g ∧ -1/2 - (g + 3) / (g + 1) ^ 3 < 0 := by
  have h1 : (g + 1) ≠ 0 := by linarith
  constructor
  · have hn : HasDerivAt (fun x : ℝ => x + 2) 1 g := (hasDerivAt_id g).add_const 2
    have hd : HasDerivAt (fun x : ℝ => (x + 1) ^ 2) (2 * (g + 1) ^ 1 * 1) g :=
      ((hasDerivAt_id g).add_const 1).pow 2
    have h := ((hasDerivAt_id g).div_const 2).const_sub c |>.add (hn.div hd (by positivity))
    refine h.congr_deriv ?_
    field_simp; ring
  · have : 0 < (g + 3) / (g + 1) ^ 3 := by positivity
    linarith

theorem φc_strictAnti (c : ℝ) : StrictAntiOn (φc c) (Ici 0) := by
  apply strictAntiOn_of_deriv_neg (convex_Ici 0)
  · intro g hg
    exact (p33_dPhi_dg c (mem_Ici.1 hg)).1.continuousAt.continuousWithinAt
  · intro g hg; rw [interior_Ici] at hg
    rw [(p33_dPhi_dg c hg.le).1.deriv]; exact (p33_dPhi_dg c hg.le).2

/-- **After the kink `Φ` rises strictly from `−1/2` toward `5/4` and has exactly one zero, an
upward crossing** (line 1134). -/
theorem p33_Phi_after :
    StrictMonoOn (Phi ρJ pJ) (Ioi T0) ∧ Tendsto (Phi ρJ pJ) atTop (𝓝 (5/4)) ∧
    ∃ T1, T0 < T1 ∧ Phi ρJ pJ T1 = 0 ∧ (∀ T, T0 < T → T < T1 → Phi ρJ pJ T < 0) ∧
      (∀ T, T1 < T → 0 < Phi ρJ pJ T) := by
  have hbranch : ∀ T, T0 < T → Phi ρJ pJ T = φc (-3/4) (lead pJ T) := fun T hT => by
    have hn : ¬ 1 ≤ lead pJ T := by rw [lead_pJ_ge_one_iff]; exact not_le.2 hT
    rw [Phi_pJ]; simp only [hn, ↓reduceIte, φc]
  have hanti : ∀ T T', T < T' → lead pJ T' < lead pJ T := fun T T' h => by
    rw [lead_pJ, lead_pJ]
    exact mul_lt_mul_of_pos_left (exp_lt_exp.2 (by linarith)) (by norm_num)
  have hmono : StrictMonoOn (Phi ρJ pJ) (Ioi T0) := by
    intro T hT T' hT' h
    rw [hbranch T hT, hbranch T' hT']
    exact φc_strictAnti _ (lead_pJ_pos T').le (lead_pJ_pos T).le (hanti T T' h)
  have hcont : Continuous (fun T => φc (-3/4) (lead pJ T)) := by
    have hl : Continuous (lead pJ) := by unfold lead; fun_prop
    unfold φc
    exact (continuous_const.sub (hl.div_const 2)).add ((hl.add continuous_const).div
      ((hl.add continuous_const).pow 2) fun T => by have := lead_pJ_pos T; positivity)
  have hlim0 : Tendsto (lead pJ) atTop (𝓝 0) := by
    have := (tendsto_exp_neg_atTop_nhds_zero.const_mul (11/10 : ℝ))
    simp only [mul_zero] at this
    refine this.congr' (Eventually.of_forall fun T => ?_)
    rw [lead_pJ]
  have hφ0 : ContinuousAt (φc (-3/4)) 0 := by
    unfold φc
    exact ContinuousAt.add (by fun_prop) (ContinuousAt.div (by fun_prop) (by fun_prop)
      (by norm_num))
  have hlim : Tendsto (Phi ρJ pJ) atTop (𝓝 (5/4)) := by
    have h := hφ0.tendsto.comp hlim0
    have hv : φc (-3/4) 0 = 5/4 := by unfold φc; norm_num
    rw [hv] at h
    refine h.congr' ?_
    filter_upwards [eventually_gt_atTop T0] with T hT
    exact (hbranch T hT).symm
  refine ⟨hmono, hlim, ?_⟩
  obtain ⟨Tb, hTb⟩ := (eventually_atTop.1 ((hlim.eventually (lt_mem_nhds
    (show (0:ℝ) < 5/4 by norm_num))).and (eventually_gt_atTop T0)))
  have hTb1 := (hTb (max Tb (T0 + 1)) (le_max_left _ _))
  have hv0 : φc (-3/4) (lead pJ T0) = -1/2 := by rw [lead_pJ_T0]; unfold φc; norm_num
  have hvb : 0 < φc (-3/4) (lead pJ (max Tb (T0 + 1))) := by
    rw [← hbranch _ hTb1.2]; exact hTb1.1
  obtain ⟨T1, hT1m, hT1z⟩ := intermediate_value_Ioo (le_of_lt hTb1.2) hcont.continuousOn
    ⟨by rw [hv0]; norm_num, hvb⟩
  have hz : Phi ρJ pJ T1 = 0 := by rw [hbranch T1 hT1m.1]; exact hT1z
  refine ⟨T1, hT1m.1, hz, fun T hT hlt => ?_, fun T hlt => ?_⟩
  · rw [← hz]; exact hmono hT hT1m.1 hlt
  · rw [← hz]; exact hmono hT1m.1 (lt_trans hT1m.1 hlt) hlt

/-- **P33, "Before the kink `Φ ≥ Φ(g = 1.1) > 0.40`"** (line 1134), as stated: on `[0, T₀]`,
`Φ` is at least its value at the starting lead `g₀ = 1.1`, which is `1777/4410 > 0.40`. -/
theorem p33_Phi_ge_start :
    (∀ T, 0 ≤ T → T ≤ T0 → φc (1/4) (11/10) ≤ Phi ρJ pJ T) ∧ (2/5 : ℝ) < φc (1/4) (11/10) := by
  refine ⟨fun T hT hle => ?_, by unfold φc; norm_num⟩
  have hg1 : 1 ≤ lead pJ T := (lead_pJ_ge_one_iff T).2 hle
  have hg2 : lead pJ T ≤ 11/10 := by
    rw [lead_pJ]; have : exp (-T) ≤ 1 := exp_le_one_iff.2 (by linarith); nlinarith
  rw [Phi_pJ]; simp only [hg1, ↓reduceIte]
  exact (φc_strictAnti (1/4)).antitoneOn (mem_Ici.2 (by linarith)) (mem_Ici.2 (by norm_num)) hg2

/-! ## P33, fix round 2: the shape of `V` on each side of the kink

Fix round 2 (focus read Sol 1). The sign of `Φ` is the sign of `V′`: on each open side of the
kink, `V′(T) = e^{−2T}Φ(T)` for the defined `V` (here `r + λ = 2`). From that, `V` rises
strictly on `[0, T₀]`, falls strictly from `T₀` to the post-kink zero `T₁` of `Φ`, has a strict
local minimum at `T₁`, and rises strictly on `[T₁, ∞)` toward `V(∞)`. -/

/-- `d/dT [v(e^{−T})] = e^{−2T}φ_{−2b}(1.1e^{−T})` for the common shape of the closed forms
`v1` (`b = −1/8`) and `v2` (`b = 3/8`). -/
theorem vgen_hasDerivAt (a b T : ℝ) :
    HasDerivAt (fun T => a + b * exp (-T) ^ 2 + 11/60 * exp (-T) ^ 3 -
      exp (-T) ^ 2 / (1 + 11/10 * exp (-T)))
      (exp (-T) ^ 2 * φc (-2 * b) (11/10 * exp (-T))) T := by
  have hu : HasDerivAt (fun T => exp (-T)) (exp (-T) * -1) T := (hasDerivAt_neg T).exp
  have hpos := exp_pos (-T)
  have hd : (1 + 11/10 * exp (-T)) ≠ 0 := by positivity
  have h := (((hasDerivAt_const T a).add ((hu.pow 2).const_mul b)).add
    ((hu.pow 3).const_mul (11/60))).sub ((hu.pow 2).div ((hu.const_mul (11/10)).const_add 1) hd)
  refine h.congr_deriv ?_
  unfold φc
  have hd2 : (11/10 * exp (-T) + 1) ≠ 0 := by positivity
  norm_num
  field_simp
  ring

theorem W1_hasDerivAt (T : ℝ) :
    HasDerivAt (fun T => v1 (exp (-T))) (exp (-T) ^ 2 * φc (1/4) (lead pJ T)) T := by
  have h := vgen_hasDerivAt (13/8 + 11/30) (-1/8) T
  rw [lead_pJ]
  convert h using 1
  · funext T; unfold v1; ring
  · norm_num

theorem W2_hasDerivAt (T : ℝ) :
    HasDerivAt (fun T => v2 (exp (-T))) (exp (-T) ^ 2 * φc (-3/4) (lead pJ T)) T := by
  have h := vgen_hasDerivAt (9/8 + 11/30 + 21/242) (3/8) T
  rw [lead_pJ]
  convert h using 1
  · funext T; unfold v2; ring
  · norm_num

theorem Phi_pJ_before {T : ℝ} (h : T ≤ T0) : Phi ρJ pJ T = φc (1/4) (lead pJ T) := by
  rw [Phi_pJ]; simp only [(lead_pJ_ge_one_iff T).2 h, ↓reduceIte, φc]

theorem Phi_pJ_after {T : ℝ} (h : T0 < T) : Phi ρJ pJ T = φc (-3/4) (lead pJ T) := by
  have hn : ¬ 1 ≤ lead pJ T := by rw [lead_pJ_ge_one_iff]; exact not_le.2 h
  rw [Phi_pJ]; simp only [hn, ↓reduceIte, φc]

/-- **P33, "so Φ rises in T on each side"**, the side before the kink (line 1134): `Φ` is
strictly increasing on `(−∞, T₀]`. The side after it is `p33_Phi_after`. -/
theorem p33_Phi_rises_before : StrictMonoOn (Phi ρJ pJ) (Iic T0) := by
  intro T hT T' hT' h
  rw [Phi_pJ_before hT, Phi_pJ_before hT']
  refine φc_strictAnti _ (lead_pJ_pos T').le (lead_pJ_pos T).le ?_
  rw [lead_pJ, lead_pJ]
  exact mul_lt_mul_of_pos_left (exp_lt_exp.2 (by linarith)) (by norm_num)

/-- **"The sign of Φ establishes this"** (line 1134): `V′(T) = e^{−2T}Φ(T)` for the defined `V`,
at every date `T > 0` other than the kink `T₀`. -/
theorem p33_V_deriv {T : ℝ} (hT : 0 < T) (hne : T ≠ T0) :
    HasDerivAt (V ρJ pJ) (exp (-2 * T) * Phi ρJ pJ T) T := by
  have e2 : exp (-2 * T) = exp (-T) ^ 2 := by
    have := exp_pow_eq (T := T) 2; push_cast at this; exact this
  rw [e2]
  rcases lt_or_gt_of_ne hne with h | h
  · rw [Phi_pJ_before h.le]
    refine (W1_hasDerivAt T).congr_of_eventuallyEq ?_
    filter_upwards [Ioo_mem_nhds hT h] with x hx
    exact V_pJ_before hx.1.le hx.2.le
  · rw [Phi_pJ_after h]
    refine (W2_hasDerivAt T).congr_of_eventuallyEq ?_
    filter_upwards [Ioi_mem_nhds h] with x hx
    exact V_pJ_after hx.le

/-- **P33, "so V rises up to T₀"** (line 1134): `V` is strictly increasing on `[0, T₀]`. -/
theorem p33_V_rises_before : StrictMonoOn (V ρJ pJ) (Icc 0 T0) := by
  have hW : StrictMonoOn (fun T => v1 (exp (-T))) (Icc 0 T0) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc 0 T0)
    · exact fun x _ => (W1_hasDerivAt x).continuousAt.continuousWithinAt
    · intro x hx; rw [interior_Icc] at hx
      rw [(W1_hasDerivAt x).deriv, ← Phi_pJ_before hx.2.le]
      exact mul_pos (by positivity)
        (lt_trans (by norm_num) (p33_Phi_pos_before.1 x hx.1.le hx.2.le))
  intro a ha b hb hab
  rw [V_pJ_before ha.1 ha.2, V_pJ_before hb.1 hb.2]
  exact hW ha hb hab

/-- **P33, "After it Φ rises from −1/2 toward 5/4, so it has a single zero, upward, a local
minimum of V, beyond which V rises toward V(∞)"** (line 1134). With `T₁` the post-kink zero of
`Φ`: `V` falls strictly on `[T₀, T₁]`, has a strict local minimum at `T₁`, rises strictly on
`[T₁, ∞)`, and tends to `V(∞) = 22919/14520`. -/
theorem p33_V_after_shape :
    ∃ T1, T0 < T1 ∧ Phi ρJ pJ T1 = 0 ∧ StrictAntiOn (V ρJ pJ) (Icc T0 T1) ∧
      (∀ᶠ T in 𝓝[≠] T1, V ρJ pJ T1 < V ρJ pJ T) ∧ StrictMonoOn (V ρJ pJ) (Ici T1) ∧
      Tendsto (V ρJ pJ) atTop (𝓝 (22919 / 14520)) := by
  obtain ⟨-, -, T1, hT01, hz, hneg, hpos⟩ := p33_Phi_after
  have hc : ∀ s, ContinuousOn (fun T => v2 (exp (-T))) s :=
    fun s x _ => (W2_hasDerivAt x).continuousAt.continuousWithinAt
  have hA : StrictAntiOn (fun T => v2 (exp (-T))) (Icc T0 T1) := by
    apply strictAntiOn_of_deriv_neg (convex_Icc T0 T1) (hc _)
    intro x hx; rw [interior_Icc] at hx
    rw [(W2_hasDerivAt x).deriv, ← Phi_pJ_after hx.1]
    exact mul_neg_of_pos_of_neg (by positivity) (hneg x hx.1 hx.2)
  have hM : StrictMonoOn (fun T => v2 (exp (-T))) (Ici T1) := by
    apply strictMonoOn_of_deriv_pos (convex_Ici T1) (hc _)
    intro x hx; rw [interior_Ici] at hx
    rw [(W2_hasDerivAt x).deriv, ← Phi_pJ_after (lt_trans hT01 hx)]
    exact mul_pos (by positivity) (hpos x hx)
  have hAV : StrictAntiOn (V ρJ pJ) (Icc T0 T1) := by
    intro a ha b hb hab
    rw [V_pJ_after ha.1, V_pJ_after hb.1]; exact hA ha hb hab
  have hMV : StrictMonoOn (V ρJ pJ) (Ici T1) := by
    intro a ha b hb hab
    rw [V_pJ_after (hT01.le.trans ha), V_pJ_after (hT01.le.trans hb)]; exact hM ha hb hab
  refine ⟨T1, hT01, hz, hAV, ?_, hMV, p33_jump_kink_optimum.2.2.2.2.2.2.1⟩
  filter_upwards [mem_nhdsWithin_of_mem_nhds (Ioi_mem_nhds hT01), self_mem_nhdsWithin]
    with T hT hne
  rcases lt_or_gt_of_ne (show T ≠ T1 from hne) with h | h
  · exact hAV ⟨hT.le, h.le⟩ ⟨hT01.le, le_rfl⟩ h
  · exact hMV (mem_Ici.2 le_rfl) (mem_Ici.2 h.le) h

/-! ## P36: the κ_pre partial of the paper's `Φ̃` is `−gΠ′`, and it can be zero

Fix round 1 (observers OBS-GAP2 Opus 2, Sol 1). Seat L5's `Release.p11v_kpre_partial` is the
derivative of the date-coordinate `Φ`. The paper's claim at line 1134 is about the
lead-coordinate `Φ̃`, defined there, so `Φ̃` is defined here as the paper writes it. -/

/-- The paper's lead-coordinate stopping function (line 1134):
`Φ̃(g) = F + λZ + ρ(g) − (r+λ)Π(g+Δ) − κ_pre·g·Π′(g+Δ)`, with `Π′` the derivative of the
defined `Π`. -/
noncomputable def Phitil (ρ : ℝ → ℝ) (p : Prm) (g : ℝ) : ℝ :=
  p.F + p.lam * p.Z + ρ g - (p.r + p.lam) * Pi ρ p.r p.kpost (g + p.Δ) -
    p.kpre * g * deriv (Pi ρ p.r p.kpost) (g + p.Δ)

/-- **P36, the identity (line 1134).** At every lead `g`, `∂Φ̃/∂κ_pre = −gΠ′(g + Δ)`. Its
content is algebraic: `Π` does not depend on `κ_pre`, so `Φ̃` is affine in `κ_pre`. -/
theorem p36_kpre_partial_lead (ρ : ℝ → ℝ) (p : Prm) (g : ℝ) :
    HasDerivAt (fun k => Phitil ρ { p with kpre := k } g)
      (-(g * deriv (Pi ρ p.r p.kpost) (g + p.Δ))) p.kpre := by
  have e : (fun k => Phitil ρ { p with kpre := k } g) = fun k =>
      (p.F + p.lam * p.Z + ρ g - (p.r + p.lam) * Pi ρ p.r p.kpost (g + p.Δ)) -
        k * (g * deriv (Pi ρ p.r p.kpost) (g + p.Δ)) := by
    funext k; simp only [Phitil]; ring
  rw [e]
  have h := ((hasDerivAt_id p.kpre).mul_const (g * deriv (Pi ρ p.r p.kpost) (g + p.Δ))).const_sub
    (p.F + p.lam * p.Z + ρ g - (p.r + p.lam) * Pi ρ p.r p.kpost (g + p.Δ))
  simpa using h

/-- `Π = ρ/r` when there is no post-release copying (`κ_post = 0`), from the integral. -/
theorem Pi_kpost_zero (ρ : ℝ → ℝ) {r : ℝ} (hr : 0 < r) (x : ℝ) : Pi ρ r 0 x = ρ x / r := by
  unfold Pi
  have e : ∀ s : ℝ, exp (-r * s) * ρ (x * exp (-0 * s)) = ρ x * exp (-r * s) := by
    intro s; simp [mul_comm]
  simp_rw [e]
  rw [MeasureTheory.integral_const_mul, integral_exp_mul_Ioi (by linarith) 0]
  simp only [mul_zero, exp_zero]
  field_simp

/-- The counterexample's rent: `ρ(x) = (x − 2)³ + 8`, strictly increasing, `C^∞`, `ρ(0) = 0`. -/
noncomputable def ρC (x : ℝ) : ℝ := (x - 2) ^ 3 + 8

/-- The counterexample's primitives: `r = λ = κ_pre = Δ = 1`, `κ_post = Z = 0`, `F = 9`,
`g₀ = 11/10`. `κ_post = 0` is admissible: the paper treats it (P11 proof, "When `κ_post = 0`,
`Π = ρ/r`", and its own saturating example), and part (v) then needs `ρ ∈ C²`. -/
noncomputable def pC : Prm :=
  { r := 1, lam := 1, F := 9, Z := 0, kpre := 1, kpost := 0, g0 := 11/10, Δ := 1 }

/-- The crossing date `T* = ln(11/10)`, where the lead is `G* = 1`. -/
noncomputable def TC : ℝ := Real.log (11/10)

/-- `Φ̃` in the counterexample, through the lead: `−4g³ + 6g² + 3g − 5 = (g − 1)(5 + 2g − 4g²)`. -/
noncomputable def φC (g : ℝ) : ℝ := -4 * g ^ 3 + 6 * g ^ 2 + 3 * g - 5

theorem ρC_hasDerivAt (y : ℝ) : HasDerivAt ρC (3 * (y - 2) ^ 2) y := by
  have h := (((hasDerivAt_id' y).sub_const 2).pow 3).add_const 8
  unfold ρC; convert h using 1; norm_num

theorem PiC : Pi ρC pC.r pC.kpost = ρC := by
  funext x; rw [show pC.r = 1 from rfl, show pC.kpost = 0 from rfl, Pi_kpost_zero ρC one_pos]
  simp

theorem lead_pC (T : ℝ) : lead pC T = 11/10 * exp (-T) := by simp [lead, pC]

theorem lead_pC_TC : lead pC TC = 1 := by
  rw [lead_pC, TC, exp_neg, exp_log (by norm_num)]; norm_num

theorem TC_pos : 0 < TC := Real.log_pos (by norm_num)

theorem Phitil_pC (g : ℝ) : Phitil ρC pC g = φC g := by
  unfold Phitil
  rw [PiC, (ρC_hasDerivAt _).deriv]
  simp only [ρC, φC, show pC.F = 9 from rfl, show pC.lam = 1 from rfl, show pC.Z = 0 from rfl,
    show pC.r = 1 from rfl, show pC.kpre = 1 from rfl, show pC.Δ = 1 from rfl]
  ring

theorem J_pC : J ρC pC = fun T => ρC (lead pC T + 1) := by
  funext T; simp only [J, PiC]; rfl

theorem J_pC_hasDerivAt (T : ℝ) :
    HasDerivAt (J ρC pC) (3 * (lead pC T + 1 - 2) ^ 2 * (-1 * lead pC T)) T := by
  rw [J_pC]
  have h := (ρC_hasDerivAt (lead pC T + 1)).comp T ((lead_hasDerivAt pC T).add_const 1)
  convert h using 1
  · rfl
  · rw [show pC.kpre = 1 from rfl]

/-- **The defined `Φ` is `Φ̃` at the lead**: `Φ(T) = φC(g(T))`. -/
theorem Phi_pC (T : ℝ) : Phi ρC pC T = φC (lead pC T) := by
  unfold Phi
  rw [(J_pC_hasDerivAt T).deriv, J_pC]
  simp only [ρC, φC, show pC.F = 9 from rfl, show pC.lam = 1 from rfl, show pC.Z = 0 from rfl,
    show pC.r = 1 from rfl]
  ring

theorem holdIntegrand_pC_continuous : Continuous (holdIntegrand ρC pC) := by
  unfold holdIntegrand ρC lead; fun_prop

/-- **`V′ = e^{−(r+λ)T}Φ(T)`** in the counterexample, for the defined `V` and `Φ`. -/
theorem V_pC_hasDerivAt (T : ℝ) :
    HasDerivAt (V ρC pC) (exp (-(pC.r + pC.lam) * T) * Phi ρC pC T) T := by
  have hcont := holdIntegrand_pC_continuous
  have h1 := intervalIntegral.integral_hasDerivAt_right (a := 0) (b := T)
    (hcont.intervalIntegrable _ _) (hcont.stronglyMeasurableAtFilter _ _) hcont.continuousAt
  have hJ := J_pC_hasDerivAt T
  have h2 : HasDerivAt (fun T => exp (-(pC.r + pC.lam) * T))
      (exp (-(pC.r + pC.lam) * T) * (-(pC.r + pC.lam))) T := by
    have := ((hasDerivAt_id T).const_mul (-(pC.r + pC.lam))).exp
    simpa [mul_comm] using this
  have h := h1.add (h2.mul hJ)
  unfold V
  refine h.congr_deriv ?_
  unfold Phi holdIntegrand
  rw [hJ.deriv]
  ring

/-- Sign of `Φ` in the counterexample: positive before `T*`, negative after (on `[0, ∞)`). -/
theorem Phi_pC_sign :
    (∀ T, 0 ≤ T → T < TC → 0 < Phi ρC pC T) ∧ (∀ T, TC < T → Phi ρC pC T < 0) := by
  have hanti : ∀ T T', T < T' → lead pC T' < lead pC T := fun T T' h => by
    rw [lead_pC, lead_pC]
    exact mul_lt_mul_of_pos_left (exp_lt_exp.2 (by linarith)) (by norm_num)
  have hfac : ∀ g, φC g = (g - 1) * (5 + 2 * g - 4 * g ^ 2) := fun g => by unfold φC; ring
  refine ⟨fun T hT hlt => ?_, fun T hlt => ?_⟩
  · have h1 : 1 < lead pC T := by have := hanti T TC hlt; rwa [lead_pC_TC] at this
    have h2 : lead pC T ≤ 11/10 := by
      rw [lead_pC]; have : exp (-T) ≤ 1 := exp_le_one_iff.2 (by linarith); nlinarith
    rw [Phi_pC, hfac]
    apply mul_pos (by linarith); nlinarith
  · have h1 : lead pC T < 1 := by have := hanti TC T hlt; rwa [lead_pC_TC] at this
    have h0 : 0 < lead pC T := by rw [lead_pC]; positivity
    rw [Phi_pC, hfac]
    apply mul_neg_of_neg_of_pos (by linarith); nlinarith

/-- **P36 refuted as worded (line 1134): `∂Φ̃/∂κ_pre = −gΠ′ < 0` can fail at an admissible
interior optimum.** With `ρ(x) = (x − 2)³ + 8` (strictly increasing, smooth, `ρ(0) = 0`),
`r = λ = κ_pre = Δ = 1`, `κ_post = Z = 0`, `F = 9` and `g₀ = 11/10`:
* `Φ` crosses zero once, from above and simply (`∂Φ/∂T = −3`), at `T* = ln(11/10) > 0`, where
  the lead is `G* = 1` and `Φ̃(G*) = 0`;
* `T*` is the strict global optimum of the defined `V` over `[0, ∞)`, and every limit of `V` at
  `∞` lies strictly below `V(T*)`;
* yet `∂Φ̃/∂κ_pre = −G*Π′(G* + Δ) = −ρ′(2) = 0`, so the strict inequality fails.
The identity `∂Φ̃/∂κ_pre = −gΠ′` holds (`p36_kpre_partial_lead`). With `Π′ ≥ 0` the paper's
conclusion "release comes sooner" survives through the date-scaling term
(`Release.p11v_kpre_earlier`). The inputs are chosen; they are not the paper's. -/
theorem p36_kpre_not_strict :
    ρC 0 = 0 ∧ StrictMono ρC ∧ ContDiff ℝ 2 ρC ∧
    0 < TC ∧ lead pC TC = 1 ∧ Phitil ρC pC (lead pC TC) = 0 ∧ Phi ρC pC TC = 0 ∧
    HasDerivAt (Phi ρC pC) (-3) TC ∧
    (∀ T, 0 ≤ T → T ≠ TC → V ρC pC T < V ρC pC TC) ∧
    (∀ L, Tendsto (V ρC pC) atTop (𝓝 L) → L < V ρC pC TC) ∧
    HasDerivAt (fun k => Phitil ρC { pC with kpre := k } (lead pC TC)) 0 pC.kpre ∧
    ¬ (-(lead pC TC * deriv (Pi ρC pC.r pC.kpost) (lead pC TC + pC.Δ)) < 0) := by
  have hd := V_pC_hasDerivAt
  have hcont : Continuous (V ρC pC) := continuous_iff_continuousAt.2 fun T => (hd T).continuousAt
  obtain ⟨hpos, hneg⟩ := Phi_pC_sign
  have hup : StrictMonoOn (V ρC pC) (Icc 0 TC) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc 0 TC) hcont.continuousOn
    intro x hx; rw [interior_Icc] at hx
    rw [(hd x).deriv]; exact mul_pos (exp_pos _) (hpos x hx.1.le hx.2)
  have hdown : StrictAntiOn (V ρC pC) (Ici TC) := by
    apply strictAntiOn_of_deriv_neg (convex_Ici TC) hcont.continuousOn
    intro x hx; rw [interior_Ici] at hx
    rw [(hd x).deriv]; exact mul_neg_of_pos_of_neg (exp_pos _) (hneg x hx)
  have hP' : deriv (Pi ρC pC.r pC.kpost) (lead pC TC + pC.Δ) = 0 := by
    rw [PiC, (ρC_hasDerivAt _).deriv, lead_pC_TC, show pC.Δ = 1 from rfl]; norm_num
  refine ⟨by norm_num [ρC], ?_, ?_, TC_pos, lead_pC_TC, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro x y h
    have : (x - 2) ^ 3 < (y - 2) ^ 3 := Odd.strictMono_pow (by decide) (by linarith)
    unfold ρC; linarith
  · unfold ρC; fun_prop
  · rw [lead_pC_TC, Phitil_pC]; norm_num [φC]
  · rw [Phi_pC, lead_pC_TC]; norm_num [φC]
  · have hf : Phi ρC pC = fun T => φC (lead pC T) := funext Phi_pC
    rw [hf]
    have hφ : HasDerivAt φC 3 (lead pC TC) := by
      rw [lead_pC_TC]
      have h := ((((hasDerivAt_pow 3 (1:ℝ)).const_mul (-4)).add
        ((hasDerivAt_pow 2 (1:ℝ)).const_mul 6)).add ((hasDerivAt_id' (1:ℝ)).const_mul 3)).sub_const 5
      unfold φC; convert h using 1; norm_num
    have := hφ.comp TC (lead_hasDerivAt pC TC)
    rw [lead_pC_TC] at this
    convert this using 1
    · rfl
    · rw [show pC.kpre = 1 from rfl]; norm_num
  · intro T hT hne
    rcases lt_or_gt_of_ne hne with h | h
    · exact hup ⟨hT, h.le⟩ ⟨TC_pos.le, le_rfl⟩ h
    · exact hdown (le_refl TC) h.le h
  · intro L hL
    have hle : L ≤ V ρC pC (TC + 1) := le_of_tendsto hL (eventually_atTop.2 ⟨TC + 1,
      fun T hT => hdown.antitoneOn (show TC ≤ TC + 1 by linarith) (show TC ≤ T by linarith) hT⟩)
    exact hle.trans_lt (hdown (le_refl TC) (show TC ≤ TC + 1 by linarith)
      (show TC < TC + 1 by linarith))
  · have h := p36_kpre_partial_lead ρC pC (lead pC TC)
    rw [hP', mul_zero, neg_zero] at h
    exact h
  · rw [hP']; simp

/-! ## B106: the degenerate edge (fix round 1) -/

/-- **B106, the zero-length exposure.** If onset and end coincide (`a = b`), shifting both by
`δ` leaves discounted exposure unchanged (both integrals are 0). So "discounted exposure falls"
needs an exposure of positive length, `a < b`, which `Hold.p7_shift_discount` assumes. -/
theorem b106_zero_length (a δ r : ℝ) :
    (∫ t in (a + δ)..(a + δ), exp (-r * t)) = ∫ t in a..a, exp (-r * t) := by simp

end RTTR.Gaps2

/-! ## Axioms audit -/

#print axioms RTTR.Gaps2.b132_stochastic_order
#print axioms RTTR.Gaps2.b132_pathwise
#print axioms RTTR.Gaps2.b86_rice_range
#print axioms RTTR.Gaps2.b86_rice_domain
#print axioms RTTR.Gaps2.b8_toy_no_wind
#print axioms RTTR.Gaps2.b8_toy_tailwind
#print axioms RTTR.Gaps2.lead_hasDerivAt
#print axioms RTTR.Gaps2.comp_statics
#print axioms RTTR.Gaps2.flow_hazard_partial
#print axioms RTTR.Gaps2.b158_theft_hazard_sooner_iff
#print axioms RTTR.Gaps2.b158_theft_flow_later_iff
#print axioms RTTR.Gaps2.b162_contract_later_iff
#print axioms RTTR.Gaps2.sqrt_exp_half
#print axioms RTTR.Gaps2.Pi_sqrt
#print axioms RTTR.Gaps2.lead_nonneg
#print axioms RTTR.Gaps2.J_sqrt
#print axioms RTTR.Gaps2.J_sqrt_hasDerivAt
#print axioms RTTR.Gaps2.Phi_sqrt
#print axioms RTTR.Gaps2.holdIntegrand_sqrt_continuous
#print axioms RTTR.Gaps2.V_sqrt_hasDerivAt
#print axioms RTTR.Gaps2.V_sqrt_strict_max
#print axioms RTTR.Gaps2.p96_Phi
#print axioms RTTR.Gaps2.φ96_hasDerivAt
#print axioms RTTR.Gaps2.φ96'_pos
#print axioms RTTR.Gaps2.φ96_cont
#print axioms RTTR.Gaps2.φ96_strictMono
#print axioms RTTR.Gaps2.φ96_one
#print axioms RTTR.Gaps2.φ96'_one
#print axioms RTTR.Gaps2.lead_p96
#print axioms RTTR.Gaps2.lead_p96_log
#print axioms RTTR.Gaps2.p96_crossing
#print axioms RTTR.Gaps2.p96_optimum
#print axioms RTTR.Gaps2.pk_Phi
#print axioms RTTR.Gaps2.pk_one
#print axioms RTTR.Gaps2.pk_kappa_partial
#print axioms RTTR.Gaps2.pk_joint_diff
#print axioms RTTR.Gaps2.zero_displacement
#print axioms RTTR.Gaps2.a96_common_kappa_either_sign
#print axioms RTTR.Gaps2.T0_pos
#print axioms RTTR.Gaps2.integral_exp_neg_interval
#print axioms RTTR.Gaps2.le_mul_exp_neg_iff
#print axioms RTTR.Gaps2.Pi_jump
#print axioms RTTR.Gaps2.lead_pJ
#print axioms RTTR.Gaps2.lead_pJ_pos
#print axioms RTTR.Gaps2.lead_pJ_T0
#print axioms RTTR.Gaps2.lead_pJ_ge_one_iff
#print axioms RTTR.Gaps2.J_pJ
#print axioms RTTR.Gaps2.J_pJ_hasDerivAt
#print axioms RTTR.Gaps2.Phi_pJ
#print axioms RTTR.Gaps2.Φplus_cont
#print axioms RTTR.Gaps2.Φminus_cont
#print axioms RTTR.Gaps2.p33_Phi_jump
#print axioms RTTR.Gaps2.p33_Phi_pos_before
#print axioms RTTR.Gaps2.holdIntegrand_pJ
#print axioms RTTR.Gaps2.integral_indicator_T0
#print axioms RTTR.Gaps2.V_pJ
#print axioms RTTR.Gaps2.exp_pow_eq
#print axioms RTTR.Gaps2.V_pJ_before
#print axioms RTTR.Gaps2.exp_neg_two_T0
#print axioms RTTR.Gaps2.V_pJ_after
#print axioms RTTR.Gaps2.exp_neg_T0
#print axioms RTTR.Gaps2.p33_jump_kink_optimum
#print axioms RTTR.Gaps2.W13_hasDerivAt
#print axioms RTTR.Gaps2.Ar_four
#print axioms RTTR.Gaps2.c13_discount_either_direction
#print axioms RTTR.Gaps2.p33_dPhi_dg
#print axioms RTTR.Gaps2.φc_strictAnti
#print axioms RTTR.Gaps2.p33_Phi_after
#print axioms RTTR.Gaps2.b132_coupling_law
#print axioms RTTR.Gaps2.b132_pathwise_ext
#print axioms RTTR.Gaps2.b86_domain_re
#print axioms RTTR.Gaps2.p33_Phi_ge_start
#print axioms RTTR.Gaps2.p36_kpre_partial_lead
#print axioms RTTR.Gaps2.Pi_kpost_zero
#print axioms RTTR.Gaps2.ρC_hasDerivAt
#print axioms RTTR.Gaps2.PiC
#print axioms RTTR.Gaps2.lead_pC
#print axioms RTTR.Gaps2.lead_pC_TC
#print axioms RTTR.Gaps2.TC_pos
#print axioms RTTR.Gaps2.Phitil_pC
#print axioms RTTR.Gaps2.J_pC
#print axioms RTTR.Gaps2.J_pC_hasDerivAt
#print axioms RTTR.Gaps2.Phi_pC
#print axioms RTTR.Gaps2.holdIntegrand_pC_continuous
#print axioms RTTR.Gaps2.V_pC_hasDerivAt
#print axioms RTTR.Gaps2.Phi_pC_sign
#print axioms RTTR.Gaps2.p36_kpre_not_strict
#print axioms RTTR.Gaps2.vgen_hasDerivAt
#print axioms RTTR.Gaps2.W1_hasDerivAt
#print axioms RTTR.Gaps2.W2_hasDerivAt
#print axioms RTTR.Gaps2.Phi_pJ_before
#print axioms RTTR.Gaps2.Phi_pJ_after
#print axioms RTTR.Gaps2.p33_Phi_rises_before
#print axioms RTTR.Gaps2.p33_V_deriv
#print axioms RTTR.Gaps2.p33_V_rises_before
#print axioms RTTR.Gaps2.p33_V_after_shape
#print axioms RTTR.Gaps2.b106_zero_length
