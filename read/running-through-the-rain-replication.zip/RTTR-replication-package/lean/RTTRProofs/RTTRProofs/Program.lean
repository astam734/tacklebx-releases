import Mathlib

/-!
# RTTR v8, sub-model Program: Propositions 12–15 (seat L6)

Statements: `PAPER-DRAFT-v8.md` lines 991–1013 (P12–P15), proofs A.6 lines 1136–1142, numbers
A.6 table lines 1109–1112.  Main text §8.4 (402–412) and lines 60–68.

## Modelling choices (how each paper object is represented, and why that is faithful)

* **Present values are integrals.**  "A unit flow eroding at rate κ is worth …" is the Bochner
  integral `∫₀^∞ e^{-rt} e^{-κt} dt` (`erodingValue`); the non-eroding value is `∫₀^∞ e^{-rt} dt`
  (`nonErodingValue`); the closed forms are proved, never assumed (faithfulness rule 1).  At `r = 0`
  the non-eroding value is the extended nonnegative (`lintegral`) integral, which is `⊤`.
* **Power rents** are P11's `ρ(x) = M x^η` (`Real.rpow`), applied to the lead `x₀e^{-κt}`.
* **Hold values (P13, P14)** are P11 (i)'s survival-weighted value with no release date
  (`T = ∞`): `holdValue r λ F Z = ∫₀^∞ e^{-(r+λ)t}(F + λZ) dt`.  `holdValue_eq_expectation`
  proves this equals the expectation over an exponential loss time `L` (density `λe^{-λl}`) of
  `∫₀^L e^{-rt}F dt + e^{-rL}Z`, which is how the paper derives it (proof of P11, line 1134).
  A use with flow `f` and added hazard `δ` is the same object with `F ↦ F + f`, `λ ↦ λ + δ`, `Z`
  unchanged (the paper's "unchanged by the use").
* **"Raises the hold value"** is strict inequality of these values.
* **The live-release option (P13 (iii))** uses P11 (i)'s `V(T)` defined as an integral, with the
  release value `Π(x) = ∫₀^∞ e^{-rs}ρ(xe^{-κ_post s})ds` (`releaseValueLin`) under linear rents,
  `Z = 0`; holding until loss is `noReleaseValueLin`.  The paper's own example is power-rent and
  transcendental; its no-release values are certified here, its optimal values are NUMERICAL, and the
  existential claim "the rule can approve a use that lowers the optimal value" is certified by
  an exact instance chosen here (`p13_live_rule_approves_yet_lowers_optimum`).
* **Optimal value (P13's optional use).**  The supremum over P11's candidate set: release dates
  `T ≥ 0` and holding until loss (`optSetLin`).  An optional use enlarges the candidate set by the
  with-use plans; the boundedness that `sSup` needs is proved, not assumed.
* **P14's liminf** is represented both as `EventuallyProportional`
  (`∃ ε > 0, ∃ M > 0, ∀ F ≥ M, εF ≤ λ_θ(F)`) and as `0 < liminf (λ_θ(F)/F)` taken in `EReal`, so
  that `+∞` is allowed and no boundedness of `λ_θ(F)/F` is assumed; `p14_liminf_iff` proves the
  two are equivalent.  "Bounded over `F ≥ 0`" is `∃ B, ∀ F ≥ 0, |V F| ≤ B`.
* **Theft on value** is the fixed-point equation `V = F/(a + θV)`; its nonnegative solutions are
  characterized exactly, and "grows like `√(F/θ)`" is `Tendsto (V/√(F/θ)) atTop (𝓝 1)`.
* **Bought security**: theft hazard `θ₀e^{-σ}F`, security `σ ≥ 0` bought at one-off cost `kσ`
  subtracted from the hold value (the replication code's specification, `check_model.py` line 1360).
* **Contests.**  A10's two-player Tullock contest with equal split at zero total effort
  (`share`, `tullockPayoff`, catastrophe index `Lθ·X` borne by each racer).  Equilibrium
  claims are proved as best-response inequalities over all deviations `x ≥ 0`
  (`tullock_nash`).  Uniqueness of the pure equilibrium is P9 (seat L4), not re-proved here.
* **P15's valuation** is `∫₀^∞ e^{-rt}[(1−d)e^{-κt} + d] dt` (`stepValue`): a share `d` of each
  unit of step earnings is a perpetual non-eroding component from the start, as the paper states.
* **P15 (c)**: each firm's payoff is `D_s p_s + D_d p_d − k(a+b)²/2` with Tullock shares, no
  private catastrophe cost (`twoContestPayoff`).  The symmetric profile given by the paper's
  formulas is proved to be a Nash equilibrium over all joint deviations `(a, b) ≥ 0`, to satisfy
  both first-order conditions (`HasDerivAt … 0`), and to be the only positive symmetric profile
  that does.  Total risk `θ_s X_s + θ_d X_d` with `X = 2x` is differentiated as defined.
-/

open MeasureTheory Set Real Filter Topology

namespace RTTR.Program

/-! ## Shared integrals -/

/-- `∫₀^∞ e^{-kt} dt = 1/k` for `k > 0`. -/
theorem integral_exp_neg_mul_Ioi_zero {k : ℝ} (hk : 0 < k) :
    ∫ t in Ioi (0:ℝ), Real.exp (-k * t) = 1 / k := by
  have h := integral_exp_mul_Ioi (a := -k) (by linarith) 0
  rw [h]
  simp

/-- `∫₀^T e^{-kt} dt = (1 - e^{-kT})/k` for `k ≠ 0`. -/
theorem integral_exp_neg_mul_interval {k : ℝ} (hk : k ≠ 0) (T : ℝ) :
    ∫ t in (0:ℝ)..T, Real.exp (-k * t) = (1 - Real.exp (-k * T)) / k := by
  have hd : ∀ x ∈ uIcc (0:ℝ) T,
      HasDerivAt (fun t => Real.exp (-k * t) / (-k)) (Real.exp (-k * x)) x := by
    intro x _
    have h1 : HasDerivAt (fun t => -k * t) (-k) x := by
      simpa using (hasDerivAt_id x).const_mul (-k)
    have h3 := h1.exp.div_const (-k)
    convert h3 using 1
    field_simp
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hd
    (by apply Continuous.intervalIntegrable; fun_prop)]
  simp
  field_simp
  ring

/-! ## The two-player Tullock contest (A10), used by P12's separate contests and P15 -/

/-- Win share with an equal split at zero total effort (A10). -/
noncomputable def share (x y : ℝ) : ℝ := if x + y = 0 then 1 / 2 else x / (x + y)

/-- A racer's payoff in A10's contest: win value `vW`, lose value `vL`, unit cost `c`, and the
catastrophe index `Lθ·(x + y)` that every racer bears. -/
noncomputable def tullockPayoff (vW vL c Lθ x y : ℝ) : ℝ :=
  share x y * vW + (1 - share x y) * vL - c * x - Lθ * (x + y)

/-- P9's symmetric effort `Δv/(4ĉ)`. -/
noncomputable def contestEffort (Δv ch : ℝ) : ℝ := Δv / (4 * ch)

theorem share_self {x : ℝ} (hx : 0 < x) : share x x = 1 / 2 := by
  unfold share
  rw [if_neg (by linarith)]
  field_simp
  ring

/-- Tangent-line (concavity) bound on the share: `a/(a+y) ≤ 1/2 + (a-y)/(4y)`. -/
theorem share_tangent {a y : ℝ} (ha : 0 ≤ a) (hy : 0 < y) :
    share a y ≤ 1 / 2 + (a - y) / (4 * y) := by
  unfold share
  rw [if_neg (by linarith)]
  have key : 1 / 2 + (a - y) / (4 * y) - a / (a + y) = (a - y) ^ 2 / (4 * y * (a + y)) := by
    field_simp
    ring
  have : 0 ≤ (a - y) ^ 2 / (4 * y * (a + y)) := by positivity
  linarith

/-- The share's derivative in own effort at the symmetric point: `1/(4y)`. -/
theorem hasDerivAt_share_self {y : ℝ} (hy : 0 < y) :
    HasDerivAt (fun a => share a y) (1 / (4 * y)) y := by
  have h : HasDerivAt (fun a => a / (a + y)) ((1 * (y + y) - y * 1) / (y + y) ^ 2) y :=
    (hasDerivAt_id y).div ((hasDerivAt_id y).add_const y) (by simp; linarith)
  have heq : (fun a => share a y) =ᶠ[𝓝 y] fun a => a / (a + y) := by
    filter_upwards [Ioi_mem_nhds hy] with a ha
    simp only [mem_Ioi] at ha
    simp only [share]
    rw [if_neg (by linarith)]
  convert h.congr_of_eventuallyEq heq using 1
  field_simp
  ring

/-- The symmetric profile `x* = Δv/(4ĉ)` is a Nash equilibrium of A10's contest: no deviation
`x ≥ 0` beats it.  (Uniqueness is P9, seat L4.) -/
theorem tullock_nash {vW vL c Lθ : ℝ} (hΔ : 0 < vW - vL) (hc : 0 < c + Lθ) (x : ℝ)
    (hx : 0 ≤ x) :
    tullockPayoff vW vL c Lθ x (contestEffort (vW - vL) (c + Lθ))
      ≤ tullockPayoff vW vL c Lθ (contestEffort (vW - vL) (c + Lθ))
          (contestEffort (vW - vL) (c + Lθ)) := by
  set y := contestEffort (vW - vL) (c + Lθ) with hy
  have hypos : 0 < y := by rw [hy, contestEffort]; positivity
  have ht := share_tangent hx hypos
  unfold tullockPayoff
  rw [share_self hypos]
  have hΔeq : vW - vL = 4 * (c + Lθ) * y := by rw [hy, contestEffort]; field_simp
  have e1 : share x y * vW + (1 - share x y) * vL = vL + share x y * (vW - vL) := by ring
  rw [e1]
  have h2 : share x y * (vW - vL) ≤ (1 / 2 + (x - y) / (4 * y)) * (vW - vL) :=
    mul_le_mul_of_nonneg_right ht hΔ.le
  have h3 : (1 / 2 + (x - y) / (4 * y)) * (vW - vL) = (vW - vL) / 2 + (c + Lθ) * (x - y) := by
    rw [hΔeq]
    field_simp
  nlinarith

/-- With no prize gap, zero effort is an equilibrium. -/
theorem tullock_nash_zero_prize {v c Lθ : ℝ} (hc : 0 ≤ c + Lθ) (x : ℝ) (hx : 0 ≤ x) :
    tullockPayoff v v c Lθ x 0 ≤ tullockPayoff v v c Lθ 0 0 := by
  unfold tullockPayoff
  have e : ∀ s : ℝ, s * v + (1 - s) * v = v := fun s => by ring
  rw [e, e]
  nlinarith

/-! ## P12, perishability and the decisive prize -/

/-- Value of a unit flow eroding at rate `κ`, discounted at `r`: `∫₀^∞ e^{-rt} e^{-κt} dt`. -/
noncomputable def erodingValue (r κ : ℝ) : ℝ :=
  ∫ t in Ioi (0:ℝ), Real.exp (-r * t) * Real.exp (-κ * t)

/-- Value of a non-eroding unit flow: `∫₀^∞ e^{-rt} dt`. -/
noncomputable def nonErodingValue (r : ℝ) : ℝ := ∫ t in Ioi (0:ℝ), Real.exp (-r * t)

/-- **P12.** A unit flow eroding at `κ` is worth `1/(r+κ)`. -/
theorem p12_eroding_value {r κ : ℝ} (h : 0 < r + κ) : erodingValue r κ = 1 / (r + κ) := by
  unfold erodingValue
  have : (fun t : ℝ => Real.exp (-r * t) * Real.exp (-κ * t))
      = fun t => Real.exp (-(r + κ) * t) := by
    funext t
    rw [← Real.exp_add]
    ring_nf
  rw [this, integral_exp_neg_mul_Ioi_zero h]

/-- **P12.** A non-eroding unit flow is worth `1/r` for `r > 0`. -/
theorem p12_nonEroding_value {r : ℝ} (hr : 0 < r) : nonErodingValue r = 1 / r :=
  integral_exp_neg_mul_Ioi_zero hr

/-- **P12 (proof, line 1136).** At `r = 0` the non-eroding value is infinite (extended
nonnegative integral). -/
theorem p12_nonEroding_infinite_at_zero :
    ∫⁻ t in Ioi (0:ℝ), ENNReal.ofReal (Real.exp (-0 * t)) = ⊤ := by
  simp [Real.volume_Ioi]

/-- **P12.** The ratio of the two values is `(r+κ)/r`. -/
theorem p12_ratio_eq {r κ : ℝ} (hr : 0 < r) (h : 0 < r + κ) :
    nonErodingValue r / erodingValue r κ = (r + κ) / r := by
  rw [p12_nonEroding_value hr, p12_eroding_value h]
  field_simp

/-- **P12.** The ratio rises (strictly) in `κ ≥ 0`. -/
theorem p12_ratio_strictMono {r : ℝ} (hr : 0 < r) :
    StrictMonoOn (fun κ => nonErodingValue r / erodingValue r κ) (Ici 0) := by
  intro a ha b hb hab
  simp only [mem_Ici] at ha hb
  simp only
  rw [p12_ratio_eq hr (by linarith), p12_ratio_eq hr (by linarith)]
  exact div_lt_div_of_pos_right (by linarith) hr

/-- **P12, plain terms (line 991).** A lead that others copy (`κ > 0`) is worth less than one
they cannot. -/
theorem p12_copied_worth_less {r κ : ℝ} (hr : 0 < r) (hκ : 0 < κ) :
    erodingValue r κ < nonErodingValue r := by
  rw [p12_eroding_value (by linarith), p12_nonEroding_value hr]
  exact one_div_lt_one_div_of_lt hr (by linarith)

/-- **P12, "as first stated".** Under P11's power rent `ρ(x) = M x^η`, a lead eroding at `κ`
yields revenue eroding at `ηκ`. -/
theorem p12_power_rent_revenue {M x₀ η κ t : ℝ} (hx : 0 ≤ x₀) :
    M * (x₀ * Real.exp (-κ * t)) ^ η = M * x₀ ^ η * Real.exp (-(η * κ) * t) := by
  rw [Real.mul_rpow hx (Real.exp_pos _).le, ← Real.exp_mul]
  ring_nf

/-- **P12, "as first stated".** … worth `M x₀^η/(r + ηκ)`. -/
theorem p12_power_rent_value {r M x₀ η κ : ℝ} (hx : 0 ≤ x₀) (h : 0 < r + η * κ) :
    ∫ t in Ioi (0:ℝ), Real.exp (-r * t) * (M * (x₀ * Real.exp (-κ * t)) ^ η)
      = M * x₀ ^ η / (r + η * κ) := by
  have : (fun t : ℝ => Real.exp (-r * t) * (M * (x₀ * Real.exp (-κ * t)) ^ η))
      = fun t => (M * x₀ ^ η) * Real.exp (-(r + η * κ) * t) := by
    funext t
    rw [p12_power_rent_revenue hx, show -(r + η * κ) * t = -r * t + -(η * κ) * t by ring,
      Real.exp_add]
    ring
  rw [this, integral_const_mul, integral_exp_neg_mul_Ioi_zero h]
  ring

/-- **P12, separate contests.** The incremental contest (prize the eroding value, no loss term)
has the equilibrium effort `contestEffort (erodingValue r κ) c`. -/
theorem p12_incremental_nash {r κ c : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) (hc : 0 < c) (x : ℝ)
    (hx : 0 ≤ x) :
    tullockPayoff (erodingValue r κ) 0 c 0 x (contestEffort (erodingValue r κ) c)
      ≤ tullockPayoff (erodingValue r κ) 0 c 0 (contestEffort (erodingValue r κ) c)
          (contestEffort (erodingValue r κ) c) := by
  have hv : 0 < erodingValue r κ - 0 := by
    rw [p12_eroding_value (by linarith), sub_zero]
    exact one_div_pos.2 (by linarith)
  have := tullock_nash (vW := erodingValue r κ) (vL := 0) (c := c) (Lθ := 0) hv (by simpa) x hx
  simpa using this

/-- **P12, separate contests.** Faster copying cuts incremental effort (strictly in `κ ≥ 0`);
the decisive effort `contestEffort D c` has no `κ` argument. -/
theorem p12_incremental_effort_strictAnti {r c : ℝ} (hr : 0 < r) (hc : 0 < c) :
    StrictAntiOn (fun κ => contestEffort (erodingValue r κ) c) (Ici 0) := by
  intro a ha b hb hab
  simp only [mem_Ici] at ha hb
  simp only [contestEffort]
  rw [p12_eroding_value (by linarith), p12_eroding_value (by linarith)]
  apply div_lt_div_of_pos_right _ (by positivity)
  exact one_div_lt_one_div_of_lt (by linarith) (by linarith)

/-- **P12, A.6 table (line 1110).** `r = 0.05`, `c = 1`, decisive prize 5: incremental efforts
`1, 5/11, 5/21` at `κ = 0.2, 0.5, 1.0`, decisive effort `5/4`; and their printed three-decimal
representations 1.000, 0.455, 0.238, 1.250. -/
theorem p12_contest_values :
    contestEffort (erodingValue (1/20) (1/5)) 1 = 1 ∧
    contestEffort (erodingValue (1/20) (1/2)) 1 = 5/11 ∧
    contestEffort (erodingValue (1/20) 1) 1 = 5/21 ∧
    contestEffort 5 1 = 5/4 ∧
    ((0.9995:ℝ) ≤ 1 ∧ (1:ℝ) < 1.0005) ∧
    ((0.4545:ℝ) ≤ 5/11 ∧ (5/11:ℝ) < 0.4555) ∧
    ((0.2375:ℝ) ≤ 5/21 ∧ (5/21:ℝ) < 0.2385) ∧
    ((1.2495:ℝ) ≤ 5/4 ∧ (5/4:ℝ) < 1.2505) := by
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · rw [contestEffort, p12_eroding_value (by norm_num)]; norm_num
  · rw [contestEffort, p12_eroding_value (by norm_num)]; norm_num
  · rw [contestEffort, p12_eroding_value (by norm_num)]; norm_num
  · rw [contestEffort]; norm_num
  · norm_num

/-! ## P13, what to sell while holding -/

/-- Hold value with constant flows, no voluntary release, loss hazard `lam` and continuation
`Z` after loss, in the survival-weighted form of P11 (i) with `T = ∞`:
`∫₀^∞ e^{-(r+λ)t}(F + λZ) dt`. -/
noncomputable def holdValue (r lam F Z : ℝ) : ℝ :=
  ∫ t in Ioi (0:ℝ), Real.exp (-(r + lam) * t) * (F + lam * Z)

theorem holdValue_eq {r lam F Z : ℝ} (h : 0 < r + lam) :
    holdValue r lam F Z = (F + lam * Z) / (r + lam) := by
  unfold holdValue
  rw [integral_mul_const, integral_exp_neg_mul_Ioi_zero h]
  field_simp

/-- The survival form is the expectation over an exponential loss time `L` (density
`λe^{-λl}`): `E[∫₀^L e^{-rt}F dt + e^{-rL}Z]`. -/
theorem holdValue_eq_expectation {r lam F Z : ℝ} (hr : 0 < r) (hl : 0 < lam) :
    ∫ l in Ioi (0:ℝ), lam * Real.exp (-lam * l) *
        ((∫ t in (0:ℝ)..l, Real.exp (-r * t) * F) + Real.exp (-r * l) * Z)
      = holdValue r lam F Z := by
  rw [holdValue_eq (by linarith)]
  have hpt : ∀ l : ℝ, lam * Real.exp (-lam * l) *
      ((∫ t in (0:ℝ)..l, Real.exp (-r * t) * F) + Real.exp (-r * l) * Z)
      = (lam * F / r) * Real.exp (-lam * l)
        + (lam * Z - lam * F / r) * Real.exp (-(lam + r) * l) := by
    intro l
    rw [intervalIntegral.integral_mul_const, integral_exp_neg_mul_interval hr.ne']
    have : Real.exp (-(lam + r) * l) = Real.exp (-lam * l) * Real.exp (-r * l) := by
      rw [← Real.exp_add]
      ring_nf
    rw [this]
    field_simp
    ring
  simp_rw [hpt]
  rw [integral_add, integral_const_mul, integral_const_mul, integral_exp_neg_mul_Ioi_zero hl,
    integral_exp_neg_mul_Ioi_zero (by linarith)]
  · field_simp
    ring
  · exact (exp_neg_integrableOn_Ioi 0 hl).const_mul _
  · exact (exp_neg_integrableOn_Ioi 0 (by linarith)).const_mul _

/-- **P13, general form.** A use with flow `f` and added hazard `δ`, continuation `Z` unchanged
by the use, raises the hold value iff `δ(F − rZ) < f(r+λ)`. -/
theorem p13_general {r lam δ F f Z : ℝ} (h0 : 0 < r + lam) (h1 : 0 < r + (lam + δ)) :
    holdValue r lam F Z < holdValue r (lam + δ) (F + f) Z ↔ δ * (F - r * Z) < f * (r + lam) := by
  rw [holdValue_eq h0, holdValue_eq h1, div_lt_div_iff₀ h0 h1]
  have e : (F + f + (lam + δ) * Z) * (r + lam) - (F + lam * Z) * (r + (lam + δ))
      = f * (r + lam) - δ * (F - r * Z) := by ring
  constructor <;> intro h <;> linarith

/-- **P13, main iff** (no continuation): raises the hold value iff `Fδ < f(r+λ)`. -/
theorem p13_main {r lam δ F f : ℝ} (h0 : 0 < r + lam) (h1 : 0 < r + (lam + δ)) :
    holdValue r lam F 0 < holdValue r (lam + δ) (F + f) 0 ↔ F * δ < f * (r + lam) := by
  rw [p13_general h0 h1]
  constructor <;> intro h <;> linarith

/-- **P13.** For `δ > 0`: `f/δ > F/(r+λ)`. -/
theorem p13_ratio {r lam δ F f : ℝ} (h0 : 0 < r + lam) (hδ : 0 < δ) :
    holdValue r lam F 0 < holdValue r (lam + δ) (F + f) 0 ↔ F / (r + lam) < f / δ := by
  rw [p13_main h0 (by linarith), div_lt_div_iff₀ h0 hδ]

/-- **P13.** For `δ = 0`, any `f > 0` passes. -/
theorem p13_delta_zero {r lam F f : ℝ} (h0 : 0 < r + lam) (hf : 0 < f) :
    holdValue r lam F 0 < holdValue r (lam + 0) (F + f) 0 :=
  (p13_main h0 (by simpa using h0)).2 (by simpa using mul_pos hf h0)

/-- **P13 (i).** `V_H = (F + λZ)/(r+λ)` and the threshold equals `V_H − Z`. -/
theorem p13_i_VH {r lam F Z : ℝ} (h0 : 0 < r + lam) :
    holdValue r lam F Z = (F + lam * Z) / (r + lam) ∧
    (F - r * Z) / (r + lam) = holdValue r lam F Z - Z := by
  refine ⟨holdValue_eq h0, ?_⟩
  rw [holdValue_eq h0]
  field_simp
  ring

/-- **P13 (i).** For `δ > 0`: raises the hold value iff `f/δ > (F − rZ)/(r+λ)`. -/
theorem p13_i_threshold {r lam δ F f Z : ℝ} (h0 : 0 < r + lam) (hδ : 0 < δ) :
    holdValue r lam F Z < holdValue r (lam + δ) (F + f) Z ↔ (F - r * Z) / (r + lam) < f / δ := by
  rw [p13_general h0 (by linarith), div_lt_div_iff₀ h0 hδ]
  constructor <;> intro h <;> linarith

/-- **P13 (i).** For `δ = 0`, any `f > 0` still passes. -/
theorem p13_i_delta_zero {r lam F f Z : ℝ} (h0 : 0 < r + lam) (hf : 0 < f) :
    holdValue r lam F Z < holdValue r (lam + 0) (F + f) Z :=
  (p13_general h0 (by simpa using h0)).2 (by simpa using mul_pos hf h0)

/-- **P13 (ii).** Theft responding to earnings: the use adds hazard `δ + θ f`.  Raises the hold
value iff `F(δ + θf) < f(r+λ)`.  (Content: `p13_main` with the use's own flow inside its
hazard.) -/
theorem p13_ii {r lam δ θ F f : ℝ} (h0 : 0 < r + lam) (h1 : 0 < r + (lam + (δ + θ * f))) :
    holdValue r lam F 0 < holdValue r (lam + (δ + θ * f)) (F + f) 0
      ↔ F * (δ + θ * f) < f * (r + lam) :=
  p13_main h0 h1

/-- **P13 (ii)** with continuation `Z`: iff `(δ + θf)(F − rZ) < f(r+λ)`. -/
theorem p13_ii_Z {r lam δ θ F f Z : ℝ} (h0 : 0 < r + lam)
    (h1 : 0 < r + (lam + (δ + θ * f))) :
    holdValue r lam F Z < holdValue r (lam + (δ + θ * f)) (F + f) Z
      ↔ (δ + θ * f) * (F - r * Z) < f * (r + lam) :=
  p13_general h0 h1

/-- **P13, "as first stated".** Undiscounted (`r = 0`), the threshold is `F/λ`. -/
theorem p13_undiscounted {lam δ F f : ℝ} (hl : 0 < lam) (hδ : 0 < δ) :
    holdValue 0 lam F 0 < holdValue 0 (lam + δ) (F + f) 0 ↔ F / lam < f / δ := by
  have := p13_ratio (r := 0) (lam := lam) (F := F) (f := f) (by simpa using hl) hδ
  simpa using this

/-- **P13, counterexample to "interactive products pass only when the hold is nearly
worthless"** (`r = 0`, `F = 50`, `λ = 1`, `f = 1000`, `δ = 10`): the use passes, and the hold
goes from 50 to `1050/11` (printed 95.45). -/
theorem p13_counter_interactive :
    holdValue 0 1 50 0 = 50 ∧ holdValue 0 (1 + 10) (50 + 1000) 0 = 1050 / 11 ∧
    holdValue 0 1 50 0 < holdValue 0 (1 + 10) (50 + 1000) 0 ∧
    ((95.45:ℝ) ≤ 1050 / 11 ∧ (1050 / 11 : ℝ) < 95.455) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [holdValue_eq (by norm_num)]; norm_num
  · rw [holdValue_eq (by norm_num)]; norm_num
  · rw [holdValue_eq (by norm_num), holdValue_eq (by norm_num)]; norm_num
  · norm_num

/-- **P13, counterexample to "artifacts in distant domains almost always pass"**
(`f = δ = 0.001`, `F/λ = 100`, `r = 0`): the use lowers the hold value, at every `λ > 0`. -/
theorem p13_counter_artifact {lam : ℝ} (hl : 0 < lam) :
    holdValue 0 (lam + 1/1000) (100 * lam + 1/1000) 0 < holdValue 0 lam (100 * lam) 0 := by
  rw [holdValue_eq (by linarith), holdValue_eq (by linarith), div_lt_div_iff₀ (by linarith)
    (by linarith)]
  nlinarith

/-- **P13, the corollaries do not follow from the model (line 1001).**  At any hold value
`F/(r+λ) > 0` and any added hazard `δ > 0`, however small, some uses pass and some fail: the
verdict turns only on `f/δ` against `F/(r+λ)`, which the model does not supply.  "Almost always"
and "nearly worthless" have no formal content without a population of uses, so this
non-implication is what the text can claim. -/
theorem p13_corollaries_undetermined {r lam F δ : ℝ} (h0 : 0 < r + lam) (hF : 0 < F)
    (hδ : 0 < δ) :
    (∃ f > 0, holdValue r lam F 0 < holdValue r (lam + δ) (F + f) 0) ∧
    (∃ f > 0, holdValue r (lam + δ) (F + f) 0 < holdValue r lam F 0) := by
  have h1 : 0 < r + (lam + δ) := by linarith
  have hq : 0 < F * δ / (r + lam) := div_pos (mul_pos hF hδ) h0
  refine ⟨⟨F * δ / (r + lam) + 1, by linarith, (p13_main h0 h1).2 ?_⟩,
    ⟨F * δ / (2 * (r + lam)), div_pos (mul_pos hF hδ) (by linarith), ?_⟩⟩
  · rw [add_mul, div_mul_cancel₀ _ h0.ne']; linarith
  · set f := F * δ / (2 * (r + lam)) with hfdef
    have e : f * (r + lam) = F * δ / 2 := by rw [hfdef]; field_simp
    rw [holdValue_eq h0, holdValue_eq h1, div_lt_div_iff₀ h1 h0]
    nlinarith [mul_pos hF hδ]

/-- **Figure 20(a).** `V_H > Z` iff `F > rZ`. -/
theorem fig20_VH_gt_Z_iff {r lam F Z : ℝ} (h0 : 0 < r + lam) :
    Z < holdValue r lam F Z ↔ r * Z < F := by
  rw [holdValue_eq h0, lt_div_iff₀ h0]
  constructor <;> intro h <;> nlinarith

/-- **Figure 20(a).** If `V_H ≤ Z`, every positive added flow passes for `δ > 0`. -/
theorem fig20_all_pass {r lam δ F f Z : ℝ} (h0 : 0 < r + lam) (hδ : 0 < δ) (hf : 0 < f)
    (hle : holdValue r lam F Z ≤ Z) :
    holdValue r lam F Z < holdValue r (lam + δ) (F + f) Z := by
  rw [p13_i_threshold h0 hδ, (p13_i_VH (F := F) (Z := Z) h0).2]
  have : 0 < f / δ := div_pos hf hδ
  linarith

/-! ### P13 with a live release option: an exact instance -/

/-- Release value under linear rents `ρ(x) = Mx`: `Π(x) = ∫₀^∞ e^{-rs} ρ(x e^{-κ_post s}) ds`. -/
noncomputable def releaseValueLin (r κpost M x : ℝ) : ℝ :=
  ∫ s in Ioi (0:ℝ), Real.exp (-r * s) * (M * (x * Real.exp (-κpost * s)))

theorem releaseValueLin_eq {r κpost M x : ℝ} (h : 0 < r + κpost) :
    releaseValueLin r κpost M x = M * x / (r + κpost) := by
  unfold releaseValueLin
  have : (fun s : ℝ => Real.exp (-r * s) * (M * (x * Real.exp (-κpost * s))))
      = fun s => (M * x) * Real.exp (-(r + κpost) * s) := by
    funext s
    rw [show -(r + κpost) * s = -r * s + -κpost * s by ring, Real.exp_add]
    ring
  rw [this, integral_const_mul, integral_exp_neg_mul_Ioi_zero h]
  ring

/-- P11 (i)'s value of releasing at `T` (`Z = 0`, linear rents, old public lead
`g(t) = g₀e^{-κ_pre t}`): `∫₀^T e^{-(r+λ)t}[F + ρ(g(t))]dt + e^{-(r+λ)T} Π(g(T) + Δ)`. -/
noncomputable def planValueLin (r lam κpre κpost M g₀ Dl F T : ℝ) : ℝ :=
  (∫ t in (0:ℝ)..T, Real.exp (-(r + lam) * t) * (F + M * (g₀ * Real.exp (-κpre * t))))
    + Real.exp (-(r + lam) * T) * releaseValueLin r κpost M (g₀ * Real.exp (-κpre * T) + Dl)

/-- The no-release value (hold until involuntary loss). -/
noncomputable def noReleaseValueLin (r lam κpre M g₀ F : ℝ) : ℝ :=
  ∫ t in Ioi (0:ℝ), Real.exp (-(r + lam) * t) * (F + M * (g₀ * Real.exp (-κpre * t)))

theorem planValueLin_eq {r lam κpre κpost M g₀ Dl F T : ℝ} (ha : r + lam ≠ 0)
    (hab : r + lam + κpre ≠ 0) (hc : 0 < r + κpost) :
    planValueLin r lam κpre κpost M g₀ Dl F T
      = F * ((1 - Real.exp (-(r + lam) * T)) / (r + lam))
        + M * g₀ * ((1 - Real.exp (-(r + lam + κpre) * T)) / (r + lam + κpre))
        + Real.exp (-(r + lam) * T) * (M * (g₀ * Real.exp (-κpre * T) + Dl) / (r + κpost)) := by
  unfold planValueLin
  rw [releaseValueLin_eq hc]
  have : (fun t : ℝ => Real.exp (-(r + lam) * t) * (F + M * (g₀ * Real.exp (-κpre * t))))
      = fun t => F * Real.exp (-(r + lam) * t) + (M * g₀) * Real.exp (-(r + lam + κpre) * t) := by
    funext t
    rw [show -(r + lam + κpre) * t = -(r + lam) * t + -κpre * t by ring, Real.exp_add]
    ring
  rw [this, intervalIntegral.integral_add, intervalIntegral.integral_const_mul,
    intervalIntegral.integral_const_mul, integral_exp_neg_mul_interval ha,
    integral_exp_neg_mul_interval hab]
  · apply Continuous.intervalIntegrable; fun_prop
  · apply Continuous.intervalIntegrable; fun_prop

theorem noReleaseValueLin_eq {r lam κpre M g₀ F : ℝ} (ha : 0 < r + lam)
    (hab : 0 < r + lam + κpre) :
    noReleaseValueLin r lam κpre M g₀ F = F / (r + lam) + M * g₀ / (r + lam + κpre) := by
  unfold noReleaseValueLin
  have : (fun t : ℝ => Real.exp (-(r + lam) * t) * (F + M * (g₀ * Real.exp (-κpre * t))))
      = fun t => F * Real.exp (-(r + lam) * t) + (M * g₀) * Real.exp (-(r + lam + κpre) * t) := by
    funext t
    rw [show -(r + lam + κpre) * t = -(r + lam) * t + -κpre * t by ring, Real.exp_add]
    ring
  rw [this, integral_add, integral_const_mul, integral_const_mul, integral_exp_neg_mul_Ioi_zero ha,
    integral_exp_neg_mul_Ioi_zero hab]
  · ring
  · exact (exp_neg_integrableOn_Ioi 0 ha).const_mul _
  · exact (exp_neg_integrableOn_Ioi 0 hab).const_mul _

/-- Closed form of the instance without the use: `r = λ = 1/2`, `κ_pre = 1`, `κ_post = 5/2`,
`M = g₀ = 1`, `Δ = 7/2`, `F = 1`.  With `u = e^{-T}`, `V = 3/2 + u/6 − u²/6`. -/
theorem p13_live_old_closed (T : ℝ) :
    planValueLin (1/2) (1/2) 1 (5/2) 1 1 (7/2) 1 T
      = 3/2 + Real.exp (-T) / 6 - Real.exp (-T) ^ 2 / 6 := by
  rw [planValueLin_eq (by norm_num) (by norm_num) (by norm_num)]
  have h1 : Real.exp (-(1/2 + 1/2) * T) = Real.exp (-T) := by ring_nf
  have h2 : Real.exp (-(1/2 + 1/2 + 1) * T) = Real.exp (-T) ^ 2 := by
    rw [← Real.exp_nat_mul]; ring_nf
  have h3 : Real.exp (-1 * T) = Real.exp (-T) := by ring_nf
  rw [h1, h2, h3]
  ring

/-- Closed form of the instance with a use committed for the rest of the hold: added flow
`f = 11/8`, added hazard `δ = 1`.  `V = 73/48 − u²/48`. -/
theorem p13_live_new_closed (T : ℝ) :
    planValueLin (1/2) (1/2 + 1) 1 (5/2) 1 1 (7/2) (1 + 11/8) T
      = 73/48 - Real.exp (-T) ^ 2 / 48 := by
  rw [planValueLin_eq (by norm_num) (by norm_num) (by norm_num)]
  have h1 : Real.exp (-(1/2 + (1/2 + 1)) * T) = Real.exp (-T) ^ 2 := by
    rw [← Real.exp_nat_mul]; ring_nf
  have h2 : Real.exp (-(1/2 + (1/2 + 1) + 1) * T) = Real.exp (-T) ^ 3 := by
    rw [← Real.exp_nat_mul]; ring_nf
  have h3 : Real.exp (-1 * T) = Real.exp (-T) := by ring_nf
  rw [h1, h2, h3]
  ring

/-- **P13, live release option (exact instance).**  P13's rule approves the use
(`Fδ < f(r+λ)`, and the no-release value rises, `3/2 → 73/48`); without the use the optimum is an
interior release at `T = ln 2` worth `37/24`, strictly better than releasing at once (`3/2`) or
never (`3/2`); with the use committed for the rest of the hold, every release date, and holding
until loss, is worth strictly less than `37/24`.  So the rule approves a use that lowers the
firm's optimal value. -/
theorem p13_live_rule_approves_yet_lowers_optimum :
    (1:ℝ) * 1 < 11/8 * (1/2 + 1/2) ∧
    noReleaseValueLin (1/2) (1/2) 1 1 1 1 = 3/2 ∧
    noReleaseValueLin (1/2) (1/2 + 1) 1 1 1 (1 + 11/8) = 73/48 ∧
    noReleaseValueLin (1/2) (1/2) 1 1 1 1 < noReleaseValueLin (1/2) (1/2 + 1) 1 1 1 (1 + 11/8) ∧
    planValueLin (1/2) (1/2) 1 (5/2) 1 1 (7/2) 1 (Real.log 2) = 37/24 ∧
    (∀ T, planValueLin (1/2) (1/2) 1 (5/2) 1 1 (7/2) 1 T ≤ 37/24) ∧
    planValueLin (1/2) (1/2) 1 (5/2) 1 1 (7/2) 1 0 = 3/2 ∧
    (∀ T, planValueLin (1/2) (1/2 + 1) 1 (5/2) 1 1 (7/2) (1 + 11/8) T < 37/24) ∧
    noReleaseValueLin (1/2) (1/2 + 1) 1 1 1 (1 + 11/8) < 37/24 := by
  have hn0 : noReleaseValueLin (1/2) (1/2) 1 1 1 1 = 3/2 := by
    rw [noReleaseValueLin_eq (by norm_num) (by norm_num)]; norm_num
  have hn1 : noReleaseValueLin (1/2) (1/2 + 1) 1 1 1 (1 + 11/8) = 73/48 := by
    rw [noReleaseValueLin_eq (by norm_num) (by norm_num)]; norm_num
  refine ⟨by norm_num, hn0, hn1, by rw [hn0, hn1]; norm_num, ?_, ?_, ?_, ?_, by rw [hn1]; norm_num⟩
  · rw [p13_live_old_closed, Real.exp_neg, Real.exp_log (by norm_num)]
    norm_num
  · intro T
    rw [p13_live_old_closed]
    nlinarith [sq_nonneg (Real.exp (-T) - 1/2)]
  · rw [p13_live_old_closed]
    simp
  · intro T
    rw [p13_live_new_closed]
    have : 0 < Real.exp (-T) := Real.exp_pos _
    nlinarith [sq_nonneg (Real.exp (-T))]

/-- **P13, an optional use cannot lower the optimal value (order form)**: the holder can decline
it, so the optimum over (release date, use or not), together with holding until loss (`W`
without the use, `W'` with it), is at least the optimum without the use.  Free-variable order
fact; no model content beyond "the option set contains every no-use plan".
`p13_optional_use_cannot_lower_model` states it on the defined values. -/
theorem p13_optional_use_cannot_lower (V V' : ℝ → ℝ) (W W' : ℝ) (hV : BddAbove (range V))
    (hV' : BddAbove (range V')) :
    max (⨆ T, V T) W ≤ max (⨆ T, max (V T) (V' T)) (max W W') := by
  have hb : BddAbove (range fun T => max (V T) (V' T)) := by
    obtain ⟨a, ha⟩ := hV
    obtain ⟨b, hb⟩ := hV'
    refine ⟨max a b, ?_⟩
    rintro _ ⟨T, rfl⟩
    exact max_le_max (ha ⟨T, rfl⟩) (hb ⟨T, rfl⟩)
  exact max_le_max (ciSup_mono hb fun T => le_max_left _ _) (le_max_left _ _)

/-- P11's candidate set under linear rents, `Z = 0`: the values of release dates `T ≥ 0` and of
holding until involuntary loss (line 985).  The optimal value is its supremum. -/
noncomputable def optSetLin (r lam κpre κpost M g₀ Dl F : ℝ) : Set ℝ :=
  (fun T => planValueLin r lam κpre κpost M g₀ Dl F T) '' Ici 0
    ∪ {noReleaseValueLin r lam κpre M g₀ F}

/-- `V(T)` is bounded above on `T ≥ 0` (nonnegative primitives, convergent rates). -/
theorem planValueLin_le {r lam κpre κpost M g₀ Dl F T : ℝ} (ha : 0 < r + lam) (hk : 0 ≤ κpre)
    (hc : 0 < r + κpost) (hF : 0 ≤ F) (hM : 0 ≤ M) (hg : 0 ≤ g₀) (hD : 0 ≤ Dl) (hT : 0 ≤ T) :
    planValueLin r lam κpre κpost M g₀ Dl F T
      ≤ F / (r + lam) + M * g₀ / (r + lam + κpre) + M * (g₀ + Dl) / (r + κpost) := by
  have hb : 0 < r + lam + κpre := by linarith
  rw [planValueLin_eq ha.ne' hb.ne' hc]
  have E1 : Real.exp (-(r + lam) * T) ≤ 1 :=
    Real.exp_le_one_iff.2 (by nlinarith [mul_nonneg ha.le hT])
  have E3 : Real.exp (-κpre * T) ≤ 1 := Real.exp_le_one_iff.2 (by nlinarith [mul_nonneg hk hT])
  have P1 := Real.exp_pos (-(r + lam) * T)
  have P2 := Real.exp_pos (-(r + lam + κpre) * T)
  have P3 := Real.exp_pos (-κpre * T)
  have t1 : F * ((1 - Real.exp (-(r + lam) * T)) / (r + lam)) ≤ F / (r + lam) := by
    rw [mul_div_assoc']
    exact div_le_div_of_nonneg_right (by nlinarith) ha.le
  have t2 : M * g₀ * ((1 - Real.exp (-(r + lam + κpre) * T)) / (r + lam + κpre))
      ≤ M * g₀ / (r + lam + κpre) := by
    rw [mul_div_assoc']
    exact div_le_div_of_nonneg_right (by nlinarith [mul_nonneg hM hg]) hb.le
  have t3 : Real.exp (-(r + lam) * T) * (M * (g₀ * Real.exp (-κpre * T) + Dl) / (r + κpost))
      ≤ M * (g₀ + Dl) / (r + κpost) := by
    have h0 : 0 ≤ M * (g₀ * Real.exp (-κpre * T) + Dl) / (r + κpost) :=
      div_nonneg (mul_nonneg hM (by positivity)) hc.le
    have h1 : M * (g₀ * Real.exp (-κpre * T) + Dl) / (r + κpost) ≤ M * (g₀ + Dl) / (r + κpost) :=
      div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left (by nlinarith) hM) hc.le
    calc _ ≤ 1 * (M * (g₀ * Real.exp (-κpre * T) + Dl) / (r + κpost)) :=
          mul_le_mul_of_nonneg_right E1 h0
      _ ≤ _ := by rw [one_mul]; exact h1
  linarith

theorem optSetLin_bddAbove {r lam κpre κpost M g₀ Dl F : ℝ} (ha : 0 < r + lam) (hk : 0 ≤ κpre)
    (hc : 0 < r + κpost) (hF : 0 ≤ F) (hM : 0 ≤ M) (hg : 0 ≤ g₀) (hD : 0 ≤ Dl) :
    BddAbove (optSetLin r lam κpre κpost M g₀ Dl F) := by
  refine BddAbove.union
    ⟨F / (r + lam) + M * g₀ / (r + lam + κpre) + M * (g₀ + Dl) / (r + κpost), ?_⟩
    bddAbove_singleton
  rintro _ ⟨T, hT, rfl⟩
  exact planValueLin_le ha hk hc hF hM hg hD hT

/-- **P13, an optional use cannot lower the optimal value, on the model's objects (line 1001).**
Linear rents, `Z = 0`.  Without the use, the optimal value is the supremum of `V(T)` over release
dates `T ≥ 0` and holding until loss.  With an optional use (flow `f ≥ 0`, added hazard `δ`,
committed for the rest of the hold once adopted), the holder picks a plan from the union of the
no-use and with-use candidate sets.  The first optimum is at most the second; both suprema exist
(`optSetLin_bddAbove`). -/
theorem p13_optional_use_cannot_lower_model {r lam δ κpre κpost M g₀ Dl F f : ℝ}
    (ha : 0 < r + lam) (ha' : 0 < r + (lam + δ)) (hk : 0 ≤ κpre) (hc : 0 < r + κpost)
    (hF : 0 ≤ F) (hf : 0 ≤ f) (hM : 0 ≤ M) (hg : 0 ≤ g₀) (hD : 0 ≤ Dl) :
    sSup (optSetLin r lam κpre κpost M g₀ Dl F)
      ≤ sSup (optSetLin r lam κpre κpost M g₀ Dl F
          ∪ optSetLin r (lam + δ) κpre κpost M g₀ Dl (F + f)) :=
  csSup_le_csSup ((optSetLin_bddAbove ha hk hc hF hM hg hD).union
      (optSetLin_bddAbove ha' hk hc (by linarith) hM hg hD))
    ⟨noReleaseValueLin r lam κpre M g₀ F, by simp [optSetLin]⟩ subset_union_left

/-! ### P13, the paper's own example (A.6 line 1109): the no-release values -/

/-- No-release value with an old public model and power rents `ρ(x) = Mx^η`. -/
noncomputable def noReleaseValuePow (r lam κ M g₀ η F : ℝ) : ℝ :=
  ∫ t in Ioi (0:ℝ), Real.exp (-(r + lam) * t) * (F + M * (g₀ * Real.exp (-κ * t)) ^ η)

theorem noReleaseValuePow_eq {r lam κ M g₀ η F : ℝ} (hg : 0 ≤ g₀) (ha : 0 < r + lam)
    (hb : 0 < r + lam + η * κ) :
    noReleaseValuePow r lam κ M g₀ η F = F / (r + lam) + M * g₀ ^ η / (r + lam + η * κ) := by
  unfold noReleaseValuePow
  have hfun : (fun t : ℝ => Real.exp (-(r + lam) * t) * (M * (g₀ * Real.exp (-κ * t)) ^ η))
      = fun t => (M * g₀ ^ η) * Real.exp (-(r + lam + η * κ) * t) := by
    funext t
    rw [p12_power_rent_revenue hg,
      show -(r + lam + η * κ) * t = -(r + lam) * t + -(η * κ) * t by ring, Real.exp_add]
    ring
  have : (fun t : ℝ => Real.exp (-(r + lam) * t) * (F + M * (g₀ * Real.exp (-κ * t)) ^ η))
      = fun t => F * Real.exp (-(r + lam) * t) + (M * g₀ ^ η) * Real.exp (-(r + lam + η * κ) * t) := by
    funext t
    rw [mul_add, show Real.exp (-(r + lam) * t) * (M * (g₀ * Real.exp (-κ * t)) ^ η)
      = (M * g₀ ^ η) * Real.exp (-(r + lam + η * κ) * t) from congrFun hfun t]
    ring
  rw [this, integral_add, integral_const_mul, integral_const_mul, integral_exp_neg_mul_Ioi_zero ha,
    integral_exp_neg_mul_Ioi_zero hb]
  · ring
  · exact (exp_neg_integrableOn_Ioi 0 ha).const_mul _
  · exact (exp_neg_integrableOn_Ioi 0 hb).const_mul _

/-- **P13, A.6 line 1109.** `F = 0.42`, `η = 0.5`, `κ = 0.5`, `λ = 0.2`, `g₀ = 0.2`, `r = 0.05`,
`M = 1`; the use has `δ = 0.02`, `f = 2.147 δ`.  The no-release value rises, from a value in
`[2.574425, 2.574435)` (printed 2.57443) to one in `[2.574615, 2.574625)` (printed 2.57462).
The first conjunct is P13's literal rule `F/(r+λ) < f/δ`. -/
theorem p13_paper_example_noRelease :
    (0.42:ℝ) / (0.05 + 0.2) < 2.147 * 0.02 / 0.02 ∧
    (2.574425 ≤ noReleaseValuePow 0.05 0.2 0.5 1 0.2 0.5 0.42 ∧
      noReleaseValuePow 0.05 0.2 0.5 1 0.2 0.5 0.42 < 2.574435) ∧
    (2.574615 ≤ noReleaseValuePow 0.05 (0.2 + 0.02) 0.5 1 0.2 0.5 (0.42 + 2.147 * 0.02) ∧
      noReleaseValuePow 0.05 (0.2 + 0.02) 0.5 1 0.2 0.5 (0.42 + 2.147 * 0.02) < 2.574625) ∧
    noReleaseValuePow 0.05 0.2 0.5 1 0.2 0.5 0.42
      < noReleaseValuePow 0.05 (0.2 + 0.02) 0.5 1 0.2 0.5 (0.42 + 2.147 * 0.02) := by
  have hs : (0.2:ℝ) ^ (0.5:ℝ) = Real.sqrt 0.2 := by
    rw [Real.sqrt_eq_rpow]; norm_num
  have hlo : (0.4472135:ℝ) < Real.sqrt 0.2 := by
    rw [Real.lt_sqrt (by norm_num)]; norm_num
  have hhi : Real.sqrt 0.2 < (0.4472136:ℝ) := by
    rw [Real.sqrt_lt' (by norm_num)]; norm_num
  rw [noReleaseValuePow_eq (by norm_num) (by norm_num) (by norm_num),
    noReleaseValuePow_eq (by norm_num) (by norm_num) (by norm_num), hs]
  generalize Real.sqrt 0.2 = s at hlo hhi ⊢
  refine ⟨by norm_num, ⟨?_, ?_⟩, ⟨?_, ?_⟩, ?_⟩ <;> norm_num <;> linarith

/-! ## P14, the value of a secret capped by those who want to take it -/

/-- P14's hold value, as P13's survival-weighted hold value with hazard `λ₀ + λ_θ(F)`, `Z = 0`. -/
noncomputable def p14Value (r lam0 : ℝ) (lθ : ℝ → ℝ) (F : ℝ) : ℝ :=
  holdValue r (lam0 + lθ F) F 0

theorem p14Value_eq {r lam0 : ℝ} {lθ : ℝ → ℝ} {F : ℝ} (h : 0 < r + (lam0 + lθ F)) :
    p14Value r lam0 lθ F = F / (r + lam0 + lθ F) := by
  rw [p14Value, holdValue_eq h]
  ring_nf

/-- "Theft eventually rises at least in proportion to the flow". -/
def EventuallyProportional (lθ : ℝ → ℝ) : Prop :=
  ∃ ε > 0, ∃ M > 0, ∀ F ≥ M, ε * F ≤ lθ F

/-- "Bounded over `F ≥ 0`". -/
def BoundedOnNonneg (V : ℝ → ℝ) : Prop := ∃ B, ∀ F ≥ 0, |V F| ≤ B

/-- **P14, the liminf wording.**  `EventuallyProportional` is exactly
`liminf_{F→∞} λ_θ(F)/F > 0`, the liminf taken in `EReal` so that `+∞` is allowed and no
boundedness of `λ_θ(F)/F` is assumed. -/
theorem p14_liminf_iff (lθ : ℝ → ℝ) :
    EventuallyProportional lθ ↔
      (0 : EReal) < liminf (fun F => ((lθ F / F : ℝ) : EReal)) atTop := by
  constructor
  · rintro ⟨ε, hε, M, hM, h⟩
    have hev : ∀ᶠ F in atTop, ((ε : ℝ) : EReal) ≤ ((lθ F / F : ℝ) : EReal) := by
      filter_upwards [eventually_ge_atTop M] with F hF
      have hFpos : 0 < F := lt_of_lt_of_le hM hF
      exact_mod_cast (le_div_iff₀ hFpos).2 (h F hF)
    calc (0 : EReal) < ((ε : ℝ) : EReal) := by exact_mod_cast hε
      _ ≤ _ := le_liminf_of_le (by isBoundedDefault) hev
  · intro h
    obtain ⟨c, hc0, hcl⟩ := exists_between h
    have hctop : c ≠ ⊤ := ne_top_of_lt hcl
    have hcbot : c ≠ ⊥ := ne_bot_of_gt hc0
    have hεc : ((c.toReal : ℝ) : EReal) = c := EReal.coe_toReal hctop hcbot
    have hε : 0 < c.toReal := by
      rw [← hεc] at hc0
      exact_mod_cast hc0
    have hev := eventually_lt_of_lt_liminf hcl
    obtain ⟨M₀, hM₀⟩ := eventually_atTop.1 hev
    refine ⟨c.toReal, hε, max M₀ 1, by positivity, fun F hF => ?_⟩
    have h1 := hM₀ F (le_trans (le_max_left _ _) hF)
    rw [← hεc] at h1
    have h2 : c.toReal < lθ F / F := by exact_mod_cast h1
    have hFpos : 0 < F := lt_of_lt_of_le one_pos (le_trans (le_max_right _ _) hF)
    exact ((lt_div_iff₀ hFpos).1 h2).le

/-- **P14 (i).**  With `r + λ₀ > 0` and `λ_θ ≥ 0`, the hold value is bounded over `F ≥ 0` iff
theft eventually rises at least in proportion to the flow. -/
theorem p14_i {r lam0 : ℝ} {lθ : ℝ → ℝ} (ha : 0 < r + lam0) (hnn : ∀ F ≥ 0, 0 ≤ lθ F) :
    BoundedOnNonneg (p14Value r lam0 lθ) ↔ EventuallyProportional lθ := by
  set a := r + lam0 with ha_def
  have hval : ∀ F ≥ 0, p14Value r lam0 lθ F = F / (a + lθ F) := by
    intro F hF
    rw [p14Value_eq (by linarith [hnn F hF])]
  constructor
  · rintro ⟨B, hB⟩
    by_contra hne
    simp only [EventuallyProportional, not_exists, not_and, not_forall, not_le] at hne
    set B' := max B 0 + 1 with hB'
    have hB'pos : 0 < B' := by positivity
    obtain ⟨F, hFM, hlt⟩ := hne (1 / (2 * B')) (by positivity) (2 * B' * a + 1) (by positivity)
    have hF0 : 0 < F := by linarith [mul_pos hB'pos ha]
    have hl0 := hnn F hF0.le
    have hden : 0 < a + lθ F := by linarith
    have key : B' < F / (a + lθ F) := by
      rw [lt_div_iff₀ hden]
      have : B' * lθ F < B' * (1 / (2 * B') * F) := mul_lt_mul_of_pos_left hlt hB'pos
      have e : B' * (1 / (2 * B') * F) = F / 2 := by field_simp
      nlinarith
    have := hB F hF0.le
    rw [hval F hF0.le] at this
    have hBB' : B < B' := by rw [hB']; linarith [le_max_left B 0]
    linarith [le_abs_self (F / (a + lθ F))]
  · rintro ⟨ε, hε, M, hM, h⟩
    refine ⟨max (1 / ε) (M / a), fun F hF => ?_⟩
    rw [hval F hF]
    have hl0 := hnn F hF
    have hden : 0 < a + lθ F := by linarith
    rw [abs_of_nonneg (div_nonneg hF hden.le)]
    rcases le_or_gt M F with hMF | hFM
    · have hεF := h F hMF
      have : F / (a + lθ F) ≤ 1 / ε := by
        rw [div_le_div_iff₀ hden hε]
        nlinarith
      exact le_trans this (le_max_left _ _)
    · have : F / (a + lθ F) ≤ M / a := by
        rw [div_le_div_iff₀ hden ha]
        nlinarith
      exact le_trans this (le_max_right _ _)

/-- **P14 (i), liminf form.** -/
theorem p14_i_liminf {r lam0 : ℝ} {lθ : ℝ → ℝ} (ha : 0 < r + lam0) (hnn : ∀ F ≥ 0, 0 ≤ lθ F) :
    BoundedOnNonneg (p14Value r lam0 lθ) ↔
      (0 : EReal) < liminf (fun F => ((lθ F / F : ℝ) : EReal)) atTop := by
  rw [p14_i ha hnn, p14_liminf_iff]

/-- **P14 (ii).**  If `λ_θ(F) ≥ θF` with `θ > 0`, then `V < 1/θ` at every `F ≥ 0`; `r` enters
only through `r + λ₀ > 0` ("the cap survives discounting"). -/
theorem p14_ii {r lam0 θ : ℝ} {lθ : ℝ → ℝ} (ha : 0 < r + lam0) (hθ : 0 < θ)
    (hge : ∀ F ≥ 0, θ * F ≤ lθ F) (F : ℝ) (hF : 0 ≤ F) :
    p14Value r lam0 lθ F < 1 / θ := by
  have hl := hge F hF
  have hl0 : 0 ≤ lθ F := le_trans (by positivity) hl
  rw [p14Value_eq (by linarith), div_lt_div_iff₀ (by linarith) hθ]
  nlinarith

/-- **P14 (ii).** With `λ_θ = θF` the value rises strictly in `F ≥ 0` … -/
theorem p14_ii_linear_strictMono {r lam0 θ : ℝ} (ha : 0 < r + lam0) (hθ : 0 < θ) :
    StrictMonoOn (p14Value r lam0 (fun F => θ * F)) (Ici 0) := by
  intro x hx y hy hxy
  simp only [mem_Ici] at hx hy
  rw [p14Value_eq (by nlinarith), p14Value_eq (by nlinarith),
    div_lt_div_iff₀ (by nlinarith) (by nlinarith)]
  nlinarith

/-- **P14 (ii).** … toward `1/θ`. -/
theorem p14_ii_linear_tendsto {r lam0 θ : ℝ} (ha : 0 < r + lam0) (hθ : 0 < θ) :
    Tendsto (p14Value r lam0 (fun F => θ * F)) atTop (𝓝 (1 / θ)) := by
  have hlim : Tendsto (fun F : ℝ => 1 / ((r + lam0) * F⁻¹ + θ)) atTop (𝓝 (1 / (0 + θ))) := by
    apply Tendsto.div tendsto_const_nhds _ (by simp; exact hθ.ne')
    have : Tendsto (fun F : ℝ => (r + lam0) * F⁻¹) atTop (𝓝 0) := by
      simpa using tendsto_inv_atTop_zero.const_mul (r + lam0)
    exact this.add_const θ
  rw [zero_add] at hlim
  apply hlim.congr'
  filter_upwards [eventually_gt_atTop 0] with F hF
  rw [p14Value_eq (by nlinarith)]
  field_simp

/-- **P14 (iii).**  With durable assets `Z ≥ 0` that survive leakage, under (ii)'s premise,
`V = F/(r+λ) + [λ/(r+λ)]Z < 1/θ + Z` at every `F ≥ 0`, `λ = λ₀ + λ_θ(F)`.  Needs `r ≥ 0` (the
Program sub-model's standing `r > 0`, line 827); see `p14_iii_needs_r_nonneg`. -/
theorem p14_iii {r lam0 θ Z : ℝ} {lθ : ℝ → ℝ} (hr : 0 ≤ r) (ha : 0 < r + lam0) (hθ : 0 < θ)
    (hge : ∀ F ≥ 0, θ * F ≤ lθ F) (hZ : 0 ≤ Z) (F : ℝ) (hF : 0 ≤ F) :
    holdValue r (lam0 + lθ F) F Z
        = F / (r + (lam0 + lθ F)) + (lam0 + lθ F) / (r + (lam0 + lθ F)) * Z ∧
      holdValue r (lam0 + lθ F) F Z < 1 / θ + Z := by
  have hl := hge F hF
  have hl0 : 0 ≤ lθ F := le_trans (by positivity) hl
  have hden : 0 < r + (lam0 + lθ F) := by linarith
  have heq : holdValue r (lam0 + lθ F) F Z
      = F / (r + (lam0 + lθ F)) + (lam0 + lθ F) / (r + (lam0 + lθ F)) * Z := by
    rw [holdValue_eq hden]
    field_simp
  refine ⟨heq, ?_⟩
  rw [heq]
  have h1 : F / (r + (lam0 + lθ F)) < 1 / θ := by
    have := p14_ii ha hθ hge F hF
    rwa [p14Value_eq hden, show r + lam0 + lθ F = r + (lam0 + lθ F) by ring] at this
  have h2 : (lam0 + lθ F) / (r + (lam0 + lθ F)) ≤ 1 := by
    rw [div_le_one hden]; linarith
  have h3 : (lam0 + lθ F) / (r + (lam0 + lθ F)) * Z ≤ Z := by
    nlinarith
  linarith

/-- **P14 (iii) needs `r ≥ 0`.**  Under P14's own preamble `r + λ₀ > 0` alone, with `r < 0`
the bound fails: `r = −1/20`, `λ₀ = 1/10`, `λ_θ = F/2`, `Z = 10`, `F = 0` gives `V = 20 ≥ 12`. -/
theorem p14_iii_needs_r_nonneg :
    (0:ℝ) < -1/20 + 1/10 ∧
    1 / (1/2 : ℝ) + 10 ≤ holdValue (-1/20) (1/10 + 1/2 * 0) 0 10 := by
  refine ⟨by norm_num, ?_⟩
  rw [holdValue_eq (by norm_num)]
  norm_num

/-- **P14, "the cap also needs … value that a leak extinguishes" (line 1007).**  Surviving `Z`
breaks the `1/θ` cap at `r > 0`: `r = 1/20`, `λ₀ = 1/10`, `θ = 1/2`, `λ_θ = θF`, `F = 0`,
`Z = 10` gives `V = 20/3 > 2`.  (A finite bound, `1/θ + Z`, survives: `p14_iii`.) -/
theorem p14_cap_needs_extinguished_value :
    (1:ℝ) / (1/2) < holdValue (1/20) (1/10 + 1/2 * 0) 0 10 := by
  rw [holdValue_eq (by norm_num)]; norm_num

/-- **P14, "as first stated": theft `θ√F`** rises with the flow, yet the value is unbounded. -/
theorem p14_sqrt_unbounded {r lam0 θ : ℝ} (ha : 0 < r + lam0) (hθ : 0 < θ) :
    StrictMonoOn (fun F => θ * Real.sqrt F) (Ici 0) ∧
    ¬ BoundedOnNonneg (p14Value r lam0 (fun F => θ * Real.sqrt F)) := by
  refine ⟨?_, ?_⟩
  · intro x hx y hy hxy
    simp only [mem_Ici] at hx
    exact mul_lt_mul_of_pos_left (Real.sqrt_lt_sqrt hx hxy) hθ
  rw [p14_i ha (fun F _ => by positivity)]
  rintro ⟨ε, hε, M, hM, h⟩
  set F := max M ((θ / ε) ^ 2 + 1) with hFdef
  have hF := h F (le_max_left _ _)
  have hFgt : (θ / ε) ^ 2 < F := lt_of_lt_of_le (by linarith) (le_max_right _ _)
  have hFpos : 0 < F := lt_of_le_of_lt (by positivity) hFgt
  have hs : θ / ε < Real.sqrt F := (Real.lt_sqrt (by positivity)).2 hFgt
  have hs' : θ < ε * Real.sqrt F := by rwa [div_lt_iff₀ hε, mul_comm] at hs
  have hsq : Real.sqrt F * Real.sqrt F = F := Real.mul_self_sqrt hFpos.le
  have hspos : 0 < Real.sqrt F := Real.sqrt_pos.2 hFpos
  nlinarith

/-- **P14, A.6 line 1111.** `r = 0.05`, `λ₀ = 0.1`, `θ = 0.5`, theft `θ√F`, `F = 10⁸`:
exactly `V = 2000000000/100003 ∈ (19999, 19999.5)`, which rounds to the printed 19,999, against
the linear-theft cap `1/θ = 2`. -/
theorem p14_sqrt_numeric :
    p14Value 0.05 0.1 (fun F => 0.5 * Real.sqrt F) (10 ^ 8) = 2000000000 / 100003 ∧
    (19999:ℝ) < p14Value 0.05 0.1 (fun F => 0.5 * Real.sqrt F) (10 ^ 8) ∧
    p14Value 0.05 0.1 (fun F => 0.5 * Real.sqrt F) (10 ^ 8) < 19999.5 := by
  have hs : Real.sqrt ((10:ℝ) ^ 8) = 10 ^ 4 := by
    rw [show ((10:ℝ) ^ 8) = (10 ^ 4) ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  rw [p14Value_eq (by simp only [hs]; norm_num)]
  simp only [hs]
  refine ⟨?_, ?_, ?_⟩ <;> norm_num

/-- **P14, "as first stated": theft `θF/(1 + ln(1+F))`** leaves the value unbounded. -/
theorem p14_log_unbounded {r lam0 θ : ℝ} (ha : 0 < r + lam0) (hθ : 0 < θ) :
    ¬ BoundedOnNonneg (p14Value r lam0 (fun F => θ * F / (1 + Real.log (1 + F)))) := by
  have hlog : ∀ F : ℝ, 0 ≤ F → 0 ≤ Real.log (1 + F) := fun F hF =>
    Real.log_nonneg (by linarith)
  rw [p14_i ha (fun F hF => by have := hlog F hF; positivity)]
  rintro ⟨ε, hε, M, hM, h⟩
  set F := max M (Real.exp (θ / ε)) with hFdef
  have hF := h F (le_max_left _ _)
  have hFpos : 0 < F := lt_of_lt_of_le hM (le_max_left _ _)
  have hlt : θ / ε < Real.log (1 + F) := by
    rw [Real.lt_log_iff_exp_lt (by linarith)]
    linarith [le_max_right M (Real.exp (θ / ε))]
  have hl0 := hlog F hFpos.le
  have hθε : θ < ε * (1 + Real.log (1 + F)) := by
    rw [div_lt_iff₀ hε] at hlt; nlinarith
  rw [le_div_iff₀ (by linarith)] at hF
  nlinarith

/-- P14, theft on capitalized value: the positive root of `θV² + aV − F = 0`. -/
noncomputable def theftOnValue (a θ F : ℝ) : ℝ := (-a + Real.sqrt (a ^ 2 + 4 * θ * F)) / (2 * θ)

/-- **P14, theft on value.**  The nonnegative solutions of `V = F/(a + θV)` are exactly
`theftOnValue a θ F`. -/
theorem p14_theft_on_value_fixed_point {a θ F V : ℝ} (ha : 0 < a) (hθ : 0 < θ) (hF : 0 ≤ F) :
    (0 ≤ V ∧ V = F / (a + θ * V)) ↔ V = theftOnValue a θ F := by
  have hs0 : 0 ≤ Real.sqrt (a ^ 2 + 4 * θ * F) := Real.sqrt_nonneg _
  have hs2 : Real.sqrt (a ^ 2 + 4 * θ * F) ^ 2 = a ^ 2 + 4 * θ * F :=
    Real.sq_sqrt (by positivity)
  constructor
  · rintro ⟨hV, hfix⟩
    have hden : 0 < a + θ * V := by positivity
    have hq : V * (a + θ * V) = F := (eq_div_iff hden.ne').1 hfix
    have hsq : Real.sqrt (a ^ 2 + 4 * θ * F) = 2 * θ * V + a := by
      rw [show a ^ 2 + 4 * θ * F = (2 * θ * V + a) ^ 2 by rw [← hq]; ring]
      exact Real.sqrt_sq (by positivity)
    rw [theftOnValue, hsq]
    field_simp
    ring
  · intro hV
    have hsa : a ≤ Real.sqrt (a ^ 2 + 4 * θ * F) := by
      have h := Real.sqrt_le_sqrt (show a ^ 2 ≤ a ^ 2 + 4 * θ * F by nlinarith)
      rwa [Real.sqrt_sq ha.le] at h
    have hV0 : 0 ≤ V := by rw [hV, theftOnValue]; apply div_nonneg <;> linarith
    refine ⟨hV0, ?_⟩
    have hden : 0 < a + θ * V := by positivity
    rw [eq_div_iff hden.ne', hV, theftOnValue]
    field_simp
    nlinarith [hs2]

/-- **P14, theft on value grows like `√(F/θ)`**: the ratio tends to 1. -/
theorem p14_theft_on_value_asymp {a θ : ℝ} (ha : 0 < a) (hθ : 0 < θ) :
    Tendsto (fun F => theftOnValue a θ F / Real.sqrt (F / θ)) atTop (𝓝 1) := by
  have hsqrt : Tendsto (fun F : ℝ => Real.sqrt (F / θ)) atTop atTop :=
    Real.tendsto_sqrt_atTop.comp (tendsto_id.atTop_div_const hθ)
  have hlow : Tendsto (fun F : ℝ => 1 - a / (2 * θ) / Real.sqrt (F / θ)) atTop (𝓝 1) := by
    have := (tendsto_const_nhds (x := a / (2 * θ))).div_atTop hsqrt
    simpa using this.const_sub (1:ℝ)
  have h4 : ∀ F, 0 < F → Real.sqrt (4 * θ * F) = 2 * θ * Real.sqrt (F / θ) := by
    intro F hF
    rw [show 4 * θ * F = (2 * θ) ^ 2 * (F / θ) by field_simp; ring, Real.sqrt_mul (by positivity),
      Real.sqrt_sq (by positivity)]
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' hlow tendsto_const_nhds ?_ ?_
  · filter_upwards [eventually_gt_atTop 0] with F hF
    have hs : 0 < Real.sqrt (F / θ) := Real.sqrt_pos.2 (by positivity)
    have hle : Real.sqrt (4 * θ * F) ≤ Real.sqrt (a ^ 2 + 4 * θ * F) :=
      Real.sqrt_le_sqrt (by nlinarith)
    rw [h4 F hF] at hle
    have hv : Real.sqrt (F / θ) - a / (2 * θ) ≤ theftOnValue a θ F := by
      rw [theftOnValue, le_div_iff₀ (by positivity)]
      have e : (Real.sqrt (F / θ) - a / (2 * θ)) * (2 * θ) = 2 * θ * Real.sqrt (F / θ) - a := by
        field_simp
      linarith
    rw [le_div_iff₀ hs]
    have e2 : (1 - a / (2 * θ) / Real.sqrt (F / θ)) * Real.sqrt (F / θ)
        = Real.sqrt (F / θ) - a / (2 * θ) := by field_simp
    linarith
  · filter_upwards [eventually_gt_atTop 0] with F hF
    have hs : 0 < Real.sqrt (F / θ) := Real.sqrt_pos.2 (by positivity)
    have h0 : 0 ≤ Real.sqrt (4 * θ * F) := Real.sqrt_nonneg _
    have hsq : Real.sqrt (4 * θ * F) ^ 2 = 4 * θ * F := Real.sq_sqrt (by positivity)
    have hup : Real.sqrt (a ^ 2 + 4 * θ * F) ≤ a + Real.sqrt (4 * θ * F) := by
      rw [Real.sqrt_le_left (by positivity)]
      nlinarith
    rw [h4 F hF] at hup
    rw [div_le_one hs, theftOnValue, div_le_iff₀ (by positivity)]
    linarith

/-- P14, bought security: theft hazard `θ₀e^{-σ}F`, security `σ` bought at one-off cost `kσ`. -/
noncomputable def securityValue (r lam0 θ0 k F σ : ℝ) : ℝ :=
  holdValue r (lam0 + θ0 * Real.exp (-σ) * F) F 0 - k * σ

/-- **P14, "as first stated": if the holder can buy security cheaply enough, value grows without
bound in `F`** (any unit cost `k ≥ 0`). -/
theorem p14_security_unbounded {r lam0 θ0 k : ℝ} (ha : 0 < r + lam0) (hθ : 0 ≤ θ0)
    (hk : 0 ≤ k) (B : ℝ) :
    ∃ F ≥ 0, ∃ σ ≥ 0, B < securityValue r lam0 θ0 k F σ := by
  set A := r + lam0 + θ0 with hA
  have hApos : 0 < A := by linarith
  set x := 2 * A * (k + |B|) + 2 with hx
  have hB0 := abs_nonneg B
  have hx2 : 2 ≤ x := by nlinarith
  refine ⟨Real.exp x, (Real.exp_pos _).le, x, by linarith, ?_⟩
  have hcancel : θ0 * Real.exp (-x) * Real.exp x = θ0 := by
    rw [mul_assoc, ← Real.exp_add]; simp
  rw [securityValue, hcancel, holdValue_eq (by linarith)]
  simp only [mul_zero, add_zero]
  rw [show r + (lam0 + θ0) = A by rw [hA]; ring]
  have hq := Real.quadratic_le_exp_of_nonneg (show 0 ≤ x by linarith)
  have hxA : x / (2 * A) = k + |B| + 1 / A := by rw [hx]; field_simp
  have h1 : x ^ 2 / (2 * A) ≤ Real.exp x / A := by
    rw [div_le_div_iff₀ (by positivity) hApos]
    nlinarith
  have h2 : x ^ 2 / (2 * A) - k * x = x * (|B| + 1 / A) := by
    rw [show x ^ 2 / (2 * A) = x * (x / (2 * A)) by ring, hxA]; ring
  have hinv : 0 < 1 / A := by positivity
  have h3 : B < x * (|B| + 1 / A) := by nlinarith [le_abs_self B]
  linarith

/-- **P14, A.6 proof line 1140: "value at `F = 10⁶` exceeds `6 × 10⁶`"** with `r = 0.05`,
`λ₀ = 0.1`, `θ₀ = 0.5`, unit cost, at the grid point `σ = 20` of `[0, 39.9]`. -/
theorem p14_security_numeric :
    (0:ℝ) ≤ 20 ∧ (20:ℝ) ≤ 39.9 ∧ 6 * 10 ^ 6 < securityValue 0.05 0.1 0.5 1 (10 ^ 6) 20 := by
  refine ⟨by norm_num, by norm_num, ?_⟩
  have he1 : (2.7:ℝ) < Real.exp 1 := by linarith [Real.exp_one_gt_d9]
  have he : (2.7:ℝ) ^ 20 < Real.exp 20 := by
    rw [show (20:ℝ) = (20:ℕ) * 1 by norm_num, Real.exp_nat_mul]
    exact pow_lt_pow_left₀ he1 (by norm_num) (by norm_num)
  have hE : Real.exp (-20) < 1 / (2.7:ℝ) ^ 20 := by
    rw [Real.exp_neg, ← one_div]
    exact one_div_lt_one_div_of_lt (by positivity) he
  have hE0 : 0 < Real.exp (-20) := Real.exp_pos _
  have hd : (0.05:ℝ) + (0.1 + 0.5 * Real.exp (-20) * 10 ^ 6) < 0.1512 := by
    have : (0.5:ℝ) * (1 / (2.7:ℝ) ^ 20) * 10 ^ 6 < 0.0012 := by norm_num
    nlinarith
  have hd0 : (0:ℝ) < 0.05 + (0.1 + 0.5 * Real.exp (-20) * 10 ^ 6) := by positivity
  rw [securityValue, holdValue_eq hd0]
  simp only [mul_zero, add_zero]
  rw [lt_sub_iff_add_lt, lt_div_iff₀ hd0]
  nlinarith

/-! ## P15, durable assets -/

/-- Value of a unit of step earnings with durable share `d`: share `1 − d` erodes at `κ`, share
`d` is a perpetual, non-eroding component from the start: `∫₀^∞ e^{-rt}[(1−d)e^{-κt} + d] dt`. -/
noncomputable def stepValue (r κ d : ℝ) : ℝ :=
  ∫ t in Ioi (0:ℝ), Real.exp (-r * t) * ((1 - d) * Real.exp (-κ * t) + d)

/-- **P15, valuation.** `V(d) = (1 − d)/(r+κ) + d/r = (r + dκ)/(r(r+κ))`. -/
theorem p15_value {r κ d : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) :
    stepValue r κ d = (1 - d) / (r + κ) + d / r ∧
    stepValue r κ d = (r + d * κ) / (r * (r + κ)) := by
  have hrk : 0 < r + κ := by linarith
  have h : stepValue r κ d = (1 - d) / (r + κ) + d / r := by
    unfold stepValue
    have : (fun t : ℝ => Real.exp (-r * t) * ((1 - d) * Real.exp (-κ * t) + d))
        = fun t => (1 - d) * Real.exp (-(r + κ) * t) + d * Real.exp (-r * t) := by
      funext t
      rw [show -(r + κ) * t = -r * t + -κ * t by ring, Real.exp_add]
      ring
    rw [this, integral_add, integral_const_mul, integral_const_mul,
      integral_exp_neg_mul_Ioi_zero hrk, integral_exp_neg_mul_Ioi_zero hr]
    · ring
    · exact (exp_neg_integrableOn_Ioi 0 hrk).const_mul _
    · exact (exp_neg_integrableOn_Ioi 0 hr).const_mul _
  refine ⟨h, ?_⟩
  rw [h]
  field_simp
  ring

/-- **P15.** `V′(d) = κ/(r(r+κ))`. -/
theorem p15_hasDerivAt {r κ : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) (d : ℝ) :
    HasDerivAt (stepValue r κ) (κ / (r * (r + κ))) d := by
  have hrk : 0 < r + κ := by linarith
  have e : stepValue r κ = fun d => (1 - d) / (r + κ) + d / r := by
    funext d; exact (p15_value hr hκ).1
  rw [e]
  have h := (((hasDerivAt_id d).const_sub 1).div_const (r + κ)).add
    ((hasDerivAt_id d).div_const r)
  have hd : -1 / (r + κ) + 1 / r = κ / (r * (r + κ)) := by field_simp; ring
  rw [hd] at h
  exact h

/-- **P15.** Changes in `d` are strict when `κ > 0`. -/
theorem p15_strictMono {r κ : ℝ} (hr : 0 < r) (hκ : 0 < κ) : StrictMono (stepValue r κ) := by
  intro a b hab
  rw [(p15_value hr hκ.le).2, (p15_value hr hκ.le).2]
  apply div_lt_div_of_pos_right _ (by positivity)
  nlinarith

/-- **P15.** At `κ = 0`, `V(d) = 1/r`. -/
theorem p15_kappa_zero {r : ℝ} (hr : 0 < r) (d : ℝ) : stepValue r 0 d = 1 / r := by
  rw [(p15_value hr le_rfl).1]
  field_simp
  ring

/-- **P15 (a).** `(1/r)/V(d) = (r+κ)/(r+dκ)` for `d ∈ [0,1]`. -/
theorem p15_a_eq {r κ d : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) (hd : 0 ≤ d) :
    (1 / r) / stepValue r κ d = (r + κ) / (r + d * κ) := by
  have : 0 < r + d * κ := by positivity
  rw [(p15_value hr hκ).2]
  field_simp

/-- **P15 (a).** … which falls in `d` (strictly when `κ > 0`). -/
theorem p15_a_strictAnti {r κ : ℝ} (hr : 0 < r) (hκ : 0 < κ) :
    StrictAntiOn (fun d => (1 / r) / stepValue r κ d) (Icc 0 1) := by
  intro a ha b hb hab
  simp only
  rw [p15_a_eq hr hκ.le ha.1, p15_a_eq hr hκ.le hb.1]
  apply div_lt_div_of_pos_left (by linarith) (by nlinarith [ha.1]) (by nlinarith)

/-- **P15 (a)** at `κ ≥ 0`: weakly falls. -/
theorem p15_a_antitone {r κ : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) :
    AntitoneOn (fun d => (1 / r) / stepValue r κ d) (Icc 0 1) := by
  intro a ha b hb hab
  simp only
  rw [p15_a_eq hr hκ ha.1, p15_a_eq hr hκ hb.1]
  apply div_le_div_of_nonneg_left (by linarith) (by nlinarith [ha.1]) (by nlinarith)

/-- **P15 (b).** In a step contest whose winner alone gets `mV(d)` (P9 with `v_W − v_L = mV(d)`),
`mV(d)/(4(c + Lθ))` is an equilibrium effort. -/
theorem p15_b_nash {r κ m c Lθ d : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) (hm : 0 < m) (hc : 0 < c + Lθ)
    (hd : 0 ≤ d) (x : ℝ) (hx : 0 ≤ x) :
    tullockPayoff (m * stepValue r κ d) 0 c Lθ x (contestEffort (m * stepValue r κ d) (c + Lθ))
      ≤ tullockPayoff (m * stepValue r κ d) 0 c Lθ
          (contestEffort (m * stepValue r κ d) (c + Lθ))
          (contestEffort (m * stepValue r κ d) (c + Lθ)) := by
  have hV : 0 < stepValue r κ d := by
    rw [(p15_value hr hκ).2]
    have : 0 < r + κ := by linarith
    positivity
  have := tullock_nash (vW := m * stepValue r κ d) (vL := 0) (c := c) (Lθ := Lθ)
    (by simpa using mul_pos hm hV) hc x hx
  simpa using this

/-- **P15 (b).** … which rises in `d` (strictly when `κ > 0`). -/
theorem p15_b_strictMono {r κ m ch : ℝ} (hr : 0 < r) (hκ : 0 < κ) (hm : 0 < m) (hc : 0 < ch) :
    StrictMono (fun d => contestEffort (m * stepValue r κ d) ch) := by
  intro a b hab
  simp only [contestEffort]
  apply div_lt_div_of_pos_right _ (by positivity)
  exact mul_lt_mul_of_pos_left (p15_strictMono hr hκ hab) hm

/-- **P15, A.6 proof line 1142: "while step effort rises"** (separate budgets; the replication
code's winner-only step contest, `r = 0.05`, `κ = 0.5`, `m = 0.05`, `c = 1`, `L = 0`). -/
theorem p15_separate_step_rises :
    StrictMono (fun d => contestEffort ((1/20) * stepValue (1/20) (1/2) d) 1) :=
  p15_b_strictMono (by norm_num) (by norm_num) (by norm_num) (by norm_num)

/-- **P15 (b), unstated condition: durable rents to both firms.**  If each firm banks the durable
share of its own products, the loser keeps `m·d/r` and the prize gap is `m(1−d)/(r+κ)`, which
falls in `d`. -/
theorem p15_b_banks_own_gap {r κ m d : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) :
    m * stepValue r κ d - m * (d * nonErodingValue r) = m * (1 - d) / (r + κ) := by
  rw [(p15_value hr hκ).1, p12_nonEroding_value hr]
  have : 0 < r + κ := by linarith
  field_simp
  ring

/-- **P15 (b), A.6 proof line 1142: step effort falls from 0.023 to 0** (`r = 0.05`, `κ = 0.5`,
`m = 0.05`, `c = 1`, the replication code's values): the equilibrium effort is `1/44`
(printed 0.023) at `d = 0`; at `d = 1` the gap is zero, and zero is every firm's strict best reply
to every rival effort, so the equilibrium effort is 0. -/
theorem p15_b_banks_own_example :
    contestEffort ((1/20) * stepValue (1/20) (1/2) 0 - (1/20) * (0 * nonErodingValue (1/20)))
        1 = 1/44 ∧
    ((0.0225:ℝ) ≤ 1/44 ∧ (1/44:ℝ) < 0.0235) ∧
    (1/20) * stepValue (1/20) (1/2) 1 = 1 ∧ (1/20) * (1 * nonErodingValue (1/20)) = 1 ∧
    (∀ x ≥ 0, tullockPayoff 1 1 1 0 x 0 ≤ tullockPayoff 1 1 1 0 0 0) ∧
    (∀ y x : ℝ, 0 < x → tullockPayoff 1 1 1 0 x y < tullockPayoff 1 1 1 0 0 y) := by
  have e : ∀ s : ℝ, s * 1 + (1 - s) * 1 = 1 := fun s => by ring
  refine ⟨?_, by norm_num, ?_, ?_, fun x hx => tullock_nash_zero_prize (by norm_num) x hx,
    fun y x hx => ?_⟩
  rotate_left 3
  · unfold tullockPayoff
    rw [e, e]
    linarith
  · rw [p15_b_banks_own_gap (by norm_num) (by norm_num), contestEffort]; norm_num
  · rw [(p15_value (by norm_num) (by norm_num)).1]; norm_num
  · rw [p12_nonEroding_value (by norm_num)]; norm_num

/-- **P15 (b), unstated condition: continuation value in the step stake.**  With stake
`V(d) + P·ρ(d)`, `ρ(d) = 0.5(1 − d)`, `P = 100`, `r = 0.05`, `κ = 0.5`: the stake falls in `d`,
from `570/11` (printed 51.8) to `20` (printed 20.0). -/
theorem p15_b_stake_dilutes :
    StrictAnti (fun d => stepValue (1/20) (1/2) d + 100 * (1/2 * (1 - d))) ∧
    stepValue (1/20) (1/2) 0 + 100 * (1/2 * (1 - 0)) = 570/11 ∧
    stepValue (1/20) (1/2) 1 + 100 * (1/2 * (1 - 1)) = 20 ∧
    ((51.75:ℝ) ≤ 570/11 ∧ (570/11:ℝ) < 51.85) := by
  have hv : ∀ d, stepValue (1/20) (1/2) d = (1 - d) / (1/20 + 1/2) + d / (1/20) := fun d =>
    (p15_value (by norm_num) (by norm_num)).1
  refine ⟨?_, ?_, ?_, by norm_num⟩
  · have hlin : ∀ d, stepValue (1/20) (1/2) d + 100 * (1/2 * (1 - d)) = 570/11 - 350/11 * d := by
      intro d; rw [hv]; ring
    intro a b hab
    simp only [hlin]
    linarith
  · rw [hv]; norm_num
  · rw [hv]; norm_num

/-! ### P15 (c): two contests sharing a quadratic effort cost -/

/-- Firm's payoff with step prize `Ds`, decisive prize `Dd`, joint cost `k(a+b)²/2`, rival
efforts `ys, yd`; no private catastrophe cost. -/
noncomputable def twoContestPayoff (Ds Dd k a b ys yd : ℝ) : ℝ :=
  Ds * share a ys + Dd * share b yd - k * (a + b) ^ 2 / 2

/-- `Y = √((D_s + D_d)/(4k))`. -/
noncomputable def Ytot (Ds Dd k : ℝ) : ℝ := Real.sqrt ((Ds + Dd) / (4 * k))
/-- `x_s = D_s/(4kY)`. -/
noncomputable def xStep (Ds Dd k : ℝ) : ℝ := Ds / (4 * k * Ytot Ds Dd k)
/-- `x_d = D_d/(4kY)`. -/
noncomputable def xDec (Ds Dd k : ℝ) : ℝ := Dd / (4 * k * Ytot Ds Dd k)

theorem Ytot_pos {Ds Dd k : ℝ} (hDs : 0 ≤ Ds) (hDd : 0 < Dd) (hk : 0 < k) :
    0 < Ytot Ds Dd k :=
  Real.sqrt_pos.2 (by positivity)

theorem Ytot_sq {Ds Dd k : ℝ} (hDs : 0 ≤ Ds) (hDd : 0 < Dd) (hk : 0 < k) :
    Ytot Ds Dd k ^ 2 = (Ds + Dd) / (4 * k) :=
  Real.sq_sqrt (by positivity)

/-- **P15 (c).** `Y = x_s + x_d` is each firm's total effort. -/
theorem p15_c_total {Ds Dd k : ℝ} (hDs : 0 ≤ Ds) (hDd : 0 < Dd) (hk : 0 < k) :
    xStep Ds Dd k + xDec Ds Dd k = Ytot Ds Dd k := by
  have hY := Ytot_pos hDs hDd hk
  have h2 := Ytot_sq hDs hDd hk
  unfold xStep xDec
  rw [← add_div, div_eq_iff (by positivity)]
  have : Ds + Dd = 4 * k * Ytot Ds Dd k ^ 2 := by rw [h2]; field_simp
  linear_combination this

/-- **P15 (c).** The profile given by the formulas is a Nash equilibrium: no joint deviation
`(a, b) ≥ 0` in the two efforts beats it (`D_s ≥ 0`, including the corner `D_s = 0`). -/
theorem p15_c_nash {Ds Dd k : ℝ} (hDs : 0 ≤ Ds) (hDd : 0 < Dd) (hk : 0 < k) (a b : ℝ)
    (ha : 0 ≤ a) (hb : 0 ≤ b) :
    twoContestPayoff Ds Dd k a b (xStep Ds Dd k) (xDec Ds Dd k)
      ≤ twoContestPayoff Ds Dd k (xStep Ds Dd k) (xDec Ds Dd k) (xStep Ds Dd k)
          (xDec Ds Dd k) := by
  have hY := Ytot_pos hDs hDd hk
  have hsum := p15_c_total hDs hDd hk
  set Y := Ytot Ds Dd k with hYdef
  set xs := xStep Ds Dd k with hxsdef
  set xd := xDec Ds Dd k with hxddef
  have hxd : 4 * k * Y * xd = Dd := by rw [hxddef, xDec, ← hYdef]; field_simp
  have hxdpos : 0 < xd := by rw [hxddef, xDec]; positivity
  have hS : Ds * share a xs ≤ Ds * share xs xs + k * Y * (a - xs) := by
    rcases hDs.lt_or_eq with hpos | hzero
    · have hxs : 4 * k * Y * xs = Ds := by rw [hxsdef, xStep, ← hYdef]; field_simp
      have hxspos : 0 < xs := by rw [hxsdef, xStep]; positivity
      rw [share_self hxspos]
      have ht := share_tangent ha hxspos
      have h1 : Ds * share a xs ≤ Ds * (1 / 2 + (a - xs) / (4 * xs)) :=
        mul_le_mul_of_nonneg_left ht hDs
      have e : Ds * (1 / 2 + (a - xs) / (4 * xs)) = Ds * (1 / 2) + k * Y * (a - xs) := by
        rw [← hxs]; field_simp
      linarith
    · have hxs0 : xs = 0 := by rw [hxsdef, xStep, ← hzero]; simp
      rw [← hzero, hxs0]
      simp only [zero_mul, sub_zero, zero_add]
      positivity
  have hD : Dd * share b xd ≤ Dd * share xd xd + k * Y * (b - xd) := by
    rw [share_self hxdpos]
    have ht := share_tangent hb hxdpos
    have h1 : Dd * share b xd ≤ Dd * (1 / 2 + (b - xd) / (4 * xd)) :=
      mul_le_mul_of_nonneg_left ht hDd.le
    have e : Dd * (1 / 2 + (b - xd) / (4 * xd)) = Dd * (1 / 2) + k * Y * (b - xd) := by
      rw [← hxd]; field_simp
    linarith
  have hQ : -(k * (a + b) ^ 2 / 2) ≤ -(k * Y ^ 2 / 2) - k * Y * (a + b - Y) := by
    nlinarith [sq_nonneg (a + b - Y)]
  have hkY : k * Y * xs + k * Y * xd = k * Y * Y := by rw [← hsum]; ring
  unfold twoContestPayoff
  rw [hsum]
  nlinarith

/-- **P15 (c).** For `D_s > 0`, both first-order conditions hold at the profile. -/
theorem p15_c_foc {Ds Dd k : ℝ} (hDs : 0 < Ds) (hDd : 0 < Dd) (hk : 0 < k) :
    HasDerivAt (fun a => twoContestPayoff Ds Dd k a (xDec Ds Dd k) (xStep Ds Dd k)
        (xDec Ds Dd k)) 0 (xStep Ds Dd k) ∧
    HasDerivAt (fun b => twoContestPayoff Ds Dd k (xStep Ds Dd k) b (xStep Ds Dd k)
        (xDec Ds Dd k)) 0 (xDec Ds Dd k) := by
  have hY := Ytot_pos hDs.le hDd hk
  have hsum := p15_c_total hDs.le hDd hk
  set Y := Ytot Ds Dd k with hYdef
  set xs := xStep Ds Dd k with hxsdef
  set xd := xDec Ds Dd k with hxddef
  have hxs : 4 * k * Y * xs = Ds := by rw [hxsdef, xStep, ← hYdef]; field_simp
  have hxd : 4 * k * Y * xd = Dd := by rw [hxddef, xDec, ← hYdef]; field_simp
  have hxspos : 0 < xs := by rw [hxsdef, xStep]; positivity
  have hxdpos : 0 < xd := by rw [hxddef, xDec]; positivity
  constructor
  · have hq : HasDerivAt (fun a => k * (a + xd) ^ 2 / 2) (k * (xs + xd)) xs := by
      have := ((((hasDerivAt_id' xs).add_const xd).pow 2).const_mul k).div_const 2
      convert this using 1
      simp
      ring
    have h := (((hasDerivAt_share_self hxspos).const_mul Ds).add_const
      (Dd * share xd xd)).sub hq
    unfold twoContestPayoff
    convert h using 1
    rw [hsum, ← hxs]
    field_simp
    ring
  · have hq : HasDerivAt (fun b => k * (xs + b) ^ 2 / 2) (k * (xs + xd)) xd := by
      have := ((((hasDerivAt_id' xd).const_add xs).pow 2).const_mul k).div_const 2
      convert this using 1
      simp
      ring
    have h := (((hasDerivAt_share_self hxdpos).const_mul Dd).const_add
      (Ds * share xs xs)).sub hq
    unfold twoContestPayoff
    convert h using 1
    rw [hsum, ← hxd]
    field_simp
    ring

/-- **P15 (c).** "The first-order conditions give …": a positive symmetric profile satisfying
`D_s/(4x_s) = kY = D_d/(4x_d)`, `Y = x_s + x_d`, is the one given by the formulas. -/
theorem p15_c_foc_determine {Ds Dd k xs' xd' : ℝ} (hk : 0 < k)
    (h1 : 0 < xs') (h2 : 0 < xd') (e1 : Ds / (4 * xs') = k * (xs' + xd'))
    (e2 : Dd / (4 * xd') = k * (xs' + xd')) :
    xs' = xStep Ds Dd k ∧ xd' = xDec Ds Dd k := by
  have hY' : 0 < xs' + xd' := by positivity
  have hs : Ds = 4 * k * (xs' + xd') * xs' := by
    rw [div_eq_iff (by positivity)] at e1; linarith
  have hd : Dd = 4 * k * (xs' + xd') * xd' := by
    rw [div_eq_iff (by positivity)] at e2; linarith
  have hYsq : (Ds + Dd) / (4 * k) = (xs' + xd') ^ 2 := by
    rw [hs, hd]; field_simp
  have hYeq : Ytot Ds Dd k = xs' + xd' := by
    rw [Ytot, hYsq, Real.sqrt_sq hY'.le]
  unfold xStep xDec
  rw [hYeq]
  constructor
  · rw [hs]; field_simp
  · rw [hd]; field_simp

/-- **P15 (c).** At `D_s = 0`: `x_s = 0` and `x_d = Y = √(D_d/(4k))`. -/
theorem p15_c_Ds_zero {Dd k : ℝ} (hDd : 0 < Dd) (hk : 0 < k) :
    xStep 0 Dd k = 0 ∧ xDec 0 Dd k = Real.sqrt (Dd / (4 * k)) ∧
    Ytot 0 Dd k = Real.sqrt (Dd / (4 * k)) := by
  have hpos : 0 < Real.sqrt (Dd / (4 * k)) := Real.sqrt_pos.2 (by positivity)
  refine ⟨by simp [xStep], ?_, by simp [Ytot]⟩
  unfold xDec Ytot
  rw [zero_add, show Dd / (4 * k * Real.sqrt (Dd / (4 * k)))
      = (Dd / (4 * k)) / Real.sqrt (Dd / (4 * k)) by field_simp, Real.div_sqrt]

/-- **P15 (c).** Decisive effort falls as `D_s` rises. -/
theorem p15_c_decisive_strictAnti {Dd k : ℝ} (hDd : 0 < Dd) (hk : 0 < k) :
    StrictAntiOn (fun Ds => xDec Ds Dd k) (Ici 0) := by
  intro a ha b hb hab
  simp only [mem_Ici] at ha hb
  simp only [xDec]
  have hYa := Ytot_pos ha hDd hk
  have hlt : Ytot a Dd k < Ytot b Dd k := by
    unfold Ytot
    apply Real.sqrt_lt_sqrt (by positivity)
    exact div_lt_div_of_pos_right (by linarith) (by positivity)
  exact div_lt_div_of_pos_left hDd (by positivity) (by nlinarith)

/-- Total risk `θ_s X_s + θ_d X_d`, `X = 2x`. -/
noncomputable def totalRisk (θs θd Ds Dd k : ℝ) : ℝ :=
  θs * (2 * xStep Ds Dd k) + θd * (2 * xDec Ds Dd k)

/-- **P15 (c).** The derivative of total risk in `D_s`. -/
theorem p15_c_risk_hasDerivAt {θs θd Ds Dd k : ℝ} (hDs : 0 ≤ Ds) (hDd : 0 < Dd) (hk : 0 < k) :
    HasDerivAt (fun D => totalRisk θs θd D Dd k)
      ((θs * Ds + (2 * θs - θd) * Dd) / (16 * k ^ 2 * Ytot Ds Dd k ^ 3)) Ds := by
  have hY := Ytot_pos hDs hDd hk
  have hY2 := Ytot_sq hDs hDd hk
  have hfun : (fun D => totalRisk θs θd D Dd k)
      = fun D => (2 * θs * D + 2 * θd * Dd) / (4 * k * Real.sqrt ((D + Dd) / (4 * k))) := by
    funext D
    unfold totalRisk xStep xDec Ytot
    ring
  rw [hfun]
  have hg : HasDerivAt (fun D => (D + Dd) / (4 * k)) (1 / (4 * k)) Ds := by
    simpa using ((hasDerivAt_id Ds).add_const Dd).div_const (4 * k)
  have hgne : (Ds + Dd) / (4 * k) ≠ 0 := by positivity
  have hsq := hg.sqrt hgne
  have hQ := hsq.const_mul (4 * k)
  have hN : HasDerivAt (fun D => 2 * θs * D + 2 * θd * Dd) (2 * θs) Ds := by
    simpa using ((hasDerivAt_id Ds).const_mul (2 * θs)).add_const (2 * θd * Dd)
  have hQne : 4 * k * Real.sqrt ((Ds + Dd) / (4 * k)) ≠ 0 := by
    have : 0 < Real.sqrt ((Ds + Dd) / (4 * k)) := Real.sqrt_pos.2 (by positivity)
    positivity
  have h := hN.div hQ hQne
  convert h using 1
  rw [← Ytot]
  set Y := Ytot Ds Dd k
  have key : 8 * k * θs * Y ^ 2 = 2 * θs * (Ds + Dd) := by rw [hY2]; field_simp; ring
  calc (θs * Ds + (2 * θs - θd) * Dd) / (16 * k ^ 2 * Y ^ 3)
      = (8 * k * θs * Y ^ 2 - (θs * Ds + θd * Dd)) / (16 * k ^ 2 * Y ^ 3) := by
        rw [key]; ring
    _ = _ := by field_simp; ring

/-- **P15 (c), one-sided at the corner (line 1142: "derivatives there are one-sided").** The
derivative of total risk within `D_s ≥ 0`, the model's domain, including `D_s = 0`. -/
theorem p15_c_risk_hasDerivWithinAt {θs θd Ds Dd k : ℝ} (hDs : 0 ≤ Ds) (hDd : 0 < Dd)
    (hk : 0 < k) :
    HasDerivWithinAt (fun D => totalRisk θs θd D Dd k)
      ((θs * Ds + (2 * θs - θd) * Dd) / (16 * k ^ 2 * Ytot Ds Dd k ^ 3)) (Ici 0) Ds :=
  (p15_c_risk_hasDerivAt hDs hDd hk).hasDerivWithinAt

/-- **P15 (c).** Total risk rises with `D_s` iff `θ_d/θ_s < 2 + D_s/D_d`. -/
theorem p15_c_risk_rises_iff {θs θd Ds Dd k : ℝ} (hθs : 0 < θs) (hDs : 0 ≤ Ds) (hDd : 0 < Dd)
    (hk : 0 < k) :
    0 < (θs * Ds + (2 * θs - θd) * Dd) / (16 * k ^ 2 * Ytot Ds Dd k ^ 3)
      ↔ θd / θs < 2 + Ds / Dd := by
  have hY := Ytot_pos hDs hDd hk
  have hden : 0 < 16 * k ^ 2 * Ytot Ds Dd k ^ 3 := by positivity
  have e : θd / θs < 2 + Ds / Dd ↔ θd * Dd < θs * (2 * Dd + Ds) := by
    rw [div_lt_iff₀ hθs, show (2 + Ds / Dd) * θs = θs * (2 * Dd + Ds) / Dd by field_simp,
      lt_div_iff₀ hDd]
  rw [lt_div_iff₀ hden, zero_mul, e]
  constructor <;> intro h <;> linarith

/-- Separate budgets: the decisive contest alone, cost `kb²/2`. -/
noncomputable def decPayoff (Dd k b y : ℝ) : ℝ := Dd * share b y - k * b ^ 2 / 2

/-- **P15 (c), separate budgets.** Decisive effort `√(D_d/(4k))` is an equilibrium of the
decisive contest; `d` and `D_s` do not enter it. -/
theorem p15_separate_nash {Dd k : ℝ} (hDd : 0 < Dd) (hk : 0 < k) (b : ℝ) (hb : 0 ≤ b) :
    decPayoff Dd k b (Real.sqrt (Dd / (4 * k)))
      ≤ decPayoff Dd k (Real.sqrt (Dd / (4 * k))) (Real.sqrt (Dd / (4 * k))) := by
  set y := Real.sqrt (Dd / (4 * k)) with hy
  have hypos : 0 < y := Real.sqrt_pos.2 (by positivity)
  have hy2 : y ^ 2 = Dd / (4 * k) := Real.sq_sqrt (by positivity)
  have hDdy : Dd = 4 * k * y * y := by rw [show 4 * k * y * y = 4 * k * y ^ 2 by ring, hy2]; field_simp
  unfold decPayoff
  rw [share_self hypos]
  have ht := share_tangent hb hypos
  have h1 : Dd * share b y ≤ Dd * (1 / 2 + (b - y) / (4 * y)) := mul_le_mul_of_nonneg_left ht hDd.le
  have e : Dd * (1 / 2 + (b - y) / (4 * y)) = Dd * (1 / 2) + k * y * (b - y) := by
    rw [hDdy]; field_simp
  nlinarith [sq_nonneg (b - y)]

/-- **P15, A.6 proof line 1142: "decisive effort stays at 0.71"** (`D_d = 2`, `k = 1`, the
replication code's values): `√(2/4) ∈ [0.705, 0.715)`. -/
theorem p15_separate_numeric :
    (0.705:ℝ) ≤ Real.sqrt (2 / (4 * 1)) ∧ Real.sqrt (2 / (4 * 1)) < 0.715 := by
  constructor
  · rw [Real.le_sqrt (by norm_num) (by norm_num)]; norm_num
  · rw [Real.sqrt_lt' (by norm_num)]; norm_num

end RTTR.Program

#print axioms RTTR.Program.integral_exp_neg_mul_Ioi_zero
#print axioms RTTR.Program.integral_exp_neg_mul_interval
#print axioms RTTR.Program.share_self
#print axioms RTTR.Program.share_tangent
#print axioms RTTR.Program.hasDerivAt_share_self
#print axioms RTTR.Program.tullock_nash
#print axioms RTTR.Program.tullock_nash_zero_prize
#print axioms RTTR.Program.p12_eroding_value
#print axioms RTTR.Program.p12_nonEroding_value
#print axioms RTTR.Program.p12_nonEroding_infinite_at_zero
#print axioms RTTR.Program.p12_ratio_eq
#print axioms RTTR.Program.p12_ratio_strictMono
#print axioms RTTR.Program.p12_power_rent_revenue
#print axioms RTTR.Program.p12_power_rent_value
#print axioms RTTR.Program.p12_incremental_nash
#print axioms RTTR.Program.p12_incremental_effort_strictAnti
#print axioms RTTR.Program.p12_contest_values
#print axioms RTTR.Program.holdValue_eq
#print axioms RTTR.Program.holdValue_eq_expectation
#print axioms RTTR.Program.p13_general
#print axioms RTTR.Program.p13_main
#print axioms RTTR.Program.p13_ratio
#print axioms RTTR.Program.p13_delta_zero
#print axioms RTTR.Program.p13_i_VH
#print axioms RTTR.Program.p13_i_threshold
#print axioms RTTR.Program.p13_i_delta_zero
#print axioms RTTR.Program.p13_ii
#print axioms RTTR.Program.p13_ii_Z
#print axioms RTTR.Program.p13_undiscounted
#print axioms RTTR.Program.p13_counter_interactive
#print axioms RTTR.Program.p13_counter_artifact
#print axioms RTTR.Program.fig20_VH_gt_Z_iff
#print axioms RTTR.Program.fig20_all_pass
#print axioms RTTR.Program.releaseValueLin_eq
#print axioms RTTR.Program.planValueLin_eq
#print axioms RTTR.Program.noReleaseValueLin_eq
#print axioms RTTR.Program.p13_live_old_closed
#print axioms RTTR.Program.p13_live_new_closed
#print axioms RTTR.Program.p13_live_rule_approves_yet_lowers_optimum
#print axioms RTTR.Program.p13_optional_use_cannot_lower
#print axioms RTTR.Program.noReleaseValuePow_eq
#print axioms RTTR.Program.p13_paper_example_noRelease
#print axioms RTTR.Program.p14Value_eq
#print axioms RTTR.Program.p14_liminf_iff
#print axioms RTTR.Program.p14_i
#print axioms RTTR.Program.p14_i_liminf
#print axioms RTTR.Program.p14_ii
#print axioms RTTR.Program.p14_ii_linear_strictMono
#print axioms RTTR.Program.p14_ii_linear_tendsto
#print axioms RTTR.Program.p14_iii
#print axioms RTTR.Program.p14_iii_needs_r_nonneg
#print axioms RTTR.Program.p14_sqrt_unbounded
#print axioms RTTR.Program.p14_sqrt_numeric
#print axioms RTTR.Program.p14_log_unbounded
#print axioms RTTR.Program.p14_theft_on_value_fixed_point
#print axioms RTTR.Program.p14_theft_on_value_asymp
#print axioms RTTR.Program.p14_security_unbounded
#print axioms RTTR.Program.p14_security_numeric
#print axioms RTTR.Program.p15_value
#print axioms RTTR.Program.p15_hasDerivAt
#print axioms RTTR.Program.p15_strictMono
#print axioms RTTR.Program.p15_kappa_zero
#print axioms RTTR.Program.p15_a_eq
#print axioms RTTR.Program.p15_a_strictAnti
#print axioms RTTR.Program.p15_a_antitone
#print axioms RTTR.Program.p15_b_nash
#print axioms RTTR.Program.p15_b_strictMono
#print axioms RTTR.Program.p15_b_banks_own_gap
#print axioms RTTR.Program.p15_b_banks_own_example
#print axioms RTTR.Program.p15_b_stake_dilutes
#print axioms RTTR.Program.Ytot_pos
#print axioms RTTR.Program.Ytot_sq
#print axioms RTTR.Program.p15_c_total
#print axioms RTTR.Program.p15_c_nash
#print axioms RTTR.Program.p15_c_foc
#print axioms RTTR.Program.p15_c_foc_determine
#print axioms RTTR.Program.p15_c_Ds_zero
#print axioms RTTR.Program.p15_c_decisive_strictAnti
#print axioms RTTR.Program.p15_c_risk_hasDerivAt
#print axioms RTTR.Program.p15_c_risk_rises_iff
#print axioms RTTR.Program.p15_separate_nash
#print axioms RTTR.Program.p15_separate_numeric
-- Fix round 1
#print axioms RTTR.Program.p12_copied_worth_less
#print axioms RTTR.Program.p13_corollaries_undetermined
#print axioms RTTR.Program.planValueLin_le
#print axioms RTTR.Program.optSetLin_bddAbove
#print axioms RTTR.Program.p13_optional_use_cannot_lower_model
#print axioms RTTR.Program.p14_cap_needs_extinguished_value
#print axioms RTTR.Program.p15_separate_step_rises
#print axioms RTTR.Program.p15_c_risk_hasDerivWithinAt
