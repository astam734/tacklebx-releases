import Mathlib

/-!
# Seat L1a — sub-model Speed: Propositions 1, 2, 4, 5 of "Running Through the Rain" (v8)

Line numbers refer to `PAPER-DRAFT-v8.md`. Statements: P1 889–893, P2 895–897, P4 913–917,
P5 919–923; proofs A.6, 1114–1122. Main-text restatements checked: line 26, §4.2–§4.4 (90–140),
§4.6 (157–169), and every other hit of "Proposition 1/2/4/5".

## How each paper object is represented, and why that is faithful

* **The loss index** `R_c(s) = H(s)·max(K/s, T_a) + S` (`Rc`). The paper *defines* it so (A.2.2,
  A.2.4: `T(s) = max(K/s, T_a)`), so the closed form is the definition (COMMON rule 1).
* **The elasticity** `ε_H = sH′/H` (`elast H H' s`), where `H'` is the derivative function that
  A4 supplies. `H'` is tied to `H` by the A4 hypothesis, never free.
* **A4** (`A4 H H' s_min`): on the speed domain `[s_min, ∞)`, `H > 0`, `H` has derivative `H'`
  *within* `[s_min, ∞)` (one-sided at `s_min`, two-sided at every interior speed), and `H′ > 0`.
  This is exactly "positive and differentiable, with `H′ > 0`" on the stated domain.
* **"dR_c/ds = …" on a branch** is `HasDerivAt (Rc H K Ta S) … s` for the function as defined,
  at a speed strictly inside the branch (`s_min < s < s*` or `s > s*`); the closed branch form is
  shown to agree with `Rc` on a neighbourhood, not merely at the point. **One-sided derivatives at
  `s*`** are `HasDerivWithinAt` on `Iic s*` / `Ici s*`. At the domain endpoint `s_min` the
  capability-branch derivative is the right derivative, `HasDerivWithinAt` on `Ici s_min`
  (`p1_deriv_at_smin`); its sign is that of `derivWithin`. The P4(ii) discounted near losses get
  the same endpoint treatment (`p4_ii_deriv_at_smin`, `p4_profile_deriv_at_smin` and their iffs).
* **"Acceleration lowers `R_c` at `s`"** is `deriv (Rc …) s < 0`.
* **Minimisers** are `IsMinOn (Rc …) (Ici s_min) m`: global minimisers over the whole domain.
* **P2**: `S = Σ_{k∈I} N_k ψ_k d_k` over a finite set of steps (`stepTerm`). "Independent of `s`"
  is congruence (algebraic content, as the paper's "identity"); "falls with `N`" is strict decrease
  under a coordinatewise decrease that is strict somewhere.
* **P4**: `C_c`, `C_A`, `P_c`, `P_A` are arbitrary differentiable functions in (i), (iii), (iv),
  because the paper states those parts for arbitrary cumulative hazards and probabilities; their
  content is the derivative plus an algebraic rearrangement, and the docstrings say so. The
  **discounted near loss** is *defined as the integral* `∫₀^{T(s)} H(s)e^{−rt} dt + S_r`
  (`nearDisc`), and the closed form `H(1 − e^{−rT})/r + S_r` is proved. The rate is taken
  `r > 0` (the closed form needs `r ≠ 0`; "below one" fails for `r < 0`,
  `p4_ii_threshold_gt_one_of_neg`); the paper does not state the sign (a finding). For a **general fixed
  profile** the near loss is *defined as* `∫₀^{T} e^{−rt} H g(t/T) dt + S_r` (`nearProf`), `ψ` is
  *defined as* `∫₀¹ e^{−xu} g(u) du` (`psi`), its derivative is *derived* by differentiation under
  the integral sign (`hasDerivAt_psi`), and the closed form `HTψ(rT)` by change of variable. The
  profile `g` is assumed interval-integrable on `[0, 1]`, nonnegative there, with `∫₀¹ g = 1`;
  nonnegativity is not stated in the paper (a finding, `p4_profile_needs_nonneg`).
* **P5**: `T_a(s) = A(s/s₀)^{−β}` with real powers (`TaP`), the kink as printed (`kinkP`). "Adoption
  binds" is read strictly, `K/s < T_a(s)`; "capability binds" as `T_a(s) < K/s`. "`s*` rises with
  `β`" is proved both as the sign of `ds*/dβ` and as `StrictMonoOn` on `β < 1`.
* **Printed decimals** (0.58, 0.39, 0.72, 2.12, 5.9, 20.0) are proved as intervals of half a unit
  in the last printed digit around the exact closed form, which is also proved.

Nothing here imports another file of this project. There are no proof holes and no added
axioms; the audit block at the end prints the axioms of every theorem.
-/

open Set Filter Topology MeasureTheory intervalIntegral Real

namespace RTTR.Speed

/-! ## P1 -/

/-- The loss index `R_c(s) = H(s)·T(s) + S` with `T(s) = max(K/s, T_a)` (A.2.2, A.2.4). -/
noncomputable def Rc (H : ℝ → ℝ) (K Ta S : ℝ) (s : ℝ) : ℝ := H s * max (K / s) Ta + S

/-- The elasticity `ε_H = sH′/H`. -/
noncomputable def elast (H H' : ℝ → ℝ) (s : ℝ) : ℝ := s * H' s / H s

/-- A4 on the speed domain `[s_min, ∞)`. -/
structure A4 (H H' : ℝ → ℝ) (smin : ℝ) : Prop where
  pos : ∀ s ∈ Ici smin, 0 < H s
  deriv : ∀ s ∈ Ici smin, HasDerivWithinAt H (H' s) (Ici smin) s
  deriv_pos : ∀ s ∈ Ici smin, 0 < H' s

theorem hasDerivAt_K_div (K s : ℝ) (hs : s ≠ 0) :
    HasDerivAt (fun x : ℝ => K / x) (-K / s ^ 2) s := by
  have h := (hasDerivAt_inv hs).const_mul K
  convert h using 1
  · ext x; simp [div_eq_mul_inv]
  · rw [div_eq_mul_inv]; ring

theorem max_cap {K Ta s : ℝ} (hTa : 0 < Ta) (hs : 0 < s) (h : s ≤ K / Ta) :
    max (K / s) Ta = K / s := by
  apply max_eq_left
  rw [le_div_iff₀ hs]; rw [le_div_iff₀ hTa] at h; linarith

theorem max_adopt {K Ta s : ℝ} (hTa : 0 < Ta) (hs : 0 < s) (h : K / Ta ≤ s) :
    max (K / s) Ta = Ta := by
  apply max_eq_right
  rw [div_le_iff₀ hs]; rw [div_le_iff₀ hTa] at h; linarith

theorem A4.hasDerivAt {H H' : ℝ → ℝ} {smin s : ℝ} (hA : A4 H H' smin) (hs : smin < s) :
    HasDerivAt H (H' s) s :=
  (hA.deriv s hs.le).hasDerivAt (Ici_mem_nhds hs)

theorem A4.continuousOn {H H' : ℝ → ℝ} {smin : ℝ} (hA : A4 H H' smin) :
    ContinuousOn H (Ici smin) := fun s hs => (hA.deriv s hs).continuousWithinAt

section P1
variable {H H' : ℝ → ℝ} {K Ta S smin : ℝ}

theorem rc_eventually_cap (hTa : 0 < Ta) {s : ℝ} (hs : 0 < s) (hk : s < K / Ta) :
    (fun x => H x * (K / x) + S) =ᶠ[𝓝 s] Rc H K Ta S := by
  filter_upwards [isOpen_Ioo.mem_nhds (show s ∈ Ioo 0 (K / Ta) from ⟨hs, hk⟩)] with x hx
  simp [Rc, max_cap hTa hx.1 hx.2.le]

theorem rc_eventually_adopt (hTa : 0 < Ta) {s : ℝ} (hk : K / Ta < s) (hKs : 0 < s) :
    (fun x => H x * Ta + S) =ᶠ[𝓝 s] Rc H K Ta S := by
  filter_upwards [isOpen_Ioi.mem_nhds (show s ∈ Ioi (max (K / Ta) 0) from
    max_lt hk hKs)] with x hx
  have hx1 : K / Ta < x := lt_of_le_of_lt (le_max_left _ _) hx
  have hx0 : 0 < x := lt_of_le_of_lt (le_max_right _ _) hx
  simp [Rc, max_adopt hTa hx0 hx1.le]

/-- **P1, capability branch: the derivative.** -/
theorem p1_deriv_below_kink (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin) {s : ℝ}
    (hs : smin < s) (hk : s < K / Ta) :
    HasDerivAt (Rc H K Ta S) ((K * H s / s ^ 2) * (elast H H' s - 1)) s := by
  have s0 : 0 < s := hsmin.trans hs
  have hHs : H s ≠ 0 := (hA.pos s hs.le).ne'
  have h1 : HasDerivAt (fun x => H x * (K / x) + S) (H' s * (K / s) + H s * (-K / s ^ 2)) s :=
    ((hA.hasDerivAt hs).mul (hasDerivAt_K_div K s s0.ne')).add_const S
  have h2 := h1.congr_of_eventuallyEq (rc_eventually_cap hTa s0 hk).symm
  convert h2 using 1
  unfold elast; field_simp; ring

/-- **P1, capability branch: the sign.** -/
theorem p1_lowers_iff_below_kink (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hK : 0 < K) {s : ℝ} (hs : smin < s) (hk : s < K / Ta) :
    deriv (Rc H K Ta S) s < 0 ↔ elast H H' s < 1 := by
  rw [(p1_deriv_below_kink (S := S) hA hTa hsmin hs hk).deriv]
  have s0 : 0 < s := hsmin.trans hs
  have hc : 0 < K * H s / s ^ 2 := by have := hA.pos s hs.le; positivity
  constructor
  · intro h; by_contra h'; replace h' := not_lt.mp h'
    have : 0 ≤ (K * H s / s ^ 2) * (elast H H' s - 1) := mul_nonneg hc.le (by linarith)
    linarith
  · intro h; exact mul_neg_of_pos_of_neg hc (by linarith)

/-- **P1, capability branch at the endpoint `s = s_min`.** Speeds range over `[s_min, ∞)`, so at
`s_min` the derivative is the right derivative (within `[s_min, ∞)`); it has the same formula. -/
theorem p1_deriv_at_smin (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hlt : smin < K / Ta) :
    HasDerivWithinAt (Rc H K Ta S) ((K * H smin / smin ^ 2) * (elast H H' smin - 1))
      (Ici smin) smin := by
  have hm : smin ∈ Ici smin := mem_Ici.mpr le_rfl
  have hHs : H smin ≠ 0 := (hA.pos smin hm).ne'
  have h1 : HasDerivWithinAt (fun x => H x * (K / x) + S)
      (H' smin * (K / smin) + H smin * (-K / smin ^ 2)) (Ici smin) smin :=
    ((hA.deriv smin hm).mul (hasDerivAt_K_div K smin hsmin.ne').hasDerivWithinAt).add_const S
  have heq : (fun x => H x * (K / x) + S) =ᶠ[𝓝[Ici smin] smin] Rc H K Ta S := by
    filter_upwards [nhdsWithin_le_nhds (isOpen_Ioo.mem_nhds
      (show smin ∈ Ioo 0 (K / Ta) from ⟨hsmin, hlt⟩))] with x hx
    simp [Rc, max_cap hTa hx.1 hx.2.le]
  have h2 := h1.congr_of_eventuallyEq heq.symm (by simp [Rc, max_cap hTa hsmin hlt.le])
  convert h2 using 1
  unfold elast; field_simp; ring

/-- **P1, capability-branch sign at `s = s_min`**, for the right derivative. -/
theorem p1_lowers_iff_at_smin (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hK : 0 < K) (hlt : smin < K / Ta) :
    derivWithin (Rc H K Ta S) (Ici smin) smin < 0 ↔ elast H H' smin < 1 := by
  have hm : smin ∈ Ici smin := mem_Ici.mpr le_rfl
  rw [(p1_deriv_at_smin (S := S) hA hTa hsmin hlt).derivWithin (uniqueDiffOn_Ici smin smin hm)]
  have hc : 0 < K * H smin / smin ^ 2 := by have := hA.pos smin hm; positivity
  constructor
  · intro h; by_contra h'; replace h' := not_lt.mp h'
    have : 0 ≤ (K * H smin / smin ^ 2) * (elast H H' smin - 1) := mul_nonneg hc.le (by linarith)
    linarith
  · intro h; exact mul_neg_of_pos_of_neg hc (by linarith)

/-- **P1, adoption branch.** -/
theorem p1_deriv_above_kink (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hlt : smin < K / Ta) {s : ℝ} (hk : K / Ta < s) :
    HasDerivAt (Rc H K Ta S) (H' s * Ta) s ∧ 0 < H' s * Ta := by
  have hs : smin < s := hlt.trans hk
  have s0 : 0 < s := hsmin.trans hs
  refine ⟨?_, mul_pos (hA.deriv_pos s hs.le) hTa⟩
  have h1 : HasDerivAt (fun x => H x * Ta + S) (H' s * Ta) s :=
    ((hA.hasDerivAt hs).mul_const Ta).add_const S
  exact h1.congr_of_eventuallyEq (rc_eventually_adopt hTa hk s0).symm

/-- **P1, the left derivative at the kink.** -/
theorem p1_left_deriv_at_kink (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hlt : smin < K / Ta) :
    HasDerivWithinAt (Rc H K Ta S)
      ((H (K / Ta) * Ta / (K / Ta)) * (elast H H' (K / Ta) - 1)) (Iic (K / Ta)) (K / Ta) := by
  set ss := K / Ta with hss
  have s0 : 0 < ss := hsmin.trans hlt
  have hHs : H ss ≠ 0 := (hA.pos ss hlt.le).ne'
  have hK : K = ss * Ta := by rw [hss]; field_simp
  have h1 : HasDerivAt (fun x => H x * (K / x) + S) (H' ss * (K / ss) + H ss * (-K / ss ^ 2)) ss :=
    ((hA.hasDerivAt hlt).mul (hasDerivAt_K_div K ss s0.ne')).add_const S
  have h2 := h1.hasDerivWithinAt (s := Iic ss)
  have heq : (fun x => H x * (K / x) + S) =ᶠ[𝓝[Iic ss] ss] Rc H K Ta S := by
    filter_upwards [self_mem_nhdsWithin,
      nhdsWithin_le_nhds (isOpen_Ioi.mem_nhds (show ss ∈ Ioi 0 from s0))] with x hx hx0
    simp [Rc, max_cap hTa hx0 hx]
  have h3 := h2.congr_of_eventuallyEq heq.symm (by simp [Rc, max_cap hTa s0 le_rfl])
  convert h3 using 1
  unfold elast; rw [hK]; field_simp; ring

/-- **P1, the right derivative at the kink.** -/
theorem p1_right_deriv_at_kink (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hlt : smin < K / Ta) :
    HasDerivWithinAt (Rc H K Ta S) (H' (K / Ta) * Ta) (Ici (K / Ta)) (K / Ta) := by
  set ss := K / Ta with hss
  have s0 : 0 < ss := hsmin.trans hlt
  have h1 : HasDerivAt (fun x => H x * Ta + S) (H' ss * Ta) ss :=
    ((hA.hasDerivAt hlt).mul_const Ta).add_const S
  have heq : (fun x => H x * Ta + S) =ᶠ[𝓝[Ici ss] ss] Rc H K Ta S := by
    filter_upwards [self_mem_nhdsWithin,
      nhdsWithin_le_nhds (isOpen_Ioi.mem_nhds (show ss ∈ Ioi 0 from s0))] with x hx hx0
    simp [Rc, max_adopt hTa hx0 hx]
  exact h1.hasDerivWithinAt.congr_of_eventuallyEq heq.symm (by simp [Rc, max_adopt hTa s0 le_rfl])

theorem rc_continuousOn (hA : A4 H H' smin) (hsmin : 0 < smin) :
    ContinuousOn (Rc H K Ta S) (Ici smin) := by
  intro s hs
  have s0 : 0 < s := lt_of_lt_of_le hsmin hs
  have hm : ContinuousAt (fun x : ℝ => max (K / x) Ta) s :=
    (continuousAt_const.div continuousAt_id s0.ne').max continuousAt_const
  exact ((hA.continuousOn s hs).mul hm.continuousWithinAt).add continuousWithinAt_const

/-- `H` is strictly increasing on the speed domain (from `H' > 0`). -/
theorem A4.strictMonoOn {smin : ℝ} (hA : A4 H H' smin) : StrictMonoOn H (Ici smin) := by
  apply strictMonoOn_of_deriv_pos (convex_Ici smin) hA.continuousOn
  intro x hx
  rw [interior_Ici] at hx
  rw [(hA.hasDerivAt hx).deriv]; exact hA.deriv_pos x (mem_Ici.mpr hx.le)

/-- On the adoption branch (from the kink on) the loss index is strictly increasing. -/
theorem rc_strictMonoOn_adopt (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hlt : smin < K / Ta) : StrictMonoOn (Rc H K Ta S) (Ici (K / Ta)) := by
  intro a ha b hb hab
  have a0 : 0 < a := hsmin.trans (lt_of_lt_of_le hlt ha)
  have b0 : 0 < b := a0.trans hab
  simp only [Rc, max_adopt hTa a0 ha, max_adopt hTa b0 hb]
  have := hA.strictMonoOn (le_of_lt (lt_of_lt_of_le hlt ha)) (le_of_lt (lt_of_lt_of_le hlt hb)) hab
  nlinarith

/-- **P1, existence.** A global minimiser of `R_c` on `[s_min, ∞)` exists, in `[s_min, s*]`. -/
theorem p1_exists_min (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hlt : smin < K / Ta) :
    ∃ m ∈ Icc smin (K / Ta), IsMinOn (Rc H K Ta S) (Ici smin) m := by
  obtain ⟨m, hm, hmin⟩ := (isCompact_Icc (a := smin) (b := K / Ta)).exists_isMinOn
    (nonempty_Icc.mpr hlt.le) ((rc_continuousOn (K := K) (Ta := Ta) (S := S) hA hsmin).mono
      Icc_subset_Ici_self)
  refine ⟨m, hm, ?_⟩
  intro x hx
  rcases le_or_gt x (K / Ta) with h | h
  · exact hmin ⟨hx, h⟩
  · have h1 := hmin (show K / Ta ∈ Icc smin (K / Ta) from ⟨hlt.le, le_rfl⟩)
    have h2 := rc_strictMonoOn_adopt (S := S) hA hTa hsmin hlt (le_refl (K / Ta)) h.le h
    simp only [mem_ofPred_eq] at h1 ⊢
    linarith

/-- **P1, location.** Every global minimiser on `[s_min, ∞)` lies in `[s_min, s*]`. -/
theorem p1_min_le_kink (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hlt : smin < K / Ta) {m : ℝ} (hm : m ∈ Ici smin) (hmin : IsMinOn (Rc H K Ta S) (Ici smin) m) :
    m ∈ Icc smin (K / Ta) := by
  refine ⟨hm, ?_⟩
  by_contra h; replace h := not_le.mp h
  have h1 := hmin (show K / Ta ∈ Ici smin from hlt.le)
  have h2 := rc_strictMonoOn_adopt (S := S) hA hTa hsmin hlt (le_refl (K / Ta)) h.le h
  simp only [mem_ofPred_eq] at h1
  linarith

/-- **P1, the kink is the unique minimiser when `ε_H < 1` on `[s_min, s*)`.** -/
theorem p1_kink_unique_min (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hK : 0 < K) (hlt : smin < K / Ta) (hε : ∀ s ∈ Ico smin (K / Ta), elast H H' s < 1) :
    IsMinOn (Rc H K Ta S) (Ici smin) (K / Ta) ∧
      ∀ m ∈ Ici smin, IsMinOn (Rc H K Ta S) (Ici smin) m → m = K / Ta := by
  have hanti : StrictAntiOn (Rc H K Ta S) (Icc smin (K / Ta)) := by
    apply strictAntiOn_of_deriv_neg (convex_Icc _ _)
      ((rc_continuousOn hA hsmin).mono Icc_subset_Ici_self)
    intro x hx
    rw [interior_Icc] at hx
    exact (p1_lowers_iff_below_kink hA hTa hsmin hK hx.1 hx.2).mpr (hε x ⟨hx.1.le, hx.2⟩)
  have hmono := rc_strictMonoOn_adopt (S := S) hA hTa hsmin hlt
  have hmin : IsMinOn (Rc H K Ta S) (Ici smin) (K / Ta) := by
    intro x hx
    simp only [mem_ofPred_eq]
    rcases lt_trichotomy x (K / Ta) with h | h | h
    · exact (hanti ⟨hx, h.le⟩ ⟨hlt.le, le_rfl⟩ h).le
    · rw [h]
    · exact (hmono (mem_Ici.mpr le_rfl) (mem_Ici.mpr h.le) h).le
  refine ⟨hmin, fun m hm hmm => ?_⟩
  have hloc := p1_min_le_kink hA hTa hsmin hlt hm hmm
  by_contra hne
  have hlt' : m < K / Ta := lt_of_le_of_ne hloc.2 hne
  have h1 := hanti hloc ⟨hlt.le, le_rfl⟩ hlt'
  have h2 := hmm (show K / Ta ∈ Ici smin from hlt.le)
  simp only [mem_ofPred_eq] at h2
  linarith

/-- **P1, the trichotomy.** Every global minimiser is `s_min`, `s*`, or an interior point of
`(s_min, s*)` with `ε_H = 1`. -/
theorem p1_min_trichotomy (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hK : 0 < K) (hlt : smin < K / Ta) {m : ℝ} (hm : m ∈ Ici smin)
    (hmin : IsMinOn (Rc H K Ta S) (Ici smin) m) :
    m = smin ∨ m = K / Ta ∨ (m ∈ Ioo smin (K / Ta) ∧ elast H H' m = 1) := by
  have hloc := p1_min_le_kink hA hTa hsmin hlt hm hmin
  rcases eq_or_lt_of_le hloc.1 with h | h
  · exact Or.inl h.symm
  rcases eq_or_lt_of_le hloc.2 with h' | h'
  · exact Or.inr (Or.inl h')
  right; right
  refine ⟨⟨h, h'⟩, ?_⟩
  have hl : IsLocalMin (Rc H K Ta S) m := hmin.isLocalMin (Ici_mem_nhds h)
  have hd := p1_deriv_below_kink (S := S) hA hTa hsmin h h'
  have h0 := hl.hasDerivAt_eq_zero hd
  have m0 : 0 < m := hsmin.trans h
  have hc : K * H m / m ^ 2 ≠ 0 := by have := hA.pos m hm; positivity
  rcases mul_eq_zero.mp h0 with h1 | h1
  · exact absurd h1 hc
  · linarith

/-- **P1 proof (line 1114), the Darboux step.** On a subinterval of the capability branch on which
`ε_H ≠ 1`, `dR_c/ds` (a derivative, so it has the intermediate-value property) keeps one sign:
`ε_H < 1` throughout or `ε_H > 1` throughout. No continuity of `H′` is assumed. -/
theorem p1_isolated_sign (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    {a b : ℝ} (ha : smin ≤ a) (hb : b ≤ K / Ta) (hK : 0 < K)
    (hne : ∀ s ∈ Ioo a b, elast H H' s ≠ 1) :
    (∀ s ∈ Ioo a b, elast H H' s < 1) ∨ (∀ s ∈ Ioo a b, 1 < elast H H' s) := by
  have hd : ∀ s ∈ Ioo a b, HasDerivWithinAt (Rc H K Ta 0)
      ((K * H s / s ^ 2) * (elast H H' s - 1)) (Ioo a b) s :=
    fun s hs => (p1_deriv_below_kink (S := 0) hA hTa hsmin (lt_of_le_of_lt ha hs.1)
      (lt_of_lt_of_le hs.2 hb)).hasDerivWithinAt
  have hc : ∀ s ∈ Ioo a b, 0 < K * H s / s ^ 2 := fun s hs => by
    have := hA.pos s (le_of_lt (lt_of_le_of_lt ha hs.1))
    have : 0 < s := by linarith [hs.1]
    positivity
  have h0 : ∀ s ∈ Ioo a b, (K * H s / s ^ 2) * (elast H H' s - 1) ≠ 0 := fun s hs =>
    mul_ne_zero (hc s hs).ne' (sub_ne_zero.mpr (hne s hs))
  rcases hasDerivWithinAt_forall_lt_or_forall_gt_of_forall_ne (convex_Ioo a b) hd h0 with h | h
  · left; intro s hs
    have := h s hs
    by_contra h'
    have : 0 ≤ (K * H s / s ^ 2) * (elast H H' s - 1) :=
      mul_nonneg (hc s hs).le (by linarith [not_lt.mp h'])
    linarith
  · right; intro s hs
    have := h s hs
    by_contra h'
    have : (K * H s / s ^ 2) * (elast H H' s - 1) ≤ 0 :=
      mul_nonpos_of_nonneg_of_nonpos (hc s hs).le (by linarith [not_lt.mp h'])
    linarith

/-- On a subinterval of the capability branch where `ε_H > 1` (resp. `< 1`) on the interior,
`R_c` is strictly increasing (resp. decreasing) on the closed subinterval. -/
theorem rc_mono_cap (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin) (hK : 0 < K)
    {x y : ℝ} (hx : smin ≤ x) (hy : y ≤ K / Ta) :
    ((∀ s ∈ Ioo x y, 1 < elast H H' s) → StrictMonoOn (Rc H K Ta S) (Icc x y)) ∧
    ((∀ s ∈ Ioo x y, elast H H' s < 1) → StrictAntiOn (Rc H K Ta S) (Icc x y)) := by
  have hcont : ContinuousOn (Rc H K Ta S) (Icc x y) :=
    (rc_continuousOn (K := K) (Ta := Ta) (S := S) hA hsmin).mono
      (fun s hs => (show smin ≤ s from le_trans hx (mem_Icc.mp hs).1))
  have hd : ∀ s ∈ interior (Icc x y), deriv (Rc H K Ta S) s
      = (K * H s / s ^ 2) * (elast H H' s - 1) := by
    intro s hs; rw [interior_Icc] at hs
    exact (p1_deriv_below_kink (S := S) hA hTa hsmin (lt_of_le_of_lt hx hs.1)
      (lt_of_lt_of_le hs.2 hy)).deriv
  have hc : ∀ s ∈ interior (Icc x y), 0 < K * H s / s ^ 2 := by
    intro s hs; rw [interior_Icc] at hs
    have := hA.pos s (le_of_lt (lt_of_le_of_lt hx hs.1))
    have : 0 < s := by linarith [hs.1]
    positivity
  refine ⟨fun h => strictMonoOn_of_deriv_pos (convex_Icc x y) hcont fun s hs => ?_,
    fun h => strictAntiOn_of_deriv_neg (convex_Icc x y) hcont fun s hs => ?_⟩
  · rw [hd s hs]
    have := h s (by rw [interior_Icc] at hs; exact hs)
    exact mul_pos (hc s hs) (by linarith)
  · rw [hd s hs]
    have := h s (by rw [interior_Icc] at hs; exact hs)
    exact mul_neg_of_pos_of_neg (hc s hs) (by linarith)

/-- **P1 proof (line 1114): "A local minimum is then a crossing of 1 from below."** At an interior
local minimum of `R_c` on the capability branch whose `ε_H = 1` point is isolated, `ε_H < 1` just
below it and `ε_H > 1` just above it. -/
theorem p1_local_min_crossing (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin) (hK : 0 < K)
    {m δ : ℝ} (hδ : 0 < δ) (hlo : smin ≤ m - δ) (hhi : m + δ ≤ K / Ta)
    (hmin : IsLocalMin (Rc H K Ta S) m)
    (hne : ∀ s ∈ Ioo (m - δ) (m + δ), s ≠ m → elast H H' s ≠ 1) :
    (∀ s ∈ Ioo (m - δ) m, elast H H' s < 1) ∧ (∀ s ∈ Ioo m (m + δ), 1 < elast H H' s) := by
  obtain ⟨e, he, hball⟩ := Metric.eventually_nhds_iff.mp hmin
  set t := min δ e / 2 with ht
  have ht0 : 0 < t := by positivity
  have htδ : t < δ := by have := min_le_left δ e; linarith
  have hte : t < e := by have := min_le_right δ e; linarith
  constructor
  · rcases p1_isolated_sign (a := m - δ) (b := m) hA hTa hsmin hlo (by linarith) hK
        (fun s hs => hne s ⟨hs.1, by linarith [hs.2]⟩ hs.2.ne) with h | h
    · exact h
    · exfalso
      have hm := (rc_mono_cap (S := S) hA hTa hsmin hK (x := m - t) (y := m) (by linarith)
        (by linarith)).1 (fun s hs => h s ⟨by linarith [hs.1], hs.2⟩)
      have h1 := hm ⟨le_rfl, by linarith⟩ ⟨by linarith, le_rfl⟩ (by linarith)
      have h2 := hball (y := m - t) (by rw [Real.dist_eq, abs_of_neg (by linarith)]; linarith)
      linarith
  · rcases p1_isolated_sign (a := m) (b := m + δ) hA hTa hsmin (by linarith) hhi hK
        (fun s hs => hne s ⟨by linarith [hs.1], hs.2⟩ hs.1.ne') with h | h
    · exfalso
      have hm := (rc_mono_cap (S := S) hA hTa hsmin hK (x := m) (y := m + t) (by linarith)
        (by linarith)).2 (fun s hs => h s ⟨hs.1, by linarith [hs.2]⟩)
      have h1 := hm ⟨le_rfl, by linarith⟩ ⟨by linarith, le_rfl⟩ (by linarith)
      have h2 := hball (y := m + t) (by rw [Real.dist_eq, abs_of_pos (by linarith)]; linarith)
      linarith
    · exact h

/-- **P1 proof (line 1114): "a crossing from above is a local maximum".** -/
theorem p1_crossing_from_above_max (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin)
    (hK : 0 < K) {m δ : ℝ} (hδ : 0 < δ) (hlo : smin ≤ m - δ) (hhi : m + δ ≤ K / Ta)
    (hl : ∀ s ∈ Ioo (m - δ) m, 1 < elast H H' s) (hr : ∀ s ∈ Ioo m (m + δ), elast H H' s < 1) :
    IsLocalMax (Rc H K Ta S) m := by
  refine Metric.eventually_nhds_iff.mpr ⟨δ, hδ, fun y hy => ?_⟩
  rw [Real.dist_eq, abs_lt] at hy
  rcases lt_trichotomy y m with h | h | h
  · have hm := (rc_mono_cap (S := S) hA hTa hsmin hK (x := y) (y := m) (by linarith)
      (by linarith)).1 (fun s hs => hl s ⟨by linarith [hs.1], hs.2⟩)
    exact (hm ⟨le_rfl, h.le⟩ ⟨h.le, le_rfl⟩ h).le
  · rw [h]
  · have hm := (rc_mono_cap (S := S) hA hTa hsmin hK (x := m) (y := y) (by linarith)
      (by linarith)).2 (fun s hs => hr s ⟨hs.1, by linarith [hs.2]⟩)
    exact (hm ⟨le_rfl, h.le⟩ ⟨h.le, le_rfl⟩ h).le

end P1

/-! ### P1 remarks and counterexamples -/

theorem rpow14 {s : ℝ} (hs : 0 < s) : s ^ (1.4 : ℝ) = s ^ (0.4 : ℝ) * s := by
  rw [show (1.4 : ℝ) = 0.4 + 1 by norm_num, rpow_add_one hs.ne']

/-- **P1 remark (line 893; proof, line 1114): without the lower bound a minimiser need not
exist.** `H = s^{1.4}` satisfies A4 on `(0, ∞)`; `R_c` has no minimiser on `(0, ∞)`, stays
strictly above `S`, and tends to `S` as `s → 0⁺`, so the infimum is approached but not attained. -/
theorem p1_no_min_without_lower_bound (K Ta S : ℝ) (hK : 0 < K) (hTa : 0 < Ta) :
    (∀ s > 0, 0 < s ^ (1.4 : ℝ) ∧
      HasDerivAt (fun x : ℝ => x ^ (1.4 : ℝ)) (1.4 * s ^ (0.4 : ℝ)) s ∧
      0 < 1.4 * s ^ (0.4 : ℝ)) ∧
    (¬ ∃ m ∈ Ioi (0 : ℝ), IsMinOn (Rc (fun x => x ^ (1.4 : ℝ)) K Ta S) (Ioi 0) m) ∧
    (∀ s > 0, S < Rc (fun x => x ^ (1.4 : ℝ)) K Ta S s) ∧
    Tendsto (Rc (fun x => x ^ (1.4 : ℝ)) K Ta S) (𝓝[>] 0) (𝓝 S) := by
  set R := Rc (fun x => x ^ (1.4 : ℝ)) K Ta S with hR
  have hge : ∀ s > 0, K * s ^ (0.4 : ℝ) + S ≤ R s := by
    intro s hs
    simp only [hR, Rc]
    have h1 : s ^ (1.4 : ℝ) * (K / s) ≤ s ^ (1.4 : ℝ) * max (K / s) Ta :=
      mul_le_mul_of_nonneg_left (le_max_left _ _) (rpow_nonneg hs.le _)
    have h2 : s ^ (1.4 : ℝ) * (K / s) = K * s ^ (0.4 : ℝ) := by
      rw [rpow14 hs]; field_simp
    linarith
  have heq : ∀ s > 0, s ≤ K / Ta → R s = K * s ^ (0.4 : ℝ) + S := by
    intro s hs hk
    simp only [hR, Rc, max_cap hTa hs hk, rpow14 hs]; field_simp
  refine ⟨fun s hs => ⟨rpow_pos_of_pos hs _, ?_, by positivity⟩, ?_, ?_, ?_⟩
  · convert hasDerivAt_rpow_const (p := (1.4 : ℝ)) (Or.inl hs.ne') using 2; norm_num
  · rintro ⟨m, hm, hmin⟩
    have hm0 : (0 : ℝ) < m := hm
    have hk0 : 0 < K / Ta := div_pos hK hTa
    set t := min m (K / Ta) / 2 with ht
    have t0 : 0 < t := by positivity
    have tm : t < m := by
      have := min_le_left m (K / Ta); linarith
    have tk : t ≤ K / Ta := by
      have := min_le_right m (K / Ta); linarith
    have h1 := hmin (show t ∈ Ioi (0 : ℝ) from t0)
    simp only [mem_ofPred_eq] at h1
    have h2 := hge m hm0
    have h3 := heq t t0 tk
    have h4 : t ^ (0.4 : ℝ) < m ^ (0.4 : ℝ) := rpow_lt_rpow t0.le tm (by norm_num)
    nlinarith
  · intro s hs
    have := hge s hs
    have : 0 < K * s ^ (0.4 : ℝ) := by positivity
    linarith
  · have hk0 : 0 < K / Ta := div_pos hK hTa
    have hc : Tendsto (fun x : ℝ => K * x ^ (0.4 : ℝ) + S) (𝓝 0) (𝓝 (K * 0 ^ (0.4 : ℝ) + S)) :=
      ((continuousAt_rpow_const 0 0.4 (Or.inr (by norm_num))).const_mul K).add_const S
    rw [zero_rpow (by norm_num), mul_zero, zero_add] at hc
    apply (hc.mono_left nhdsWithin_le_nhds).congr'
    filter_upwards [Ioo_mem_nhdsGT hk0] with x hx
    exact (heq x hx.1 hx.2.le).symm

theorem hasDerivAt_posPart_sq (a x : ℝ) :
    HasDerivAt (fun s : ℝ => (max (s - a) 0) ^ 2) (2 * max (x - a) 0) x := by
  rcases lt_trichotomy x a with h | h | h
  · have hx : max (x - a) 0 = 0 := max_eq_right (by linarith)
    rw [hx, mul_zero]
    apply (hasDerivAt_const x (0 : ℝ)).congr_of_eventuallyEq
    filter_upwards [isOpen_Iio.mem_nhds h] with s hs
    have : max (s - a) 0 = 0 := max_eq_right (by have : s < a := hs; linarith)
    simp [this]
  · subst h
    have hl : HasDerivWithinAt (fun s : ℝ => (max (s - x) 0) ^ 2) 0 (Iic x) x := by
      apply (hasDerivWithinAt_const x (Iic x) (0 : ℝ)).congr
      · intro s hs
        have : max (s - x) 0 = 0 := max_eq_right (by have : s ≤ x := hs; linarith)
        simp [this]
      · simp
    have hr : HasDerivWithinAt (fun s : ℝ => (max (s - x) 0) ^ 2) 0 (Ici x) x := by
      have hd : HasDerivAt (fun s : ℝ => (s - x) ^ 2) 0 x := by
        have := ((hasDerivAt_id x).sub_const x).fun_pow 2
        simpa using this
      apply hd.hasDerivWithinAt.congr
      · intro s hs
        have : max (s - x) 0 = s - x := max_eq_left (by have : x ≤ s := hs; linarith)
        simp [this]
      · simp
    have := hl.union hr
    rw [Iic_union_Ici, hasDerivWithinAt_univ] at this
    simpa using this
  · have hx : max (x - a) 0 = x - a := max_eq_left (by linarith)
    rw [hx]
    have hd : HasDerivAt (fun s : ℝ => (s - a) ^ 2) (2 * (x - a)) x := by
      have := ((hasDerivAt_id x).sub_const a).fun_pow 2
      simpa using this
    apply hd.congr_of_eventuallyEq
    filter_upwards [isOpen_Ioi.mem_nhds h] with s hs
    have : max (s - a) 0 = s - a := max_eq_left (by have : a < s := hs; linarith)
    simp [this]

theorem hasDerivAt_negPart_sq (a x : ℝ) :
    HasDerivAt (fun s : ℝ => (max (a - s) 0) ^ 2) (-(2 * max (a - x) 0)) x := by
  have h := (hasDerivAt_posPart_sq (-a) (-x)).comp x (hasDerivAt_neg x)
  convert h using 1
  · ext s; simp [Function.comp, sub_eq_add_neg, add_comm]
  · simp [sub_eq_add_neg, add_comm]

/-- The hazard factor of the `[2, 3]` example (proof of P1, line 1114). -/
noncomputable def qEx (s : ℝ) : ℝ := 1 + (max (2 - s) 0) ^ 2 / 10 + (max (s - 3) 0) ^ 2 / 10

noncomputable def qEx' (s : ℝ) : ℝ := -(2 * max (2 - s) 0) / 10 + 2 * max (s - 3) 0 / 10

noncomputable def HEx (s : ℝ) : ℝ := s * qEx s

noncomputable def HEx' (s : ℝ) : ℝ := qEx s + s * qEx' s

theorem hasDerivAt_qEx (x : ℝ) : HasDerivAt qEx (qEx' x) x := by
  have h := (((hasDerivAt_negPart_sq 2 x).div_const 10).const_add 1).add
    ((hasDerivAt_posPart_sq 3 x).div_const 10)
  exact h

/-- **P1 proof, the flat example (line 1114).** With `K = 4`, `T_a = 1`, `s_min = 1`,
`H = s·q(s)`: A4 holds, the global minimisers on `[1, ∞)` are exactly `[2, 3]`, and `ε_H = 1`
on all of `[2, 3]`. -/
theorem p1_flat_example (S : ℝ) :
    A4 HEx HEx' 1 ∧
    (∀ m ∈ Ici (1 : ℝ), IsMinOn (Rc HEx 4 1 S) (Ici 1) m ↔ m ∈ Icc (2 : ℝ) 3) ∧
    (∀ s ∈ Icc (2 : ℝ) 3, elast HEx HEx' s = 1) := by
  have hq1 : ∀ s, 1 ≤ qEx s := fun s => by
    unfold qEx
    have := sq_nonneg (max (2 - s) 0); have := sq_nonneg (max (s - 3) 0); linarith
  have hqeq : ∀ s ∈ Icc (2 : ℝ) 3, qEx s = 1 ∧ qEx' s = 0 := by
    intro s hs
    have h1 : max (2 - s) 0 = 0 := max_eq_right (by linarith [hs.1])
    have h2 : max (s - 3) 0 = 0 := max_eq_right (by linarith [hs.2])
    simp [qEx, qEx', h1, h2]
  have hqgt : ∀ s, s ∉ Icc (2 : ℝ) 3 → 1 < qEx s := by
    intro s hs
    rw [mem_Icc, not_and_or, not_le, not_le] at hs
    unfold qEx
    rcases hs with h | h
    · have : max (2 - s) 0 = 2 - s := max_eq_left (by linarith)
      rw [this]
      have : 0 < (2 - s) ^ 2 := by have : 0 < 2 - s := by linarith
                                   positivity
      have : 0 ≤ (max (s - 3) 0) ^ 2 := sq_nonneg _
      linarith
    · have : max (s - 3) 0 = s - 3 := max_eq_left (by linarith)
      rw [this]
      have : 0 < (s - 3) ^ 2 := by have : 0 < s - 3 := by linarith
                                   positivity
      have : 0 ≤ (max (2 - s) 0) ^ 2 := sq_nonneg _
      linarith
  have hA : A4 HEx HEx' 1 := by
    refine ⟨fun s hs => ?_, fun s _ => ?_, fun s hs => ?_⟩
    · have : (1 : ℝ) ≤ s := hs
      unfold HEx; exact mul_pos (by linarith) (by linarith [hq1 s])
    · exact ((hasDerivAt_id s).mul (hasDerivAt_qEx s)).hasDerivWithinAt.congr_deriv
        (by simp [HEx'])
    · have s1 : (1 : ℝ) ≤ s := hs
      unfold HEx' qEx qEx'
      rcases le_or_gt s 2 with h2 | h2
      · have e1 : max (2 - s) 0 = 2 - s := max_eq_left (by linarith)
        have e2 : max (s - 3) 0 = 0 := max_eq_right (by linarith)
        rw [e1, e2]; nlinarith
      · have e1 : max (2 - s) 0 = 0 := max_eq_right (by linarith)
        rw [e1]
        have : 0 ≤ max (s - 3) 0 := le_max_right _ _
        have : 0 ≤ s * (2 * max (s - 3) 0 / 10) := by positivity
        nlinarith [sq_nonneg (max (s - 3) 0)]
  have hR : ∀ s ∈ Ici (1 : ℝ), (s ≤ 4 → Rc HEx 4 1 S s = 4 * qEx s + S) ∧
      (4 < s → Rc HEx 4 1 S s = s * qEx s + S) := by
    intro s hs
    have s0 : (0 : ℝ) < s := lt_of_lt_of_le one_pos hs
    refine ⟨fun h => ?_, fun h => ?_⟩
    · rw [Rc, max_cap one_pos s0 (by norm_num; exact h), HEx]; field_simp
    · rw [Rc, max_adopt one_pos s0 (by norm_num; exact h.le), HEx]; ring
  have hlow : ∀ s ∈ Ici (1 : ℝ), 4 + S ≤ Rc HEx 4 1 S s := by
    intro s hs
    rcases le_or_gt s 4 with h | h
    · rw [(hR s hs).1 h]; linarith [hq1 s]
    · rw [(hR s hs).2 h]; nlinarith [hq1 s]
  refine ⟨hA, fun m hm => ⟨fun hmin => ?_, fun hm23 => ?_⟩, fun s hs => ?_⟩
  · by_contra hn
    have h25 : (2.5 : ℝ) ∈ Ici (1 : ℝ) := by norm_num
    have h1 := hmin h25
    simp only [mem_ofPred_eq] at h1
    have h2 : Rc HEx 4 1 S 2.5 = 4 + S := by
      rw [(hR 2.5 h25).1 (by norm_num), (hqeq 2.5 (by norm_num)).1]; ring
    have h3 : 4 + S < Rc HEx 4 1 S m := by
      have hq := hqgt m hn
      rcases le_or_gt m 4 with h | h
      · rw [(hR m hm).1 h]; linarith
      · rw [(hR m hm).2 h]; nlinarith
    linarith
  · intro x hx
    simp only [mem_ofPred_eq]
    have : Rc HEx 4 1 S m = 4 + S := by
      rw [(hR m hm).1 (by linarith [hm23.2]), (hqeq m hm23).1]; ring
    rw [this]; exact hlow x hx
  · have s0 : (0 : ℝ) < s := by linarith [hs.1]
    obtain ⟨h1, h2⟩ := hqeq s hs
    simp [elast, HEx, HEx', h1, h2, s0.ne']

theorem qEx_ge_one (s : ℝ) : 1 ≤ qEx s := by
  unfold qEx
  have := sq_nonneg (max (2 - s) 0); have := sq_nonneg (max (s - 3) 0); linarith

/-- **P1 proof, the flat example: no point is a strict crossing (line 1114).** In the flat example
`ε_H ≤ 1` on `(0, 3]` and `ε_H ≥ 1` on `[2, ∞)`, so no speed `m ≥ 1` has `ε_H < 1` just below it
and `ε_H > 1` just above it. -/
theorem p1_flat_no_strict_crossing :
    (∀ s ∈ Ioc (0 : ℝ) 3, elast HEx HEx' s ≤ 1) ∧ (∀ s ∈ Ici (2 : ℝ), 1 ≤ elast HEx HEx' s) ∧
    ∀ m ∈ Ici (1 : ℝ), ¬ ∃ δ > 0, (∀ s ∈ Ioo (m - δ) m, elast HEx HEx' s < 1) ∧
      (∀ s ∈ Ioo m (m + δ), 1 < elast HEx HEx' s) := by
  have hkey : ∀ s, 0 < s → elast HEx HEx' s = 1 + s * qEx' s / qEx s := by
    intro s hs
    have hq0 : qEx s ≠ 0 := (lt_of_lt_of_le one_pos (qEx_ge_one s)).ne'
    have hs0 : s ≠ 0 := hs.ne'
    unfold elast HEx HEx'
    field_simp
  have hle : ∀ s ∈ Ioc (0 : ℝ) 3, elast HEx HEx' s ≤ 1 := by
    intro s hs
    rw [hkey s hs.1]
    have h2 : max (s - 3) 0 = 0 := max_eq_right (by linarith [hs.2])
    have hq' : qEx' s ≤ 0 := by
      unfold qEx'; rw [h2]
      have := le_max_right (2 - s) 0
      linarith
    have : s * qEx' s / qEx s ≤ 0 :=
      div_nonpos_of_nonpos_of_nonneg (mul_nonpos_of_nonneg_of_nonpos hs.1.le hq')
        (by linarith [qEx_ge_one s])
    linarith
  have hge : ∀ s ∈ Ici (2 : ℝ), 1 ≤ elast HEx HEx' s := by
    intro s hs
    have hs2 : (2 : ℝ) ≤ s := hs
    rw [hkey s (by linarith)]
    have h1 : max (2 - s) 0 = 0 := max_eq_right (by linarith)
    have hq' : 0 ≤ qEx' s := by
      unfold qEx'; rw [h1]
      have := le_max_right (s - 3) 0
      linarith
    have : 0 ≤ s * qEx' s / qEx s :=
      div_nonneg (mul_nonneg (by linarith) hq') (by linarith [qEx_ge_one s])
    linarith
  refine ⟨hle, hge, fun m hm => ?_⟩
  rintro ⟨δ, hδ, hl, hr⟩
  have hm1 : (1 : ℝ) ≤ m := hm
  rcases lt_or_ge m 3 with h | h
  · have hmin0 : 0 < min δ (3 - m) := lt_min hδ (by linarith)
    have hmδ := min_le_left δ (3 - m)
    have hm3 := min_le_right δ (3 - m)
    have h1 := hr (m + min δ (3 - m) / 2) ⟨by linarith, by linarith⟩
    have h2 := hle (m + min δ (3 - m) / 2) ⟨by linarith, by linarith⟩
    linarith
  · have hmin0 : 0 < min δ (m - 2) := lt_min hδ (by linarith)
    have hmδ := min_le_left δ (m - 2)
    have hm2 := min_le_right δ (m - 2)
    have h1 := hl (m - min δ (m - 2) / 2) ⟨by linarith, by linarith⟩
    have h2 := hge (m - min δ (m - 2) / 2) (show (2 : ℝ) ≤ m - min δ (m - 2) / 2 by linarith)
    linarith

/-- **Main-text concordance (line 102 vs A4).** The body states the hypothesis as "the hazard as
positive, differentiable and rising" and concludes that above the kink "the derivative is
`H′T_a > 0`". A strictly increasing, positive, differentiable hazard can have `H′ = 0` at a point
above the kink, where `dR_c/ds = 0`, not `> 0`. Here `H = 10 + (s − 2)³`, `K = T_a = 1`. -/
theorem p1_body_rising_not_enough (S : ℝ) :
    StrictMono (fun s : ℝ => 10 + (s - 2) ^ 3) ∧
    (∀ s ∈ Ici (1 / 2 : ℝ), 0 < 10 + (s - 2) ^ 3) ∧
    HasDerivAt (Rc (fun s : ℝ => 10 + (s - 2) ^ 3) 1 1 S) 0 2 := by
  refine ⟨fun a b hab => ?_, fun s hs => ?_, ?_⟩
  · have := (Odd.strictMono_pow (R := ℝ) (n := 3) ⟨1, rfl⟩) (sub_lt_sub_right hab 2)
    simp only at this ⊢; linarith
  · have : (1 / 2 : ℝ) ≤ s := hs
    have h := (Odd.strictMono_pow (R := ℝ) (n := 3) ⟨1, rfl⟩).monotone
      (show (-3 / 2 : ℝ) ≤ s - 2 by linarith)
    norm_num at h; linarith
  · have hd : HasDerivAt (fun s : ℝ => (10 + (s - 2) ^ 3) * 1 + S) 0 2 := by
      have := ((((hasDerivAt_id (2 : ℝ)).sub_const 2).fun_pow 3).const_add 10).mul_const 1
      convert this.add_const S using 1 <;> simp
    exact hd.congr_of_eventuallyEq (rc_eventually_adopt (K := 1) one_pos (by norm_num)
      (by norm_num)).symm

/-- **Main-text concordance (line 105), what survives "rising".** If `H` is only strictly
increasing on the adoption branch (no derivative condition), `R_c` is still strictly increasing
there, so the level claim "acceleration only raises it" holds; only the strict sign of the
derivative fails (`p1_body_rising_not_enough`). -/
theorem p1_body_rising_level {H : ℝ → ℝ} {K Ta S : ℝ} (hK : 0 < K) (hTa : 0 < Ta)
    (hH : StrictMonoOn H (Ici (K / Ta))) : StrictMonoOn (Rc H K Ta S) (Ici (K / Ta)) := by
  intro a ha b hb hab
  have hk : 0 < K / Ta := div_pos hK hTa
  have a0 : 0 < a := lt_of_lt_of_le hk ha
  have b0 : 0 < b := a0.trans hab
  simp only [Rc, max_adopt hTa a0 ha, max_adopt hTa b0 hb]
  have := hH ha hb hab
  nlinarith

/-- The oscillating perturbation of the P1 proof (line 1114), `d⁴(2 + sin(1/d))`. In Lean
`1/0 = 0`, so the formula already takes the value `0` at `d = 0`. -/
noncomputable def fOsc (d : ℝ) : ℝ := d ^ 4 * (2 + sin d⁻¹)

/-- Its derivative, `4d³(2 + sin(1/d)) − d² cos(1/d)` (equal to `0` at `d = 0`). -/
noncomputable def fOsc' (d : ℝ) : ℝ := 4 * d ^ 3 * (2 + sin d⁻¹) - d ^ 2 * cos d⁻¹

theorem hasDerivAt_fOsc (d : ℝ) : HasDerivAt fOsc (fOsc' d) d := by
  rcases eq_or_ne d 0 with h | h
  · subst h
    have hO : Asymptotics.IsBigO (𝓝 0) fOsc (fun x : ℝ => ‖x - 0‖ ^ 4) := by
      apply Asymptotics.IsBigO.of_bound 3
      refine Eventually.of_forall fun x => ?_
      simp only [fOsc, sub_zero, norm_mul, norm_pow, Real.norm_eq_abs]
      have h1 : |2 + sin x⁻¹| ≤ 3 := by
        rw [abs_le]; constructor <;> linarith [neg_one_le_sin x⁻¹, sin_le_one x⁻¹]
      rw [abs_abs]
      nlinarith [pow_nonneg (abs_nonneg x) 4]
    have := (hO.hasFDerivAt (by norm_num)).hasDerivAt
    simpa [fOsc'] using this
  · have hi : HasDerivAt (fun x : ℝ => x⁻¹) (-(d ^ 2)⁻¹) d := hasDerivAt_inv h
    have := ((hasDerivAt_id' d).fun_pow 4).fun_mul (hi.sin.const_add 2)
    unfold fOsc
    convert this using 1
    unfold fOsc'
    field_simp
    ring

/-- The loss index of the example: `R_c = c + S + (s − s₀)⁴(2 + sin(1/(s − s₀)))`. -/
noncomputable def ROsc (c S s0 : ℝ) (s : ℝ) : ℝ := c + S + fOsc (s - s0)

/-- The hazard that produces it on the capability branch, `H = s(R_c − S)/K`. -/
noncomputable def HOsc (c K s0 : ℝ) (s : ℝ) : ℝ := s * (c + fOsc (s - s0)) / K

noncomputable def HOsc' (c K s0 : ℝ) (s : ℝ) : ℝ :=
  ((c + fOsc (s - s0)) + s * fOsc' (s - s0)) / K

theorem fOsc_nonneg (d : ℝ) : 0 ≤ fOsc d := by
  unfold fOsc
  have := neg_one_le_sin d⁻¹
  have : 0 ≤ d ^ 4 := by positivity
  nlinarith

theorem fOsc_pos {d : ℝ} (hd : d ≠ 0) : 0 < fOsc d := by
  unfold fOsc
  have := neg_one_le_sin d⁻¹
  have : 0 < d ^ 4 := by positivity
  nlinarith

theorem fOsc'_lower {d : ℝ} (hd : |d| ≤ 1) : -(13 * |d|) ≤ fOsc' d := by
  unfold fOsc'
  have hs1 := neg_one_le_sin d⁻¹
  have hs2 := sin_le_one d⁻¹
  have hc1 := neg_one_le_cos d⁻¹
  have hc2 := cos_le_one d⁻¹
  rcases le_or_gt 0 d with h | h
  · rw [abs_of_nonneg h] at hd ⊢
    have : 0 ≤ 4 * d ^ 3 * (2 + sin d⁻¹) := by
      have : 0 ≤ d ^ 3 := by positivity
      nlinarith
    have : d ^ 2 * cos d⁻¹ ≤ d ^ 2 := by nlinarith [sq_nonneg d]
    nlinarith
  · rw [abs_of_neg h] at hd ⊢
    have h3 : d ≤ d ^ 3 := by
      have := mul_nonneg (mul_nonneg_of_nonpos_of_nonpos h.le (by linarith : d - 1 ≤ 0))
        (by linarith : 0 ≤ d + 1)
      nlinarith
    have : 12 * d ^ 3 ≤ 4 * d ^ 3 * (2 + sin d⁻¹) := by
      have : d ^ 3 < 0 := by
        have : 0 < d ^ 2 := by nlinarith [mul_pos_of_neg_of_neg h h]
        nlinarith
      nlinarith
    have : d ^ 2 * cos d⁻¹ ≤ d ^ 2 := by nlinarith [sq_nonneg d]
    nlinarith

/-- **P1 proof (line 1114): without isolated zeros the derivative can oscillate on both sides of a
strict minimum.** For `c > 0`: `s₀` is the strict global minimiser of
`R_c = c + S + (s − s₀)⁴(2 + sin(1/(s − s₀)))`; `R_c` is differentiable everywhere, with
derivative `0` at `s₀`; on each side of `s₀`, in every neighbourhood, the derivative takes both
signs; for `s₀, K > 0` the hazard `H = s(R_c − S)/K` is differentiable with `H > 0` and `H′ > 0`
near `s₀`; and on the capability branch `R_c` is exactly the model's loss index for that `H`. -/
theorem p1_oscillation_example (c S s0 K Ta : ℝ) (hc : 0 < c) (hs0 : 0 < s0) (hK : 0 < K)
    (hTa : 0 < Ta) :
    (∀ s, s ≠ s0 → ROsc c S s0 s0 < ROsc c S s0 s) ∧
    (∀ s, HasDerivAt (ROsc c S s0) (fOsc' (s - s0)) s) ∧ fOsc' (s0 - s0) = 0 ∧
    (∀ ε > 0, (∃ s ∈ Ioo s0 (s0 + ε), fOsc' (s - s0) < 0) ∧
      (∃ s ∈ Ioo s0 (s0 + ε), 0 < fOsc' (s - s0)) ∧
      (∃ s ∈ Ioo (s0 - ε) s0, fOsc' (s - s0) < 0) ∧
      (∃ s ∈ Ioo (s0 - ε) s0, 0 < fOsc' (s - s0))) ∧
    (∀ s, HasDerivAt (HOsc c K s0) (HOsc' c K s0 s) s) ∧
    (∀ᶠ s in 𝓝 s0, 0 < HOsc c K s0 s ∧ 0 < HOsc' c K s0 s) ∧
    (∀ s, 0 < s → s ≤ K / Ta → Rc (HOsc c K s0) K Ta S s = ROsc c S s0 s) := by
  refine ⟨fun s hs => ?_, fun s => ?_, by simp [fOsc'], fun ε hε => ?_, fun s => ?_, ?_,
    fun s hs hk => ?_⟩
  · simp only [ROsc, sub_self, fOsc, ne_eq, OfNat.ofNat_ne_zero, not_false_eq_true, zero_pow,
      zero_mul, add_zero]
    have := fOsc_pos (sub_ne_zero.mpr hs)
    unfold fOsc at this; linarith
  · have h1 : HasDerivAt (fun x => fOsc (x - s0)) (fOsc' (s - s0)) s := by
      have := (hasDerivAt_fOsc (s - s0)).comp s ((hasDerivAt_id' s).sub_const s0)
      rw [mul_one] at this; exact this
    unfold ROsc
    exact h1.const_add (c + S)
  · -- the oscillation, at `d = ±1/(2πn)` and `d = ±1/(2πn + π)`
    obtain ⟨n, hn⟩ := exists_nat_gt (1 / (2 * π * min ε (1 / 8)))
    have hm : 0 < min ε (1 / 8) := lt_min hε (by norm_num)
    have hpi := pi_pos
    have hn0 : (0 : ℝ) < n := lt_trans (by positivity) hn
    set a : ℝ := n * (2 * π) with ha
    have ha0 : 0 < a := by positivity
    have hsa : sin a = 0 := by
      rw [ha, show (n : ℝ) * (2 * π) = ((2 * n : ℕ) : ℝ) * π by push_cast; ring]
      exact sin_nat_mul_pi _
    have hca : cos a = 1 := cos_nat_mul_two_pi n
    have hsb : sin (a + π) = 0 := by rw [sin_add_pi, hsa, neg_zero]
    have hcb : cos (a + π) = -1 := by rw [cos_add_pi, hca]
    have hd1 : a⁻¹ < min ε (1 / 8) := by
      rw [inv_eq_one_div, div_lt_iff₀ ha0]
      rw [div_lt_iff₀ (by positivity)] at hn
      have : min ε (1 / 8) * a = n * (2 * π * min ε (1 / 8)) := by rw [ha]; ring
      linarith
    have hd2 : (a + π)⁻¹ < a⁻¹ := inv_strictAnti₀ ha0 (by linarith)
    have hd2' : 0 < (a + π)⁻¹ := by positivity
    have ha' : 0 < a⁻¹ := by positivity
    have hε1 : a⁻¹ < ε := lt_of_lt_of_le hd1 (min_le_left _ _)
    have h81 : a⁻¹ < 1 / 8 := lt_of_lt_of_le hd1 (min_le_right _ _)
    refine ⟨⟨s0 + a⁻¹, ⟨by linarith, by linarith⟩, ?_⟩, ⟨s0 + (a + π)⁻¹, ⟨by linarith, by linarith⟩, ?_⟩,
      ⟨s0 - a⁻¹, ⟨by linarith, by linarith⟩, ?_⟩, ⟨s0 - (a + π)⁻¹, ⟨by linarith, by linarith⟩, ?_⟩⟩
    · simp only [add_sub_cancel_left, fOsc', inv_inv, hsa, hca]
      nlinarith [pow_pos ha' 2, pow_pos ha' 3]
    · simp only [add_sub_cancel_left, fOsc', inv_inv, hsb, hcb]
      nlinarith [pow_pos hd2' 2, pow_pos hd2' 3]
    · simp only [sub_sub_cancel_left, fOsc', inv_neg, inv_inv, sin_neg, cos_neg, hsa, hca]
      nlinarith [pow_pos ha' 2, pow_pos ha' 3]
    · simp only [sub_sub_cancel_left, fOsc', inv_neg, inv_inv, sin_neg, cos_neg, hsb, hcb]
      nlinarith [pow_pos hd2' 2, pow_pos hd2' 3]
  · have hf : HasDerivAt (fun x => fOsc (x - s0)) (fOsc' (s - s0)) s := by
      have := (hasDerivAt_fOsc (s - s0)).comp s ((hasDerivAt_id' s).sub_const s0)
      rw [mul_one] at this; exact this
    have := (((hasDerivAt_id' s).fun_mul (hf.const_add c)).div_const K)
    unfold HOsc HOsc'
    convert this using 1
    ring
  · set δ := min 1 (min (s0 / 2) (c / (26 * (s0 + 1)))) with hδ
    have hδ0 : 0 < δ := lt_min one_pos (lt_min (by linarith) (by positivity))
    rw [Metric.eventually_nhds_iff]
    refine ⟨δ, hδ0, fun s hs => ?_⟩
    rw [Real.dist_eq] at hs
    have h1 : |s - s0| < 1 := lt_of_lt_of_le hs (min_le_left _ _)
    have h2 : |s - s0| < s0 / 2 := lt_of_lt_of_le hs ((min_le_right _ _).trans (min_le_left _ _))
    have h3 : |s - s0| < c / (26 * (s0 + 1)) :=
      lt_of_lt_of_le hs ((min_le_right _ _).trans (min_le_right _ _))
    have hsp : 0 < s := by have := (abs_lt.mp h2).1; linarith
    have hsu : s < s0 + 1 := by have := (abs_lt.mp h1).2; linarith
    have hf0 := fOsc_nonneg (s - s0)
    have hf' := fOsc'_lower h1.le
    have h3' : 26 * (s0 + 1) * |s - s0| < c := by
      rw [lt_div_iff₀ (by positivity)] at h3; linarith
    have habs := abs_nonneg (s - s0)
    refine ⟨by unfold HOsc; positivity, ?_⟩
    unfold HOsc'
    apply div_pos _ hK
    have : s * (-(13 * |s - s0|)) ≤ s * fOsc' (s - s0) := mul_le_mul_of_nonneg_left hf' hsp.le
    nlinarith
  · rw [Rc, max_cap hTa hs hk, HOsc, ROsc]; field_simp; ring

/-- **P1 proof (line 1114), the oscillation example inside the model.** With `s₀` strictly on
the capability branch (`s₀ < K/T_a`), on a neighbourhood of `s₀` inside `(0, K/T_a)` the model's
own loss index `R_c` for the hazard `H = s(R_c − S)/K` has derivative `fOsc'(s − s₀)`, a strict
minimum at `s₀`, and `H > 0`, `H′ > 0`; and on each side of `s₀`, in every neighbourhood,
`deriv R_c` takes both signs. -/
theorem p1_oscillation_model (c S s0 K Ta : ℝ) (hc : 0 < c) (hs0 : 0 < s0) (hK : 0 < K)
    (hTa : 0 < Ta) (hs0K : s0 < K / Ta) :
    ∃ δ > 0, Ioo (s0 - δ) (s0 + δ) ⊆ Ioo 0 (K / Ta) ∧
      (∀ s ∈ Ioo (s0 - δ) (s0 + δ),
        HasDerivAt (Rc (HOsc c K s0) K Ta S) (fOsc' (s - s0)) s ∧
        0 < HOsc c K s0 s ∧ 0 < HOsc' c K s0 s ∧
        (s ≠ s0 → Rc (HOsc c K s0) K Ta S s0 < Rc (HOsc c K s0) K Ta S s)) ∧
      ∀ ε > 0, (∃ s ∈ Ioo s0 (s0 + ε), deriv (Rc (HOsc c K s0) K Ta S) s < 0) ∧
        (∃ s ∈ Ioo s0 (s0 + ε), 0 < deriv (Rc (HOsc c K s0) K Ta S) s) ∧
        (∃ s ∈ Ioo (s0 - ε) s0, deriv (Rc (HOsc c K s0) K Ta S) s < 0) ∧
        (∃ s ∈ Ioo (s0 - ε) s0, 0 < deriv (Rc (HOsc c K s0) K Ta S) s) := by
  obtain ⟨hmin, hd, -, hosc, -, hpos, heq⟩ :=
    p1_oscillation_example c S s0 K Ta hc hs0 hK hTa
  obtain ⟨e, he, hball⟩ := Metric.eventually_nhds_iff.mp hpos
  have hδ0 : 0 < min e (min s0 (K / Ta - s0)) := lt_min he (lt_min hs0 (by linarith))
  have hδe : min e (min s0 (K / Ta - s0)) ≤ e := min_le_left _ _
  have hδs : min e (min s0 (K / Ta - s0)) ≤ s0 := (min_le_right _ _).trans (min_le_left _ _)
  have hδk : min e (min s0 (K / Ta - s0)) ≤ K / Ta - s0 :=
    (min_le_right _ _).trans (min_le_right _ _)
  set δ := min e (min s0 (K / Ta - s0)) with hδ
  have hsub : Ioo (s0 - δ) (s0 + δ) ⊆ Ioo 0 (K / Ta) := fun s hs =>
    ⟨by linarith [hs.1], by linarith [hs.2]⟩
  have hD : ∀ s ∈ Ioo (s0 - δ) (s0 + δ),
      HasDerivAt (Rc (HOsc c K s0) K Ta S) (fOsc' (s - s0)) s := by
    intro s hs
    have hev : ROsc c S s0 =ᶠ[𝓝 s] Rc (HOsc c K s0) K Ta S := by
      filter_upwards [isOpen_Ioo.mem_nhds (hsub hs)] with x hx
      exact (heq x hx.1 hx.2.le).symm
    exact (hd s).congr_of_eventuallyEq hev.symm
  have hdist : ∀ s ∈ Ioo (s0 - δ) (s0 + δ), dist s s0 < e := fun s hs => by
    rw [Real.dist_eq, abs_lt]; constructor <;> linarith [hs.1, hs.2]
  refine ⟨δ, hδ0, hsub, fun s hs => ⟨hD s hs, (hball (hdist s hs)).1, (hball (hdist s hs)).2,
    fun hne => ?_⟩, fun ε hε => ?_⟩
  · have hs' := hsub hs
    rw [heq s hs'.1 hs'.2.le, heq s0 hs0 hs0K.le]
    exact hmin s hne
  · obtain ⟨⟨a1, ha1, h1⟩, ⟨a2, ha2, h2⟩, ⟨a3, ha3, h3⟩, ⟨a4, ha4, h4⟩⟩ :=
      hosc (min ε δ) (lt_min hε hδ0)
    have hme : min ε δ ≤ ε := min_le_left _ _
    have hmd : min ε δ ≤ δ := min_le_right _ _
    have hr : ∀ a ∈ Ioo s0 (s0 + min ε δ), a ∈ Ioo (s0 - δ) (s0 + δ) := fun a ha =>
      ⟨by linarith [ha.1], by linarith [ha.2]⟩
    have hl : ∀ a ∈ Ioo (s0 - min ε δ) s0, a ∈ Ioo (s0 - δ) (s0 + δ) := fun a ha =>
      ⟨by linarith [ha.1], by linarith [ha.2]⟩
    refine ⟨⟨a1, ⟨ha1.1, by linarith [ha1.2]⟩, ?_⟩, ⟨a2, ⟨ha2.1, by linarith [ha2.2]⟩, ?_⟩,
      ⟨a3, ⟨by linarith [ha3.1], ha3.2⟩, ?_⟩, ⟨a4, ⟨by linarith [ha4.1], ha4.2⟩, ?_⟩⟩
    · rw [(hD a1 (hr a1 ha1)).deriv]; exact h1
    · rw [(hD a2 (hr a2 ha2)).deriv]; exact h2
    · rw [(hD a3 (hl a3 ha3)).deriv]; exact h3
    · rw [(hD a4 (hl a4 ha4)).deriv]; exact h4

/-! ## P2 -/

/-- The step term as a finite sum over steps: `S = Σ_k N_k ψ_k d_k` (line 897). -/
def stepTerm (I : Finset ℕ) (N ψ d : ℕ → ℝ) : ℝ := ∑ k ∈ I, N k * ψ k * d k

/-- **P2 corrected, first clause.** If the set of steps and every per-step factor are independent
of `s`, so is `S`. Content: algebraic (congruence); it is the paper's "identity". -/
theorem p2_indep_of_speed (I : ℝ → Finset ℕ) (N ψ d : ℝ → ℕ → ℝ)
    (hI : ∀ s s', I s = I s') (hN : ∀ s s' k, N s k = N s' k) (hψ : ∀ s s' k, ψ s k = ψ s' k)
    (hd : ∀ s s' k, d s k = d s' k) (s s' : ℝ) :
    stepTerm (I s) (N s) (ψ s) (d s) = stepTerm (I s') (N s') (ψ s') (d s') := by
  unfold stepTerm
  rw [hI s s']
  exact Finset.sum_congr rfl fun k _ => by rw [hN s s' k, hψ s s' k, hd s s' k]

/-- **P2 corrected, second clause, in `N`.** -/
theorem p2_falls_with_N (I : Finset ℕ) (N N' ψ d : ℕ → ℝ) (hle : ∀ k ∈ I, N' k ≤ N k)
    (hlt : ∃ j ∈ I, N' j < N j) (hpos : ∀ k ∈ I, 0 < ψ k ∧ 0 < d k) :
    stepTerm I N' ψ d < stepTerm I N ψ d := by
  apply Finset.sum_lt_sum
  · intro k hk
    have := hpos k hk
    have : 0 < ψ k * d k := mul_pos this.1 this.2
    nlinarith [hle k hk]
  · obtain ⟨j, hj, h⟩ := hlt
    refine ⟨j, hj, ?_⟩
    have := hpos j hj
    have : 0 < ψ j * d j := mul_pos this.1 this.2
    nlinarith

/-- **P2 corrected, second clause, in `ψ`.** -/
theorem p2_falls_with_psi (I : Finset ℕ) (N ψ ψ' d : ℕ → ℝ) (hle : ∀ k ∈ I, ψ' k ≤ ψ k)
    (hlt : ∃ j ∈ I, ψ' j < ψ j) (hpos : ∀ k ∈ I, 0 < N k ∧ 0 < d k) :
    stepTerm I N ψ' d < stepTerm I N ψ d := by
  apply Finset.sum_lt_sum
  · intro k hk
    have := hpos k hk
    have : 0 < N k * d k := mul_pos this.1 this.2
    nlinarith [hle k hk]
  · obtain ⟨j, hj, h⟩ := hlt
    refine ⟨j, hj, ?_⟩
    have := hpos j hj
    have : 0 < N j * d j := mul_pos this.1 this.2
    nlinarith

/-- **P2 corrected, second clause, in `d`.** -/
theorem p2_falls_with_d (I : Finset ℕ) (N ψ d d' : ℕ → ℝ) (hle : ∀ k ∈ I, d' k ≤ d k)
    (hlt : ∃ j ∈ I, d' j < d j) (hpos : ∀ k ∈ I, 0 < N k ∧ 0 < ψ k) :
    stepTerm I N ψ d' < stepTerm I N ψ d := by
  apply Finset.sum_lt_sum
  · intro k hk
    have := hpos k hk
    have : 0 < N k * ψ k := mul_pos this.1 this.2
    nlinarith [hle k hk]
  · obtain ⟨j, hj, h⟩ := hlt
    refine ⟨j, hj, ?_⟩
    have := hpos j hj
    have : 0 < N j * ψ j := mul_pos this.1 this.2
    nlinarith

/-- **P2, halving `d` with `N`, `ψ` fixed halves `S`.** -/
theorem p2_halve_d (I : Finset ℕ) (N ψ d : ℕ → ℝ) :
    stepTerm I N ψ (fun k => d k / 2) = stepTerm I N ψ d / 2 := by
  unfold stepTerm; rw [Finset.sum_div]
  exact Finset.sum_congr rfl fun k _ => by ring

/-- **P2, halving `ψ` with `N`, `d` fixed halves `S`.** -/
theorem p2_halve_psi (I : Finset ℕ) (N ψ d : ℕ → ℝ) :
    stepTerm I N (fun k => ψ k / 2) d = stepTerm I N ψ d / 2 := by
  unfold stepTerm; rw [Finset.sum_div]
  exact Finset.sum_congr rfl fun k _ => by ring

/-- **P2 as first stated, second sentence, is false.** "Only fewer exploitable flaws" reduce `S`
would mean: every reduction of `S` lowers some `N_k`. A one-step instance with `N`, `ψ` fixed and
`d` halved refutes it. -/
theorem p2_first_stated_false :
    ¬ (∀ (I : Finset ℕ) (N ψ d N' ψ' d' : ℕ → ℝ),
        stepTerm I N' ψ' d' < stepTerm I N ψ d → ∃ k ∈ I, N' k < N k) := by
  intro h
  obtain ⟨k, hk, hlt⟩ := h {0} (fun _ => 1) (fun _ => 1) (fun _ => 1) (fun _ => 1) (fun _ => 1)
    (fun _ => 1 / 2) (by simp [stepTerm]; norm_num)
  simp at hlt

/-- **P2, "S depends on speed after all" (line 897).** If a step at capability `c_k > 0` arrives at
date `c_k/s` and exploit success there is `p(c_k/s)` with `p` strictly increasing in the date
(attackers' tools improve on calendar time), then `S` is strictly decreasing in `s`; in
particular it is not independent of `s`. -/
theorem p2_tools_speed_dependence (I : Finset ℕ) (hI : I.Nonempty) (N d c : ℕ → ℝ)
    (p : ℝ → ℝ) (hp : StrictMono p) (hNd : ∀ k ∈ I, 0 < N k ∧ 0 < d k) (hc : ∀ k ∈ I, 0 < c k)
    {s s' : ℝ} (hs : 0 < s) (hss : s < s') :
    stepTerm I N (fun k => p (c k / s')) d < stepTerm I N (fun k => p (c k / s)) d := by
  apply p2_falls_with_psi I N _ _ d
  · intro k hk
    exact (hp (div_lt_div_of_pos_left (hc k hk) hs hss)).le
  · obtain ⟨j, hj⟩ := hI
    exact ⟨j, hj, hp (div_lt_div_of_pos_left (hc j hj) hs hss)⟩
  · exact hNd

/-! ## P5 -/

/-- Adoption time responding to speed: `T_a(s) = A (s/s₀)^{−β}`. -/
noncomputable def TaP (A s0 β s : ℝ) : ℝ := A * (s / s0) ^ (-β)

/-- The kink of P5(i): `s* = s₀ (K/(A s₀))^{1/(1−β)}`. -/
noncomputable def kinkP (K A s0 β : ℝ) : ℝ := s0 * (K / (A * s0)) ^ (1 / (1 - β))

/-- The loss index with a speed-dependent adoption time. -/
noncomputable def RcT (H : ℝ → ℝ) (K : ℝ) (Ta : ℝ → ℝ) (S : ℝ) (s : ℝ) : ℝ :=
  H s * max (K / s) (Ta s) + S

section P5
variable {K A s0 β : ℝ}

theorem TaP_pos (hA : 0 < A) (hs0 : 0 < s0) {s : ℝ} (hs : 0 < s) : 0 < TaP A s0 β s :=
  mul_pos hA (rpow_pos_of_pos (div_pos hs hs0) _)

theorem log_TaP (hA : 0 < A) (hs0 : 0 < s0) {s : ℝ} (hs : 0 < s) :
    log (TaP A s0 β s) = log A - β * (log s - log s0) := by
  unfold TaP
  rw [log_mul hA.ne' (rpow_pos_of_pos (div_pos hs hs0) _).ne', log_rpow (div_pos hs hs0),
    log_div hs.ne' hs0.ne']; ring

theorem log_ratio (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) :
    log (K / (A * s0)) = log K - log A - log s0 := by
  rw [log_div hK.ne' (mul_pos hA hs0).ne', log_mul hA.ne' hs0.ne']; ring

/-- Adoption binds strictly (`K/s < T_a`) iff `ℓ < (1 − β)(ln s − ln s₀)`, `ℓ = ln(K/(As₀))`. -/
theorem p5_adopt_iff (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) {s : ℝ} (hs : 0 < s) :
    K / s < TaP A s0 β s ↔ log (K / (A * s0)) < (1 - β) * (log s - log s0) := by
  rw [← log_lt_log_iff (div_pos hK hs) (TaP_pos hA hs0 hs), log_TaP hA hs0 hs,
    log_div hK.ne' hs.ne', log_ratio hK hA hs0]
  constructor <;> intro h <;> linarith

/-- Capability binds strictly (`T_a < K/s`) iff `(1 − β)(ln s − ln s₀) < ℓ`. -/
theorem p5_cap_iff (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) {s : ℝ} (hs : 0 < s) :
    TaP A s0 β s < K / s ↔ (1 - β) * (log s - log s0) < log (K / (A * s0)) := by
  rw [← log_lt_log_iff (TaP_pos hA hs0 hs) (div_pos hK hs), log_TaP hA hs0 hs,
    log_div hK.ne' hs.ne', log_ratio hK hA hs0]
  constructor <;> intro h <;> linarith

theorem kinkP_pos (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) : 0 < kinkP K A s0 β :=
  mul_pos hs0 (rpow_pos_of_pos (div_pos hK (mul_pos hA hs0)) _)

theorem log_kinkP (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) :
    log (kinkP K A s0 β) = log s0 + log (K / (A * s0)) / (1 - β) := by
  unfold kinkP
  rw [log_mul hs0.ne' (rpow_pos_of_pos (div_pos hK (mul_pos hA hs0)) _).ne',
    log_rpow (div_pos hK (mul_pos hA hs0))]; ring

/-- **P5(i), the kink.** For `β ≠ 1`, `s*` solves `K/s = T_a(s)`, and it is the only positive
solution. -/
theorem p5_kink (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) (hβ : β ≠ 1) :
    K / kinkP K A s0 β = TaP A s0 β (kinkP K A s0 β) ∧
      ∀ s > 0, K / s = TaP A s0 β s → s = kinkP K A s0 β := by
  have h1 : (1 - β) ≠ 0 := sub_ne_zero.mpr (Ne.symm hβ)
  have hk := kinkP_pos (β := β) hK hA hs0
  set ℓ := log (K / (A * s0))
  constructor
  · have hl := log_kinkP (β := β) hK hA hs0
    have he : (1 - β) * (log (kinkP K A s0 β) - log s0) = ℓ := by rw [hl]; field_simp; ring
    rcases lt_trichotomy (K / kinkP K A s0 β) (TaP A s0 β (kinkP K A s0 β)) with h | h | h
    · have := (p5_adopt_iff hK hA hs0 hk).mp h; linarith
    · exact h
    · have := (p5_cap_iff hK hA hs0 hk).mp h; linarith
  · intro s hs heq
    have e1 : ¬ (K / s < TaP A s0 β s) := by rw [heq]; exact lt_irrefl _
    have e2 : ¬ (TaP A s0 β s < K / s) := by rw [heq]; exact lt_irrefl _
    rw [p5_adopt_iff hK hA hs0 hs] at e1
    rw [p5_cap_iff hK hA hs0 hs] at e2
    have he : (1 - β) * (log s - log s0) = ℓ := le_antisymm (not_lt.mp e1) (not_lt.mp e2)
    have hl : log s = log (kinkP K A s0 β) := by
      rw [log_kinkP hK hA hs0]; field_simp; linarith
    exact log_injOn_pos (mem_Ioi.mpr hs) (mem_Ioi.mpr hk) hl

/-- **P5(i), `β < 1`.** Capability binds below `s*`, adoption above it. -/
theorem p5_order_lt_one (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) (hβ : β < 1) {s : ℝ}
    (hs : 0 < s) :
    (s < kinkP K A s0 β → TaP A s0 β s < K / s) ∧ (kinkP K A s0 β < s → K / s < TaP A s0 β s) := by
  have h1 : 0 < 1 - β := by linarith
  have hk := kinkP_pos (β := β) hK hA hs0
  have hl := log_kinkP (β := β) hK hA hs0
  constructor
  · intro h
    rw [p5_cap_iff hK hA hs0 hs]
    have := log_lt_log hs h
    rw [hl] at this
    have : log s - log s0 < log (K / (A * s0)) / (1 - β) := by linarith
    rw [lt_div_iff₀ h1] at this; linarith
  · intro h
    rw [p5_adopt_iff hK hA hs0 hs]
    have := log_lt_log hk h
    rw [hl] at this
    have : log (K / (A * s0)) / (1 - β) < log s - log s0 := by linarith
    rw [div_lt_iff₀ h1] at this; linarith

/-- **P5(i), `β > 1`.** The order reverses: adoption binds below `s*`, capability above. -/
theorem p5_order_gt_one (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) (hβ : 1 < β) {s : ℝ}
    (hs : 0 < s) :
    (s < kinkP K A s0 β → K / s < TaP A s0 β s) ∧ (kinkP K A s0 β < s → TaP A s0 β s < K / s) := by
  have h1 : 1 - β < 0 := by linarith
  have hk := kinkP_pos (β := β) hK hA hs0
  have hl := log_kinkP (β := β) hK hA hs0
  constructor
  · intro h
    rw [p5_adopt_iff hK hA hs0 hs]
    have := log_lt_log hs h
    rw [hl] at this
    have : log s - log s0 < log (K / (A * s0)) / (1 - β) := by linarith
    rw [lt_div_iff_of_neg h1] at this; linarith
  · intro h
    rw [p5_cap_iff hK hA hs0 hs]
    have := log_lt_log hk h
    rw [hl] at this
    have : log (K / (A * s0)) / (1 - β) < log s - log s0 := by linarith
    rw [div_lt_iff_of_neg h1] at this; linarith

/-- **P5(i), `β = 1`.** The branches never cross unless `K = As₀` (then they coincide at every
speed); otherwise one binds everywhere. -/
theorem p5_beta_one (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) :
    (∀ s > 0, K / s = TaP A s0 1 s ↔ K = A * s0) ∧
    (A * s0 < K → ∀ s > 0, TaP A s0 1 s < K / s) ∧
    (K < A * s0 → ∀ s > 0, K / s < TaP A s0 1 s) := by
  have hT : ∀ s > 0, TaP A s0 1 s = A * s0 / s := by
    intro s hs; unfold TaP; rw [rpow_neg_one]; field_simp
  refine ⟨fun s hs => ?_, fun h s hs => ?_, fun h s hs => ?_⟩
  · rw [hT s hs]; constructor
    · intro h; field_simp at h; linarith
    · intro h; rw [h]
  · rw [hT s hs]; exact div_lt_div_of_pos_right h hs
  · rw [hT s hs]; exact div_lt_div_of_pos_right h hs

/-- The kink as a function of `β`, in exponential form. -/
theorem kinkP_exp (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) (b : ℝ) :
    kinkP K A s0 b = s0 * exp (log (K / (A * s0)) * (1 / (1 - b))) := by
  unfold kinkP; rw [rpow_def_of_pos (div_pos hK (mul_pos hA hs0))]

/-- **P5(ii), the derivative in `β`.** `d s*/dβ = s* · ℓ/(1 − β)²`. -/
theorem p5_kink_deriv (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) (hβ : β ≠ 1) :
    HasDerivAt (fun b => kinkP K A s0 b)
      (kinkP K A s0 β * (log (K / (A * s0)) / (1 - β) ^ 2)) β := by
  have h1 : (1 - β) ≠ 0 := sub_ne_zero.mpr (Ne.symm hβ)
  set ℓ := log (K / (A * s0))
  have hinv : HasDerivAt (fun b : ℝ => 1 / (1 - b)) (1 / (1 - β) ^ 2) β := by
    have := ((hasDerivAt_id β).const_sub 1).inv h1
    convert this using 1
    · ext b; simp
    · simp
  have h := ((hinv.const_mul ℓ).exp).const_mul s0
  have hfun : (fun b => kinkP K A s0 b) = fun b => s0 * exp (ℓ * (1 / (1 - b))) := by
    ext b; exact kinkP_exp hK hA hs0 b
  rw [hfun]
  convert h using 1
  rw [kinkP_exp hK hA hs0 β]; ring

theorem log_ratio_pos_iff (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) :
    0 < log (K / (A * s0)) ↔ A * s0 < K := by
  have hc : 0 < K / (A * s0) := div_pos hK (mul_pos hA hs0)
  constructor
  · intro h
    by_contra h'
    have : K / (A * s0) ≤ 1 := by rw [div_le_one (mul_pos hA hs0)]; exact not_lt.mp h'
    have := log_nonpos hc.le this; linarith
  · intro h; exact log_pos (by rw [one_lt_div (mul_pos hA hs0)]; exact h)

theorem log_ratio_neg_iff (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) :
    log (K / (A * s0)) < 0 ↔ K < A * s0 := by
  have hc : 0 < K / (A * s0) := div_pos hK (mul_pos hA hs0)
  rw [log_neg_iff hc, div_lt_one (mul_pos hA hs0)]

/-- **P5(ii), the sign of the derivative.** For `β < 1`, `d s*/dβ > 0` iff `K > As₀`. -/
theorem p5_kink_deriv_pos_iff (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) (hβ : β < 1) :
    0 < kinkP K A s0 β * (log (K / (A * s0)) / (1 - β) ^ 2) ↔ A * s0 < K := by
  have hk := kinkP_pos (β := β) hK hA hs0
  have h2 : 0 < (1 - β) ^ 2 := pow_pos (by linarith) 2
  rw [← log_ratio_pos_iff hK hA hs0]
  constructor
  · intro h
    by_contra h'
    have : log (K / (A * s0)) / (1 - β) ^ 2 ≤ 0 :=
      div_nonpos_of_nonpos_of_nonneg (not_lt.mp h') h2.le
    have := mul_nonpos_of_nonneg_of_nonpos hk.le this; linarith
  · intro h; exact mul_pos hk (div_pos h h2)

theorem one_div_one_sub_strictMonoOn : StrictMonoOn (fun b : ℝ => 1 / (1 - b)) (Iio 1) := by
  intro a ha b hb hab
  have hb' : 0 < 1 - b := by have : b < 1 := hb; linarith
  exact one_div_lt_one_div_of_lt hb' (by linarith)

/-- **P5(ii), globally.** If `K > As₀` the kink rises with `β` on `β < 1`. -/
theorem p5_kink_strictMono (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) (h : A * s0 < K) :
    StrictMonoOn (kinkP K A s0) (Iio 1) := by
  have hl := (log_ratio_pos_iff hK hA hs0).mpr h
  intro a ha b hb hab
  rw [kinkP_exp hK hA hs0, kinkP_exp hK hA hs0]
  have h1 := one_div_one_sub_strictMonoOn ha hb hab
  simp only at h1
  have h2 := exp_lt_exp.mpr (mul_lt_mul_of_pos_left h1 hl)
  exact mul_lt_mul_of_pos_left h2 hs0

/-- **P5 as first stated, A14 reading (line 923).** If `K < As₀`, the kink falls with `β` for
every `β < 1`. -/
theorem p5_kink_strictAnti (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) (h : K < A * s0) :
    StrictAntiOn (kinkP K A s0) (Iio 1) := by
  have hl := (log_ratio_neg_iff hK hA hs0).mpr h
  intro a ha b hb hab
  rw [kinkP_exp hK hA hs0, kinkP_exp hK hA hs0]
  have h1 := one_div_one_sub_strictMonoOn ha hb hab
  simp only at h1
  have h2 := exp_lt_exp.mpr (mul_lt_mul_of_neg_left h1 hl)
  exact mul_lt_mul_of_pos_left h2 hs0

/-- **P5(ii), the iff, globally.** On `β < 1`, `s*` is strictly increasing in `β` iff `K > As₀`. -/
theorem p5_kink_rises_iff (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) :
    StrictMonoOn (kinkP K A s0) (Iio 1) ↔ A * s0 < K := by
  refine ⟨fun hm => ?_, p5_kink_strictMono hK hA hs0⟩
  have h := hm (show (0 : ℝ) ∈ Iio 1 by norm_num) (show (1 / 2 : ℝ) ∈ Iio 1 by norm_num)
    (by norm_num)
  rw [kinkP_exp hK hA hs0, kinkP_exp hK hA hs0] at h
  have h' := (mul_lt_mul_iff_of_pos_left hs0).mp h
  rw [exp_lt_exp] at h'
  norm_num at h'
  rw [← log_ratio_pos_iff hK hA hs0]; linarith

/-- **P5 as first stated is false (line 923).** `K = 1`, `A = 2`, `s₀ = 1`: raising `β` from 0 to
`1/2` moves `s*` from `1/2` down to `1/4`. -/
theorem p5_counterexample : kinkP 1 2 1 0 = 1 / 2 ∧ kinkP 1 2 1 (1 / 2) = 1 / 4 := by
  constructor
  · unfold kinkP; norm_num
  · unfold kinkP
    rw [show (1 : ℝ) / (1 - 1 / 2) = 2 by norm_num, rpow_two]; norm_num

/-- **A14 reading (line 923).** With `A` measured at the reference speed, adoption binds there
(strictly) iff `K < As₀`. -/
theorem p5_a14_reading (hA : 0 < A) (hs0 : 0 < s0) :
    K / s0 < TaP A s0 β s0 ↔ K < A * s0 := by
  unfold TaP; rw [div_self hs0.ne', one_rpow, mul_one, div_lt_iff₀ hs0]

/-- **P5(ii), "that is, iff capability binds at the reference speed".** Capability binds
(strictly) at `s₀` iff `K > As₀`; hence on `β < 1`, `s*` rises with `β` iff capability binds at
`s₀`. -/
theorem p5_cap_at_ref_iff (hK : 0 < K) (hA : 0 < A) (hs0 : 0 < s0) :
    (TaP A s0 β s0 < K / s0 ↔ A * s0 < K) ∧
      (StrictMonoOn (kinkP K A s0) (Iio 1) ↔ TaP A s0 β s0 < K / s0) := by
  have h : TaP A s0 β s0 < K / s0 ↔ A * s0 < K := by
    unfold TaP; rw [div_self hs0.ne', one_rpow, mul_one, lt_div_iff₀ hs0]
  exact ⟨h, (p5_kink_rises_iff hK hA hs0).trans h.symm⟩

/-- **P5 as first stated is false on `β < 1` (line 923).** In the example `K = 1`, `A = 2`,
`s₀ = 1`, `s*` does not rise with `β` on `[0, 1)`, and there is no "fast enough" threshold
`β₀ < 1` beyond which it even weakly rises. -/
theorem p5_first_stated_false :
    (¬ ∀ β β' : ℝ, 0 ≤ β → β < β' → β' < 1 → kinkP 1 2 1 β < kinkP 1 2 1 β') ∧
    (¬ ∃ β₀ < 1, ∀ β β' : ℝ, β₀ ≤ β → β < β' → β' < 1 → kinkP 1 2 1 β ≤ kinkP 1 2 1 β') := by
  have hanti := p5_kink_strictAnti (K := 1) (A := 2) (s0 := 1) one_pos two_pos one_pos
    (by norm_num)
  refine ⟨fun h => ?_, fun ⟨β₀, hβ₀, h⟩ => ?_⟩
  · have := h 0 (1 / 2) le_rfl (by norm_num) (by norm_num)
    rw [p5_counterexample.1, p5_counterexample.2] at this; norm_num at this
  · have hb : β₀ < (β₀ + 1) / 2 := by linarith
    have hb1 : (β₀ + 1) / 2 < 1 := by linarith
    have h1 := h β₀ ((β₀ + 1) / 2) le_rfl hb hb1
    have h2 := hanti (show β₀ ∈ Iio 1 from hβ₀) (show (β₀ + 1) / 2 ∈ Iio 1 from hb1) hb
    linarith

/-- **P5 as first stated, the `β > 1` side.** In the same example the kink exceeds one, and so
lies above its `β = 0` value `1/2`, for every `β > 1` (at `β = 2`, `s* = 2`). So the example
refutes "`s*` rises" only on `β < 1`, where `s*` keeps its P1 meaning; for `β > 1` the branch
order is reversed. -/
theorem p5_first_stated_beta_gt_one :
    kinkP 1 2 1 2 = 2 ∧ ∀ β > 1, 1 < kinkP 1 2 1 β ∧ kinkP 1 2 1 0 < kinkP 1 2 1 β := by
  constructor
  · unfold kinkP
    rw [show (1 : ℝ) / (1 - 2) = -1 by norm_num, rpow_neg_one]; norm_num
  · intro β hβ
    rw [p5_counterexample.1]
    unfold kinkP
    have he : 1 / (1 - β) < 0 := div_neg_of_pos_of_neg one_pos (by linarith)
    have := one_lt_rpow_of_pos_of_lt_one_of_neg (x := (1 : ℝ) / (2 * 1)) (by norm_num)
      (by norm_num) he
    constructor <;> linarith

theorem hasDerivAt_TaP (hA : 0 < A) (hs0 : 0 < s0) {s : ℝ} (hs : 0 < s) :
    HasDerivAt (TaP A s0 β) (-β * TaP A s0 β s / s) s := by
  have hd : HasDerivAt (fun x => x / s0) (1 / s0) s := by
    simpa using (hasDerivAt_id s).div_const s0
  have h := (hd.rpow_const (p := -β) (Or.inl (div_pos hs hs0).ne')).const_mul A
  unfold TaP
  convert h using 1
  rw [rpow_sub_one (div_pos hs hs0).ne']
  field_simp

/-- **P5(iv), general `T_a(s)`.** On the adoption branch (strictly), with `T_a` differentiable,
`dR_c/ds = (H T_a/s)(ε_H + ε_{T_a})`. -/
theorem p5_iv_adopt_deriv {H : ℝ → ℝ} {H' Ta' S s : ℝ} {Ta : ℝ → ℝ} (hs : 0 < s)
    (hH : HasDerivAt H H' s) (hHs : 0 < H s) (hT : HasDerivAt Ta Ta' s) (hTs : 0 < Ta s)
    (hb : K / s < Ta s) :
    HasDerivAt (RcT H K Ta S) ((H s * Ta s / s) * (s * H' / H s + s * Ta' / Ta s)) s := by
  have hev : (fun x => H x * Ta x + S) =ᶠ[𝓝 s] RcT H K Ta S := by
    have hc : ContinuousAt (fun x => Ta x - K / x) s :=
      hT.continuousAt.sub (continuousAt_const.div continuousAt_id hs.ne')
    filter_upwards [hc.eventually (isOpen_Ioi.mem_nhds (show Ta s - K / s ∈ Ioi 0 by
      simp; linarith))] with x hx
    simp only [mem_Ioi, sub_pos] at hx
    simp [RcT, max_eq_right hx.le]
  have h := ((hH.mul hT).add_const S).congr_of_eventuallyEq hev.symm
  convert h using 1
  field_simp

/-- **P5(iii), adoption branch.** `dR_c/ds = (H T_a/s)(ε_H − β)`. -/
theorem p5_iii_adopt_deriv (hA : 0 < A) (hs0 : 0 < s0) {H : ℝ → ℝ} {H' S s : ℝ} (hs : 0 < s)
    (hH : HasDerivAt H H' s) (hHs : 0 < H s) (hb : K / s < TaP A s0 β s) :
    HasDerivAt (RcT H K (TaP A s0 β) S) ((H s * TaP A s0 β s / s) * (s * H' / H s - β)) s := by
  have h := p5_iv_adopt_deriv (S := S) hs hH hHs (hasDerivAt_TaP (β := β) hA hs0 hs)
    (TaP_pos hA hs0 hs) hb
  convert h using 2
  have := (TaP_pos (β := β) hA hs0 hs).ne'
  field_simp; ring

/-- **P5(iii), the escape.** On the adoption branch, acceleration lowers `R_c` iff `β > ε_H`. -/
theorem p5_iii_lowers_iff (hA : 0 < A) (hs0 : 0 < s0) {H : ℝ → ℝ} {H' S s : ℝ} (hs : 0 < s)
    (hH : HasDerivAt H H' s) (hHs : 0 < H s) (hb : K / s < TaP A s0 β s) :
    deriv (RcT H K (TaP A s0 β) S) s < 0 ↔ s * H' / H s < β := by
  rw [(p5_iii_adopt_deriv (S := S) hA hs0 hs hH hHs hb).deriv]
  have hc : 0 < H s * TaP A s0 β s / s := by
    have := TaP_pos (β := β) hA hs0 hs; positivity
  constructor
  · intro h; by_contra h'
    have := mul_nonneg hc.le (show 0 ≤ s * H' / H s - β by linarith [not_lt.mp h']); linarith
  · intro h; exact mul_neg_of_pos_of_neg hc (by linarith)

/-- **P5(iii), "equivalently `|ε_{T_a}| > ε_H`".** The elasticity of `T_a` is `−β`. -/
theorem p5_iii_elast_Ta (hA : 0 < A) (hs0 : 0 < s0) (hβ0 : 0 ≤ β) {s : ℝ} (hs : 0 < s) :
    s * (-β * TaP A s0 β s / s) / TaP A s0 β s = -β ∧ |(-β)| = β := by
  have := (TaP_pos (β := β) hA hs0 hs).ne'
  exact ⟨by field_simp, by rw [abs_neg, abs_of_nonneg hβ0]⟩

/-- **P5(iii), capability branch.** Where capability binds, `dR_c/ds = (KH/s²)(ε_H − 1)`, an
expression in which neither `β`, `A` nor `s₀` appears. -/
theorem p5_iii_cap_deriv {H : ℝ → ℝ} {H' S s : ℝ} {Ta : ℝ → ℝ} (hs : 0 < s)
    (hH : HasDerivAt H H' s) (hHs : 0 < H s) (hT : ContinuousAt Ta s) (hb : Ta s < K / s) :
    HasDerivAt (RcT H K Ta S) ((K * H s / s ^ 2) * (s * H' / H s - 1)) s := by
  have hev : (fun x => H x * (K / x) + S) =ᶠ[𝓝 s] RcT H K Ta S := by
    have hc : ContinuousAt (fun x => K / x - Ta x) s :=
      (continuousAt_const.div continuousAt_id hs.ne').sub hT
    filter_upwards [hc.eventually (isOpen_Ioi.mem_nhds (show K / s - Ta s ∈ Ioi 0 by
      simp; linarith))] with x hx
    simp only [mem_Ioi, sub_pos] at hx
    simp [RcT, max_eq_left hx.le]
  have h := ((hH.mul (hasDerivAt_K_div K s hs.ne')).add_const S).congr_of_eventuallyEq hev.symm
  convert h using 1
  field_simp; ring

/-- **P5(iv), "P1 is the case `β = 0`".** -/
theorem p5_beta_zero (H : ℝ → ℝ) (K A s0 S : ℝ) : RcT H K (TaP A s0 0) S = Rc H K A S := by
  ext s; simp [RcT, Rc, TaP]

/-- **P5(iv), unbounded adoption branch.** If adoption binds and `β > ε_H` throughout `(a, ∞)`,
`R_c` is strictly decreasing there and no point of `(a, ∞)` minimises it over any domain
containing `(a, ∞)`. -/
theorem p5_iv_unbounded_branch (hA : 0 < A) (hs0 : 0 < s0) {H H' : ℝ → ℝ} {S a : ℝ}
    (ha : 0 ≤ a) (hH : ∀ s ∈ Ioi a, HasDerivAt H (H' s) s) (hHs : ∀ s ∈ Ioi a, 0 < H s)
    (hb : ∀ s ∈ Ioi a, K / s < TaP A s0 β s) (hε : ∀ s ∈ Ioi a, s * H' s / H s < β) :
    StrictAntiOn (RcT H K (TaP A s0 β) S) (Ioi a) ∧
      ∀ D, Ioi a ⊆ D → ∀ m ∈ Ioi a, ¬ IsMinOn (RcT H K (TaP A s0 β) S) D m := by
  have hpos : ∀ s ∈ Ioi a, 0 < s := fun s hs => lt_of_le_of_lt ha hs
  have hanti : StrictAntiOn (RcT H K (TaP A s0 β) S) (Ioi a) := by
    apply strictAntiOn_of_deriv_neg (convex_Ioi a)
    · intro s hs
      exact (p5_iii_adopt_deriv (S := S) hA hs0 (hpos s hs) (hH s hs) (hHs s hs)
        (hb s hs)).continuousAt.continuousWithinAt
    · intro s hs
      rw [interior_Ioi] at hs
      exact (p5_iii_lowers_iff hA hs0 (hpos s hs) (hH s hs) (hHs s hs) (hb s hs)).mpr (hε s hs)
  refine ⟨hanti, fun D hD m hm hmin => ?_⟩
  have hm1 : m + 1 ∈ Ioi a := by have : a < m := hm; show a < m + 1; linarith
  have h1 := hmin (hD hm1)
  simp only [mem_ofPred_eq] at h1
  have h2 := hanti hm hm1 (by linarith)
  linarith

/-- **Body only (line 134): the escape with a speed-dependent step term.** On the adoption
branch, with `S` differentiable, acceleration lowers `R_c` iff `β > ε_H + sS′/(H T_a)`. -/
theorem p5_body_step_term (hA : 0 < A) (hs0 : 0 < s0) {H Sf : ℝ → ℝ} {H' S' s : ℝ}
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHs : 0 < H s) (hS : HasDerivAt Sf S' s)
    (hb : K / s < TaP A s0 β s) :
    HasDerivAt (fun x => H x * max (K / x) (TaP A s0 β x) + Sf x)
        ((H s * TaP A s0 β s / s) * (s * H' / H s - β) + S') s ∧
      ((H s * TaP A s0 β s / s) * (s * H' / H s - β) + S' < 0 ↔
        s * H' / H s + s * S' / (H s * TaP A s0 β s) < β) := by
  have h0 := p5_iii_adopt_deriv (S := 0) hA hs0 hs hH hHs hb
  have hT := TaP_pos (β := β) hA hs0 hs
  refine ⟨?_, ?_⟩
  · have := h0.add hS
    convert this using 1
    ext x; simp [RcT]
  · have hc : 0 < H s * TaP A s0 β s / s := by positivity
    have key : (H s * TaP A s0 β s / s) * (s * H' / H s - β) + S'
        = (H s * TaP A s0 β s / s) * (s * H' / H s + s * S' / (H s * TaP A s0 β s) - β) := by
      field_simp; ring
    rw [key]
    constructor
    · intro h; by_contra h'
      have := mul_nonneg hc.le (show 0 ≤ s * H' / H s + s * S' / (H s * TaP A s0 β s) - β by
        linarith [not_lt.mp h']); linarith
    · intro h; exact mul_neg_of_pos_of_neg hc (by linarith)

end P5

/-! ## P4 -/

section P4

/-- **P4(i).** For the social loss `V_c C_c + V_A C_A` with `V_c, V_A > 0` and `C_A′ > 0`, a
marginal acceleration lowers the loss iff `C_c′ < 0` and `V_c/V_A > C_A′/(−C_c′)`. `C_c`, `C_A`
are arbitrary differentiable functions here because the paper states P4(i) for arbitrary
cumulative hazards; the content is the derivative and its algebraic rearrangement. -/
theorem p4_i {Cc CA : ℝ → ℝ} {Cc' CA' Vc VA s : ℝ} (hc : HasDerivAt Cc Cc' s)
    (ha : HasDerivAt CA CA' s) (hVc : 0 < Vc) (hVA : 0 < VA) (hCA' : 0 < CA') :
    HasDerivAt (fun x => Vc * Cc x + VA * CA x) (Vc * Cc' + VA * CA') s ∧
      (Vc * Cc' + VA * CA' < 0 ↔ Cc' < 0 ∧ CA' / (-Cc') < Vc / VA) := by
  refine ⟨(hc.const_mul Vc).add (ha.const_mul VA), ⟨fun h => ?_, fun ⟨h1, h2⟩ => ?_⟩⟩
  · have hneg : Cc' < 0 := by
      by_contra h'
      have : 0 ≤ Vc * Cc' := mul_nonneg hVc.le (not_lt.mp h')
      have : 0 < VA * CA' := mul_pos hVA hCA'
      linarith
    refine ⟨hneg, ?_⟩
    rw [div_lt_div_iff₀ (by linarith) hVA]
    nlinarith
  · rw [div_lt_div_iff₀ (by linarith) hVA] at h2
    nlinarith

/-- **P4(i), above the kink.** With `C_c = R_c` of P1, above `s*` the total-loss derivative is
positive for every pair of positive stakes: no ratio of stakes justifies acceleration. -/
theorem p4_i_above_kink {H H' : ℝ → ℝ} {K Ta S smin : ℝ} {CA : ℝ → ℝ} {CA' s : ℝ}
    (hA : A4 H H' smin) (hTa : 0 < Ta) (hsmin : 0 < smin) (hlt : smin < K / Ta)
    (hk : K / Ta < s) (ha : HasDerivAt CA CA' s) (hCA' : 0 < CA') :
    ∀ Vc VA : ℝ, 0 < Vc → 0 < VA →
      HasDerivAt (fun x => Vc * Rc H K Ta S x + VA * CA x) (Vc * (H' s * Ta) + VA * CA') s ∧
        0 < Vc * (H' s * Ta) + VA * CA' := by
  intro Vc VA hVc hVA
  obtain ⟨hd, hpos⟩ := p1_deriv_above_kink (S := S) hA hTa hsmin hlt hk
  exact ⟨(hd.const_mul Vc).add (ha.const_mul VA), add_pos (mul_pos hVc hpos) (mul_pos hVA hCA')⟩

/-- The rectangular discounted integral: `∫₀^T c e^{−rt} dt = c(1 − e^{−rT})/r`. -/
theorem integral_rect (c r T : ℝ) (hr : r ≠ 0) :
    ∫ t in (0 : ℝ)..T, c * exp (-(r * t)) = c * (1 - exp (-(r * T))) / r := by
  have hF : ∀ t ∈ uIcc (0 : ℝ) T,
      HasDerivAt (fun t => -(c * exp (-(r * t))) / r) (c * exp (-(r * t))) t := by
    intro t _
    have h := ((((hasDerivAt_id' t).const_mul r).fun_neg.exp).const_mul c).fun_neg.div_const r
    convert h using 1
    field_simp
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hF
    (by apply Continuous.intervalIntegrable; fun_prop)]
  simp only [mul_zero, neg_zero, exp_zero]; ring

/-- The discounted near loss under a rectangular hazard, **defined as the integral** of the
discounted hazard over the transition `[0, T(s)]`, `T(s) = max(K/s, T_a)`, plus the present value
of the step losses `S_r(s)`. -/
noncomputable def nearDisc (H : ℝ → ℝ) (K Ta r : ℝ) (Sr : ℝ → ℝ) (s : ℝ) : ℝ :=
  (∫ t in (0 : ℝ)..max (K / s) Ta, H s * exp (-(r * t))) + Sr s

/-- **P4(ii), the closed form.** The near loss is `H(1 − e^{−rT})/r + S_r`. -/
theorem p4_ii_closed (H : ℝ → ℝ) (K Ta r : ℝ) (Sr : ℝ → ℝ) (s : ℝ) (hr : r ≠ 0) :
    nearDisc H K Ta r Sr s = H s * (1 - exp (-(r * max (K / s) Ta))) / r + Sr s := by
  unfold nearDisc; rw [integral_rect _ _ _ hr]

/-- **P4(ii), the derivative below the kink**, for a differentiable `S_r`. -/
theorem p4_ii_deriv {H H' Sr : ℝ → ℝ} {K Ta r smin Sr' : ℝ} (hA : A4 H H' smin) (hTa : 0 < Ta)
    (hsmin : 0 < smin) (hr : 0 < r) {s : ℝ} (hs : smin < s) (hk : s < K / Ta)
    (hS : HasDerivAt Sr Sr' s) :
    HasDerivAt (nearDisc H K Ta r Sr)
      (H' s * (1 - exp (-(r * (K / s)))) / r - H s * exp (-(r * (K / s))) * K / s ^ 2 + Sr') s := by
  have s0 : 0 < s := hsmin.trans hs
  have hev : (fun x => H x * (1 - exp (-(r * (K / x)))) / r + Sr x) =ᶠ[𝓝 s]
      nearDisc H K Ta r Sr := by
    filter_upwards [isOpen_Ioo.mem_nhds (show s ∈ Ioo 0 (K / Ta) from ⟨s0, hk⟩)] with x hx
    rw [p4_ii_closed _ _ _ _ _ _ hr.ne', max_cap hTa hx.1 hx.2.le]
  have he := (((hasDerivAt_K_div K s s0.ne').const_mul r).fun_neg.exp).const_sub 1
  have h := (((hA.hasDerivAt hs).fun_mul he).div_const r).fun_add hS
  convert h.congr_of_eventuallyEq hev.symm using 1
  field_simp; ring

/-- **P4(ii), the iff.** With `S_r` independent of `s`, below `s*` acceleration lowers the
discounted near loss iff `ε_H < x/(e^x − 1)`, `x = rK/s`. -/
theorem p4_ii_lowers_iff {H H' : ℝ → ℝ} {K Ta r smin c : ℝ} (hA : A4 H H' smin) (hTa : 0 < Ta)
    (hsmin : 0 < smin) (hK : 0 < K) (hr : 0 < r) {s : ℝ} (hs : smin < s) (hk : s < K / Ta) :
    deriv (nearDisc H K Ta r (fun _ => c)) s < 0 ↔
      elast H H' s < (r * (K / s)) / (exp (r * (K / s)) - 1) := by
  have s0 : 0 < s := hsmin.trans hs
  have hHs := hA.pos s hs.le
  rw [(p4_ii_deriv (Sr' := 0) hA hTa hsmin hr hs hk (hasDerivAt_const s c)).deriv]
  set x := r * (K / s) with hx
  have x0 : 0 < x := by positivity
  have hex : 1 < exp x := by have := add_one_lt_exp x0.ne'; linarith
  have hE : exp (-x) = (exp x)⁻¹ := exp_neg x
  have hexp0 : 0 < exp x := exp_pos x
  have key : H' s * (1 - exp (-x)) / r - H s * exp (-x) * K / s ^ 2 + 0
      = (H s / (r * s * exp x)) * (elast H H' s * (exp x - 1) - x) := by
    rw [hE, hx]; unfold elast; field_simp; ring
  rw [key, lt_div_iff₀ (by linarith)]
  have hc : 0 < H s / (r * s * exp x) := by positivity
  constructor
  · intro h; by_contra h'
    have := mul_nonneg hc.le (show 0 ≤ elast H H' s * (exp x - 1) - x by linarith [not_lt.mp h'])
    linarith
  · intro h; exact mul_neg_of_pos_of_neg hc (by linarith)

/-- **P4(ii), the derivative at the endpoint `s = s_min`**: the right derivative (within
`[s_min, ∞)`), with the same formula as below the kink. -/
theorem p4_ii_deriv_at_smin {H H' Sr : ℝ → ℝ} {K Ta r smin Sr' : ℝ} (hA : A4 H H' smin)
    (hTa : 0 < Ta) (hsmin : 0 < smin) (hr : 0 < r) (hlt : smin < K / Ta)
    (hS : HasDerivWithinAt Sr Sr' (Ici smin) smin) :
    HasDerivWithinAt (nearDisc H K Ta r Sr)
      (H' smin * (1 - exp (-(r * (K / smin)))) / r
        - H smin * exp (-(r * (K / smin))) * K / smin ^ 2 + Sr') (Ici smin) smin := by
  have hm : smin ∈ Ici smin := mem_Ici.mpr le_rfl
  have heq : (fun x => H x * (1 - exp (-(r * (K / x)))) / r + Sr x) =ᶠ[𝓝[Ici smin] smin]
      nearDisc H K Ta r Sr := by
    filter_upwards [nhdsWithin_le_nhds (isOpen_Ioo.mem_nhds
      (show smin ∈ Ioo 0 (K / Ta) from ⟨hsmin, hlt⟩))] with x hx
    rw [p4_ii_closed _ _ _ _ _ _ hr.ne', max_cap hTa hx.1 hx.2.le]
  have he := (((hasDerivAt_K_div K smin hsmin.ne').const_mul r).fun_neg.exp).const_sub 1
  have h := (((hA.deriv smin hm).mul he.hasDerivWithinAt).div_const r).add hS
  have h2 := h.congr_of_eventuallyEq heq.symm
    (by rw [p4_ii_closed _ _ _ _ _ _ hr.ne', max_cap hTa hsmin hlt.le]; rfl)
  convert h2 using 1
  field_simp; ring

/-- **P4(ii), the iff at the endpoint `s = s_min`**, for the right derivative. -/
theorem p4_ii_lowers_iff_at_smin {H H' : ℝ → ℝ} {K Ta r smin c : ℝ} (hA : A4 H H' smin)
    (hTa : 0 < Ta) (hsmin : 0 < smin) (hK : 0 < K) (hr : 0 < r) (hlt : smin < K / Ta) :
    derivWithin (nearDisc H K Ta r (fun _ => c)) (Ici smin) smin < 0 ↔
      elast H H' smin < (r * (K / smin)) / (exp (r * (K / smin)) - 1) := by
  have hm : smin ∈ Ici smin := mem_Ici.mpr le_rfl
  have hHs := hA.pos smin hm
  rw [(p4_ii_deriv_at_smin (Sr' := 0) hA hTa hsmin hr hlt
    (hasDerivWithinAt_const smin _ c)).derivWithin (uniqueDiffOn_Ici smin smin hm)]
  set x := r * (K / smin) with hx
  have x0 : 0 < x := by positivity
  have hex : 1 < exp x := by have := add_one_lt_exp x0.ne'; linarith
  have hE : exp (-x) = (exp x)⁻¹ := exp_neg x
  have hexp0 : 0 < exp x := exp_pos x
  have key : H' smin * (1 - exp (-x)) / r - H smin * exp (-x) * K / smin ^ 2 + 0
      = (H smin / (r * smin * exp x)) * (elast H H' smin * (exp x - 1) - x) := by
    rw [hE, hx]; unfold elast; field_simp; ring
  rw [key, lt_div_iff₀ (by linarith)]
  have hc : 0 < H smin / (r * smin * exp x) := by positivity
  constructor
  · intro h; by_contra h'
    have := mul_nonneg hc.le
      (show 0 ≤ elast H H' smin * (exp x - 1) - x by linarith [not_lt.mp h'])
    linarith
  · intro h; exact mul_neg_of_pos_of_neg hc (by linarith)

/-- **P4(ii), "this threshold lies below one".** -/
theorem p4_ii_threshold_lt_one {x : ℝ} (hx : 0 < x) : x / (exp x - 1) < 1 := by
  have := add_one_lt_exp hx.ne'
  rw [div_lt_one (by linarith)]; linarith

/-- **P4(ii), the sign of `r` matters.** For `x < 0` (a negative rate `r`) the threshold
`x/(e^x − 1)` exceeds one, so "this threshold lies below one" needs `r > 0`. -/
theorem p4_ii_threshold_gt_one_of_neg {x : ℝ} (hx : x < 0) : 1 < x / (exp x - 1) := by
  have h1 := add_one_lt_exp hx.ne
  have h2 : exp x < 1 := by rw [← exp_zero]; exact exp_lt_exp.mpr hx
  rw [lt_div_iff_of_neg (by linarith)]; linarith

/-- **P4(ii), steps brought earlier.** With `S_r(s) = Σ_k S_k e^{−r t_k(s)}` over a nonempty
finite set of steps, `S_k > 0`, `r > 0`, and every date differentiable at `s` with `t_k′(s) < 0`:
`S_r′(s) > 0`, and at any speed where the near loss without step losses has derivative `d₀`
(on either branch), the near loss with them has derivative `d₀ + S_r′ > d₀`. -/
theorem p4_ii_steps_earlier {H : ℝ → ℝ} {K Ta r d0 : ℝ} (hr : 0 < r) {s : ℝ}
    (I : Finset ℕ) (hI : I.Nonempty) (Sk : ℕ → ℝ) (t : ℕ → ℝ → ℝ) (t' : ℕ → ℝ)
    (hSk : ∀ k ∈ I, 0 < Sk k) (ht : ∀ k ∈ I, HasDerivAt (t k) (t' k) s)
    (ht' : ∀ k ∈ I, t' k < 0) (h0 : HasDerivAt (nearDisc H K Ta r (fun _ => 0)) d0 s) :
    let Sr := fun x => ∑ k ∈ I, Sk k * exp (-(r * t k x))
    let dS := ∑ k ∈ I, Sk k * (exp (-(r * t k s)) * -(r * t' k))
    HasDerivAt Sr dS s ∧ 0 < dS ∧ HasDerivAt (nearDisc H K Ta r Sr) (d0 + dS) s ∧ d0 < d0 + dS := by
  intro Sr dS
  have hSr : HasDerivAt Sr dS s :=
    HasDerivAt.fun_sum fun k hk => ((((ht k hk).const_mul r).fun_neg).exp).const_mul (Sk k)
  have hdS : 0 < dS := by
    apply Finset.sum_pos _ hI
    intro k hk
    have := ht' k hk
    have : 0 < -(r * t' k) := by nlinarith
    have := hSk k hk
    positivity
  have hfun : nearDisc H K Ta r Sr = fun x => nearDisc H K Ta r (fun _ => 0) x + Sr x := by
    ext x; simp [nearDisc]
  refine ⟨hSr, hdS, ?_, by linarith⟩
  rw [hfun]; exact h0.add hSr

/-- **P4(ii), steps brought earlier, below the kink:** `d₀` is the rectangular derivative of
`p4_ii_deriv`. -/
theorem p4_ii_steps_earlier_below_kink {H H' : ℝ → ℝ} {K Ta r smin : ℝ} (hA : A4 H H' smin)
    (hTa : 0 < Ta) (hsmin : 0 < smin) (hr : 0 < r) {s : ℝ} (hs : smin < s) (hk : s < K / Ta)
    (I : Finset ℕ) (hI : I.Nonempty) (Sk : ℕ → ℝ) (t : ℕ → ℝ → ℝ) (t' : ℕ → ℝ)
    (hSk : ∀ k ∈ I, 0 < Sk k) (ht : ∀ k ∈ I, HasDerivAt (t k) (t' k) s)
    (ht' : ∀ k ∈ I, t' k < 0) :
    HasDerivAt (nearDisc H K Ta r (fun x => ∑ k ∈ I, Sk k * exp (-(r * t k x))))
      ((H' s * (1 - exp (-(r * (K / s)))) / r - H s * exp (-(r * (K / s))) * K / s ^ 2 + 0) +
        ∑ k ∈ I, Sk k * (exp (-(r * t k s)) * -(r * t' k))) s :=
  (p4_ii_steps_earlier hr I hI Sk t t' hSk ht ht'
    (p4_ii_deriv (Sr' := 0) hA hTa hsmin hr hs hk (hasDerivAt_const s 0))).2.2.1

/-! ### P4(ii), a general fixed profile -/

/-- `ψ(x) = ∫₀¹ e^{−xu} g(u) du`. -/
noncomputable def psi (g : ℝ → ℝ) (x : ℝ) : ℝ := ∫ u in (0 : ℝ)..1, exp (-(x * u)) * g u

/-- `−ψ′(x) = ∫₀¹ u e^{−xu} g(u) du` (proved to be minus the derivative in `hasDerivAt_psi`). -/
noncomputable def psiD (g : ℝ → ℝ) (x : ℝ) : ℝ := ∫ u in (0 : ℝ)..1, u * exp (-(x * u)) * g u

/-- Differentiation under the integral sign: `ψ′(x) = −∫₀¹ u e^{−xu} g(u) du` for any integrable
profile `g`. -/
theorem hasDerivAt_psi {g : ℝ → ℝ} (hg : IntervalIntegrable g volume 0 1) (x : ℝ) :
    HasDerivAt (psi g) (-psiD g x) x := by
  have hmeas : AEStronglyMeasurable g (volume.restrict (uIoc (0 : ℝ) 1)) :=
    (intervalIntegrable_iff.mp hg).aestronglyMeasurable
  have hbound : ∀ᵐ u ∂(volume : Measure ℝ), u ∈ uIoc (0 : ℝ) 1 → ∀ y ∈ Metric.ball x 1,
      ‖-(u * exp (-(y * u)) * g u)‖ ≤ exp (|x| + 1) * ‖g u‖ := by
    refine ae_of_all _ fun u hu y hy => ?_
    rw [uIoc_of_le zero_le_one] at hu
    have hy' : |y| < |x| + 1 := by
      have := abs_sub_abs_le_abs_sub y x
      rw [Metric.mem_ball, Real.dist_eq] at hy; linarith
    rw [norm_neg, norm_mul, norm_mul, Real.norm_of_nonneg hu.1.le,
      Real.norm_of_nonneg (exp_pos _).le]
    have a1 : -y * u ≤ |y| * u := mul_le_mul_of_nonneg_right (neg_le_abs y) hu.1.le
    have a2 : |y| * u ≤ |y| := mul_le_of_le_one_right (abs_nonneg y) hu.2
    have h1 : exp (-(y * u)) ≤ exp (|x| + 1) := exp_le_exp.mpr (by linarith [neg_mul y u])
    have h2 : u * exp (-(y * u)) ≤ exp (|x| + 1) :=
      calc u * exp (-(y * u)) ≤ 1 * exp (-(y * u)) :=
            mul_le_mul_of_nonneg_right hu.2 (exp_pos _).le
        _ ≤ exp (|x| + 1) := by rw [one_mul]; exact h1
    exact mul_le_mul_of_nonneg_right h2 (norm_nonneg _)
  have hdiff : ∀ᵐ u ∂(volume : Measure ℝ), u ∈ uIoc (0 : ℝ) 1 → ∀ y ∈ Metric.ball x 1,
      HasDerivAt (fun y => exp (-(y * u)) * g u) (-(u * exp (-(y * u)) * g u)) y := by
    refine ae_of_all _ fun u _ y _ => ?_
    have := (((hasDerivAt_id' y).mul_const u).fun_neg.exp).mul_const (g u)
    convert this using 1; ring
  have key := intervalIntegral.hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (μ := volume) (a := 0) (b := 1) (x₀ := x) (s := Metric.ball x 1)
    (F := fun y u => exp (-(y * u)) * g u) (F' := fun y u => -(u * exp (-(y * u)) * g u))
    (bound := fun u => exp (|x| + 1) * ‖g u‖)
    (Metric.ball_mem_nhds x one_pos)
    (Eventually.of_forall fun y =>
      ((by fun_prop : Continuous fun u : ℝ => exp (-(y * u))).aestronglyMeasurable.mul hmeas))
    (hg.continuousOn_mul (by fun_prop : Continuous fun u : ℝ => exp (-(x * u))).continuousOn)
    (((by fun_prop : Continuous fun u : ℝ => u * exp (-(x * u))).aestronglyMeasurable.mul
      hmeas).neg)
    hbound (hg.norm.const_mul _) hdiff
  have h2 := key.2
  rw [intervalIntegral.integral_neg] at h2
  exact h2

/-- `ψ > 0` for a nonnegative profile with `∫ g = 1`. -/
theorem psi_pos {g : ℝ → ℝ} (hg : IntervalIntegrable g volume 0 1)
    (hg0 : ∀ u ∈ Icc (0 : ℝ) 1, 0 ≤ g u) (hg1 : ∫ u in (0 : ℝ)..1, g u = 1) (x : ℝ) :
    0 < psi g x := by
  have hle : ∫ u in (0 : ℝ)..1, exp (-|x|) * g u ≤ psi g x := by
    apply intervalIntegral.integral_mono_on zero_le_one (hg.const_mul _)
      (hg.continuousOn_mul (by fun_prop : Continuous fun u : ℝ => exp (-(x * u))).continuousOn)
    intro u hu
    apply mul_le_mul_of_nonneg_right _ (hg0 u hu)
    apply exp_le_exp.mpr
    have a1 : x * u ≤ |x| * u := mul_le_mul_of_nonneg_right (le_abs_self x) hu.1
    have a2 : |x| * u ≤ |x| := mul_le_of_le_one_right (abs_nonneg x) hu.2
    linarith
  rw [intervalIntegral.integral_const_mul, hg1, mul_one] at hle
  exact lt_of_lt_of_le (exp_pos _) hle

/-- `∫₀¹ u e^{−xu} g(u) du > 0` (so `ψ′ < 0`) for a nonnegative profile with `∫ g = 1`. -/
theorem psiD_pos {g : ℝ → ℝ} (hg : IntervalIntegrable g volume 0 1)
    (hg0 : ∀ u ∈ Icc (0 : ℝ) 1, 0 ≤ g u) (hg1 : ∫ u in (0 : ℝ)..1, g u = 1) (x : ℝ) :
    0 < psiD g x := by
  have hint : IntervalIntegrable (fun u => u * exp (-(x * u)) * g u) volume 0 1 :=
    hg.continuousOn_mul (by fun_prop : Continuous fun u : ℝ => u * exp (-(x * u))).continuousOn
  unfold psiD
  rw [intervalIntegral.integral_of_le zero_le_one] at hg1 ⊢
  have hint' : Integrable (fun u => u * exp (-(x * u)) * g u) (volume.restrict (Ioc (0 : ℝ) 1)) :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le zero_le_one).mp hint
  have hnn : 0 ≤ᵐ[volume.restrict (Ioc (0 : ℝ) 1)] (fun u => u * exp (-(x * u)) * g u) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with u hu
    exact mul_nonneg (mul_nonneg hu.1.le (exp_pos _).le) (hg0 u ⟨hu.1.le, hu.2⟩)
  rcases (integral_nonneg_of_ae hnn).lt_or_eq with h | h
  · exact h
  · exfalso
    have h0 := (integral_eq_zero_iff_of_nonneg_ae hnn hint').mp h.symm
    have hg0' : g =ᵐ[volume.restrict (Ioc (0 : ℝ) 1)] 0 := by
      filter_upwards [h0, ae_restrict_mem measurableSet_Ioc] with u hu hmem
      have hne : u * exp (-(x * u)) ≠ 0 := mul_ne_zero hmem.1.ne' (exp_pos _).ne'
      simp only [Pi.zero_apply] at hu ⊢
      rcases mul_eq_zero.mp hu with h1 | h1
      · exact absurd h1 hne
      · exact h1
    rw [integral_congr_ae hg0'] at hg1
    simp at hg1

/-- The discounted near loss for a hazard of fixed profile `H·g(t/T)`, **defined as the
integral** of the discounted hazard over `[0, T(s)]`, plus a speed-independent `S_r`. -/
noncomputable def nearProf (H g : ℝ → ℝ) (K Ta r Sr : ℝ) (s : ℝ) : ℝ :=
  (∫ t in (0 : ℝ)..max (K / s) Ta, exp (-(r * t)) * (H s * g (t / max (K / s) Ta))) + Sr

/-- Change of variable `u = t/T`: `∫₀^T e^{−rt} c g(t/T) dt = c T ψ(rT)`. -/
theorem integral_profile (c r T : ℝ) (g : ℝ → ℝ) (hT : T ≠ 0) :
    ∫ t in (0 : ℝ)..T, exp (-(r * t)) * (c * g (t / T)) = c * T * psi g (r * T) := by
  have h2 : ∫ u in (0 : ℝ)..1, exp (-(r * T * u)) * (c * g u) = c * psi g (r * T) := by
    unfold psi
    rw [← intervalIntegral.integral_const_mul]
    congr 1; ext u; ring
  have h3 := intervalIntegral.integral_comp_div (a := 0) (b := T)
    (fun u => exp (-(r * T * u)) * (c * g u)) hT
  rw [zero_div, div_self hT, smul_eq_mul, h2] at h3
  calc ∫ t in (0 : ℝ)..T, exp (-(r * t)) * (c * g (t / T))
      = ∫ t in (0 : ℝ)..T, exp (-(r * T * (t / T))) * (c * g (t / T)) := by
        congr 1; ext t; rw [show r * T * (t / T) = r * t by field_simp]
    _ = T * (c * psi g (r * T)) := h3
    _ = c * T * psi g (r * T) := by ring

/-- **P4(ii), general profile: the closed form** `H T ψ(rT) + S_r`. -/
theorem p4_profile_closed (H g : ℝ → ℝ) (K Ta r Sr s : ℝ) (hT : max (K / s) Ta ≠ 0) :
    nearProf H g K Ta r Sr s = H s * max (K / s) Ta * psi g (r * max (K / s) Ta) + Sr := by
  unfold nearProf; rw [integral_profile _ _ _ _ hT]

/-- **P4(ii), general profile: the derivative below the kink**, in the paper's form
`d ln[HTψ(rT)]/d ln s = ε_H − 1 − xψ′(x)/ψ(x)`, written with `ψ′ = −psiD`. -/
theorem p4_profile_deriv {H H' g : ℝ → ℝ} {K Ta r smin Sr : ℝ} (hA : A4 H H' smin)
    (hTa : 0 < Ta) (hsmin : 0 < smin) (hK : 0 < K) (hg : IntervalIntegrable g volume 0 1)
    (hg0 : ∀ u ∈ Icc (0 : ℝ) 1, 0 ≤ g u) (hg1 : ∫ u in (0 : ℝ)..1, g u = 1)
    {s : ℝ} (hs : smin < s) (hk : s < K / Ta) :
    HasDerivAt (nearProf H g K Ta r Sr)
      ((H s * K * psi g (r * (K / s)) / s ^ 2) *
        (elast H H' s - 1 - r * (K / s) * (-psiD g (r * (K / s))) / psi g (r * (K / s)))) s := by
  have s0 : 0 < s := hsmin.trans hs
  have hHs := (hA.pos s hs.le).ne'
  have hψ := (psi_pos hg hg0 hg1 (r * (K / s))).ne'
  have hev : (fun x => H x * (K / x) * psi g (r * (K / x)) + Sr) =ᶠ[𝓝 s] nearProf H g K Ta r Sr := by
    filter_upwards [isOpen_Ioo.mem_nhds (show s ∈ Ioo 0 (K / Ta) from ⟨s0, hk⟩)] with x hx
    rw [p4_profile_closed _ _ _ _ _ _ _ (by rw [max_cap hTa hx.1 hx.2.le]; exact (div_pos hK hx.1).ne'),
      max_cap hTa hx.1 hx.2.le]
  have hc : HasDerivAt (fun x => psi g (r * (K / x)))
      (-psiD g (r * (K / s)) * (r * (-K / s ^ 2))) s :=
    (hasDerivAt_psi hg _).comp s ((hasDerivAt_K_div K s s0.ne').const_mul r)
  have h := ((((hA.hasDerivAt hs).fun_mul (hasDerivAt_K_div K s s0.ne')).fun_mul hc).add_const Sr)
  convert h.congr_of_eventuallyEq hev.symm using 1
  unfold elast
  set p := psi g (r * (K / s))
  set q := psiD g (r * (K / s))
  field_simp; ring

/-- **P4(ii), general profile: the iff.** Below `s*`, acceleration lowers the near loss iff
`ε_H < 1 + xψ′(x)/ψ(x)`. -/
theorem p4_profile_lowers_iff {H H' g : ℝ → ℝ} {K Ta r smin Sr : ℝ} (hA : A4 H H' smin)
    (hTa : 0 < Ta) (hsmin : 0 < smin) (hK : 0 < K) (hg : IntervalIntegrable g volume 0 1)
    (hg0 : ∀ u ∈ Icc (0 : ℝ) 1, 0 ≤ g u) (hg1 : ∫ u in (0 : ℝ)..1, g u = 1)
    {s : ℝ} (hs : smin < s) (hk : s < K / Ta) :
    deriv (nearProf H g K Ta r Sr) s < 0 ↔
      elast H H' s < 1 + r * (K / s) * (-psiD g (r * (K / s))) / psi g (r * (K / s)) := by
  rw [(p4_profile_deriv (r := r) (Sr := Sr) hA hTa hsmin hK hg hg0 hg1 hs hk).deriv]
  have s0 : 0 < s := hsmin.trans hs
  have hc : 0 < H s * K * psi g (r * (K / s)) / s ^ 2 := by
    have := hA.pos s hs.le; have := psi_pos hg hg0 hg1 (r * (K / s)); positivity
  constructor
  · intro h; by_contra h'
    have := mul_nonneg hc.le (show 0 ≤ elast H H' s - 1 -
      r * (K / s) * (-psiD g (r * (K / s))) / psi g (r * (K / s)) by linarith [not_lt.mp h'])
    linarith
  · intro h; exact mul_neg_of_pos_of_neg hc (by linarith)

/-- **P4(ii), general profile: the derivative at the endpoint `s = s_min`**: the right
derivative (within `[s_min, ∞)`), with the same formula as below the kink. -/
theorem p4_profile_deriv_at_smin {H H' g : ℝ → ℝ} {K Ta r smin Sr : ℝ} (hA : A4 H H' smin)
    (hTa : 0 < Ta) (hsmin : 0 < smin) (hK : 0 < K) (hg : IntervalIntegrable g volume 0 1)
    (hg0 : ∀ u ∈ Icc (0 : ℝ) 1, 0 ≤ g u) (hg1 : ∫ u in (0 : ℝ)..1, g u = 1)
    (hlt : smin < K / Ta) :
    HasDerivWithinAt (nearProf H g K Ta r Sr)
      ((H smin * K * psi g (r * (K / smin)) / smin ^ 2) *
        (elast H H' smin - 1 - r * (K / smin) * (-psiD g (r * (K / smin))) /
          psi g (r * (K / smin)))) (Ici smin) smin := by
  have hm : smin ∈ Ici smin := mem_Ici.mpr le_rfl
  have hHs := (hA.pos smin hm).ne'
  have hψ := (psi_pos hg hg0 hg1 (r * (K / smin))).ne'
  have heq : (fun x => H x * (K / x) * psi g (r * (K / x)) + Sr) =ᶠ[𝓝[Ici smin] smin]
      nearProf H g K Ta r Sr := by
    filter_upwards [nhdsWithin_le_nhds (isOpen_Ioo.mem_nhds
      (show smin ∈ Ioo 0 (K / Ta) from ⟨hsmin, hlt⟩))] with x hx
    rw [p4_profile_closed _ _ _ _ _ _ _ (by rw [max_cap hTa hx.1 hx.2.le]; exact (div_pos hK hx.1).ne'),
      max_cap hTa hx.1 hx.2.le]
  have hc : HasDerivAt (fun x => psi g (r * (K / x)))
      (-psiD g (r * (K / smin)) * (r * (-K / smin ^ 2))) smin :=
    (hasDerivAt_psi hg _).comp smin ((hasDerivAt_K_div K smin hsmin.ne').const_mul r)
  have h := (((hA.deriv smin hm).mul (hasDerivAt_K_div K smin hsmin.ne').hasDerivWithinAt).mul
    hc.hasDerivWithinAt).add_const Sr
  have hT0 : max (K / smin) Ta ≠ 0 := by
    rw [max_cap hTa hsmin hlt.le]; exact (div_pos hK hsmin).ne'
  have h2 := h.congr_of_eventuallyEq heq.symm
    (by rw [p4_profile_closed _ _ _ _ _ _ _ hT0, max_cap hTa hsmin hlt.le]; rfl)
  convert h2 using 1
  simp only [Pi.mul_apply]
  unfold elast
  set p := psi g (r * (K / smin))
  set q := psiD g (r * (K / smin))
  field_simp; ring

/-- **P4(ii), general profile: the iff at the endpoint `s = s_min`**, for the right
derivative. -/
theorem p4_profile_lowers_iff_at_smin {H H' g : ℝ → ℝ} {K Ta r smin Sr : ℝ} (hA : A4 H H' smin)
    (hTa : 0 < Ta) (hsmin : 0 < smin) (hK : 0 < K) (hg : IntervalIntegrable g volume 0 1)
    (hg0 : ∀ u ∈ Icc (0 : ℝ) 1, 0 ≤ g u) (hg1 : ∫ u in (0 : ℝ)..1, g u = 1)
    (hlt : smin < K / Ta) :
    derivWithin (nearProf H g K Ta r Sr) (Ici smin) smin < 0 ↔
      elast H H' smin < 1 + r * (K / smin) * (-psiD g (r * (K / smin))) /
        psi g (r * (K / smin)) := by
  have hm : smin ∈ Ici smin := mem_Ici.mpr le_rfl
  rw [(p4_profile_deriv_at_smin (r := r) (Sr := Sr) hA hTa hsmin hK hg hg0 hg1 hlt).derivWithin
    (uniqueDiffOn_Ici smin smin hm)]
  have hc : 0 < H smin * K * psi g (r * (K / smin)) / smin ^ 2 := by
    have := hA.pos smin hm; have := psi_pos hg hg0 hg1 (r * (K / smin)); positivity
  constructor
  · intro h; by_contra h'
    have := mul_nonneg hc.le (show 0 ≤ elast H H' smin - 1 -
      r * (K / smin) * (-psiD g (r * (K / smin))) / psi g (r * (K / smin)) by
        linarith [not_lt.mp h'])
    linarith
  · intro h; exact mul_neg_of_pos_of_neg hc (by linarith)

/-- **P4(ii), "below one for every profile, since `ψ′ < 0`"** (for `x > 0`), for every
nonnegative integrable profile with `∫ g = 1`. -/
theorem p4_profile_threshold_lt_one {g : ℝ → ℝ} (hg : IntervalIntegrable g volume 0 1)
    (hg0 : ∀ u ∈ Icc (0 : ℝ) 1, 0 ≤ g u) (hg1 : ∫ u in (0 : ℝ)..1, g u = 1) {x : ℝ}
    (hx : 0 < x) : 1 + x * (-psiD g x) / psi g x < 1 := by
  have := div_neg_of_neg_of_pos (mul_neg_of_pos_of_neg hx (neg_neg_of_pos (psiD_pos hg hg0 hg1 x)))
    (psi_pos hg hg0 hg1 x)
  linarith

/-- **Gap: the comparison with one needs `g ≥ 0`.** The paper does not state it. With
`g(u) = 5 − 8u` (`∫ g = 1`, negative near `u = 1`), `∫₀¹ u g(u) du = −1/6 < 0`, so at `x = 0` the
profile derivative `ψ′(0) = 1/6 > 0`; `p4_profile_threshold_gt_one_example` shows the threshold
`1 + xψ′/ψ` then exceeds one at some `x > 0`. -/
theorem p4_profile_needs_nonneg :
    (∫ u in (0 : ℝ)..1, (5 - 8 * u)) = 1 ∧ psiD (fun u => 5 - 8 * u) 0 = -1 / 6 := by
  constructor
  · rw [intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
      (by apply Continuous.intervalIntegrable; fun_prop), intervalIntegral.integral_const,
      intervalIntegral.integral_const_mul, integral_id, smul_eq_mul]
    norm_num
  · unfold psiD
    simp only [zero_mul, neg_zero, exp_zero, mul_one]
    have : (fun u : ℝ => u * (5 - 8 * u)) = fun u => 5 * u - 8 * u ^ 2 := by ext u; ring
    rw [this, intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
      (by apply Continuous.intervalIntegrable; fun_prop), intervalIntegral.integral_const_mul,
      intervalIntegral.integral_const_mul, integral_id, integral_pow]
    norm_num

/-- Antiderivatives of `polynomial × e^{−u}`. -/
theorem hasDerivAt_poly_exp (a b c u : ℝ) :
    HasDerivAt (fun u => (a * u ^ 2 + b * u + c) * exp (-u))
      ((2 * a * u + b - (a * u ^ 2 + b * u + c)) * exp (-u)) u := by
  have hp : HasDerivAt (fun u => a * u ^ 2 + b * u + c) (2 * a * u + b) u := by
    have := (((hasDerivAt_id' u).fun_pow 2).const_mul a).fun_add ((hasDerivAt_id' u).const_mul b)
    convert this.add_const c using 1; simp; ring
  have := hp.fun_mul (hasDerivAt_id' u).fun_neg.exp
  convert this using 1; ring

/-- **The rectangle `g ≡ 1` gives `x/(e^x − 1)`** (line 1120), from the integral definitions. -/
theorem p4_rect_threshold {x : ℝ} (hx : 0 < x) :
    1 + x * (-psiD (fun _ => 1) x) / psi (fun _ => 1) x = x / (exp x - 1) := by
  have hF0 : ∀ u ∈ uIcc (0 : ℝ) 1,
      HasDerivAt (fun u => -exp (-(x * u)) / x) (exp (-(x * u)) * 1) u := by
    intro u _
    have := (((hasDerivAt_id' u).const_mul x).fun_neg.exp).fun_neg.div_const x
    convert this using 1; field_simp
  have hF1 : ∀ u ∈ uIcc (0 : ℝ) 1,
      HasDerivAt (fun u => -(u / x + 1 / x ^ 2) * exp (-(x * u))) (u * exp (-(x * u)) * 1) u := by
    intro u _
    have h1 : HasDerivAt (fun u => -(u / x + 1 / x ^ 2)) (-(1 / x)) u := by
      have := (((hasDerivAt_id' u).div_const x).add_const (1 / x ^ 2)).fun_neg
      simpa using this
    have := h1.fun_mul (((hasDerivAt_id' u).const_mul x).fun_neg.exp)
    convert this using 1; field_simp; ring
  have hψ : psi (fun _ => 1) x = (1 - exp (-x)) / x := by
    show ∫ u in (0 : ℝ)..1, exp (-(x * u)) * 1 = _
    rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hF0
      (by apply Continuous.intervalIntegrable; fun_prop)]
    simp only [mul_zero, neg_zero, exp_zero, mul_one]; ring
  have hψD : psiD (fun _ => 1) x = (1 - (1 + x) * exp (-x)) / x ^ 2 := by
    show ∫ u in (0 : ℝ)..1, u * exp (-(x * u)) * 1 = _
    rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hF1
      (by apply Continuous.intervalIntegrable; fun_prop)]
    simp only [mul_zero, neg_zero, exp_zero, mul_one, zero_div, zero_add]; field_simp; ring
  have hex : 1 < exp x := by have := add_one_lt_exp hx.ne'; linarith
  have h1 : 1 - (exp x)⁻¹ ≠ 0 := by
    have : (exp x)⁻¹ < 1 := inv_lt_one_of_one_lt₀ hex
    linarith
  rw [hψ, hψD, exp_neg]
  have : exp x - 1 ≠ 0 := by linarith
  field_simp
  ring

/-- **The three profile values at `x = 1` (line 1120)**, from the integral definitions:
rectangle `1/(e − 1) ≈ 0.58`, `g = 2u` gives `(3 − e)/(e − 2) ≈ 0.39`, `g = 2(1 − u)` gives
`e − 2 ≈ 0.72`; each within `0.005` of the printed two-decimal value. -/
theorem p4_profile_values :
    (1 + 1 * (-psiD (fun _ => 1) 1) / psi (fun _ => 1) 1 = exp (-1) / (1 - exp (-1)) ∧
      0.575 < exp (-1) / (1 - exp (-1)) ∧ exp (-1) / (1 - exp (-1)) < 0.585) ∧
    (1 + 1 * (-psiD (fun u => 2 * u) 1) / psi (fun u => 2 * u) 1
        = (3 * exp (-1) - 1) / (1 - 2 * exp (-1)) ∧
      0.385 < (3 * exp (-1) - 1) / (1 - 2 * exp (-1)) ∧
      (3 * exp (-1) - 1) / (1 - 2 * exp (-1)) < 0.395) ∧
    (1 + 1 * (-psiD (fun u => 2 * (1 - u)) 1) / psi (fun u => 2 * (1 - u)) 1
        = (1 - 2 * exp (-1)) / exp (-1) ∧
      0.715 < (1 - 2 * exp (-1)) / exp (-1) ∧ (1 - 2 * exp (-1)) / exp (-1) < 0.725) := by
  have lo := exp_neg_one_gt_d9
  have hi := exp_neg_one_lt_d9
  have I : ∀ (a b c : ℝ) (f : ℝ → ℝ), (∀ u, f u = (2 * a * u + b - (a * u ^ 2 + b * u + c)) *
      exp (-u)) → ∫ u in (0 : ℝ)..1, f u = (a + b + c) * exp (-1) - c := by
    intro a b c f hf
    have hfun : f = fun u => (2 * a * u + b - (a * u ^ 2 + b * u + c)) * exp (-u) := funext hf
    rw [hfun, intervalIntegral.integral_eq_sub_of_hasDerivAt
      (fun u _ => hasDerivAt_poly_exp a b c u) (by apply Continuous.intervalIntegrable; fun_prop)]
    simp
  have r0 : psi (fun _ => 1) 1 = 1 - exp (-1) := by
    rw [psi, I 0 0 (-1) _ (fun u => by simp)]; ring
  have r1 : psiD (fun _ => 1) 1 = 1 - 2 * exp (-1) := by
    rw [psiD, I 0 (-1) (-1) _ (fun u => by simp)]; ring
  have l0 : psi (fun u => 2 * u) 1 = 2 * (1 - 2 * exp (-1)) := by
    rw [psi, I 0 (-2) (-2) _ (fun u => by simp; ring)]; ring
  have l1 : psiD (fun u => 2 * u) 1 = 2 * (2 - 5 * exp (-1)) := by
    rw [psiD, I (-2) (-4) (-4) _ (fun u => by simp; ring)]; ring
  have d0 : psi (fun u => 2 * (1 - u)) 1 = 2 * exp (-1) := by
    rw [psi, I 0 2 0 _ (fun u => by simp; ring)]; ring
  have d1 : psiD (fun u => 2 * (1 - u)) 1 = 2 * (3 * exp (-1) - 1) := by
    rw [psiD, I 2 2 2 _ (fun u => by simp; ring)]; ring
  have n1 : 1 - exp (-1) ≠ 0 := by linarith
  have n2 : 1 - 2 * exp (-1) ≠ 0 := by linarith
  have n3 : exp (-1) ≠ 0 := (exp_pos _).ne'
  refine ⟨⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩⟩
  · rw [r0, r1]; field_simp; ring
  · rw [lt_div_iff₀ (by linarith)]; linarith
  · rw [div_lt_iff₀ (by linarith)]; linarith
  · rw [l0, l1]; field_simp; ring
  · rw [lt_div_iff₀ (by linarith)]; linarith
  · rw [div_lt_iff₀ (by linarith)]; linarith
  · rw [d0, d1]; field_simp; ring
  · rw [lt_div_iff₀ (by linarith)]; linarith
  · rw [div_lt_iff₀ (by linarith)]; linarith

/-- **P4(iii).** The far loss's present value `V_A C_A(s) e^{−rK_A/s}` has derivative
`V_A e^{−rT_A}[C_A′ + rC_A K_A/s²]`. -/
theorem p4_iii {CA : ℝ → ℝ} {CA' VA r KA s : ℝ} (hs : 0 < s) (ha : HasDerivAt CA CA' s) :
    HasDerivAt (fun x => VA * CA x * exp (-(r * (KA / x))))
      (VA * exp (-(r * (KA / s))) * (CA' + r * CA s * KA / s ^ 2)) s := by
  have he := ((hasDerivAt_K_div KA s hs.ne').const_mul r).fun_neg.exp
  have h := (ha.const_mul VA).fun_mul he
  convert h using 1
  field_simp

/-- **P4(iii), "acceleration also brings the far loss nearer".** The arrival date `K_A/s` falls
with speed, and in the derivative of the model's present value `V_A C_A(s) e^{−rK_A/s}` the
discounting term adds a strictly positive amount to the undiscounted part `V_A e^{−rT_A} C_A′`.
Content: algebraic, given `p4_iii`. -/
theorem p4_iii_nearer {CA : ℝ → ℝ} {CA' VA r KA s : ℝ} (hs : 0 < s) (hr : 0 < r)
    (hCA : 0 < CA s) (hKA : 0 < KA) (hVA : 0 < VA) (ha : HasDerivAt CA CA' s) :
    StrictAntiOn (fun x : ℝ => KA / x) (Ioi 0) ∧
    HasDerivAt (fun x => VA * CA x * exp (-(r * (KA / x))))
      (VA * exp (-(r * (KA / s))) * (CA' + r * CA s * KA / s ^ 2)) s ∧
    VA * exp (-(r * (KA / s))) * CA' <
      VA * exp (-(r * (KA / s))) * (CA' + r * CA s * KA / s ^ 2) := by
  refine ⟨fun x hx y _ hxy => div_lt_div_of_pos_left hKA hx hxy, p4_iii hs ha, ?_⟩
  have : 0 < r * CA s * KA / s ^ 2 := by positivity
  have : 0 < VA * exp (-(r * (KA / s))) := by positivity
  nlinarith

/-- **P4(iv).** Total catastrophe probability `1 − (1 − P_c)(1 − P_A)`: its derivative, and the
iff. Content: algebraic (product rule and rearrangement). -/
theorem p4_iv {Pc PA : ℝ → ℝ} {Pc' PA' s : ℝ} (hc : HasDerivAt Pc Pc' s)
    (ha : HasDerivAt PA PA' s) :
    HasDerivAt (fun x => 1 - (1 - Pc x) * (1 - PA x)) (Pc' * (1 - PA s) + PA' * (1 - Pc s)) s ∧
      (Pc' * (1 - PA s) + PA' * (1 - Pc s) < 0 ↔ PA' * (1 - Pc s) < -Pc' * (1 - PA s)) := by
  refine ⟨?_, by constructor <;> intro h <;> linarith⟩
  have := ((hc.const_sub 1).fun_mul (ha.const_sub 1)).const_sub 1
  convert this using 1; ring

/-- **P4(iv), the probability identity, derived.** With `E_c` the near catastrophe, `E_A` the far
one, and `P_A = μ(E_A ∩ E_cᶜ)/μ(E_cᶜ)` the probability of the far catastrophe conditional on
surviving the near one, the probability of at least one catastrophe is `1 − (1 − P_c)(1 − P_A)`. -/
theorem p4_iv_total_prob {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {Ec Ea : Set Ω} (hc : MeasurableSet Ec) (ha : MeasurableSet Ea) (hpos : 0 < μ.real Ecᶜ) :
    μ.real (Ec ∪ Ea) = 1 - (1 - μ.real Ec) * (1 - μ.real (Ea ∩ Ecᶜ) / μ.real Ecᶜ) := by
  have hU : Ec ∪ Ea = Ec ∪ (Ea ∩ Ecᶜ) := by
    ext ω; by_cases h : ω ∈ Ec <;> simp [h]
  have hdisj : Disjoint Ec (Ea ∩ Ecᶜ) :=
    Set.disjoint_left.mpr fun ω h1 h2 => h2.2 h1
  rw [hU, measureReal_union hdisj (ha.inter hc.compl)]
  have hcomp : μ.real Ecᶜ = 1 - μ.real Ec := probReal_compl_eq_one_sub hc
  rw [hcomp] at hpos ⊢
  field_simp
  ring

/-- **Gap: the comparison with one needs `g ≥ 0`, sharpened.** For `g(u) = 5 − 8u` (`∫ g = 1`,
negative near `u = 1`) there is an `x > 0` at which the threshold `1 + xψ′(x)/ψ(x)` exceeds one,
so "below one for every profile" fails without `g ≥ 0`. -/
theorem p4_profile_threshold_gt_one_example :
    ∃ x > 0, 1 < 1 + x * (-psiD (fun u => 5 - 8 * u) x) / psi (fun u => 5 - 8 * u) x := by
  set g : ℝ → ℝ := fun u => 5 - 8 * u with hgdef
  set g2 : ℝ → ℝ := fun u => u * (5 - 8 * u) with hg2def
  have hgi : IntervalIntegrable g volume 0 1 := by
    apply Continuous.intervalIntegrable; fun_prop
  have hg2i : IntervalIntegrable g2 volume 0 1 := by
    apply Continuous.intervalIntegrable; fun_prop
  have hD : psiD g = psi g2 := by
    ext x; unfold psiD psi; congr 1; ext u; simp only [hgdef, hg2def]; ring
  have h0 : psi g2 0 = -1 / 6 := by
    unfold psi
    simp only [zero_mul, neg_zero, exp_zero, one_mul, hg2def]
    have : (fun u : ℝ => u * (5 - 8 * u)) = fun u => 5 * u - 8 * u ^ 2 := by ext u; ring
    rw [this, intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
      (by apply Continuous.intervalIntegrable; fun_prop), intervalIntegral.integral_const_mul,
      intervalIntegral.integral_const_mul, integral_id, integral_pow]
    norm_num
  have h1 : psi g 0 = 1 := by
    unfold psi
    simp only [zero_mul, neg_zero, exp_zero, one_mul, hgdef]
    rw [intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
      (by apply Continuous.intervalIntegrable; fun_prop), intervalIntegral.integral_const,
      intervalIntegral.integral_const_mul, integral_id, smul_eq_mul]
    norm_num
  have e2 : ∀ᶠ x in 𝓝 (0 : ℝ), psi g2 x < 0 :=
    (hasDerivAt_psi hg2i 0).continuousAt.eventually
      (gt_mem_nhds (show psi g2 0 < 0 by rw [h0]; norm_num))
  have e1 : ∀ᶠ x in 𝓝 (0 : ℝ), 0 < psi g x :=
    (hasDerivAt_psi hgi 0).continuousAt.eventually
      (lt_mem_nhds (show (0 : ℝ) < psi g 0 by rw [h1]; norm_num))
  obtain ⟨x, ⟨hx2, hx1⟩, hx0⟩ :=
    (((e2.and e1).filter_mono nhdsWithin_le_nhds).and (self_mem_nhdsWithin (s := Ioi (0 : ℝ))
      (a := 0))).exists
  refine ⟨x, hx0, ?_⟩
  rw [hD]
  have : 0 < x * -psi g2 x / psi g x := div_pos (mul_pos hx0 (by linarith)) hx1
  linarith

/-- The hazard of P4's discrete counterexample (line 1120). -/
noncomputable def Hd (s : ℝ) : ℝ := if s ≤ 2 then s ^ (1.5 : ℝ) else 2 ^ (1.5 : ℝ) + 0.01 * (s - 2)

/-- Total loss of the counterexample: `R_c + R_A` with `K = 20`, `T_a = 1`, `S = 0`,
`R_A = 0.01 s`, unit stakes. -/
noncomputable def totalD (s : ℝ) : ℝ := Rc Hd 20 1 0 s + 0.01 * s

theorem two_rpow_15 : (2 : ℝ) ^ (1.5 : ℝ) = 2 * √2 := by
  rw [show (1.5 : ℝ) = 1 / 2 + 1 by norm_num, rpow_add_one two_ne_zero, ← sqrt_eq_rpow]; ring

/-- **P4, the discrete counterexample (line 917, proof line 1120).** At `s = 1` the near-loss
derivative is `10 > 0` (so the test of (i), which needs `C_c′ < 0`, fails) and the total
derivative is `10.01 > 0`; yet moving from `s = 1` to `s = 10` cuts the total loss from `20.01`
(printed `20.0`) to `4√2 + 0.26 ∈ (5.85, 5.95)` (printed `5.9`). `H′` jumps at `s = 2` from
`1.5√2 ∈ (2.115, 2.125)` (printed `2.12`) to `0.01`, so `H` is not differentiable there. -/
theorem p4_discrete_counterexample :
    HasDerivAt (Rc Hd 20 1 0) 10 1 ∧ HasDerivAt totalD 10.01 1 ∧
    totalD 1 = 20.01 ∧ totalD 10 = 4 * √2 + 0.26 ∧ 5.85 < totalD 10 ∧ totalD 10 < 5.95 ∧
    HasDerivWithinAt Hd (1.5 * √2) (Iic 2) 2 ∧ HasDerivWithinAt Hd 0.01 (Ici 2) 2 ∧
    2.115 < 1.5 * √2 ∧ 1.5 * √2 < 2.125 ∧ ¬ DifferentiableAt ℝ Hd 2 := by
  have s2lo : (1.414 : ℝ) < √2 := (lt_sqrt (by norm_num)).mpr (by norm_num)
  have s2hi : √2 < (1.4143 : ℝ) := (sqrt_lt' (by norm_num)).mpr (by norm_num)
  have hnear : HasDerivAt (Rc Hd 20 1 0) 10 1 := by
    have hr := hasDerivAt_rpow_const (x := (1 : ℝ)) (p := 1.5) (Or.inl one_ne_zero)
    have h := (hr.mul (hasDerivAt_K_div 20 1 one_ne_zero)).add_const 0
    have hev : (fun x : ℝ => x ^ (1.5 : ℝ) * (20 / x) + 0) =ᶠ[𝓝 1] Rc Hd 20 1 0 := by
      filter_upwards [isOpen_Ioo.mem_nhds (show (1 : ℝ) ∈ Ioo 0 2 by norm_num)] with x hx
      have hx2 : x ≤ 2 := hx.2.le
      simp only [Rc, Hd, if_pos hx2, max_cap one_pos hx.1 (by linarith : x ≤ 20 / 1)]
    convert h.congr_of_eventuallyEq hev.symm using 1
    simp; norm_num
  have hb : HasDerivWithinAt Hd (1.5 * √2) (Iic 2) 2 := by
    have hr := hasDerivAt_rpow_const (x := (2 : ℝ)) (p := 1.5) (Or.inl two_ne_zero)
    have e : (1.5 : ℝ) * (2 : ℝ) ^ ((1.5 : ℝ) - 1) = 1.5 * √2 := by
      rw [show (1.5 : ℝ) - 1 = 1 / 2 by norm_num, ← sqrt_eq_rpow]
    rw [e] at hr
    apply hr.hasDerivWithinAt.congr
    · intro y hy; simp [Hd, show y ≤ 2 from hy]
    · simp [Hd]
  have ha : HasDerivWithinAt Hd 0.01 (Ici 2) 2 := by
    have hl : HasDerivAt (fun y : ℝ => 2 ^ (1.5 : ℝ) + 0.01 * (y - 2)) 0.01 2 := by
      have := (((hasDerivAt_id (2 : ℝ)).sub_const 2).const_mul (0.01 : ℝ)).const_add
        ((2 : ℝ) ^ (1.5 : ℝ))
      simpa using this
    apply hl.hasDerivWithinAt.congr
    · intro y hy
      rcases eq_or_lt_of_le (show (2 : ℝ) ≤ y from hy) with h | h
      · subst h; simp [Hd]
      · simp [Hd, not_le.mpr h]
    · simp [Hd]
  refine ⟨hnear, ?_, ?_, ?_, ?_, ?_, hb, ha, by nlinarith, by nlinarith, ?_⟩
  · have := hnear.fun_add ((hasDerivAt_id' (1 : ℝ)).const_mul (0.01 : ℝ))
    show HasDerivAt (fun s => Rc Hd 20 1 0 s + 0.01 * s) 10.01 1
    convert this using 1; norm_num
  · simp [totalD, Rc, Hd]; norm_num
  · simp only [totalD, Rc, Hd, show ¬ ((10 : ℝ) ≤ 2) by norm_num, if_false, two_rpow_15]
    rw [max_eq_left (by norm_num)]; ring
  · simp only [totalD, Rc, Hd, show ¬ ((10 : ℝ) ≤ 2) by norm_num, if_false, two_rpow_15]
    rw [max_eq_left (by norm_num)]; nlinarith
  · simp only [totalD, Rc, Hd, show ¬ ((10 : ℝ) ≤ 2) by norm_num, if_false, two_rpow_15]
    rw [max_eq_left (by norm_num)]; nlinarith
  · intro hd
    have h1 := (uniqueDiffWithinAt_Iic (2 : ℝ)).eq_deriv _ hd.hasDerivAt.hasDerivWithinAt hb
    have h2 := (uniqueDiffWithinAt_Ici (2 : ℝ)).eq_deriv _ hd.hasDerivAt.hasDerivWithinAt ha
    rw [h1] at h2
    nlinarith

/-- The smooth hazard of `p4_discrete_smooth`. -/
noncomputable def Hsm (s : ℝ) : ℝ := s ^ 3 / (1 + s ^ 3)

noncomputable def Hsm' (s : ℝ) : ℝ := 3 * s ^ 2 / (1 + s ^ 3) ^ 2

/-- **P4 remark within A4 (lines 166, 917).** The appendix's discrete counterexample violates A4
at `s = 2`. The body's claim — "a large, discrete acceleration can cut the total loss where the
derivative test fails" — also holds for a hazard satisfying A4 everywhere: `H = s³/(1 + s³)`,
`K = 20`, `T_a = 1`, `s_min = 1`, `R_A = 0.01 s`. At `s = 1` the near-loss derivative is `5 > 0`,
yet the total loss falls from `10.01` at `s = 1` to below `2.1` at `s = 10`. -/
theorem p4_discrete_smooth :
    A4 Hsm Hsm' 1 ∧ HasDerivAt (Rc Hsm 20 1 0) 5 1 ∧
    Rc Hsm 20 1 0 1 + 0.01 * 1 = 10.01 ∧ Rc Hsm 20 1 0 10 + 0.01 * 10 < 2.1 := by
  have hd : ∀ s : ℝ, 0 ≤ s → HasDerivAt Hsm (Hsm' s) s := by
    intro s hs
    have h1 : (1 : ℝ) + s ^ 3 ≠ 0 := by positivity
    have := ((hasDerivAt_id' s).fun_pow 3).div (((hasDerivAt_id' s).fun_pow 3).const_add 1) h1
    unfold Hsm Hsm'
    convert this using 1
    field_simp; ring
  refine ⟨⟨fun s hs => ?_, fun s hs => (hd s (by linarith [mem_Ici.mp hs])).hasDerivWithinAt,
    fun s hs => ?_⟩, ?_, ?_, ?_⟩
  · have : (1 : ℝ) ≤ s := hs
    unfold Hsm; positivity
  · have : (1 : ℝ) ≤ s := hs
    unfold Hsm'; positivity
  · have h := ((hd 1 zero_le_one).fun_mul (hasDerivAt_K_div 20 1 one_ne_zero)).add_const 0
    have hev : (fun x : ℝ => Hsm x * (20 / x) + 0) =ᶠ[𝓝 1] Rc Hsm 20 1 0 := by
      filter_upwards [isOpen_Ioo.mem_nhds (show (1 : ℝ) ∈ Ioo 0 2 by norm_num)] with x hx
      simp only [Rc, max_cap one_pos hx.1 (by linarith [hx.2] : x ≤ 20 / 1)]
    convert h.congr_of_eventuallyEq hev.symm using 1
    simp [Hsm, Hsm']; norm_num
  · simp [Rc, Hsm]; norm_num
  · simp only [Rc, Hsm]
    rw [max_eq_left (by norm_num)]; norm_num

end P4

/-- **P5, "the escape … can occur while `s*` falls" (line 923).** `K = 1`, `A = 2`, `s₀ = 1`
(so `K < As₀` and `s*` falls with `β`), `β = 1/2`, `H = s^{1/4}` (`ε_H = 1/4 < β`): at `s = 1`
adoption binds and acceleration lowers `R_c`. -/
theorem p5_escape_while_kink_falls :
    StrictAntiOn (kinkP 1 2 1) (Iio 1) ∧ (1 : ℝ) / 1 < TaP 2 1 (1 / 2) 1 ∧
    deriv (RcT (fun x : ℝ => x ^ (1 / 4 : ℝ)) 1 (TaP 2 1 (1 / 2)) 0) 1 < 0 := by
  have hb : (1 : ℝ) / 1 < TaP 2 1 (1 / 2) 1 := by simp [TaP]
  refine ⟨p5_kink_strictAnti one_pos two_pos one_pos (by norm_num), hb, ?_⟩
  have hH := hasDerivAt_rpow_const (x := (1 : ℝ)) (p := 1 / 4) (Or.inl one_ne_zero)
  rw [p5_iii_lowers_iff two_pos one_pos one_pos hH (by simp) hb]
  simp; norm_num

/-! ## Axiom audit: one line per theorem -/

#print axioms hasDerivAt_K_div
#print axioms max_cap
#print axioms max_adopt
#print axioms A4.hasDerivAt
#print axioms A4.continuousOn
#print axioms rc_eventually_cap
#print axioms rc_eventually_adopt
#print axioms p1_deriv_below_kink
#print axioms p1_lowers_iff_below_kink
#print axioms p1_deriv_above_kink
#print axioms p1_left_deriv_at_kink
#print axioms p1_right_deriv_at_kink
#print axioms rc_continuousOn
#print axioms A4.strictMonoOn
#print axioms rc_strictMonoOn_adopt
#print axioms p1_exists_min
#print axioms p1_min_le_kink
#print axioms p1_kink_unique_min
#print axioms p1_min_trichotomy
#print axioms p1_isolated_sign
#print axioms rc_mono_cap
#print axioms p1_local_min_crossing
#print axioms p1_crossing_from_above_max
#print axioms rpow14
#print axioms p1_no_min_without_lower_bound
#print axioms hasDerivAt_posPart_sq
#print axioms hasDerivAt_negPart_sq
#print axioms hasDerivAt_qEx
#print axioms p1_flat_example
#print axioms p1_body_rising_not_enough
#print axioms hasDerivAt_fOsc
#print axioms fOsc_nonneg
#print axioms fOsc_pos
#print axioms fOsc'_lower
#print axioms p1_oscillation_example
#print axioms p2_indep_of_speed
#print axioms p2_falls_with_N
#print axioms p2_falls_with_psi
#print axioms p2_falls_with_d
#print axioms p2_halve_d
#print axioms p2_halve_psi
#print axioms p2_first_stated_false
#print axioms p2_tools_speed_dependence
#print axioms TaP_pos
#print axioms log_TaP
#print axioms log_ratio
#print axioms p5_adopt_iff
#print axioms p5_cap_iff
#print axioms kinkP_pos
#print axioms log_kinkP
#print axioms p5_kink
#print axioms p5_order_lt_one
#print axioms p5_order_gt_one
#print axioms p5_beta_one
#print axioms kinkP_exp
#print axioms p5_kink_deriv
#print axioms log_ratio_pos_iff
#print axioms log_ratio_neg_iff
#print axioms p5_kink_deriv_pos_iff
#print axioms one_div_one_sub_strictMonoOn
#print axioms p5_kink_strictMono
#print axioms p5_kink_strictAnti
#print axioms p5_kink_rises_iff
#print axioms p5_counterexample
#print axioms p5_a14_reading
#print axioms hasDerivAt_TaP
#print axioms p5_iv_adopt_deriv
#print axioms p5_iii_adopt_deriv
#print axioms p5_iii_lowers_iff
#print axioms p5_iii_elast_Ta
#print axioms p5_iii_cap_deriv
#print axioms p5_beta_zero
#print axioms p5_iv_unbounded_branch
#print axioms p5_body_step_term
#print axioms p4_i
#print axioms p4_i_above_kink
#print axioms integral_rect
#print axioms p4_ii_closed
#print axioms p4_ii_deriv
#print axioms p4_ii_lowers_iff
#print axioms p4_ii_threshold_lt_one
#print axioms p4_ii_steps_earlier
#print axioms hasDerivAt_psi
#print axioms psi_pos
#print axioms psiD_pos
#print axioms integral_profile
#print axioms p4_profile_closed
#print axioms p4_profile_deriv
#print axioms p4_profile_lowers_iff
#print axioms p4_profile_threshold_lt_one
#print axioms p4_profile_needs_nonneg
#print axioms hasDerivAt_poly_exp
#print axioms p4_rect_threshold
#print axioms p4_profile_values
#print axioms p4_iii
#print axioms p4_iii_nearer
#print axioms p4_iv
#print axioms p4_iv_total_prob
#print axioms p4_profile_threshold_gt_one_example
#print axioms two_rpow_15
#print axioms p4_discrete_counterexample
#print axioms p4_discrete_smooth
#print axioms p5_escape_while_kink_falls
-- Fix round 1 additions
#print axioms p1_deriv_at_smin
#print axioms p1_lowers_iff_at_smin
#print axioms qEx_ge_one
#print axioms p1_flat_no_strict_crossing
#print axioms p1_body_rising_level
#print axioms p1_oscillation_model
#print axioms p5_cap_at_ref_iff
#print axioms p5_first_stated_false
#print axioms p5_first_stated_beta_gt_one
#print axioms p4_ii_threshold_gt_one_of_neg
#print axioms p4_ii_steps_earlier_below_kink
-- Fix round 2 additions
#print axioms p4_ii_deriv_at_smin
#print axioms p4_ii_lowers_iff_at_smin
#print axioms p4_profile_deriv_at_smin
#print axioms p4_profile_lowers_iff_at_smin

end RTTR.Speed
