import Mathlib

/-!
# GAP3 — data arithmetic, the binomial calculation, numeric captions, missing inputs

Seat GAP3 for "Running Through the Rain", `PAPER-DRAFT-v8.md`. Standalone: imports Mathlib only.

## Modelling choices (how each paper object is represented, and why that is faithful)

* **Data ratios (B89, B91, B92, B165, B166, B167).** Each printed share is a ratio of two counts the
  paper prints. We state the ratio in `ℚ` and prove that it lies in the half-open rounding interval
  of the printed value, `v − ½u ≤ 100·a/b < v + ½u`, where `u` is the printed unit (1 point for
  "19%", 0.1 point for "35.2%"). That is the exact content of "`a` of `b`, or `v`%". Where the paper
  prints sums or partitions (839 and 648 usable entries; 125 of 659 split by year), we prove them.
  These are rearrangements of the paper's own printed counts; their content is arithmetic, and they
  certify the printed rounding, not the counts themselves (which come from CISA's file and the
  dashboard and cannot be checked here).
* **B87 (repeats among 181 successes).** The successful attempts are `Fin 181`; the bugs live in an
  arbitrary type `Bug`; the reports are a finset `R` of an arbitrary type with `R.card ≤ 112`, and
  `rep : Report → Bug` sends a report to the one bug it represents. The paper's inference needs two
  premises it does not state: every success targets a bug that some report represents, and each
  report represents a single bug. Under them, pigeonhole gives two distinct successes on the same
  bug (`b87_repeats`). Without the second premise the conclusion does not follow from 181 > 112:
  `b87_needs_one_bug_per_report` builds 112 reports, each covering at most two of 181 distinct
  bugs, that together cover every success, with no two successes on the same bug.
* **B168 (the conditional binomial calculation).** "If the share were a fixed 19.0% (125 of 659)
  with independent entries", the number of memory-corruption entries among `n` usable entries is
  `ProbabilityTheory.binomial n p` with `p = 125/659`. Mathlib *defines* this measure as the law of
  the number of successes among `n` independent Bernoulli(`p`) trials (`setBer(Iio n, p).map ncard`),
  which is exactly the paper's premise; we do not take the binomial formula as the definition. The
  event "a year's share exceeds 23.0%" is the strict event `{k | 23/100 < k/n}`. We prove
  `binomial_real_eq_sum` (the measure of an event is the finite sum of the binomial weights over
  `k ≤ n` in it), reduce each tail to an exact natural-number ratio `N/659ⁿ`, and decide the
  resulting inequalities between natural numbers by kernel reduction (`decide +kernel`: kernel
  evaluation only, no `native_decide`, no extra axioms). Every value is therefore exact.
* **C11 (the (C3) illustrative case).** Inputs recovered from `check_benefits.py` lines 463–470
  (`K = T_a = 1`, parallel cyber timing, `h(c) = c`, `V_c = 1`, `s = 0.1`, `r = 1`). The cyber loss
  is defined as the paper defines it (line 1329; undiscounted analogue from A.7/(C2)), with the
  integral and the `max` clock kept in the definition; we prove its closed form on the capability
  branch `0 < s < 1` and take `HasDerivAt` of the defined function at `s = 0.1` through eventual
  equality. The balance keeps the benefit term, as A15 requires `y > 0`: the code's benefit clock
  is `K_B = T_b = 1`, parallel, so `t_B(s) = max(1/s, 1)`, counted to the code's horizon `L = 50`
  (undiscounted `B_L = y(L − t_B)⁺`, line 1025; discounted `y∫_{t_B}^{L} e^{−rt}dt`, defined as
  the integral). We prove `s·W′` for every `y` (`5 + 10y` and `−1/10 + (111/10 + 10y)e^{−10}`)
  and then at the code's `y = 10⁻²⁰` (`c11_code_case`): `5 + 10⁻¹⁹`, which the paper prints as 5.
  `e^{−10}` is enclosed with Mathlib's nine-digit bounds on `e`.
* **P11's interior example (A101, P40).** `Φ̃(g)` is the expression of the paper's proof of (v)
  (line 1134) with `Π(x) = Mx^η/(r + ηκ_post)`, at A.6's inputs (line 1109); `phiEx_eq_rpow` shows
  it is, symbol for symbol, the right side of `RTTR.Release.Phi_power` (L5, cited, not imported).
  We prove that every crossing with lead in `[0, g₀]` lies in `(0, 0.01)`, that exactly one exists
  (`phiEx_root_unique`), that it is simple and downward in `T`, and that along the lead path
  `g(T) = g₀e^{−κ_pre T}` `Φ̃` is positive before the crossing date `T*` and negative after it, with
  `T* > 2 ln 20` (`phiEx_path_single_crossing`): these are the hypotheses `hpos`, `hneg` of
  `RTTR.Release.p11i_global`, so `T*` is the strict global optimum. This pins `J(T*)` to
  `(1.8257, 1.8560)` and fixes the sign
  of every artifact term the paper and the code use. The step from "the sign of `∂Φ̃/∂θ`" to "the
  sign of `dT*/dθ`" is L5's `comp_statics` (IFT, given a differentiable selection of crossings);
  we do not re-prove it. A101's `λ′ = 0.75` and P40's four `(λ′, Z)` cases are the code's
  (`check_model.py` lines 1223–1256), not chosen by us.
* **B90 (class-order robustness).** The six-order count table is data printed by
  `PEAKS-PAPER/M8/kev_v5.py` from the saved catalogue (version 2026.10.21); Lean proves the paper's
  arithmetic claim about that table, not the counts.

* **P24 / B111(b), the full-coalition corner.** `B(n) = (1 − π)Σ_j c_j w_j m(λ(n), τ_j)` (line 949)
  with one operator, `c = n`, `λ = 1 + 0.01n` on `[0, 1]`. L3's `Hold.p8_corner_full` fixes weight 1
  and `π = 0`; here `m` is restated (same definition as L3's) and the corner is proved for every
  `π < 1`, weight `w > 0` and `τ > 0` (`p24_corner_full_general`). At `π = 1`, `B ≡ 0` and does not
  rise (`p24_corner_full_needs_pi`), so `π < 1` is a needed hypothesis the example does not state.
  So are `w > 0` and `τ > 0`: the paper allows zero weights (line 84), and at `w = 0` or `τ = 0`,
  `B ≡ 0` (`p24_corner_full_needs_w`, `p24_corner_full_needs_tau`).
* **P19's duration.** L3's `Hold.p7_shift_discount` needs a positive exposure duration; with zero
  duration both discounted exposures are 0 and nothing falls (`p19_needs_positive_duration`).

Rows covered by other seats' files (A28, the P3 `e^t` example, P19, P24/B109/A66/B111, P47) are
cited in `GAP3-ROWS.md` and are not restated here, except the two extensions above.
-/

namespace RTTR.Gaps3

open ProbabilityTheory MeasureTheory

/-! ## 1. Data arithmetic -/

/-- **B89** (line 272): access-policy share 19% (171 of 920) → 27% (180 of 659); memory-corruption
share 33% (299 of 920) → 19% (125 of 659). The 299/920 share is exactly 32.5%, a rounding tie:
"33%" is correct under round-half-up, and would be "32%" under round-half-even. -/
theorem b89_kev_shares :
    ((37:ℚ)/2 ≤ 100 * 171 / 920 ∧ (100:ℚ) * 171 / 920 < 39/2) ∧
    ((53:ℚ)/2 ≤ 100 * 180 / 659 ∧ (100:ℚ) * 180 / 659 < 55/2) ∧
    ((100:ℚ) * 299 / 920 = 65/2) ∧
    ((37:ℚ)/2 ≤ 100 * 125 / 659 ∧ (100:ℚ) * 125 / 659 < 39/2) := by
  norm_num

/-- **B91** (line 272): excluding CWE-20 leaves 839 and 648 usable entries, split 299, 287, 171, 82
and 125, 284, 180, 59; access policy 20% → 28%, memory corruption 36% → 19%. Also the implied
CWE-20 counts (920 − 839 = 81 earlier, 659 − 648 = 11 later) all fall in injection-and-input and
"other", since the memory-corruption and access-policy counts are unchanged from B89. -/
theorem b91_cwe20_check :
    (299 + 287 + 171 + 82 = 839 ∧ 125 + 284 + 180 + 59 = 648) ∧
    ((39:ℚ)/2 ≤ 100 * 171 / 839 ∧ (100:ℚ) * 171 / 839 < 41/2) ∧
    ((55:ℚ)/2 ≤ 100 * 180 / 648 ∧ (100:ℚ) * 180 / 648 < 57/2) ∧
    ((71:ℚ)/2 ≤ 100 * 299 / 839 ∧ (100:ℚ) * 299 / 839 < 73/2) ∧
    ((37:ℚ)/2 ≤ 100 * 125 / 648 ∧ (100:ℚ) * 125 / 648 < 39/2) ∧
    (920 - 839 = 81 ∧ 659 - 648 = 11 ∧ (920 - 299 - 171) - (287 + 82) = 81 ∧
      (659 - 125 - 180) - (284 + 59) = 11) := by
  norm_num

/-- **B92** (line 272): entries listed in their CVE year or the next: memory corruption 35.2%
(160 of 454) → 19.7% (105 of 532); access policy 19.8% (90 of 454) → 28.0% (149 of 532). -/
theorem b92_same_year_check :
    ((703:ℚ)/20 ≤ 100 * 160 / 454 ∧ (100:ℚ) * 160 / 454 < 705/20) ∧
    ((393:ℚ)/20 ≤ 100 * 105 / 532 ∧ (100:ℚ) * 105 / 532 < 395/20) ∧
    ((395:ℚ)/20 ≤ 100 * 90 / 454 ∧ (100:ℚ) * 90 / 454 < 397/20) ∧
    ((559:ℚ)/20 ≤ 100 * 149 / 532 ∧ (100:ℚ) * 149 / 532 < 561/20) := by
  norm_num

/-- **B165** (lines 510, 514): 516 of 6,157 is 8.4%. -/
theorem b165_patched_ratio :
    (167:ℚ)/20 ≤ 100 * 516 / 6157 ∧ (100:ℚ) * 516 / 6157 < 169/20 := by
  norm_num

/-- **B166** (line 511): 381 of 555 is 68.6%. -/
theorem b166_batch_ratio :
    (1371:ℚ)/20 ≤ 100 * 381 / 555 ∧ (100:ℚ) * 381 / 555 < 1373/20 := by
  norm_num

/-- **B167** (line 512): yearly memory-corruption shares 20.2% (36 of 178), 22.3% (49 of 220),
15.3% (40 of 261), each below the 23.0% cut; the years partition the baseline window used in
B168: `36 + 49 + 40 = 125` and `178 + 220 + 261 = 659`; and B168's "a fixed 19.0% (125 of 659)"
rounds as printed to 0.1 point. -/
theorem b167_yearly_shares :
    ((403:ℚ)/20 ≤ 100 * 36 / 178 ∧ (100:ℚ) * 36 / 178 < 405/20) ∧
    ((445:ℚ)/20 ≤ 100 * 49 / 220 ∧ (100:ℚ) * 49 / 220 < 447/20) ∧
    ((305:ℚ)/20 ≤ 100 * 40 / 261 ∧ (100:ℚ) * 40 / 261 < 307/20) ∧
    ((100:ℚ) * 36 / 178 < 23 ∧ (100:ℚ) * 49 / 220 < 23 ∧ (100:ℚ) * 40 / 261 < 23) ∧
    (36 + 49 + 40 = 125 ∧ 178 + 220 + 261 = 659) ∧
    ((379:ℚ)/20 ≤ 100 * 125 / 659 ∧ (100:ℚ) * 125 / 659 < 381/20) := by
  norm_num

/-- **B87** (line 239), under the two premises the paper leaves unstated: each of the 181
successful attempts targets a bug that one of the reports represents, and each report represents
one bug (`rep`). With at most 112 reports, two distinct successes target the same bug. -/
theorem b87_repeats {Bug Report : Type*} [DecidableEq Bug] (R : Finset Report) (hR : R.card ≤ 112)
    (rep : Report → Bug) (target : Fin 181 → Bug) (hin : ∀ i, target i ∈ R.image rep) :
    ∃ i j : Fin 181, i ≠ j ∧ target i = target j := by
  have hlt : (R.image rep).card < (Finset.univ : Finset (Fin 181)).card := by
    have := Finset.card_image_le (s := R) (f := rep)
    simp only [Finset.card_univ, Fintype.card_fin]
    omega
  obtain ⟨i, -, j, -, hij, h⟩ :=
    Finset.exists_ne_map_eq_of_card_lt_of_maps_to hlt (fun i _ => hin i)
  exact ⟨i, j, hij, h⟩

/-- **B87, the premise matters**: 181 > 112 alone does not force a repeat. Take the bugs to be
`Fin 181` and each success's target to be its own bug (`target = id`, injective: no repeats). If a
report may cover two bugs, 112 reports `cov r`, each covering at most two bugs, cover every
success's bug. This is `b87_repeats`'s setting with "one bug per report" replaced by "at most two",
and its conclusion fails. -/
theorem b87_needs_one_bug_per_report :
    ∃ cov : Fin 112 → Finset (Fin 181), (∀ r, (cov r).card ≤ 2) ∧ (∀ i, ∃ r, i ∈ cov r) ∧
      Function.Injective (id : Fin 181 → Fin 181) := by
  refine ⟨fun r => Finset.univ.filter (fun i : Fin 181 => i.val / 2 = r.val), ?_, ?_,
    Function.injective_id⟩
  · decide +kernel
  · intro i
    have := i.isLt
    exact ⟨⟨i.val / 2, by omega⟩, by simp⟩

/-! ## 2. B168: the conditional binomial calculation -/

/-- The fixed share `125/659` as a point of the unit interval. -/
noncomputable def pMC : unitInterval := ⟨125 / 659, by constructor <;> norm_num⟩

/-- Probability, under the binomial law of `n` independent entries with fixed share `p`, that the
year's share `k/n` strictly exceeds `c`. -/
noncomputable def shareExceeds (n : ℕ) (p : unitInterval) (c : ℝ) : ℝ :=
  (binomial n p).real {k : ℕ | c < (k : ℝ) / n}

/-- The measure of any event under `Bin(n, p)` is the sum of the binomial weights over the
`k ≤ n` in the event. -/
theorem binomial_real_eq_sum (n : ℕ) (p : unitInterval) (S : Set ℕ) [DecidablePred (· ∈ S)] :
    (binomial n p).real S =
      ∑ k ∈ (Finset.Iic n).filter (· ∈ S), (n.choose k : ℝ) * (p : ℝ) ^ k * (1 - (p : ℝ)) ^ (n - k) := by
  rw [measureReal_def, binomial_eq_sum_dirac, Measure.coe_finsetSum, Finset.sum_apply,
    Finset.sum_filter, ENNReal.toReal_sum]
  · refine Finset.sum_congr rfl fun k _ => ?_
    rw [Measure.smul_apply, Measure.dirac_apply, smul_eq_mul]
    by_cases hk : k ∈ S
    · simp [hk, binomial_nonneg]
    · simp [hk]
  · intro k _
    rw [Measure.smul_apply, Measure.dirac_apply, smul_eq_mul]
    by_cases hk : k ∈ S <;> simp [hk]

/-- The strict cut `num/den < k/n` on `k ≤ n` is the integer range `k ≥ ⌊num·n/den⌋ + 1`. -/
theorem filter_cut (n num den : ℕ) (hn : 0 < n) (hden : 0 < den) :
    (Finset.Iic n).filter (fun k : ℕ => ((num : ℝ) / den) < (k : ℝ) / n) =
      Finset.Ico (num * n / den + 1) (n + 1) := by
  ext k
  simp only [Finset.mem_filter, Finset.mem_Iic, Finset.mem_Ico]
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  have hd' : (0 : ℝ) < den := by exact_mod_cast hden
  rw [div_lt_div_iff₀ hd' hn']
  have : ((num : ℝ) * n < k * den) ↔ num * n < k * den := by norm_cast
  rw [this, ← Nat.div_lt_iff_lt_mul hden]
  omega

/-- Factorial-form binomial coefficient (kernel-friendly; equals `Nat.choose` for `k ≤ n`). -/
def chooseF (n k : ℕ) : ℕ := n.factorial / (k.factorial * (n - k).factorial)

/-- The numerator `Σ_{kmin ≤ k ≤ n} C(n,k)·a^k·b^(n−k)` of an exact binomial tail. -/
def tailNum (a b n kmin : ℕ) : ℕ :=
  ∑ k ∈ Finset.Ico kmin (n + 1), chooseF n k * a ^ k * b ^ (n - k)

/-- With `p = 125/659`, the tail sum over `k ≥ kmin` is `tailNum 125 534 n kmin / 659ⁿ`. -/
theorem tail_sum_eq (n kmin : ℕ) :
    ∑ k ∈ Finset.Ico kmin (n + 1), (n.choose k : ℝ) * ((125 : ℝ) / 659) ^ k * (1 - 125 / 659) ^ (n - k)
      = (tailNum 125 534 n kmin : ℝ) / 659 ^ n := by
  unfold tailNum
  push_cast
  rw [Finset.sum_div]
  refine Finset.sum_congr rfl fun k hk => ?_
  have hkn : k ≤ n := by simp only [Finset.mem_Ico] at hk; omega
  rw [chooseF, ← Nat.choose_eq_factorial_div_factorial hkn]
  have h659 : (659 : ℝ) ^ n = 659 ^ k * 659 ^ (n - k) := by
    rw [← pow_add, Nat.add_sub_cancel' hkn]
  rw [h659, show (1 : ℝ) - 125 / 659 = 534 / 659 by norm_num, div_pow, div_pow]
  field_simp

/-- **The exact tail as a ratio of natural numbers**: for `n > 0`, the chance that the share
strictly exceeds `num/den` is `tailNum 125 534 n (⌊num·n/den⌋ + 1) / 659ⁿ`. -/
theorem shareExceeds_eq (n num den : ℕ) (hn : 0 < n) (hden : 0 < den) :
    shareExceeds n pMC ((num : ℝ) / den) =
      (tailNum 125 534 n (num * n / den + 1) : ℝ) / 659 ^ n := by
  classical
  unfold shareExceeds
  rw [binomial_real_eq_sum]
  have hS : (Finset.Iic n).filter (· ∈ {k : ℕ | ((num : ℝ) / den) < (k : ℝ) / n}) =
      Finset.Ico (num * n / den + 1) (n + 1) := by
    rw [← filter_cut n num den hn hden]; rfl
  rw [hS, ← tail_sum_eq]
  rfl

/-- The same, for a cut written as any real equal to `num/den`. -/
theorem shareExceeds_cut (n num den : ℕ) (c : ℝ) (hc : c = (num : ℝ) / den) (hn : 0 < n)
    (hden : 0 < den) :
    shareExceeds n pMC c = (tailNum 125 534 n (num * n / den + 1) : ℝ) / 659 ^ n := by
  rw [hc]; exact shareExceeds_eq n num den hn hden

/-- Turning natural-number inequalities into bounds on an exact tail `N/659ⁿ`. -/
theorem le_tail_of_nat {N n lo d : ℕ} (h : lo * 659 ^ n ≤ d * N) (hd : 0 < d) :
    (lo : ℝ) / d ≤ (N : ℝ) / 659 ^ n := by
  rw [div_le_div_iff₀ (by exact_mod_cast hd) (by positivity)]
  exact_mod_cast (by linarith [h] : lo * 659 ^ n ≤ N * d)

theorem tail_lt_of_nat {N n hi d : ℕ} (h : d * N < hi * 659 ^ n) (hd : 0 < d) :
    (N : ℝ) / 659 ^ n < (hi : ℝ) / d := by
  rw [div_lt_div_iff₀ (by positivity) (by exact_mod_cast hd)]
  exact_mod_cast (by linarith [h] : N * d < hi * 659 ^ n)

theorem tail_le_of_nat {N n hi d : ℕ} (h : d * N ≤ hi * 659 ^ n) (hd : 0 < d) :
    (N : ℝ) / 659 ^ n ≤ (hi : ℝ) / d := by
  rw [div_le_div_iff₀ (by positivity) (by exact_mod_cast hd)]
  exact_mod_cast (by linarith [h] : N * d ≤ hi * 659 ^ n)

theorem lt_tail_of_nat {N n lo d : ℕ} (h : lo * 659 ^ n < d * N) (hd : 0 < d) :
    (lo : ℝ) / d < (N : ℝ) / 659 ^ n := by
  rw [div_lt_div_iff₀ (by exact_mod_cast hd) (by positivity)]
  exact_mod_cast (by linarith [h] : lo * 659 ^ n < N * d)

/-- Comparing two exact tails with different `n`. -/
theorem tail_le_tail {N₁ N₂ n₁ n₂ : ℕ} (h : N₁ * 659 ^ n₂ ≤ N₂ * 659 ^ n₁) :
    (N₁ : ℝ) / 659 ^ n₁ ≤ (N₂ : ℝ) / 659 ^ n₂ := by
  rw [div_le_div_iff₀ (by positivity) (by positivity)]
  exact_mod_cast h

/-! Kernel-checked natural-number facts. Each is a finite computation on exact integers. -/

set_option maxRecDepth 100000 in
/-- Cut 23%, every `n` from 220 to 261: `0.0435 ≤ tail < 0.0745`, and the tail at `n` lies
between the tails at `n = 261` and `n = 226` (compared exactly). -/
theorem nat_cut23_range : ∀ n ∈ List.range' 220 42,
    (435 * 659 ^ n ≤ 10000 * tailNum 125 534 n (23 * n / 100 + 1) ∧
      10000 * tailNum 125 534 n (23 * n / 100 + 1) < 745 * 659 ^ n) ∧
    tailNum 125 534 261 (23 * 261 / 100 + 1) * 659 ^ n ≤
      tailNum 125 534 n (23 * n / 100 + 1) * 659 ^ 261 ∧
    tailNum 125 534 n (23 * n / 100 + 1) * 659 ^ 226 ≤
      tailNum 125 534 226 (23 * 226 / 100 + 1) * 659 ^ n := by
  decide +kernel

set_option maxRecDepth 100000 in
/-- Cut 23%: `tail(261) ∈ [0.0435, 0.0445)`, `tail(226) ∈ [0.0735, 0.0745)`,
`tail(220) ∈ [0.06835, 0.06845)`, `tail(178) ∈ [0.1005, 0.1015)`. -/
theorem nat_cut23_points :
    (435 * 659 ^ 261 ≤ 10000 * tailNum 125 534 261 (23 * 261 / 100 + 1) ∧
      10000 * tailNum 125 534 261 (23 * 261 / 100 + 1) < 445 * 659 ^ 261) ∧
    (735 * 659 ^ 226 ≤ 10000 * tailNum 125 534 226 (23 * 226 / 100 + 1) ∧
      10000 * tailNum 125 534 226 (23 * 226 / 100 + 1) < 745 * 659 ^ 226) ∧
    (6835 * 659 ^ 220 ≤ 100000 * tailNum 125 534 220 (23 * 220 / 100 + 1) ∧
      100000 * tailNum 125 534 220 (23 * 220 / 100 + 1) < 6845 * 659 ^ 220) ∧
    (1005 * 659 ^ 178 ≤ 10000 * tailNum 125 534 178 (23 * 178 / 100 + 1) ∧
      10000 * tailNum 125 534 178 (23 * 178 / 100 + 1) < 1015 * 659 ^ 178) := by
  decide +kernel

set_option maxRecDepth 100000 in
/-- Cut 19%, `n = 178` and every `n` from 220 to 261: `0.457 ≤ tail ≤ 0.522`. -/
theorem nat_cut19_range : ∀ n ∈ 178 :: List.range' 220 42,
    457 * 659 ^ n ≤ 1000 * tailNum 125 534 n (19 * n / 100 + 1) ∧
    1000 * tailNum 125 534 n (19 * n / 100 + 1) ≤ 522 * 659 ^ n := by
  decide +kernel

set_option maxRecDepth 100000 in
/-- Cut 19%, each value in the half-open interval of its one-decimal rounding:
`tail(237) ∈ [0.4565, 0.4575)` (45.7%), `tail(221) ∈ [0.5215, 0.5225)` (52.2%),
`tail(178) ∈ [0.5115, 0.5125)` (51.2%), `tail(220) ∈ [0.5085, 0.5095)` (50.9%),
`tail(261) ∈ [0.4935, 0.4945)` (49.4%). -/
theorem nat_cut19_points :
    (4565 * 659 ^ 237 ≤ 10000 * tailNum 125 534 237 (19 * 237 / 100 + 1) ∧
      10000 * tailNum 125 534 237 (19 * 237 / 100 + 1) < 4575 * 659 ^ 237) ∧
    (5215 * 659 ^ 221 ≤ 10000 * tailNum 125 534 221 (19 * 221 / 100 + 1) ∧
      10000 * tailNum 125 534 221 (19 * 221 / 100 + 1) < 5225 * 659 ^ 221) ∧
    (5115 * 659 ^ 178 ≤ 10000 * tailNum 125 534 178 (19 * 178 / 100 + 1) ∧
      10000 * tailNum 125 534 178 (19 * 178 / 100 + 1) < 5125 * 659 ^ 178) ∧
    (5085 * 659 ^ 220 ≤ 10000 * tailNum 125 534 220 (19 * 220 / 100 + 1) ∧
      10000 * tailNum 125 534 220 (19 * 220 / 100 + 1) < 5095 * 659 ^ 220) ∧
    (4935 * 659 ^ 261 ≤ 10000 * tailNum 125 534 261 (19 * 261 / 100 + 1) ∧
      10000 * tailNum 125 534 261 (19 * 261 / 100 + 1) < 4945 * 659 ^ 261) := by
  decide +kernel

theorem mem_range'_iff {n : ℕ} : n ∈ List.range' 220 42 ↔ 220 ≤ n ∧ n ≤ 261 := by
  rw [List.mem_range'_1]; omega

/-- **B168, "4.4–7.4% for 220 to 261 usable entries"**: for every count `n` from 220 to 261,
with share `p = 125/659` and the strict cut 23.0%, the chance lies in `[4.35%, 7.45%)`; it is
smallest at `n = 261`, in `[4.35%, 4.45%)`, and largest at `n = 226`, in `[7.35%, 7.45%)`. -/
theorem b168_cut23_range :
    (∀ n : ℕ, 220 ≤ n → n ≤ 261 →
      (435 / 10000 : ℝ) ≤ shareExceeds n pMC (23 / 100) ∧
      shareExceeds n pMC (23 / 100) < 745 / 10000 ∧
      shareExceeds 261 pMC (23 / 100) ≤ shareExceeds n pMC (23 / 100) ∧
      shareExceeds n pMC (23 / 100) ≤ shareExceeds 226 pMC (23 / 100)) ∧
    ((435 / 10000 : ℝ) ≤ shareExceeds 261 pMC (23 / 100) ∧
      shareExceeds 261 pMC (23 / 100) < 445 / 10000) ∧
    ((735 / 10000 : ℝ) ≤ shareExceeds 226 pMC (23 / 100) ∧
      shareExceeds 226 pMC (23 / 100) < 745 / 10000) := by
  obtain ⟨h261, h226, -, -⟩ := nat_cut23_points
  rw [shareExceeds_cut 261 23 100 _ (by norm_num) (by norm_num) (by norm_num),
    shareExceeds_cut 226 23 100 _ (by norm_num) (by norm_num) (by norm_num)]
  refine ⟨fun n h1 h2 => ?_, ?_, ?_⟩
  · obtain ⟨⟨a, b⟩, c, d⟩ := nat_cut23_range n (mem_range'_iff.2 ⟨h1, h2⟩)
    rw [shareExceeds_cut n 23 100 _ (by norm_num) (by omega) (by norm_num)]
    refine ⟨?_, ?_, tail_le_tail c, tail_le_tail d⟩
    · have := le_tail_of_nat a (by norm_num : 0 < 10000); exact_mod_cast this
    · have := tail_lt_of_nat b (by norm_num : 0 < 10000); exact_mod_cast this
  · constructor
    · have := le_tail_of_nat h261.1 (by norm_num : 0 < 10000); exact_mod_cast this
    · have := tail_lt_of_nat h261.2 (by norm_num : 0 < 10000); exact_mod_cast this
  · constructor
    · have := le_tail_of_nat h226.1 (by norm_num : 0 < 10000); exact_mod_cast this
    · have := tail_lt_of_nat h226.2 (by norm_num : 0 < 10000); exact_mod_cast this

/-- **B168, the endpoint `n = 220` and "10.1% at 2024's count of 178"**: at the strict 23.0% cut,
`n = 220` gives `[6.835%, 6.845%)` (6.84%, neither 4.4% nor 7.4%), and `n = 178` gives
`[10.05%, 10.15%)`. -/
theorem b168_cut23_points :
    ((6835 / 100000 : ℝ) ≤ shareExceeds 220 pMC (23 / 100) ∧
      shareExceeds 220 pMC (23 / 100) < 6845 / 100000) ∧
    ((1005 / 10000 : ℝ) ≤ shareExceeds 178 pMC (23 / 100) ∧
      shareExceeds 178 pMC (23 / 100) < 1015 / 10000) := by
  obtain ⟨-, -, h220, h178⟩ := nat_cut23_points
  rw [shareExceeds_cut 220 23 100 _ (by norm_num) (by norm_num) (by norm_num),
    shareExceeds_cut 178 23 100 _ (by norm_num) (by norm_num) (by norm_num)]
  refine ⟨⟨?_, ?_⟩, ?_, ?_⟩
  · have := le_tail_of_nat h220.1 (by norm_num : 0 < 100000); exact_mod_cast this
  · have := tail_lt_of_nat h220.2 (by norm_num : 0 < 100000); exact_mod_cast this
  · have := le_tail_of_nat h178.1 (by norm_num : 0 < 10000); exact_mod_cast this
  · have := tail_lt_of_nat h178.2 (by norm_num : 0 < 10000); exact_mod_cast this

/-- **B168, "at the earlier cut of 19.0% it was about one half"**: at the strict 19.0% cut, for
`n = 178` and every `n` from 220 to 261, the chance lies in `[45.7%, 52.2%]`; both ends are
attained to one decimal (45.7% at `n = 237`, 52.2% at `n = 221`); at the three yearly counts it
rounds to 51.2% (`n = 178`), 50.9% (`n = 220`) and 49.4% (`n = 261`). Each point value is
proved in the half-open interval of its one-decimal rounding. -/
theorem b168_cut19_range :
    (∀ n : ℕ, (n = 178 ∨ (220 ≤ n ∧ n ≤ 261)) →
      (457 / 1000 : ℝ) ≤ shareExceeds n pMC (19 / 100) ∧
      shareExceeds n pMC (19 / 100) ≤ 522 / 1000) ∧
    ((4565 / 10000 : ℝ) ≤ shareExceeds 237 pMC (19 / 100) ∧
      shareExceeds 237 pMC (19 / 100) < 4575 / 10000) ∧
    ((5215 / 10000 : ℝ) ≤ shareExceeds 221 pMC (19 / 100) ∧
      shareExceeds 221 pMC (19 / 100) < 5225 / 10000) ∧
    ((5115 / 10000 : ℝ) ≤ shareExceeds 178 pMC (19 / 100) ∧
      shareExceeds 178 pMC (19 / 100) < 5125 / 10000) ∧
    ((5085 / 10000 : ℝ) ≤ shareExceeds 220 pMC (19 / 100) ∧
      shareExceeds 220 pMC (19 / 100) < 5095 / 10000) ∧
    ((4935 / 10000 : ℝ) ≤ shareExceeds 261 pMC (19 / 100) ∧
      shareExceeds 261 pMC (19 / 100) < 4945 / 10000) := by
  obtain ⟨h237, h221, h178, h220, h261⟩ := nat_cut19_points
  rw [shareExceeds_cut 237 19 100 _ (by norm_num) (by norm_num) (by norm_num),
    shareExceeds_cut 221 19 100 _ (by norm_num) (by norm_num) (by norm_num),
    shareExceeds_cut 178 19 100 _ (by norm_num) (by norm_num) (by norm_num),
    shareExceeds_cut 220 19 100 _ (by norm_num) (by norm_num) (by norm_num),
    shareExceeds_cut 261 19 100 _ (by norm_num) (by norm_num) (by norm_num)]
  refine ⟨fun n hn => ?_, ⟨?_, ?_⟩, ⟨?_, ?_⟩, ⟨?_, ?_⟩, ⟨?_, ?_⟩, ⟨?_, ?_⟩⟩
  · have hmem : n ∈ 178 :: List.range' 220 42 := by
      rcases hn with h | h
      · exact h ▸ List.mem_cons_self
      · exact List.mem_cons_of_mem _ (mem_range'_iff.2 h)
    obtain ⟨a, b⟩ := nat_cut19_range n hmem
    rw [shareExceeds_cut n 19 100 _ (by norm_num) (by omega) (by norm_num)]
    constructor
    · have := le_tail_of_nat a (by norm_num : 0 < 1000); exact_mod_cast this
    · have := tail_le_of_nat b (by norm_num : 0 < 1000); exact_mod_cast this
  · have := le_tail_of_nat h237.1 (by norm_num : 0 < 10000); exact_mod_cast this
  · have := tail_lt_of_nat h237.2 (by norm_num : 0 < 10000); exact_mod_cast this
  · have := le_tail_of_nat h221.1 (by norm_num : 0 < 10000); exact_mod_cast this
  · have := tail_lt_of_nat h221.2 (by norm_num : 0 < 10000); exact_mod_cast this
  · have := le_tail_of_nat h178.1 (by norm_num : 0 < 10000); exact_mod_cast this
  · have := tail_lt_of_nat h178.2 (by norm_num : 0 < 10000); exact_mod_cast this
  · have := le_tail_of_nat h220.1 (by norm_num : 0 < 10000); exact_mod_cast this
  · have := tail_lt_of_nat h220.2 (by norm_num : 0 < 10000); exact_mod_cast this
  · have := le_tail_of_nat h261.1 (by norm_num : 0 < 10000); exact_mod_cast this
  · have := tail_lt_of_nat h261.2 (by norm_num : 0 < 10000); exact_mod_cast this

/-! ## 3. C11: the illustrative (C3) case, with the replication code's inputs

`check_benefits.py` lines 463–470: cyber clock `K = 1`, `T_a = 1`, parallel (`m = 0`);
`h(c) = c` (`h0 = 0`, `h1 = 1`, `h2 = 0`); `V_c = 1` (default); constant step mass; `s = 0.1`,
`r = 1`; benefit flow `y = 10⁻²⁰` on the benefit clock `K_B = T_b = 1`, parallel, horizon
`L = 50` (`Model(Clock(1, 1, 0), Clock(1, 1, 0), y=1e-20, …)`, `master(…, 50)`). The cyber loss is
the paper's own definition (line 1329, and its undiscounted analogue, Section A.7 / (C2)):
`C^{lev}_{c,r}(s) = (1/s)∫₀^K e^{−rc/s}h(c)dc + h(K)[A_r(T) − A_r(τ)] + S_r`, with `τ = K/s`,
`T = max(K/s, T_a)` and `A_r(t) = (1 − e^{−rt})/r`; undiscounted,
`(1/s)∫₀^K h(c)dc + (T − τ)h(K) + S`. The balance is `W = B − V_c·C` (line 1025), with the benefit
level `B` defined below; `y` is kept as a parameter and then set to the code's `10⁻²⁰ > 0` (A15). -/

/-- `A_r(t) = (1 − e^{−rt})/r`. -/
noncomputable def Ar (r t : ℝ) : ℝ := (1 - Real.exp (-r * t)) / r

/-- The discounted level-set cyber loss of the C11 case, line 1329: `K = 1`, `h(c) = c`, `r = 1`,
`T = max(1/s, 1)`, constant step mass `S`. -/
noncomputable def c11Disc (S s : ℝ) : ℝ :=
  (1 / s) * (∫ c in (0:ℝ)..1, Real.exp (-(1 * c / s)) * c) +
    1 * (Ar 1 (max (1 / s) 1) - Ar 1 (1 / s)) + S

/-- The undiscounted level-set cyber loss of the same case: `(1/s)∫₀¹ c dc + (T − τ)h(K) + S`. -/
noncomputable def c11Undisc (S s : ℝ) : ℝ :=
  (1 / s) * (∫ c in (0:ℝ)..1, c) + (max (1 / s) 1 - 1 / s) * 1 + S

theorem c11_integral {s : ℝ} (hs : 0 < s) :
    (∫ c in (0:ℝ)..1, Real.exp (-(1 * c / s)) * c) = s ^ 2 - Real.exp (-(1 / s)) * (s + s ^ 2) := by
  have hd : ∀ x ∈ Set.uIcc (0:ℝ) 1,
      HasDerivAt (fun c => -s * Real.exp (c * (-(1 / s))) * (c + s))
        (Real.exp (-(1 * x / s)) * x) x := by
    intro x _
    have h2 := (((hasDerivAt_mul_const (-(1 / s))).exp).const_mul (-s)).mul
      ((hasDerivAt_id x).add_const s)
    refine h2.congr_deriv ?_
    rw [show x * (-(1 / s)) = -(1 * x / s) by ring]
    simp only [id]
    field_simp
    ring
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hd (by
    apply Continuous.intervalIntegrable; fun_prop)]
  simp only [zero_mul, Real.exp_zero, zero_add, one_mul]
  ring

/-- On the capability branch `0 < s < 1` the discounted loss is `s − e^{−1/s}(1 + s) + S`. -/
theorem c11Disc_eq {S s : ℝ} (hs : 0 < s) (hs1 : s < 1) :
    c11Disc S s = s - Real.exp (-(1 / s)) * (1 + s) + S := by
  have hmax : max (1 / s) 1 = 1 / s := max_eq_left (by rw [le_div_iff₀ hs]; linarith)
  unfold c11Disc
  rw [c11_integral hs, hmax]
  field_simp
  ring

/-- On the capability branch the undiscounted loss is `1/(2s) + S`. -/
theorem c11Undisc_eq {S s : ℝ} (hs : 0 < s) (hs1 : s < 1) : c11Undisc S s = 1 / (2 * s) + S := by
  have hmax : max (1 / s) 1 = 1 / s := max_eq_left (by rw [le_div_iff₀ hs]; linarith)
  unfold c11Undisc
  rw [integral_id, hmax]
  field_simp
  ring

/-- C11, the cyber part `−V_c·C` of the undiscounted balance (`V_c = 1`): derivative 50 at
`s = 0.1`. -/
theorem c11_cyber_undiscounted (S : ℝ) :
    HasDerivAt (fun s => -c11Undisc S s) 50 (1 / 10) ∧ (1 / 10 : ℝ) * 50 = 5 := by
  refine ⟨?_, by norm_num⟩
  have hev : (fun s => -c11Undisc S s) =ᶠ[nhds (1 / 10)] fun s => -(1 / (2 * s) + S) :=
    Filter.eventuallyEq_of_mem (Ioo_mem_nhds (by norm_num : (0:ℝ) < 1 / 10)
      (by norm_num : (1 / 10 : ℝ) < 1)) fun s hs => by rw [c11Undisc_eq hs.1 hs.2]
  refine HasDerivAt.congr_of_eventuallyEq ?_ hev
  have h0 := ((hasDerivAt_id (1 / 10 : ℝ)).const_mul 2).inv (by norm_num)
  have h3 := (h0.add_const S).neg
  convert h3 using 1
  · funext s; simp [one_div]
  · norm_num

/-- C11, the cyber part `−V_c·C` of the discounted balance at `r = 1`: `s` times its derivative is
`−1/10 + (111/10)e^{−10} ∈ (−0.0995, −0.0994)`. -/
theorem c11_cyber_discounted (S : ℝ) :
    HasDerivAt (fun s => -c11Disc S s) (-(1 - 111 * Real.exp (-10))) (1 / 10) ∧
    (1 / 10 : ℝ) * (-(1 - 111 * Real.exp (-10))) = -1 / 10 + 111 / 10 * Real.exp (-10) ∧
    (-995 / 10000 : ℝ) < -1 / 10 + 111 / 10 * Real.exp (-10) ∧
    -1 / 10 + 111 / 10 * Real.exp (-10) < (-994 / 10000 : ℝ) := by
  have hev : (fun s => -c11Disc S s) =ᶠ[nhds (1 / 10)]
      fun s => -(s - Real.exp (-(1 / s)) * (1 + s) + S) :=
    Filter.eventuallyEq_of_mem (Ioo_mem_nhds (by norm_num : (0:ℝ) < 1 / 10)
      (by norm_num : (1 / 10 : ℝ) < 1)) fun s hs => by rw [c11Disc_eq hs.1 hs.2]
  have he : Real.exp (-10) * Real.exp 10 = 1 := by rw [← Real.exp_add]; norm_num
  have hpos : 0 < Real.exp (-10) := Real.exp_pos _
  have h10 : Real.exp 10 = Real.exp 1 ^ 10 := by rw [← Real.exp_nat_mul]; norm_num
  have hlo : (2.7182818283 : ℝ) < Real.exp 1 := Real.exp_one_gt_d9
  have hhi : Real.exp 1 < 2.7182818286 := Real.exp_one_lt_d9
  have hE1 : (18502 : ℝ) < Real.exp 10 := by
    rw [h10]; calc (18502 : ℝ) < 2.7182818283 ^ 10 := by norm_num
      _ < Real.exp 1 ^ 10 := by gcongr
  have hE2 : Real.exp 10 < 22197 := by
    rw [h10]; calc Real.exp 1 ^ 10 < (2.7182818286 : ℝ) ^ 10 := by gcongr
      _ < 22197 := by norm_num
  refine ⟨?_, by ring, by nlinarith, by nlinarith⟩
  refine HasDerivAt.congr_of_eventuallyEq ?_ hev
  have hx : (1 / 10 : ℝ) ≠ 0 := by norm_num
  have h1 := (hasDerivAt_inv hx).neg
  have h2 := ((hasDerivAt_id (1 / 10 : ℝ)).sub
    ((h1.exp).mul ((hasDerivAt_id (1 / 10 : ℝ)).const_add 1))).add_const S
  convert h2.neg using 1
  · funext s; simp [one_div]
  · simp only [Pi.neg_apply, id]
    norm_num
    ring

/-- Benefit arrival `t_B(s) = max(K_B/s, T_b)` with `K_B = T_b = 1`, parallel timing (`m_B = 0`). -/
noncomputable def c11tB (s : ℝ) : ℝ := max (1 / s) 1

/-- Undiscounted benefit level over the horizon `L = 50`: `B_L(s) = y(L − t_B(s))⁺` (line 1025). -/
noncomputable def c11BenU (y s : ℝ) : ℝ := y * max (50 - c11tB s) 0

/-- Discounted benefit level at `r = 1` over the horizon `L = 50`: the flow `y` discounted from
arrival (if before `L`) to `L`, `y∫_{min(t_B, L)}^{L} e^{−t}dt`. -/
noncomputable def c11BenD (y s : ℝ) : ℝ := y * ∫ t in (min (c11tB s) 50)..50, Real.exp (-(1 * t))

/-- The undiscounted balance `W_L = B_L − V_c·C` (`V_c = 1`). -/
noncomputable def c11WU (y S s : ℝ) : ℝ := c11BenU y s - 1 * c11Undisc S s

/-- The discounted balance `W_r = B_r − V_c·C^{lev}_{c,r}` (`V_c = 1`, `r = 1`). -/
noncomputable def c11WD (y S s : ℝ) : ℝ := c11BenD y s - 1 * c11Disc S s

theorem c11_benefit_integral (a : ℝ) :
    (∫ t in a..50, Real.exp (-(1 * t))) = Real.exp (-a) - Real.exp (-50) := by
  have hd : ∀ x ∈ Set.uIcc a 50,
      HasDerivAt (fun t => -Real.exp (-t)) (Real.exp (-(1 * x))) x := by
    intro x _
    have := ((hasDerivAt_id x).neg.exp).neg
    convert this using 1
    · funext t; simp
    · simp
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hd (by
    apply Continuous.intervalIntegrable; fun_prop)]
  ring

theorem c11BenU_eq {y s : ℝ} (hs : 1 / 20 < s) (hs1 : s < 1) :
    c11BenU y s = y * (50 - 1 / s) := by
  have hs0 : 0 < s := by linarith
  have hmax : max (1 / s) 1 = 1 / s := max_eq_left (by rw [le_div_iff₀ hs0]; linarith)
  have h20 : 1 / s < 20 := by rw [div_lt_iff₀ hs0]; linarith
  have h50 : 0 ≤ 50 - 1 / s := by linarith
  unfold c11BenU c11tB
  rw [hmax, max_eq_left h50]

theorem c11BenD_eq {y s : ℝ} (hs : 1 / 20 < s) (hs1 : s < 1) :
    c11BenD y s = y * (Real.exp (-(1 / s)) - Real.exp (-50)) := by
  have hs0 : 0 < s := by linarith
  have hmax : max (1 / s) 1 = 1 / s := max_eq_left (by rw [le_div_iff₀ hs0]; linarith)
  have h20 : 1 / s < 20 := by rw [div_lt_iff₀ hs0]; linarith
  have hmin : min (1 / s) 50 = 1 / s := min_eq_left (by linarith)
  unfold c11BenD c11tB
  rw [hmax, hmin, c11_benefit_integral]

/-- The undiscounted benefit's derivative at `s = 0.1`: `yK_B/s² = 100y` (`s·B_L′ = yqχ_Bη_L`). -/
theorem c11BenU_deriv (y : ℝ) : HasDerivAt (c11BenU y) (100 * y) (1 / 10) := by
  have hev : c11BenU y =ᶠ[nhds (1 / 10)] fun s => y * (50 - 1 / s) :=
    Filter.eventuallyEq_of_mem (Ioo_mem_nhds (by norm_num : (1 / 20 : ℝ) < 1 / 10)
      (by norm_num : (1 / 10 : ℝ) < 1)) fun s hs => c11BenU_eq hs.1 hs.2
  refine HasDerivAt.congr_of_eventuallyEq ?_ hev
  have hx : (1 / 10 : ℝ) ≠ 0 := by norm_num
  have h1 := ((hasDerivAt_inv hx).const_sub 50).const_mul y
  convert h1 using 1
  · funext s; simp [one_div]
  · norm_num
    ring

/-- The discounted benefit's derivative at `s = 0.1`: `100y·e^{−10}` (`s·B_r′ = yqχ_Be^{−rt_B}`). -/
theorem c11BenD_deriv (y : ℝ) : HasDerivAt (c11BenD y) (100 * y * Real.exp (-10)) (1 / 10) := by
  have hev : c11BenD y =ᶠ[nhds (1 / 10)] fun s => y * (Real.exp (-(1 / s)) - Real.exp (-50)) :=
    Filter.eventuallyEq_of_mem (Ioo_mem_nhds (by norm_num : (1 / 20 : ℝ) < 1 / 10)
      (by norm_num : (1 / 10 : ℝ) < 1)) fun s hs => c11BenD_eq hs.1 hs.2
  refine HasDerivAt.congr_of_eventuallyEq ?_ hev
  have hx : (1 / 10 : ℝ) ≠ 0 := by norm_num
  have h1 := (((hasDerivAt_inv hx).neg.exp).sub_const (Real.exp (-50))).const_mul y
  convert h1 using 1
  · funext s; simp [one_div]
  · norm_num
    ring

/-- **C11** (line 1335), undiscounted, for any benefit flow `y`: `s·W_L′ = 5 + 10y` at `s = 0.1`. -/
theorem c11_undiscounted (y S : ℝ) :
    HasDerivAt (c11WU y S) (100 * y + 50) (1 / 10) ∧
      (1 / 10 : ℝ) * (100 * y + 50) = 5 + 10 * y := by
  refine ⟨?_, by ring⟩
  have e : c11WU y S = fun s => c11BenU y s + -c11Undisc S s := by
    funext s; unfold c11WU; ring
  rw [e]
  exact (c11BenU_deriv y).add (c11_cyber_undiscounted S).1

/-- **C11** (line 1335), discounted at `r = 1`, for any benefit flow `y`:
`s·W_r′ = −1/10 + (111/10 + 10y)e^{−10}` at `s = 0.1`. -/
theorem c11_discounted (y S : ℝ) :
    HasDerivAt (c11WD y S) (100 * y * Real.exp (-10) + -(1 - 111 * Real.exp (-10))) (1 / 10) ∧
      (1 / 10 : ℝ) * (100 * y * Real.exp (-10) + -(1 - 111 * Real.exp (-10))) =
        -1 / 10 + (111 / 10 + 10 * y) * Real.exp (-10) := by
  refine ⟨?_, by ring⟩
  have e : c11WD y S = fun s => c11BenD y s + -c11Disc S s := by
    funext s; unfold c11WD; ring
  rw [e]
  exact (c11BenD_deriv y).add (c11_cyber_discounted S).1

theorem exp_neg_ten_bounds : (1 : ℝ) / 22197 < Real.exp (-10) ∧ Real.exp (-10) < 1 / 18502 := by
  have he : Real.exp (-10) * Real.exp 10 = 1 := by rw [← Real.exp_add]; norm_num
  have hpos : 0 < Real.exp (-10) := Real.exp_pos _
  have h10 : Real.exp 10 = Real.exp 1 ^ 10 := by rw [← Real.exp_nat_mul]; norm_num
  have hlo : (2.7182818283 : ℝ) < Real.exp 1 := Real.exp_one_gt_d9
  have hhi : Real.exp 1 < 2.7182818286 := Real.exp_one_lt_d9
  have hE1 : (18502 : ℝ) < Real.exp 10 := by
    rw [h10]; calc (18502 : ℝ) < 2.7182818283 ^ 10 := by norm_num
      _ < Real.exp 1 ^ 10 := by gcongr
  have hE2 : Real.exp 10 < 22197 := by
    rw [h10]; calc Real.exp 1 ^ 10 < (2.7182818286 : ℝ) ^ 10 := by gcongr
      _ < 22197 := by norm_num
  constructor
  · rw [div_lt_iff₀ (by norm_num)]; nlinarith [mul_lt_mul_of_pos_left hE2 hpos]
  · rw [lt_div_iff₀ (by norm_num)]; nlinarith [mul_lt_mul_of_pos_left hE1 hpos]

/-- **C11 at the code's inputs** (`check_benefits.py` lines 463–470, `y = 10⁻²⁰ > 0` as A15
requires): undiscounted `s·W_L′ = 5 + 10⁻¹⁹`, which the paper prints as 5; discounted
`s·W_r′ = −1/10 + (111/10 + 10⁻¹⁹)e^{−10} ∈ (−0.0995, −0.0994)`, which prints as −0.099. -/
theorem c11_code_case (S : ℝ) :
    HasDerivAt (c11WU (1 / 10 ^ 20) S) (100 * (1 / 10 ^ 20) + 50) (1 / 10) ∧
    (1 / 10 : ℝ) * (100 * (1 / 10 ^ 20) + 50) = 5 + 1 / 10 ^ 19 ∧
    HasDerivAt (c11WD (1 / 10 ^ 20) S)
      (100 * (1 / 10 ^ 20) * Real.exp (-10) + -(1 - 111 * Real.exp (-10))) (1 / 10) ∧
    (-995 / 10000 : ℝ) <
      (1 / 10) * (100 * (1 / 10 ^ 20) * Real.exp (-10) + -(1 - 111 * Real.exp (-10))) ∧
    (1 / 10 : ℝ) * (100 * (1 / 10 ^ 20) * Real.exp (-10) + -(1 - 111 * Real.exp (-10))) <
      -994 / 10000 := by
  obtain ⟨hU, eU⟩ := c11_undiscounted (1 / 10 ^ 20) S
  obtain ⟨hD, eD⟩ := c11_discounted (1 / 10 ^ 20) S
  obtain ⟨hlo, hhi⟩ := exp_neg_ten_bounds
  refine ⟨hU, by rw [eU]; norm_num, hD, ?_, ?_⟩
  · rw [eD]; nlinarith
  · rw [eD]; nlinarith

/-! ## 4. P11's interior example: where the crossing lies (A101, P40)

A.6's interior example (line 1109): `ρ = Mx^η`, `M = 1`, `η = 1/2`, `Δ = 0.3`, `g₀ = 0.2`,
`κ_pre = κ_post = 0.5`, `λ = 0.2`, `r = 0.05`, `F + λZ = 0.42`. The artifact example (A101) and the
four `Z ≠ 0` test cases (P40) use this example, per `check_model.py` lines 1223–1256: A101 takes
`λ′ = 0.75` at `Z = 0`; P40 takes `(λ′, Z) ∈ {(0.75, 0.8), (1.0, 1.2), (1.5, 0.4), (0.5, 0.8)}`
with `F = 0.42 − 0.2Z`, so `F + λZ = 0.42` and the crossing is the same in all of them.

`phiEx g` is the paper's `Φ̃(g)` for this example (line 1134), with `Π(x) = Mx^η/(r + ηκ_post)`
(proved as `RTTR.Release.Pi_power`); `phiEx_eq_rpow` shows it equals, symbol for symbol, the right
side of `RTTR.Release.Phi_power` at lead `g`. `Jex g = Π(g + Δ)` is `J(T)` at lead `g`. -/

/-- `Φ̃(g)` for the interior example, written with square roots. -/
noncomputable def phiEx (g : ℝ) : ℝ :=
  21 / 50 + Real.sqrt g - 5 / 6 * Real.sqrt (g + 3 / 10) - 5 / 6 * g / Real.sqrt (g + 3 / 10)

/-- `J = Π(g + Δ)` for the interior example. -/
noncomputable def Jex (g : ℝ) : ℝ := Real.sqrt (g + 3 / 10) / (3 / 10)

/-- `phiEx` and `Jex` are the power-rent `Φ` and `J` of `RTTR.Release.Phi_power` and
`RTTR.Release.Pi_power` at `M = 1`, `η = 1/2`, `r = 1/20`, `λ = 1/5`, `κ_pre = κ_post = 1/2`,
`Δ = 3/10`, `F + λZ = 21/50`, lead `g ≥ 0`. -/
theorem phiEx_eq_rpow {g : ℝ} (hg : 0 ≤ g) :
    phiEx g = 21 / 50 + 1 * g ^ (1 / 2 : ℝ)
      - (1 / 20 + 1 / 5) * (1 * (g + 3 / 10) ^ (1 / 2 : ℝ) / (1 / 20 + 1 / 2 * (1 / 2)))
      - 1 / 2 * g * (1 * (1 / 2) * (g + 3 / 10) ^ ((1 / 2 : ℝ) - 1) / (1 / 20 + 1 / 2 * (1 / 2))) ∧
    Jex g = 1 * (g + 3 / 10) ^ (1 / 2 : ℝ) / (1 / 20 + 1 / 2 * (1 / 2)) := by
  have hu : 0 < g + 3 / 10 := by linarith
  have hsq : Real.sqrt (g + 3 / 10) ≠ 0 := (Real.sqrt_pos.2 hu).ne'
  have e1 : (g + 3 / 10) ^ ((1 / 2 : ℝ) - 1) = (Real.sqrt (g + 3 / 10))⁻¹ := by
    rw [show (1 / 2 : ℝ) - 1 = -(1 / 2) by norm_num, Real.rpow_neg hu.le, Real.sqrt_eq_rpow]
  rw [e1, ← Real.sqrt_eq_rpow, ← Real.sqrt_eq_rpow]
  unfold phiEx Jex
  constructor
  · field_simp; ring
  · field_simp; ring

/-- `Φ̃ < 0` at a vanished lead. -/
theorem phiEx_zero_neg : phiEx 0 < 0 := by
  unfold phiEx
  have h : (504 / 1000 : ℝ) < Real.sqrt (3 / 10) := by
    rw [Real.lt_sqrt (by norm_num)]; norm_num
  simp only [Real.sqrt_zero, zero_add, mul_zero, zero_div, add_zero, sub_zero]
  linarith

/-- `Φ̃ > 0` for every lead in `[0.01, 0.2]`. -/
theorem phiEx_pos {g : ℝ} (h1 : 1 / 100 ≤ g) (h2 : g ≤ 1 / 5) : 0 < phiEx g := by
  have hg : 0 ≤ g := by linarith
  have hs2 : Real.sqrt g ^ 2 = g := Real.sq_sqrt hg
  have hu2 : Real.sqrt (g + 3 / 10) ^ 2 = g + 3 / 10 := Real.sq_sqrt (by linarith)
  have hs0 : 1 / 10 ≤ Real.sqrt g := by rw [Real.le_sqrt (by norm_num) hg]; linarith
  have hs1 : Real.sqrt g ≤ 45 / 100 := by rw [Real.sqrt_le_left (by norm_num)]; linarith
  have hu0 : 0 < Real.sqrt (g + 3 / 10) := Real.sqrt_pos.2 (by linarith)
  unfold phiEx
  generalize Real.sqrt g = s at hs2 hs0 hs1 ⊢
  generalize Real.sqrt (g + 3 / 10) = u at hu2 hu0 ⊢
  have key : 5 / 6 * (2 * s ^ 2 + 3 / 10) < (21 / 50 + s) * u := by
    have hA : 0 < (21 / 50 + s) * u := by positivity
    have hB : 0 < 5 / 6 * (2 * s ^ 2 + 3 / 10) := by positivity
    have hsq : (5 / 6 * (2 * s ^ 2 + 3 / 10)) ^ 2 < ((21 / 50 + s) * u) ^ 2 := by
      rw [show ((21 / 50 + s) * u) ^ 2 = (21 / 50 + s) ^ 2 * u ^ 2 by ring, hu2, ← hs2]
      nlinarith [mul_nonneg (sub_nonneg.2 hs0) (sub_nonneg.2 hs1), sq_nonneg (s - 1 / 10),
        mul_nonneg (sub_nonneg.2 hs0) (sub_nonneg.2 hs0)]
    nlinarith
  have hgu : g / u = (2 * g + 3 / 10) / u - u := by
    field_simp; nlinarith [hu2]
  have hlt : (2 * g + 3 / 10) / u < 6 / 5 * (21 / 50 + s) := by
    rw [div_lt_iff₀ hu0]; nlinarith [key, hs2]
  rw [mul_div_assoc, hgu]
  linarith

/-- Every crossing lies below lead `0.01`: a zero of `Φ̃` with lead in `[0, g₀] = [0, 0.2]` has
`G* < 0.01` (so `T* = ln(g₀/G*)/κ_pre > 2 ln 20`). -/
theorem phiEx_root_lt {g : ℝ} (h2 : g ≤ 1 / 5) (h0 : phiEx g = 0) : g < 1 / 100 := by
  by_contra h
  exact (phiEx_pos (not_lt.1 h) h2).ne' h0

theorem phiEx_continuousOn : ContinuousOn phiEx (Set.Icc 0 (1 / 100)) := by
  unfold phiEx
  apply ContinuousOn.sub (by fun_prop)
  apply ContinuousOn.div (by fun_prop) (by fun_prop)
  intro x hx
  exact (Real.sqrt_pos.2 (by linarith [hx.1])).ne'

/-- A crossing exists, strictly inside `(0, 0.01)`. -/
theorem phiEx_root_exists : ∃ g ∈ Set.Ioo (0 : ℝ) (1 / 100), phiEx g = 0 := by
  have h := intermediate_value_Ioo (by norm_num : (0 : ℝ) ≤ 1 / 100) phiEx_continuousOn
  exact h ⟨phiEx_zero_neg, phiEx_pos le_rfl (by norm_num)⟩

/-- At every crossing, `J(T*) = Jex(G*)` lies in `(1.8257, 1.8560)`. -/
theorem Jex_bounds {g : ℝ} (hg : 0 ≤ g) (h2 : g ≤ 1 / 5) (h0 : phiEx g = 0) :
    18257 / 10000 < Jex g ∧ Jex g < 18560 / 10000 := by
  have hlt := phiEx_root_lt h2 h0
  unfold Jex
  constructor
  · rw [lt_div_iff₀ (by norm_num), Real.lt_sqrt (by norm_num)]; nlinarith
  · rw [div_lt_iff₀ (by norm_num), Real.sqrt_lt' (by norm_num)]; nlinarith

/-- `Φ̃′ > 0` at every lead in `(0, 0.01)`. -/
theorem phiEx_hasDerivAt_pos {g : ℝ} (hg : 0 < g) (hg1 : g < 1 / 100) :
    ∃ d : ℝ, 0 < d ∧ HasDerivAt phiEx d g := by
  have hu0 : 0 < Real.sqrt (g + 3 / 10) := Real.sqrt_pos.2 (by linarith)
  have hs0 : 0 < Real.sqrt g := Real.sqrt_pos.2 hg
  have hs1 : Real.sqrt g < 1 / 10 := by rw [Real.sqrt_lt' (by norm_num)]; linarith
  have hu1 : 1 / 2 < Real.sqrt (g + 3 / 10) := by rw [Real.lt_sqrt (by norm_num)]; linarith
  have hds : HasDerivAt Real.sqrt (1 / (2 * Real.sqrt g)) g := by
    simpa [one_div] using Real.hasDerivAt_sqrt hg.ne'
  have hdu : HasDerivAt (fun x => Real.sqrt (x + 3 / 10)) (1 / (2 * Real.sqrt (g + 3 / 10))) g := by
    have := (Real.hasDerivAt_sqrt (by linarith : g + 3 / 10 ≠ 0)).comp g
      ((hasDerivAt_id g).add_const (3 / 10))
    simpa [one_div, Function.comp_def] using this
  set d := 1 / (2 * Real.sqrt g) - 5 / 6 * (1 / (2 * Real.sqrt (g + 3 / 10)))
    - 5 / 6 * ((1 * Real.sqrt (g + 3 / 10) - g * (1 / (2 * Real.sqrt (g + 3 / 10))))
      / Real.sqrt (g + 3 / 10) ^ 2) with hd_def
  have hD : HasDerivAt phiEx d g := by
    have h := ((((hasDerivAt_const g (21 / 50 : ℝ)).add hds).sub (hdu.const_mul (5 / 6))).sub
      (((hasDerivAt_id g).const_mul (5 / 6)).div hdu hu0.ne'))
    refine (h.congr_deriv ?_).congr_of_eventuallyEq ?_
    · rw [hd_def]; simp only [id]; ring
    · exact Filter.Eventually.of_forall fun x => by
        unfold phiEx; simp only [Pi.add_apply, Pi.sub_apply, Pi.div_apply, id]
  have hdpos : 0 < d := by
    have e1 : 5 < 1 / (2 * Real.sqrt g) := by rw [lt_div_iff₀ (by positivity)]; linarith
    have e2 : 5 / 6 * (1 / (2 * Real.sqrt (g + 3 / 10))) < 5 / 6 := by
      have : 1 / (2 * Real.sqrt (g + 3 / 10)) < 1 := by rw [div_lt_one (by positivity)]; linarith
      linarith
    have e3 : 5 / 6 * ((1 * Real.sqrt (g + 3 / 10) - g * (1 / (2 * Real.sqrt (g + 3 / 10))))
        / Real.sqrt (g + 3 / 10) ^ 2) < 5 / 6 * 2 := by
      have hg' : 0 ≤ g * (1 / (2 * Real.sqrt (g + 3 / 10))) := by positivity
      have : (1 * Real.sqrt (g + 3 / 10) - g * (1 / (2 * Real.sqrt (g + 3 / 10))))
          / Real.sqrt (g + 3 / 10) ^ 2 < 2 := by
        rw [div_lt_iff₀ (by positivity)]; nlinarith
      linarith
    rw [hd_def]; linarith
  exact ⟨d, hdpos, hD⟩

/-- The crossing is simple and downward in `T`: at a crossing `G* ∈ (0, 0.01)`, `Φ̃′(G*) > 0`,
and along the lead path `g(T) = 0.2e^{−T/2}` the derivative of `Φ̃(g(T))` at the crossing date is
negative. This is the hypothesis `a < 0` of `RTTR.Release.comp_statics`. -/
theorem phiEx_simple_crossing {g T : ℝ} (hg : 0 < g) (hg1 : g < 1 / 100)
    (hT : 1 / 5 * Real.exp (-(1 / 2) * T) = g) :
    ∃ d : ℝ, 0 < d ∧ HasDerivAt phiEx d g ∧
      HasDerivAt (fun t => phiEx (1 / 5 * Real.exp (-(1 / 2) * t))) (d * (-(1 / 2) * g)) T ∧
      d * (-(1 / 2) * g) < 0 := by
  obtain ⟨d, hdpos, hD⟩ := phiEx_hasDerivAt_pos hg hg1
  have hpath : HasDerivAt (fun t => 1 / 5 * Real.exp (-(1 / 2) * t)) (-(1 / 2) * g) T := by
    have := ((((hasDerivAt_id T).const_mul (-(1 / 2))).exp).const_mul (1 / 5 : ℝ))
    refine this.congr_deriv ?_
    rw [← hT]; simp only [id]; ring
  have hD' : HasDerivAt phiEx d (1 / 5 * Real.exp (-(1 / 2) * T)) := by rw [hT]; exact hD
  refine ⟨d, hdpos, hD, ?_, by nlinarith⟩
  exact hD'.comp T hpath

/-- `Φ̃` is strictly increasing in the lead on `[0, 0.01]`. -/
theorem phiEx_strictMonoOn : StrictMonoOn phiEx (Set.Icc 0 (1 / 100)) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc 0 (1 / 100)) phiEx_continuousOn
  intro x hx
  rw [interior_Icc] at hx
  obtain ⟨d, hd, hD⟩ := phiEx_hasDerivAt_pos hx.1 hx.2
  rw [hD.deriv]; exact hd

/-- **The crossing is unique**: exactly one lead in `[0, g₀] = [0, 0.2]` has `Φ̃ = 0`. -/
theorem phiEx_root_unique : ∃! g, g ∈ Set.Icc (0 : ℝ) (1 / 5) ∧ phiEx g = 0 := by
  obtain ⟨g, hg, h0⟩ := phiEx_root_exists
  refine ⟨g, ⟨⟨hg.1.le, by linarith [hg.2]⟩, h0⟩, ?_⟩
  rintro g' ⟨hg', h0'⟩
  have h1 := phiEx_root_lt hg'.2 h0'
  exact phiEx_strictMonoOn.injOn ⟨hg'.1, h1.le⟩ ⟨hg.1.le, hg.2.le⟩ (h0'.trans h0.symm)

/-- Single crossing in the lead: below the crossing `Φ̃ < 0`, above it (up to `g₀`) `Φ̃ > 0`. -/
theorem phiEx_sign {G g : ℝ} (hG0 : 0 ≤ G) (hG : G ≤ 1 / 5) (h0 : phiEx G = 0) :
    (0 ≤ g → g < G → phiEx g < 0) ∧ (G < g → g ≤ 1 / 5 → 0 < phiEx g) := by
  have hG1 := phiEx_root_lt hG h0
  refine ⟨fun h1 h2 => ?_, fun h1 h2 => ?_⟩
  · have := phiEx_strictMonoOn ⟨h1, by linarith⟩ ⟨hG0, hG1.le⟩ h2
    linarith
  · rcases lt_or_ge g (1 / 100) with h | h
    · have := phiEx_strictMonoOn ⟨hG0, hG1.le⟩ ⟨by linarith, h.le⟩ h1
      linarith
    · exact phiEx_pos h h2

/-- **Single crossing along the path**, in the form `RTTR.Release.p11i_global` takes: with lead
`g(T) = 0.2e^{−T/2}`, there is a date `T* > 2 ln 20` with `Φ̃(g(T*)) = 0`, `Φ̃(g(T)) > 0` for
`0 < T < T*` and `Φ̃(g(T)) < 0` for `T > T*`. -/
theorem phiEx_path_single_crossing :
    ∃ Ts : ℝ, 2 * Real.log 20 < Ts ∧ phiEx (1 / 5 * Real.exp (-(1 / 2) * Ts)) = 0 ∧
      (∀ T, 0 < T → T < Ts → 0 < phiEx (1 / 5 * Real.exp (-(1 / 2) * T))) ∧
      (∀ T, Ts < T → phiEx (1 / 5 * Real.exp (-(1 / 2) * T)) < 0) := by
  obtain ⟨G, hG, h0⟩ := phiEx_root_exists
  have h5G : 0 < 5 * G := by linarith [hG.1]
  have hsgn := fun g : ℝ => phiEx_sign (g := g) (le_of_lt hG.1) (by linarith [hG.2]) h0
  have hlead : 1 / 5 * Real.exp (-(1 / 2) * (-2 * Real.log (5 * G))) = G := by
    rw [show -(1 / 2) * (-2 * Real.log (5 * G)) = Real.log (5 * G) by ring, Real.exp_log h5G]
    ring
  have hanti : ∀ a b : ℝ, a < b →
      1 / 5 * Real.exp (-(1 / 2) * b) < 1 / 5 * Real.exp (-(1 / 2) * a) := by
    intro a b hab
    have := Real.exp_lt_exp.2 (show -(1 / 2) * b < -(1 / 2) * a by linarith)
    linarith
  refine ⟨-2 * Real.log (5 * G), ?_, by rw [hlead]; exact h0, fun T h1 h2 => ?_, fun T h1 => ?_⟩
  · have hl : Real.log (5 * G) < Real.log (1 / 20) := Real.log_lt_log h5G (by linarith [hG.2])
    rw [Real.log_div (by norm_num) (by norm_num), Real.log_one] at hl
    linarith
  · have hgt := hanti T _ h2
    rw [hlead] at hgt
    have hle : 1 / 5 * Real.exp (-(1 / 2) * T) ≤ 1 / 5 := by
      have := Real.exp_lt_exp.2 (show -(1 / 2) * T < 0 by linarith)
      rw [Real.exp_zero] at this
      linarith
    exact (hsgn _).2 hgt hle
  · have hlt := hanti _ T h1
    rw [hlead] at hlt
    exact (hsgn _).1 (by positivity) hlt

/-- **A101** (line 989), at the paper's interior example with the code's `λ′ = 0.75`, `Z = 0`: at
every crossing the artifact term `∂Φ̃/∂f_a = 1 − λ′(J(T*) − Z)` is negative while the internal
term `∂Φ̃/∂f_u = 1` is positive, so (by `RTTR.Release.comp_statics` at the simple crossing) richer
artifact sales bring release sooner and richer internal use delays it. The ratio
`dT*/df_a ÷ dT*/df_u = 1 − λ′J(T*)` lies in `(−0.392, −0.369)`, and the printed
`−45.5 ÷ 122 = −0.3730` lies in it. -/
theorem a101_signs {g : ℝ} (hg : 0 ≤ g) (h2 : g ≤ 1 / 5) (h0 : phiEx g = 0) :
    1 - 3 / 4 * (Jex g - 0) < 0 ∧ (0 : ℝ) < 1 ∧
    (-392 / 1000 : ℝ) < 1 - 3 / 4 * (Jex g - 0) ∧ 1 - 3 / 4 * (Jex g - 0) < -369 / 1000 ∧
    (-392 / 1000 : ℝ) < -45.5 / 122 ∧ (-45.5 / 122 : ℝ) < -369 / 1000 := by
  obtain ⟨a, b⟩ := Jex_bounds hg h2 h0
  refine ⟨by linarith, one_pos, by linarith, by linarith, by norm_num, by norm_num⟩

/-- **P40** (line 1134), the four `Z ≠ 0` test cases of `check_model.py` (lines 1245–1256): at
every crossing, the correct artifact term `1 − λ′(J(T*) − Z)` and the term without `Z`,
`1 − λ′J(T*)`, have opposite signs in exactly the first two cases, `(λ′, Z) = (0.75, 0.8)` and
`(1.0, 1.2)`, and the same sign in `(1.5, 0.4)` and `(0.5, 0.8)`: two of four. -/
theorem p40_two_of_four {g : ℝ} (hg : 0 ≤ g) (h2 : g ≤ 1 / 5) (h0 : phiEx g = 0) :
    (0 < 1 - 3 / 4 * (Jex g - 4 / 5) ∧ 1 - 3 / 4 * Jex g < 0) ∧
    (0 < 1 - 1 * (Jex g - 6 / 5) ∧ 1 - 1 * Jex g < 0) ∧
    (1 - 3 / 2 * (Jex g - 2 / 5) < 0 ∧ 1 - 3 / 2 * Jex g < 0) ∧
    (0 < 1 - 1 / 2 * (Jex g - 4 / 5) ∧ 0 < 1 - 1 / 2 * Jex g) := by
  obtain ⟨a, b⟩ := Jex_bounds hg h2 h0
  refine ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩,
    ⟨by linarith, by linarith⟩⟩

/-! ## 5. B90: the class-order robustness, from the six-order table

The four class counts (memory corruption, injection and input handling, access policy, other)
under each of the six priority orders of the three named classes, as `PEAKS-PAPER/M8/kev_v5.py`
prints them from the saved catalogue `M8/sources/G4-kev_live.json` (catalogVersion 2026.10.21,
1,754 entries). The counts are data, not proved here; what is proved is the paper's arithmetic
claim about them. The paper's order is the first row. -/

/-- Six-order counts `(a, b, c, d)`, November 2021 through 2023 (920 usable entries). -/
def ordersEarly : List (ℕ × ℕ × ℕ × ℕ) :=
  [(299, 368, 171, 82), (299, 365, 174, 82), (285, 382, 171, 82), (285, 382, 171, 82),
    (299, 365, 174, 82), (285, 379, 174, 82)]

/-- Six-order counts `(a, b, c, d)`, January 2024 to 20 October 2026 (659 usable entries). -/
def ordersLate : List (ℕ × ℕ × ℕ × ℕ) :=
  [(125, 295, 180, 59), (125, 288, 187, 59), (125, 295, 180, 59), (125, 295, 180, 59),
    (125, 288, 187, 59), (125, 288, 187, 59)]

/-- `|100·(x − x₀)/N| < q/10` points, in natural numbers. -/
def withinPts (N q x x₀ : ℕ) : Prop := 1000 * x < 1000 * x₀ + q * N ∧ 1000 * x₀ < 1000 * x + q * N

instance (N q x x₀ : ℕ) : Decidable (withinPts N q x x₀) := by unfold withinPts; infer_instance

/-- **B90** (line 272): in every order, each class's share moves from the paper's-order share by
less than 1.9 points in the earlier period and less than 1.1 points in the later; every row sums
to the usable total. (The largest moves are 14/920 = 1.52 and 7/659 = 1.06 points.) -/
theorem b90_order_bound :
    (∀ t ∈ ordersEarly, t.1 + t.2.1 + t.2.2.1 + t.2.2.2 = 920 ∧
      withinPts 920 19 t.1 299 ∧ withinPts 920 19 t.2.1 368 ∧
      withinPts 920 19 t.2.2.1 171 ∧ withinPts 920 19 t.2.2.2 82) ∧
    (∀ t ∈ ordersLate, t.1 + t.2.1 + t.2.2.1 + t.2.2.2 = 659 ∧
      withinPts 659 11 t.1 125 ∧ withinPts 659 11 t.2.1 295 ∧
      withinPts 659 11 t.2.2.1 180 ∧ withinPts 659 11 t.2.2.2 59) := by
  decide

/-! ## 6. P24 / B111(b) at every admissible `π` and weight; P19's duration

`B(n) = (1 − π)Σ_j c_j(n)w_j m(λ(n), τ_j)` with `m(λ, τ) = (1 − e^{−λτ})/λ` (line 949). The
definitions of `m` and `m_λ` are L3's (`RTTR.Hold.m`, `RTTR.Hold.mlam`), restated because this file
imports nothing from the project; the unit-weight monotonicity proof follows L3's
`p8_corner_full`. -/

/-- `m(λ, τ) = (1 − e^{−λτ})/λ`. -/
noncomputable def m (l τ : ℝ) : ℝ := (1 - Real.exp (-l * τ)) / l

/-- `m_λ(λ, τ) = ∂m/∂λ`. -/
noncomputable def mlam (l τ : ℝ) : ℝ := (l * τ * Real.exp (-l * τ) - (1 - Real.exp (-l * τ))) / l ^ 2

theorem hasDerivAt_m (l τ : ℝ) (hl : l ≠ 0) : HasDerivAt (fun y => m y τ) (mlam l τ) l := by
  have hnum : HasDerivAt (fun y => 1 - Real.exp (-y * τ)) (τ * Real.exp (-l * τ)) l := by
    have h1 : HasDerivAt (fun y => -y * τ) (-τ) l := by
      simpa using ((hasDerivAt_id l).neg).mul_const τ
    have := (h1.exp).const_sub 1
    convert this using 1; ring
  have := hnum.div (hasDerivAt_id l) hl
  have e : mlam l τ = (τ * Real.exp (-l * τ) * id l - (1 - Real.exp (-l * τ)) * 1) / id l ^ 2 := by
    simp only [mlam, id]; ring
  rw [e]; exact this

theorem m_pos (l τ : ℝ) (hl : 0 < l) (hτ : 0 < τ) : 0 < m l τ := by
  unfold m
  apply div_pos _ hl
  have : Real.exp (-l * τ) < 1 := by
    have := Real.exp_lt_exp.2 (show -l * τ < 0 by nlinarith); rwa [Real.exp_zero] at this
  linarith

/-- One operator, coverage `n`, unit weight, `π = 0`, `λ = 1 + 0.01n`: `n·m(λ(n), τ)` is strictly
increasing on `[0, 1]` for every `τ > 0` (the content of L3's `p8_corner_full`). -/
theorem p24_corner_full_unit (τ : ℝ) (hτ : 0 < τ) :
    StrictMonoOn (fun n : ℝ => n * m (1 + 0.01 * n) τ) (Set.Icc 0 1) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc 0 1)
  · intro x hx
    have hl : 0 < 1 + 0.01 * x := by linarith [hx.1]
    exact ((hasDerivAt_id x).mul ((hasDerivAt_m _ τ hl.ne').comp x
      (((hasDerivAt_id x).const_mul 0.01).const_add 1))).continuousAt.continuousWithinAt
  · intro x hx
    rw [interior_Icc] at hx
    have hl : 0 < 1 + 0.01 * x := by linarith [hx.1]
    have h2raw := (hasDerivAt_m _ τ hl.ne').comp x
      (((hasDerivAt_id x).const_mul 0.01).const_add 1)
    have h2 : HasDerivAt (fun n : ℝ => m (1 + 0.01 * n) τ)
        (mlam (1 + 0.01 * x) τ * (0.01 * 1)) x := h2raw
    have hD : HasDerivAt (fun n : ℝ => n * m (1 + 0.01 * n) τ)
        (1 * m (1 + 0.01 * x) τ + x * (mlam (1 + 0.01 * x) τ * (0.01 * 1))) x :=
      (hasDerivAt_id x).mul h2
    rw [hD.deriv]
    simp only [one_mul, mul_one]
    set l := 1 + 0.01 * x with hldef
    have hmp := m_pos l τ hl hτ
    have hmlam : -(m l τ) / l < mlam l τ := by
      unfold mlam m
      rw [neg_div, div_div, ← sq, neg_lt, ← neg_div]
      apply div_lt_div_of_pos_right _ (by positivity)
      have : 0 < l * τ * Real.exp (-l * τ) := by positivity
      linarith
    have h1 : 0.01 * x < l := by linarith
    have hx0 : 0 < x := hx.1
    have key : m l τ * (1 - 0.01 * x / l) ≤ m l τ + x * (mlam l τ * 0.01) := by
      have : x * 0.01 * (-(m l τ) / l) ≤ x * 0.01 * mlam l τ :=
        mul_le_mul_of_nonneg_left hmlam.le (by positivity)
      have e : m l τ * (1 - 0.01 * x / l) = m l τ + x * 0.01 * (-(m l τ) / l) := by
        field_simp; ring
      rw [e]; linarith
    have : 0 < 1 - 0.01 * x / l := by rw [sub_pos, div_lt_one hl]; exact h1
    nlinarith [mul_pos hmp this]

/-- **P24 / B111(b), the full-coalition corner, at every admissible `π` and weight**: one operator
with coverage `c = n`, weight `w > 0`, deployment time `τ > 0`, access share `π < 1`, and
`λ = 1 + 0.01n`: `B(n) = (1 − π)·n·w·m(λ(n), τ)` is strictly increasing on `[0, 1]`, so the
largest coalition is the unique best. -/
theorem p24_corner_full_general (π w τ : ℝ) (hπ : π < 1) (hw : 0 < w) (hτ : 0 < τ) :
    StrictMonoOn (fun n : ℝ => (1 - π) * (n * w * m (1 + 0.01 * n) τ)) (Set.Icc 0 1) := by
  intro a ha b hb hab
  have h := p24_corner_full_unit τ hτ ha hb hab
  have hk : 0 < (1 - π) * w := mul_pos (by linarith) hw
  have e : ∀ n : ℝ, (1 - π) * (n * w * m (1 + 0.01 * n) τ) =
      ((1 - π) * w) * (n * m (1 + 0.01 * n) τ) := fun n => by ring
  simp only [e]
  exact mul_lt_mul_of_pos_left h hk

/-- **P24 / B111(b) needs `π < 1`**: at `π = 1`, `B ≡ 0` on `[0, 1]` and does not rise. -/
theorem p24_corner_full_needs_pi (w τ : ℝ) :
    ¬ StrictMonoOn (fun n : ℝ => (1 - 1) * (n * w * m (1 + 0.01 * n) τ)) (Set.Icc 0 1) := by
  intro h
  have := h (show (0 : ℝ) ∈ Set.Icc 0 1 by norm_num) (show (1 : ℝ) ∈ Set.Icc 0 1 by norm_num)
    one_pos
  simp at this

/-- **P24 / B111(b) needs `w > 0`**: the paper's weights are only nonnegative (line 84); at
`w = 0`, `B ≡ 0` on `[0, 1]` for every `π` and `τ` and does not rise. -/
theorem p24_corner_full_needs_w (π τ : ℝ) :
    ¬ StrictMonoOn (fun n : ℝ => (1 - π) * (n * 0 * m (1 + 0.01 * n) τ)) (Set.Icc 0 1) := by
  intro h
  have := h (show (0 : ℝ) ∈ Set.Icc 0 1 by norm_num) (show (1 : ℝ) ∈ Set.Icc 0 1 by norm_num)
    one_pos
  simp at this

/-- **P24 / B111(b) needs `τ > 0`**: at `τ = 0`, `m(λ, 0) = 0`, so `B ≡ 0` on `[0, 1]` for every
`π` and `w` and does not rise. -/
theorem p24_corner_full_needs_tau (π w : ℝ) :
    ¬ StrictMonoOn (fun n : ℝ => (1 - π) * (n * w * m (1 + 0.01 * n) 0)) (Set.Icc 0 1) := by
  intro h
  have := h (show (0 : ℝ) ∈ Set.Icc 0 1 by norm_num) (show (1 : ℝ) ∈ Set.Icc 0 1 by norm_num)
    one_pos
  simp [m] at this

/-- **P19 needs a positive exposure duration**: with exposure `[a, a]` of zero length, shifting it
by any `δ` leaves the discounted exposure at 0, so it does not fall (`Hold.p7_shift_discount`
assumes `a < b`). -/
theorem p19_needs_positive_duration (a δ r : ℝ) :
    ¬ ((∫ t in (a + δ)..(a + δ), Real.exp (-r * t)) < ∫ t in a..a, Real.exp (-r * t)) := by
  simp

end RTTR.Gaps3

#print axioms RTTR.Gaps3.b89_kev_shares
#print axioms RTTR.Gaps3.b91_cwe20_check
#print axioms RTTR.Gaps3.b92_same_year_check
#print axioms RTTR.Gaps3.b165_patched_ratio
#print axioms RTTR.Gaps3.b166_batch_ratio
#print axioms RTTR.Gaps3.b167_yearly_shares
#print axioms RTTR.Gaps3.b87_repeats
#print axioms RTTR.Gaps3.b87_needs_one_bug_per_report
#print axioms RTTR.Gaps3.binomial_real_eq_sum
#print axioms RTTR.Gaps3.filter_cut
#print axioms RTTR.Gaps3.tail_sum_eq
#print axioms RTTR.Gaps3.shareExceeds_eq
#print axioms RTTR.Gaps3.shareExceeds_cut
#print axioms RTTR.Gaps3.le_tail_of_nat
#print axioms RTTR.Gaps3.tail_lt_of_nat
#print axioms RTTR.Gaps3.tail_le_of_nat
#print axioms RTTR.Gaps3.lt_tail_of_nat
#print axioms RTTR.Gaps3.tail_le_tail
#print axioms RTTR.Gaps3.nat_cut23_range
#print axioms RTTR.Gaps3.nat_cut23_points
#print axioms RTTR.Gaps3.nat_cut19_range
#print axioms RTTR.Gaps3.nat_cut19_points
#print axioms RTTR.Gaps3.mem_range'_iff
#print axioms RTTR.Gaps3.b168_cut23_range
#print axioms RTTR.Gaps3.b168_cut23_points
#print axioms RTTR.Gaps3.b168_cut19_range
#print axioms RTTR.Gaps3.c11_integral
#print axioms RTTR.Gaps3.c11Disc_eq
#print axioms RTTR.Gaps3.c11Undisc_eq
#print axioms RTTR.Gaps3.c11_cyber_undiscounted
#print axioms RTTR.Gaps3.c11_cyber_discounted
#print axioms RTTR.Gaps3.c11_benefit_integral
#print axioms RTTR.Gaps3.c11BenU_eq
#print axioms RTTR.Gaps3.c11BenD_eq
#print axioms RTTR.Gaps3.c11BenU_deriv
#print axioms RTTR.Gaps3.c11BenD_deriv
#print axioms RTTR.Gaps3.c11_undiscounted
#print axioms RTTR.Gaps3.c11_discounted
#print axioms RTTR.Gaps3.exp_neg_ten_bounds
#print axioms RTTR.Gaps3.c11_code_case
#print axioms RTTR.Gaps3.phiEx_eq_rpow
#print axioms RTTR.Gaps3.phiEx_zero_neg
#print axioms RTTR.Gaps3.phiEx_pos
#print axioms RTTR.Gaps3.phiEx_root_lt
#print axioms RTTR.Gaps3.phiEx_continuousOn
#print axioms RTTR.Gaps3.phiEx_root_exists
#print axioms RTTR.Gaps3.Jex_bounds
#print axioms RTTR.Gaps3.phiEx_hasDerivAt_pos
#print axioms RTTR.Gaps3.phiEx_simple_crossing
#print axioms RTTR.Gaps3.phiEx_strictMonoOn
#print axioms RTTR.Gaps3.phiEx_root_unique
#print axioms RTTR.Gaps3.phiEx_sign
#print axioms RTTR.Gaps3.phiEx_path_single_crossing
#print axioms RTTR.Gaps3.a101_signs
#print axioms RTTR.Gaps3.p40_two_of_four
#print axioms RTTR.Gaps3.b90_order_bound
#print axioms RTTR.Gaps3.hasDerivAt_m
#print axioms RTTR.Gaps3.m_pos
#print axioms RTTR.Gaps3.p24_corner_full_unit
#print axioms RTTR.Gaps3.p24_corner_full_general
#print axioms RTTR.Gaps3.p24_corner_full_needs_pi
#print axioms RTTR.Gaps3.p24_corner_full_needs_w
#print axioms RTTR.Gaps3.p24_corner_full_needs_tau
#print axioms RTTR.Gaps3.p19_needs_positive_duration
