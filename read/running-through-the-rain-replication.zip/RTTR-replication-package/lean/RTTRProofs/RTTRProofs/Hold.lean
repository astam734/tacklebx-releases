import Mathlib

/-!
# Sub-model Hold: Propositions 6, 7 and 8 of "Running Through the Rain" (v8, Appendix A.3.2)

Seat L3. Statements: P6 lines 927–935, P7 937–945, P8 947–953, the truncated window of A.2.1
(line 831), the shortening-lag remarks (lines 943, 1160, 1219). Proofs A.6 lines 1124–1128.

## Modelling choices (how each paper object is represented, and why that is faithful)

* **Probability.** `(Ω, P)` with `[IsProbabilityMeasure P]`. Expectations of nonnegative
  quantities are extended nonnegative integrals `∫⁻` (so an infinite mean is allowed and no
  integrability is assumed). A real Bochner integral is used only for bounded quantities, after
  integrability is proved (`integrable_min`), never relying on the junk value of a non-integrable
  integral.
* **P6(i).** The window is any `W : Ω → ℝ≥0∞` (no measurability needed, infinite values and
  infinite mean allowed), `τ : ℝ≥0∞`; the bound is `∫⁻ min W τ ≤ min (∫⁻ W) τ` (`p6i_bound`).
* **Exponential window.** "W exponential with rate λ" is the survival law
  `P {t < W} = e^{−λt}` for all `t ≥ 0`, which determines the exponential distribution;
  almost-sure positivity is derived from it (`ae_pos_of_survival`), not assumed.
  `E[min(W, τ)]` is computed by the layer-cake formula (`lintegral_disc_min`), from the
  definition, not taken as a definition. `m λ τ := (1 − e^{−λτ})/λ` is the paper's notation
  (P8 defines `m` so); `p6ii_exp` proves it is that expectation.
* **Exposure model (A6, A8).** Baseline exposure of a covered operator is `τ` (every attacker
  exposed until deployment). Under the window, share `π` (parallel access) is still exposed for
  `τ` and share `1 − π` arrives at `W`, exposed for `(τ − W)⁺`: `holdExposure`. The saving
  `(1 − π) min(W, τ)` is *derived* (`p6_pathwise_saving`; algebraic content). Discounted exposure is
  `∫ e^{−rt}` over the same dated intervals (`baseDisc`, `holdDisc`).
* **Coverage (A9).** Coverage is a measurable event `Cov`; A9 is `IndepFun (1_Cov) W`. The
  factorization `E[1_Cov · saving] = P(Cov)(1 − π)E[min(W, τ)]` is proved from independence
  (`p6_factorization`), and shown to fail without it (`p6_factorization_needs_A9`, on any model
  with the stated conditional survival laws). `p6_A9_counterexample_exists` constructs such a model
  (`U` uniform on `[0, 1]`, covered iff `U < 1/2`, `W` the inverse-survival transform of the
  rescaled uniform on each half) and proves A9 fails in it.
* **P6(iii).** The share `(1 − π) m(λ, τ)/τ` depends only on `u = λτ` (`p6iii_share_eq`);
  "asymptotically equal" is `Asymptotics.IsEquivalent` as `u → 0⁺` and `u → ∞`, and, for `π < 1`,
  a ratio tending to one (`p6iii_ratio_small`, `p6iii_ratio_large`). At `π = 1` the saving is
  identically zero and the ratio is `0/0` (`p6_saving_pi_one`).
* **P6(iv).** Operators are a `Finset`; fast operators a sub-`Finset`; deployment times `τ_j ≥ 0`.
  Each operator's expected saving uses the actual `∫⁻ min(W, τ_j)`. The inner bound is for any
  window law with `∫⁻ W = 1/λ` (`p6iv_aggregate`); the outer bound is for any window, infinite mean
  allowed (`p6iv_aggregate_any`). `p6iv_model` states both for the model's total saving
  `Σ_j w_j E[1_{Cov_j} · saving_j]` under A9, through `p6iv_G_eq`, which composes
  `p6_factorization`; there `c_j = P(Cov_j)`.
* **P6(v).** Harm `g` is any function with a subgradient `d` at `τ` on `[0, ∞)`; convexity is
  needed only to guarantee such a `d` exists, so the theorem is stated for the subgradient.
* **P7.** Dated intervals as the paper defines them: first usable exploit `min(P_f + ℓ_x, A)`,
  deployment `P_f + τ`, exposure the positive part of the difference; unfound flaws exposed from
  discovery to `ζ`. A8 mixture: share `π` keeps release-regime exposure (`mixHold`). P7(c)'s
  completion date `min(P + τ, max(P, t) + τ′)` is the proof's formula; several flaws carry
  nonnegative loss weights.
* **Shortening lag.** The paper does not specify the rule. We state one (`lagOnset`): without the
  capability a patch is exploited after `ℓ₀`; once the capability is held (from `W`), after
  `ℓ₁ ≤ ℓ₀`, never before publication.
* **P8.** `B(n) = (1 − π) Σ_j c_j(n) w_j m(λ(n), τ_j)` exactly as defined; `m_λ` is proved to be the
  derivative of the defined `m` (`hasDerivAt_m`) and negative for `τ > 0` (`mlam_neg`); it is zero
  at `τ = 0` (`mlam_zero`). P8(i) assumes each `c_j` and `λ` differentiable at `n`. P8(ii) is proved
  for any function on `[0, N]` (the paper's argument is generic in `B`) and restated for `B` itself
  (`p8ii_*_B`); P8(iii) for `ℕ`-indexed functions and for `k ↦ B(k)` (`p8iii_B`).
* **Decimals.** Printed example decimals are certified by rigorous enclosures: fifth-order Taylor
  bounds for `exp` on `[−1, 0]` from Mathlib's `Real.exp_bound` (`exp_enclose`).
* **Examples.** Inputs are those of the A.6 table; where the paper's text omits an input (P7(c)'s
  discounted example, P8's corner and rival examples) we use the replication code's inputs and say
  so in the log.
-/

open MeasureTheory ProbabilityTheory Set Filter Topology Asymptotics
open scoped ENNReal

namespace RTTR.Hold

/-! ## P6 -/

/-- Exposure-time of a covered operator, weighted by attack intensity (A6, A8). -/
def holdExposure (π τ W : ℝ) : ℝ := π * τ + (1 - π) * max (τ - W) 0

/-- Baseline exposure without a window. -/
def baseExposure (τ : ℝ) : ℝ := τ

theorem p6_pathwise_saving (π τ W : ℝ) :
    baseExposure τ - holdExposure π τ W = (1 - π) * min W τ := by
  unfold baseExposure holdExposure
  rcases le_total W τ with h | h
  · rw [max_eq_left (by linarith), min_eq_left h]; ring
  · rw [max_eq_right (by linarith), min_eq_right h]; ring

theorem p6i_bound {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (W : Ω → ℝ≥0∞) (τ : ℝ≥0∞) :
    ∫⁻ ω, min (W ω) τ ∂P ≤ min (∫⁻ ω, W ω ∂P) τ := by
  refine le_min (lintegral_mono fun ω => min_le_left _ _) ?_
  calc ∫⁻ ω, min (W ω) τ ∂P ≤ ∫⁻ _, τ ∂P := lintegral_mono fun ω => min_le_right _ _
    _ = τ := by simp

theorem integral_exp_neg_mul (c τ : ℝ) (hc : 0 < c) :
    ∫ t in (0:ℝ)..τ, Real.exp (-c * t) = (1 - Real.exp (-c * τ)) / c := by
  have hd : ∀ x ∈ uIcc (0:ℝ) τ,
      HasDerivAt (fun t => -Real.exp (-c * t) / c) (Real.exp (-c * x)) x := by
    intro x _
    have h1 : HasDerivAt (fun t => -c * t) (-c) x := by
      simpa using (hasDerivAt_id x).const_mul (-c)
    have h2 := (h1.exp).neg.div_const c
    convert h2 using 1
    field_simp
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hd
    (by apply Continuous.intervalIntegrable; fun_prop)]
  simp; field_simp; ring

/-- The layer-cake core. -/
theorem lintegral_disc_min {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) (W : Ω → ℝ)
    (hW : AEMeasurable W μ) (hnn : 0 ≤ᵐ[μ] W) (a lam r τ : ℝ) (ha : 0 ≤ a) (hlam : 0 < lam)
    (hr : 0 ≤ r) (hτ : 0 ≤ τ)
    (hsurv : ∀ t, 0 < t → t < τ → μ {ω | t < W ω} = ENNReal.ofReal (a * Real.exp (-lam * t))) :
    ∫⁻ ω, ENNReal.ofReal (∫ t in (0:ℝ)..min (W ω) τ, Real.exp (-r * t)) ∂μ
      = ENNReal.ofReal (a * ((1 - Real.exp (-(r + lam) * τ)) / (r + lam))) := by
  have hnn' : 0 ≤ᵐ[μ] fun ω => min (W ω) τ :=
    hnn.mono fun ω h => le_min h hτ
  have hm : AEMeasurable (fun ω => min (W ω) τ) μ := hW.min aemeasurable_const
  rw [lintegral_comp_eq_lintegral_meas_lt_mul μ hnn' hm
    (fun t _ => by apply Continuous.intervalIntegrable; fun_prop)
    (Eventually.of_forall fun t => (Real.exp_pos _).le)]
  have hcongr : ∀ t ∈ Ioi (0:ℝ), μ {ω | t < min (W ω) τ} * ENNReal.ofReal (Real.exp (-r * t))
      = (Iio τ).indicator (fun t => ENNReal.ofReal (a * Real.exp (-(r + lam) * t))) t := by
    intro t ht
    by_cases htτ : t < τ
    · rw [indicator_of_mem (show t ∈ Iio τ from htτ)]
      have hset : {ω | t < min (W ω) τ} = {ω | t < W ω} := by
        ext ω; simp [lt_min_iff, htτ]
      rw [hset, hsurv t ht htτ, ← ENNReal.ofReal_mul (by positivity)]
      congr 1
      rw [mul_assoc, ← Real.exp_add]; ring_nf
    · rw [indicator_of_notMem (show t ∉ Iio τ from htτ)]
      have hset : {ω | t < min (W ω) τ} = ∅ :=
        eq_empty_iff_forall_notMem.2 fun ω (h : t < min (W ω) τ) =>
          htτ (lt_of_lt_of_le h (min_le_right _ _))
      rw [hset, measure_empty, zero_mul]
  rw [setLIntegral_congr_fun measurableSet_Ioi hcongr, lintegral_indicator measurableSet_Iio,
    Measure.restrict_restrict measurableSet_Iio]
  have hI : Iio τ ∩ Ioi (0:ℝ) = Ioo 0 τ := by
    ext t; simp [and_comm]
  rw [hI, ← ofReal_integral_eq_lintegral_ofReal]
  · congr 1
    rw [← integral_Ioc_eq_integral_Ioo, ← intervalIntegral.integral_of_le hτ,
      intervalIntegral.integral_const_mul, integral_exp_neg_mul _ _ (by linarith)]
  · exact (Continuous.integrableOn_Icc (by fun_prop)).mono_set Ioo_subset_Icc_self
  · exact Eventually.of_forall fun t => by positivity

/-- `m(λ, τ) = (1 − e^{−λτ})/λ`. -/
noncomputable def m (lam τ : ℝ) : ℝ := (1 - Real.exp (-lam * τ)) / lam

theorem m_nonneg (lam τ : ℝ) (hlam : 0 < lam) (hτ : 0 ≤ τ) : 0 ≤ m lam τ := by
  unfold m
  have : Real.exp (-lam * τ) ≤ 1 := Real.exp_le_one_iff.2 (by nlinarith)
  exact div_nonneg (by linarith) hlam.le

theorem ae_pos_of_survival {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (W : Ω → ℝ) (hW : Measurable W) (lam : ℝ)
    (hsurv : ∀ t, 0 ≤ t → P {ω | t < W ω} = ENNReal.ofReal (Real.exp (-lam * t))) :
    ∀ᵐ ω ∂P, 0 < W ω := by
  have h0 : P {ω | 0 < W ω} = 1 := by rw [hsurv 0 le_rfl]; simp
  have hms : MeasurableSet {ω | 0 < W ω} := measurableSet_lt measurable_const hW
  rw [ae_iff, show {a | ¬ 0 < W a} = {ω | 0 < W ω}ᶜ by ext; simp, prob_compl_eq_zero_iff hms]
  exact h0

theorem p6ii_exp {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (W : Ω → ℝ) (hW : Measurable W) (lam τ : ℝ) (hlam : 0 < lam) (hτ : 0 ≤ τ)
    (hsurv : ∀ t, 0 ≤ t → P {ω | t < W ω} = ENNReal.ofReal (Real.exp (-lam * t))) :
    ∫⁻ ω, ENNReal.ofReal (min (W ω) τ) ∂P = ENNReal.ofReal (m lam τ) := by
  have hnn : 0 ≤ᵐ[P] W := (ae_pos_of_survival P W hW lam hsurv).mono fun ω h => h.le
  have h := lintegral_disc_min P W hW.aemeasurable hnn 1 lam 0 τ zero_le_one hlam le_rfl hτ
    (fun t ht _ => by rw [hsurv t ht.le, one_mul])
  simp only [neg_zero, zero_mul, Real.exp_zero, intervalIntegral.integral_const, smul_eq_mul,
    mul_one, sub_zero, zero_add, one_mul] at h
  rw [h, m]

theorem p6ii_exp_real {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (W : Ω → ℝ) (hW : Measurable W) (lam τ : ℝ) (hlam : 0 < lam) (hτ : 0 ≤ τ)
    (hsurv : ∀ t, 0 ≤ t → P {ω | t < W ω} = ENNReal.ofReal (Real.exp (-lam * t))) :
    ∫ ω, min (W ω) τ ∂P = m lam τ := by
  have hnn : 0 ≤ᵐ[P] fun ω => min (W ω) τ :=
    (ae_pos_of_survival P W hW lam hsurv).mono fun ω h => le_min h.le hτ
  rw [integral_eq_lintegral_of_nonneg_ae hnn (hW.min measurable_const).aestronglyMeasurable,
    p6ii_exp P W hW lam τ hlam hτ hsurv, ENNReal.toReal_ofReal (m_nonneg lam τ hlam hτ)]

theorem p6ii_saving {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (W : Ω → ℝ) (hW : Measurable W) (π lam τ : ℝ) (hπ : π ≤ 1) (hlam : 0 < lam) (hτ : 0 ≤ τ)
    (hsurv : ∀ t, 0 ≤ t → P {ω | t < W ω} = ENNReal.ofReal (Real.exp (-lam * t))) :
    ∫⁻ ω, ENNReal.ofReal (baseExposure τ - holdExposure π τ (W ω)) ∂P
      = ENNReal.ofReal ((1 - π) * m lam τ) := by
  simp_rw [p6_pathwise_saving, ENNReal.ofReal_mul (sub_nonneg.2 hπ)]
  rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top, p6ii_exp P W hW lam τ hlam hτ hsurv]

/-- Discounted baseline exposure `∫₀^τ e^{−rt} dt`. -/
noncomputable def baseDisc (r τ : ℝ) : ℝ := ∫ t in (0:ℝ)..τ, Real.exp (-r * t)

/-- Discounted exposure under the window. -/
noncomputable def holdDisc (π r τ W : ℝ) : ℝ :=
  π * baseDisc r τ + (1 - π) * ∫ t in (min W τ)..τ, Real.exp (-r * t)

theorem p6_pathwise_saving_disc (π r τ W : ℝ) :
    baseDisc r τ - holdDisc π r τ W = (1 - π) * ∫ t in (0:ℝ)..min W τ, Real.exp (-r * t) := by
  have hc : Continuous fun t : ℝ => Real.exp (-r * t) := by fun_prop
  unfold holdDisc baseDisc
  rw [← intervalIntegral.integral_add_adjacent_intervals (hc.intervalIntegrable 0 (min W τ))
    (hc.intervalIntegrable (min W τ) τ)]
  ring

theorem p6ii_saving_disc {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (W : Ω → ℝ) (hW : Measurable W) (π lam r τ : ℝ) (hπ : π ≤ 1) (hlam : 0 < lam) (hr : 0 ≤ r)
    (hτ : 0 ≤ τ)
    (hsurv : ∀ t, 0 ≤ t → P {ω | t < W ω} = ENNReal.ofReal (Real.exp (-lam * t))) :
    ∫⁻ ω, ENNReal.ofReal (baseDisc r τ - holdDisc π r τ (W ω)) ∂P
      = ENNReal.ofReal ((1 - π) * (1 - Real.exp (-(r + lam) * τ)) / (r + lam)) := by
  have hnn : 0 ≤ᵐ[P] W := (ae_pos_of_survival P W hW lam hsurv).mono fun ω h => h.le
  simp_rw [p6_pathwise_saving_disc, ENNReal.ofReal_mul (sub_nonneg.2 hπ)]
  rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top,
    lintegral_disc_min P W hW.aemeasurable hnn 1 lam r τ zero_le_one hlam hr hτ
      (fun t ht _ => by rw [hsurv t ht.le, one_mul]),
    ← ENNReal.ofReal_mul (sub_nonneg.2 hπ)]
  congr 1; ring

theorem p6_factorization {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (Cov : Set Ω) (hCov : MeasurableSet Cov) (W : Ω → ℝ) (hW : Measurable W)
    (hind : IndepFun (Cov.indicator (1 : Ω → ℝ≥0∞)) W P) (π τ : ℝ) (hπ : π ≤ 1) :
    ∫⁻ ω, Cov.indicator (1 : Ω → ℝ≥0∞) ω * ENNReal.ofReal (baseExposure τ - holdExposure π τ (W ω)) ∂P
      = P Cov * (ENNReal.ofReal (1 - π) * ∫⁻ ω, ENNReal.ofReal (min (W ω) τ) ∂P) := by
  simp_rw [p6_pathwise_saving, ENNReal.ofReal_mul (sub_nonneg.2 hπ)]
  have hψ : Measurable fun x : ℝ => ENNReal.ofReal (1 - π) * ENNReal.ofReal (min x τ) := by
    fun_prop
  have hind' := hind.comp (φ := id) measurable_id hψ
  have key := lintegral_mul_eq_lintegral_mul_lintegral_of_indepFun''
      ((measurable_one.indicator hCov).aemeasurable) ((hψ.comp hW).aemeasurable) hind'
  simp only [Function.comp] at key
  rw [key,
    lintegral_indicator_one hCov, lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]

/-- Saving as a share of baseline exposure, in terms of `u = λτ`. -/
noncomputable def shareFn (π u : ℝ) : ℝ := (1 - π) * ((1 - Real.exp (-u)) / u)

theorem p6iii_share_eq (π lam τ : ℝ) (hlam : 0 < lam) :
    (1 - π) * m lam τ / τ = shareFn π (lam * τ) := by
  unfold m shareFn
  rw [neg_mul]
  field_simp

theorem p6iii_tendsto_small (π : ℝ) : Tendsto (shareFn π) (𝓝[>] 0) (𝓝 (1 - π)) := by
  have hd : HasDerivAt (fun u : ℝ => 1 - Real.exp (-u)) 1 0 := by
    have := ((hasDerivAt_neg (0:ℝ)).exp).const_sub 1
    simpa using this
  have h1 : Tendsto (fun u : ℝ => (1 - Real.exp (-u)) / u) (𝓝[>] 0) (𝓝 1) := by
    have := (hasDerivAt_iff_tendsto_slope.1 hd).mono_left
      (nhdsWithin_mono _ fun x (hx : 0 < x) => hx.ne')
    refine this.congr fun u => ?_
    simp [slope_def_field]
  have h2 := h1.const_mul (1 - π)
  rw [mul_one] at h2
  exact h2

theorem p6iii_small (π : ℝ) : shareFn π ~[𝓝[>] 0] fun _ => 1 - π := by
  by_cases hπ : π = 1
  · subst hπ
    have : shareFn 1 = fun _ => 1 - 1 := by funext u; simp [shareFn]
    rw [this]
  · exact (isEquivalent_const_iff_tendsto (sub_ne_zero.2 (Ne.symm hπ))).2
      (p6iii_tendsto_small π)

theorem p6iii_large (π : ℝ) : shareFn π ~[atTop] fun u => (1 - π) / u := by
  by_cases hπ : π = 1
  · subst hπ
    have h1 : shareFn 1 = fun _ => 0 := by funext u; simp [shareFn]
    have h2 : (fun u : ℝ => (1 - 1) / u) = fun _ => 0 := by funext u; simp
    rw [h1, h2]
  · refine isEquivalent_of_tendsto_one ?_
    have hlim : Tendsto (fun u : ℝ => 1 - Real.exp (-u)) atTop (𝓝 1) := by
      simpa using Real.tendsto_exp_neg_atTop_nhds_zero.const_sub 1
    refine hlim.congr' ?_
    filter_upwards [eventually_gt_atTop 0] with u hu
    have h1π : (1 - π) ≠ 0 := sub_ne_zero.2 (Ne.symm hπ)
    simp only [Pi.div_apply, shareFn]
    field_simp

/-- As first stated, the fast-operator limit was one; it is `1 − π`. -/
theorem p6iii_first_stated_false (π : ℝ) (hπ : 0 < π) :
    ¬ Tendsto (shareFn π) (𝓝[>] 0) (𝓝 1) := by
  intro h
  have := tendsto_nhds_unique (p6iii_tendsto_small π) h
  linarith

/-- The share never exceeds `1 − π` nor `(1 − π)/(λτ)`. -/
theorem p6_share_le (π u : ℝ) (hπ : π ≤ 1) (hu : 0 < u) :
    shareFn π u ≤ 1 - π ∧ shareFn π u ≤ (1 - π) / u := by
  unfold shareFn
  have h1 : 0 ≤ 1 - π := by linarith
  have he : 0 < Real.exp (-u) := Real.exp_pos _
  have hle : 1 - Real.exp (-u) ≤ u := by linarith [Real.add_one_le_exp (-u)]
  constructor
  · calc (1 - π) * ((1 - Real.exp (-u)) / u) ≤ (1 - π) * 1 := by
          apply mul_le_mul_of_nonneg_left _ h1
          rw [div_le_one hu]; exact hle
      _ = 1 - π := mul_one _
  · rw [mul_div_assoc']
    apply div_le_div_of_nonneg_right _ hu.le
    nlinarith

theorem m_le (lam τ : ℝ) (hlam : 0 < lam) : m lam τ ≤ min (1 / lam) τ := by
  unfold m
  have he : 0 < Real.exp (-lam * τ) := Real.exp_pos _
  have hle : 1 - Real.exp (-lam * τ) ≤ lam * τ := by
    have := Real.add_one_le_exp (-lam * τ); nlinarith
  refine le_min ?_ ?_
  · exact div_le_div_of_nonneg_right (by linarith) hlam.le
  · rw [div_le_iff₀ hlam]; linarith

/-- **P6(iv)**. -/
theorem p6iv_aggregate {Ω ι : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (W : Ω → ℝ≥0∞) (lam : ℝ) (hlam : 0 < lam) (hmean : ∫⁻ ω, W ω ∂P = ENNReal.ofReal (1 / lam))
    (s Fast : Finset ι) (hF : Fast ⊆ s) (w τ c : ι → ℝ) (π cbar τs : ℝ)
    (hπ : π ≤ 1) (hw : ∀ j ∈ s, 0 ≤ w j) (hτ : ∀ j ∈ s, 0 ≤ τ j)
    (hc0 : ∀ j ∈ s, 0 ≤ c j) (hc1 : ∀ j ∈ s, c j ≤ 1)
    (hslowc : ∀ j ∈ s, j ∉ Fast → c j ≤ cbar) (hslowτ : ∀ j ∈ s, j ∉ Fast → τs ≤ τ j)
    (hτs : 0 < τs) (hcbar : 0 ≤ cbar) (hE0 : 0 < ∑ j ∈ s, w j * τ j) :
    let E0 := ∑ j ∈ s, w j * τ j
    let α := (∑ j ∈ Fast, w j * τ j) / E0
    let G := (1 - π) * ∑ j ∈ s, c j * w j *
      (∫⁻ ω, min (W ω) (ENNReal.ofReal (τ j)) ∂P).toReal
    G / E0 ≤ (1 - π) * (α + (1 - α) * cbar * min 1 (1 / (lam * τs))) ∧
      (1 - π) * (α + (1 - α) * cbar * min 1 (1 / (lam * τs)))
        ≤ (1 - π) * (α + cbar * (1 - α)) := by
  classical
  intro E0 α G
  set k := min 1 (1 / (lam * τs)) with hk
  set M : ι → ℝ := fun j => (∫⁻ ω, min (W ω) (ENNReal.ofReal (τ j)) ∂P).toReal with hM
  set Slow := s.filter (fun j => j ∉ Fast) with hSlow
  have h1π : 0 ≤ 1 - π := by linarith
  have hk1 : k ≤ 1 := min_le_left _ _
  have hk0 : 0 ≤ k := le_min zero_le_one (by positivity)
  have hMb : ∀ j ∈ s, 0 ≤ M j ∧ M j ≤ min (1 / lam) (τ j) := by
    intro j hj
    refine ⟨ENNReal.toReal_nonneg, ENNReal.toReal_le_of_le_ofReal (le_min (by positivity)
      (hτ j hj)) ?_⟩
    calc ∫⁻ ω, min (W ω) (ENNReal.ofReal (τ j)) ∂P
        ≤ min (∫⁻ ω, W ω ∂P) (ENNReal.ofReal (τ j)) := p6i_bound P W _
      _ = ENNReal.ofReal (min (1 / lam) (τ j)) := by rw [hmean, ENNReal.ofReal_min]
  have hfast : ∀ j ∈ Fast, c j * w j * M j ≤ w j * τ j := by
    intro j hj
    have hjs := hF hj
    obtain ⟨hM0, hMτ⟩ := hMb j hjs
    have hMτ' : M j ≤ τ j := hMτ.trans (min_le_right _ _)
    have := hw j hjs
    nlinarith [mul_nonneg (mul_nonneg (sub_nonneg.2 (hc1 j hjs)) this) hM0,
      mul_nonneg this (sub_nonneg.2 hMτ')]
  have hslow : ∀ j ∈ Slow, c j * w j * M j ≤ cbar * k * (w j * τ j) := by
    intro j hj
    obtain ⟨hjs, hjF⟩ := Finset.mem_filter.1 hj
    obtain ⟨hM0, hMτ⟩ := hMb j hjs
    have hτj := hτ j hjs
    have hMk : M j ≤ τ j * k := by
      refine hMτ.trans ?_
      rw [hk, mul_min_of_nonneg _ _ hτj, mul_one, min_comm]
      refine min_le_min le_rfl ?_
      rw [mul_one_div, div_le_div_iff₀ hlam (mul_pos hlam hτs)]
      nlinarith [hslowτ j hjs hjF]
    have hw0 := hw j hjs
    have hc0' := hc0 j hjs
    nlinarith [mul_nonneg (mul_nonneg hc0' hw0) (sub_nonneg.2 hMk),
      mul_nonneg (mul_nonneg (sub_nonneg.2 (hslowc j hjs hjF)) hw0) (mul_nonneg hτj hk0)]
  have hsplit : ∀ f : ι → ℝ, ∑ j ∈ s, f j = ∑ j ∈ Fast, f j + ∑ j ∈ Slow, f j := by
    intro f
    rw [hSlow, Finset.sum_filter_not_add_sum_filter s (fun j => j ∈ Fast) f |>.symm, add_comm,
      Finset.filter_mem_eq_inter, Finset.inter_eq_right.2 hF]
  have hA := Finset.sum_le_sum hfast
  have hB := Finset.sum_le_sum hslow
  rw [← Finset.mul_sum] at hB
  have hBnn : 0 ≤ ∑ j ∈ Slow, w j * τ j :=
    Finset.sum_nonneg fun j hj => mul_nonneg (hw j (Finset.mem_filter.1 hj).1)
      (hτ j (Finset.mem_filter.1 hj).1)
  have hE0' : E0 = ∑ j ∈ Fast, w j * τ j + ∑ j ∈ Slow, w j * τ j := hsplit _
  have hαE : α * E0 = ∑ j ∈ Fast, w j * τ j := div_mul_cancel₀ _ hE0.ne'
  have hα1 : 1 - α = (∑ j ∈ Slow, w j * τ j) / E0 := by
    rw [eq_div_iff hE0.ne', sub_mul, hαE, one_mul]; linarith [hsplit (fun j => w j * τ j)]
  have h1αE : (1 - α) * E0 = ∑ j ∈ Slow, w j * τ j := by
    rw [hα1]; exact div_mul_cancel₀ _ hE0.ne'
  have hα1nn : 0 ≤ 1 - α := by rw [hα1]; exact div_nonneg hBnn hE0.le
  constructor
  · simp only [G]
    rw [mul_div_assoc]
    apply mul_le_mul_of_nonneg_left _ h1π
    rw [div_le_iff₀ hE0, hsplit]
    have : (α + (1 - α) * cbar * k) * E0
        = ∑ j ∈ Fast, w j * τ j + cbar * k * ∑ j ∈ Slow, w j * τ j := by
      calc (α + (1 - α) * cbar * k) * E0 = α * E0 + cbar * k * ((1 - α) * E0) := by ring
        _ = _ := by rw [hαE, h1αE]
    rw [this]; linarith
  · apply mul_le_mul_of_nonneg_left _ h1π
    nlinarith [mul_nonneg hα1nn hcbar, mul_nonneg (mul_nonneg hα1nn hcbar) (sub_nonneg.2 hk1)]

/-- **P6(v)**. -/
theorem p6v_convex (g : ℝ → ℝ) (π τ W d : ℝ) (hπ0 : 0 ≤ π) (hτ : 0 ≤ τ)
    (hW : 0 ≤ W) (hsub : ∀ x, 0 ≤ x → g τ + d * (x - τ) ≤ g x) :
    g (baseExposure τ) - g (holdExposure π τ W) = g τ - g (τ - (1 - π) * min W τ) ∧
      g τ - g (τ - (1 - π) * min W τ) ≤ (1 - π) * min W τ * d := by
  have hh : holdExposure π τ W = τ - (1 - π) * min W τ := by
    have := p6_pathwise_saving π τ W; unfold baseExposure at this; linarith
  refine ⟨by rw [hh]; rfl, ?_⟩
  have hw0 : 0 ≤ min W τ := le_min hW hτ
  have hwτ : min W τ ≤ τ := min_le_right _ _
  have hx : 0 ≤ τ - (1 - π) * min W τ := by nlinarith
  have := hsub _ hx
  linarith

/-- Convex harm: the saving in harm units is 19 and exceeds `g(min(W, τ)) = 1`. -/
theorem p6v_counterexample :
    let g : ℝ → ℝ := fun x => x ^ 2
    g (baseExposure 10) - g (holdExposure 0 10 1) = 19 ∧ g (min 1 10) < 19 := by
  intro g
  simp only [g, baseExposure, holdExposure]
  norm_num

/-- The truncated window `W_T = min(L, T)` (line 831). -/
theorem trunc_window {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (L : Ω → ℝ) (hL : Measurable L) (lam T τ : ℝ) (hlam : 0 < lam) (hT : 0 ≤ T) (hτ : 0 ≤ τ)
    (hsurv : ∀ t, 0 ≤ t → P {ω | t < L ω} = ENNReal.ofReal (Real.exp (-lam * t))) :
    ∫⁻ ω, ENNReal.ofReal (min (min (L ω) T) τ) ∂P
      = ENNReal.ofReal ((1 - Real.exp (-lam * min T τ)) / lam) := by
  simp_rw [min_assoc]
  exact p6ii_exp P L hL lam (min T τ) hlam (le_min hT hτ) hsurv

theorem trunc_window_eq_iff (lam T τ : ℝ) (hlam : 0 < lam) :
    (1 - Real.exp (-lam * min T τ)) / lam = m lam τ ↔ τ ≤ T := by
  unfold m
  constructor
  · intro h
    have h1 : Real.exp (-lam * min T τ) = Real.exp (-lam * τ) := by
      rw [div_left_inj' hlam.ne'] at h; linarith
    have h3 : min T τ = τ := mul_left_cancel₀ (neg_ne_zero.2 hlam.ne') (Real.exp_injective h1)
    exact min_eq_right_iff.1 h3
  · intro h; rw [min_eq_right h]

/-! ## P7 -/

/-- Exposure to a found-and-patched flaw: from the first usable exploit `min(P_f + ℓ_x, A)` to the
deployed fix `P_f + τ`, where `A` is the attackers' own discovery date. -/
def patchedExposure (Pf τ lx A : ℝ) : ℝ := max (Pf + τ - min (Pf + lx) A) 0

/-- Exposure to an unfound flaw: from the attackers' discovery `A` to the removal date `ζ`. -/
def unfoundExposure (ζ A : ℝ) : ℝ := max (ζ - A) 0

/-- A8 mixture under the hold: share `π` keeps the release-regime exposure. -/
def mixHold (π eRel eHold : ℝ) : ℝ := π * eRel + (1 - π) * eHold

theorem p7a_no_gain (Pf τ lx df W π : ℝ) (hW : 0 ≤ W) (hd : Pf + lx ≤ df) :
    patchedExposure Pf τ lx df = max (τ - lx) 0 ∧
      patchedExposure Pf τ lx (W + df) = max (τ - lx) 0 ∧
      mixHold π (patchedExposure Pf τ lx df) (patchedExposure Pf τ lx (W + df))
        = patchedExposure Pf τ lx df := by
  have h1 : min (Pf + lx) df = Pf + lx := min_eq_left hd
  have h2 : min (Pf + lx) (W + df) = Pf + lx := min_eq_left (by linarith)
  unfold patchedExposure mixHold
  rw [h1, h2]
  refine ⟨by ring_nf, by ring_nf, by ring⟩

theorem p7a_weak (Pf τ lx df W π : ℝ) (hW : 0 ≤ W) (hπ : π ≤ 1) :
    mixHold π (patchedExposure Pf τ lx df) (patchedExposure Pf τ lx (W + df))
      ≤ patchedExposure Pf τ lx df := by
  have hle : patchedExposure Pf τ lx (W + df) ≤ patchedExposure Pf τ lx df := by
    unfold patchedExposure
    exact max_le_max (by linarith [min_le_min_left (Pf + lx) (show df ≤ W + df by linarith)])
      le_rfl
  unfold mixHold
  nlinarith

theorem p7a_strict (Pf τ lx df W π : ℝ) (hπ : π < 1) (hW : 0 < W) (hd : df < Pf + lx)
    (hdτ : df < Pf + τ) :
    mixHold π (patchedExposure Pf τ lx df) (patchedExposure Pf τ lx (W + df))
      < patchedExposure Pf τ lx df := by
  have hrel : patchedExposure Pf τ lx df = Pf + τ - df := by
    unfold patchedExposure; rw [min_eq_right hd.le]; exact max_eq_left (by linarith)
  have hlt : patchedExposure Pf τ lx (W + df) < patchedExposure Pf τ lx df := by
    rw [hrel]; unfold patchedExposure
    have : df < min (Pf + lx) (W + df) := lt_min hd (by linarith)
    exact max_lt (by linarith) (by linarith)
  unfold mixHold
  nlinarith

theorem p7b_saving (ζ df W : ℝ) (hW : 0 ≤ W) :
    unfoundExposure ζ df - unfoundExposure ζ (W + df) = min W (max (ζ - df) 0) := by
  unfold unfoundExposure
  rcases le_total (ζ - df) 0 with h | h
  · rw [max_eq_right h, max_eq_right (by linarith), min_eq_right hW]; ring
  · rw [max_eq_left h]
    rcases le_total W (ζ - df) with h' | h'
    · rw [max_eq_left (by linarith), min_eq_left h']; ring
    · rw [max_eq_right (by linarith), min_eq_right h']; ring

theorem p7b_saving_mix (ζ df W π : ℝ) (hW : 0 ≤ W) :
    unfoundExposure ζ df - mixHold π (unfoundExposure ζ df) (unfoundExposure ζ (W + df))
      = (1 - π) * min W (max (ζ - df) 0) := by
  rw [← p7b_saving ζ df W hW]; unfold mixHold; ring

theorem p7b_bound (ζ df W π : ℝ) (hπ : π ≤ 1) (hd : 0 ≤ df) (hζ : 0 ≤ ζ) :
    (1 - π) * min W (max (ζ - df) 0) ≤ (1 - π) * min W ζ :=
  mul_le_mul_of_nonneg_left (min_le_min le_rfl (max_le (by linarith) hζ)) (by linarith)

theorem p7b_exp {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (W : Ω → ℝ) (hW : Measurable W) (π lam ζ df : ℝ) (hπ : π ≤ 1) (hlam : 0 < lam)
    (hsurv : ∀ t, 0 ≤ t → P {ω | t < W ω} = ENNReal.ofReal (Real.exp (-lam * t))) :
    ∫⁻ ω, ENNReal.ofReal ((1 - π) * (unfoundExposure ζ df - unfoundExposure ζ (W ω + df))) ∂P
      = ENNReal.ofReal ((1 - π) * ((1 - Real.exp (-lam * max (ζ - df) 0)) / lam)) := by
  have hpos := ae_pos_of_survival P W hW lam hsurv
  have hcongr : (fun ω => ENNReal.ofReal ((1 - π) *
      (unfoundExposure ζ df - unfoundExposure ζ (W ω + df))))
      =ᵐ[P] fun ω => ENNReal.ofReal (1 - π) * ENNReal.ofReal (min (W ω) (max (ζ - df) 0)) := by
    filter_upwards [hpos] with ω hω
    rw [p7b_saving ζ df (W ω) hω.le, ENNReal.ofReal_mul (by linarith)]
  rw [lintegral_congr_ae hcongr, lintegral_const_mul' _ _ ENNReal.ofReal_ne_top,
    p6ii_exp P W hW lam _ hlam (le_max_right _ _) hsurv, ← ENNReal.ofReal_mul (by linarith), m]

/-- Deployment completion when the tool is available from `t` (P7(c)). -/
def completion (Pf τ τ' t : ℝ) : ℝ := min (Pf + τ) (max Pf t + τ')

theorem completion_mono (Pf τ τ' : ℝ) : Monotone (completion Pf τ τ') := fun _ _ h =>
  min_le_min le_rfl (by linarith [max_le_max (le_refl Pf) h])

/-- Exposure of one flaw with fixed onset `O`. -/
def toolExposure (Pf τ τ' O t : ℝ) : ℝ := max (completion Pf τ τ' t - O) 0

theorem pos_part_strict_iff (a b O : ℝ) (hab : a ≤ b) :
    max (a - O) 0 < max (b - O) 0 ↔ a < b ∧ O < b := by
  constructor
  · intro h
    refine ⟨?_, ?_⟩
    · by_contra hc; push Not at hc
      have : a = b := le_antisymm hab hc
      rw [this] at h; exact lt_irrefl _ h
    · by_contra hc; push Not at hc
      rw [max_eq_right (by linarith : b - O ≤ 0)] at h
      exact absurd h (not_lt.2 (le_max_right _ _))
  · rintro ⟨h1, h2⟩
    rw [max_eq_left (by linarith : 0 ≤ b - O)]
    exact max_lt (by linarith) (by linarith)

/-- **P7(c)** for a finite set of flaws with nonnegative loss weights `v`. -/
theorem p7c_tool {ι : Type*} (s : Finset ι) (v Pf τ τ' O : ι → ℝ) (hv : ∀ f ∈ s, 0 ≤ v f)
    (t₁ t₂ : ℝ) (ht : t₁ ≤ t₂) :
    (∑ f ∈ s, v f * toolExposure (Pf f) (τ f) (τ' f) (O f) t₁
        ≤ ∑ f ∈ s, v f * toolExposure (Pf f) (τ f) (τ' f) (O f) t₂) ∧
    ((∑ f ∈ s, v f * toolExposure (Pf f) (τ f) (τ' f) (O f) t₁
        < ∑ f ∈ s, v f * toolExposure (Pf f) (τ f) (τ' f) (O f) t₂) ↔
      ∃ f ∈ s, 0 < v f ∧ completion (Pf f) (τ f) (τ' f) t₁ < completion (Pf f) (τ f) (τ' f) t₂ ∧
        O f < completion (Pf f) (τ f) (τ' f) t₂) := by
  have hmono : ∀ f, toolExposure (Pf f) (τ f) (τ' f) (O f) t₁
      ≤ toolExposure (Pf f) (τ f) (τ' f) (O f) t₂ := fun f =>
    max_le_max (by linarith [completion_mono (Pf f) (τ f) (τ' f) ht]) le_rfl
  have hterm : ∀ f ∈ s, v f * toolExposure (Pf f) (τ f) (τ' f) (O f) t₁
      ≤ v f * toolExposure (Pf f) (τ f) (τ' f) (O f) t₂ := fun f hf =>
    mul_le_mul_of_nonneg_left (hmono f) (hv f hf)
  refine ⟨Finset.sum_le_sum hterm, ⟨fun h => ?_, fun ⟨f, hf, hvf, h1, h2⟩ => ?_⟩⟩
  · by_contra hc
    push Not at hc
    have heq : ∀ f ∈ s, v f * toolExposure (Pf f) (τ f) (τ' f) (O f) t₁
        = v f * toolExposure (Pf f) (τ f) (τ' f) (O f) t₂ := by
      intro f hf
      rcases (hv f hf).lt_or_eq with hvf | hvf
      · have hnot : ¬ toolExposure (Pf f) (τ f) (τ' f) (O f) t₁
            < toolExposure (Pf f) (τ f) (τ' f) (O f) t₂ := by
          unfold toolExposure
          rw [pos_part_strict_iff _ _ _ (completion_mono _ _ _ ht)]
          rintro ⟨h1, h2⟩; exact absurd h2 (not_lt.2 (hc f hf hvf h1))
        rw [le_antisymm (hmono f) (not_lt.1 hnot)]
      · rw [← hvf]; ring
    rw [Finset.sum_congr rfl heq] at h
    exact lt_irrefl _ h
  · refine Finset.sum_lt_sum hterm ⟨f, hf, ?_⟩
    apply mul_lt_mul_of_pos_left _ hvf
    unfold toolExposure
    exact (pos_part_strict_iff _ _ _ (completion_mono _ _ _ ht)).2 ⟨h1, h2⟩

/-- A tool that does not shorten deployment (`τ' = τ`) changes nothing, whenever it is made
available: the "strictly worse off" reading is false. -/
theorem p7c_no_shortening (Pf τ O t₁ t₂ : ℝ) :
    toolExposure Pf τ τ O t₁ = toolExposure Pf τ τ O t₂ := by
  unfold toolExposure completion
  rw [min_eq_left (by linarith [le_max_left Pf t₁]), min_eq_left (by linarith [le_max_left Pf t₂])]

/-- If withholding delays exposure's onset and completion equally, undiscounted exposure is
unchanged and discounted exposure falls strictly. -/
theorem p7_shift_discount (a b δ r : ℝ) (hab : a < b) (hδ : 0 < δ) (hr : 0 < r) :
    ((b + δ) - (a + δ) = b - a) ∧
      (∫ t in (a + δ)..(b + δ), Real.exp (-r * t)) < ∫ t in a..b, Real.exp (-r * t) := by
  refine ⟨by ring, ?_⟩
  have hshift : (∫ t in (a + δ)..(b + δ), Real.exp (-r * t))
      = Real.exp (-r * δ) * ∫ t in a..b, Real.exp (-r * t) := by
    rw [← intervalIntegral.integral_comp_add_right (fun t => Real.exp (-r * t)) δ,
      ← intervalIntegral.integral_const_mul]
    congr 1; funext t; rw [← Real.exp_add]; ring_nf
  have hpos : 0 < ∫ t in a..b, Real.exp (-r * t) :=
    intervalIntegral.intervalIntegral_pos_of_pos_on
      ((by fun_prop : Continuous fun t : ℝ => Real.exp (-r * t)).intervalIntegrable _ _)
      (fun _ _ => Real.exp_pos _) hab
  have hlt : Real.exp (-r * δ) < 1 := by
    have := Real.exp_lt_exp.2 (show -r * δ < 0 by nlinarith); rwa [Real.exp_zero] at this
  rw [hshift]; nlinarith

/-- The opposing case: exploitation from 0 independently of publication, deployment at
publication. Delaying publication from 1 to 2 at `r = 1` raises discounted exposure. -/
theorem p7_delay_raises :
    (∫ t in (0:ℝ)..1, Real.exp (-1 * t)) = 1 - Real.exp (-1) ∧
      (∫ t in (0:ℝ)..2, Real.exp (-1 * t)) = 1 - Real.exp (-2) ∧
      1 - Real.exp (-1) < 1 - Real.exp (-2) := by
  refine ⟨?_, ?_, ?_⟩
  · rw [integral_exp_neg_mul 1 1 one_pos]; norm_num
  · rw [integral_exp_neg_mul 1 2 one_pos]; norm_num
  · have := Real.exp_lt_exp.2 (show (-2:ℝ) < -1 by norm_num); linarith

/-! ### The 100-flaw example -/

/-- Release: all attackers hold the capability at 0 (`λ = 3, π = 0.3, d_f = 0.2, ζ = 5,
P_f = 0.25, ℓ_x = 0.01, τ = 0.25`; 10 patched, 90 unfound). -/
noncomputable def releaseTotal : ℝ :=
  10 * patchedExposure 0.25 0.25 0.01 0.2 + 90 * unfoundExposure 5 0.2

/-- Hold, A8 mixture applied to every flaw. -/
noncomputable def holdTotal (W : ℝ) : ℝ :=
  10 * mixHold 0.3 (patchedExposure 0.25 0.25 0.01 0.2) (patchedExposure 0.25 0.25 0.01 (W + 0.2))
    + 90 * mixHold 0.3 (unfoundExposure 5 0.2) (unfoundExposure 5 (W + 0.2))

/-- Hold, alternative composition: patched flaws wholly excluded from attack during the hold. -/
noncomputable def holdTotalAlt (W : ℝ) : ℝ :=
  10 * patchedExposure 0.25 0.25 0.01 (W + 0.2)
    + 90 * mixHold 0.3 (unfoundExposure 5 0.2) (unfoundExposure 5 (W + 0.2))

theorem p7_release_total : releaseTotal = 435 := by
  unfold releaseTotal patchedExposure unfoundExposure
  norm_num [min_def, max_def]

theorem patched_ex (W : ℝ) :
    patchedExposure 0.25 0.25 0.01 (W + 0.2) = 0.3 - min W 0.06 := by
  unfold patchedExposure
  rcases le_total W 0.06 with h | h
  · rw [min_eq_right (by linarith : W + 0.2 ≤ 0.25 + 0.01), min_eq_left h,
      max_eq_left (by linarith)]; ring
  · rw [min_eq_left (by linarith : (0.25:ℝ) + 0.01 ≤ W + 0.2), min_eq_right h,
      max_eq_left (by norm_num)]; norm_num

theorem unfound_ex (W : ℝ) :
    unfoundExposure 5 (W + 0.2) = 4.8 - min W 4.8 := by
  unfold unfoundExposure
  rcases le_total W 4.8 with h | h
  · rw [min_eq_left h, max_eq_left (by linarith)]; ring
  · rw [min_eq_right h, max_eq_right (by linarith)]; ring

theorem holdTotal_eq (W : ℝ) :
    holdTotal W = 435 - 0.7 * (10 * min W 0.06 + 90 * min W 4.8) := by
  unfold holdTotal mixHold
  rw [patched_ex W, unfound_ex W]
  unfold patchedExposure unfoundExposure
  rw [min_eq_right (by norm_num : (0.2:ℝ) ≤ 0.25 + 0.01), max_eq_left (by norm_num : (0:ℝ) ≤ 0.25 + 0.25 - 0.2),
    max_eq_left (by norm_num : (0:ℝ) ≤ 5 - 0.2)]
  ring

theorem holdTotalAlt_eq (W : ℝ) :
    holdTotalAlt W = 435 - (10 * min W 0.06 + 0.7 * 90 * min W 4.8) := by
  unfold holdTotalAlt mixHold
  rw [patched_ex W, unfound_ex W]
  unfold unfoundExposure
  rw [max_eq_left (by norm_num : (0:ℝ) ≤ 5 - 0.2)]
  ring

theorem integrable_min {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (W : Ω → ℝ) (hW : Measurable W) (hpos : ∀ᵐ ω ∂P, 0 < W ω) (u : ℝ) (hu : 0 ≤ u) :
    Integrable (fun ω => min (W ω) u) P := by
  refine (integrable_const u).mono' (hW.min measurable_const).aestronglyMeasurable ?_
  filter_upwards [hpos] with ω hω
  rw [Real.norm_eq_abs, abs_of_nonneg (le_min hω.le hu)]
  exact min_le_right _ _

theorem p7_hold_expectation {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω)
    [IsProbabilityMeasure P] (W : Ω → ℝ) (hW : Measurable W)
    (hsurv : ∀ t, 0 ≤ t → P {ω | t < W ω} = ENNReal.ofReal (Real.exp (-3 * t))) :
    ∫ ω, holdTotal (W ω) ∂P = 435 - 0.7 * (10 * m 3 0.06 + 90 * m 3 4.8) ∧
      ∫ ω, holdTotalAlt (W ω) ∂P = 435 - (10 * m 3 0.06 + 0.7 * 90 * m 3 4.8) := by
  have hpos := ae_pos_of_survival P W hW 3 hsurv
  have i1 := integrable_min P W hW hpos 0.06 (by norm_num)
  have i2 := integrable_min P W hW hpos 4.8 (by norm_num)
  have e1 := p6ii_exp_real P W hW 3 0.06 (by norm_num) (by norm_num) hsurv
  have e2 := p6ii_exp_real P W hW 3 4.8 (by norm_num) (by norm_num) hsurv
  have i4 : Integrable (fun ω => 10 * min (W ω) 0.06) P := i1.const_mul 10
  have i5 : Integrable (fun ω => 90 * min (W ω) 4.8) P := i2.const_mul 90
  have i5' : Integrable (fun ω => 0.7 * 90 * min (W ω) 4.8) P := i2.const_mul (0.7 * 90)
  have i6 : Integrable (fun ω => 10 * min (W ω) 0.06 + 90 * min (W ω) 4.8) P := i4.add i5
  have i6' : Integrable (fun ω => 10 * min (W ω) 0.06 + 0.7 * 90 * min (W ω) 4.8) P := i4.add i5'
  have i7 : Integrable (fun ω => 0.7 * (10 * min (W ω) 0.06 + 90 * min (W ω) 4.8)) P :=
    i6.const_mul 0.7
  have hc : ∫ _ : Ω, (435:ℝ) ∂P = 435 := by simp
  constructor
  · simp_rw [holdTotal_eq]
    rw [integral_sub (integrable_const _) i7, integral_const_mul, integral_add i4 i5,
      integral_const_mul, integral_const_mul, e1, e2, hc]
  · simp_rw [holdTotalAlt_eq]
    rw [integral_sub (integrable_const _) i6', integral_add i4 i5', integral_const_mul,
      integral_const_mul, e1, e2, hc]

theorem exp_bounds_ex :
    0.830584 ≤ Real.exp (-3 * 0.06) ∧ Real.exp (-3 * 0.06) * 1.18 ≤ 1 ∧
      0 < Real.exp (-3 * 4.8) ∧ Real.exp (-3 * 4.8) * 2.8 ^ 8 ≤ 1 := by
  have h1 : Real.exp (-3 * 0.06) = Real.exp (-0.06) ^ 3 := by
    rw [← Real.exp_nat_mul]; norm_num
  have h2 := Real.add_one_le_exp (-0.06)
  have h3 := Real.add_one_le_exp (0.18)
  have h4 : Real.exp (-3 * 0.06) * Real.exp 0.18 = 1 := by
    rw [← Real.exp_add]; norm_num
  have h5 : Real.exp (-3 * 4.8) * Real.exp 1.8 ^ 8 = 1 := by
    rw [← Real.exp_nat_mul, ← Real.exp_add]; norm_num
  have h6 := Real.add_one_le_exp (1.8)
  have hp : 0 < Real.exp (-3 * 4.8) := Real.exp_pos _
  refine ⟨?_, ?_, hp, ?_⟩
  · rw [h1]
    have : (0.94:ℝ) ≤ Real.exp (-0.06) := by linarith
    calc (0.830584:ℝ) = 0.94 ^ 3 := by norm_num
      _ ≤ Real.exp (-0.06) ^ 3 := by gcongr
  · have hp' : 0 < Real.exp (-3 * 0.06) := Real.exp_pos _
    nlinarith
  · have h7 : (2.8:ℝ) ^ 8 ≤ Real.exp 1.8 ^ 8 := by gcongr; linarith
    nlinarith

/-- The hold values lie in `(413.6, 413.7)` and `(413.4, 413.5)`; both are below release, 435. -/
theorem p7_hold_bounds :
    413.6 < 435 - 0.7 * (10 * m 3 0.06 + 90 * m 3 4.8) ∧
      435 - 0.7 * (10 * m 3 0.06 + 90 * m 3 4.8) < 413.7 ∧
      413.4 < 435 - (10 * m 3 0.06 + 0.7 * 90 * m 3 4.8) ∧
      435 - (10 * m 3 0.06 + 0.7 * 90 * m 3 4.8) < 413.5 := by
  obtain ⟨a1, a2, b1, b2⟩ := exp_bounds_ex
  unfold m
  refine ⟨?_, ?_, ?_, ?_⟩ <;> nlinarith

/-! ### An exploit lag that shortens with the capability (lines 943, 1160, 1219) -/

/-- Lag rule (our specification; the paper does not give one): without the capability an
attacker exploits a patch after `ℓ₀`; once holding it (from `W`), after `ℓ₁ ≤ ℓ₀`, but never
before publication. Onset is the earliest of the two patch exploits and own discovery `W + d`. -/
def lagOnset (Pf l0 l1 df W : ℝ) : ℝ := min (min (Pf + l0) (max Pf W + l1)) (W + df)

theorem lagOnset_mono (Pf l0 l1 df : ℝ) : Monotone (lagOnset Pf l0 l1 df) := fun _ _ h =>
  min_le_min (min_le_min le_rfl (by linarith [max_le_max (le_refl Pf) h])) (by linarith)

theorem lagOnset_release (Pf l0 l1 df : ℝ) (hP : 0 ≤ Pf) (hl : l1 ≤ l0) :
    lagOnset Pf l0 l1 df 0 = min (Pf + l1) df := by
  unfold lagOnset
  rw [max_eq_left hP, min_eq_right (show Pf + l1 ≤ Pf + l0 by linarith), zero_add]

/-- With a shortening lag, a hold protects found-and-patched flaws, for at most the window. -/
theorem p7_lag_protects (Pf τ l0 l1 df W : ℝ) (hP : 0 ≤ Pf) (hW : 0 ≤ W) (hl : l1 ≤ l0) :
    let eRel := max (Pf + τ - lagOnset Pf l0 l1 df 0) 0
    let eHold := max (Pf + τ - lagOnset Pf l0 l1 df W) 0
    0 ≤ eRel - eHold ∧ eRel - eHold ≤ min W eRel := by
  intro eRel eHold
  have hmono := lagOnset_mono Pf l0 l1 df hW
  have hup : lagOnset Pf l0 l1 df W ≤ W + lagOnset Pf l0 l1 df 0 := by
    rw [lagOnset_release Pf l0 l1 df hP hl]
    unfold lagOnset
    have : max Pf W ≤ Pf + W := max_le (by linarith) (by linarith)
    rcases le_total (Pf + l1) df with h | h
    · rw [min_eq_left h]
      exact (min_le_left _ _).trans ((min_le_right _ _).trans (by linarith))
    · rw [min_eq_right h]; exact (min_le_right _ _).trans (by linarith)
  have h1 : eHold ≤ eRel := max_le_max (by linarith) le_rfl
  have h2 : eRel - eHold ≤ W := by
    have : eRel ≤ eHold + W := by
      apply max_le
      · linarith [le_max_left (Pf + τ - lagOnset Pf l0 l1 df W) 0]
      · linarith [le_max_right (Pf + τ - lagOnset Pf l0 l1 df W) 0]
    linarith
  have h3 : 0 ≤ eHold := le_max_right _ _
  exact ⟨by linarith, le_min h2 (by linarith)⟩

/-- Strictness witness: under the common lag (P7(a), `d_f ≥ P_f + ℓ_x`) the hold adds nothing,
but with `ℓ₁ = 0 < ℓ₀ = 1` it saves exactly the window `W = 1/2`. -/
theorem p7_lag_strict_example :
    patchedExposure 0 2 1 10 - patchedExposure 0 2 1 ((1/2) + 10) = 0 ∧
      max (0 + 2 - lagOnset 0 1 0 10 0) 0 - max (0 + 2 - lagOnset 0 1 0 10 (1/2)) 0 = 1/2 := by
  unfold patchedExposure lagOnset
  norm_num [min_def, max_def]

/-! ## P8 -/

/-- `m_λ(λ, τ)`. -/
noncomputable def mlam (l τ : ℝ) : ℝ := (l * τ * Real.exp (-l * τ) - (1 - Real.exp (-l * τ))) / l ^ 2

theorem hasDerivAt_m (l τ : ℝ) (hl : l ≠ 0) : HasDerivAt (fun y => m y τ) (mlam l τ) l := by
  have hnum : HasDerivAt (fun y => 1 - Real.exp (-y * τ)) (τ * Real.exp (-l * τ)) l := by
    have h1 : HasDerivAt (fun y => -y * τ) (-τ) l := by
      simpa using ((hasDerivAt_id l).neg).mul_const τ
    have := (h1.exp).const_sub 1
    convert this using 1; ring
  have := hnum.div (hasDerivAt_id l) hl
  have e : mlam l τ = (τ * Real.exp (-l * τ) * id l - (1 - Real.exp (-l * τ)) * 1) / id l ^ 2 := by
    simp only [mlam, id]; ring
  rw [e]; exact this

theorem mlam_neg (l τ : ℝ) (hl : 0 < l) (hτ : 0 < τ) : mlam l τ < 0 := by
  unfold mlam
  apply div_neg_of_neg_of_pos _ (by positivity)
  have hu : 0 < l * τ := mul_pos hl hτ
  have h1 := Real.add_one_lt_exp hu.ne'
  have h2 : Real.exp (-l * τ) * Real.exp (l * τ) = 1 := by rw [← Real.exp_add]; ring_nf; simp
  have h3 : 0 < Real.exp (-l * τ) := Real.exp_pos _
  nlinarith

theorem m_pos (l τ : ℝ) (hl : 0 < l) (hτ : 0 < τ) : 0 < m l τ := by
  unfold m
  apply div_pos _ hl
  have : Real.exp (-l * τ) < 1 := by
    have := Real.exp_lt_exp.2 (show -l * τ < 0 by nlinarith); rwa [Real.exp_zero] at this
  linarith

theorem m_strictAntiOn (τ : ℝ) (hτ : 0 < τ) : StrictAntiOn (fun l => m l τ) (Ioi 0) := by
  apply strictAntiOn_of_deriv_neg (convex_Ioi 0)
  · intro x hx; exact (hasDerivAt_m x τ (ne_of_gt hx)).continuousAt.continuousWithinAt
  · intro x hx
    rw [interior_Ioi] at hx
    rw [(hasDerivAt_m x τ (ne_of_gt hx)).deriv]
    exact mlam_neg x τ hx hτ

/-- `B(n) = (1 − π) Σ_j c_j(n) w_j m(λ(n), τ_j)`. -/
noncomputable def B {ι : Type*} (π : ℝ) (s : Finset ι) (c : ι → ℝ → ℝ) (w τ : ι → ℝ)
    (lam : ℝ → ℝ) (n : ℝ) : ℝ :=
  (1 - π) * ∑ j ∈ s, c j n * w j * m (lam n) (τ j)

/-- **P8(i)**. -/
theorem p8i_deriv {ι : Type*} (π : ℝ) (s : Finset ι) (c c' : ι → ℝ → ℝ) (w τ : ι → ℝ)
    (lam lam' : ℝ → ℝ) (n : ℝ) (hc : ∀ j ∈ s, HasDerivAt (c j) (c' j n) n)
    (hl : HasDerivAt lam (lam' n) n) (hpos : lam n ≠ 0) :
    HasDerivAt (B π s c w τ lam)
      ((1 - π) * ∑ j ∈ s, w j * (c' j n * m (lam n) (τ j)
        + c j n * mlam (lam n) (τ j) * lam' n)) n := by
  unfold B
  apply HasDerivAt.const_mul
  have : ∀ j ∈ s, HasDerivAt (fun y => c j y * w j * m (lam y) (τ j))
      (w j * (c' j n * m (lam n) (τ j) + c j n * mlam (lam n) (τ j) * lam' n)) n := by
    intro j hj
    have hm : HasDerivAt (fun y => m (lam y) (τ j)) (mlam (lam n) (τ j) * lam' n) n :=
      (hasDerivAt_m (lam n) (τ j) hpos).comp n hl
    convert ((hc j hj).mul_const (w j)).mul hm using 1
    ring
  exact HasDerivAt.fun_sum this

/-- **P8(ii)**, existence: `B′(0) > 0 > B′(N)` gives an interior maximum. -/
theorem p8ii_interior (f : ℝ → ℝ) (b0 bN N : ℝ) (hN : 0 < N)
    (hcont : ContinuousOn f (Icc 0 N)) (hd0 : HasDerivWithinAt f b0 (Icc 0 N) 0)
    (hdN : HasDerivWithinAt f bN (Icc 0 N) N) (h0 : 0 < b0) (hN' : bN < 0) :
    ∃ n ∈ Ioo 0 N, IsMaxOn f (Icc 0 N) n := by
  obtain ⟨n, hn, hmax⟩ := isCompact_Icc.exists_isMaxOn (nonempty_Icc.2 hN.le) hcont
  refine ⟨n, ⟨?_, ?_⟩, hmax⟩
  · rcases hn.1.lt_or_eq with h | h
    · exact h
    · exfalso
      subst h
      have hy : N ∈ posTangentConeAt (Icc 0 N) 0 :=
        mem_posTangentConeAt_of_segment_subset (by rw [zero_add, segment_eq_Icc hN.le])
      have := (hmax.isLocalMaxOn).hasFDerivWithinAt_nonpos hd0 hy
      simp at this
      nlinarith
  · rcases hn.2.lt_or_eq with h | h
    · exact h
    · exfalso
      subst h
      have hy : -n ∈ posTangentConeAt (Icc 0 n) n :=
        mem_posTangentConeAt_of_segment_subset (by
          rw [add_neg_cancel, segment_symm, segment_eq_Icc hN.le])
      have := (hmax.isLocalMaxOn).hasFDerivWithinAt_nonpos hdN hy
      simp at this
      nlinarith

/-- **P8(ii)**, uniqueness under the sign pattern `B′ > 0` on `[0, n*)`, `B′ < 0` on `(n*, N]`. -/
theorem p8ii_unique_signs (f f' : ℝ → ℝ) (N ns : ℝ) (hns : ns ∈ Icc 0 N)
    (hd : ∀ x ∈ Icc 0 N, HasDerivWithinAt f (f' x) (Icc 0 N) x)
    (hpos : ∀ x ∈ Ico 0 ns, 0 < f' x) (hneg : ∀ x ∈ Ioc ns N, f' x < 0) :
    IsMaxOn f (Icc 0 N) ns ∧ ∀ y ∈ Icc 0 N, IsMaxOn f (Icc 0 N) y → y = ns := by
  have hcont : ContinuousOn f (Icc 0 N) := fun x hx => (hd x hx).continuousWithinAt
  have hderiv : ∀ x ∈ Ioo 0 N, deriv f x = f' x := fun x hx =>
    ((hd x (Ioo_subset_Icc_self hx)).hasDerivAt (Icc_mem_nhds hx.1 hx.2)).deriv
  have hinc : StrictMonoOn f (Icc 0 ns) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc 0 ns)
      (hcont.mono (Icc_subset_Icc le_rfl hns.2))
    intro x hx
    rw [interior_Icc] at hx
    rw [hderiv x ⟨hx.1, hx.2.trans_le hns.2⟩]
    exact hpos x ⟨hx.1.le, hx.2⟩
  have hdec : StrictAntiOn f (Icc ns N) := by
    apply strictAntiOn_of_deriv_neg (convex_Icc ns N)
      (hcont.mono (Icc_subset_Icc hns.1 le_rfl))
    intro x hx
    rw [interior_Icc] at hx
    rw [hderiv x ⟨hns.1.trans_lt hx.1, hx.2⟩]
    exact hneg x ⟨hx.1, hx.2.le⟩
  have hlt : ∀ y ∈ Icc 0 N, y ≠ ns → f y < f ns := by
    intro y hy hne
    rcases lt_or_gt_of_ne hne with h | h
    · exact hinc ⟨hy.1, h.le⟩ ⟨hns.1, le_rfl⟩ h
    · exact hdec ⟨le_rfl, hns.2⟩ ⟨h.le, hy.2⟩ h
  refine ⟨fun y hy => ?_, fun y hy hmax => ?_⟩
  · show f y ≤ f ns
    by_cases h : y = ns
    · rw [h]
    · exact (hlt y hy h).le
  · by_contra h
    exact absurd (hmax hns) (not_le.2 (hlt y hy h))

/-- **P8(ii)**, uniqueness under strict concavity. -/
theorem p8ii_unique_concave (f : ℝ → ℝ) (N : ℝ) (hN : 0 ≤ N) (hcont : ContinuousOn f (Icc 0 N))
    (hconc : StrictConcaveOn ℝ (Icc 0 N) f) : ∃! n, n ∈ Icc 0 N ∧ IsMaxOn f (Icc 0 N) n := by
  obtain ⟨n, hn, hmax⟩ := isCompact_Icc.exists_isMaxOn (nonempty_Icc.2 hN) hcont
  refine ⟨n, ⟨hn, hmax⟩, fun y ⟨hy, hymax⟩ => ?_⟩
  by_contra hne
  have h := hconc.2 hy hn hne (by norm_num : (0:ℝ) < 1/2) (by norm_num : (0:ℝ) < 1/2)
    (by norm_num)
  have hmid : (1/2:ℝ) • y + (1/2:ℝ) • n ∈ Icc 0 N := (convex_Icc 0 N) hy hn (by norm_num)
    (by norm_num) (by norm_num)
  have h1 : f ((1/2:ℝ) * y + (1/2:ℝ) * n) ≤ f n := by
    have := hmax hmid; simpa [smul_eq_mul] using this
  have h2 : f n ≤ f y := hymax hn
  have h3 : f y ≤ f n := hmax hy
  simp only [smul_eq_mul] at h h1
  linarith

/-- **P8(iii)**, interior: `B(1) > B(0)` and `B(N − 1) > B(N)` exclude both corners. -/
theorem p8iii_interior (Bn : ℕ → ℝ) (N : ℕ) (h1 : Bn 0 < Bn 1) (h2 : Bn N < Bn (N - 1))
    (n : ℕ) (hn : n ≤ N) (hmax : ∀ k ≤ N, Bn k ≤ Bn n) : 0 < n ∧ n < N := by
  have hN : 1 ≤ N := by
    rcases Nat.eq_zero_or_pos N with h | h
    · subst h; simp at h2
    · exact h
  constructor
  · rcases Nat.eq_zero_or_pos n with h | h
    · subst h; exact absurd (hmax 1 hN) (not_le.2 h1)
    · exact h
  · rcases hn.lt_or_eq with h | h
    · exact h
    · subst h; exact absurd (hmax (n - 1) (Nat.sub_le n 1)) (not_le.2 h2)

theorem p8iii_exists (Bn : ℕ → ℝ) (N : ℕ) : ∃ n ≤ N, ∀ k ≤ N, Bn k ≤ Bn n := by
  obtain ⟨n, hn, h⟩ := (Finset.range (N + 1)).exists_max_image Bn ⟨0, by simp⟩
  exact ⟨n, Nat.lt_succ_iff.1 (Finset.mem_range.1 hn),
    fun k hk => h k (Finset.mem_range.2 (Nat.lt_succ_iff.2 hk))⟩

/-- **P8(iii)**: with strictly decreasing differences two maximizers are adjacent, with a zero
difference between them. -/
theorem p8iii_adjacent (Bn : ℕ → ℝ) (N : ℕ)
    (hdec : ∀ i j, i < j → j < N → Bn (j + 1) - Bn j < Bn (i + 1) - Bn i)
    (a b : ℕ) (hb : b ≤ N) (hma : ∀ k ≤ N, Bn k ≤ Bn a) (hmb : ∀ k ≤ N, Bn k ≤ Bn b)
    (hab : a < b) : b = a + 1 ∧ Bn (a + 1) - Bn a = 0 := by
  have hΔa : Bn (a + 1) - Bn a ≤ 0 := by linarith [hma (a + 1) (by omega)]
  have hΔb : 0 ≤ Bn (b - 1 + 1) - Bn (b - 1) := by
    rw [Nat.sub_add_cancel (by omega)]; linarith [hmb (b - 1) (by omega)]
  have hba : b = a + 1 := by
    by_contra hne
    have := hdec a (b - 1) (by omega) (by omega)
    linarith
  refine ⟨hba, ?_⟩
  rw [← hba]; linarith [hma b hb, hmb a (by omega)]

theorem p8iii_at_most_two (Bn : ℕ → ℝ) (N : ℕ)
    (hdec : ∀ i j, i < j → j < N → Bn (j + 1) - Bn j < Bn (i + 1) - Bn i)
    (a b c : ℕ) (hc : c ≤ N) (hma : ∀ k ≤ N, Bn k ≤ Bn a) (hmb : ∀ k ≤ N, Bn k ≤ Bn b)
    (hmc : ∀ k ≤ N, Bn k ≤ Bn c) (hab : a < b) (hbc : b < c) : False := by
  have h1 := (p8iii_adjacent Bn N hdec a b (by omega) hma hmb hab).1
  have h2 := (p8iii_adjacent Bn N hdec a c hc hma hmc (by omega)).1
  omega

theorem p8iii_unique (Bn : ℕ → ℝ) (N : ℕ)
    (hdec : ∀ i j, i < j → j < N → Bn (j + 1) - Bn j < Bn (i + 1) - Bn i)
    (hnz : ∀ i < N, Bn (i + 1) - Bn i ≠ 0)
    (a b : ℕ) (ha : a ≤ N) (hb : b ≤ N) (hma : ∀ k ≤ N, Bn k ≤ Bn a)
    (hmb : ∀ k ≤ N, Bn k ≤ Bn b) : a = b := by
  rcases lt_trichotomy a b with h | h | h
  · obtain ⟨h1, h2⟩ := p8iii_adjacent Bn N hdec a b hb hma hmb h
    exact absurd h2 (hnz a (by omega))
  · exact h
  · obtain ⟨h1, h2⟩ := p8iii_adjacent Bn N hdec b a ha hmb hma h
    exact absurd h2 (hnz b (by omega))

/-- The tie example `B = (1, 2, 2, 1)`. -/
def tieB : ℕ → ℝ
  | 0 => 1
  | 1 => 2
  | 2 => 2
  | _ => 1

theorem p8iii_tie_example :
    (∀ i j, i < j → j < 3 → tieB (j + 1) - tieB j < tieB (i + 1) - tieB i) ∧
      tieB 0 < tieB 1 ∧ tieB 3 < tieB (3 - 1) ∧
      (∀ k ≤ 3, tieB k ≤ tieB 1) ∧ (∀ k ≤ 3, tieB k ≤ tieB 2) := by
  refine ⟨?_, by norm_num [tieB], by norm_num [tieB], ?_, ?_⟩
  · intro i j hij hj
    interval_cases j <;> interval_cases i <;> norm_num [tieB]
  · intro k hk; interval_cases k <;> norm_num [tieB]
  · intro k hk; interval_cases k <;> norm_num [tieB]

/-- **P8(iv)**, the rival rule: with coverage, deployment, access and beneficiaries fixed,
`B` rises iff `λ` falls. -/
theorem p8iv_rival {ι : Type*} (π : ℝ) (s : Finset ι) (c w τ : ι → ℝ) (hπ : π < 1)
    (hc : ∀ j ∈ s, 0 ≤ c j) (hw : ∀ j ∈ s, 0 ≤ w j) (hτ : ∀ j ∈ s, 0 ≤ τ j)
    (hcov : 0 < ∑ j ∈ s, c j * w j * τ j) (l0 l1 : ℝ) (hl0 : 0 < l0) (hl1 : 0 < l1) :
    (1 - π) * ∑ j ∈ s, c j * w j * m l0 (τ j) < (1 - π) * ∑ j ∈ s, c j * w j * m l1 (τ j)
      ↔ l1 < l0 := by
  have h1π : 0 < 1 - π := by linarith
  have hanti : ∀ a b, 0 < a → 0 < b → a ≤ b →
      ∑ j ∈ s, c j * w j * m b (τ j) ≤ ∑ j ∈ s, c j * w j * m a (τ j) := by
    intro a b ha hb hab
    apply Finset.sum_le_sum
    intro j hj
    apply mul_le_mul_of_nonneg_left _ (mul_nonneg (hc j hj) (hw j hj))
    rcases (hτ j hj).lt_or_eq with h | h
    · exact (m_strictAntiOn (τ j) h).antitoneOn ha hb hab
    · rw [← h]; simp [m]
  constructor
  · intro h
    by_contra hle
    push Not at hle
    have := mul_le_mul_of_nonneg_left (hanti l0 l1 hl0 hl1 hle) h1π.le
    linarith
  · intro h
    apply mul_lt_mul_of_pos_left _ h1π
    obtain ⟨j, hj, hjpos⟩ : ∃ j ∈ s, 0 < c j * w j * τ j := by
      by_contra hne
      push Not at hne
      exact absurd hcov (not_lt.2 (Finset.sum_nonpos hne))
    have hτj : 0 < τ j := by
      rcases (hτ j hj).lt_or_eq with h' | h'
      · exact h'
      · rw [← h'] at hjpos; simp at hjpos
    have hcw : 0 < c j * w j := by
      by_contra hcw; push Not at hcw
      have := mul_nonpos_of_nonpos_of_nonneg hcw hτj.le; linarith
    refine Finset.sum_lt_sum (fun i hi => ?_) ⟨j, hj, ?_⟩
    · apply mul_le_mul_of_nonneg_left _ (mul_nonneg (hc i hi) (hw i hi))
      rcases (hτ i hi).lt_or_eq with h' | h'
      · exact (m_strictAntiOn (τ i) h').antitoneOn hl1 hl0 h.le
      · rw [← h']; simp [m]
    · exact mul_lt_mul_of_pos_left (m_strictAntiOn (τ j) hτj hl1 hl0 h) hcw

theorem p8iv_rival_hazards {ι : Type*} (π : ℝ) (s : Finset ι) (c w τ : ι → ℝ) (hπ : π < 1)
    (hc : ∀ j ∈ s, 0 ≤ c j) (hw : ∀ j ∈ s, 0 ≤ w j) (hτ : ∀ j ∈ s, 0 ≤ τ j)
    (hcov : 0 < ∑ j ∈ s, c j * w j * τ j) (l0 removed added : ℝ) (hl0 : 0 < l0)
    (hl1 : 0 < l0 - removed + added) :
    (1 - π) * ∑ j ∈ s, c j * w j * m l0 (τ j)
        < (1 - π) * ∑ j ∈ s, c j * w j * m (l0 - removed + added) (τ j)
      ↔ added < removed := by
  rw [p8iv_rival π s c w τ hπ hc hw hτ hcov l0 _ hl0 hl1]
  constructor <;> intro h <;> linarith

/-! ### Examples -/

/-- Corner (b): coverage `n`, `λ = 1 + 0.01n` on `[0, 1]` (one operator, weight 1, `π = 0`):
`B` is strictly increasing for every deployment time `τ > 0`, so `N = 1` is the unique best. -/
theorem p8_corner_full (τ : ℝ) (hτ : 0 < τ) :
    StrictMonoOn (fun n : ℝ => n * m (1 + 0.01 * n) τ) (Icc 0 1) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc 0 1)
  · intro x hx
    have hl : 0 < 1 + 0.01 * x := by linarith [hx.1]
    exact ((hasDerivAt_id x).mul ((hasDerivAt_m _ τ hl.ne').comp x
      (((hasDerivAt_id x).const_mul 0.01).const_add 1))).continuousAt.continuousWithinAt
  · intro x hx
    rw [interior_Icc] at hx
    have hl : 0 < 1 + 0.01 * x := by linarith [hx.1]
    have h2raw := (hasDerivAt_m _ τ hl.ne').comp x
      (((hasDerivAt_id x).const_mul 0.01).const_add 1)
    have h2 : HasDerivAt (fun n : ℝ => m (1 + 0.01 * n) τ)
        (mlam (1 + 0.01 * x) τ * (0.01 * 1)) x := h2raw
    have hD : HasDerivAt (fun n : ℝ => n * m (1 + 0.01 * n) τ)
        (1 * m (1 + 0.01 * x) τ + x * (mlam (1 + 0.01 * x) τ * (0.01 * 1))) x :=
      (hasDerivAt_id x).mul h2
    rw [hD.deriv]
    simp only [one_mul, mul_one]
    set l := 1 + 0.01 * x with hldef
    have hmp := m_pos l τ hl hτ
    have hmlam : -(m l τ) / l < mlam l τ := by
      unfold mlam m
      rw [neg_div, div_div, ← sq, neg_lt, ← neg_div]
      apply div_lt_div_of_pos_right _ (by positivity)
      have : 0 < l * τ * Real.exp (-l * τ) := by positivity
      linarith
    have h1 : 0.01 * x < l := by linarith
    have hx0 : 0 < x := hx.1
    have key : m l τ * (1 - 0.01 * x / l) ≤ m l τ + x * (mlam l τ * 0.01) := by
      have : x * 0.01 * (-(m l τ) / l) ≤ x * 0.01 * mlam l τ :=
        mul_le_mul_of_nonneg_left hmlam.le (by positivity)
      have e : m l τ * (1 - 0.01 * x / l) = m l τ + x * 0.01 * (-(m l τ) / l) := by
        field_simp; ring
      rw [e]; linarith
    have : 0 < 1 - 0.01 * x / l := by rw [sub_pos, div_lt_one hl]; exact h1
    nlinarith [mul_pos hmp this]

theorem exp_neg_one_lt : Real.exp (-1) < 0.3679 := by
  have h := Real.exp_one_gt_d9
  have : Real.exp (-1) * Real.exp 1 = 1 := by rw [← Real.exp_add]; simp
  nlinarith [Real.exp_pos (-1)]

/-- `(1 + λ)e^{−λ} ≤ 2/e` for `λ ≥ 1`. -/
theorem one_add_mul_exp_neg_le (l : ℝ) (hl : 1 ≤ l) :
    (1 + l) * Real.exp (-l) ≤ 2 * Real.exp (-1) := by
  have h1 : l ≤ Real.exp (l - 1) := by linarith [Real.add_one_le_exp (l - 1)]
  have h2 : Real.exp (-l) * Real.exp (l - 1) = Real.exp (-1) := by rw [← Real.exp_add]; ring_nf
  have h3 : 0 < Real.exp (-l) := Real.exp_pos _
  nlinarith

/-- Corner (c): the holder's own systems covered at `n = 0` (weight 1, `τ = 1`), partners adding
coverage `0.01n` (weight 1, `τ = 1`), `λ = 1 + n` on `[0, 10]`, `π = 0`: `B` is strictly
decreasing, so the empty coalition is the unique best. -/
theorem p8_corner_empty :
    StrictAntiOn (fun n : ℝ => 1 * 1 * m (1 + n) 1 + 0.01 * n * 1 * m (1 + n) 1) (Icc 0 10) := by
  have hform : ∀ n : ℝ, 1 * 1 * m (1 + n) 1 + 0.01 * n * 1 * m (1 + n) 1
      = (1 + 0.01 * n) * m (1 + n) 1 := fun n => by ring
  simp_rw [hform]
  apply strictAntiOn_of_deriv_neg (convex_Icc 0 10)
  · intro x hx
    have hl : 0 < 1 + x := by linarith [hx.1]
    exact ((((hasDerivAt_id x).const_mul 0.01).const_add 1).mul ((hasDerivAt_m _ 1 hl.ne').comp x
      ((hasDerivAt_id x).const_add 1))).continuousAt.continuousWithinAt
  · intro x hx
    rw [interior_Icc] at hx
    have hl : 0 < 1 + x := by linarith [hx.1]
    have hD : HasDerivAt (fun n : ℝ => (1 + 0.01 * n) * m (1 + n) 1)
        (0.01 * 1 * m (1 + x) 1 + (1 + 0.01 * x) * (mlam (1 + x) 1 * 1)) x :=
      (((hasDerivAt_id x).const_mul 0.01).const_add 1).mul
        ((hasDerivAt_m _ 1 hl.ne').comp x ((hasDerivAt_id x).const_add 1))
    rw [hD.deriv]
    simp only [mul_one]
    set l := 1 + x with hldef
    have hl1 : 1 ≤ l := by linarith [hx.1]
    have hl11 : l ≤ 11 := by linarith [hx.2]
    have hb := one_add_mul_exp_neg_le l hl1
    have he := exp_neg_one_lt
    have hm : m l 1 ≤ 1 / l := by
      unfold m
      simp only [mul_one]
      exact div_le_div_of_nonneg_right (by linarith [Real.exp_pos (-l)]) (by linarith)
    have hml : mlam l 1 ≤ -0.264 / l ^ 2 := by
      unfold mlam
      simp only [mul_one]
      apply div_le_div_of_nonneg_right _ (by positivity)
      nlinarith
    have hl2 : 0 < l ^ 2 := by positivity
    have hA : 0.01 * m l 1 ≤ 0.01 / l := by
      have := mul_le_mul_of_nonneg_left hm (by norm_num : (0:ℝ) ≤ 0.01)
      rwa [mul_one_div] at this
    have hB : (1 + 0.01 * x) * mlam l 1 ≤ (1 + 0.01 * x) * (-0.264 / l ^ 2) :=
      mul_le_mul_of_nonneg_left hml (by linarith [hx.1])
    have hC : (1 + 0.01 * x) * (-0.264 / l ^ 2) ≤ -0.264 / l ^ 2 := by
      have : -0.264 / l ^ 2 ≤ 0 := div_nonpos_of_nonpos_of_nonneg (by norm_num) hl2.le
      nlinarith [hx.1]
    have hD' : 0.01 / l < 0.264 / l ^ 2 := by
      rw [div_lt_div_iff₀ (by linarith) hl2]; nlinarith
    have : -0.264 / l ^ 2 = -(0.264 / l ^ 2) := neg_div _ _
    linarith

/-- The corner-(c) conclusion depends on the unstated `τ = 1`: at `τ = 0.01` the full coalition
`n = 10` beats the empty one. -/
theorem p8_corner_empty_needs_tau :
    1 * 1 * m (1 + 0) 0.01 + 0.01 * 0 * 1 * m (1 + 0) 0.01
      < 1 * 1 * m (1 + 10) 0.01 + 0.01 * 10 * 1 * m (1 + 10) 0.01 := by
  unfold m
  have h1 := Real.add_one_le_exp (-(1 + 0) * 0.01)
  have h2 := Real.quadratic_le_exp_of_nonneg (show (0:ℝ) ≤ 0.11 by norm_num)
  have h3 : Real.exp (-(1 + 10) * 0.01) * Real.exp 0.11 = 1 := by
    rw [← Real.exp_add]; norm_num
  have h4 : 0 < Real.exp (-(1 + 10) * 0.01) := Real.exp_pos _
  norm_num at h1 h2 h3 h4 ⊢
  nlinarith

/-- The rival's own systems: admitting the rival raises net hazard from 1.0 to 1.1, yet `B` rises
(holder's operator coverage 0.8, `τ = 1`; rival's own systems coverage 1, `τ = 0.5`). -/
theorem p8_rival_own_systems :
    (1:ℝ) < 1.1 ∧ 0.8 * 1 * m 1 1 < 0.8 * 1 * m 1.1 1 + 1 * 1 * m 1.1 0.5 := by
  refine ⟨by norm_num, ?_⟩
  unfold m
  have h1 : Real.exp (-1.1 * 1) * Real.exp 1.1 = 1 := by rw [← Real.exp_add]; norm_num
  have h2 : Real.exp (-1.1 * 0.5) * Real.exp 0.55 = 1 := by rw [← Real.exp_add]; norm_num
  have h3 := Real.add_one_le_exp 1.1
  have h4 := Real.add_one_le_exp 0.55
  have h5 := exp_neg_one_lt
  have h6 : 0 < Real.exp (-1.1 * 1) := Real.exp_pos _
  have h7 : 0 < Real.exp (-1.1 * 0.5) := Real.exp_pos _
  have h8 : Real.exp (-1 * 1) = Real.exp (-1) := by norm_num
  rw [h8]
  have hA : Real.exp (-1.1 * 1) ≤ 1 / 2.1 := by
    rw [le_div_iff₀ (by norm_num)]; nlinarith
  have hB : Real.exp (-1.1 * 0.5) ≤ 1 / 1.55 := by
    rw [le_div_iff₀ (by norm_num)]; nlinarith
  have hC : 0.3678 < Real.exp (-1) := by
    have he := Real.exp_one_lt_d9
    have h : Real.exp (-1) * Real.exp 1 = 1 := by rw [← Real.exp_add]; simp
    nlinarith [Real.exp_pos (-1)]
  rw [div_one]
  have e1 : 0.8 * 1 * ((1 - Real.exp (-1.1 * 1)) / 1.1) + 1 * 1 * ((1 - Real.exp (-1.1 * 0.5)) / 1.1)
      = (1.8 - 0.8 * Real.exp (-1.1 * 1) - Real.exp (-1.1 * 0.5)) / 1.1 := by ring
  rw [e1, lt_div_iff₀ (by norm_num)]
  norm_num at hA hB ⊢
  nlinarith

/-- The interior example (A.6 table): `c(n) = 1 − e^{−n}`, weight 1, `τ = 3`,
`λ(n) = 0.5 + 0.3n`, `π = 0`, `N = 10`. -/
noncomputable def Bint (n : ℝ) : ℝ := (1 - Real.exp (-n)) * 1 * m (0.5 + 0.3 * n) 3

noncomputable def Bint' (n : ℝ) : ℝ :=
  1 * (Real.exp (-n) * m (0.5 + 0.3 * n) 3 + (1 - Real.exp (-n)) * mlam (0.5 + 0.3 * n) 3 * 0.3)

theorem Bint_hasDerivAt (n : ℝ) (hn : 0 ≤ n) : HasDerivAt Bint (Bint' n) n := by
  have hl : 0 < 0.5 + 0.3 * n := by linarith
  have hc : HasDerivAt (fun y => 1 - Real.exp (-y)) (Real.exp (-n)) n := by
    have := ((hasDerivAt_neg n).exp).const_sub 1
    convert this using 1; ring
  have hlam : HasDerivAt (fun y : ℝ => 0.5 + 0.3 * y) 0.3 n := by
    simpa using ((hasDerivAt_id n).const_mul 0.3).const_add 0.5
  have := p8i_deriv 0 {()} (fun _ y => 1 - Real.exp (-y)) (fun _ y => Real.exp (-y))
    (fun _ => 1) (fun _ => 3) (fun y => 0.5 + 0.3 * y) (fun _ => 0.3) n
    (fun _ _ => hc) hlam hl.ne'
  unfold B at this
  simp only [Finset.sum_singleton, sub_zero, one_mul] at this
  unfold Bint Bint'
  convert this using 1
  ring

theorem p8_interior_example_signs : 0 < Bint' 0 ∧ Bint' 10 < 0 := by
  constructor
  · unfold Bint'
    simp only [neg_zero, Real.exp_zero, sub_self, zero_mul, add_zero, one_mul, mul_zero]
    exact m_pos _ _ (by norm_num) (by norm_num)
  · unfold Bint' m mlam
    have he1 := Real.exp_one_gt_d9
    have h10 : Real.exp (-10) * Real.exp 1 ^ 10 = 1 := by
      rw [← Real.exp_nat_mul, ← Real.exp_add]; norm_num
    have hpow : (2.7:ℝ) ^ 10 ≤ Real.exp 1 ^ 10 := by gcongr; linarith
    have hp10 : 0 < Real.exp (-10) := Real.exp_pos _
    have hE10 : Real.exp (-10) ≤ 1 / 2.7 ^ 10 := by
      rw [le_div_iff₀ (by norm_num)]; nlinarith
    have hx : (0.5:ℝ) + 0.3 * 10 = 3.5 := by norm_num
    rw [hx]
    have hq : Real.exp (-3.5 * 3) ≤ Real.exp (-10) := Real.exp_le_exp.2 (by norm_num)
    have hq0 : 0 < Real.exp (-3.5 * 3) := Real.exp_pos _
    have hq1 : Real.exp (-3.5 * 3) ≤ 1 := by linarith [hE10]
    norm_num at hE10 ⊢
    nlinarith

theorem p8_interior_example_exists : ∃ n ∈ Ioo (0:ℝ) 10, IsMaxOn Bint (Icc 0 10) n :=
  p8ii_interior Bint (Bint' 0) (Bint' 10) 10 (by norm_num)
    (fun x hx => (Bint_hasDerivAt x hx.1).continuousAt.continuousWithinAt)
    (Bint_hasDerivAt 0 le_rfl).hasDerivWithinAt (Bint_hasDerivAt 10 (by norm_num)).hasDerivWithinAt
    p8_interior_example_signs.1 p8_interior_example_signs.2

theorem exp_neg_two_lt : Real.exp (-2) < 1 / 7.389 := by
  have he := Real.exp_one_gt_d9
  have h : Real.exp (-2) * Real.exp 1 ^ 2 = 1 := by
    rw [← Real.exp_nat_mul, ← Real.exp_add]; norm_num
  have h2 : (7.389:ℝ) < Real.exp 1 ^ 2 := by nlinarith
  have hp := Real.exp_pos (-2)
  rw [lt_div_iff₀ (by norm_num)]
  nlinarith

theorem exp_neg_three_lt : Real.exp (-3) < 1 / 20.085 := by
  have he := Real.exp_one_gt_d9
  have h : Real.exp (-3) * Real.exp 1 ^ 3 = 1 := by
    rw [← Real.exp_nat_mul, ← Real.exp_add]; norm_num
  have h2 : (20.085:ℝ) < Real.exp 1 ^ 3 := by
    have : (2.71828:ℝ) ^ 3 ≤ Real.exp 1 ^ 3 := by gcongr; linarith
    nlinarith
  have hp := Real.exp_pos (-3)
  rw [lt_div_iff₀ (by norm_num)]
  nlinarith

theorem exp_neg_one_gt : 0.3678 < Real.exp (-1) := by
  have he := Real.exp_one_lt_d9
  have h : Real.exp (-1) * Real.exp 1 = 1 := by rw [← Real.exp_add]; simp
  nlinarith [Real.exp_pos (-1)]

theorem Bint_one_lt : Bint 1 < 0.7262 := by
  unfold Bint m
  rw [show -(0.5 + 0.3 * (1:ℝ)) * 3 = -2.4 by norm_num, show (0.5 + 0.3 * (1:ℝ)) = 0.8 by norm_num,
    mul_one, mul_div_assoc', div_lt_iff₀ (by norm_num)]
  have ha := exp_neg_one_gt
  have hb : 0.0865 < Real.exp (-2.4) := by
    have e : Real.exp (-2.4) = Real.exp (-0.2) ^ 2 * Real.exp (-1) * Real.exp (-1) := by
      rw [← Real.exp_nat_mul, ← Real.exp_add, ← Real.exp_add]; norm_num
    have h02 : (0.8:ℝ) ≤ Real.exp (-0.2) := by linarith [Real.add_one_le_exp (-0.2)]
    have h04 : (0.64:ℝ) ≤ Real.exp (-0.2) ^ 2 := by nlinarith
    rw [e]
    have : (0.64:ℝ) * 0.3678 ≤ Real.exp (-0.2) ^ 2 * Real.exp (-1) :=
      mul_le_mul h04 ha.le (by norm_num) (by positivity)
    nlinarith
  have hb1 : Real.exp (-2.4) < 1 := by
    have := Real.exp_lt_exp.2 (show (-2.4:ℝ) < 0 by norm_num); rwa [Real.exp_zero] at this
  have ha1 : Real.exp (-1) < 1 := by
    have := Real.exp_lt_exp.2 (show (-1:ℝ) < 0 by norm_num); rwa [Real.exp_zero] at this
  have : (1 - Real.exp (-1)) * (1 - Real.exp (-2.4)) ≤ (1 - 0.3678) * (1 - 0.0865) :=
    mul_le_mul (by linarith) (by linarith) (by linarith) (by norm_num)
  linarith

theorem Bint_two_gt : 0.746 < Bint 2 := by
  unfold Bint m
  rw [show -(0.5 + 0.3 * (2:ℝ)) * 3 = -3.3 by norm_num, show (0.5 + 0.3 * (2:ℝ)) = 1.1 by norm_num,
    mul_one, mul_div_assoc', lt_div_iff₀ (by norm_num)]
  have ha := exp_neg_two_lt
  have hb : Real.exp (-3.3) < 1 / 20.085 :=
    lt_of_le_of_lt (Real.exp_le_exp.2 (by norm_num)) exp_neg_three_lt
  have p1 : (0.8646:ℝ) < 1 - Real.exp (-2) := by
    have : (1:ℝ) / 7.389 < 0.1354 := by norm_num
    linarith
  have p2 : (0.9502:ℝ) < 1 - Real.exp (-3.3) := by
    have : (1:ℝ) / 20.085 < 0.0498 := by norm_num
    linarith
  have := mul_lt_mul'' p1 p2 (by norm_num) (by norm_num)
  linarith

/-- Integer maximizer of the interior example is 2. -/
theorem p8_interior_example_integer :
    ∀ k : ℕ, k ≤ 10 → k ≠ 2 → Bint k < Bint 2 := by
  have hB2 := Bint_two_gt
  intro k hk hk2
  rcases Nat.lt_or_ge k 3 with h | h
  · interval_cases k
    · have h0 : Bint ((0:ℕ):ℝ) = 0 := by unfold Bint; simp
      linarith
    · have := Bint_one_lt; push_cast; linarith
    · exact absurd rfl hk2
  · have hk3 : (3:ℝ) ≤ k := by exact_mod_cast h
    have hl : 0 < 0.5 + 0.3 * (k:ℝ) := by linarith
    have hle : Bint k ≤ 1 / (0.5 + 0.3 * k) := by
      unfold Bint
      have hm := (m_le (0.5 + 0.3 * k) 3 hl).trans (min_le_left _ _)
      have hm0 := m_nonneg (0.5 + 0.3 * k) 3 hl (by norm_num)
      have hc0 : 0 ≤ 1 - Real.exp (-(k:ℝ)) := by
        have := Real.exp_le_one_iff.2 (show -(k:ℝ) ≤ 0 by linarith); linarith
      have hc1 : 1 - Real.exp (-(k:ℝ)) ≤ 1 := by linarith [Real.exp_pos (-(k:ℝ))]
      rw [mul_one]
      calc (1 - Real.exp (-(k:ℝ))) * m (0.5 + 0.3 * k) 3 ≤ 1 * m (0.5 + 0.3 * k) 3 :=
            mul_le_mul_of_nonneg_right hc1 hm0
        _ ≤ 1 / (0.5 + 0.3 * k) := by rw [one_mul]; exact hm
    have : 1 / (0.5 + 0.3 * (k:ℝ)) ≤ 1 / 1.4 :=
      one_div_le_one_div_of_le (by norm_num) (by linarith)
    have : (1:ℝ) / 1.4 < 0.746 := by norm_num
    linarith

/-! ## P6, remaining parts -/

/-- **P6, leading identity**: for any window law, a covered operator's expected saving is
`(1 − π) E[min(W, τ)]`. -/
theorem p6_saving_general {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) (W : Ω → ℝ)
    (π τ : ℝ) (hπ : π ≤ 1) :
    ∫⁻ ω, ENNReal.ofReal (baseExposure τ - holdExposure π τ (W ω)) ∂P
      = ENNReal.ofReal (1 - π) * ∫⁻ ω, ENNReal.ofReal (min (W ω) τ) ∂P := by
  simp_rw [p6_pathwise_saving, ENNReal.ofReal_mul (sub_nonneg.2 hπ)]
  rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]

/-- Survival on a restricted measure, in the form the layer-cake core needs. -/
theorem restrict_survival {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω) (S : Set Ω)
    (W : Ω → ℝ) (hW : Measurable W) (a lam τ : ℝ)
    (h : ∀ t, 0 ≤ t → P (S ∩ {ω | t < W ω}) = ENNReal.ofReal (a * Real.exp (-lam * t))) :
    ∀ t, 0 < t → t < τ → P.restrict S {ω | t < W ω} = ENNReal.ofReal (a * Real.exp (-lam * t)) := by
  intro t ht _
  rw [Measure.restrict_apply (measurableSet_lt measurable_const hW), inter_comm, h t ht.le]

/-- Without A9 the factorization fails: if covered operators face a window of rate 2 and the rest
rate 1/2 (coverage 1/2, `τ = 2`, `π = 0`), the expected saving is `(1/2) m(2, 2) ≈ 0.245`, while the
factorized `c E[min(W, τ)]` is `≈ 0.439`. -/
theorem p6_factorization_needs_A9 {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω)
    [IsProbabilityMeasure P] (Cov : Set Ω) (hCov : MeasurableSet Cov) (W : Ω → ℝ)
    (hW : Measurable W) (hWnn : ∀ ω, 0 ≤ W ω) (hc : P Cov = ENNReal.ofReal (1 / 2))
    (h1 : ∀ t, 0 ≤ t → P (Cov ∩ {ω | t < W ω}) = ENNReal.ofReal (1 / 2 * Real.exp (-2 * t)))
    (h0 : ∀ t, 0 ≤ t →
      P (Covᶜ ∩ {ω | t < W ω}) = ENNReal.ofReal (1 / 2 * Real.exp (-(1 / 2) * t))) :
    ∫⁻ ω, Cov.indicator (1 : Ω → ℝ≥0∞) ω * ENNReal.ofReal (min (W ω) 2) ∂P
        = ENNReal.ofReal (1 / 2 * m 2 2) ∧
      P Cov * ∫⁻ ω, ENNReal.ofReal (min (W ω) 2) ∂P
        = ENNReal.ofReal (1 / 2 * (1 / 2 * m 2 2 + 1 / 2 * m (1 / 2) 2)) ∧
      1 / 2 * m 2 2 < 1 / 2 * (1 / 2 * m 2 2 + 1 / 2 * m (1 / 2) 2) ∧
      0.2445 < 1 / 2 * m 2 2 ∧ 1 / 2 * m 2 2 < 0.2455 ∧
      0.4385 < 1 / 2 * (1 / 2 * m 2 2 + 1 / 2 * m (1 / 2) 2) ∧
      1 / 2 * (1 / 2 * m 2 2 + 1 / 2 * m (1 / 2) 2) < 0.4395 := by
  have hnn : ∀ S : Set Ω, 0 ≤ᵐ[P.restrict S] W := fun S => Eventually.of_forall hWnn
  have core : ∀ (S : Set Ω), MeasurableSet S → ∀ lam : ℝ, 0 < lam →
      (∀ t, 0 ≤ t → P (S ∩ {ω | t < W ω}) = ENNReal.ofReal (1 / 2 * Real.exp (-lam * t))) →
      ∫⁻ ω in S, ENNReal.ofReal (min (W ω) 2) ∂P = ENNReal.ofReal (1 / 2 * m lam 2) := by
    intro S hS lam hlam h
    have := lintegral_disc_min (P.restrict S) W hW.aemeasurable (hnn S) (1 / 2) lam 0 2
      (by norm_num) hlam le_rfl (by norm_num) (restrict_survival P S W hW _ lam 2 h)
    simp only [neg_zero, zero_mul, Real.exp_zero, intervalIntegral.integral_const, smul_eq_mul,
      mul_one, sub_zero, zero_add] at this
    rw [this, m]
  have hL : ∫⁻ ω, Cov.indicator (1 : Ω → ℝ≥0∞) ω * ENNReal.ofReal (min (W ω) 2) ∂P
      = ∫⁻ ω in Cov, ENNReal.ofReal (min (W ω) 2) ∂P := by
    rw [← lintegral_indicator hCov]
    congr 1; funext ω
    by_cases h : ω ∈ Cov <;> simp [indicator, h]
  have hC1 := core Cov hCov 2 (by norm_num) h1
  have hC0 := core Covᶜ hCov.compl (1 / 2) (by norm_num) h0
  have hm1 := m_pos 2 2 (by norm_num) (by norm_num)
  have hm0 := m_pos (1 / 2) 2 (by norm_num) (by norm_num)
  have hlt : m 2 2 < m (1 / 2) 2 :=
    m_strictAntiOn 2 (by norm_num) (show (1/2:ℝ) ∈ Ioi 0 by norm_num)
      (show (2:ℝ) ∈ Ioi 0 by norm_num) (by norm_num)
  -- numeric bounds
  have ha := exp_neg_one_gt
  have hb := exp_neg_one_lt
  have e4 : Real.exp (-2 * 2) = Real.exp (-1) ^ 4 := by rw [← Real.exp_nat_mul]; norm_num
  have e1 : Real.exp (-(1 / 2) * 2) = Real.exp (-1) := by norm_num
  have p4l : (0.3678:ℝ) ^ 4 < Real.exp (-1) ^ 4 := by gcongr
  have p4u : Real.exp (-1) ^ 4 < (0.3679:ℝ) ^ 4 := by gcongr
  refine ⟨hL.trans hC1, ?_, by linarith, ?_, ?_, ?_, ?_⟩
  · rw [← lintegral_add_compl _ hCov, hC1, hC0, hc, ← ENNReal.ofReal_add (by positivity)
      (by positivity), ← ENNReal.ofReal_mul (by norm_num)]
  all_goals
    unfold m
    simp only [e4, e1]
    norm_num at p4l p4u ⊢
    nlinarith

/-- Main text line 300, "fast patchers gain most in proportion": for `π < 1` the share falls
strictly in `u = λτ`. -/
theorem p6_fast_gain_most (π : ℝ) (hπ : π < 1) : StrictAntiOn (shareFn π) (Ioi 0) := by
  intro a ha b hb hab
  have e : ∀ u, shareFn π u = (1 - π) * m u 1 := fun u => by simp [shareFn, m]
  rw [e, e]
  exact mul_lt_mul_of_pos_left (m_strictAntiOn 1 one_pos ha hb hab) (by linarith)

/-! ## Fix round 1 -/

/-! ### P6(iv) for any window, and composed with the factorization -/

/-- **P6(iv)**, the outer bound "whatever the window" (lines 298, 935): any `W : Ω → ℝ≥0∞`, so
infinite values and an infinite mean are allowed; deployment times may be zero. -/
theorem p6iv_aggregate_any {Ω ι : Type*} [MeasurableSpace Ω] (P : Measure Ω)
    [IsProbabilityMeasure P] (W : Ω → ℝ≥0∞) (s Fast : Finset ι) (hF : Fast ⊆ s) (w τ c : ι → ℝ)
    (π cbar : ℝ) (hπ : π ≤ 1) (hw : ∀ j ∈ s, 0 ≤ w j) (hτ : ∀ j ∈ s, 0 ≤ τ j)
    (hc0 : ∀ j ∈ s, 0 ≤ c j) (hc1 : ∀ j ∈ s, c j ≤ 1)
    (hslowc : ∀ j ∈ s, j ∉ Fast → c j ≤ cbar)
    (hE0 : 0 < ∑ j ∈ s, w j * τ j) :
    let E0 := ∑ j ∈ s, w j * τ j
    let α := (∑ j ∈ Fast, w j * τ j) / E0
    let G := (1 - π) * ∑ j ∈ s, c j * w j *
      (∫⁻ ω, min (W ω) (ENNReal.ofReal (τ j)) ∂P).toReal
    G / E0 ≤ (1 - π) * (α + cbar * (1 - α)) := by
  classical
  intro E0 α G
  set M : ι → ℝ := fun j => (∫⁻ ω, min (W ω) (ENNReal.ofReal (τ j)) ∂P).toReal with hM
  set Slow := s.filter (fun j => j ∉ Fast) with hSlow
  have h1π : 0 ≤ 1 - π := by linarith
  have hMb : ∀ j ∈ s, 0 ≤ M j ∧ M j ≤ τ j := by
    intro j hj
    refine ⟨ENNReal.toReal_nonneg, ENNReal.toReal_le_of_le_ofReal (hτ j hj) ?_⟩
    calc ∫⁻ ω, min (W ω) (ENNReal.ofReal (τ j)) ∂P
        ≤ min (∫⁻ ω, W ω ∂P) (ENNReal.ofReal (τ j)) := p6i_bound P W _
      _ ≤ ENNReal.ofReal (τ j) := min_le_right _ _
  have hfast : ∀ j ∈ Fast, c j * w j * M j ≤ w j * τ j := by
    intro j hj
    have hjs := hF hj
    obtain ⟨hM0, hMτ⟩ := hMb j hjs
    have := hw j hjs
    nlinarith [mul_nonneg (mul_nonneg (sub_nonneg.2 (hc1 j hjs)) this) hM0,
      mul_nonneg this (sub_nonneg.2 hMτ)]
  have hslow : ∀ j ∈ Slow, c j * w j * M j ≤ cbar * (w j * τ j) := by
    intro j hj
    obtain ⟨hjs, hjF⟩ := Finset.mem_filter.1 hj
    obtain ⟨hM0, hMτ⟩ := hMb j hjs
    have hw0 := hw j hjs
    have hc0' := hc0 j hjs
    nlinarith [mul_nonneg (mul_nonneg hc0' hw0) (sub_nonneg.2 hMτ),
      mul_nonneg (mul_nonneg (sub_nonneg.2 (hslowc j hjs hjF)) hw0) (hτ j hjs)]
  have hsplit : ∀ f : ι → ℝ, ∑ j ∈ s, f j = ∑ j ∈ Fast, f j + ∑ j ∈ Slow, f j := by
    intro f
    rw [hSlow, Finset.sum_filter_not_add_sum_filter s (fun j => j ∈ Fast) f |>.symm, add_comm,
      Finset.filter_mem_eq_inter, Finset.inter_eq_right.2 hF]
  have hA := Finset.sum_le_sum hfast
  have hB := Finset.sum_le_sum hslow
  rw [← Finset.mul_sum] at hB
  have hαE : α * E0 = ∑ j ∈ Fast, w j * τ j := div_mul_cancel₀ _ hE0.ne'
  have hα1 : 1 - α = (∑ j ∈ Slow, w j * τ j) / E0 := by
    rw [eq_div_iff hE0.ne', sub_mul, hαE, one_mul]; linarith [hsplit (fun j => w j * τ j)]
  have h1αE : (1 - α) * E0 = ∑ j ∈ Slow, w j * τ j := by
    rw [hα1]; exact div_mul_cancel₀ _ hE0.ne'
  simp only [G]
  rw [mul_div_assoc]
  apply mul_le_mul_of_nonneg_left _ h1π
  rw [div_le_iff₀ hE0, hsplit]
  have : (α + cbar * (1 - α)) * E0
      = ∑ j ∈ Fast, w j * τ j + cbar * ∑ j ∈ Slow, w j * τ j := by
    calc (α + cbar * (1 - α)) * E0 = α * E0 + cbar * ((1 - α) * E0) := by ring
      _ = _ := by rw [hαE, h1αE]
  rw [this]; linarith

/-- **P6(iv)**, total saving from the model: with each coverage event `Cov j` independent of the
window (A9), `Σ_j w_j E[1_{Cov_j} · saving_j]` equals the factorized
`(1 − π) Σ_j c_j w_j E[min(W, τ_j)]` with `c_j = P(Cov_j)`. Composes `p6_factorization`. -/
theorem p6iv_G_eq {Ω ι : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (W : Ω → ℝ) (hW : Measurable W) (s : Finset ι) (Cov : ι → Set Ω)
    (hCov : ∀ j ∈ s, MeasurableSet (Cov j))
    (hind : ∀ j ∈ s, IndepFun ((Cov j).indicator (1 : Ω → ℝ≥0∞)) W P) (w τ : ι → ℝ) (π : ℝ)
    (hπ : π ≤ 1) :
    ∑ j ∈ s, w j * (∫⁻ ω, (Cov j).indicator (1 : Ω → ℝ≥0∞) ω *
        ENNReal.ofReal (baseExposure (τ j) - holdExposure π (τ j) (W ω)) ∂P).toReal
      = (1 - π) * ∑ j ∈ s, (P (Cov j)).toReal * w j *
        (∫⁻ ω, min (ENNReal.ofReal (W ω)) (ENNReal.ofReal (τ j)) ∂P).toReal := by
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun j hj => ?_
  rw [p6_factorization P (Cov j) (hCov j hj) W hW (hind j hj) π (τ j) hπ]
  simp only [ENNReal.ofReal_min, ENNReal.toReal_mul, ENNReal.toReal_ofReal (sub_nonneg.2 hπ)]
  ring

/-- **P6(iv)** stated for the model's total saving `G = Σ_j w_j E[1_{Cov_j} · saving_j]` under A9:
the outer bound for any window, and the inner bound for a window of mean `1/λ`. -/
theorem p6iv_model {Ω ι : Type*} [MeasurableSpace Ω] (P : Measure Ω) [IsProbabilityMeasure P]
    (W : Ω → ℝ) (hW : Measurable W) (s Fast : Finset ι) (hF : Fast ⊆ s) (Cov : ι → Set Ω)
    (hCov : ∀ j ∈ s, MeasurableSet (Cov j))
    (hind : ∀ j ∈ s, IndepFun ((Cov j).indicator (1 : Ω → ℝ≥0∞)) W P)
    (w τ : ι → ℝ) (π cbar : ℝ) (hπ : π ≤ 1) (hw : ∀ j ∈ s, 0 ≤ w j) (hτ : ∀ j ∈ s, 0 ≤ τ j)
    (hslowc : ∀ j ∈ s, j ∉ Fast → (P (Cov j)).toReal ≤ cbar) (hcbar : 0 ≤ cbar)
    (hE0 : 0 < ∑ j ∈ s, w j * τ j) :
    let E0 := ∑ j ∈ s, w j * τ j
    let α := (∑ j ∈ Fast, w j * τ j) / E0
    let G := ∑ j ∈ s, w j * (∫⁻ ω, (Cov j).indicator (1 : Ω → ℝ≥0∞) ω *
        ENNReal.ofReal (baseExposure (τ j) - holdExposure π (τ j) (W ω)) ∂P).toReal
    G / E0 ≤ (1 - π) * (α + cbar * (1 - α)) ∧
      ∀ lam τs : ℝ, 0 < lam → ∫⁻ ω, ENNReal.ofReal (W ω) ∂P = ENNReal.ofReal (1 / lam) →
        0 < τs → (∀ j ∈ s, j ∉ Fast → τs ≤ τ j) →
        G / E0 ≤ (1 - π) * (α + (1 - α) * cbar * min 1 (1 / (lam * τs))) := by
  intro E0 α G
  have hG := p6iv_G_eq P W hW s Cov hCov hind w τ π hπ
  have hc0 : ∀ j ∈ s, 0 ≤ (P (Cov j)).toReal := fun _ _ => ENNReal.toReal_nonneg
  have hc1 : ∀ j ∈ s, (P (Cov j)).toReal ≤ 1 := fun _ _ =>
    ENNReal.toReal_le_of_le_ofReal zero_le_one (by rw [ENNReal.ofReal_one]; exact prob_le_one)
  refine ⟨?_, fun lam τs hlam hmean hτs hslowτ => ?_⟩
  · simp only [G]; rw [hG]
    exact p6iv_aggregate_any P (fun ω => ENNReal.ofReal (W ω)) s Fast hF w τ
      (fun j => (P (Cov j)).toReal) π cbar hπ hw hτ hc0 hc1 hslowc hE0
  · simp only [G]; rw [hG]
    exact (p6iv_aggregate P (fun ω => ENNReal.ofReal (W ω)) lam hlam hmean s Fast hF w τ
      (fun j => (P (Cov j)).toReal) π cbar τs hπ hw hτ hc0 hc1 hslowc hslowτ hτs hcbar hE0).1

/-! ### P6(iii) as limits of ratios; Figure 14 -/

/-- At `π = 1` the saving, and so the share, is identically zero. -/
theorem p6_saving_pi_one (τ W u : ℝ) :
    baseExposure τ - holdExposure 1 τ W = 0 ∧ shareFn 1 u = 0 := by
  refine ⟨by rw [p6_pathwise_saving]; ring, by simp [shareFn]⟩

/-- **P6(iii)**, `λτ → 0`, as a ratio tending to one (`π < 1`; at `π = 1` the ratio is `0/0`).
Equivalently the saving over exposure to attackers without access, `(1 − π)τ`, tends to one. -/
theorem p6iii_ratio_small (π : ℝ) (hπ : π < 1) :
    Tendsto (fun u => shareFn π u / (1 - π)) (𝓝[>] 0) (𝓝 1) := by
  have h := (p6iii_tendsto_small π).div_const (1 - π)
  rwa [div_self (by linarith : (1:ℝ) - π ≠ 0)] at h

/-- **P6(iii)**, `λτ → ∞`, as a ratio tending to one (`π < 1`). -/
theorem p6iii_ratio_large (π : ℝ) (hπ : π < 1) :
    Tendsto (fun u => shareFn π u / ((1 - π) / u)) atTop (𝓝 1) := by
  have hz : ∀ᶠ u in atTop, (fun u : ℝ => (1 - π) / u) u ≠ 0 := by
    filter_upwards [eventually_gt_atTop 0] with u hu
    exact div_ne_zero (by linarith) hu.ne'
  exact (isEquivalent_iff_tendsto_one hz).1 (p6iii_large π)

/-- Figure 14 (line 296): with `x = E[W]/τ = 1/(λτ)`, the normalized saving is `x(1 − e^{−1/x})`,
strictly below the distribution-free bound `min(x, 1)`. -/
theorem p6_fig14 (π x : ℝ) (hπ : π < 1) (hx : 0 < x) :
    shareFn π (1 / x) / (1 - π) = x * (1 - Real.exp (-(1 / x))) ∧
      x * (1 - Real.exp (-(1 / x))) < min x 1 := by
  have h1π : (1:ℝ) - π ≠ 0 := by linarith
  have hx0 : x ≠ 0 := hx.ne'
  refine ⟨?_, ?_⟩
  · unfold shareFn
    field_simp
  · have he := Real.exp_pos (-(1 / x))
    have hlt : 1 - Real.exp (-(1 / x)) < 1 / x := by
      have := Real.add_one_lt_exp (show -(1 / x) ≠ 0 by
        have : 0 < 1 / x := by positivity
        linarith)
      linarith
    refine lt_min (by nlinarith [mul_pos hx he]) ?_
    calc x * (1 - Real.exp (-(1 / x))) < x * (1 / x) := mul_lt_mul_of_pos_left hlt hx
      _ = 1 := by field_simp

/-! ### `m_λ` at `τ = 0` -/

theorem mlam_zero (l : ℝ) : mlam l 0 = 0 := by simp [mlam]

/-- `m_λ ≤ 0` for `τ ≥ 0`; strict only for `τ > 0` (`mlam_neg`), zero at `τ = 0`. -/
theorem mlam_nonpos (l τ : ℝ) (hl : 0 < l) (hτ : 0 ≤ τ) : mlam l τ ≤ 0 := by
  rcases hτ.lt_or_eq with h | h
  · exact (mlam_neg l τ hl h).le
  · rw [← h, mlam_zero]

/-! ### P8(ii)–(iii) for the coalition objective `B` -/

theorem p8ii_interior_B {ι : Type*} (π : ℝ) (s : Finset ι) (c : ι → ℝ → ℝ) (w τ : ι → ℝ)
    (lam : ℝ → ℝ) (b0 bN N : ℝ) (hN : 0 < N)
    (hcont : ContinuousOn (B π s c w τ lam) (Icc 0 N))
    (hd0 : HasDerivWithinAt (B π s c w τ lam) b0 (Icc 0 N) 0)
    (hdN : HasDerivWithinAt (B π s c w τ lam) bN (Icc 0 N) N) (h0 : 0 < b0) (hN' : bN < 0) :
    ∃ n ∈ Ioo 0 N, IsMaxOn (B π s c w τ lam) (Icc 0 N) n :=
  p8ii_interior _ b0 bN N hN hcont hd0 hdN h0 hN'

theorem p8ii_unique_signs_B {ι : Type*} (π : ℝ) (s : Finset ι) (c : ι → ℝ → ℝ) (w τ : ι → ℝ)
    (lam : ℝ → ℝ) (B' : ℝ → ℝ) (N ns : ℝ) (hns : ns ∈ Icc 0 N)
    (hd : ∀ x ∈ Icc 0 N, HasDerivWithinAt (B π s c w τ lam) (B' x) (Icc 0 N) x)
    (hpos : ∀ x ∈ Ico 0 ns, 0 < B' x) (hneg : ∀ x ∈ Ioc ns N, B' x < 0) :
    IsMaxOn (B π s c w τ lam) (Icc 0 N) ns ∧
      ∀ y ∈ Icc 0 N, IsMaxOn (B π s c w τ lam) (Icc 0 N) y → y = ns :=
  p8ii_unique_signs _ B' N ns hns hd hpos hneg

theorem p8ii_unique_concave_B {ι : Type*} (π : ℝ) (s : Finset ι) (c : ι → ℝ → ℝ) (w τ : ι → ℝ)
    (lam : ℝ → ℝ) (N : ℝ) (hN : 0 ≤ N) (hcont : ContinuousOn (B π s c w τ lam) (Icc 0 N))
    (hconc : StrictConcaveOn ℝ (Icc 0 N) (B π s c w τ lam)) :
    ∃! n, n ∈ Icc 0 N ∧ IsMaxOn (B π s c w τ lam) (Icc 0 N) n :=
  p8ii_unique_concave _ N hN hcont hconc

/-- **P8(iii)** for the integer coalition objective `k ↦ B(k)`: a maximizer exists; it is interior
under the corner conditions; with strictly decreasing differences any two maximizers are adjacent,
there are at most two, and the maximizer is unique if no difference is zero. -/
theorem p8iii_B {ι : Type*} (π : ℝ) (s : Finset ι) (c : ι → ℝ → ℝ) (w τ : ι → ℝ)
    (lam : ℝ → ℝ) (N : ℕ) :
    let Bn : ℕ → ℝ := fun k => B π s c w τ lam k
    (∃ n ≤ N, ∀ k ≤ N, Bn k ≤ Bn n) ∧
    (Bn 0 < Bn 1 → Bn N < Bn (N - 1) → ∀ n ≤ N, (∀ k ≤ N, Bn k ≤ Bn n) → 0 < n ∧ n < N) ∧
    ((∀ i j, i < j → j < N → Bn (j + 1) - Bn j < Bn (i + 1) - Bn i) →
      (∀ a b, a < b → b ≤ N → (∀ k ≤ N, Bn k ≤ Bn a) → (∀ k ≤ N, Bn k ≤ Bn b) → b = a + 1) ∧
      (∀ a b d, a < b → b < d → d ≤ N → (∀ k ≤ N, Bn k ≤ Bn a) → (∀ k ≤ N, Bn k ≤ Bn b) →
        (∀ k ≤ N, Bn k ≤ Bn d) → False) ∧
      ((∀ i < N, Bn (i + 1) - Bn i ≠ 0) → ∀ a b, a ≤ N → b ≤ N →
        (∀ k ≤ N, Bn k ≤ Bn a) → (∀ k ≤ N, Bn k ≤ Bn b) → a = b)) := by
  intro Bn
  refine ⟨p8iii_exists Bn N, fun h1 h2 n hn hmax => p8iii_interior Bn N h1 h2 n hn hmax,
    fun hdec => ⟨fun a b hab hb ha' hb' => (p8iii_adjacent Bn N hdec a b hb ha' hb' hab).1,
      fun a b d hab hbd hd ha' hb' hd' => p8iii_at_most_two Bn N hdec a b d hd ha' hb' hd' hab hbd,
      fun hnz a b ha hb ha' hb' => p8iii_unique Bn N hdec hnz a b ha hb ha' hb'⟩⟩

/-- Necessity in the rival rule (line 318, "holds only with … some attackers lacking access and
covered exposure positive"): at `π = 1`, or with zero covered exposure, `B` does not depend on
`λ` at all, so it cannot rise as `λ` falls. -/
theorem p8iv_rival_needs {ι : Type*} (π : ℝ) (s : Finset ι) (c w τ : ι → ℝ)
    (hc : ∀ j ∈ s, 0 ≤ c j) (hw : ∀ j ∈ s, 0 ≤ w j) (hτ : ∀ j ∈ s, 0 ≤ τ j) (l0 l1 : ℝ) :
    (π = 1 → (1 - π) * ∑ j ∈ s, c j * w j * m l0 (τ j)
        = (1 - π) * ∑ j ∈ s, c j * w j * m l1 (τ j)) ∧
      (∑ j ∈ s, c j * w j * τ j = 0 → (1 - π) * ∑ j ∈ s, c j * w j * m l0 (τ j)
        = (1 - π) * ∑ j ∈ s, c j * w j * m l1 (τ j)) := by
  refine ⟨fun h => by rw [h]; ring, fun h0 => ?_⟩
  have hz : ∀ j ∈ s, c j * w j * τ j = 0 :=
    (Finset.sum_eq_zero_iff_of_nonneg fun j hj =>
      mul_nonneg (mul_nonneg (hc j hj) (hw j hj)) (hτ j hj)).1 h0
  have hterm : ∀ l, ∀ j ∈ s, c j * w j * m l (τ j) = 0 := by
    intro l j hj
    rcases mul_eq_zero.1 (hz j hj) with h | h
    · rw [h, zero_mul]
    · rw [h]; simp [m]
  rw [Finset.sum_eq_zero (hterm l0), Finset.sum_eq_zero (hterm l1)]

/-! ### Rigorous enclosures for the printed example decimals -/

/-- Fifth-order Taylor enclosure of `exp` on `[−1, 0]`, from Mathlib's `Real.exp_bound`. -/
theorem exp_enclose (x : ℝ) (hx0 : -1 ≤ x) (hx1 : x ≤ 0) :
    1 + x + x ^ 2 / 2 + x ^ 3 / 6 + x ^ 4 / 24 - (-x) ^ 5 / 100 ≤ Real.exp x ∧
      Real.exp x ≤ 1 + x + x ^ 2 / 2 + x ^ 3 / 6 + x ^ 4 / 24 + (-x) ^ 5 / 100 := by
  have habs : |x| = -x := abs_of_nonpos hx1
  have h := Real.exp_bound (show |x| ≤ 1 by rw [habs]; linarith) (n := 5) (by norm_num)
  have e1 : ∑ i ∈ Finset.range 5, x ^ i / (i.factorial : ℝ)
      = 1 + x + x ^ 2 / 2 + x ^ 3 / 6 + x ^ 4 / 24 := by
    simp [Finset.sum_range_succ, Nat.factorial]
  have e2 : |x| ^ 5 * (((Nat.succ 5 : ℕ) : ℝ) / ((Nat.factorial 5 : ℕ) * (5 : ℕ)))
      = (-x) ^ 5 / 100 := by
    rw [habs]; norm_num [Nat.factorial]; ring
  rw [e1, e2] at h
  constructor <;> linarith [(abs_le.1 h).1, (abs_le.1 h).2]

theorem exp_neg_022 : 0.97824 < Real.exp (-0.022) ∧ Real.exp (-0.022) < 0.97825 := by
  obtain ⟨h1, h2⟩ := exp_enclose (-0.022) (by norm_num) (by norm_num)
  constructor <;> norm_num at h1 h2 ⊢ <;> linarith

theorem exp_neg_022' : 0.80251 < Real.exp (-0.22) ∧ Real.exp (-0.22) < 0.80253 := by
  obtain ⟨h1, h2⟩ := exp_enclose (-0.22) (by norm_num) (by norm_num)
  constructor <;> norm_num at h1 h2 ⊢ <;> linarith

theorem exp_neg_0122 : 0.88514 < Real.exp (-0.122) ∧ Real.exp (-0.122) < 0.88516 := by
  obtain ⟨h1, h2⟩ := exp_enclose (-0.122) (by norm_num) (by norm_num)
  constructor <;> norm_num at h1 h2 ⊢ <;> linarith

theorem exp_neg_032 : 0.72614 < Real.exp (-0.32) ∧ Real.exp (-0.32) < 0.72621 := by
  obtain ⟨h1, h2⟩ := exp_enclose (-0.32) (by norm_num) (by norm_num)
  constructor <;> norm_num at h1 h2 ⊢ <;> linarith

theorem exp_neg_01 : 0.9048 < Real.exp (-0.1) ∧ Real.exp (-0.1) < 0.9049 := by
  obtain ⟨h1, h2⟩ := exp_enclose (-0.1) (by norm_num) (by norm_num)
  constructor <;> norm_num at h1 h2 ⊢ <;> linarith

theorem exp_neg_055 : 0.5768 < Real.exp (-0.55) ∧ Real.exp (-0.55) < 0.5779 := by
  obtain ⟨h1, h2⟩ := exp_enclose (-0.55) (by norm_num) (by norm_num)
  constructor <;> norm_num at h1 h2 ⊢ <;> linarith

theorem integral_exp_neg_mul_ab (c a b : ℝ) (hc : 0 < c) :
    ∫ t in a..b, Real.exp (-c * t) = (Real.exp (-c * a) - Real.exp (-c * b)) / c := by
  have hd : ∀ x ∈ uIcc a b,
      HasDerivAt (fun t => -Real.exp (-c * t) / c) (Real.exp (-c * x)) x := by
    intro x _
    have h1 : HasDerivAt (fun t => -c * t) (-c) x := by
      simpa using (hasDerivAt_id x).const_mul (-c)
    have h2 := (h1.exp).neg.div_const c
    convert h2 using 1
    field_simp
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hd
    (by apply Continuous.intervalIntegrable; fun_prop)]
  ring

/-- P7(c)'s discounted example (line 1126) with the replication code's inputs: exposure from
`0.11` to `1.1`, `r = 0.2`, onset and completion both delayed by `0.5`. Undiscounted exposure is
unchanged; discounted exposure is `0.879` and `0.795` to three decimals. -/
theorem p7c_discount_example :
    (1.1 + 0.5) - (0.11 + 0.5) = (1.1 : ℝ) - 0.11 ∧
      0.8785 < ∫ t in (0.11:ℝ)..1.1, Real.exp (-0.2 * t) ∧
      ∫ t in (0.11:ℝ)..1.1, Real.exp (-0.2 * t) < 0.8795 ∧
      0.7945 < ∫ t in (0.11 + 0.5 : ℝ)..(1.1 + 0.5), Real.exp (-0.2 * t) ∧
      ∫ t in (0.11 + 0.5 : ℝ)..(1.1 + 0.5), Real.exp (-0.2 * t) < 0.7955 := by
  rw [integral_exp_neg_mul_ab _ _ _ (by norm_num), integral_exp_neg_mul_ab _ _ _ (by norm_num)]
  have e1 : Real.exp (-0.2 * 0.11) = Real.exp (-0.022) := by norm_num
  have e2 : Real.exp (-0.2 * 1.1) = Real.exp (-0.22) := by norm_num
  have e3 : Real.exp (-0.2 * (0.11 + 0.5)) = Real.exp (-0.122) := by norm_num
  have e4 : Real.exp (-0.2 * (1.1 + 0.5)) = Real.exp (-0.32) := by norm_num
  rw [e1, e2, e3, e4]
  obtain ⟨a1, a2⟩ := exp_neg_022
  obtain ⟨b1, b2⟩ := exp_neg_022'
  obtain ⟨c1, c2⟩ := exp_neg_0122
  obtain ⟨d1, d2⟩ := exp_neg_032
  refine ⟨by norm_num, ?_, ?_, ?_, ?_⟩
  · rw [lt_div_iff₀ (by norm_num)]; linarith
  · rw [div_lt_iff₀ (by norm_num)]; linarith
  · rw [lt_div_iff₀ (by norm_num)]; linarith
  · rw [div_lt_iff₀ (by norm_num)]; linarith

/-- The rival's-own-systems example (line 1128) with the replication code's inputs: `B` is `0.51`
before and `0.87` after, to two decimals. -/
theorem p8_rival_own_systems_values :
    0.505 < 0.8 * 1 * m 1 1 ∧ 0.8 * 1 * m 1 1 < 0.515 ∧
      0.865 < 0.8 * 1 * m 1.1 1 + 1 * 1 * m 1.1 0.5 ∧
      0.8 * 1 * m 1.1 1 + 1 * 1 * m 1.1 0.5 < 0.875 := by
  have ha := exp_neg_one_gt
  have hb := exp_neg_one_lt
  obtain ⟨c1, c2⟩ := exp_neg_01
  obtain ⟨d1, d2⟩ := exp_neg_055
  have e11 : Real.exp (-1.1 * 1) = Real.exp (-1) * Real.exp (-0.1) := by
    rw [← Real.exp_add]; norm_num
  have e55 : Real.exp (-1.1 * 0.5) = Real.exp (-0.55) := by norm_num
  have e1 : Real.exp (-1 * 1) = Real.exp (-1) := by norm_num
  have hp : 0 < Real.exp (-0.1) := Real.exp_pos _
  have q1 : 0.3678 * Real.exp (-0.1) ≤ Real.exp (-1) * Real.exp (-0.1) :=
    mul_le_mul_of_nonneg_right ha.le hp.le
  have q2 : Real.exp (-1) * Real.exp (-0.1) ≤ 0.3679 * Real.exp (-0.1) :=
    mul_le_mul_of_nonneg_right hb.le hp.le
  unfold m
  rw [e11, e55, e1]
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [div_one]; linarith
  · rw [div_one]; linarith
  · have : 0.8 * 1 * ((1 - Real.exp (-1) * Real.exp (-0.1)) / 1.1)
        + 1 * 1 * ((1 - Real.exp (-0.55)) / 1.1)
        = (1.8 - 0.8 * (Real.exp (-1) * Real.exp (-0.1)) - Real.exp (-0.55)) / 1.1 := by ring
    rw [this, lt_div_iff₀ (by norm_num)]; nlinarith
  · have : 0.8 * 1 * ((1 - Real.exp (-1) * Real.exp (-0.1)) / 1.1)
        + 1 * 1 * ((1 - Real.exp (-0.55)) / 1.1)
        = (1.8 - 0.8 * (Real.exp (-1) * Real.exp (-0.1)) - Real.exp (-0.55)) / 1.1 := by ring
    rw [this, div_lt_iff₀ (by norm_num)]; nlinarith

/-- The interior example's `B` is not concave on `[0, 10]` (line 1128): `B(6.5) < (B(3) + B(10))/2`. -/
theorem p8_interior_example_not_concave : ¬ ConcaveOn ℝ (Icc (0:ℝ) 10) Bint := by
  intro hconc
  have hmid := hconc.2 (show (3:ℝ) ∈ Icc 0 10 by norm_num) (show (10:ℝ) ∈ Icc 0 10 by norm_num)
    (show (0:ℝ) ≤ 1 / 2 by norm_num) (show (0:ℝ) ≤ 1 / 2 by norm_num) (by norm_num)
  have e : (1 / 2 : ℝ) • (3:ℝ) + (1 / 2 : ℝ) • (10:ℝ) = 6.5 := by norm_num
  rw [e] at hmid
  simp only [smul_eq_mul] at hmid
  have ha := exp_neg_three_lt
  have hp3 := Real.exp_pos (-3)
  have p1 : (0.9502:ℝ) < 1 - Real.exp (-3) := by
    have : (1:ℝ) / 20.085 < 0.0498 := by norm_num
    linarith
  have hu : Bint 6.5 ≤ 1 / 2.45 := by
    unfold Bint
    rw [show (0.5:ℝ) + 0.3 * 6.5 = 2.45 by norm_num, mul_one]
    have hm := (m_le 2.45 3 (by norm_num)).trans (min_le_left _ _)
    have hm0 := m_nonneg 2.45 3 (by norm_num) (by norm_num)
    have he := Real.exp_pos (-6.5)
    nlinarith [mul_nonneg he.le hm0]
  have h3 : 0.64 < Bint 3 := by
    unfold Bint m
    rw [show (0.5:ℝ) + 0.3 * 3 = 1.4 by norm_num, mul_one, mul_div_assoc', lt_div_iff₀ (by norm_num)]
    have hb : Real.exp (-1.4 * 3) ≤ Real.exp (-3) := Real.exp_le_exp.2 (by norm_num)
    have p2 : (0.9502:ℝ) < 1 - Real.exp (-1.4 * 3) := by linarith
    nlinarith [mul_lt_mul'' p1 p2 (by norm_num) (by norm_num)]
  have h10 : 0.25 < Bint 10 := by
    unfold Bint m
    rw [show (0.5:ℝ) + 0.3 * 10 = 3.5 by norm_num, mul_one, mul_div_assoc',
      lt_div_iff₀ (by norm_num)]
    have hb : Real.exp (-3.5 * 3) ≤ Real.exp (-3) := Real.exp_le_exp.2 (by norm_num)
    have hb' : Real.exp (-10) ≤ Real.exp (-3) := Real.exp_le_exp.2 (by norm_num)
    have p2 : (0.9502:ℝ) < 1 - Real.exp (-3.5 * 3) := by linarith
    have p3 : (0.9502:ℝ) < 1 - Real.exp (-10) := by linarith
    nlinarith [mul_lt_mul'' p3 p2 (by norm_num) (by norm_num)]
  have : (1:ℝ) / 2.45 < 0.41 := by norm_num
  linarith

/-! ### A concrete model for the A9 counterexample -/

/-- `U` uniform on `[0, 1]` (Lebesgue measure restricted to `[0, 1]`). -/
noncomputable def a9P : Measure ℝ := volume.restrict (Icc 0 1)

instance a9P_isProb : IsProbabilityMeasure a9P := ⟨by simp [a9P]⟩

/-- Covered iff `U < 1/2`, so coverage is `1/2`. -/
def a9Cov : Set ℝ := Iio (1 / 2)

/-- Inverse-survival transform of the rescaled uniform on each half: rate 2 when covered, rate
`1/2` otherwise. The outer `max 0` only fixes values off `[0, 1]`, a null set. -/
noncomputable def a9W (u : ℝ) : ℝ :=
  max 0 (if u < 1 / 2 then -Real.log (1 - 2 * u) / 2 else -2 * Real.log (2 - 2 * u))

theorem a9W_measurable : Measurable a9W := by
  unfold a9W
  refine measurable_const.max (Measurable.ite (measurableSet_lt measurable_id measurable_const)
    ?_ ?_)
  · exact ((Real.measurable_log.comp (measurable_const.sub (measurable_const.mul measurable_id))).neg).div_const _
  · exact (Real.measurable_log.comp (measurable_const.sub (measurable_const.mul measurable_id))).const_mul _

theorem a9_cov_mass : a9P a9Cov = ENNReal.ofReal (1 / 2) := by
  rw [a9P, Measure.restrict_apply' measurableSet_Icc]
  have : a9Cov ∩ Icc 0 1 = Ico 0 (1 / 2) := by
    ext u
    simp only [a9Cov, mem_inter_iff, mem_Iio, mem_Icc, mem_Ico]
    constructor
    · rintro ⟨h1, h2, _⟩; exact ⟨h2, h1⟩
    · rintro ⟨h1, h2⟩; exact ⟨h2, h1, by linarith⟩
  rw [this, Real.volume_Ico, sub_zero]

theorem a9_cov_surv (t : ℝ) (ht : 0 ≤ t) :
    a9P (a9Cov ∩ {ω | t < a9W ω}) = ENNReal.ofReal (1 / 2 * Real.exp (-2 * t)) := by
  have hset : (a9Cov ∩ {ω | t < a9W ω}) ∩ Icc 0 1 = Ioo ((1 - Real.exp (-2 * t)) / 2) (1 / 2) := by
    ext u
    simp only [a9Cov, mem_inter_iff, mem_Iio, mem_ofPred_eq, mem_Icc, mem_Ioo, a9W]
    constructor
    · rintro ⟨⟨hu, hw⟩, h0, _⟩
      rw [ite_eq_left hu, lt_max_iff] at hw
      rcases hw with hw | hw
      · linarith
      · have hpos : 0 < 1 - 2 * u := by linarith
        have hl : Real.log (1 - 2 * u) < -2 * t := by linarith
        have := (Real.log_lt_iff_lt_exp hpos).1 hl
        constructor <;> linarith
    · rintro ⟨h1, h2⟩
      have he : Real.exp (-2 * t) ≤ 1 := Real.exp_le_one_iff.2 (by linarith)
      refine ⟨⟨h2, ?_⟩, by linarith, by linarith⟩
      rw [ite_eq_left h2, lt_max_iff]
      right
      have hpos : 0 < 1 - 2 * u := by linarith
      have := (Real.log_lt_iff_lt_exp hpos).2 (show 1 - 2 * u < Real.exp (-2 * t) by linarith)
      linarith
  rw [a9P, Measure.restrict_apply' measurableSet_Icc, hset, Real.volume_Ioo]
  congr 1; ring

theorem a9_compl_surv (t : ℝ) (ht : 0 ≤ t) :
    a9P (a9Covᶜ ∩ {ω | t < a9W ω}) = ENNReal.ofReal (1 / 2 * Real.exp (-(1 / 2) * t)) := by
  have hset : (a9Covᶜ ∩ {ω | t < a9W ω}) ∩ Icc 0 1
      = Ioo (1 - Real.exp (-(1 / 2) * t) / 2) 1 := by
    ext u
    simp only [a9Cov, mem_inter_iff, mem_compl_iff, mem_Iio, not_lt, mem_ofPred_eq, mem_Icc,
      mem_Ioo, a9W]
    constructor
    · rintro ⟨⟨hu, hw⟩, _, h1⟩
      rw [ite_eq_right (not_lt.2 hu), lt_max_iff] at hw
      rcases hw with hw | hw
      · linarith
      · rcases h1.lt_or_eq with h1 | h1
        · have hpos : 0 < 2 - 2 * u := by linarith
          have hl : Real.log (2 - 2 * u) < -(1 / 2) * t := by linarith
          have := (Real.log_lt_iff_lt_exp hpos).1 hl
          constructor <;> linarith
        · exfalso
          rw [h1] at hw
          norm_num at hw
          linarith
    · rintro ⟨h1, h2⟩
      have he : Real.exp (-(1 / 2) * t) ≤ 1 := Real.exp_le_one_iff.2 (by linarith)
      have hu : 1 / 2 ≤ u := by linarith
      refine ⟨⟨hu, ?_⟩, by linarith, h2.le⟩
      rw [ite_eq_right (not_lt.2 hu), lt_max_iff]
      right
      have hpos : 0 < 2 - 2 * u := by linarith
      have := (Real.log_lt_iff_lt_exp hpos).2
        (show 2 - 2 * u < Real.exp (-(1 / 2) * t) by linarith)
      linarith
  rw [a9P, Measure.restrict_apply' measurableSet_Icc, hset, Real.volume_Ioo]
  congr 1; ring

/-- **A9 is needed** (line 935, proof line 1124): a concrete probability space (`U` uniform on
`[0, 1]`) satisfying every hypothesis of `p6_factorization_needs_A9`. On it the expected saving is
`½m(2, 2) ∈ (0.2445, 0.2455)`, the factorized value is in `(0.4385, 0.4395)`, and coverage is
not independent of the window. -/
theorem p6_A9_counterexample_exists :
    MeasurableSet a9Cov ∧ Measurable a9W ∧ (∀ ω, 0 ≤ a9W ω) ∧
      a9P a9Cov = ENNReal.ofReal (1 / 2) ∧
      (∫⁻ ω, a9Cov.indicator (1 : ℝ → ℝ≥0∞) ω * ENNReal.ofReal (min (a9W ω) 2) ∂a9P
        = ENNReal.ofReal (1 / 2 * m 2 2)) ∧
      a9P a9Cov * ∫⁻ ω, ENNReal.ofReal (min (a9W ω) 2) ∂a9P
        = ENNReal.ofReal (1 / 2 * (1 / 2 * m 2 2 + 1 / 2 * m (1 / 2) 2)) ∧
      0.2445 < 1 / 2 * m 2 2 ∧ 1 / 2 * m 2 2 < 0.2455 ∧
      0.4385 < 1 / 2 * (1 / 2 * m 2 2 + 1 / 2 * m (1 / 2) 2) ∧
      1 / 2 * (1 / 2 * m 2 2 + 1 / 2 * m (1 / 2) 2) < 0.4395 ∧
      ¬ IndepFun (a9Cov.indicator (1 : ℝ → ℝ≥0∞)) a9W a9P := by
  have hCov : MeasurableSet a9Cov := measurableSet_Iio
  have hnn : ∀ ω, 0 ≤ a9W ω := fun ω => le_max_left _ _
  obtain ⟨hL, hR, _, b1, b2, b3, b4⟩ := p6_factorization_needs_A9 a9P a9Cov hCov a9W
    a9W_measurable hnn a9_cov_mass a9_cov_surv a9_compl_surv
  refine ⟨hCov, a9W_measurable, hnn, a9_cov_mass, hL, hR, b1, b2, b3, b4, fun hind => ?_⟩
  have hf := p6_factorization a9P a9Cov hCov a9W a9W_measurable hind 0 2 (by norm_num)
  have hpw : ∀ ω, baseExposure 2 - holdExposure 0 2 (a9W ω) = min (a9W ω) 2 := fun ω => by
    rw [p6_pathwise_saving]; ring
  simp only [hpw, sub_zero, ENNReal.ofReal_one, one_mul] at hf
  rw [hL, hR] at hf
  have := (ENNReal.ofReal_eq_ofReal_iff (by linarith) (by linarith)).1 hf
  linarith

end RTTR.Hold

#print axioms RTTR.Hold.p6_pathwise_saving
#print axioms RTTR.Hold.p6i_bound
#print axioms RTTR.Hold.integral_exp_neg_mul
#print axioms RTTR.Hold.lintegral_disc_min
#print axioms RTTR.Hold.m_nonneg
#print axioms RTTR.Hold.ae_pos_of_survival
#print axioms RTTR.Hold.p6ii_exp
#print axioms RTTR.Hold.p6ii_exp_real
#print axioms RTTR.Hold.p6ii_saving
#print axioms RTTR.Hold.p6_pathwise_saving_disc
#print axioms RTTR.Hold.p6ii_saving_disc
#print axioms RTTR.Hold.p6_factorization
#print axioms RTTR.Hold.p6iii_share_eq
#print axioms RTTR.Hold.p6iii_tendsto_small
#print axioms RTTR.Hold.p6iii_small
#print axioms RTTR.Hold.p6iii_large
#print axioms RTTR.Hold.p6iii_first_stated_false
#print axioms RTTR.Hold.p6_share_le
#print axioms RTTR.Hold.m_le
#print axioms RTTR.Hold.p6iv_aggregate
#print axioms RTTR.Hold.p6v_convex
#print axioms RTTR.Hold.p6v_counterexample
#print axioms RTTR.Hold.trunc_window
#print axioms RTTR.Hold.trunc_window_eq_iff
#print axioms RTTR.Hold.p7a_no_gain
#print axioms RTTR.Hold.p7a_weak
#print axioms RTTR.Hold.p7a_strict
#print axioms RTTR.Hold.p7b_saving
#print axioms RTTR.Hold.p7b_saving_mix
#print axioms RTTR.Hold.p7b_bound
#print axioms RTTR.Hold.p7b_exp
#print axioms RTTR.Hold.completion_mono
#print axioms RTTR.Hold.pos_part_strict_iff
#print axioms RTTR.Hold.p7c_tool
#print axioms RTTR.Hold.p7c_no_shortening
#print axioms RTTR.Hold.p7_shift_discount
#print axioms RTTR.Hold.p7_delay_raises
#print axioms RTTR.Hold.p7_release_total
#print axioms RTTR.Hold.patched_ex
#print axioms RTTR.Hold.unfound_ex
#print axioms RTTR.Hold.holdTotal_eq
#print axioms RTTR.Hold.holdTotalAlt_eq
#print axioms RTTR.Hold.integrable_min
#print axioms RTTR.Hold.p7_hold_expectation
#print axioms RTTR.Hold.exp_bounds_ex
#print axioms RTTR.Hold.p7_hold_bounds
#print axioms RTTR.Hold.lagOnset_mono
#print axioms RTTR.Hold.lagOnset_release
#print axioms RTTR.Hold.p7_lag_protects
#print axioms RTTR.Hold.p7_lag_strict_example
#print axioms RTTR.Hold.hasDerivAt_m
#print axioms RTTR.Hold.mlam_neg
#print axioms RTTR.Hold.m_pos
#print axioms RTTR.Hold.m_strictAntiOn
#print axioms RTTR.Hold.p8i_deriv
#print axioms RTTR.Hold.p8ii_interior
#print axioms RTTR.Hold.p8ii_unique_signs
#print axioms RTTR.Hold.p8ii_unique_concave
#print axioms RTTR.Hold.p8iii_interior
#print axioms RTTR.Hold.p8iii_exists
#print axioms RTTR.Hold.p8iii_adjacent
#print axioms RTTR.Hold.p8iii_at_most_two
#print axioms RTTR.Hold.p8iii_unique
#print axioms RTTR.Hold.p8iii_tie_example
#print axioms RTTR.Hold.p8iv_rival
#print axioms RTTR.Hold.p8iv_rival_hazards
#print axioms RTTR.Hold.p8_corner_full
#print axioms RTTR.Hold.exp_neg_one_lt
#print axioms RTTR.Hold.one_add_mul_exp_neg_le
#print axioms RTTR.Hold.p8_corner_empty
#print axioms RTTR.Hold.p8_corner_empty_needs_tau
#print axioms RTTR.Hold.p8_rival_own_systems
#print axioms RTTR.Hold.Bint_hasDerivAt
#print axioms RTTR.Hold.p8_interior_example_signs
#print axioms RTTR.Hold.p8_interior_example_exists
#print axioms RTTR.Hold.exp_neg_two_lt
#print axioms RTTR.Hold.exp_neg_three_lt
#print axioms RTTR.Hold.exp_neg_one_gt
#print axioms RTTR.Hold.Bint_one_lt
#print axioms RTTR.Hold.Bint_two_gt
#print axioms RTTR.Hold.p8_interior_example_integer
#print axioms RTTR.Hold.p6_saving_general
#print axioms RTTR.Hold.restrict_survival
#print axioms RTTR.Hold.p6_factorization_needs_A9
#print axioms RTTR.Hold.p6_fast_gain_most
#print axioms RTTR.Hold.p6iv_aggregate_any
#print axioms RTTR.Hold.p6iv_G_eq
#print axioms RTTR.Hold.p6iv_model
#print axioms RTTR.Hold.p6_saving_pi_one
#print axioms RTTR.Hold.p6iii_ratio_small
#print axioms RTTR.Hold.p6iii_ratio_large
#print axioms RTTR.Hold.p6_fig14
#print axioms RTTR.Hold.mlam_zero
#print axioms RTTR.Hold.mlam_nonpos
#print axioms RTTR.Hold.p8ii_interior_B
#print axioms RTTR.Hold.p8ii_unique_signs_B
#print axioms RTTR.Hold.p8ii_unique_concave_B
#print axioms RTTR.Hold.p8iii_B
#print axioms RTTR.Hold.p8iv_rival_needs
#print axioms RTTR.Hold.exp_enclose
#print axioms RTTR.Hold.exp_neg_022
#print axioms RTTR.Hold.exp_neg_022'
#print axioms RTTR.Hold.exp_neg_0122
#print axioms RTTR.Hold.exp_neg_032
#print axioms RTTR.Hold.exp_neg_01
#print axioms RTTR.Hold.exp_neg_055
#print axioms RTTR.Hold.integral_exp_neg_mul_ab
#print axioms RTTR.Hold.p7c_discount_example
#print axioms RTTR.Hold.p8_rival_own_systems_values
#print axioms RTTR.Hold.p8_interior_example_not_concave
#print axioms RTTR.Hold.a9W_measurable
#print axioms RTTR.Hold.a9_cov_mass
#print axioms RTTR.Hold.a9_cov_surv
#print axioms RTTR.Hold.a9_compl_surv
#print axioms RTTR.Hold.p6_A9_counterexample_exists
