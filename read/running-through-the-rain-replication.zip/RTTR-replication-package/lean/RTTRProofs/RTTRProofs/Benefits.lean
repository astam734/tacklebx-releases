import Mathlib

/-!
# P16 — health benefits on a second adoption clock (RTTR v8, §A.3.5 and Appendix C)

Seat L7.  Every object below is defined from the paper's set-up (lines 1019–1025), and each
derivative is of the function so defined.

## Modelling choices (how each paper object is represented, and why it is faithful)

1. **Clocks.**  `clock D t₀ m s = max (D/s) ((1 − m)t₀) + m t₀` is the paper's
   `T = max{τ, (1 − m)T_a} + mT_a` (with `D = K`, `t₀ = T_a`) and
   `t_B = max{q, (1 − m_B)T_b} + m_BT_b` (with `D = K_B`, `t₀ = T_b`), line 1021, verbatim.
   Parallel timing is `m = 0`, sequential `m = 1`.
2. **Indicators.**  `ind D t₀ m s = 1` if `(1 − m)t₀ < D/s` (capability binds) and `0` otherwise;
   this is `χ_c` (resp. `χ_B`) at every speed off the kink `D/s = (1 − m)t₀`, which is the only
   place the paper uses it.  `eta L t = 1` if `t < L`, else `0`, is `η_L`.
3. **Benefit level.**  `BL y L t = y · max (L − t) 0` is `B_L = y(L − t_B)⁺` (a definition in the
   paper, line 1025); `BL_eq_integral` shows it is the integral of the flow over `(t_B, L]`.
4. **Speed-set loss.**  `Cc H K Tₐ m S s = H s · T(s) + S` is P1's loss index (a definition, A.2.2),
   `H : ℝ → ℝ` arbitrary; each theorem states the regularity it uses (differentiability at the
   speed considered, positivity of `H s` where `ε_H = sH′/H` appears).  `elast H H' s = s H'/H s`.
5. **Level-set loss**, defined as the integral `∫₀^{T(s)} h(min(st, K)) dt + S`: the capability
   path `c(t) = min(st, K)` held at `h(K)` on the adoption tail (line 1025).  `h` is taken
   continuous on ℝ; only its values on `[0, K]` enter, and any hazard continuous on `[0, K]`
   extends continuously, so this is no restriction.  `hbar h K = K⁻¹ ∫₀^K h`.  The closed form
   `τh̄ + (T − τ)h(K) + S` is **proved** (`Clev_eq`).
6. **Discounting.**  `Ar r u = ∫₀^u e^{−rt} dt` (proved `= (1 − e^{−ru})/r`); the perpetual
   benefit `Br y r t = ∫_{(t,∞)} y e^{−rx} dx` (proved `= (y/r)e^{−rt}`); the finite-horizon
   benefit `BrL y r L t = ∫_{(t, L]} y e^{−rx} dx` (proved `= (y/r)(e^{−rt} − e^{−rL})⁺`); the
   discounted level-set loss is the discounted integral of the actual path,
   `∫₀^{T(s)} e^{−rt} h(min(st,K)) dt + S_r(s)`, and its closed form (line 1329) is proved.
   `S_r : ℝ → ℝ` is the present value of the step losses, an arbitrary function differentiable
   where its derivative is used; the dated-step form `Σ_j S_j e^{−r t_j(s)}` is treated separately.
7. **"Acceleration improves the balance"** is read as the sign of the derivative of the defined
   balance in `s`, `deriv`, at the stated speed (COMMON rule 4).
8. **Kinks.**  One-sided derivatives are `HasDerivWithinAt` on `Iic s₀` / `Ici s₀`; each kink
   theorem proves both exist and states the change `s₀(W′₊ − W′₋)`.
9. **Generic calculus.**  The optimizer conditions of P16(iii) and lines 1345–1351 are stated by
   the paper for "each objective"; they are proved here for an arbitrary `f : ℝ → ℝ`
   (`fermat_Icc`, `p16_iii_kink_max/min`, `p16_suff1/2/3`) and apply to every balance above.
10. **Far loss.**  In "P4 and the objective" the paper supplies no far-loss model, so `C_A` is an
   arbitrary function differentiable at the speed considered; that row's content is algebraic.
11. **Worked examples** (`Wex`, `Wsq`, `Wub`, `Wlb`, …) are the general definitions applied to
   the paper's numbers, never separate formulas.
12. **Fix round 1.**  Kinks of every kind are handled by line 1058's own method, one general
   theorem per objective (`p16_kink_general_*`): the lower-speed side uses `indL` (capability
   binds weakly) and `eta` (arrival strictly before `L`), the higher-speed side `ind` and `etaR`
   (arrival at or before `L`), and `H`, `S_r` enter through their own one-sided derivatives.
   The horizon-truncated cyber ledgers `CcrTrunc`, `ClevrTrunc` are integrals up to
   `min(T, L)`.  The candidate theorems assume differentiability only at interior speeds off
   the kinks.
-/

open MeasureTheory intervalIntegral Set Filter Topology Real

namespace RTTRBenefits

/-! ## Definitions -/

/-- A clock with capability distance `D`, own adoption time `t₀` and share `m` waiting for
capability: `max (D/s) ((1 − m)t₀) + m t₀` (line 1021). -/
noncomputable def clock (D t₀ m s : ℝ) : ℝ := max (D / s) ((1 - m) * t₀) + m * t₀

/-- The indicator that capability sets the clock (`χ_c` or `χ_B`). -/
noncomputable def ind (D t₀ m s : ℝ) : ℝ := if (1 - m) * t₀ < D / s then 1 else 0

/-- `η_L`: the benefit arrives before the horizon. -/
noncomputable def eta (L t : ℝ) : ℝ := if t < L then 1 else 0

/-- `B_L = y(L − t_B)⁺` as a function of the arrival date. -/
noncomputable def BL (y L t : ℝ) : ℝ := y * max (L - t) 0

/-- Hazard elasticity `ε_H = sH′/H`. -/
noncomputable def elast (H : ℝ → ℝ) (H' s : ℝ) : ℝ := s * H' / H s

/-- Speed-set loss index `C_c = H(s)T(s) + S`. -/
noncomputable def Cc (H : ℝ → ℝ) (K Ta m S s : ℝ) : ℝ := H s * clock K Ta m s + S

/-- The undiscounted balance `W_L = B_L − V_c C_c`, speed-set hazard. -/
noncomputable def WL (H : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ) : ℝ :=
  BL y L (clock KB Tb mB s) - Vc * Cc H K Ta m S s

/-- Level-set loss index, **defined as the integral** of the hazard along the capability path
`c(t) = min (s t) K` over the cyber transition `[0, T(s)]`, plus `S`. -/
noncomputable def Clev (h : ℝ → ℝ) (K Ta m S s : ℝ) : ℝ :=
  (∫ t in (0:ℝ)..clock K Ta m s, h (min (s * t) K)) + S

/-- The undiscounted balance, level-set hazard. -/
noncomputable def WLlev (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ) : ℝ :=
  BL y L (clock KB Tb mB s) - Vc * Clev h K Ta m S s

/-- The ramp average `h̄ = K⁻¹ ∫₀^K h`. -/
noncomputable def hbar (h : ℝ → ℝ) (K : ℝ) : ℝ := (∫ c in (0:ℝ)..K, h c) / K

/-! ## Elementary facts about clocks -/

theorem clock_ge_cap (D t₀ m s : ℝ) (hm : 0 ≤ m) (ht : 0 ≤ t₀) : D / s ≤ clock D t₀ m s := by
  unfold clock; have := le_max_left (D / s) ((1 - m) * t₀); nlinarith [mul_nonneg hm ht]

theorem clock_ge_own (D t₀ m s : ℝ) : t₀ ≤ clock D t₀ m s := by
  unfold clock; have := le_max_right (D / s) ((1 - m) * t₀); nlinarith

theorem clock_pos (D t₀ m s : ℝ) (ht : 0 < t₀) : 0 < clock D t₀ m s :=
  lt_of_lt_of_le ht (clock_ge_own D t₀ m s)

theorem clock_cap (D t₀ m s : ℝ) (h : (1 - m) * t₀ ≤ D / s) :
    clock D t₀ m s = D / s + m * t₀ := by
  unfold clock; rw [max_eq_left h]

theorem clock_adopt (D t₀ m s : ℝ) (h : D / s ≤ (1 - m) * t₀) : clock D t₀ m s = t₀ := by
  unfold clock; rw [max_eq_right h]; ring

theorem clock_antitone (D t₀ m x x' : ℝ) (hD : 0 ≤ D) (hx : 0 < x) (hxx : x ≤ x') :
    clock D t₀ m x' ≤ clock D t₀ m x := by
  unfold clock
  have : D / x' ≤ D / x := div_le_div_of_nonneg_left hD hx hxx
  have := max_le_max this (le_refl ((1 - m) * t₀))
  linarith

theorem clock_continuousAt (D t₀ m s : ℝ) (hs : s ≠ 0) :
    ContinuousAt (fun x => clock D t₀ m x) s := by
  unfold clock
  exact ((continuousAt_const.div continuousAt_id hs).max continuousAt_const).add
    continuousAt_const

/-- `d/ds (D/s) = −(D/s)/s`. -/
theorem hasDerivAt_div_self (D s : ℝ) (hs : s ≠ 0) :
    HasDerivAt (fun x : ℝ => D / x) (-(D / s) / s) s := by
  have h := (hasDerivAt_inv hs).const_mul D
  simp only [div_eq_mul_inv] at *
  convert h using 1
  field_simp

/-- **`sT′ = −χτ` off the kink.**  The derivative of the clock is `−χ·(D/s)/s`. -/
theorem clock_hasDerivAt (D t₀ m s : ℝ) (hs : 0 < s) (hne : D / s ≠ (1 - m) * t₀) :
    HasDerivAt (fun x => clock D t₀ m x) (-(ind D t₀ m s * (D / s)) / s) s := by
  have hcd : ContinuousAt (fun x : ℝ => D / x) s := continuousAt_const.div continuousAt_id hs.ne'
  by_cases hc : (1 - m) * t₀ < D / s
  · have hev : ∀ᶠ x in 𝓝 s, clock D t₀ m x = D / x + m * t₀ := by
      filter_upwards [hcd.eventually (lt_mem_nhds hc)] with x hx
      exact clock_cap D t₀ m x hx.le
    have hd := (hasDerivAt_div_self D s hs.ne').add_const (m * t₀)
    simp only [ind, hc, ite_true, one_mul]
    exact hd.congr_of_eventuallyEq hev
  · have hlt : D / s < (1 - m) * t₀ := lt_of_le_of_ne (not_lt.mp hc) hne
    have hev : ∀ᶠ x in 𝓝 s, clock D t₀ m x = t₀ := by
      filter_upwards [hcd.eventually (gt_mem_nhds hlt)] with x hx
      exact clock_adopt D t₀ m x hx.le
    simp only [ind, hc, ite_false, zero_mul, neg_zero, zero_div]
    exact (hasDerivAt_const s t₀).congr_of_eventuallyEq hev

/-- Left derivative of a clock at its kink: the capability branch. -/
theorem clock_hasDerivWithinAt_Iic_kink (D t₀ m s₀ : ℝ) (hs : 0 < s₀) (hD : 0 ≤ D)
    (hk : D / s₀ = (1 - m) * t₀) :
    HasDerivWithinAt (fun x => clock D t₀ m x) (-(D / s₀) / s₀) (Iic s₀) s₀ := by
  have hd := ((hasDerivAt_div_self D s₀ hs.ne').add_const (m * t₀)).hasDerivWithinAt
    (s := Iic s₀)
  have hpos : ∀ᶠ x in 𝓝[Iic s₀] s₀, 0 < x :=
    eventually_nhdsWithin_of_eventually_nhds (lt_mem_nhds hs)
  refine hd.congr_of_eventuallyEq ?_ (clock_cap D t₀ m s₀ hk.ge)
  filter_upwards [hpos, self_mem_nhdsWithin] with x hx hxle
  apply clock_cap
  rw [← hk]; exact div_le_div_of_nonneg_left hD hx hxle

/-- Right derivative of a clock at its kink: the adoption branch. -/
theorem clock_hasDerivWithinAt_Ici_kink (D t₀ m s₀ : ℝ) (hs : 0 < s₀) (hD : 0 ≤ D)
    (hk : D / s₀ = (1 - m) * t₀) :
    HasDerivWithinAt (fun x => clock D t₀ m x) 0 (Ici s₀) s₀ := by
  have hd := (hasDerivAt_const s₀ t₀).hasDerivWithinAt (s := Ici s₀)
  refine hd.congr_of_eventuallyEq ?_ (clock_adopt D t₀ m s₀ hk.le)
  filter_upwards [self_mem_nhdsWithin] with x hx
  apply clock_adopt
  rw [← hk]; exact div_le_div_of_nonneg_left hD hs hx

/-- Under sequential timing the indicator is one at every positive speed (line 1023). -/
theorem ind_sequential (D t₀ s : ℝ) (hD : 0 < D) (hs : 0 < s) : ind D t₀ 1 s = 1 := by
  simp [ind, div_pos hD hs]

/-! ## The benefit level `B_L` as a function of speed -/

theorem BL_eq_integral (y L t : ℝ) :
    BL y L t = ∫ _x in Ioc t L, y := by
  rcases le_or_gt t L with h | h
  · rw [setIntegral_const, Real.volume_real_Ioc_of_le h, smul_eq_mul, BL,
      max_eq_left (by linarith)]; ring
  · rw [Ioc_eq_empty (not_lt.mpr h.le), setIntegral_empty, BL, max_eq_right (by linarith),
      mul_zero]

/-- Within any set, while arrival is strictly before the horizon, `B_L′ = −y t_B′`. -/
theorem BL_comp_within_before (y L : ℝ) (tB : ℝ → ℝ) (tB' s : ℝ) (U : Set ℝ)
    (htB : HasDerivWithinAt tB tB' U s) (hlt : tB s < L) :
    HasDerivWithinAt (fun x => BL y L (tB x)) (-(y * tB')) U s := by
  have hev : ∀ᶠ x in 𝓝[U] s, tB x < L := htB.continuousWithinAt.eventually (gt_mem_nhds hlt)
  have hd : HasDerivWithinAt (fun x => y * (L - tB x)) (y * -tB') U s :=
    (htB.const_sub L).const_mul y
  rw [show -(y * tB') = y * -tB' by ring]
  refine hd.congr_of_eventuallyEq ?_ (by simp [BL, max_eq_left (sub_nonneg.mpr hlt.le)])
  filter_upwards [hev] with x hx
  simp [BL, max_eq_left (sub_nonneg.mpr hx.le)]

/-- Within any set, while arrival is strictly after the horizon, `B_L′ = 0`. -/
theorem BL_comp_within_after (y L : ℝ) (tB : ℝ → ℝ) (tB' s : ℝ) (U : Set ℝ)
    (htB : HasDerivWithinAt tB tB' U s) (hgt : L < tB s) :
    HasDerivWithinAt (fun x => BL y L (tB x)) 0 U s := by
  have hev : ∀ᶠ x in 𝓝[U] s, L < tB x := htB.continuousWithinAt.eventually (lt_mem_nhds hgt)
  refine (hasDerivWithinAt_const s U (0:ℝ)).congr_of_eventuallyEq ?_
    (by simp [BL, max_eq_right (sub_nonpos.mpr hgt.le)])
  filter_upwards [hev] with x hx
  simp [BL, max_eq_right (sub_nonpos.mpr hx.le)]

/-- Off the horizon kink, `B_L′ = −y η_L t_B′`. -/
theorem BL_comp_hasDerivAt (y L : ℝ) (tB : ℝ → ℝ) (tB' s : ℝ) (htB : HasDerivAt tB tB' s)
    (hne : tB s ≠ L) :
    HasDerivAt (fun x => BL y L (tB x)) (-(y * eta L (tB s) * tB')) s := by
  rcases lt_or_gt_of_ne hne with h | h
  · have := BL_comp_within_before y L tB tB' s univ htB.hasDerivWithinAt h
    rw [hasDerivWithinAt_univ] at this
    simpa [eta, h] using this
  · have := BL_comp_within_after y L tB tB' s univ htB.hasDerivWithinAt h
    rw [hasDerivWithinAt_univ] at this
    simpa [eta, not_lt.mpr h.le] using this

/-- **`sB_L′ = yqχ_Bη_L`** (Appendix C, P16(i)), for the benefit clock as defined. -/
theorem p16_BL_hasDerivAt (y L KB Tb mB s : ℝ) (hs : 0 < s)
    (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    HasDerivAt (fun x => BL y L (clock KB Tb mB x))
      (y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) / s) s := by
  have := BL_comp_hasDerivAt y L (fun x => clock KB Tb mB x) _ s
    (clock_hasDerivAt KB Tb mB s hs hkB) hL
  convert this using 1; ring

/-! ## P16(i), speed-set hazard -/

/-- The undiscounted speed-set balance has derivative `D_B − V_c(H′T + HT′)` within any set on
which the clocks have those derivatives (used both off and at kinks). -/
theorem WL_hasDerivWithinAt_of (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s T' B' : ℝ)
    (U : Set ℝ) (hH : HasDerivAt H H' s)
    (hT : HasDerivWithinAt (fun x => clock K Ta m x) T' U s)
    (hB : HasDerivWithinAt (fun x => BL y L (clock KB Tb mB x)) B' U s) :
    HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x)
      (B' - Vc * (H' * clock K Ta m s + H s * T')) U s := by
  have hC : HasDerivWithinAt (fun x => Cc H K Ta m S x) (H' * clock K Ta m s + H s * T') U s :=
    by simpa [Cc] using (hH.hasDerivWithinAt.mul hT).add_const S
  exact hB.sub (hC.const_mul Vc)

/-- **P16(i), speed-set, the master formula.**  Off the clock and horizon kinks,
`sW_L′ = yqχ_Bη_L − V_cH(ε_HT − χ_cτ)`. -/
theorem p16_i_speedset_hasDerivAt (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    HasDerivAt (fun x => WL H K Ta m KB Tb mB y L Vc S x)
      ((y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
        - Vc * H s * (elast H H' s * clock K Ta m s - ind K Ta m s * (K / s))) / s) s := by
  have h := WL_hasDerivWithinAt_of H H' K Ta m KB Tb mB y L Vc S s _ _ univ hH
    (clock_hasDerivAt K Ta m s hs hkc).hasDerivWithinAt
    (p16_BL_hasDerivAt y L KB Tb mB s hs hkB hL).hasDerivWithinAt
  rw [hasDerivWithinAt_univ] at h
  convert h using 1
  unfold elast; field_simp; ring

/-! ## P16(i), level-set hazard -/

/-- The ramp integral, change of variable `c = st`. -/
theorem ramp_integral (h : ℝ → ℝ) (K s : ℝ) (hs : s ≠ 0) :
    (∫ t in (0:ℝ)..(K / s), h (s * t)) = s⁻¹ * ∫ c in (0:ℝ)..K, h c := by
  rw [integral_comp_mul_left (f := h) hs, smul_eq_mul, mul_zero, mul_div_cancel₀ K hs]

/-- The level-set path integral over `[0, T]` with `T ≥ K/s`. -/
theorem path_integral_eq (h : ℝ → ℝ) (K s T : ℝ) (hcont : Continuous h) (hs : 0 < s)
    (hK : 0 ≤ K) (hT : K / s ≤ T) :
    (∫ t in (0:ℝ)..T, h (min (s * t) K)) = s⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (T - K / s) := by
  have hτ : 0 ≤ K / s := by positivity
  have hc : Continuous (fun t : ℝ => h (min (s * t) K)) :=
    hcont.comp ((continuous_const.mul continuous_id).min continuous_const)
  have h1 : (∫ t in (0:ℝ)..(K / s), h (min (s * t) K)) = s⁻¹ * ∫ c in (0:ℝ)..K, h c := by
    rw [integral_congr_Ioo_of_le hτ (g := fun t : ℝ => h (s * t)) ?_]
    · exact ramp_integral h K s hs.ne'
    · intro t ht
      have : s * t ≤ K := by
        calc s * t ≤ s * (K / s) := mul_le_mul_of_nonneg_left ht.2.le hs.le
        _ = K := mul_div_cancel₀ K hs.ne'
      simp [min_eq_left this]
  have h2 : (∫ t in (K / s)..T, h (min (s * t) K)) = h K * (T - K / s) := by
    rw [integral_congr_Ioo_of_le hT (g := fun _ : ℝ => h K) ?_,
      intervalIntegral.integral_const, smul_eq_mul]
    · ring
    · intro t ht
      have : K ≤ s * t := by
        calc K = s * (K / s) := (mul_div_cancel₀ K hs.ne').symm
        _ ≤ s * t := mul_le_mul_of_nonneg_left ht.1.le hs.le
      simp [min_eq_right this]
  rw [← integral_add_adjacent_intervals (hc.intervalIntegrable 0 (K / s))
    (hc.intervalIntegrable (K / s) T), h1, h2]

/-- **The level-set closed form** `C_c = τh̄ + (T − τ)h(K) + S` (line 1025), proved from the
integral. -/
theorem Clev_eq (h : ℝ → ℝ) (K Ta m S s : ℝ) (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K)
    (hm : 0 ≤ m) (hTa : 0 ≤ Ta) :
    Clev h K Ta m S s = (K / s) * hbar h K + (clock K Ta m s - K / s) * h K + S := by
  rw [Clev, path_integral_eq h K s _ hcont hs hK.le (clock_ge_cap K Ta m s hm hTa), hbar]
  field_simp

/-- The level-set loss has derivative `−s⁻²∫h + h(K)(T′ + K/s²)` within any set on which the
cyber clock has derivative `T′`. -/
theorem Clev_hasDerivWithinAt_of (h : ℝ → ℝ) (K Ta m S s T' : ℝ) (U : Set ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 ≤ K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hT : HasDerivWithinAt (fun x => clock K Ta m x) T' U s) :
    HasDerivWithinAt (fun x => Clev h K Ta m S x)
      (-(s ^ 2)⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (T' + K / s ^ 2)) U s := by
  have hev : ∀ᶠ x in 𝓝[U] s, Clev h K Ta m S x
      = x⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (clock K Ta m x - K / x) + S := by
    filter_upwards [eventually_nhdsWithin_of_eventually_nhds (lt_mem_nhds hs)] with x hx
    rw [Clev, path_integral_eq h K x _ hcont hx hK (clock_ge_cap K Ta m x hm hTa)]
  have hd : HasDerivWithinAt
      (fun x => x⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (clock K Ta m x - K / x) + S)
      (-(s ^ 2)⁻¹ * (∫ c in (0:ℝ)..K, h c) + h K * (T' + K / s ^ 2)) U s := by
    have h1 := ((hasDerivAt_inv hs.ne').mul_const (∫ c in (0:ℝ)..K, h c)).hasDerivWithinAt
      (s := U)
    have h2 := ((hT.sub (hasDerivAt_div_self K s hs.ne').hasDerivWithinAt).const_mul (h K))
    have := (h1.add h2).add_const S
    convert this using 1
    field_simp; ring
  exact hd.congr_of_eventuallyEq hev (by
    rw [Clev, path_integral_eq h K s _ hcont hs hK (clock_ge_cap K Ta m s hm hTa)])

/-- **(C2)** `sC_c′ = −τh̄ + (τ − χ_cτ)h(K)` off the cyber kink. -/
theorem p16_C2 (h : ℝ → ℝ) (K Ta m S s : ℝ) (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K)
    (hm : 0 ≤ m) (hTa : 0 ≤ Ta) (hkc : K / s ≠ (1 - m) * Ta) :
    HasDerivAt (fun x => Clev h K Ta m S x)
      ((-(K / s) * hbar h K + ((K / s) - ind K Ta m s * (K / s)) * h K) / s) s := by
  have h := Clev_hasDerivWithinAt_of h K Ta m S s _ univ hcont hs hK.le hm hTa
    (clock_hasDerivAt K Ta m s hs hkc).hasDerivWithinAt
  rw [hasDerivWithinAt_univ] at h
  convert h using 1
  rw [hbar]; field_simp; ring

/-- **P16(i), level-set, the master formula.**
`sW_L′ = yqχ_Bη_L − V_cτ[(1 − χ_c)h(K) − h̄]`. -/
theorem p16_i_levelset_hasDerivAt (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    HasDerivAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x)
      ((y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
        - Vc * (K / s) * ((1 - ind K Ta m s) * h K - hbar h K)) / s) s := by
  have := (p16_BL_hasDerivAt y L KB Tb mB s hs hkB hL).sub
    ((p16_C2 h K Ta m S s hcont hs hK hm hTa hkc).const_mul Vc)
  convert this using 1
  · rfl
  · field_simp; ring


/-! ## P16(i): signs, tests and thresholds -/

/-- Signs are preserved by division by a positive speed. -/
theorem sign_div_pos (R s : ℝ) (hs : 0 < s) :
    (0 < R / s ↔ 0 < R) ∧ (R / s < 0 ↔ R < 0) ∧ (R / s = 0 ↔ R = 0) :=
  ⟨div_pos_iff_of_pos_right hs,
    ⟨fun h => by
      by_contra hc
      have := div_nonneg (not_lt.mp hc) hs.le
      linarith, fun h => div_neg_of_neg_of_pos h hs⟩,
    ⟨fun h => by rcases div_eq_zero_iff.mp h with h | h <;> [exact h; exact absurd h hs.ne'],
     fun h => by simp [h]⟩⟩

/-- **P16(i), speed-set: improves / worsens / neutral.**  The sign of the derivative of the
defined balance is the sign of the master right side, with the equality case. -/
theorem p16_i_speedset_sign (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    let R := y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
        - Vc * H s * (elast H H' s * clock K Ta m s - ind K Ta m s * (K / s))
    (0 < deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s ↔ 0 < R) ∧
    (deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s < 0 ↔ R < 0) ∧
    (deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s = 0 ↔ R = 0) := by
  intro R
  rw [(p16_i_speedset_hasDerivAt H H' K Ta m KB Tb mB y L Vc S s hs hH hHpos hkc hkB hL).deriv]
  exact sign_div_pos R s hs

/-- **P16(i), level-set: improves / worsens / neutral.** -/
theorem p16_i_levelset_sign (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    let R := y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
        - Vc * (K / s) * ((1 - ind K Ta m s) * h K - hbar h K)
    (0 < deriv (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) s ↔ 0 < R) ∧
    (deriv (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) s < 0 ↔ R < 0) ∧
    (deriv (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) s = 0 ↔ R = 0) := by
  intro R
  rw [(p16_i_levelset_hasDerivAt h K Ta m KB Tb mB y L Vc S s hcont hs hK hm hTa hkc hkB
    hL).deriv]
  exact sign_div_pos R s hs

/-- **P16(i), the headline test above the cyber kink** (speed-set): with adoption setting the
cyber clock, capability the benefit, and arrival inside the horizon, acceleration improves the
balance iff `yq > ε_H V_c H T_a`. -/
theorem p16_i_speedset_above_kink_test (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hc : K / s < (1 - m) * Ta) (hb : (1 - mB) * Tb < KB / s) (hL : clock KB Tb mB s < L) :
    0 < deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s ↔
      elast H H' s * Vc * H s * Ta < y * (KB / s) := by
  have hsg := (p16_i_speedset_sign H H' K Ta m KB Tb mB y L Vc S s hs hH hHpos hc.ne hb.ne'
    hL.ne).1
  rw [hsg]
  simp only [ind, eta, hb, hL, not_lt.mpr hc.le, ite_true, ite_false, clock_adopt K Ta m s hc.le]
  constructor <;> intro h <;> nlinarith

/-- **P16(i), the level-set test above the cyber kink**: `yq > V_cτ[h(K) − h̄]`. -/
theorem p16_i_levelset_above_kink_test (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hc : K / s < (1 - m) * Ta) (hb : (1 - mB) * Tb < KB / s) (hL : clock KB Tb mB s < L) :
    0 < deriv (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) s ↔
      Vc * (K / s) * (h K - hbar h K) < y * (KB / s) := by
  rw [(p16_i_levelset_sign h K Ta m KB Tb mB y L Vc S s hcont hs hK hm hTa hc.ne hb.ne'
    hL.ne).1]
  simp only [ind, eta, hb, hL, not_lt.mpr hc.le, ite_true, ite_false]
  constructor <;> intro h <;> nlinarith

/-- **The level-set test multiplied by `s`** (Appendix C and §4.7 line 199):
`yK_B > V_cK[h(K) − h̄]`, which does not involve `s`. -/
theorem p16_i_levelset_above_kink_test_speedfree (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hc : K / s < (1 - m) * Ta) (hb : (1 - mB) * Tb < KB / s) (hL : clock KB Tb mB s < L) :
    0 < deriv (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) s ↔
      Vc * K * (h K - hbar h K) < y * KB := by
  rw [p16_i_levelset_above_kink_test h K Ta m KB Tb mB y L Vc S s hcont hs hK hm hTa hc hb hL]
  have e1 : Vc * (K / s) * (h K - hbar h K) = (Vc * K * (h K - hbar h K)) / s := by ring
  have e2 : y * (KB / s) = (y * KB) / s := by ring
  rw [e1, e2, div_lt_div_iff_of_pos_right hs]

/-- **P16(i), the speed-set test below the cyber kink**, with its equality case:
`ε_H < [τ + yqχ_Bη_L/(V_cH)]/T`. -/
theorem p16_i_speedset_below_kink_test (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s) (hVc : 0 < Vc) (hTa : 0 < Ta)
    (hc : (1 - m) * Ta < K / s) (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    let thr := (K / s + y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
        / (Vc * H s)) / clock K Ta m s
    (0 < deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s ↔ elast H H' s < thr) ∧
    (deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s = 0 ↔ elast H H' s = thr) := by
  intro thr
  have hsg := p16_i_speedset_sign H H' K Ta m KB Tb mB y L Vc S s hs hH hHpos hc.ne' hkB hL
  have hT : 0 < clock K Ta m s := clock_pos K Ta m s hTa
  have hVH : 0 < Vc * H s := mul_pos hVc hHpos
  have hind : ind K Ta m s = 1 := by simp [ind, hc]
  rw [hind, one_mul] at hsg
  have key : y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
      - Vc * H s * (elast H H' s * clock K Ta m s - K / s)
      = Vc * H s * clock K Ta m s * (thr - elast H H' s) := by
    simp only [thr]; field_simp; ring
  have hpos : 0 < Vc * H s * clock K Ta m s := mul_pos hVH hT
  refine ⟨?_, ?_⟩
  · rw [hsg.1, key]
    constructor
    · intro h; by_contra hc'; have hc' := not_lt.mp hc'
      have : Vc * H s * clock K Ta m s * (thr - elast H H' s) ≤ 0 :=
        mul_nonpos_of_nonneg_of_nonpos hpos.le (by linarith)
      linarith
    · intro h; exact mul_pos hpos (by linarith)
  · rw [hsg.2.2, key]
    constructor
    · intro h
      rcases mul_eq_zero.mp h with h | h
      · exact absurd h hpos.ne'
      · linarith
    · intro h; rw [h, sub_self, mul_zero]

/-- Without an active benefit term the below-kink test is `ε_H < τ/T` (Section 4.3). -/
theorem p16_i_speedset_below_kink_no_benefit (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s) (hVc : 0 < Vc) (hTa : 0 < Ta)
    (hc : (1 - m) * Ta < K / s) (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L)
    (hinactive : ind KB Tb mB s * eta L (clock KB Tb mB s) = 0) :
    0 < deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s ↔
      elast H H' s < (K / s) / clock K Ta m s := by
  have := (p16_i_speedset_below_kink_test H H' K Ta m KB Tb mB y L Vc S s hs hH hHpos hVc hTa hc
    hkB hL).1
  rw [this]
  have : y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) = 0 := by
    rw [mul_assoc, hinactive, mul_zero]
  simp only [this, zero_div, add_zero]

/-- Beyond a parallel or mixed benefit kink the benefit clock is locally constant, so `B_L` has
zero derivative whatever the horizon does. -/
theorem BL_beyond_benefit_kink (y L KB Tb mB s : ℝ) (hs : 0 < s)
    (hb : KB / s < (1 - mB) * Tb) :
    HasDerivAt (fun x => BL y L (clock KB Tb mB x)) 0 s := by
  have hcd : ContinuousAt (fun x : ℝ => KB / x) s := continuousAt_const.div continuousAt_id hs.ne'
  have hev : ∀ᶠ x in 𝓝 s, BL y L (clock KB Tb mB x) = BL y L Tb := by
    filter_upwards [hcd.eventually (gt_mem_nhds hb)] with x hx
    rw [clock_adopt KB Tb mB x hx.le]
  exact (hasDerivAt_const s _).congr_of_eventuallyEq hev

/-- **"Beyond a parallel or mixed benefit kink the benefit term is zero and P1's cyber sign
returns"**, speed-set: the balance's derivative is `−V_c` times the cyber loss's. -/
theorem p16_i_speedset_beyond_benefit_kink (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hkc : K / s ≠ (1 - m) * Ta)
    (hb : KB / s < (1 - mB) * Tb) :
    deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s
      = -Vc * deriv (fun x => Cc H K Ta m S x) s := by
  have hC : HasDerivAt (fun x => Cc H K Ta m S x)
      (H' * clock K Ta m s + H s * (-(ind K Ta m s * (K / s)) / s)) s := by
    simpa [Cc] using (hH.mul (clock_hasDerivAt K Ta m s hs hkc)).add_const S
  have hW := (BL_beyond_benefit_kink y L KB Tb mB s hs hb).sub (hC.const_mul Vc)
  rw [show (fun x => WL H K Ta m KB Tb mB y L Vc S x) =
    (fun x => BL y L (clock KB Tb mB x)) - fun x => Vc * Cc H K Ta m S x from rfl, hW.deriv,
    hC.deriv]
  ring

/-- The same for the level-set hazard. -/
theorem p16_i_levelset_beyond_benefit_kink (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hkc : K / s ≠ (1 - m) * Ta) (hb : KB / s < (1 - mB) * Tb) :
    deriv (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) s
      = -Vc * deriv (fun x => Clev h K Ta m S x) s := by
  have hC := p16_C2 h K Ta m S s hcont hs hK hm hTa hkc
  have hW := (BL_beyond_benefit_kink y L KB Tb mB s hs hb).sub (hC.const_mul Vc)
  rw [show (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) =
    (fun x => BL y L (clock KB Tb mB x)) - fun x => Vc * Clev h K Ta m S x from rfl, hW.deriv,
    hC.deriv]
  ring

/-! ## The four branch cells of §4.7's table (lines 188–193), both hazards -/

/-- Speed-set, capability sets both: `yq − V_cH(ε_HT − τ)` (arrival inside the horizon). -/
theorem p16_cell_speedset_cap_cap (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hc : (1 - m) * Ta < K / s) (hb : (1 - mB) * Tb < KB / s) (hL : clock KB Tb mB s < L) :
    HasDerivAt (fun x => WL H K Ta m KB Tb mB y L Vc S x)
      ((y * (KB / s) - Vc * H s * (elast H H' s * clock K Ta m s - K / s)) / s) s := by
  have := p16_i_speedset_hasDerivAt H H' K Ta m KB Tb mB y L Vc S s hs hH hHpos hc.ne' hb.ne'
    hL.ne
  simpa [ind, eta, hc, hb, hL] using this

/-- Speed-set, adoption sets the cyber clock, capability the benefit: `yq − V_cHε_HT_a`. -/
theorem p16_cell_speedset_adopt_cap (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hc : K / s < (1 - m) * Ta) (hb : (1 - mB) * Tb < KB / s) (hL : clock KB Tb mB s < L) :
    HasDerivAt (fun x => WL H K Ta m KB Tb mB y L Vc S x)
      ((y * (KB / s) - Vc * H s * elast H H' s * Ta) / s) s := by
  have := p16_i_speedset_hasDerivAt H H' K Ta m KB Tb mB y L Vc S s hs hH hHpos hc.ne hb.ne'
    hL.ne
  convert this using 2
  simp [ind, eta, hb, hL, not_lt.mpr hc.le, clock_adopt K Ta m s hc.le]; ring

/-- Speed-set, capability sets the cyber clock, adoption the benefit: `V_cH(τ − ε_HT)`. -/
theorem p16_cell_speedset_cap_adopt (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hc : (1 - m) * Ta < K / s) (hb : KB / s < (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    HasDerivAt (fun x => WL H K Ta m KB Tb mB y L Vc S x)
      (Vc * H s * (K / s - elast H H' s * clock K Ta m s) / s) s := by
  have := p16_i_speedset_hasDerivAt H H' K Ta m KB Tb mB y L Vc S s hs hH hHpos hc.ne' hb.ne hL
  convert this using 2
  simp [ind, hc, not_lt.mpr hb.le]; ring

/-- Speed-set, adoption sets both: `−V_cHε_HT_a`. -/
theorem p16_cell_speedset_adopt_adopt (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hc : K / s < (1 - m) * Ta) (hb : KB / s < (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    HasDerivAt (fun x => WL H K Ta m KB Tb mB y L Vc S x)
      (-(Vc * H s * elast H H' s * Ta) / s) s := by
  have := p16_i_speedset_hasDerivAt H H' K Ta m KB Tb mB y L Vc S s hs hH hHpos hc.ne hb.ne hL
  convert this using 2
  simp [ind, not_lt.mpr hb.le, not_lt.mpr hc.le, clock_adopt K Ta m s hc.le]; ring

/-- **"The speed-set cell with adoption setting both clocks is strictly negative"** (line 1039),
under A4's `H′ > 0`. -/
theorem p16_cell_speedset_adopt_adopt_neg (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s) (hH' : 0 < H') (hVc : 0 < Vc)
    (hTa : 0 < Ta) (hc : K / s < (1 - m) * Ta) (hb : KB / s < (1 - mB) * Tb)
    (hL : clock KB Tb mB s ≠ L) :
    deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s < 0 := by
  rw [(p16_cell_speedset_adopt_adopt H H' K Ta m KB Tb mB y L Vc S s hs hH hHpos hc hb hL).deriv]
  have he : 0 < elast H H' s := div_pos (mul_pos hs hH') hHpos
  have : 0 < Vc * H s * elast H H' s * Ta := by positivity
  exact div_neg_of_neg_of_pos (by linarith) hs

/-- Level-set, capability sets both: `yq + V_cτh̄`. -/
theorem p16_cell_levelset_cap_cap (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hc : (1 - m) * Ta < K / s) (hb : (1 - mB) * Tb < KB / s) (hL : clock KB Tb mB s < L) :
    HasDerivAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x)
      ((y * (KB / s) + Vc * (K / s) * hbar h K) / s) s := by
  have := p16_i_levelset_hasDerivAt h K Ta m KB Tb mB y L Vc S s hcont hs hK hm hTa hc.ne' hb.ne'
    hL.ne
  convert this using 2
  simp [ind, eta, hc, hb, hL]

/-- Level-set, adoption sets the cyber clock, capability the benefit: `yq − V_cτ[h(K) − h̄]`. -/
theorem p16_cell_levelset_adopt_cap (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hc : K / s < (1 - m) * Ta) (hb : (1 - mB) * Tb < KB / s) (hL : clock KB Tb mB s < L) :
    HasDerivAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x)
      ((y * (KB / s) - Vc * (K / s) * (h K - hbar h K)) / s) s := by
  have := p16_i_levelset_hasDerivAt h K Ta m KB Tb mB y L Vc S s hcont hs hK hm hTa hc.ne hb.ne'
    hL.ne
  convert this using 2
  simp [ind, eta, hb, hL, not_lt.mpr hc.le]

/-- Level-set, capability sets the cyber clock, adoption the benefit: `V_cτh̄`. -/
theorem p16_cell_levelset_cap_adopt (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hc : (1 - m) * Ta < K / s) (hb : KB / s < (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    HasDerivAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x)
      (Vc * (K / s) * hbar h K / s) s := by
  have := p16_i_levelset_hasDerivAt h K Ta m KB Tb mB y L Vc S s hcont hs hK hm hTa hc.ne' hb.ne
    hL
  convert this using 2
  simp [ind, hc, not_lt.mpr hb.le]

/-- Level-set, adoption sets both: `−V_cτ[h(K) − h̄]`. -/
theorem p16_cell_levelset_adopt_adopt (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hc : K / s < (1 - m) * Ta) (hb : KB / s < (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    HasDerivAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x)
      (-(Vc * (K / s) * (h K - hbar h K)) / s) s := by
  have := p16_i_levelset_hasDerivAt h K Ta m KB Tb mB y L Vc S s hcont hs hK hm hTa hc.ne hb.ne hL
  convert this using 2
  simp [ind, not_lt.mpr hb.le, not_lt.mpr hc.le]

/-- **Line 1039**: the level-set cell (capability cyber, adoption benefit) is positive if
`h̄ > 0`. -/
theorem p16_cell_levelset_cap_adopt_pos (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) (hVc : 0 < Vc)
    (hc : (1 - m) * Ta < K / s) (hb : KB / s < (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L)
    (hh : 0 < hbar h K) :
    0 < deriv (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) s := by
  rw [(p16_cell_levelset_cap_adopt h K Ta m KB Tb mB y L Vc S s hcont hs hK hm hTa hc hb
    hL).deriv]
  positivity

/-- **Line 1039**: the level-set cell with adoption setting both is negative if `h(K) > h̄`,
zero at equality, positive if `h(K) < h̄`. -/
theorem p16_cell_levelset_adopt_adopt_sign (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) (hVc : 0 < Vc)
    (hc : K / s < (1 - m) * Ta) (hb : KB / s < (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    (hbar h K < h K → deriv (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) s < 0) ∧
    (hbar h K = h K → deriv (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) s = 0) ∧
    (h K < hbar h K → 0 < deriv (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) s) := by
  rw [(p16_cell_levelset_adopt_adopt h K Ta m KB Tb mB y L Vc S s hcont hs hK hm hTa hc hb
    hL).deriv]
  have hτ : 0 < Vc * (K / s) := by positivity
  refine ⟨fun h1 => ?_, fun h1 => ?_, fun h1 => ?_⟩
  · exact div_neg_of_neg_of_pos (by nlinarith) hs
  · rw [h1]; simp
  · exact div_pos (by nlinarith) hs

/-- **"as for any nondecreasing, nonconstant continuous h"** (line 1039), proved with
nonconstancy read **on the capability range `[0, K]`**: a continuous `h`, nondecreasing on
`[0, K]` and not constant there, has `h̄ < h(K)`. -/
theorem hbar_lt_of_monotoneOn_nonconst (h : ℝ → ℝ) (K : ℝ) (hK : 0 < K) (hcont : Continuous h)
    (hmono : MonotoneOn h (Icc 0 K)) (hnc : ∃ c ∈ Icc (0:ℝ) K, h c ≠ h K) : hbar h K < h K := by
  obtain ⟨c, hc, hne⟩ := hnc
  have hlt : h c < h K := lt_of_le_of_ne (hmono hc ⟨hK.le, le_refl K⟩ hc.2) hne
  have hint : (∫ x in (0:ℝ)..K, h x) < ∫ _x in (0:ℝ)..K, h K :=
    intervalIntegral.integral_lt_integral_of_continuousOn_of_le_of_exists_lt hK
      hcont.continuousOn continuousOn_const
      (fun x hx => hmono ⟨hx.1.le, hx.2⟩ ⟨hK.le, le_refl K⟩ hx.2) ⟨c, hc, hlt⟩
  rw [intervalIntegral.integral_const, smul_eq_mul, sub_zero] at hint
  rw [hbar, div_lt_iff₀ hK]; linarith

/-- **The same sentence with "nonconstant" read globally fails**: `h(c) = max(c − 1, 0)` is
continuous, nondecreasing and nonconstant on ℝ, yet with `K = 1` it has `h̄ = h(K) = 0`, so the
adoption-sets-both level-set cell is zero, not negative. -/
theorem hbar_eq_endpoint_counterexample :
    let h : ℝ → ℝ := fun c => max (c - 1) 0
    Continuous h ∧ Monotone h ∧ (∃ a b, h a ≠ h b) ∧ hbar h 1 = h 1 := by
  intro h
  refine ⟨by fun_prop, fun a b hab => max_le_max (by linarith) le_rfl, ⟨0, 2, ?_⟩, ?_⟩
  · simp [h]; norm_num
  · have : (∫ c in (0:ℝ)..1, h c) = ∫ _c in (0:ℝ)..1, (0:ℝ) := by
      apply integral_congr; intro c hc
      rw [uIcc_of_le zero_le_one] at hc
      simp [h, max_eq_right (by linarith [hc.2] : c - 1 ≤ 0)]
    simp [hbar, this, h]

/-! ## The kink table (lines 1041–1045) and the branch orderings (1047–1054) -/

/-- Below a parallel or mixed kink `D/((1 − m)t₀)` capability binds, and conversely. -/
theorem kink_iff (D t₀ m s : ℝ) (hs : 0 < s) (ht : 0 < t₀) (hm1 : m < 1) :
    (1 - m) * t₀ < D / s ↔ s < D / ((1 - m) * t₀) := by
  have hpos : 0 < (1 - m) * t₀ := mul_pos (by linarith) ht
  rw [lt_div_iff₀ hs, lt_div_iff₀ hpos, mul_comm]

/-- Duration below the kink: `D/s + m t₀` (`τ` under parallel, `τ + mT_a` under mixed). -/
theorem clock_below_kink (D t₀ m s : ℝ) (hs : 0 < s) (ht : 0 < t₀) (hm1 : m < 1)
    (h : s ≤ D / ((1 - m) * t₀)) : clock D t₀ m s = D / s + m * t₀ := by
  have hpos : 0 < (1 - m) * t₀ := mul_pos (by linarith) ht
  apply clock_cap
  rw [le_div_iff₀ hs]; rw [le_div_iff₀ hpos] at h; linarith

/-- Duration above the kink: `t₀`. -/
theorem clock_above_kink (D t₀ m s : ℝ) (hs : 0 < s) (ht : 0 < t₀) (hm1 : m < 1)
    (h : D / ((1 - m) * t₀) ≤ s) : clock D t₀ m s = t₀ := by
  have hpos : 0 < (1 - m) * t₀ := mul_pos (by linarith) ht
  apply clock_adopt
  rw [div_le_iff₀ hs]; rw [div_le_iff₀ hpos] at h; linarith

/-- Sequential timing: no finite kink, duration `D/s + t₀` at every positive speed. -/
theorem clock_sequential (D t₀ s : ℝ) (hD : 0 ≤ D) (hs : 0 < s) :
    clock D t₀ 1 s = D / s + t₀ := by
  rw [clock_cap D t₀ 1 s (by simp; positivity)]; ring

/-- The indicator as a step in speed at the kink. -/
theorem ind_eq_step (D t₀ m s : ℝ) (hs : 0 < s) (ht : 0 < t₀) (hm1 : m < 1) :
    ind D t₀ m s = if s < D / ((1 - m) * t₀) then 1 else 0 := by
  simp only [ind, kink_iff D t₀ m s hs ht hm1]

/-- **Branch orderings, parallel or mixed on both clocks** (rows 1–3 of the second table).
With cyber kink `k_c` and benefit kink `k_B`, the pair `(χ_c, χ_B)` at speed `s` is
`(1,1)` below both, `(0,1)` between when `k_c < k_B`, `(1,0)` between when `k_B < k_c`, and `(0,0)`
above both (coincident kinks leave no middle region). -/
theorem p16_branch_order_finite (K Ta m KB Tb mB s : ℝ) (hs : 0 < s) (hTa : 0 < Ta)
    (hTb : 0 < Tb) (hm1 : m < 1) (hmB1 : mB < 1) :
    (s < K / ((1 - m) * Ta) → s < KB / ((1 - mB) * Tb) →
      ind K Ta m s = 1 ∧ ind KB Tb mB s = 1) ∧
    (K / ((1 - m) * Ta) < s → s < KB / ((1 - mB) * Tb) →
      ind K Ta m s = 0 ∧ ind KB Tb mB s = 1) ∧
    (KB / ((1 - mB) * Tb) < s → s < K / ((1 - m) * Ta) →
      ind K Ta m s = 1 ∧ ind KB Tb mB s = 0) ∧
    (K / ((1 - m) * Ta) < s → KB / ((1 - mB) * Tb) < s →
      ind K Ta m s = 0 ∧ ind KB Tb mB s = 0) := by
  rw [ind_eq_step K Ta m s hs hTa hm1, ind_eq_step KB Tb mB s hs hTb hmB1]
  refine ⟨fun h1 h2 => by simp [h1, h2], fun h1 h2 => ?_, fun h1 h2 => ?_, fun h1 h2 => ?_⟩
  · simp [h2, not_lt.mpr h1.le]
  · simp [h2, not_lt.mpr h1.le]
  · simp [not_lt.mpr h1.le, not_lt.mpr h2.le]

/-- **Rows 4–6**: a sequential clock's indicator is one at every speed, so with sequential
benefit timing the pairs are `(1,1)` below the cyber kink and `(0,1)` above it; with sequential
cyber timing `(1,1)` below the benefit kink and `(1,0)` above; sequential on both, `(1,1)`. -/
theorem p16_branch_order_sequential (K Ta m KB Tb mB s : ℝ) (hs : 0 < s) (hK : 0 < K)
    (hKB : 0 < KB) (hTa : 0 < Ta) (hTb : 0 < Tb) :
    (m < 1 → ind KB Tb 1 s = 1 ∧ ind K Ta m s = if s < K / ((1 - m) * Ta) then 1 else 0) ∧
    (mB < 1 → ind K Ta 1 s = 1 ∧ ind KB Tb mB s = if s < KB / ((1 - mB) * Tb) then 1 else 0) ∧
    (ind K Ta 1 s = 1 ∧ ind KB Tb 1 s = 1) :=
  ⟨fun hm => ⟨ind_sequential KB Tb s hKB hs, ind_eq_step K Ta m s hs hTa hm⟩,
   fun hm => ⟨ind_sequential K Ta s hK hs, ind_eq_step KB Tb mB s hs hTb hm⟩,
   ⟨ind_sequential K Ta s hK hs, ind_sequential KB Tb s hKB hs⟩⟩

/-! ## The horizon paragraph (line 1056) -/

/-- **If `L ≤ T_b`, the benefit yields no flow within the horizon at any speed and under any
timing** (including `L = T_b`: reaching the plateau at the horizon activates nothing). -/
theorem p16_horizon_none (y L KB Tb mB s : ℝ) (hL : L ≤ Tb) :
    BL y L (clock KB Tb mB s) = 0 := by
  have := clock_ge_own KB Tb mB s
  simp [BL, max_eq_right (by linarith : L - clock KB Tb mB s ≤ 0)]

/-- **If `L > T_b`, arrival is inside the horizon exactly above `k_L = K_B/(L − m_BT_b)`.** -/
theorem p16_horizon_activation (KB Tb mB L s : ℝ) (hs : 0 < s) (hTb : 0 < Tb) (_hmB0 : 0 ≤ mB)
    (hmB1 : mB ≤ 1) (hL : Tb < L) :
    clock KB Tb mB s < L ↔ KB / (L - mB * Tb) < s := by
  have hgap : 0 < L - mB * Tb := by nlinarith
  unfold clock
  rw [← lt_sub_iff_add_lt, max_lt_iff, div_lt_iff₀ hgap, div_lt_iff₀ hs]
  constructor
  · intro h; linarith [h.1]
  · intro h; exact ⟨by linarith, by nlinarith⟩

/-- At `k_L` arrival is exactly at the horizon, strictly on the benefit's capability branch, and
(for a finite benefit kink) strictly below that kink (Appendix C, line 1339). -/
theorem p16_horizon_kL_on_cap_branch (KB Tb mB L : ℝ) (hKB : 0 < KB) (hTb : 0 < Tb)
    (_hmB0 : 0 ≤ mB) (hmB1 : mB ≤ 1) (hL : Tb < L) :
    clock KB Tb mB (KB / (L - mB * Tb)) = L ∧ (1 - mB) * Tb < KB / (KB / (L - mB * Tb)) ∧
      (mB < 1 → KB / (L - mB * Tb) < KB / ((1 - mB) * Tb)) := by
  have hgap : 0 < L - mB * Tb := by nlinarith
  have hq : KB / (KB / (L - mB * Tb)) = L - mB * Tb := by field_simp
  have hcap : (1 - mB) * Tb < KB / (KB / (L - mB * Tb)) := by rw [hq]; nlinarith
  refine ⟨?_, hcap, fun hm => ?_⟩
  · rw [clock_cap KB Tb mB _ hcap.le, hq]; ring
  · have hpos : 0 < (1 - mB) * Tb := mul_pos (by linarith) hTb
    apply div_lt_div_of_pos_left hKB hpos
    nlinarith


/-! ## Kinks: one-sided derivatives and the changes in `sW′` (line 1058, Appendix C line 1339) -/

/-- Horizon activation, lower-speed side: arrival is after the horizon, `B_L′₋ = 0`. -/
theorem BL_activation_left (y L KB Tb mB s₀ : ℝ) (hKB : 0 ≤ KB) (hs : 0 < s₀)
    (hL : clock KB Tb mB s₀ = L) :
    HasDerivWithinAt (fun x => BL y L (clock KB Tb mB x)) 0 (Iic s₀) s₀ := by
  refine (hasDerivWithinAt_const s₀ (Iic s₀) (0:ℝ)).congr_of_eventuallyEq ?_
    (by simp [BL, hL])
  filter_upwards [eventually_nhdsWithin_of_eventually_nhds (lt_mem_nhds hs),
    self_mem_nhdsWithin] with x hx hxle
  have := clock_antitone KB Tb mB x s₀ hKB hx hxle
  simp [BL, max_eq_right (by linarith : L - clock KB Tb mB x ≤ 0)]

/-- Horizon activation, higher-speed side: arrival is before the horizon, `B_L′₊ = −y t_B′₊`. -/
theorem BL_activation_right (y L KB Tb mB s₀ tB' : ℝ) (hKB : 0 ≤ KB) (hs : 0 < s₀)
    (hL : clock KB Tb mB s₀ = L)
    (htB : HasDerivWithinAt (fun x => clock KB Tb mB x) tB' (Ici s₀) s₀) :
    HasDerivWithinAt (fun x => BL y L (clock KB Tb mB x)) (-(y * tB')) (Ici s₀) s₀ := by
  have hd : HasDerivWithinAt (fun x => y * (L - clock KB Tb mB x)) (y * -tB') (Ici s₀) s₀ :=
    (htB.const_sub L).const_mul y
  rw [show -(y * tB') = y * -tB' by ring]
  refine hd.congr_of_eventuallyEq ?_ (by simp [BL, hL])
  filter_upwards [self_mem_nhdsWithin] with x hx
  have := clock_antitone KB Tb mB s₀ x hKB hs hx
  simp [BL, max_eq_left (by linarith : 0 ≤ L - clock KB Tb mB x)]

/-- Benefit-side one-sided derivative off the horizon kink, within any set. -/
theorem BL_within_offhorizon (y L KB Tb mB s tB' : ℝ) (U : Set ℝ)
    (htB : HasDerivWithinAt (fun x => clock KB Tb mB x) tB' U s) (hL : clock KB Tb mB s ≠ L) :
    HasDerivWithinAt (fun x => BL y L (clock KB Tb mB x))
      (-(y * eta L (clock KB Tb mB s) * tB')) U s := by
  rcases lt_or_gt_of_ne hL with h | h
  · simpa [eta, h] using BL_comp_within_before y L _ tB' s U htB h
  · simpa [eta, not_lt.mpr h.le] using BL_comp_within_after y L _ tB' s U htB h

/-- **Cyber kink alone, speed-set**: the change in `sW′` from the lower-speed side to the
higher is `−V_cHτ`. -/
theorem p16_kink_cyber_speedset (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hs : 0 < s₀) (hK : 0 ≤ K) (hH : HasDerivAt H H' s₀)
    (hkc : K / s₀ = (1 - m) * Ta) (hkB : KB / s₀ ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * H s₀ * (K / s₀)) := by
  have hB := p16_BL_hasDerivAt y L KB Tb mB s₀ hs hkB hL
  refine ⟨_, _, WL_hasDerivWithinAt_of H H' K Ta m KB Tb mB y L Vc S s₀ _ _ (Iic s₀) hH
    (clock_hasDerivWithinAt_Iic_kink K Ta m s₀ hs hK hkc) hB.hasDerivWithinAt,
    WL_hasDerivWithinAt_of H H' K Ta m KB Tb mB y L Vc S s₀ _ _ (Ici s₀) hH
    (clock_hasDerivWithinAt_Ici_kink K Ta m s₀ hs hK hkc) hB.hasDerivWithinAt, ?_⟩
  field_simp; ring

/-- **Cyber kink alone, level-set**: the change is `−V_cτh(K)`. -/
theorem p16_kink_cyber_levelset (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 ≤ K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hkc : K / s₀ = (1 - m) * Ta) (hkB : KB / s₀ ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * (K / s₀) * h K) := by
  have hB0 := p16_BL_hasDerivAt y L KB Tb mB s₀ hs hkB hL
  refine ⟨_, _, (hB0.hasDerivWithinAt (s := Iic s₀)).sub ((Clev_hasDerivWithinAt_of h K Ta m S s₀ _ (Iic s₀) hcont
    hs hK hm hTa (clock_hasDerivWithinAt_Iic_kink K Ta m s₀ hs hK hkc)).const_mul Vc),
    (hB0.hasDerivWithinAt (s := Ici s₀)).sub ((Clev_hasDerivWithinAt_of h K Ta m S s₀ _ (Ici s₀) hcont hs hK hm
    hTa (clock_hasDerivWithinAt_Ici_kink K Ta m s₀ hs hK hkc)).const_mul Vc), ?_⟩
  field_simp; ring

/-- **Benefit kink alone, speed-set**: the change is `−yq` if arrival is inside the horizon and
zero if not (`−yqη_L`). -/
theorem p16_kink_benefit_speedset (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hs : 0 < s₀) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hkc : K / s₀ ≠ (1 - m) * Ta) (hkB : KB / s₀ = (1 - mB) * Tb) (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(y * (KB / s₀) * eta L (clock KB Tb mB s₀)) := by
  have hT0 := clock_hasDerivAt K Ta m s₀ hs hkc
  refine ⟨_, _, WL_hasDerivWithinAt_of H H' K Ta m KB Tb mB y L Vc S s₀ _ _ (Iic s₀) hH hT0.hasDerivWithinAt
    (BL_within_offhorizon y L KB Tb mB s₀ _ (Iic s₀)
      (clock_hasDerivWithinAt_Iic_kink KB Tb mB s₀ hs hKB hkB) hL),
    WL_hasDerivWithinAt_of H H' K Ta m KB Tb mB y L Vc S s₀ _ _ (Ici s₀) hH hT0.hasDerivWithinAt
    (BL_within_offhorizon y L KB Tb mB s₀ _ (Ici s₀)
      (clock_hasDerivWithinAt_Ici_kink KB Tb mB s₀ hs hKB hkB) hL), ?_⟩
  field_simp; ring

/-- **Benefit kink alone, level-set**: the same change `−yqη_L`, whatever the hazard. -/
theorem p16_kink_benefit_levelset (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hkc : K / s₀ ≠ (1 - m) * Ta) (hkB : KB / s₀ = (1 - mB) * Tb) (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(y * (KB / s₀) * eta L (clock KB Tb mB s₀)) := by
  have hC0 := (p16_C2 h K Ta m S s₀ hcont hs hK hm hTa hkc).const_mul Vc
  refine ⟨_, _, (BL_within_offhorizon y L KB Tb mB s₀ _ (Iic s₀)
      (clock_hasDerivWithinAt_Iic_kink KB Tb mB s₀ hs hKB hkB) hL).sub (hC0.hasDerivWithinAt (s := Iic s₀)),
    (BL_within_offhorizon y L KB Tb mB s₀ _ (Ici s₀)
      (clock_hasDerivWithinAt_Ici_kink KB Tb mB s₀ hs hKB hkB) hL).sub (hC0.hasDerivWithinAt (s := Ici s₀)), ?_⟩
  field_simp; ring

/-- **Coincident cyber and benefit kinks, speed-set**: the changes add, `−V_cHτ − yqη_L`. -/
theorem p16_kink_coincident_speedset (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hs : 0 < s₀) (hK : 0 ≤ K) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hkc : K / s₀ = (1 - m) * Ta) (hkB : KB / s₀ = (1 - mB) * Tb) (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * H s₀ * (K / s₀)) - y * (KB / s₀) * eta L (clock KB Tb mB s₀) := by
  refine ⟨_, _, WL_hasDerivWithinAt_of H H' K Ta m KB Tb mB y L Vc S s₀ _ _ (Iic s₀) hH
    (clock_hasDerivWithinAt_Iic_kink K Ta m s₀ hs hK hkc)
    (BL_within_offhorizon y L KB Tb mB s₀ _ (Iic s₀)
      (clock_hasDerivWithinAt_Iic_kink KB Tb mB s₀ hs hKB hkB) hL),
    WL_hasDerivWithinAt_of H H' K Ta m KB Tb mB y L Vc S s₀ _ _ (Ici s₀) hH
    (clock_hasDerivWithinAt_Ici_kink K Ta m s₀ hs hK hkc)
    (BL_within_offhorizon y L KB Tb mB s₀ _ (Ici s₀)
      (clock_hasDerivWithinAt_Ici_kink KB Tb mB s₀ hs hKB hkB) hL), ?_⟩
  field_simp; ring

/-- **Horizon-activation kink alone, speed-set**: the change is `+yq`. -/
theorem p16_kink_activation_speedset (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hs : 0 < s₀) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hkc : K / s₀ ≠ (1 - m) * Ta) (hcap : (1 - mB) * Tb < KB / s₀)
    (hL : clock KB Tb mB s₀ = L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = y * (KB / s₀) := by
  have hT0 := clock_hasDerivAt K Ta m s₀ hs hkc
  have htB := (clock_hasDerivAt KB Tb mB s₀ hs hcap.ne').hasDerivWithinAt (s := Ici s₀)
  refine ⟨_, _, WL_hasDerivWithinAt_of H H' K Ta m KB Tb mB y L Vc S s₀ _ _ (Iic s₀) hH hT0.hasDerivWithinAt
    (BL_activation_left y L KB Tb mB s₀ hKB hs hL),
    WL_hasDerivWithinAt_of H H' K Ta m KB Tb mB y L Vc S s₀ _ _ (Ici s₀) hH hT0.hasDerivWithinAt
    (BL_activation_right y L KB Tb mB s₀ _ hKB hs hL htB), ?_⟩
  simp only [ind, hcap, ite_true]
  field_simp; ring

/-- **Horizon-activation kink alone, level-set**: the change is `+yq`. -/
theorem p16_kink_activation_levelset (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hkc : K / s₀ ≠ (1 - m) * Ta) (hcap : (1 - mB) * Tb < KB / s₀)
    (hL : clock KB Tb mB s₀ = L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = y * (KB / s₀) := by
  have hC0 := (p16_C2 h K Ta m S s₀ hcont hs hK hm hTa hkc).const_mul Vc
  have htB := (clock_hasDerivAt KB Tb mB s₀ hs hcap.ne').hasDerivWithinAt (s := Ici s₀)
  refine ⟨_, _, (BL_activation_left y L KB Tb mB s₀ hKB hs hL).sub (hC0.hasDerivWithinAt (s := Iic s₀)),
    (BL_activation_right y L KB Tb mB s₀ _ hKB hs hL htB).sub (hC0.hasDerivWithinAt (s := Ici s₀)), ?_⟩
  simp only [ind, hcap, ite_true]
  field_simp; ring

/-- "The maximum of continuous clock functions is continuous": both objectives are continuous at
every positive speed where `H` is (resp. for continuous `h`). -/
theorem WL_continuousAt (H : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ) (hs : 0 < s)
    (hH : ContinuousAt H s) : ContinuousAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) s := by
  unfold WL BL Cc
  have h1 := clock_continuousAt KB Tb mB s hs.ne'
  have h2 := clock_continuousAt K Ta m s hs.ne'
  exact (continuousAt_const.mul ((continuousAt_const.sub h1).max continuousAt_const)).sub
    (continuousAt_const.mul ((hH.mul h2).add continuousAt_const))

theorem WLlev_continuousAt (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s : ℝ) (hcont : Continuous h)
    (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) :
    ContinuousAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) s := by
  have hev : (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) =ᶠ[𝓝 s]
      fun x => BL y L (clock KB Tb mB x)
        - Vc * ((K / x) * hbar h K + (clock K Ta m x - K / x) * h K + S) := by
    filter_upwards [lt_mem_nhds hs] with x hx
    simp only [WLlev, Clev_eq h K Ta m S x hcont hx hK hm hTa]
  refine ContinuousAt.congr ?_ hev.symm
  have h1 := clock_continuousAt KB Tb mB s hs.ne'
  have h2 := clock_continuousAt K Ta m s hs.ne'
  have h3 : ContinuousAt (fun x : ℝ => K / x) s := continuousAt_const.div continuousAt_id hs.ne'
  unfold BL
  exact (continuousAt_const.mul ((continuousAt_const.sub h1).max continuousAt_const)).sub
    (continuousAt_const.mul (((h3.mul continuousAt_const).add
      ((h2.sub h3).mul continuousAt_const)).add continuousAt_const))

/-! ## P16(iii): existence, candidates, and the kink conditions -/

/-- **P16(iii), existence, speed-set**: on `[s_min, s_max]` with `s_min > 0` and `H` continuous,
the balance attains a maximum and a minimum. -/
theorem p16_iii_exists_speedset (H : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S a b : ℝ) (ha : 0 < a)
    (hab : a ≤ b) (hH : ContinuousOn H (Icc a b)) :
    (∃ x ∈ Icc a b, IsMaxOn (fun x => WL H K Ta m KB Tb mB y L Vc S x) (Icc a b) x) ∧
    (∃ x ∈ Icc a b, IsMinOn (fun x => WL H K Ta m KB Tb mB y L Vc S x) (Icc a b) x) := by
  have hc : ContinuousOn (fun x => WL H K Ta m KB Tb mB y L Vc S x) (Icc a b) := by
    intro x hx
    have hx0 : 0 < x := lt_of_lt_of_le ha hx.1
    unfold WL BL Cc
    exact ((continuousAt_const.mul ((continuousAt_const.sub
      (clock_continuousAt KB Tb mB x hx0.ne')).max continuousAt_const)).continuousWithinAt).sub
      (continuousWithinAt_const.mul (((hH x hx).mul
      (clock_continuousAt K Ta m x hx0.ne').continuousWithinAt).add continuousWithinAt_const))
  exact ⟨isCompact_Icc.exists_isMaxOn (nonempty_Icc.mpr hab) hc,
    isCompact_Icc.exists_isMinOn (nonempty_Icc.mpr hab) hc⟩

/-- **P16(iii), existence, level-set.** -/
theorem p16_iii_exists_levelset (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S a b : ℝ)
    (hcont : Continuous h) (ha : 0 < a) (hab : a ≤ b) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) :
    (∃ x ∈ Icc a b, IsMaxOn (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) (Icc a b) x) ∧
    (∃ x ∈ Icc a b, IsMinOn (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) (Icc a b) x) := by
  have hc : ContinuousOn (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) (Icc a b) := fun x hx =>
    (WLlev_continuousAt h K Ta m KB Tb mB y L Vc S x hcont (lt_of_lt_of_le ha hx.1) hK hm
      hTa).continuousWithinAt
  exact ⟨isCompact_Icc.exists_isMaxOn (nonempty_Icc.mpr hab) hc,
    isCompact_Icc.exists_isMinOn (nonempty_Icc.mpr hab) hc⟩

/-- Fermat on a closed interval: an extremum on `[a, b]` at an interior point of
differentiability has zero derivative. -/
theorem fermat_Icc (f : ℝ → ℝ) (a b x d : ℝ) (hx : x ∈ Ioo a b) (hd : HasDerivAt f d x)
    (hext : IsMaxOn f (Icc a b) x ∨ IsMinOn f (Icc a b) x) : d = 0 := by
  have hn : Icc a b ∈ 𝓝 x := Icc_mem_nhds hx.1 hx.2
  rcases hext with h | h
  · exact (h.isLocalMax hn).hasDerivAt_eq_zero hd
  · exact (h.isLocalMin hn).hasDerivAt_eq_zero hd

/-- **P16(iii), the candidates, speed-set**: an optimizer on `[a, b]` is an endpoint, a cyber or
benefit clock kink, a horizon kink, or a smooth stationary point (`W′ = 0`).  `H` need be
differentiable only at interior speeds off these kinks (fix round 1). -/
theorem p16_iii_candidates_speedset (H : ℝ → ℝ) (H'f : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S a b x : ℝ)
    (ha : 0 < a) (hx : x ∈ Icc a b)
    (hH : ∀ z ∈ Ioo a b, K / z ≠ (1 - m) * Ta → KB / z ≠ (1 - mB) * Tb → clock KB Tb mB z ≠ L →
      HasDerivAt H (H'f z) z)
    (hext : IsMaxOn (fun x => WL H K Ta m KB Tb mB y L Vc S x) (Icc a b) x ∨
      IsMinOn (fun x => WL H K Ta m KB Tb mB y L Vc S x) (Icc a b) x) :
    x = a ∨ x = b ∨ K / x = (1 - m) * Ta ∨ KB / x = (1 - mB) * Tb ∨ clock KB Tb mB x = L ∨
      ∃ d, HasDerivAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) d x ∧ d = 0 := by
  by_cases h1 : x = a; · exact Or.inl h1
  by_cases h2 : x = b; · exact Or.inr (Or.inl h2)
  by_cases h3 : K / x = (1 - m) * Ta; · exact Or.inr (Or.inr (Or.inl h3))
  by_cases h4 : KB / x = (1 - mB) * Tb; · exact Or.inr (Or.inr (Or.inr (Or.inl h4)))
  by_cases h5 : clock KB Tb mB x = L; · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h5))))
  right; right; right; right; right
  have hx0 : 0 < x := lt_of_lt_of_le ha hx.1
  have hxI : x ∈ Ioo a b := ⟨lt_of_le_of_ne hx.1 (Ne.symm h1), lt_of_le_of_ne hx.2 h2⟩
  have hd := WL_hasDerivWithinAt_of H (H'f x) K Ta m KB Tb mB y L Vc S x _ _ univ
    (hH x hxI h3 h4 h5)
    (clock_hasDerivAt K Ta m x hx0 h3).hasDerivWithinAt
    (p16_BL_hasDerivAt y L KB Tb mB x hx0 h4 h5).hasDerivWithinAt
  rw [hasDerivWithinAt_univ] at hd
  exact ⟨_, hd, fermat_Icc _ a b x _ hxI hd hext⟩

/-- **P16(iii), the candidates, level-set.** -/
theorem p16_iii_candidates_levelset (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S a b x : ℝ)
    (hcont : Continuous h) (ha : 0 < a) (hx : x ∈ Icc a b) (hK : 0 < K) (hm : 0 ≤ m)
    (hTa : 0 ≤ Ta)
    (hext : IsMaxOn (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) (Icc a b) x ∨
      IsMinOn (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) (Icc a b) x) :
    x = a ∨ x = b ∨ K / x = (1 - m) * Ta ∨ KB / x = (1 - mB) * Tb ∨ clock KB Tb mB x = L ∨
      ∃ d, HasDerivAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) d x ∧ d = 0 := by
  by_cases h1 : x = a; · exact Or.inl h1
  by_cases h2 : x = b; · exact Or.inr (Or.inl h2)
  by_cases h3 : K / x = (1 - m) * Ta; · exact Or.inr (Or.inr (Or.inl h3))
  by_cases h4 : KB / x = (1 - mB) * Tb; · exact Or.inr (Or.inr (Or.inr (Or.inl h4)))
  by_cases h5 : clock KB Tb mB x = L; · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h5))))
  right; right; right; right; right
  have hx0 : 0 < x := lt_of_lt_of_le ha hx.1
  have hxI : x ∈ Ioo a b := ⟨lt_of_le_of_ne hx.1 (Ne.symm h1), lt_of_le_of_ne hx.2 h2⟩
  have hd := p16_i_levelset_hasDerivAt h K Ta m KB Tb mB y L Vc S x hcont hx0 hK hm hTa h3 h4 h5
  exact ⟨_, hd, fermat_Icc _ a b x _ hxI hd hext⟩

/-- One-sided derivative sign → strict comparison just to the right. -/
theorem right_cmp_of_hasDerivWithinAt {f : ℝ → ℝ} {x d : ℝ} (h : HasDerivWithinAt f d (Ici x) x) :
    (d < 0 → ∀ᶠ y in 𝓝[>] x, f y < f x) ∧ (0 < d → ∀ᶠ y in 𝓝[>] x, f x < f y) := by
  have h' := h.mono (Ioi_subset_Ici_self (a := x))
  rw [hasDerivWithinAt_iff_tendsto_slope,
    sdiff_singleton_eq_self (show x ∉ Ioi x from lt_irrefl x)] at h'
  refine ⟨fun hd => ?_, fun hd => ?_⟩
  · filter_upwards [h'.eventually (gt_mem_nhds hd), self_mem_nhdsWithin] with y hy hyx
    rw [slope_def_field] at hy
    have hyx' : 0 < y - x := sub_pos.mpr hyx
    have := (div_neg_iff.mp hy)
    rcases this with ⟨_, h2⟩ | ⟨h1, _⟩
    · linarith
    · linarith
  · filter_upwards [h'.eventually (lt_mem_nhds hd), self_mem_nhdsWithin] with y hy hyx
    rw [slope_def_field] at hy
    have hyx' : 0 < y - x := sub_pos.mpr hyx
    have := (lt_div_iff₀ hyx').mp hy
    linarith

/-- One-sided derivative sign → strict comparison just to the left. -/
theorem left_cmp_of_hasDerivWithinAt {f : ℝ → ℝ} {x d : ℝ} (h : HasDerivWithinAt f d (Iic x) x) :
    (0 < d → ∀ᶠ y in 𝓝[<] x, f y < f x) ∧ (d < 0 → ∀ᶠ y in 𝓝[<] x, f x < f y) := by
  have h' := h.mono (Iio_subset_Iic_self (a := x))
  rw [hasDerivWithinAt_iff_tendsto_slope,
    sdiff_singleton_eq_self (show x ∉ Iio x from lt_irrefl x)] at h'
  refine ⟨fun hd => ?_, fun hd => ?_⟩
  · filter_upwards [h'.eventually (lt_mem_nhds hd), self_mem_nhdsWithin] with y hy hyx
    rw [slope_def_field] at hy
    have hyx' : y - x < 0 := sub_neg.mpr hyx
    have := (lt_div_iff_of_neg hyx').mp hy
    linarith
  · filter_upwards [h'.eventually (gt_mem_nhds hd), self_mem_nhdsWithin] with y hy hyx
    rw [slope_def_field] at hy
    have hyx' : y - x < 0 := sub_neg.mpr hyx
    have := (div_lt_iff_of_neg hyx').mp hy
    linarith

/-- **Kink conditions (iii), maximum**: a local maximum at a kink requires `W′₋ ≥ 0 ≥ W′₊`, and
strict inequalities make it a strict local maximum. -/
theorem p16_iii_kink_max (f : ℝ → ℝ) (x dl dr : ℝ) (hl : HasDerivWithinAt f dl (Iic x) x)
    (hr : HasDerivWithinAt f dr (Ici x) x) :
    (IsLocalMax f x → 0 ≤ dl ∧ dr ≤ 0) ∧
    (0 < dl → dr < 0 → ∀ᶠ y in 𝓝[≠] x, f y < f x) := by
  refine ⟨fun hmax => ⟨?_, ?_⟩, fun h1 h2 => ?_⟩
  · by_contra hc
    have e1 := (left_cmp_of_hasDerivWithinAt hl).2 (lt_of_not_ge hc)
    have e2 : ∀ᶠ y in 𝓝[<] x, f y ≤ f x := nhdsWithin_le_nhds hmax
    have := (e1.and e2).exists
    obtain ⟨y, hy1, hy2⟩ := this
    linarith
  · by_contra hc
    have e1 := (right_cmp_of_hasDerivWithinAt hr).2 (lt_of_not_ge hc)
    have e2 : ∀ᶠ y in 𝓝[>] x, f y ≤ f x := nhdsWithin_le_nhds hmax
    obtain ⟨y, hy1, hy2⟩ := (e1.and e2).exists
    linarith
  · rw [← nhdsLT_sup_nhdsGT, eventually_sup]
    exact ⟨(left_cmp_of_hasDerivWithinAt hl).1 h1, (right_cmp_of_hasDerivWithinAt hr).1 h2⟩

/-- **Kink conditions (iii), minimum**: the reversed inequalities. -/
theorem p16_iii_kink_min (f : ℝ → ℝ) (x dl dr : ℝ) (hl : HasDerivWithinAt f dl (Iic x) x)
    (hr : HasDerivWithinAt f dr (Ici x) x) :
    (IsLocalMin f x → dl ≤ 0 ∧ 0 ≤ dr) ∧
    (dl < 0 → 0 < dr → ∀ᶠ y in 𝓝[≠] x, f x < f y) := by
  have := p16_iii_kink_max (fun y => -f y) x (-dl) (-dr) hl.neg hr.neg
  refine ⟨fun hmin => ?_, fun h1 h2 => ?_⟩
  · have := this.1 hmin.neg; constructor <;> linarith [this.1, this.2]
  · filter_upwards [this.2 (by linarith) (by linarith)] with y hy; linarith

/-! ## Sufficient conditions for an interior maximum (lines 1345–1351) -/

/-- **Condition 1**: positive right derivative at `s_min` and negative left derivative at `s_max`
⇒ neither endpoint maximizes, and a global maximum exists in the interior. -/
theorem p16_suff1_interior_max (f : ℝ → ℝ) (a b d₁ d₂ : ℝ) (hab : a < b)
    (hc : ContinuousOn f (Icc a b)) (ha : HasDerivWithinAt f d₁ (Ici a) a) (hd₁ : 0 < d₁)
    (hb : HasDerivWithinAt f d₂ (Iic b) b) (hd₂ : d₂ < 0) :
    ¬ IsMaxOn f (Icc a b) a ∧ ¬ IsMaxOn f (Icc a b) b ∧
      ∃ x ∈ Ioo a b, IsMaxOn f (Icc a b) x := by
  have hna : ¬ IsMaxOn f (Icc a b) a := by
    intro hmax
    have e1 := (right_cmp_of_hasDerivWithinAt ha).2 hd₁
    obtain ⟨y, hy1, hy2⟩ := (e1.and (Ioo_mem_nhdsGT hab)).exists
    have := hmax ⟨hy2.1.le, hy2.2.le⟩
    simp at this; linarith
  have hnb : ¬ IsMaxOn f (Icc a b) b := by
    intro hmax
    have e1 := (left_cmp_of_hasDerivWithinAt hb).2 hd₂
    obtain ⟨y, hy1, hy2⟩ := (e1.and (Ioo_mem_nhdsLT hab)).exists
    have := hmax ⟨hy2.1.le, hy2.2.le⟩
    simp at this; linarith
  obtain ⟨x, hx, hmax⟩ := isCompact_Icc.exists_isMaxOn (nonempty_Icc.mpr hab.le) hc
  refine ⟨hna, hnb, x, ⟨lt_of_le_of_ne hx.1 ?_, lt_of_le_of_ne hx.2 ?_⟩, hmax⟩
  · rintro rfl; exact hna hmax
  · rintro rfl; exact hnb hmax

/-- Strict local maximum from a derivative positive just below and negative just above. -/
theorem strict_localmax_of_deriv_sign (f : ℝ → ℝ) (x : ℝ) (hc : ContinuousAt f x)
    (hl : ∀ᶠ y in 𝓝[<] x, DifferentiableAt ℝ f y ∧ 0 < deriv f y)
    (hr : ∀ᶠ y in 𝓝[>] x, DifferentiableAt ℝ f y ∧ deriv f y < 0) :
    ∀ᶠ y in 𝓝[≠] x, f y < f x := by
  obtain ⟨a, hax, ha⟩ := (nhdsLT_basis x).eventually_iff.mp hl
  obtain ⟨b, hxb, hb⟩ := (nhdsGT_basis x).eventually_iff.mp hr
  have hmono : StrictMonoOn f (Ioc a x) := by
    apply strictMonoOn_of_deriv_pos (convex_Ioc a x)
    · intro y hy
      rcases eq_or_lt_of_le hy.2 with rfl | hlt
      · exact hc.continuousWithinAt
      · exact (ha ⟨hy.1, hlt⟩).1.continuousAt.continuousWithinAt
    · intro y hy; rw [interior_Ioc] at hy; exact (ha hy).2
  have hanti : StrictAntiOn f (Ico x b) := by
    apply strictAntiOn_of_deriv_neg (convex_Ico x b)
    · intro y hy
      rcases eq_or_lt_of_le hy.1 with rfl | hlt
      · exact hc.continuousWithinAt
      · exact (hb ⟨hlt, hy.2⟩).1.continuousAt.continuousWithinAt
    · intro y hy; rw [interior_Ico] at hy; exact (hb hy).2
  rw [← nhdsLT_sup_nhdsGT, eventually_sup]
  refine ⟨?_, ?_⟩
  · filter_upwards [Ioo_mem_nhdsLT hax] with y hy
    exact hmono ⟨hy.1, hy.2.le⟩ ⟨hax, le_rfl⟩ hy.2
  · filter_upwards [Ioo_mem_nhdsGT hxb] with y hy
    exact hanti ⟨le_rfl, hxb⟩ ⟨hy.1.le, hy.2⟩ hy.1

/-- **Condition 2**: at a smooth stationary speed, `W″(s₀) < 0` suffices for a strict local
maximum (smooth: differentiable on a neighbourhood). -/
theorem p16_suff2_second_deriv (f : ℝ → ℝ) (x c : ℝ)
    (hdiff : ∀ᶠ y in 𝓝 x, DifferentiableAt ℝ f y) (hstat : deriv f x = 0)
    (h2 : HasDerivAt (deriv f) c x) (hc : c < 0) :
    ∀ᶠ y in 𝓝[≠] x, f y < f x := by
  have hl := (left_cmp_of_hasDerivWithinAt h2.hasDerivWithinAt).2 hc
  have hr := (right_cmp_of_hasDerivWithinAt h2.hasDerivWithinAt).1 hc
  rw [hstat] at hl hr
  apply strict_localmax_of_deriv_sign f x (hdiff.self_of_nhds).continuousAt
  · filter_upwards [hl, nhdsWithin_le_nhds hdiff] with y h1 h2 using ⟨h2, h1⟩
  · filter_upwards [hr, nhdsWithin_le_nhds hdiff] with y h1 h2 using ⟨h2, h1⟩

/-- **Condition 2, "equality in a one-sided sign alone does not"**: `f = x` on the left and
`x²` on the right has left derivative `1 > 0` and right derivative `0` at the origin, and the
origin is not a local maximum. -/
theorem p16_suff2_equality_fails :
    let f : ℝ → ℝ := fun x => if x ≤ 0 then x else x ^ 2
    HasDerivWithinAt f 1 (Iic 0) 0 ∧ HasDerivWithinAt f 0 (Ici 0) 0 ∧ ¬ IsLocalMax f 0 := by
  intro f
  refine ⟨?_, ?_, ?_⟩
  · refine (hasDerivAt_id (0:ℝ)).hasDerivWithinAt.congr_of_eventuallyEq ?_ (by simp [f])
    filter_upwards [self_mem_nhdsWithin] with y hy
    simp [f, show y ≤ 0 from hy]
  · have hd : HasDerivAt (fun x : ℝ => x ^ 2) 0 0 := by
      simpa using (hasDerivAt_pow 2 (0:ℝ))
    refine hd.hasDerivWithinAt.congr_of_eventuallyEq ?_ (by simp [f])
    filter_upwards [self_mem_nhdsWithin] with y hy
    rcases eq_or_lt_of_le (show (0:ℝ) ≤ y from hy) with h | h
    · subst h; simp [f]
    · simp [f, not_le.mpr h]
  · intro hmax
    have e : ∀ᶠ y in 𝓝[>] (0:ℝ), f 0 < f y := by
      filter_upwards [self_mem_nhdsWithin] with y hy
      have hy' : (0:ℝ) < y := hy
      simp [f, not_le.mpr hy']; positivity
    obtain ⟨y, h1, h2⟩ := (e.and (nhdsWithin_le_nhds hmax)).exists
    linarith

/-- Strict increase across finitely many points where the derivative is not controlled. -/
theorem strict_incr_finite_exc (f : ℝ → ℝ) (E : Finset ℝ) :
    ∀ n : ℕ, ∀ x y, x < y → ContinuousOn f (Icc x y) →
      (∀ z ∈ Ioo x y, z ∉ E → 0 < deriv f z) →
      (E.filter (fun e => e ∈ Ioo x y)).card ≤ n → f x < f y := by
  intro n
  induction n with
  | zero =>
    intro x y hxy hc hd hcard
    have hempty : E.filter (fun e => e ∈ Ioo x y) = ∅ := Finset.card_eq_zero.mp (by omega)
    apply strictMonoOn_of_deriv_pos (convex_Icc x y) hc _ ⟨le_rfl, hxy.le⟩ ⟨hxy.le, le_rfl⟩ hxy
    intro z hz
    rw [interior_Icc] at hz
    apply hd z hz
    intro hzE
    have : z ∈ E.filter (fun e => e ∈ Ioo x y) := Finset.mem_filter.mpr ⟨hzE, hz⟩
    rw [hempty] at this; simp at this
  | succ n ih =>
    intro x y hxy hc hd hcard
    by_cases hne : (E.filter (fun e => e ∈ Ioo x y)).Nonempty
    · obtain ⟨e, he⟩ := hne
      have heE := Finset.mem_filter.mp he
      have hsub1 : E.filter (fun z => z ∈ Ioo x e) ⊂ E.filter (fun z => z ∈ Ioo x y) := by
        refine Finset.ssubset_iff_of_subset ?_ |>.mpr ⟨e, he, ?_⟩
        · intro z hz
          have := Finset.mem_filter.mp hz
          exact Finset.mem_filter.mpr ⟨this.1, this.2.1, lt_trans this.2.2 heE.2.2⟩
        · intro h; have := (Finset.mem_filter.mp h).2.2; exact lt_irrefl e this
      have hsub2 : E.filter (fun z => z ∈ Ioo e y) ⊂ E.filter (fun z => z ∈ Ioo x y) := by
        refine Finset.ssubset_iff_of_subset ?_ |>.mpr ⟨e, he, ?_⟩
        · intro z hz
          have := Finset.mem_filter.mp hz
          exact Finset.mem_filter.mpr ⟨this.1, lt_trans heE.2.1 this.2.1, this.2.2⟩
        · intro h; have := (Finset.mem_filter.mp h).2.1; exact lt_irrefl e this
      have c1 := Finset.card_lt_card hsub1
      have c2 := Finset.card_lt_card hsub2
      have i1 := ih x e heE.2.1 (hc.mono (Icc_subset_Icc le_rfl heE.2.2.le))
        (fun z hz hzE => hd z ⟨hz.1, lt_trans hz.2 heE.2.2⟩ hzE) (by omega)
      have i2 := ih e y heE.2.2 (hc.mono (Icc_subset_Icc heE.2.1.le le_rfl))
        (fun z hz hzE => hd z ⟨lt_trans heE.2.1 hz.1, hz.2⟩ hzE) (by omega)
      linarith
    · rw [Finset.not_nonempty_iff_eq_empty] at hne
      exact ih x y hxy hc hd (by rw [hne]; simp)

/-- **Condition 3**: if `W′ > 0` at all smooth speeds below `s₀` and `W′ < 0` at all smooth
speeds above it, with continuity across finitely many kinks `E`, then `s₀` is the unique global
maximum on `[a, b]`. -/
theorem p16_suff3_unique_global_max (f : ℝ → ℝ) (a b x₀ : ℝ) (E : Finset ℝ)
    (hx₀ : x₀ ∈ Icc a b) (hc : ContinuousOn f (Icc a b))
    (hpos : ∀ z ∈ Ioo a x₀, z ∉ E → 0 < deriv f z)
    (hneg : ∀ z ∈ Ioo x₀ b, z ∉ E → deriv f z < 0) :
    ∀ x ∈ Icc a b, x ≠ x₀ → f x < f x₀ := by
  intro x hx hne
  rcases lt_or_gt_of_ne hne with h | h
  · exact strict_incr_finite_exc f E _ x x₀ h (hc.mono (Icc_subset_Icc hx.1 hx₀.2))
      (fun z hz hzE => hpos z ⟨lt_of_le_of_lt hx.1 hz.1, hz.2⟩ hzE) le_rfl
  · have := strict_incr_finite_exc (fun z => -f z) E _ x₀ x h
      (hc.neg.mono (Icc_subset_Icc hx₀.1 hx.2))
      (fun z hz hzE => by
        rw [show (fun z => -f z) = -f from rfl, deriv.neg]; exact neg_pos.mpr (hneg z ⟨hz.1, lt_of_lt_of_le hz.2 hx.2⟩ hzE)) le_rfl
    linarith


/-! ## The illustrative optimum and the counterexamples (line 1060; §4.7 line 209)

Values: `K = T_a = V_c = y = T_b = 1`, `K_B = 4`, parallel timing (`m = m_B = 0`), `H = s`,
`S = 0`, `L = 10`, `I = [0.5, 6]`. -/

/-- Section 4.7's illustrative balance, built from the general definitions. -/
noncomputable def Wex (s : ℝ) : ℝ := WL (fun x => x) 1 1 0 4 1 0 1 10 1 0 s

theorem ex_unfold (s : ℝ) :
    Wex s = max (10 - max (4 / s) 1) 0 - s * max (1 / s) 1 := by
  simp [Wex, WL, BL, Cc, clock]

/-- `W_L = 9 − 4/s` on `[0.5, 1]`. -/
theorem ex_piece1 (s : ℝ) (h1 : 1 / 2 ≤ s) (h2 : s ≤ 1) : Wex s = 9 - 4 / s := by
  have hs : 0 < s := by linarith
  rw [ex_unfold, max_eq_left (show 1 ≤ 4 / s by rw [le_div_iff₀ hs]; linarith),
    max_eq_left (show 1 ≤ 1 / s by rw [le_div_iff₀ hs]; linarith),
    max_eq_left (show 0 ≤ 10 - 4 / s by
      have : 4 / s ≤ 8 := by rw [div_le_iff₀ hs]; linarith
      linarith)]
  field_simp; ring

/-- `W_L = 10 − 4/s − s` on `[1, 4]`. -/
theorem ex_piece2 (s : ℝ) (h1 : 1 ≤ s) (h2 : s ≤ 4) : Wex s = 10 - 4 / s - s := by
  have hs : 0 < s := by linarith
  rw [ex_unfold, max_eq_left (show 1 ≤ 4 / s by rw [le_div_iff₀ hs]; linarith),
    max_eq_right (show 1 / s ≤ 1 by rw [div_le_iff₀ hs]; linarith),
    max_eq_left (show 0 ≤ 10 - 4 / s by
      have : 4 / s ≤ 4 := by rw [div_le_iff₀ hs]; linarith
      linarith)]
  ring

/-- `W_L = 9 − s` on `[4, 6]` (indeed for every `s ≥ 4`). -/
theorem ex_piece3 (s : ℝ) (h1 : 4 ≤ s) : Wex s = 9 - s := by
  have hs : 0 < s := by linarith
  rw [ex_unfold, max_eq_right (show 4 / s ≤ 1 by rw [div_le_iff₀ hs]; linarith),
    max_eq_right (show 1 / s ≤ 1 by rw [div_le_iff₀ hs]; linarith)]
  norm_num

/-- The listed values: 1, 5, 6, 5, 3 at `s = 0.5, 1, 2, 4, 6`; and 4 at `s = 5`. -/
theorem ex_values :
    Wex (1 / 2) = 1 ∧ Wex 1 = 5 ∧ Wex 2 = 6 ∧ Wex 4 = 5 ∧ Wex 6 = 3 ∧ Wex 5 = 4 := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [ex_piece1 _ le_rfl (by norm_num)]; norm_num
  · rw [ex_piece1 _ (by norm_num) le_rfl]; norm_num
  · rw [ex_piece2 _ (by norm_num) (by norm_num)]; norm_num
  · rw [ex_piece3 _ le_rfl]; norm_num
  · rw [ex_piece3 _ (by norm_num)]; norm_num
  · rw [ex_piece3 _ (by norm_num)]; norm_num

/-- The kinks: cyber `s* = K/T_a = 1`, benefit `K_B/T_b = 4`; cyber completion and benefit
arrival fall within the horizon throughout `I`. -/
theorem ex_kinks_and_horizon :
    (1:ℝ) / ((1 - 0) * 1) = 1 ∧ (4:ℝ) / ((1 - 0) * 1) = 4 ∧
    ∀ s ∈ Icc (1 / 2 : ℝ) 6, clock 1 1 0 s ≤ 10 ∧ clock 4 1 0 s < 10 := by
  refine ⟨by norm_num, by norm_num, fun s hs => ?_⟩
  have hs0 : 0 < s := by linarith [hs.1]
  have e1 : 1 / s ≤ 2 := by rw [div_le_iff₀ hs0]; linarith [hs.1]
  have e2 : 4 / s ≤ 8 := by rw [div_le_iff₀ hs0]; linarith [hs.1]
  simp only [clock]
  constructor
  · have := max_le e1 (show (1 - 0) * (1:ℝ) ≤ 2 by norm_num); linarith
  · have := max_le e2 (show (1 - 0) * (1:ℝ) ≤ 8 by norm_num); linarith

/-- **The unique global maximum on `[0.5, 6]` is `s₀ = 2`, with `W_L = 6`.** -/
theorem ex_unique_global_max :
    IsMaxOn Wex (Icc (1 / 2) 6) 2 ∧ ∀ s ∈ Icc (1 / 2 : ℝ) 6, s ≠ 2 → Wex s < 6 := by
  have key : ∀ s ∈ Icc (1 / 2 : ℝ) 6, s ≠ 2 → Wex s < 6 := by
    intro s hs hne
    rcases le_or_gt s 1 with h1 | h1
    · rw [ex_piece1 s hs.1 h1]
      have hs0 : 0 < s := by linarith [hs.1]
      have : 4 ≤ 4 / s := by rw [le_div_iff₀ hs0]; linarith
      linarith
    rcases le_or_gt s 4 with h4 | h4
    · rw [ex_piece2 s h1.le h4]
      have hs0 : 0 < s := by linarith
      have hsq : 0 < (s - 2) ^ 2 := by positivity
      rw [show 10 - 4 / s - s = 6 - (s - 2) ^ 2 / s by field_simp; ring]
      have : 0 < (s - 2) ^ 2 / s := div_pos hsq hs0
      linarith
    · rw [ex_piece3 s h4.le]; linarith
  refine ⟨fun s hs => ?_, key⟩
  show Wex s ≤ Wex 2
  rw [ex_values.2.2.1]
  by_cases h : s = 2
  · rw [h, ex_values.2.2.1]
  · exact (key s hs h).le

/-- Derivative `4/s² > 0` below the cyber kink. -/
theorem ex_deriv_piece1 (s : ℝ) (hs : s ∈ Ioo (1 / 2 : ℝ) 1) :
    HasDerivAt Wex (4 / s ^ 2) s := by
  have hs0 : 0 < s := by linarith [hs.1]
  have hev : (fun x => 9 - 4 / x) =ᶠ[𝓝 s] Wex := by
    filter_upwards [Ioo_mem_nhds hs.1 hs.2] with x hx
    rw [ex_piece1 x hx.1.le hx.2.le]
  have hd := (hasDerivAt_div_self 4 s hs0.ne').const_sub 9
  refine (hd.congr_of_eventuallyEq hev.symm).congr_deriv ?_
  field_simp

/-- Derivative `4/s² − 1` between the kinks. -/
theorem ex_deriv_piece2 (s : ℝ) (hs : s ∈ Ioo (1:ℝ) 4) :
    HasDerivAt Wex (4 / s ^ 2 - 1) s := by
  have hs0 : 0 < s := by linarith [hs.1]
  have hev : (fun x => 10 - 4 / x - x) =ᶠ[𝓝 s] Wex := by
    filter_upwards [Ioo_mem_nhds hs.1 hs.2] with x hx
    rw [ex_piece2 x hx.1.le hx.2.le]
  have hd := ((hasDerivAt_div_self 4 s hs0.ne').const_sub 10).sub (hasDerivAt_id s)
  refine (hd.congr_of_eventuallyEq hev.symm).congr_deriv ?_
  simp; field_simp

/-- Derivative `−1` above the benefit kink. -/
theorem ex_deriv_piece3 (s : ℝ) (hs : 4 < s) : HasDerivAt Wex (-1) s := by
  have hev : (fun x => 9 - x) =ᶠ[𝓝 s] Wex := by
    filter_upwards [lt_mem_nhds hs] with x hx
    rw [ex_piece3 x hx.le]
  have hd := (hasDerivAt_id s).const_sub 9
  exact (hd.congr_of_eventuallyEq hev.symm).congr_deriv (by simp)

/-- **The one-sided derivatives**: 4 and 3 at `s = 1`, `−3/4` and `−1` at `s = 4`. -/
theorem ex_one_sided :
    HasDerivWithinAt Wex 4 (Iic 1) 1 ∧ HasDerivWithinAt Wex 3 (Ici 1) 1 ∧
    HasDerivWithinAt Wex (-3 / 4) (Iic 4) 4 ∧ HasDerivWithinAt Wex (-1) (Ici 4) 4 := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · have hd := ((hasDerivAt_div_self 4 1 one_ne_zero).const_sub 9).hasDerivWithinAt
      (s := Iic (1:ℝ))
    refine (hd.congr_of_eventuallyEq ?_ (by rw [ex_piece1 1 (by norm_num) le_rfl])).congr_deriv
      (by norm_num)
    filter_upwards [eventually_nhdsWithin_of_eventually_nhds (lt_mem_nhds
      (show (1 / 2 : ℝ) < 1 by norm_num)), self_mem_nhdsWithin] with x hx hx1
    exact ex_piece1 x hx.le hx1
  · have hd := (((hasDerivAt_div_self 4 1 one_ne_zero).const_sub 10).sub
      (hasDerivAt_id 1)).hasDerivWithinAt (s := Ici (1:ℝ))
    refine (hd.congr_of_eventuallyEq ?_ (by rw [ex_piece2 1 le_rfl (by norm_num)]; simp)).congr_deriv
      (by norm_num)
    filter_upwards [eventually_nhdsWithin_of_eventually_nhds (gt_mem_nhds
      (show (1:ℝ) < 4 by norm_num)), self_mem_nhdsWithin] with x hx hx1
    exact ex_piece2 x hx1 hx.le
  · have hd := (((hasDerivAt_div_self 4 4 (by norm_num)).const_sub 10).sub
      (hasDerivAt_id 4)).hasDerivWithinAt (s := Iic (4:ℝ))
    refine (hd.congr_of_eventuallyEq ?_ (by rw [ex_piece2 4 (by norm_num) le_rfl]; simp)).congr_deriv
      (by norm_num)
    filter_upwards [eventually_nhdsWithin_of_eventually_nhds (lt_mem_nhds
      (show (1:ℝ) < 4 by norm_num)), self_mem_nhdsWithin] with x hx hx1
    exact ex_piece2 x hx.le hx1
  · have hd := ((hasDerivAt_id (4:ℝ)).const_sub 9).hasDerivWithinAt (s := Ici (4:ℝ))
    refine (hd.congr_of_eventuallyEq ?_ (by rw [ex_piece3 4 le_rfl]; simp)).congr_deriv (by norm_num)
    filter_upwards [self_mem_nhdsWithin] with x hx
    exact ex_piece3 x hx

/-- **"Cyber loss is rising at the optimum; the benefit balances its marginal rise"**: at `s = 2`
the cyber loss has derivative 1, the benefit has derivative 1, and `W_L′(2) = 0`. -/
theorem ex_optimum_balance :
    HasDerivAt (fun x => Cc (fun x => x) 1 1 0 0 x) 1 2 ∧
    HasDerivAt (fun x => BL 1 10 (clock 4 1 0 x)) 1 2 ∧ HasDerivAt Wex 0 2 := by
  have hs : (0:ℝ) < 2 := by norm_num
  have hC := (hasDerivAt_id (2:ℝ)).mul (clock_hasDerivAt 1 1 0 2 hs (by norm_num))
  have hL2 : clock 4 1 0 2 ≠ 10 := by
    rw [clock_cap 4 1 0 2 (by norm_num)]; norm_num
  have hB := p16_BL_hasDerivAt 1 10 4 1 0 2 hs (by norm_num) hL2
  refine ⟨?_, ?_, ?_⟩
  · have := hC.add_const 0
    refine this.congr_deriv ?_
    simp only [ind, clock]; norm_num
  · refine hB.congr_deriv ?_
    simp only [ind, eta, clock]; norm_num
  · exact (ex_deriv_piece2 2 ⟨by norm_num, by norm_num⟩).congr_deriv (by norm_num)

/-- `W_L″(2) = −1 < 0`, so condition 2 certifies `s = 2` as a strict local maximum too. -/
theorem ex_second_deriv : HasDerivAt (deriv Wex) (-1) 2 := by
  have hev : (fun x => 4 / x ^ 2 - 1) =ᶠ[𝓝 (2:ℝ)] deriv Wex := by
    filter_upwards [Ioo_mem_nhds (show (1:ℝ) < 2 by norm_num) (show (2:ℝ) < 4 by norm_num)]
      with x hx
    exact (ex_deriv_piece2 x hx).deriv.symm
  have hd : HasDerivAt (fun x : ℝ => 4 / x ^ 2 - 1) (-1) 2 := by
    have h1 := ((hasDerivAt_pow 2 (2:ℝ)).inv (by norm_num)).const_mul 4
    have h2 := h1.sub_const 1
    refine (h2.congr_deriv (by norm_num)).congr_of_eventuallyEq ?_
    filter_upwards with x
    simp [div_eq_mul_inv]
  exact hd.congr_of_eventuallyEq hev.symm

/-- **The `s = 5` counterexample to "benefits always justify speed"**: the benefit level is 9
but its derivative is zero, `W_L′(5) = −1`, and the balance falls from 4 to 3 between 5 and 6. -/
theorem ex_s5_counterexample :
    BL 1 10 (clock 4 1 0 5) = 9 ∧ HasDerivAt (fun x => BL 1 10 (clock 4 1 0 x)) 0 5 ∧
    HasDerivAt Wex (-1) 5 ∧ Wex 5 = 4 ∧ Wex 6 = 3 := by
  refine ⟨?_, BL_beyond_benefit_kink 1 10 4 1 0 5 (by norm_num) (by norm_num),
    ex_deriv_piece3 5 (by norm_num), ex_values.2.2.2.2.2, ex_values.2.2.2.2.1⟩
  rw [clock_adopt 4 1 0 5 (by norm_num)]; norm_num [BL]

/-- The `H = s²` variant of the illustrative instance. -/
noncomputable def Wsq (s : ℝ) : ℝ := WL (fun x => x ^ 2) 1 1 0 4 1 0 1 10 1 0 s

/-- **`H = s²` at `s = 0.5`**: `ε_H = 2 > 1`, `C_c′ = 1 > 0`, `B_L′ = 16` and `W_L′ = 15 > 0`.
Benefits outweigh a rising cyber loss below the cyber kink with `ε_H > 1`.  The last conjunct
ties the `H′ = 2·(1/2)` used in `ε_H` to the hazard `s²` (fix round 1). -/
theorem ex_Hsq :
    elast (fun x => x ^ 2) (2 * (1 / 2)) (1 / 2) = 2 ∧
    HasDerivAt (fun x => Cc (fun x => x ^ 2) 1 1 0 0 x) 1 (1 / 2) ∧
    HasDerivAt (fun x => BL 1 10 (clock 4 1 0 x)) 16 (1 / 2) ∧
    HasDerivAt Wsq 15 (1 / 2) ∧
    HasDerivAt (fun x : ℝ => x ^ 2) (2 * (1 / 2)) (1 / 2) := by
  have hs : (0:ℝ) < 1 / 2 := by norm_num
  have hH : HasDerivAt (fun x : ℝ => x ^ 2) (2 * (1 / 2)) (1 / 2) := by
    simpa using hasDerivAt_pow 2 (1 / 2 : ℝ)
  have hkc : (1:ℝ) / (1 / 2) ≠ (1 - 0) * 1 := by norm_num
  have hkB : (4:ℝ) / (1 / 2) ≠ (1 - 0) * 1 := by norm_num
  have hL : clock 4 1 0 (1 / 2) ≠ 10 := by rw [clock_cap 4 1 0 _ (by norm_num)]; norm_num
  have hC := (hH.mul (clock_hasDerivAt 1 1 0 (1 / 2) hs hkc)).add_const 0
  have hB := p16_BL_hasDerivAt 1 10 4 1 0 (1 / 2) hs hkB hL
  have hW := p16_i_speedset_hasDerivAt (fun x => x ^ 2) (2 * (1 / 2)) 1 1 0 4 1 0 1 10 1 0
    (1 / 2) hs hH (by norm_num) hkc hkB hL
  refine ⟨by simp [elast]; norm_num, ?_, ?_, ?_, hH⟩
  · refine hC.congr_deriv ?_
    simp only [ind, clock]; norm_num
  · refine hB.congr_deriv ?_
    simp only [ind, eta, clock]; norm_num
  · refine hW.congr_deriv ?_
    simp only [ind, eta, elast, clock]; norm_num

/-! ## Existence needs both bounds (line 1343) -/

/-- The unbounded-interval instance: sequential benefit timing, parallel cyber timing,
`K = T_a = K_B = T_b = V_c = y = 1`, `S = 0`, `L = 10`, `H(s) = 1 − 1/(2s)`. -/
noncomputable def Wub (s : ℝ) : ℝ := WL (fun x => 1 - 1 / (2 * x)) 1 1 0 1 1 1 1 10 1 0 s

theorem ub_closed (s : ℝ) (hs : 1 ≤ s) : Wub s = 8 - 1 / (2 * s) := by
  have hs0 : 0 < s := by linarith
  simp only [Wub, WL, BL, Cc, clock]
  rw [max_eq_right (show 1 / s ≤ (1 - 0) * 1 by rw [div_le_iff₀ hs0]; linarith),
    max_eq_left (show (1 - 1) * (1:ℝ) ≤ 1 / s by simp; positivity),
    max_eq_left (show (0:ℝ) ≤ 10 - (1 / s + 1 * 1) by
      have : 1 / s ≤ 1 := by rw [div_le_iff₀ hs0]; linarith
      linarith)]
  field_simp; ring

/-- **The unattained supremum**: on `[1, ∞)` the hazard is positive and increasing, the
balance is `8 − 1/(2s)`, strictly increasing, below 8 everywhere, with supremum 8, and no
maximizer exists. -/
theorem p16_existence_needs_upper_bound :
    (∀ s ∈ Ici (1:ℝ), 0 < 1 - 1 / (2 * s) ∧
      HasDerivAt (fun x : ℝ => 1 - 1 / (2 * x)) (1 / (2 * s ^ 2)) s ∧ 0 < 1 / (2 * s ^ 2)) ∧
    StrictMonoOn Wub (Ici 1) ∧ (∀ s ∈ Ici (1:ℝ), Wub s < 8) ∧
    (∀ ε > 0, ∃ s ∈ Ici (1:ℝ), 8 - ε < Wub s) ∧ ¬ ∃ x ∈ Ici (1:ℝ), IsMaxOn Wub (Ici 1) x := by
  have hlt : ∀ s ∈ Ici (1:ℝ), Wub s < 8 := by
    intro s hs
    rw [ub_closed s hs]
    have : 0 < 1 / (2 * s) := by have : (0:ℝ) < s := by linarith [mem_Ici.mp hs]
                                 positivity
    linarith
  have hmono : StrictMonoOn Wub (Ici 1) := by
    intro a ha b hb hab
    rw [ub_closed a ha, ub_closed b hb]
    have ha0 : (0:ℝ) < a := by linarith [mem_Ici.mp ha]
    have : 1 / (2 * b) < 1 / (2 * a) := by
      apply one_div_lt_one_div_of_lt (by positivity); linarith
    linarith
  refine ⟨fun s hs => ?_, hmono, hlt, fun ε hε => ?_, ?_⟩
  · have hs0 : (0:ℝ) < s := by linarith [mem_Ici.mp hs]
    refine ⟨?_, ?_, by positivity⟩
    · have : 1 / (2 * s) ≤ 1 / 2 := by
        rw [div_le_div_iff₀ (by positivity) (by norm_num)]; linarith [mem_Ici.mp hs]
      linarith
    · have h := ((hasDerivAt_id s).const_mul 2).inv (by simp only [id]; positivity)
      have h2 := h.const_sub 1
      refine (h2.congr_deriv ?_).congr_of_eventuallyEq ?_
      · simp only [id]; field_simp
      · filter_upwards with x; simp [one_div]
  · refine ⟨max 1 (1 / ε), mem_Ici.mpr (le_max_left _ _), ?_⟩
    have hx : 1 ≤ max 1 (1 / ε) := le_max_left _ _
    rw [ub_closed _ hx]
    have hx0 : 0 < max 1 (1 / ε) := by linarith
    have h1 : 1 / ε ≤ max 1 (1 / ε) := le_max_right _ _
    have : 1 / (2 * max 1 (1 / ε)) < ε := by
      rw [div_lt_iff₀ (by positivity)]
      have := (div_le_iff₀ hε).mp h1
      nlinarith
    linarith
  · rintro ⟨x, hx, hmax⟩
    have hx1 : x + 1 ∈ Ici (1:ℝ) := by simp only [mem_Ici] at hx ⊢; linarith
    have := hmono hx hx1 (by linarith)
    have : Wub (x + 1) ≤ Wub x := hmax hx1
    linarith

/-- The lower-bound instance: `L = T_b` (no benefit inside the horizon), `K = T_a = V_c = 1`,
parallel cyber timing, `H(s) = s²`, so `W_L = −s` on `(0, 1]`. -/
noncomputable def Wlb (s : ℝ) : ℝ := WL (fun x => x ^ 2) 1 1 0 1 1 0 1 1 1 0 s

/-- **"A positive lower bound is needed too"**, as a P16 instance (the paper cites P1's proof):
on `(0, 1]`, with `H > 0` and `H′ > 0`, the balance is `−s`, below 0 everywhere, and has no
maximizer. -/
theorem p16_existence_needs_lower_bound :
    (∀ s ∈ Ioc (0:ℝ) 1, Wlb s = -s) ∧ (∀ s ∈ Ioc (0:ℝ) 1, 0 < s ^ 2 ∧ 0 < 2 * s) ∧
    ¬ ∃ x ∈ Ioc (0:ℝ) 1, IsMaxOn Wlb (Ioc 0 1) x := by
  have hcl : ∀ s ∈ Ioc (0:ℝ) 1, Wlb s = -s := by
    intro s hs
    have hs0 := hs.1
    simp only [Wlb, WL, Cc]
    rw [p16_horizon_none 1 1 1 1 0 s le_rfl, clock_cap 1 1 0 s
      (by rw [le_div_iff₀ hs0]; linarith [hs.2])]
    field_simp; ring
  refine ⟨hcl, fun s hs => ⟨by positivity [hs.1], by linarith [hs.1]⟩, ?_⟩
  rintro ⟨x, hx, hmax⟩
  have hx2 : x / 2 ∈ Ioc (0:ℝ) 1 := ⟨by linarith [hx.1], by linarith [hx.1, hx.2]⟩
  have : Wlb (x / 2) ≤ Wlb x := hmax hx2
  rw [hcl _ hx2, hcl _ hx] at this
  linarith [hx.1]

/-- On `[0.5, 6]` the cyber transition of the illustrative values ends by `s = 2`, so `L = 10`
covers it (line 1025's one-calendar-ledger reading, §4.7 line 176). -/
theorem ex_transition_within_10 : ∀ x ∈ Icc (1 / 2 : ℝ) 6, clock 1 1 0 x ≤ 10 := by
  intro x hx
  have hx0 : 0 < x := by linarith [hx.1]
  have h1 : 1 / x ≤ 2 := by rw [div_le_iff₀ hx0]; linarith [hx.1]
  have := max_le h1 (show (1 - 0) * (1:ℝ) ≤ 2 by norm_num)
  unfold clock; linarith

/-- **"An optimum above the cyber kink is possible, not guaranteed."**  Possible: `Wex` has its
unique global maximum at `2 > s* = 1`.  Not guaranteed: with the same values but
`T_b = L = 10` (fix round 1: `L` still covers the whole transition, `ex_transition_within_10`,
and no benefit is counted), no speed above the cyber kink maximizes on `[0.5, 6]`. -/
theorem p16_optimum_above_kink_possible_not_guaranteed :
    (IsMaxOn Wex (Icc (1 / 2) 6) 2 ∧ (1:ℝ) < 2) ∧
    ∀ s ∈ Ioc (1:ℝ) 6,
      ¬ IsMaxOn (fun x => WL (fun x => x) 1 1 0 4 10 0 1 10 1 0 x) (Icc (1 / 2) 6) s := by
  refine ⟨⟨ex_unique_global_max.1, by norm_num⟩, fun s hs hmax => ?_⟩
  have hval : ∀ x, 1 ≤ x → WL (fun x => x) 1 1 0 4 10 0 1 10 1 0 x = -x := by
    intro x hx
    have hx0 : 0 < x := by linarith
    simp only [WL, Cc]
    rw [p16_horizon_none 1 10 4 10 0 x le_rfl, clock_adopt 1 1 0 x
      (by rw [div_le_iff₀ hx0]; linarith)]
    ring
  have : WL (fun x => x) 1 1 0 4 10 0 1 10 1 0 1 ≤ WL (fun x => x) 1 1 0 4 10 0 1 10 1 0 s :=
    hmax (show (1:ℝ) ∈ Icc (1 / 2) 6 by norm_num)
  rw [hval 1 le_rfl, hval s hs.1.le] at this
  linarith [hs.1]

/-! ## "Two readings that fail" (line 1062) -/

/-- **The capability-set share of the total wait**: on the benefit's capability branch,
`−d ln t_B/d ln s = −s t_B′/t_B = q/(q + m_BT_b)`. -/
theorem p16_capability_share (KB Tb mB s : ℝ) (hs : 0 < s) (hKB : 0 < KB) (hTb : 0 ≤ Tb)
    (hmB : 0 ≤ mB) (hcap : (1 - mB) * Tb < KB / s) :
    -(s * deriv (fun x => clock KB Tb mB x) s) / clock KB Tb mB s
      = (KB / s) / (KB / s + mB * Tb) := by
  rw [(clock_hasDerivAt KB Tb mB s hs hcap.ne').deriv, clock_cap KB Tb mB s hcap.le]
  simp only [ind, hcap, ite_true, one_mul]
  have : 0 < KB / s + mB * Tb := by positivity
  field_simp

/-- **The above-kink test read through the share**: `yq = yt_B[q/(q + m_BT_b)]`, so the test is
`yt_B[q/(q + m_BT_b)] > ε_HV_cHT_a`. -/
theorem p16_test_via_share (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s) (hKB : 0 < KB) (hTb : 0 ≤ Tb)
    (hmB : 0 ≤ mB) (hc : K / s < (1 - m) * Ta) (hb : (1 - mB) * Tb < KB / s)
    (hL : clock KB Tb mB s < L) :
    0 < deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s ↔
      elast H H' s * Vc * H s * Ta <
        y * clock KB Tb mB s * ((KB / s) / (KB / s + mB * Tb)) := by
  rw [p16_i_speedset_above_kink_test H H' K Ta m KB Tb mB y L Vc S s hs hH hHpos hc hb hL,
    clock_cap KB Tb mB s hb.le]
  have : 0 < KB / s + mB * Tb := by positivity
  rw [show y * (KB / s + mB * Tb) * (KB / s / (KB / s + mB * Tb)) = y * (KB / s) by
    field_simp]

/-- Parallel timing makes the capability-set share of the defined benefit clock one. -/
theorem p16_share_parallel (KB Tb s : ℝ) (hs : 0 < s) (hKB : 0 < KB) (hTb : 0 ≤ Tb)
    (hcap : (1 - 0) * Tb < KB / s) :
    -(s * deriv (fun x => clock KB Tb 0 x) s) / clock KB Tb 0 s = 1 := by
  rw [p16_capability_share KB Tb 0 s hs hKB hTb le_rfl hcap]
  have : 0 < KB / s := by positivity
  field_simp; ring

/-- **The 0.806 number** (and Figure 8's 0.71): with `q = 5`, `T_b = 2`, `m_B = 0.6` (Figure 8's
case; here `K_B = 5`, `s = 1`) the capability-set share is `25/31 ∈ (0.806, 0.807)`; under
sequential timing it is `5/7 ∈ (0.71, 0.72)`. -/
theorem p16_share_0806 :
    -(1 * deriv (fun x => clock 5 2 0.6 x) 1) / clock 5 2 0.6 1 = 25 / 31 ∧
    (0.806 : ℝ) < 25 / 31 ∧ (25 / 31 : ℝ) < 0.807 ∧
    -(1 * deriv (fun x => clock 5 2 1 x) 1) / clock 5 2 1 1 = 5 / 7 ∧
    (0.71 : ℝ) < 5 / 7 ∧ (5 / 7 : ℝ) < 0.72 := by
  refine ⟨?_, by norm_num, by norm_num, ?_, by norm_num, by norm_num⟩
  · rw [p16_capability_share 5 2 0.6 1 one_pos (by norm_num) (by norm_num) (by norm_num)
      (by norm_num)]; norm_num
  · rw [p16_capability_share 5 2 1 1 one_pos (by norm_num) (by norm_num) (by norm_num)
      (by norm_num)]; norm_num

/-! ## "P4 and the objective" (line 1064) -/

/-- **`W_full′ = B′ − V_cC_c′ − V_AC_A′`, and acceleration improves it iff
`B′ − V_cC_c′ > V_AC_A′`.**  The paper supplies no far-loss model, so `C_A` is an arbitrary
function differentiable at `s`; the content is algebraic given the proved `B′` and `C_c′`.  The
paper's condition `C_A′ > 0` is not needed for the equivalence. -/
theorem p16_P4_objective (H : ℝ → ℝ) (CA : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S VA s B' C' CA' : ℝ)
    (hB : HasDerivAt (fun x => BL y L (clock KB Tb mB x)) B' s)
    (hC : HasDerivAt (fun x => Cc H K Ta m S x) C' s) (hA : HasDerivAt CA CA' s) :
    HasDerivAt (fun x => WL H K Ta m KB Tb mB y L Vc S x - VA * CA x) (B' - Vc * C' - VA * CA') s ∧
    (0 < deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x - VA * CA x) s ↔
      VA * CA' < B' - Vc * C') := by
  have hd : HasDerivAt (fun x => WL H K Ta m KB Tb mB y L Vc S x - VA * CA x)
      (B' - Vc * C' - VA * CA') s := (hB.sub (hC.const_mul Vc)).sub (hA.const_mul VA)
  exact ⟨hd, by rw [hd.deriv]; constructor <;> intro h <;> linarith⟩

/-- **"With benefits, near cyber loss may rise while the balance improves"**: the `H = s²`
instance has `C_c′ = 1 > 0` and `W_L′ = 15 > 0`. -/
theorem p16_near_loss_rises_balance_improves :
    0 < deriv (fun x => Cc (fun x => x ^ 2) 1 1 0 0 x) (1 / 2) ∧ 0 < deriv Wsq (1 / 2) := by
  rw [ex_Hsq.2.1.deriv, ex_Hsq.2.2.2.1.deriv]; norm_num

/-! ## Adoption levels and the marginal return to speed (line 1066), undiscounted -/

/-- Shortening `T_b` weakly advances arrival: the benefit clock is nondecreasing in `T_b`. -/
theorem p16_tB_mono_Tb (KB mB s Tb₁ Tb₂ : ℝ) (hmB0 : 0 ≤ mB) (hmB1 : mB ≤ 1) (h : Tb₁ ≤ Tb₂) :
    clock KB Tb₁ mB s ≤ clock KB Tb₂ mB s := by
  unfold clock
  have := max_le_max (le_refl (KB / s)) (mul_le_mul_of_nonneg_left h (by linarith : 0 ≤ 1 - mB))
  nlinarith [mul_le_mul_of_nonneg_left h hmB0]

/-- …and weakly raises the benefit level, **strictly exactly when it advances arrival during a
counted period**: `B_L(t₂) < B_L(t₁) ↔ t₁ < t₂ ∧ t₁ < L` for `y > 0`. -/
theorem p16_BL_level_strict (y L t₁ t₂ : ℝ) (hy : 0 < y) (h : t₁ ≤ t₂) :
    BL y L t₂ ≤ BL y L t₁ ∧ (BL y L t₂ < BL y L t₁ ↔ t₁ < t₂ ∧ t₁ < L) := by
  unfold BL
  refine ⟨mul_le_mul_of_nonneg_left (max_le_max (by linarith) le_rfl) hy.le, ?_⟩
  rw [mul_lt_mul_iff_right₀ hy]
  constructor
  · intro hlt
    refine ⟨lt_of_le_of_ne h ?_, ?_⟩
    · rintro rfl; exact lt_irrefl _ hlt
    · by_contra hc; push Not at hc
      rw [max_eq_right (by linarith : L - t₁ ≤ 0), max_eq_right (by linarith : L - t₂ ≤ 0)]
        at hlt
      exact lt_irrefl _ hlt
  · rintro ⟨h1, h2⟩
    rw [max_eq_left (by linarith : 0 ≤ L - t₁)]
    rcases le_or_gt t₂ L with h3 | h3
    · rw [max_eq_left (by linarith : 0 ≤ L - t₂)]; linarith
    · rw [max_eq_right (by linarith : L - t₂ ≤ 0)]; linarith

/-- **`∂B_L/∂T_b = −ym_B` on the capability branch** (arrival before `L`). -/
theorem p16_dBL_dTb_cap (y L KB Tb mB s : ℝ) (hcap : (1 - mB) * Tb < KB / s)
    (hL : clock KB Tb mB s < L) :
    HasDerivAt (fun T => BL y L (clock KB T mB s)) (-(y * mB)) Tb := by
  have hcT : ContinuousAt (fun T : ℝ => (1 - mB) * T) Tb := by fun_prop
  have hev : ∀ᶠ T in 𝓝 Tb, clock KB T mB s = KB / s + mB * T := by
    filter_upwards [hcT.eventually (gt_mem_nhds hcap)] with T hT
    exact clock_cap KB T mB s hT.le
  have hd : HasDerivAt (fun T => clock KB T mB s) mB Tb := by
    refine ((hasDerivAt_id Tb).const_mul mB |>.const_add (KB / s)).congr_of_eventuallyEq hev
      |>.congr_deriv (by simp)
  have := BL_comp_within_before y L (fun T => clock KB T mB s) mB Tb univ hd.hasDerivWithinAt hL
  rwa [hasDerivWithinAt_univ] at this

/-- **`∂B_L/∂T_b = −y` on the adoption branch** (arrival before `L`). -/
theorem p16_dBL_dTb_adopt (y L KB Tb mB s : ℝ) (hb : KB / s < (1 - mB) * Tb)
    (hL : clock KB Tb mB s < L) :
    HasDerivAt (fun T => BL y L (clock KB T mB s)) (-(y * 1)) Tb := by
  have hcT : ContinuousAt (fun T : ℝ => (1 - mB) * T) Tb := by fun_prop
  have hev : ∀ᶠ T in 𝓝 Tb, clock KB T mB s = T := by
    filter_upwards [hcT.eventually (lt_mem_nhds hb)] with T hT
    exact clock_adopt KB T mB s hT.le
  have hd : HasDerivAt (fun T => clock KB T mB s) 1 Tb :=
    (hasDerivAt_id Tb).congr_of_eventuallyEq hev
  have := BL_comp_within_before y L (fun T => clock KB T mB s) 1 Tb univ hd.hasDerivWithinAt hL
  rwa [hasDerivWithinAt_univ] at this

/-- **Under parallel timing a shorter `T_b` has no level effect while capability binds.** -/
theorem p16_dBL_dTb_parallel (y L KB Tb s : ℝ) (hcap : (1 - 0) * Tb < KB / s)
    (hL : clock KB Tb 0 s < L) :
    HasDerivAt (fun T => BL y L (clock KB T 0 s)) 0 Tb := by
  simpa using p16_dBL_dTb_cap y L KB Tb 0 s hcap hL

/-- **On the undiscounted capability branch `B_L′ = yK_B/s²`**, an expression free of `T_b`:
a shorter `T_b` does not raise the marginal return to speed while the branch holds. -/
theorem p16_BL_marginal_free_of_Tb (y L KB Tb mB s : ℝ) (hs : 0 < s)
    (hcap : (1 - mB) * Tb < KB / s) (hL : clock KB Tb mB s < L) :
    HasDerivAt (fun x => BL y L (clock KB Tb mB x)) (y * KB / s ^ 2) s := by
  refine (p16_BL_hasDerivAt y L KB Tb mB s hs hcap.ne' hL.ne).congr_deriv ?_
  simp only [ind, eta, hcap, hL, ite_true]; field_simp


/-! ## P16(ii): discounting

`Ar r u = ∫₀^u e^{−rt} dt`; perpetual benefit `∫_{(t,∞)} y e^{−rx}`; finite-horizon benefit
`∫_{(t,L]} y e^{−rx}`.  The speed-set discounted cyber loss is `H·A_r(T) + S_r` with `S_r` the
present value of the steps (line 1031). -/

/-- `A_r(u) = ∫₀^u e^{−rt} dt`. -/
noncomputable def Ar (r u : ℝ) : ℝ := ∫ t in (0:ℝ)..u, exp (-r * t)

/-- The perpetual discounted benefit, as an integral of the flow from arrival on. -/
noncomputable def Br (y r t : ℝ) : ℝ := ∫ x in Ioi t, y * exp (-r * x)

/-- The finite-horizon discounted benefit, the flow integrated over `(t, L]`. -/
noncomputable def BrL (y r L t : ℝ) : ℝ := ∫ x in Ioc t L, y * exp (-r * x)

/-- Discounted speed-set cyber loss `C_{c,r} = H A_r(T) + S_r`. -/
noncomputable def Ccr (H : ℝ → ℝ) (K Ta m r : ℝ) (Sr : ℝ → ℝ) (s : ℝ) : ℝ :=
  H s * Ar r (clock K Ta m s) + Sr s

/-- `W_r = B_r − V_c C_{c,r}` (perpetual benefit). -/
noncomputable def Wr (H : ℝ → ℝ) (K Ta m KB Tb mB y r Vc : ℝ) (Sr : ℝ → ℝ) (s : ℝ) : ℝ :=
  Br y r (clock KB Tb mB s) - Vc * Ccr H K Ta m r Sr s

/-- The finite-horizon discounted balance `B_{r,L} − V_c C_{c,r}`. -/
noncomputable def WrL (H : ℝ → ℝ) (K Ta m KB Tb mB y r L Vc : ℝ) (Sr : ℝ → ℝ) (s : ℝ) : ℝ :=
  BrL y r L (clock KB Tb mB s) - Vc * Ccr H K Ta m r Sr s

theorem hasDerivAt_neg_exp_div (r t : ℝ) (hr : r ≠ 0) :
    HasDerivAt (fun x => -exp (-r * x) / r) (exp (-r * t)) t := by
  have h := ((hasDerivAt_id t).const_mul (-r)).exp
  have h2 := h.neg.div_const r
  refine h2.congr_deriv ?_
  simp only [id]; field_simp

theorem continuous_exp_neg_mul (r : ℝ) : Continuous (fun x : ℝ => exp (-r * x)) := by fun_prop

/-- **`A_r(u) = (1 − e^{−ru})/r`.** -/
theorem Ar_eq (r u : ℝ) (hr : r ≠ 0) : Ar r u = (1 - exp (-r * u)) / r := by
  rw [Ar, integral_eq_sub_of_hasDerivAt (fun x _ => hasDerivAt_neg_exp_div r x hr)
    ((continuous_exp_neg_mul r).intervalIntegrable _ _)]
  simp; ring

theorem Ar_zero (u : ℝ) : Ar 0 u = u := by simp [Ar]

/-- **`A_r′(T) = e^{−rT}`** (fundamental theorem of calculus on the defining integral). -/
theorem Ar_hasDerivAt (r u : ℝ) : HasDerivAt (fun v => Ar r v) (exp (-r * u)) u :=
  integral_hasDerivAt_right ((continuous_exp_neg_mul r).intervalIntegrable _ _)
    (continuous_exp_neg_mul r).aestronglyMeasurable.stronglyMeasurableAtFilter
    (continuous_exp_neg_mul r).continuousAt

theorem Ar_pos (r u : ℝ) (hr : 0 < r) (hu : 0 < u) : 0 < Ar r u := by
  rw [Ar_eq r u hr.ne']
  have : exp (-r * u) < 1 := by
    have := exp_lt_exp.mpr (show -r * u < 0 by nlinarith); simpa using this
  exact div_pos (by linarith) hr

/-- **The perpetual benefit `B_r = (y/r)e^{−rt_B}`**, from the improper integral. -/
theorem Br_eq (y r t : ℝ) (hr : 0 < r) : Br y r t = y / r * exp (-r * t) := by
  have hint : IntegrableOn (fun x => y * exp (-r * x)) (Ioi t) :=
    (exp_neg_integrableOn_Ioi t hr).const_mul y
  have hlim : Tendsto (fun x => -(y / r) * exp (-r * x)) atTop (𝓝 0) := by
    have h1 : Tendsto (fun x => -r * x) atTop atBot :=
      tendsto_id.const_mul_atTop_of_neg (by linarith)
    simpa using (tendsto_exp_atBot.comp h1).const_mul (-(y / r))
  have hd : ∀ x ∈ Ioi t, HasDerivAt (fun x => -(y / r) * exp (-r * x)) (y * exp (-r * x)) x := by
    intro x _
    have h := (((hasDerivAt_id x).const_mul (-r)).exp).const_mul (-(y / r))
    refine h.congr_deriv ?_
    simp only [id]; field_simp
  have := integral_Ioi_of_hasDerivAt_of_tendsto
    ((Continuous.continuousWithinAt (by fun_prop))) hd hint hlim
  rw [Br, this]; ring

/-- **The finite-horizon benefit `B_{r,L} = (y/r)(e^{−rt_B} − e^{−rL})⁺`.** -/
theorem BrL_eq (y r L t : ℝ) (hr : 0 < r) :
    BrL y r L t = y / r * max (exp (-r * t) - exp (-r * L)) 0 := by
  rcases le_or_gt t L with h | h
  · have hle : exp (-r * L) ≤ exp (-r * t) := exp_le_exp.mpr (by nlinarith)
    rw [BrL, ← intervalIntegral.integral_of_le h, intervalIntegral.integral_const_mul,
      integral_eq_sub_of_hasDerivAt (fun x _ => hasDerivAt_neg_exp_div r x hr.ne')
      ((continuous_exp_neg_mul r).intervalIntegrable _ _), max_eq_left (by linarith)]
    field_simp; ring
  · have hlt : exp (-r * t) < exp (-r * L) := exp_lt_exp.mpr (by nlinarith)
    rw [BrL, Ioc_eq_empty (not_lt.mpr h.le), setIntegral_empty, max_eq_right (by linarith),
      mul_zero]

/-- Perpetual benefit composed with an arrival date: `B_r′ = −y e^{−rt_B} t_B′`. -/
theorem Br_comp_within (y r : ℝ) (tB : ℝ → ℝ) (tB' s : ℝ) (U : Set ℝ) (hr : 0 < r)
    (htB : HasDerivWithinAt tB tB' U s) :
    HasDerivWithinAt (fun x => Br y r (tB x)) (-(y * exp (-r * tB s) * tB')) U s := by
  have h := ((htB.const_mul (-r)).exp).const_mul (y / r)
  rw [show (fun x => Br y r (tB x)) = fun x => y / r * exp (-r * tB x) from
    funext fun x => Br_eq y r (tB x) hr]
  refine h.congr_deriv ?_
  field_simp

/-- Finite-horizon benefit before the horizon: `B_{r,L}′ = −y e^{−rt_B} t_B′`. -/
theorem BrL_comp_within_before (y r L : ℝ) (tB : ℝ → ℝ) (tB' s : ℝ) (U : Set ℝ) (hr : 0 < r)
    (htB : HasDerivWithinAt tB tB' U s) (hlt : tB s < L) :
    HasDerivWithinAt (fun x => BrL y r L (tB x)) (-(y * exp (-r * tB s) * tB')) U s := by
  have hev : ∀ᶠ x in 𝓝[U] s, tB x < L := htB.continuousWithinAt.eventually (gt_mem_nhds hlt)
  have hcl : ∀ t, t ≤ L → BrL y r L t = y / r * (exp (-r * t) - exp (-r * L)) := by
    intro t ht
    rw [BrL_eq y r L t hr, max_eq_left (by
      have := exp_le_exp.mpr (show -r * L ≤ -r * t by nlinarith); linarith)]
  have h := (((htB.const_mul (-r)).exp).sub_const (exp (-r * L))).const_mul (y / r)
  refine (h.congr_of_eventuallyEq ?_ (hcl _ hlt.le)).congr_deriv ?_
  · filter_upwards [hev] with x hx using hcl _ hx.le
  · field_simp

/-- Finite-horizon benefit after the horizon: zero derivative. -/
theorem BrL_comp_within_after (y r L : ℝ) (tB : ℝ → ℝ) (tB' s : ℝ) (U : Set ℝ) (_hr : 0 < r)
    (htB : HasDerivWithinAt tB tB' U s) (hgt : L < tB s) :
    HasDerivWithinAt (fun x => BrL y r L (tB x)) 0 U s := by
  have hev : ∀ᶠ x in 𝓝[U] s, L < tB x := htB.continuousWithinAt.eventually (lt_mem_nhds hgt)
  have hz : ∀ t, L < t → BrL y r L t = 0 := fun t ht => by
    rw [BrL, Ioc_eq_empty (not_lt.mpr ht.le), setIntegral_empty]
  refine (hasDerivWithinAt_const s U (0:ℝ)).congr_of_eventuallyEq ?_ (hz _ hgt)
  filter_upwards [hev] with x hx using hz _ hx

theorem BrL_within_offhorizon (y r L KB Tb mB s tB' : ℝ) (U : Set ℝ) (hr : 0 < r)
    (htB : HasDerivWithinAt (fun x => clock KB Tb mB x) tB' U s) (hL : clock KB Tb mB s ≠ L) :
    HasDerivWithinAt (fun x => BrL y r L (clock KB Tb mB x))
      (-(y * eta L (clock KB Tb mB s) * exp (-r * clock KB Tb mB s) * tB')) U s := by
  rcases lt_or_gt_of_ne hL with h | h
  · simpa [eta, h] using BrL_comp_within_before y r L _ tB' s U hr htB h
  · simpa [eta, not_lt.mpr h.le] using BrL_comp_within_after y r L _ tB' s U hr htB h

/-- The discounted speed-set cyber loss: `C_{c,r}′ = H′A_r(T) + He^{−rT}T′ + S_r′`. -/
theorem Ccr_hasDerivWithinAt_of (H : ℝ → ℝ) (Sr : ℝ → ℝ) (H' K Ta m r s T' Sr' : ℝ)
    (U : Set ℝ) (hH : HasDerivAt H H' s)
    (hT : HasDerivWithinAt (fun x => clock K Ta m x) T' U s) (hS : HasDerivAt Sr Sr' s) :
    HasDerivWithinAt (fun x => Ccr H K Ta m r Sr x)
      (H' * Ar r (clock K Ta m s) + H s * (exp (-r * clock K Ta m s) * T') + Sr') U s := by
  have hA := (Ar_hasDerivAt r (clock K Ta m s)).comp_hasDerivWithinAt s hT
  exact (hH.hasDerivWithinAt.mul hA).add hS.hasDerivWithinAt

/-- **P16(ii), perpetual benefit, the master formula**:
`sW_r′ = yqχ_Be^{−rt_B} − V_cH[ε_HA_r(T) − χ_cτe^{−rT}] − V_c sS_r′`. -/
theorem p16_ii_hasDerivAt (H : ℝ → ℝ) (Sr : ℝ → ℝ) (H' Sr' K Ta m KB Tb mB y r Vc s : ℝ)
    (hs : 0 < s) (hr : 0 < r) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hS : HasDerivAt Sr Sr' s) (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) :
    HasDerivAt (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x)
      ((y * (KB / s) * ind KB Tb mB s * exp (-r * clock KB Tb mB s)
        - Vc * H s * (elast H H' s * Ar r (clock K Ta m s)
          - ind K Ta m s * (K / s) * exp (-r * clock K Ta m s))
        - Vc * (s * Sr')) / s) s := by
  have hB := Br_comp_within y r _ _ s univ hr (clock_hasDerivAt KB Tb mB s hs hkB).hasDerivWithinAt
  have hC := Ccr_hasDerivWithinAt_of H Sr H' K Ta m r s _ Sr' univ hH
    (clock_hasDerivAt K Ta m s hs hkc).hasDerivWithinAt hS
  have h := hB.sub (hC.const_mul Vc)
  rw [hasDerivWithinAt_univ] at h
  refine h.congr_deriv ?_
  unfold elast; field_simp; ring

/-- **P16(ii), finite horizon**: replace `B_r` by `B_{r,L}` and multiply its term by `η_L`; the
cyber terms are unchanged. -/
theorem p16_ii_finite_hasDerivAt (H : ℝ → ℝ) (Sr : ℝ → ℝ) (H' Sr' K Ta m KB Tb mB y r L Vc s : ℝ)
    (hs : 0 < s) (hr : 0 < r) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hS : HasDerivAt Sr Sr' s) (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb)
    (hL : clock KB Tb mB s ≠ L) :
    HasDerivAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x)
      ((y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) * exp (-r * clock KB Tb mB s)
        - Vc * H s * (elast H H' s * Ar r (clock K Ta m s)
          - ind K Ta m s * (K / s) * exp (-r * clock K Ta m s))
        - Vc * (s * Sr')) / s) s := by
  have hB := BrL_within_offhorizon y r L KB Tb mB s _ univ hr
    (clock_hasDerivAt KB Tb mB s hs hkB).hasDerivWithinAt hL
  have hC := Ccr_hasDerivWithinAt_of H Sr H' K Ta m r s _ Sr' univ hH
    (clock_hasDerivAt K Ta m s hs hkc).hasDerivWithinAt hS
  have h := hB.sub (hC.const_mul Vc)
  rw [hasDerivWithinAt_univ] at h
  refine h.congr_deriv ?_
  unfold elast; field_simp; ring

/-- **P16(ii), the speed-set threshold** (finite horizon; `η_L = 1` gives the perpetual case
below): acceleration improves the balance iff
`ε_H < [χ_cτe^{−rT} + (yqχ_Bη_L/(V_cH))e^{−rt_B} − sS_r′/H]/A_r(T)`.  With `S_r′ = 0` the last
term vanishes; with dated steps it is the subtraction the paper describes. -/
theorem p16_ii_threshold (H : ℝ → ℝ) (Sr : ℝ → ℝ) (H' Sr' K Ta m KB Tb mB y r L Vc s : ℝ)
    (hs : 0 < s) (hr : 0 < r) (hH : HasDerivAt H H' s) (hHpos : 0 < H s) (hVc : 0 < Vc)
    (hTa : 0 < Ta) (hS : HasDerivAt Sr Sr' s) (hkc : K / s ≠ (1 - m) * Ta)
    (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    0 < deriv (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) s ↔
      elast H H' s < (ind K Ta m s * (K / s) * exp (-r * clock K Ta m s)
        + y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) / (Vc * H s)
          * exp (-r * clock KB Tb mB s) - s * Sr' / H s) / Ar r (clock K Ta m s) := by
  rw [(p16_ii_finite_hasDerivAt H Sr H' Sr' K Ta m KB Tb mB y r L Vc s hs hr hH hHpos hS hkc hkB
    hL).deriv, div_pos_iff_of_pos_right hs]
  have hA : 0 < Ar r (clock K Ta m s) := Ar_pos r _ hr (clock_pos K Ta m s hTa)
  have hVH : 0 < Vc * H s := mul_pos hVc hHpos
  rw [lt_div_iff₀ hA]
  constructor
  · intro h
    have : Vc * H s * (elast H H' s * Ar r (clock K Ta m s)) < Vc * H s *
        (ind K Ta m s * (K / s) * exp (-r * clock K Ta m s)
        + y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) / (Vc * H s)
          * exp (-r * clock KB Tb mB s) - s * Sr' / H s) := by
      have e : Vc * H s * (ind K Ta m s * (K / s) * exp (-r * clock K Ta m s)
        + y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) / (Vc * H s)
          * exp (-r * clock KB Tb mB s) - s * Sr' / H s)
          = Vc * H s * (ind K Ta m s * (K / s) * exp (-r * clock K Ta m s))
            + y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
              * exp (-r * clock KB Tb mB s) - Vc * (s * Sr') := by
        field_simp
      rw [e]; linarith
    exact lt_of_mul_lt_mul_left this hVH.le
  · intro h
    have := mul_lt_mul_of_pos_left h hVH
    have e : Vc * H s * (ind K Ta m s * (K / s) * exp (-r * clock K Ta m s)
        + y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) / (Vc * H s)
          * exp (-r * clock KB Tb mB s) - s * Sr' / H s)
          = Vc * H s * (ind K Ta m s * (K / s) * exp (-r * clock K Ta m s))
            + y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
              * exp (-r * clock KB Tb mB s) - Vc * (s * Sr') := by
      field_simp
    rw [e] at this; linarith

/-- **P16(ii), the test above the cyber kink on the benefit's capability branch** (perpetual):
`yqe^{−rt_B} > V_cHε_HA_r(T_a) + V_c sS_r′`. -/
theorem p16_ii_above_kink_test (H : ℝ → ℝ) (Sr : ℝ → ℝ) (H' Sr' K Ta m KB Tb mB y r Vc s : ℝ)
    (hs : 0 < s) (hr : 0 < r) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hS : HasDerivAt Sr Sr' s) (hc : K / s < (1 - m) * Ta) (hb : (1 - mB) * Tb < KB / s) :
    0 < deriv (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) s ↔
      Vc * H s * elast H H' s * Ar r Ta + Vc * (s * Sr') <
        y * (KB / s) * exp (-r * clock KB Tb mB s) := by
  rw [(p16_ii_hasDerivAt H Sr H' Sr' K Ta m KB Tb mB y r Vc s hs hr hH hHpos hS hc.ne
    hb.ne').deriv, div_pos_iff_of_pos_right hs]
  simp only [ind, hb, not_lt.mpr hc.le, ite_true, ite_false, clock_adopt K Ta m s hc.le]
  constructor <;> intro h <;> linarith

/-- The same test for the finite horizon with arrival inside it. -/
theorem p16_ii_above_kink_test_finite (H : ℝ → ℝ) (Sr : ℝ → ℝ)
    (H' Sr' K Ta m KB Tb mB y r L Vc s : ℝ)
    (hs : 0 < s) (hr : 0 < r) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hS : HasDerivAt Sr Sr' s) (hc : K / s < (1 - m) * Ta) (hb : (1 - mB) * Tb < KB / s)
    (hL : clock KB Tb mB s < L) :
    0 < deriv (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) s ↔
      Vc * H s * elast H H' s * Ar r Ta + Vc * (s * Sr') <
        y * (KB / s) * exp (-r * clock KB Tb mB s) := by
  rw [(p16_ii_finite_hasDerivAt H Sr H' Sr' K Ta m KB Tb mB y r L Vc s hs hr hH hHpos hS hc.ne
    hb.ne' hL.ne).deriv, div_pos_iff_of_pos_right hs]
  simp only [ind, eta, hb, hL, not_lt.mpr hc.le, ite_true, ite_false,
    clock_adopt K Ta m s hc.le]
  constructor <;> intro h <;> linarith

/-- **Reduction to P4(ii)** (line 1337): with `S_r′ = 0`, `χ_c = 1` and no active benefit term,
the threshold is `ε_H < rτ/(e^{rT} − 1)`. -/
theorem p16_ii_reduces_to_P4 (H : ℝ → ℝ) (Sr : ℝ → ℝ) (H' K Ta m KB Tb mB y r L Vc s : ℝ)
    (hs : 0 < s) (hr : 0 < r) (hH : HasDerivAt H H' s) (hHpos : 0 < H s) (hVc : 0 < Vc)
    (hTa : 0 < Ta) (hS : HasDerivAt Sr 0 s) (hc : (1 - m) * Ta < K / s)
    (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L)
    (hinactive : ind KB Tb mB s * eta L (clock KB Tb mB s) = 0) :
    0 < deriv (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) s ↔
      elast H H' s < r * (K / s) / (exp (r * clock K Ta m s) - 1) := by
  rw [p16_ii_threshold H Sr H' 0 K Ta m KB Tb mB y r L Vc s hs hr hH hHpos hVc hTa hS hc.ne' hkB
    hL]
  have hT := clock_pos K Ta m s hTa
  have e0 : y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) = 0 := by
    rw [mul_assoc, hinactive, mul_zero]
  have hind : ind K Ta m s = 1 := by simp [ind, hc]
  have hexp : 1 < exp (r * clock K Ta m s) := by rw [one_lt_exp_iff]; positivity
  have key : (ind K Ta m s * (K / s) * exp (-r * clock K Ta m s)
      + y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) / (Vc * H s)
        * exp (-r * clock K Ta m s) - s * 0 / H s) / Ar r (clock K Ta m s)
      = r * (K / s) / (exp (r * clock K Ta m s) - 1) := by
    rw [e0, hind, Ar_eq r _ hr.ne', show -r * clock K Ta m s = -(r * clock K Ta m s) by ring,
      exp_neg]
    have : exp (r * clock K Ta m s) - 1 ≠ 0 := by linarith
    field_simp
    ring
  rw [← key]
  constructor <;> intro h <;> convert h using 3 <;> simp [e0]

/-- With parallel timing below the cyber kink (`T = τ`) the reduced threshold is P4(ii)'s
`x/(e^x − 1)` with `x = rτ`. -/
theorem p16_ii_parallel_is_P4 (H : ℝ → ℝ) (Sr : ℝ → ℝ) (H' K Ta KB Tb mB y r L Vc s : ℝ)
    (hs : 0 < s) (hr : 0 < r) (hH : HasDerivAt H H' s) (hHpos : 0 < H s) (hVc : 0 < Vc)
    (hTa : 0 < Ta) (hS : HasDerivAt Sr 0 s) (hc : (1 - 0) * Ta < K / s)
    (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L)
    (hinactive : ind KB Tb mB s * eta L (clock KB Tb mB s) = 0) :
    0 < deriv (fun x => WrL H K Ta 0 KB Tb mB y r L Vc Sr x) s ↔
      elast H H' s < (r * (K / s)) / (exp (r * (K / s)) - 1) := by
  rw [p16_ii_reduces_to_P4 H Sr H' K Ta 0 KB Tb mB y r L Vc s hs hr hH hHpos hVc hTa hS hc hkB hL
    hinactive, clock_cap K Ta 0 s hc.le, zero_mul, add_zero]

/-- **Above the cyber kink, without an active benefit term, the speed-set discounted
derivative is negative whenever `S_r′ ≥ 0`** (needs A4's `H′ > 0`). -/
theorem p16_ii_above_kink_no_benefit_neg (H : ℝ → ℝ) (Sr : ℝ → ℝ)
    (H' Sr' K Ta m KB Tb mB y r L Vc s : ℝ)
    (hs : 0 < s) (hr : 0 < r) (hH : HasDerivAt H H' s) (hHpos : 0 < H s) (hH' : 0 < H')
    (hVc : 0 < Vc) (hTa : 0 < Ta) (hS : HasDerivAt Sr Sr' s) (hS0 : 0 ≤ Sr')
    (hc : K / s < (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L)
    (hinactive : ind KB Tb mB s * eta L (clock KB Tb mB s) = 0) :
    deriv (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) s < 0 := by
  rw [(p16_ii_finite_hasDerivAt H Sr H' Sr' K Ta m KB Tb mB y r L Vc s hs hr hH hHpos hS hc.ne hkB
    hL).deriv]
  apply div_neg_of_neg_of_pos _ hs
  have e0 : y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
      * exp (-r * clock KB Tb mB s) = 0 := by rw [mul_assoc (y * (KB / s)), hinactive]; simp
  have hind : ind K Ta m s = 0 := by simp [ind, not_lt.mpr hc.le]
  rw [e0, hind]
  have he : 0 < elast H H' s := div_pos (mul_pos hs hH') hHpos
  have hA := Ar_pos r _ hr (clock_pos K Ta m s hTa)
  have : 0 < Vc * H s * (elast H H' s * Ar r (clock K Ta m s)) := by positivity
  have : 0 ≤ Vc * (s * Sr') := by positivity
  nlinarith

/-- **"Discounting lowers the marginal credit for a late benefit"** (restated in fix round 1 on
the defined benefits, replacing a free-variable `e^{−x} < 1`): on an active capability branch
with arrival inside the horizon, the speed derivative of the finite-horizon discounted benefit
`B_{r,L}(t_B(s))` and of the perpetual `B_r(t_B(s))` are each strictly below that of the
undiscounted `B_L(t_B(s))`, and the discounted one is still positive. -/
theorem p16_ii_discount_lowers_credit (y r L KB Tb mB s : ℝ) (hs : 0 < s) (hr : 0 < r)
    (hy : 0 < y) (hKB : 0 < KB) (hTb : 0 < Tb) (hcap : (1 - mB) * Tb < KB / s)
    (hL : clock KB Tb mB s < L) :
    0 < deriv (fun x => BrL y r L (clock KB Tb mB x)) s ∧
    deriv (fun x => BrL y r L (clock KB Tb mB x)) s
      < deriv (fun x => BL y L (clock KB Tb mB x)) s ∧
    deriv (fun x => Br y r (clock KB Tb mB x)) s
      < deriv (fun x => BL y L (clock KB Tb mB x)) s := by
  have hT := clock_hasDerivAt KB Tb mB s hs hcap.ne'
  have h1 : HasDerivAt (fun x => BrL y r L (clock KB Tb mB x))
      (y * (KB / s) * exp (-r * clock KB Tb mB s) / s) s := by
    have := BrL_within_offhorizon y r L KB Tb mB s _ univ hr hT.hasDerivWithinAt hL.ne
    rw [hasDerivWithinAt_univ] at this
    refine this.congr_deriv ?_
    simp only [eta, ind, hL, hcap, ite_true]; ring
  have h2 : HasDerivAt (fun x => BL y L (clock KB Tb mB x)) (y * (KB / s) / s) s := by
    refine (p16_BL_hasDerivAt y L KB Tb mB s hs hcap.ne' hL.ne).congr_deriv ?_
    simp only [eta, ind, hL, hcap, ite_true]; ring
  have h3 : HasDerivAt (fun x => Br y r (clock KB Tb mB x))
      (y * (KB / s) * exp (-r * clock KB Tb mB s) / s) s := by
    have := Br_comp_within y r _ _ s univ hr hT.hasDerivWithinAt
    rw [hasDerivWithinAt_univ] at this
    refine this.congr_deriv ?_
    simp only [ind, hcap, ite_true]; ring
  have hq : 0 < y * (KB / s) := by positivity
  have hE : exp (-r * clock KB Tb mB s) < 1 := by
    have := clock_pos KB Tb mB s hTb
    have := exp_lt_exp.mpr (show -r * clock KB Tb mB s < 0 by nlinarith); simpa using this
  have hlt : y * (KB / s) * exp (-r * clock KB Tb mB s) / s < y * (KB / s) / s :=
    div_lt_div_of_pos_right (mul_lt_of_lt_one_right hq hE) hs
  rw [h1.deriv, h2.deriv, h3.deriv]
  exact ⟨by positivity, hlt, hlt⟩

/-! ## Dated steps (line 1325) -/

/-- Present value of step weights `S_j` at dates `t_j(s)`: `S_r(s) = Σ_j S_j e^{−rt_j(s)}`. -/
noncomputable def SrD {n : ℕ} (Sj : Fin n → ℝ) (tj : Fin n → ℝ → ℝ) (r s : ℝ) : ℝ :=
  ∑ j, Sj j * exp (-r * tj j s)

/-- **`sS_r′ = −rΣ_j S_j st_j′(s)e^{−rt_j(s)}`.** -/
theorem p16_dated_steps_hasDerivAt {n : ℕ} (Sj : Fin n → ℝ) (tj : Fin n → ℝ → ℝ)
    (tj' : Fin n → ℝ) (r s : ℝ) (hs : 0 < s) (ht : ∀ j, HasDerivAt (tj j) (tj' j) s) :
    HasDerivAt (fun x => SrD Sj tj r x)
      ((-r * ∑ j, Sj j * (s * tj' j) * exp (-r * tj j s)) / s) s := by
  have h : HasDerivAt (fun x => ∑ j, Sj j * exp (-r * tj j x))
      (∑ j, Sj j * (exp (-r * tj j s) * (-r * tj' j))) s :=
    HasDerivAt.fun_sum (fun j _ => (((ht j).const_mul (-r)).exp).const_mul (Sj j))
  refine h.congr_deriv ?_
  rw [Finset.mul_sum, Finset.sum_div]
  refine Finset.sum_congr rfl fun j _ => ?_
  field_simp

/-- Dates fixed in calendar time: `S_r′ = 0`. -/
theorem p16_dated_steps_fixed {n : ℕ} (Sj : Fin n → ℝ) (c : Fin n → ℝ) (r s : ℝ) :
    HasDerivAt (fun x => SrD Sj (fun j _ => c j) r x) 0 s := by
  simpa [SrD] using hasDerivAt_const s (∑ j, Sj j * exp (-r * c j))

/-- **Capability-set dates `t_j = k_j/s`**: `sS_r′ = rΣ_j S_j(k_j/s)e^{−rk_j/s} ≥ 0`, strictly
when `r > 0` and some positive mass has a positive distance. -/
theorem p16_dated_steps_capability {n : ℕ} (Sj kj : Fin n → ℝ) (r s : ℝ) (hs : 0 < s)
    (hS : ∀ j, 0 ≤ Sj j) (hk : ∀ j, 0 ≤ kj j) (hr : 0 ≤ r) :
    HasDerivAt (fun x => SrD Sj (fun j x => kj j / x) r x)
      ((r * ∑ j, Sj j * (kj j / s) * exp (-r * (kj j / s))) / s) s ∧
    0 ≤ r * ∑ j, Sj j * (kj j / s) * exp (-r * (kj j / s)) ∧
    (0 < r → (∃ j, 0 < Sj j ∧ 0 < kj j) →
      0 < r * ∑ j, Sj j * (kj j / s) * exp (-r * (kj j / s))) := by
  have hd := p16_dated_steps_hasDerivAt Sj (fun j x => kj j / x) (fun j => -(kj j / s) / s) r s hs
    (fun j => hasDerivAt_div_self (kj j) s hs.ne')
  have hterm : ∀ j, 0 ≤ Sj j * (kj j / s) * exp (-r * (kj j / s)) := fun j => by
    have := hS j; have := hk j; positivity
  refine ⟨hd.congr_deriv ?_, mul_nonneg hr (Finset.sum_nonneg fun j _ => hterm j),
    fun hr' ⟨j, hSj, hkj⟩ => mul_pos hr' ?_⟩
  · congr 1
    rw [Finset.mul_sum, Finset.mul_sum]
    refine Finset.sum_congr rfl fun j _ => ?_
    field_simp
  · exact Finset.sum_pos' (fun j _ => hterm j) ⟨j, Finset.mem_univ j, by positivity⟩

/-- **"Earlier steps subtract from `sW_r′`"**: with capability-set dates `t_j = k_j/s`, the
discounted balance's derivative is at most its value with the same weights at fixed dates,
strictly when `r > 0` and some positive mass has a positive distance. -/
theorem p16_dated_steps_subtract {n : ℕ} (H : ℝ → ℝ) (H' K Ta m KB Tb mB y r L Vc s : ℝ)
    (Sj kj c : Fin n → ℝ) (hs : 0 < s) (hr : 0 < r) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (hVc : 0 < Vc) (hS : ∀ j, 0 ≤ Sj j) (hk : ∀ j, 0 ≤ kj j)
    (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    deriv (fun x => WrL H K Ta m KB Tb mB y r L Vc (fun x => SrD Sj (fun j x => kj j / x) r x) x) s
      ≤ deriv (fun x => WrL H K Ta m KB Tb mB y r L Vc (fun x => SrD Sj (fun j _ => c j) r x) x) s
    ∧ ((∃ j, 0 < Sj j ∧ 0 < kj j) →
      deriv (fun x => WrL H K Ta m KB Tb mB y r L Vc
          (fun x => SrD Sj (fun j x => kj j / x) r x) x) s
        < deriv (fun x => WrL H K Ta m KB Tb mB y r L Vc
          (fun x => SrD Sj (fun j _ => c j) r x) x) s) := by
  obtain ⟨hd, hnn, hpos⟩ := p16_dated_steps_capability Sj kj r s hs hS hk hr.le
  rw [(p16_ii_finite_hasDerivAt H _ H' _ K Ta m KB Tb mB y r L Vc s hs hr hH hHpos hd hkc hkB
    hL).deriv, (p16_ii_finite_hasDerivAt H _ H' _ K Ta m KB Tb mB y r L Vc s hs hr hH hHpos
    (p16_dated_steps_fixed Sj c r s) hkc hkB hL).deriv]
  set X := r * ∑ j, Sj j * (kj j / s) * exp (-r * (kj j / s))
  have e : s * (X / s) = X := by field_simp
  rw [e, mul_zero, mul_zero, sub_zero]
  refine ⟨div_le_div_of_nonneg_right (by nlinarith) hs.le, fun hex => ?_⟩
  have := hpos hr hex
  exact div_lt_div_of_pos_right (by nlinarith) hs

/-! ## Adoption levels, discounted (line 1066) -/

/-- On an active capability branch the perpetual benefit's speed derivative is
`y(K_B/s²)e^{−rt_B}`. -/
theorem Br_speed_deriv_cap (y r KB Tb mB s : ℝ) (hs : 0 < s) (hr : 0 < r)
    (hcap : (1 - mB) * Tb < KB / s) :
    deriv (fun x => Br y r (clock KB Tb mB x)) s
      = y * (KB / s ^ 2) * exp (-r * (KB / s + mB * Tb)) := by
  have h := Br_comp_within y r _ _ s univ hr (clock_hasDerivAt KB Tb mB s hs hcap.ne').hasDerivWithinAt
  rw [hasDerivWithinAt_univ] at h
  rw [h.deriv, clock_cap KB Tb mB s hcap.le]
  simp only [ind, hcap, ite_true]; field_simp

/-- **`∂B_r′/∂T_b = −rm_BB_r′` on an active capability branch.** -/
theorem p16_dBr'_dTb (y r KB Tb mB s : ℝ) (hs : 0 < s) (hr : 0 < r)
    (hcap : (1 - mB) * Tb < KB / s) :
    HasDerivAt (fun T => deriv (fun x => Br y r (clock KB T mB x)) s)
      (-(r * mB) * deriv (fun x => Br y r (clock KB Tb mB x)) s) Tb := by
  have hcT : ContinuousAt (fun T : ℝ => (1 - mB) * T) Tb := by fun_prop
  have hev : ∀ᶠ T in 𝓝 Tb, deriv (fun x => Br y r (clock KB T mB x)) s
      = y * (KB / s ^ 2) * exp (-r * (KB / s + mB * T)) := by
    filter_upwards [hcT.eventually (gt_mem_nhds hcap)] with T hT
    exact Br_speed_deriv_cap y r KB T mB s hs hr hT
  rw [Br_speed_deriv_cap y r KB Tb mB s hs hr hcap]
  have h := ((((hasDerivAt_id Tb).const_mul mB).const_add (KB / s)).const_mul (-r)).exp.const_mul
    (y * (KB / s ^ 2))
  refine (h.congr_of_eventuallyEq hev).congr_deriv ?_
  simp only [id]; ring

/-- A shorter `T_b` raises the discounted marginal return when `m_B > 0` (the `T_b`-derivative
of `B_r′` is negative), and leaves it unchanged under parallel timing. -/
theorem p16_dBr'_dTb_sign (y r KB Tb mB s : ℝ) (hs : 0 < s) (hr : 0 < r) (hy : 0 < y)
    (hKB : 0 < KB) (hcap : (1 - mB) * Tb < KB / s) :
    (0 < mB → -(r * mB) * deriv (fun x => Br y r (clock KB Tb mB x)) s < 0) ∧
    (mB = 0 → -(r * mB) * deriv (fun x => Br y r (clock KB Tb mB x)) s = 0) := by
  rw [Br_speed_deriv_cap y r KB Tb mB s hs hr hcap]
  refine ⟨fun hm => ?_, fun hm => by simp [hm]⟩
  have : 0 < y * (KB / s ^ 2) * exp (-r * (KB / s + mB * Tb)) := by positivity
  have : 0 < r * mB := mul_pos hr hm
  nlinarith

/-! ## Discounted kinks (line 1058): cyber × `e^{−rT}`, benefit × `e^{−rt_B}`, activation ×
`e^{−rL}` -/

/-- **Cyber kink, discounted speed-set**: the change is `−V_cHτe^{−rT}`. -/
theorem p16_kink_cyber_discounted (H : ℝ → ℝ) (Sr : ℝ → ℝ) (H' Sr' K Ta m KB Tb mB y r Vc s₀ : ℝ)
    (hs : 0 < s₀) (hr : 0 < r) (hK : 0 ≤ K) (hH : HasDerivAt H H' s₀) (hS : HasDerivAt Sr Sr' s₀)
    (hkc : K / s₀ = (1 - m) * Ta) (hkB : KB / s₀ ≠ (1 - mB) * Tb) :
    ∃ dl dr, HasDerivWithinAt (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * H s₀ * (K / s₀)) * exp (-r * clock K Ta m s₀) := by
  have hB0 := clock_hasDerivAt KB Tb mB s₀ hs hkB
  refine ⟨_, _, (Br_comp_within y r _ _ s₀ (Iic s₀) hr hB0.hasDerivWithinAt).sub
    ((Ccr_hasDerivWithinAt_of H Sr H' K Ta m r s₀ _ Sr' (Iic s₀) hH
      (clock_hasDerivWithinAt_Iic_kink K Ta m s₀ hs hK hkc) hS).const_mul Vc),
    (Br_comp_within y r _ _ s₀ (Ici s₀) hr hB0.hasDerivWithinAt).sub
    ((Ccr_hasDerivWithinAt_of H Sr H' K Ta m r s₀ _ Sr' (Ici s₀) hH
      (clock_hasDerivWithinAt_Ici_kink K Ta m s₀ hs hK hkc) hS).const_mul Vc), ?_⟩
  field_simp; ring

/-- **Benefit kink, discounted (perpetual)**: the change is `−yqe^{−rt_B}`. -/
theorem p16_kink_benefit_discounted (H : ℝ → ℝ) (Sr : ℝ → ℝ)
    (H' Sr' K Ta m KB Tb mB y r Vc s₀ : ℝ)
    (hs : 0 < s₀) (hr : 0 < r) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ ≠ (1 - m) * Ta) (hkB : KB / s₀ = (1 - mB) * Tb) :
    ∃ dl dr, HasDerivWithinAt (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(y * (KB / s₀)) * exp (-r * clock KB Tb mB s₀) := by
  have hT0 := clock_hasDerivAt K Ta m s₀ hs hkc
  refine ⟨_, _, (Br_comp_within y r _ _ s₀ (Iic s₀) hr
      (clock_hasDerivWithinAt_Iic_kink KB Tb mB s₀ hs hKB hkB)).sub
    ((Ccr_hasDerivWithinAt_of H Sr H' K Ta m r s₀ _ Sr' (Iic s₀) hH hT0.hasDerivWithinAt
      hS).const_mul Vc),
    (Br_comp_within y r _ _ s₀ (Ici s₀) hr
      (clock_hasDerivWithinAt_Ici_kink KB Tb mB s₀ hs hKB hkB)).sub
    ((Ccr_hasDerivWithinAt_of H Sr H' K Ta m r s₀ _ Sr' (Ici s₀) hH hT0.hasDerivWithinAt
      hS).const_mul Vc), ?_⟩
  field_simp; ring

/-- Discounted activation, lower side: `B_{r,L}′₋ = 0`. -/
theorem BrL_activation_left (y r L KB Tb mB s₀ : ℝ) (hKB : 0 ≤ KB) (hs : 0 < s₀)
    (hL : clock KB Tb mB s₀ = L) :
    HasDerivWithinAt (fun x => BrL y r L (clock KB Tb mB x)) 0 (Iic s₀) s₀ := by
  have hz : ∀ t, L ≤ t → BrL y r L t = 0 := fun t ht => by
    rw [BrL, Ioc_eq_empty (not_lt.mpr ht), setIntegral_empty]
  refine (hasDerivWithinAt_const s₀ (Iic s₀) (0:ℝ)).congr_of_eventuallyEq ?_ (hz _ hL.ge)
  filter_upwards [eventually_nhdsWithin_of_eventually_nhds (lt_mem_nhds hs),
    self_mem_nhdsWithin] with x hx hxle
  exact hz _ (hL ▸ clock_antitone KB Tb mB x s₀ hKB hx hxle)

/-- Discounted activation, higher side: `B_{r,L}′₊ = −ye^{−rL}t_B′₊`. -/
theorem BrL_activation_right (y r L KB Tb mB s₀ tB' : ℝ) (hKB : 0 ≤ KB) (hs : 0 < s₀)
    (hr : 0 < r) (hL : clock KB Tb mB s₀ = L)
    (htB : HasDerivWithinAt (fun x => clock KB Tb mB x) tB' (Ici s₀) s₀) :
    HasDerivWithinAt (fun x => BrL y r L (clock KB Tb mB x))
      (-(y * exp (-r * L) * tB')) (Ici s₀) s₀ := by
  have hcl : ∀ t, t ≤ L → BrL y r L t = y / r * (exp (-r * t) - exp (-r * L)) := by
    intro t ht
    rw [BrL_eq y r L t hr, max_eq_left (by
      have := exp_le_exp.mpr (show -r * L ≤ -r * t by nlinarith); linarith)]
  have h := (((htB.const_mul (-r)).exp).sub_const (exp (-r * L))).const_mul (y / r)
  refine (h.congr_of_eventuallyEq ?_ (hcl _ hL.le)).congr_deriv ?_
  · filter_upwards [self_mem_nhdsWithin] with x hx
    exact hcl _ (hL ▸ clock_antitone KB Tb mB s₀ x hKB hs hx)
  · rw [hL]; field_simp

/-- **Horizon activation, discounted (finite horizon)**: the change is `+yqe^{−rL}`. -/
theorem p16_kink_activation_discounted (H : ℝ → ℝ) (Sr : ℝ → ℝ)
    (H' Sr' K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hs : 0 < s₀) (hr : 0 < r) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ ≠ (1 - m) * Ta) (hcap : (1 - mB) * Tb < KB / s₀)
    (hL : clock KB Tb mB s₀ = L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = y * (KB / s₀) * exp (-r * L) := by
  have hT0 := clock_hasDerivAt K Ta m s₀ hs hkc
  have htB := (clock_hasDerivAt KB Tb mB s₀ hs hcap.ne').hasDerivWithinAt (s := Ici s₀)
  refine ⟨_, _, (BrL_activation_left y r L KB Tb mB s₀ hKB hs hL).sub
    ((Ccr_hasDerivWithinAt_of H Sr H' K Ta m r s₀ _ Sr' (Iic s₀) hH hT0.hasDerivWithinAt
      hS).const_mul Vc),
    (BrL_activation_right y r L KB Tb mB s₀ _ hKB hs hr hL htB).sub
    ((Ccr_hasDerivWithinAt_of H Sr H' K Ta m r s₀ _ Sr' (Ici s₀) hH hT0.hasDerivWithinAt
      hS).const_mul Vc), ?_⟩
  simp only [ind, hcap, ite_true]
  field_simp; ring


/-! ## The discounted level-set alternative (lines 1327–1335) -/

/-- The discounted level-set loss, **defined as the discounted integral of the actual path**
`h(min(st, K))` over `[0, T(s)]`, including the constant endpoint-hazard tail, plus `S_r`. -/
noncomputable def Clevr (h : ℝ → ℝ) (K Ta m r : ℝ) (Sr : ℝ → ℝ) (s : ℝ) : ℝ :=
  (∫ t in (0:ℝ)..clock K Ta m s, exp (-r * t) * h (min (s * t) K)) + Sr s

/-- `G_r(s) = ∫₀^K e^{−rc/s}h(c)dc`. -/
noncomputable def Gr (h : ℝ → ℝ) (K r s : ℝ) : ℝ := ∫ c in (0:ℝ)..K, exp (-r * c / s) * h c

/-- The derivative-weighted level average `h̄_{r,D}(s) = K⁻¹∫₀^K e^{−rc/s}(1 − rc/s)h(c)dc`. -/
noncomputable def hbarRD (h : ℝ → ℝ) (K r s : ℝ) : ℝ :=
  (∫ c in (0:ℝ)..K, exp (-r * c / s) * (1 - r * c / s) * h c) / K

/-- Discounted level-set balance, perpetual benefit. -/
noncomputable def Wrlev (h : ℝ → ℝ) (K Ta m KB Tb mB y r Vc : ℝ) (Sr : ℝ → ℝ) (s : ℝ) : ℝ :=
  Br y r (clock KB Tb mB s) - Vc * Clevr h K Ta m r Sr s

/-- Discounted level-set balance, finite horizon. -/
noncomputable def WrLlev (h : ℝ → ℝ) (K Ta m KB Tb mB y r L Vc : ℝ) (Sr : ℝ → ℝ) (s : ℝ) : ℝ :=
  BrL y r L (clock KB Tb mB s) - Vc * Clevr h K Ta m r Sr s

/-- **The closed form of line 1329**:
`C^{lev}_{c,r} = (1/s)∫₀^K e^{−rc/s}h(c)dc + h(K)[A_r(T) − A_r(τ)] + S_r`. -/
theorem Clevr_eq (h : ℝ → ℝ) (K Ta m r : ℝ) (Sr : ℝ → ℝ) (s : ℝ) (hcont : Continuous h)
    (hs : 0 < s) (hK : 0 ≤ K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) :
    Clevr h K Ta m r Sr s
      = s⁻¹ * Gr h K r s + h K * (Ar r (clock K Ta m s) - Ar r (K / s)) + Sr s := by
  have hτ : 0 ≤ K / s := by positivity
  have hT : K / s ≤ clock K Ta m s := clock_ge_cap K Ta m s hm hTa
  have hc : Continuous (fun t : ℝ => exp (-r * t) * h (min (s * t) K)) :=
    (continuous_exp_neg_mul r).mul
      (hcont.comp ((continuous_const.mul continuous_id).min continuous_const))
  have h1 : (∫ t in (0:ℝ)..(K / s), exp (-r * t) * h (min (s * t) K)) = s⁻¹ * Gr h K r s := by
    rw [integral_congr_Ioo_of_le hτ (g := fun t : ℝ => (fun c => exp (-r * c / s) * h c) (s * t))
      ?_]
    · rw [integral_comp_mul_left (f := fun c => exp (-r * c / s) * h c) hs.ne', smul_eq_mul,
        mul_zero, mul_div_cancel₀ K hs.ne', Gr]
    · intro t ht
      have : s * t ≤ K := by
        calc s * t ≤ s * (K / s) := mul_le_mul_of_nonneg_left ht.2.le hs.le
        _ = K := mul_div_cancel₀ K hs.ne'
      simp only [min_eq_left this]
      congr 2; field_simp
  have h2 : (∫ t in (K / s)..clock K Ta m s, exp (-r * t) * h (min (s * t) K))
      = h K * (Ar r (clock K Ta m s) - Ar r (K / s)) := by
    rw [integral_congr_Ioo_of_le hT (g := fun t : ℝ => exp (-r * t) * h K) ?_,
      intervalIntegral.integral_mul_const, Ar, Ar, integral_interval_sub_left
        ((continuous_exp_neg_mul r).intervalIntegrable _ _)
        ((continuous_exp_neg_mul r).intervalIntegrable _ _)]
    · ring
    · intro t ht
      have : K ≤ s * t := by
        calc K = s * (K / s) := (mul_div_cancel₀ K hs.ne').symm
        _ ≤ s * t := mul_le_mul_of_nonneg_left ht.1.le hs.le
      simp [min_eq_right this]
  rw [Clevr, ← integral_add_adjacent_intervals (hc.intervalIntegrable 0 (K / s))
    (hc.intervalIntegrable (K / s) _), h1, h2]

/-- **Differentiation under the integral sign** (line 1331: "continuity and boundedness on the
finite capability domain justify differentiating under the integral"):
`G_r′(s) = ∫₀^K e^{−rc/s}(rc/s²)h(c)dc`. -/
theorem Gr_hasDerivAt (h : ℝ → ℝ) (K r s₀ : ℝ) (hcont : Continuous h) (hK : 0 ≤ K)
    (hr : 0 ≤ r) (hs : 0 < s₀) :
    HasDerivAt (fun s => Gr h K r s)
      (∫ c in (0:ℝ)..K, exp (-r * c / s₀) * (r * c / s₀ ^ 2) * h c) s₀ := by
  obtain ⟨M, hM⟩ := isCompact_Icc.exists_bound_of_continuousOn
    (hcont.continuousOn (s := Icc (0:ℝ) K))
  have hFc : ∀ x : ℝ, Continuous (fun c : ℝ => exp (-r * c / x) * h c) := fun x =>
    (Real.continuous_exp.comp ((continuous_const.mul continuous_id).div_const x)).mul hcont
  have hF'c : ∀ x : ℝ, Continuous (fun c : ℝ => exp (-r * c / x) * (r * c / x ^ 2) * h c) :=
    fun x => ((Real.continuous_exp.comp ((continuous_const.mul continuous_id).div_const x)).mul
      ((continuous_const.mul continuous_id).div_const _)).mul hcont
  have hs2 : 0 < s₀ / 2 := by linarith
  have key := intervalIntegral.hasDerivAt_integral_of_dominated_loc_of_deriv_le (μ := volume)
    (a := 0) (b := K) (F := fun x c => exp (-r * c / x) * h c)
    (F' := fun x c => exp (-r * c / x) * (r * c / x ^ 2) * h c) (x₀ := s₀)
    (bound := fun _ => r * K / (s₀ / 2) ^ 2 * M) (s := Ioi (s₀ / 2))
    (Ioi_mem_nhds (by linarith)) (Eventually.of_forall fun x => (hFc x).aestronglyMeasurable)
    ((hFc s₀).intervalIntegrable _ _) (hF'c s₀).aestronglyMeasurable ?_ intervalIntegrable_const ?_
  · exact key.2
  · refine Eventually.of_forall (fun c hc x hx => ?_)
    rw [uIoc_of_le hK] at hc
    have hx0 : 0 < x := lt_trans hs2 hx
    have hc0 : 0 < c := hc.1
    have hMc : |h c| ≤ M := by simpa [Real.norm_eq_abs] using hM c ⟨hc.1.le, hc.2⟩
    have he : exp (-r * c / x) ≤ 1 := by
      have : -r * c / x ≤ 0 := div_nonpos_of_nonpos_of_nonneg (by nlinarith) hx0.le
      simpa using exp_le_exp.mpr this
    have hq : r * c / x ^ 2 ≤ r * K / (s₀ / 2) ^ 2 := by
      rw [div_le_div_iff₀ (by positivity) (by positivity)]
      have hxx : (s₀ / 2) ^ 2 ≤ x ^ 2 := by nlinarith [mem_Ioi.mp hx]
      have hrc : r * c ≤ r * K := mul_le_mul_of_nonneg_left hc.2 hr
      nlinarith [sq_nonneg x, mul_nonneg hr hc0.le]
    simp only [Real.norm_eq_abs]
    rw [abs_mul, abs_mul, abs_of_pos (exp_pos _),
      abs_of_nonneg (by positivity : 0 ≤ r * c / x ^ 2)]
    calc exp (-r * c / x) * (r * c / x ^ 2) * |h c|
        ≤ 1 * (r * K / (s₀ / 2) ^ 2) * M :=
          mul_le_mul (mul_le_mul he hq (by positivity) zero_le_one) hMc (abs_nonneg _)
            (by positivity)
      _ = r * K / (s₀ / 2) ^ 2 * M := by ring
  · refine Eventually.of_forall (fun c _ x hx => ?_)
    have hx0 : 0 < x := lt_trans hs2 hx
    have h1 := ((hasDerivAt_div_self (-r * c) x hx0.ne').exp).mul_const (h c)
    refine h1.congr_deriv ?_
    field_simp

/-- `s·d/ds[(1/s)G_r(s)] = −τh̄_{r,D}` (line 1331). -/
theorem ramp_disc_hasDerivAt (h : ℝ → ℝ) (K r s : ℝ) (hcont : Continuous h) (hK : 0 < K)
    (hr : 0 ≤ r) (hs : 0 < s) :
    HasDerivAt (fun x => x⁻¹ * Gr h K r x) (-(K / s) * hbarRD h K r s / s) s := by
  have hG := Gr_hasDerivAt h K r s hcont hK.le hr hs
  have hd := (hasDerivAt_inv hs.ne').mul hG
  refine hd.congr_deriv ?_
  have hi1 : IntervalIntegrable (fun c => exp (-r * c / s) * h c) volume 0 K :=
    ((Real.continuous_exp.comp ((continuous_const.mul continuous_id).div_const s)).mul
      hcont).intervalIntegrable _ _
  have hi2 : IntervalIntegrable (fun c => exp (-r * c / s) * (r * c / s ^ 2) * h c) volume 0 K :=
    (((Real.continuous_exp.comp ((continuous_const.mul continuous_id).div_const s)).mul
      ((continuous_const.mul continuous_id).div_const _)).mul hcont).intervalIntegrable _ _
  have hsplit : (∫ c in (0:ℝ)..K, exp (-r * c / s) * (1 - r * c / s) * h c)
      = Gr h K r s - s * ∫ c in (0:ℝ)..K, exp (-r * c / s) * (r * c / s ^ 2) * h c := by
    rw [Gr, ← intervalIntegral.integral_const_mul, ← intervalIntegral.integral_sub hi1
      (hi2.const_mul s)]
    refine integral_congr fun c _ => ?_
    field_simp
  rw [hbarRD, hsplit]
  field_simp; ring

/-- The discounted level-set loss has derivative
`[−τh̄_{r,D} + h(K)(sT′e^{−rT} + τe^{−rτ})]/s + S_r′` within any set on which `T` has
derivative `T′`. -/
theorem Clevr_hasDerivWithinAt_of (h : ℝ → ℝ) (Sr : ℝ → ℝ) (K Ta m r s T' Sr' : ℝ) (U : Set ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) (hr : 0 ≤ r)
    (hT : HasDerivWithinAt (fun x => clock K Ta m x) T' U s) (hS : HasDerivAt Sr Sr' s) :
    HasDerivWithinAt (fun x => Clevr h K Ta m r Sr x)
      (-(K / s) * hbarRD h K r s / s
        + h K * (exp (-r * clock K Ta m s) * T' - exp (-r * (K / s)) * (-(K / s) / s)) + Sr')
      U s := by
  have hev : ∀ᶠ x in 𝓝[U] s, Clevr h K Ta m r Sr x
      = x⁻¹ * Gr h K r x + h K * (Ar r (clock K Ta m x) - Ar r (K / x)) + Sr x := by
    filter_upwards [eventually_nhdsWithin_of_eventually_nhds (lt_mem_nhds hs)] with x hx
    exact Clevr_eq h K Ta m r Sr x hcont hx hK.le hm hTa
  have hA1 := (Ar_hasDerivAt r (clock K Ta m s)).comp_hasDerivWithinAt s hT
  have hA2 := (Ar_hasDerivAt r (K / s)).comp s (hasDerivAt_div_self K s hs.ne')
  have hd := (((ramp_disc_hasDerivAt h K r s hcont hK hr hs).hasDerivWithinAt (s := U)).add
    ((hA1.sub hA2.hasDerivWithinAt).const_mul (h K))).add hS.hasDerivWithinAt
  exact hd.congr_of_eventuallyEq hev (Clevr_eq h K Ta m r Sr s hcont hs hK.le hm hTa)

/-- **(C3), perpetual benefit**:
`s(W^{lev}_r)′ = yqχ_Be^{−rt_B} − V_cτ{h(K)[e^{−rτ} − χ_ce^{−rT}] − h̄_{r,D}} − V_c sS_r′`,
for parallel, mixed and sequential cyber timing and any benefit timing. -/
theorem p16_C3_hasDerivAt (h : ℝ → ℝ) (Sr : ℝ → ℝ) (Sr' K Ta m KB Tb mB y r Vc s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) (hr : 0 < r)
    (hS : HasDerivAt Sr Sr' s) (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) :
    HasDerivAt (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x)
      ((y * (KB / s) * ind KB Tb mB s * exp (-r * clock KB Tb mB s)
        - Vc * (K / s) * (h K * (exp (-r * (K / s))
            - ind K Ta m s * exp (-r * clock K Ta m s)) - hbarRD h K r s)
        - Vc * (s * Sr')) / s) s := by
  have hB := Br_comp_within y r _ _ s univ hr (clock_hasDerivAt KB Tb mB s hs hkB).hasDerivWithinAt
  have hC := Clevr_hasDerivWithinAt_of h Sr K Ta m r s _ Sr' univ hcont hs hK hm hTa hr.le
    (clock_hasDerivAt K Ta m s hs hkc).hasDerivWithinAt hS
  have hW := hB.sub (hC.const_mul Vc)
  rw [hasDerivWithinAt_univ] at hW
  refine hW.congr_deriv ?_
  field_simp; ring

/-- **(C3), finite horizon**, with `η_L` on the benefit term. -/
theorem p16_C3_finite_hasDerivAt (h : ℝ → ℝ) (Sr : ℝ → ℝ) (Sr' K Ta m KB Tb mB y r L Vc s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) (hr : 0 < r)
    (hS : HasDerivAt Sr Sr' s) (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb)
    (hL : clock KB Tb mB s ≠ L) :
    HasDerivAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x)
      ((y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) * exp (-r * clock KB Tb mB s)
        - Vc * (K / s) * (h K * (exp (-r * (K / s))
            - ind K Ta m s * exp (-r * clock K Ta m s)) - hbarRD h K r s)
        - Vc * (s * Sr')) / s) s := by
  have hB := BrL_within_offhorizon y r L KB Tb mB s _ univ hr
    (clock_hasDerivAt KB Tb mB s hs hkB).hasDerivWithinAt hL
  have hC := Clevr_hasDerivWithinAt_of h Sr K Ta m r s _ Sr' univ hcont hs hK hm hTa hr.le
    (clock_hasDerivAt K Ta m s hs hkc).hasDerivWithinAt hS
  have hW := hB.sub (hC.const_mul Vc)
  rw [hasDerivWithinAt_univ] at hW
  refine hW.congr_deriv ?_
  field_simp; ring

/-- **"Its right side being positive is the discounted level-set test."** -/
theorem p16_C3_test (h : ℝ → ℝ) (Sr : ℝ → ℝ) (Sr' K Ta m KB Tb mB y r Vc s : ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) (hr : 0 < r)
    (hS : HasDerivAt Sr Sr' s) (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) :
    0 < deriv (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) s ↔
      0 < y * (KB / s) * ind KB Tb mB s * exp (-r * clock KB Tb mB s)
        - Vc * (K / s) * (h K * (exp (-r * (K / s))
            - ind K Ta m s * exp (-r * clock K Ta m s)) - hbarRD h K r s)
        - Vc * (s * Sr') := by
  rw [(p16_C3_hasDerivAt h Sr Sr' K Ta m KB Tb mB y r Vc s hcont hs hK hm hTa hr hS hkc
    hkB).deriv]
  exact div_pos_iff_of_pos_right hs

/-- **Cyber kink, discounted level-set**: the change is `−V_cτh(K)e^{−rT}`. -/
theorem p16_kink_cyber_levelset_discounted (h : ℝ → ℝ) (Sr : ℝ → ℝ)
    (Sr' K Ta m KB Tb mB y r Vc s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) (hr : 0 < r)
    (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ = (1 - m) * Ta) (hkB : KB / s₀ ≠ (1 - mB) * Tb) :
    ∃ dl dr, HasDerivWithinAt (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * (K / s₀) * h K) * exp (-r * clock K Ta m s₀) := by
  have hB0 := clock_hasDerivAt KB Tb mB s₀ hs hkB
  refine ⟨_, _, (Br_comp_within y r _ _ s₀ (Iic s₀) hr hB0.hasDerivWithinAt).sub
    ((Clevr_hasDerivWithinAt_of h Sr K Ta m r s₀ _ Sr' (Iic s₀) hcont hs hK hm hTa hr.le
      (clock_hasDerivWithinAt_Iic_kink K Ta m s₀ hs hK.le hkc) hS).const_mul Vc),
    (Br_comp_within y r _ _ s₀ (Ici s₀) hr hB0.hasDerivWithinAt).sub
    ((Clevr_hasDerivWithinAt_of h Sr K Ta m r s₀ _ Sr' (Ici s₀) hcont hs hK hm hTa hr.le
      (clock_hasDerivWithinAt_Ici_kink K Ta m s₀ hs hK.le hkc) hS).const_mul Vc), ?_⟩
  field_simp; ring

/-! ## Limits as `r ↓ 0` and the case without benefits (line 1337) -/

theorem Ar_tendsto_zero (u : ℝ) : Tendsto (fun r => Ar r u) (𝓝[>] 0) (𝓝 u) := by
  have hc : Continuous (fun r => Ar r u) :=
    intervalIntegral.continuous_parametric_intervalIntegral_of_continuous'
      (by fun_prop) 0 u
  simpa [Ar_zero] using (hc.tendsto 0).mono_left nhdsWithin_le_nhds

theorem exp_tendsto_zero (c : ℝ) : Tendsto (fun r => exp (-r * c)) (𝓝[>] 0) (𝓝 1) := by
  have hc : Continuous (fun r : ℝ => exp (-r * c)) := by fun_prop
  simpa using (hc.tendsto 0).mono_left nhdsWithin_le_nhds

theorem hbarRD_tendsto_zero (h : ℝ → ℝ) (K s : ℝ) (hcont : Continuous h) :
    Tendsto (fun r => hbarRD h K r s) (𝓝[>] 0) (𝓝 (hbar h K)) := by
  have hc : Continuous (fun r => ∫ c in (0:ℝ)..K, exp (-r * c / s) * (1 - r * c / s) * h c) :=
    intervalIntegral.continuous_parametric_intervalIntegral_of_continuous'
      (by fun_prop) 0 K
  have := ((hc.tendsto 0).mono_left (nhdsWithin_le_nhds (s := Ioi 0))).div_const K
  simpa [hbarRD, hbar] using this

/-- **Speed-set limit**: as `r ↓ 0` the discounted finite-horizon derivative converges to the
undiscounted one, the same benefit-activity indicator `η_L` being used, with dated step masses
`Σ_j S_j e^{−rt_j(s)}` whose dates are differentiable (the undiscounted step mass `Σ_j S_j` is
constant). -/
theorem p16_limit_speedset {n : ℕ} (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc s : ℝ)
    (Sj : Fin n → ℝ) (tj : Fin n → ℝ → ℝ) (tj' : Fin n → ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s)
    (ht : ∀ j, HasDerivAt (tj j) (tj' j) s)
    (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    Tendsto (fun r => deriv (fun x => WrL H K Ta m KB Tb mB y r L Vc (fun x => SrD Sj tj r x) x) s)
      (𝓝[>] 0) (𝓝 (deriv (fun x => WL H K Ta m KB Tb mB y L Vc (∑ j, Sj j) x) s)) := by
  rw [(p16_i_speedset_hasDerivAt H H' K Ta m KB Tb mB y L Vc _ s hs hH hHpos hkc hkB hL).deriv]
  set b := y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
  set e := elast H H' s
  set T := clock K Ta m s
  set χ := ind K Ta m s
  have hev : (fun r => (b * exp (-r * clock KB Tb mB s)
        - Vc * H s * (e * Ar r T - χ * (K / s) * exp (-r * T))
        - Vc * (s * ((-r * ∑ j, Sj j * (s * tj' j) * exp (-r * tj j s)) / s))) / s)
      =ᶠ[𝓝[>] 0] fun r =>
        deriv (fun x => WrL H K Ta m KB Tb mB y r L Vc (fun x => SrD Sj tj r x) x) s := by
    filter_upwards [self_mem_nhdsWithin] with r hr
    rw [(p16_ii_finite_hasDerivAt H _ H' _ K Ta m KB Tb mB y r L Vc s hs hr hH hHpos
      (p16_dated_steps_hasDerivAt Sj tj tj' r s hs ht) hkc hkB hL).deriv]
  refine Tendsto.congr' hev ?_
  have hsum : Tendsto (fun r : ℝ => -r * ∑ j, Sj j * (s * tj' j) * exp (-r * tj j s))
      (𝓝[>] 0) (𝓝 0) := by
    have hc : Continuous (fun r : ℝ => -r * ∑ j, Sj j * (s * tj' j) * exp (-r * tj j s)) := by
      fun_prop
    simpa using (hc.tendsto 0).mono_left nhdsWithin_le_nhds
  have := ((((tendsto_const_nhds (x := b)).mul (exp_tendsto_zero (clock KB Tb mB s))).sub
    ((tendsto_const_nhds (x := Vc * H s)).mul (((tendsto_const_nhds (x := e)).mul
      (Ar_tendsto_zero T)).sub ((tendsto_const_nhds (x := χ * (K / s))).mul
        (exp_tendsto_zero T))))).sub ((tendsto_const_nhds (x := Vc)).mul
          ((tendsto_const_nhds (x := s)).mul (hsum.div_const s)))).div_const s
  convert this using 2
  simp only [e, elast]; field_simp; ring

/-- **Level-set limit**: the discounted (C3) derivative converges to the undiscounted level-set
derivative as `r ↓ 0`. -/
theorem p16_limit_levelset {n : ℕ} (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc s : ℝ)
    (Sj : Fin n → ℝ) (tj : Fin n → ℝ → ℝ) (tj' : Fin n → ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (ht : ∀ j, HasDerivAt (tj j) (tj' j) s)
    (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    Tendsto
      (fun r => deriv (fun x => WrLlev h K Ta m KB Tb mB y r L Vc (fun x => SrD Sj tj r x) x) s)
      (𝓝[>] 0) (𝓝 (deriv (fun x => WLlev h K Ta m KB Tb mB y L Vc (∑ j, Sj j) x) s)) := by
  rw [(p16_i_levelset_hasDerivAt h K Ta m KB Tb mB y L Vc _ s hcont hs hK hm hTa hkc hkB
    hL).deriv]
  set b := y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
  set T := clock K Ta m s
  set χ := ind K Ta m s
  have hev : (fun r => (b * exp (-r * clock KB Tb mB s)
        - Vc * (K / s) * (h K * (exp (-r * (K / s)) - χ * exp (-r * T)) - hbarRD h K r s)
        - Vc * (s * ((-r * ∑ j, Sj j * (s * tj' j) * exp (-r * tj j s)) / s))) / s)
      =ᶠ[𝓝[>] 0] fun r =>
        deriv (fun x => WrLlev h K Ta m KB Tb mB y r L Vc (fun x => SrD Sj tj r x) x) s := by
    filter_upwards [self_mem_nhdsWithin] with r hr
    rw [(p16_C3_finite_hasDerivAt h _ _ K Ta m KB Tb mB y r L Vc s hcont hs hK hm hTa hr
      (p16_dated_steps_hasDerivAt Sj tj tj' r s hs ht) hkc hkB hL).deriv]
  refine Tendsto.congr' hev ?_
  have hsum : Tendsto (fun r : ℝ => -r * ∑ j, Sj j * (s * tj' j) * exp (-r * tj j s))
      (𝓝[>] 0) (𝓝 0) := by
    have hc : Continuous (fun r : ℝ => -r * ∑ j, Sj j * (s * tj' j) * exp (-r * tj j s)) := by
      fun_prop
    simpa using (hc.tendsto 0).mono_left nhdsWithin_le_nhds
  have := ((((tendsto_const_nhds (x := b)).mul (exp_tendsto_zero (clock KB Tb mB s))).sub
    ((tendsto_const_nhds (x := Vc * (K / s))).mul (((tendsto_const_nhds (x := h K)).mul
      ((exp_tendsto_zero (K / s)).sub ((tendsto_const_nhds (x := χ)).mul
        (exp_tendsto_zero T)))).sub (hbarRD_tendsto_zero h K s hcont)))).sub
    ((tendsto_const_nhds (x := Vc)).mul
      ((tendsto_const_nhds (x := s)).mul (hsum.div_const s)))).div_const s
  convert this using 2
  ring

/-- **Finite-horizon benefit levels converge to `B_L`.** -/
theorem p16_limit_BrL (y L t : ℝ) : Tendsto (fun r => BrL y r L t) (𝓝[>] 0) (𝓝 (BL y L t)) := by
  rcases le_or_gt t L with h | h
  · have hev : (fun r => ∫ x in t..L, y * exp (-r * x)) = fun r => BrL y r L t := by
      funext r; rw [BrL, intervalIntegral.integral_of_le h]
    rw [← hev]
    have hc : Continuous (fun r => ∫ x in t..L, y * exp (-r * x)) :=
      intervalIntegral.continuous_parametric_intervalIntegral_of_continuous'
        (by fun_prop) t L
    have := (hc.tendsto 0).mono_left (nhdsWithin_le_nhds (s := Ioi 0))
    simpa [BL, max_eq_left (sub_nonneg.mpr h), intervalIntegral.integral_const, mul_comm]
      using this
  · have hz : (fun r => BrL y r L t) = fun _ => 0 := by
      funext r; rw [BrL, Ioc_eq_empty (not_lt.mpr h.le), setIntegral_empty]
    rw [hz, BL, max_eq_right (by linarith), mul_zero]
    exact tendsto_const_nhds

/-- **The perpetual level diverges as `r ↓ 0`.** -/
theorem p16_limit_Br_diverges (y t : ℝ) (hy : 0 < y) :
    Tendsto (fun r => Br y r t) (𝓝[>] 0) atTop := by
  have hev : (fun r => y * r⁻¹ * exp (-r * t)) =ᶠ[𝓝[>] 0] fun r => Br y r t := by
    filter_upwards [self_mem_nhdsWithin] with r hr
    rw [Br_eq y r t hr]; ring
  refine Tendsto.congr' hev ?_
  have h1 : Tendsto (fun r : ℝ => y * r⁻¹) (𝓝[>] 0) atTop :=
    tendsto_inv_nhdsGT_zero.const_mul_atTop hy
  exact h1.atTop_mul_pos one_pos (exp_tendsto_zero t)

/-- **…although its speed derivative has the stated finite limit** `yqχ_B/s`. -/
theorem p16_limit_Br_deriv (y KB Tb mB s : ℝ) (hs : 0 < s) (hkB : KB / s ≠ (1 - mB) * Tb) :
    Tendsto (fun r => deriv (fun x => Br y r (clock KB Tb mB x)) s) (𝓝[>] 0)
      (𝓝 (y * (KB / s) * ind KB Tb mB s / s)) := by
  have hev : (fun r => y * (KB / s) * ind KB Tb mB s * exp (-r * clock KB Tb mB s) / s)
      =ᶠ[𝓝[>] 0] fun r => deriv (fun x => Br y r (clock KB Tb mB x)) s := by
    filter_upwards [self_mem_nhdsWithin] with r hr
    have h := Br_comp_within y r _ _ s univ hr
      (clock_hasDerivAt KB Tb mB s hs hkB).hasDerivWithinAt
    rw [hasDerivWithinAt_univ] at h
    rw [h.deriv]; field_simp
  refine Tendsto.congr' hev ?_
  simpa using ((tendsto_const_nhds (x := y * (KB / s) * ind KB Tb mB s)).mul
    (exp_tendsto_zero (clock KB Tb mB s))).div_const s

/-! ## "No general ranking of the net sign as `r` changes" (line 1337), and the level-set signs
that do not carry over (line 1335) -/

/-- **Discounting can turn a gain from speed into a loss** (speed-set, below the cyber kink,
parallel timing, no benefit term in the horizon): `K = 1`, `T_a = 1/2`, `H(s) = s + 1/9`, `s = 1`,
`V_c = 1`, `K_B = 2`, `T_b = L = 1`, fixed steps.  Undiscounted `W_L′(1) > 0`; at `r = 10`,
`W_{r,L}′(1) < 0`. -/
theorem p16_ranking_plus_to_minus :
    0 < deriv (fun x => WL (fun x => x + 1 / 9) 1 (1 / 2) 0 2 1 0 1 1 1 0 x) 1 ∧
    deriv (fun x => WrL (fun x => x + 1 / 9) 1 (1 / 2) 0 2 1 0 1 10 1 1 (fun _ => 0) x) 1 < 0 := by
  have hH : HasDerivAt (fun x : ℝ => x + 1 / 9) 1 1 := by simpa using (hasDerivAt_id (1:ℝ)).add_const (1 / 9)
  have hkc : (1:ℝ) / 1 ≠ (1 - 0) * (1 / 2) := by norm_num
  have hkB : (2:ℝ) / 1 ≠ (1 - 0) * 1 := by norm_num
  have hcl : clock 2 1 0 1 = 2 := by rw [clock_cap 2 1 0 1 (by norm_num)]; norm_num
  have hL : clock 2 1 0 1 ≠ 1 := by rw [hcl]; norm_num
  constructor
  · rw [(p16_i_speedset_hasDerivAt _ 1 1 (1 / 2) 0 2 1 0 1 1 1 0 1 one_pos hH (by norm_num) hkc
      hkB hL).deriv]
    simp only [ind, eta, elast, clock]; norm_num
  · rw [(p16_ii_finite_hasDerivAt _ _ 1 0 1 (1 / 2) 0 2 1 0 1 10 1 1 1 one_pos (by norm_num) hH
      (by norm_num) (hasDerivAt_const _ _) hkc hkB hL).deriv]
    have hT : clock 1 (1 / 2) 0 1 = 1 := by rw [clock_cap 1 _ 0 1 (by norm_num)]; norm_num
    rw [Ar_eq 10 _ (by norm_num), hT]
    simp only [ind, eta, elast, hcl]
    norm_num
    have h10 : 61 ≤ exp 10 := by
      have := Real.quadratic_le_exp_of_nonneg (show (0:ℝ) ≤ 10 by norm_num); norm_num at this
      linarith
    have : exp (-10) = (exp 10)⁻¹ := by rw [exp_neg]
    rw [this]
    have hpos : 0 < exp 10 := exp_pos 10
    have hu : (exp 10)⁻¹ ≤ 1 / 61 := by
      rw [inv_le_comm₀ hpos (by norm_num)]; norm_num; linarith
    have hu0 : 0 < (exp 10)⁻¹ := inv_pos.mpr hpos
    nlinarith

/-- **Discounting can turn a loss from speed into a gain** (speed-set, above the cyber kink, on
the benefit's capability branch, arrival inside the horizon): `K = 1`, `T_a = 10`, `H(s) = s/10`,
`V_c = 10`, `K_B = 1/10`, `T_b = 1/20`, `y = 95`, `L = 10`, `s = 1`, fixed steps.  Undiscounted
`W_L′(1) < 0`; at `r = 1`, `W_{r,L}′(1) > 0`. -/
theorem p16_ranking_minus_to_plus :
    deriv (fun x => WL (fun x => x / 10) 1 10 0 (1 / 10) (1 / 20) 0 95 10 10 0 x) 1 < 0 ∧
    0 < deriv (fun x =>
      WrL (fun x => x / 10) 1 10 0 (1 / 10) (1 / 20) 0 95 1 10 10 (fun _ => 0) x) 1 := by
  have hH : HasDerivAt (fun x : ℝ => x / 10) (1 / 10) 1 := by
    simpa using (hasDerivAt_id (1:ℝ)).div_const 10
  have hc : (1:ℝ) / 1 < (1 - 0) * 10 := by norm_num
  have hb : (1 - 0) * (1 / 20 : ℝ) < 1 / 10 / 1 := by norm_num
  have hcl : clock (1 / 10) (1 / 20) 0 1 = 1 / 10 := by
    rw [clock_cap _ _ 0 1 hb.le]; norm_num
  have hL : clock (1 / 10) (1 / 20) 0 1 < 10 := by rw [hcl]; norm_num
  constructor
  · rw [(p16_cell_speedset_adopt_cap _ (1 / 10) 1 10 0 (1 / 10) (1 / 20) 0 95 10 10 0 1 one_pos
      hH (by norm_num) hc hb hL).deriv]
    simp only [elast]; norm_num
  · rw [(p16_ii_finite_hasDerivAt _ _ (1 / 10) 0 1 10 0 (1 / 10) (1 / 20) 0 95 1 10 10 1 one_pos
      one_pos hH (by norm_num) (hasDerivAt_const _ _) hc.ne hb.ne' hL.ne).deriv]
    rw [Ar_eq 1 _ one_ne_zero, clock_adopt 1 10 0 1 hc.le, hcl]
    simp only [ind, eta, elast, hb, not_lt.mpr hc.le, ite_true, ite_false]
    have h1 : 0.9 ≤ exp (-1 * (1 / 10)) := by
      have := Real.add_one_le_exp (-1 * (1 / 10)); norm_num at this ⊢; linarith
    have h2 : 0 < exp (-1 * 10) := exp_pos _
    norm_num at h1 h2 ⊢
    nlinarith

/-- `∫₀³ e^{−c}(1 − c)c dc = 13e^{−3} − 1`. -/
theorem integral_exp_lin_quad :
    (∫ c in (0:ℝ)..3, exp (-1 * c / 1) * (1 - 1 * c / 1) * c) = 13 * exp (-3) - 1 := by
  have hd : ∀ x ∈ uIcc (0:ℝ) 3, HasDerivAt (fun c => (c ^ 2 + c + 1) * exp (-c))
      (exp (-1 * x / 1) * (1 - 1 * x / 1) * x) x := by
    intro x _
    have h1 : HasDerivAt (fun c : ℝ => c ^ 2 + c + 1) (2 * x + 1) x := by
      have := ((hasDerivAt_pow 2 x).add (hasDerivAt_id x)).add_const 1
      simpa using this
    have h2 : HasDerivAt (fun c : ℝ => exp (-c)) (exp (-x) * (-1)) x :=
      (hasDerivAt_neg x).exp
    refine (h1.mul h2).congr_deriv ?_
    simp only [neg_mul, one_mul, div_one]; ring
  rw [integral_eq_sub_of_hasDerivAt hd (by
    apply Continuous.intervalIntegrable; fun_prop)]
  norm_num

/-- **The undiscounted level-set signs do not carry over without (C3)** (line 1335), as an exact
instance: `h(c) = c`, `K = 3`, `s = 1`, parallel cyber timing on its capability branch
(`T_a = 1`), no benefit term inside the horizon (`K_B = 2`, `T_b = L = 1`), `V_c = 1`, fixed
steps.  Undiscounted, `sW_L′ = V_cτh̄ = 9/2 > 0`; at `r = 1`, `sW′ = V_cτh̄_{1,D} < 0`, because
`h̄_{1,D} = (13e^{−3} − 1)/3 < 0`. -/
theorem p16_levelset_sign_flip :
    deriv (fun x => WLlev (fun c => c) 3 1 0 2 1 0 1 1 1 0 x) 1 = 9 / 2 ∧
    deriv (fun x => WrLlev (fun c => c) 3 1 0 2 1 0 1 1 1 1 (fun _ => 0) x) 1 < 0 := by
  have hkc : (3:ℝ) / 1 ≠ (1 - 0) * 1 := by norm_num
  have hkB : (2:ℝ) / 1 ≠ (1 - 0) * 1 := by norm_num
  have hcl : clock 2 1 0 1 = 2 := by rw [clock_cap 2 1 0 1 (by norm_num)]; norm_num
  have hL : clock 2 1 0 1 ≠ 1 := by rw [hcl]; norm_num
  have hT : clock 3 1 0 1 = 3 := by rw [clock_cap 3 1 0 1 (by norm_num)]; norm_num
  constructor
  · rw [(p16_i_levelset_hasDerivAt (fun c => c) 3 1 0 2 1 0 1 1 1 0 1 continuous_id one_pos
      (by norm_num) le_rfl zero_le_one hkc hkB hL).deriv]
    simp only [ind, eta, hcl, hbar]
    rw [integral_id]; norm_num
  · rw [(p16_C3_finite_hasDerivAt (fun c => c) _ 0 3 1 0 2 1 0 1 1 1 1 1 continuous_id one_pos
      (by norm_num) le_rfl zero_le_one one_pos (hasDerivAt_const _ _) hkc hkB hL).deriv]
    simp only [ind, eta, hcl, hT, hbarRD]
    rw [integral_exp_lin_quad]
    have he1 := Real.exp_one_gt_d9
    have h3 : exp 3 = exp 1 ^ 3 := by rw [← exp_nat_mul]; norm_num
    have h13 : 13 < exp 3 := by
      have := pow_lt_pow_left₀ he1 (by norm_num) (by norm_num : (3:ℕ) ≠ 0)
      rw [h3]; norm_num at this; linarith
    have : exp (-3) = (exp 3)⁻¹ := by rw [exp_neg]
    norm_num
    rw [this]
    have hpos : 0 < exp 3 := exp_pos 3
    have h' : 13 * (exp 3)⁻¹ < 1 := by rw [mul_inv_lt_iff₀ hpos]; linarith
    have e : 3 * ((13 * (exp 3)⁻¹ - 1) / 3) = 13 * (exp 3)⁻¹ - 1 := by ring
    rw [e]; linarith


/-! ## Condition 4: the power hazard above the cyber kink (line 1349) -/

/-- On the branch where adoption sets the cyber clock, capability the benefit, and arrival is
inside `L`, with `H(s) = as^α`:
`W_L = y(L − m_BT_b) − yK_B/s − V_caT_as^α − V_cS`. -/
theorem p16_power_closed (a α K Ta m KB Tb mB y L Vc S s : ℝ)
    (hc : K / s ≤ (1 - m) * Ta) (hb : (1 - mB) * Tb ≤ KB / s) (hL : clock KB Tb mB s ≤ L) :
    WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S s
      = y * (L - mB * Tb) - y * KB / s - Vc * a * Ta * s ^ α - Vc * S := by
  have hL' := hL
  rw [clock_cap KB Tb mB s hb] at hL'
  simp only [WL, BL, Cc]
  rw [clock_adopt K Ta m s hc, max_eq_left (by linarith : 0 ≤ L - clock KB Tb mB s),
    clock_cap KB Tb mB s hb]
  ring

/-- Its derivative on the open branch. -/
theorem p16_power_hasDerivAt (a α K Ta m KB Tb mB y L Vc S s : ℝ) (hs : 0 < s)
    (hc : K / s < (1 - m) * Ta) (hb : (1 - mB) * Tb < KB / s) (hL : clock KB Tb mB s < L) :
    HasDerivAt (fun x => WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S x)
      (y * KB / s ^ 2 - Vc * a * Ta * (α * s ^ (α - 1))) s := by
  have hcd : ContinuousAt (fun x : ℝ => K / x) s := continuousAt_const.div continuousAt_id hs.ne'
  have hbd : ContinuousAt (fun x : ℝ => KB / x) s :=
    continuousAt_const.div continuousAt_id hs.ne'
  have hev : (fun x => y * (L - mB * Tb) - y * KB / x - Vc * a * Ta * x ^ α - Vc * S)
      =ᶠ[𝓝 s] fun x => WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S x := by
    filter_upwards [hcd.eventually (gt_mem_nhds hc), hbd.eventually (lt_mem_nhds hb),
      (clock_continuousAt KB Tb mB s hs.ne').eventually (gt_mem_nhds hL)] with x h1 h2 h3
    exact (p16_power_closed a α K Ta m KB Tb mB y L Vc S x h1.le h2.le h3.le).symm
  have h1 := hasDerivAt_div_self (y * KB) s hs.ne'
  have h2 := (Real.hasDerivAt_rpow_const (p := α) (Or.inl hs.ne')).const_mul (Vc * a * Ta)
  have hd := (((hasDerivAt_const s (y * (L - mB * Tb))).sub h1).sub h2).sub_const (Vc * S)
  refine (hd.congr_of_eventuallyEq hev.symm).congr_deriv ?_
  field_simp; ring

/-- `sW_L′ = yK_B/s − αV_caT_as^α`. -/
theorem p16_power_sW (a α K Ta m KB Tb mB y L Vc S s : ℝ) (hs : 0 < s)
    (hc : K / s < (1 - m) * Ta) (hb : (1 - mB) * Tb < KB / s) (hL : clock KB Tb mB s < L) :
    s * deriv (fun x => WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S x) s
      = y * KB / s - α * Vc * a * Ta * s ^ α := by
  rw [(p16_power_hasDerivAt a α K Ta m KB Tb mB y L Vc S s hs hc hb hL).deriv,
    Real.rpow_sub_one hs.ne']
  field_simp

/-- `yK_B/s − αV_caT_as^α` is strictly decreasing in `s > 0`. -/
theorem p16_power_g_strictAnti (a α Ta KB y Vc : ℝ) (ha : 0 < a) (hα : 0 < α) (hTa : 0 < Ta)
    (hKB : 0 < KB) (hy : 0 < y) (hVc : 0 < Vc) :
    StrictAntiOn (fun s => y * KB / s - α * Vc * a * Ta * s ^ α) (Ioi 0) := by
  intro x hx x' hx' hxx
  have hx0 : (0:ℝ) < x := hx
  have h1 : y * KB / x' < y * KB / x := div_lt_div_of_pos_left (by positivity) hx0 hxx
  have h2 : x ^ α < x' ^ α := Real.rpow_lt_rpow hx0.le hxx hα
  have : 0 < α * Vc * a * Ta := by positivity
  simp only
  nlinarith

/-- The stationary speed `s₀ = (yK_B/(αV_caT_a))^{1/(α+1)}` makes `sW_L′` vanish. -/
theorem p16_power_g_zero (a α Ta KB y Vc : ℝ) (ha : 0 < a) (hα : 0 < α) (hTa : 0 < Ta)
    (hKB : 0 < KB) (hy : 0 < y) (hVc : 0 < Vc) :
    let s₀ := (y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1))
    0 < s₀ ∧ y * KB / s₀ - α * Vc * a * Ta * s₀ ^ α = 0 := by
  intro s₀
  have hc : 0 < y * KB / (α * Vc * a * Ta) := by positivity
  have hs₀ : 0 < s₀ := Real.rpow_pos_of_pos hc _
  refine ⟨hs₀, ?_⟩
  have hpow : s₀ ^ (α + 1) = y * KB / (α * Vc * a * Ta) := by
    simp only [s₀]
    rw [← Real.rpow_mul hc.le, show 1 / (α + 1) * (α + 1) = 1 by field_simp, Real.rpow_one]
  rw [Real.rpow_add_one hs₀.ne'] at hpow
  have : α * Vc * a * Ta * s₀ ^ α = y * KB / s₀ := by
    field_simp; field_simp at hpow; linarith
  linarith

/-- **Condition 4, core**: if `s₀` lies strictly inside an open speed interval on which the
branch conditions hold, it is the branch's unique strict maximum. -/
theorem p16_power_unique_max (a α K Ta m KB Tb mB y L Vc S lo hi : ℝ) (ha : 0 < a) (hα : 0 < α)
    (hTa : 0 < Ta) (hKB : 0 < KB) (hy : 0 < y) (hVc : 0 < Vc) (hlo : 0 ≤ lo)
    (hbr : ∀ s ∈ Ioo lo hi,
      K / s < (1 - m) * Ta ∧ (1 - mB) * Tb < KB / s ∧ clock KB Tb mB s < L)
    (hin : (y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1)) ∈ Ioo lo hi) :
    ∀ s ∈ Ioo lo hi, s ≠ (y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1)) →
      WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S s
        < WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S
            ((y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1))) := by
  set s₀ := (y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1)) with hs₀def
  obtain ⟨hs₀, hg0⟩ := p16_power_g_zero a α Ta KB y Vc ha hα hTa hKB hy hVc
  set W := fun x => WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S x
  have hpos : ∀ s ∈ Ioo lo hi, 0 < s := fun s hs => lt_of_le_of_lt hlo hs.1
  have hdiff : ∀ s ∈ Ioo lo hi, HasDerivAt W (y * KB / s ^ 2 - Vc * a * Ta * (α * s ^ (α - 1))) s :=
    fun s hs => p16_power_hasDerivAt a α K Ta m KB Tb mB y L Vc S s (hpos s hs) (hbr s hs).1
      (hbr s hs).2.1 (hbr s hs).2.2
  have hsign : ∀ s ∈ Ioo lo hi, s * deriv W s = y * KB / s - α * Vc * a * Ta * s ^ α :=
    fun s hs => p16_power_sW a α K Ta m KB Tb mB y L Vc S s (hpos s hs) (hbr s hs).1
      (hbr s hs).2.1 (hbr s hs).2.2
  have hanti := p16_power_g_strictAnti a α Ta KB y Vc ha hα hTa hKB hy hVc
  have hd_pos : ∀ s ∈ Ioo lo s₀, 0 < deriv W s := by
    intro s hs
    have hsI : s ∈ Ioo lo hi := ⟨hs.1, lt_trans hs.2 hin.2⟩
    have hg := hanti (hpos s hsI) hs₀ hs.2
    simp only at hg
    have := hsign s hsI
    have hs0 := hpos s hsI
    by_contra hc; push Not at hc
    nlinarith
  have hd_neg : ∀ s ∈ Ioo s₀ hi, deriv W s < 0 := by
    intro s hs
    have hsI : s ∈ Ioo lo hi := ⟨lt_trans hin.1 hs.1, hs.2⟩
    have hg := hanti hs₀ (hpos s hsI) hs.1
    simp only at hg
    have := hsign s hsI
    have hs0 := hpos s hsI
    by_contra hc; push Not at hc
    nlinarith
  have hmono : StrictMonoOn W (Ioc lo s₀) := by
    apply strictMonoOn_of_deriv_pos (convex_Ioc lo s₀)
    · intro x hx
      exact (hdiff x ⟨hx.1, lt_of_le_of_lt hx.2 hin.2⟩).continuousAt.continuousWithinAt
    · intro x hx; rw [interior_Ioc] at hx; exact hd_pos x hx
  have hantiW : StrictAntiOn W (Ico s₀ hi) := by
    apply strictAntiOn_of_deriv_neg (convex_Ico s₀ hi)
    · intro x hx
      exact (hdiff x ⟨lt_of_lt_of_le hin.1 hx.1, hx.2⟩).continuousAt.continuousWithinAt
    · intro x hx; rw [interior_Ico] at hx; exact hd_neg x hx
  intro s hs hne
  rcases lt_or_gt_of_ne hne with h | h
  · exact hmono ⟨hs.1, h.le⟩ ⟨hin.1, le_rfl⟩ h
  · exact hantiW ⟨le_rfl, hin.2⟩ ⟨h.le, hs.2⟩ h

/-- **Condition 4, the second derivative**: `W″(s₀) = −(α + 1)yK_B/s₀³ < 0`. -/
theorem p16_power_second_deriv (a α K Ta m KB Tb mB y L Vc S : ℝ) (ha : 0 < a) (hα : 0 < α)
    (hTa : 0 < Ta) (hKB : 0 < KB) (hy : 0 < y) (hVc : 0 < Vc)
    (hc : K / (y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1)) < (1 - m) * Ta)
    (hb : (1 - mB) * Tb < KB / (y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1)))
    (hL : clock KB Tb mB ((y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1))) < L) :
    HasDerivAt (deriv fun x => WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S x)
      (-(α + 1) * y * KB / ((y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1))) ^ 3)
      ((y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1))) ∧
    -(α + 1) * y * KB / ((y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1))) ^ 3 < 0 := by
  set s₀ := (y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1)) with hs₀def
  obtain ⟨hs₀, hg0⟩ := p16_power_g_zero a α Ta KB y Vc ha hα hTa hKB hy hVc
  have hcd : ContinuousAt (fun x : ℝ => K / x) s₀ :=
    continuousAt_const.div continuousAt_id hs₀.ne'
  have hbd : ContinuousAt (fun x : ℝ => KB / x) s₀ :=
    continuousAt_const.div continuousAt_id hs₀.ne'
  have hev : (fun x => y * KB / x ^ 2 - Vc * a * Ta * (α * x ^ (α - 1)))
      =ᶠ[𝓝 s₀] deriv fun x => WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S x := by
    filter_upwards [lt_mem_nhds hs₀, hcd.eventually (gt_mem_nhds hc),
      hbd.eventually (lt_mem_nhds hb),
      (clock_continuousAt KB Tb mB s₀ hs₀.ne').eventually (gt_mem_nhds hL)] with x h0 h1 h2 h3
    exact (p16_power_hasDerivAt a α K Ta m KB Tb mB y L Vc S x h0 h1 h2 h3).deriv.symm
  have hs0' : 0 < s₀ := hs₀
  have h1 : HasDerivAt (fun x : ℝ => y * KB / x ^ 2) (-(2 * y * KB) / s₀ ^ 3) s₀ := by
    have := (hasDerivAt_const s₀ (y * KB)).div (hasDerivAt_pow 2 s₀) (by positivity)
    refine this.congr_deriv ?_
    field_simp; ring
  have h2 := ((Real.hasDerivAt_rpow_const (p := α - 1) (Or.inl hs₀.ne')).const_mul α).const_mul
    (Vc * a * Ta)
  have hd := h1.sub h2
  have hrel : α * Vc * a * Ta * s₀ ^ α = y * KB / s₀ := by linarith
  refine ⟨(hd.congr_of_eventuallyEq hev.symm).congr_deriv ?_, ?_⟩
  · rw [show α - 1 - 1 = α - 2 by ring, Real.rpow_sub hs₀ α 2, Real.rpow_two]
    have : Vc * a * Ta * (α * ((α - 1) * (s₀ ^ α / s₀ ^ 2)))
        = (α - 1) * (α * Vc * a * Ta * s₀ ^ α) / s₀ ^ 2 := by ring
    rw [this, hrel]
    field_simp; ring
  · have : 0 < (α + 1) * y * KB / s₀ ^ 3 := by positivity
    have e : -(α + 1) * y * KB / s₀ ^ 3 = -((α + 1) * y * KB / s₀ ^ 3) := by ring
    rw [e]; linarith

/-- **Condition 4 with the kinks**: for finite cyber and benefit timing, the branch is
`max(s_min, k_c, k_L) < s < min(s_max, k_B)`; if `s₀` lies strictly inside it, it is the
branch's unique strict maximum. -/
theorem p16_power_unique_max_kinks (a α K Ta m KB Tb mB y L Vc S smin smax : ℝ) (ha : 0 < a)
    (hα : 0 < α) (hTa : 0 < Ta) (hTb : 0 < Tb) (_hK : 0 < K) (hKB : 0 < KB) (hy : 0 < y)
    (hVc : 0 < Vc) (hm1 : m < 1) (hmB0 : 0 ≤ mB) (hmB1 : mB < 1) (hLTb : Tb < L)
    (hsmin : 0 < smin)
    (hin : (y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1)) ∈
      Ioo (max (max smin (K / ((1 - m) * Ta))) (KB / (L - mB * Tb)))
        (min smax (KB / ((1 - mB) * Tb)))) :
    ∀ s ∈ Ioo (max (max smin (K / ((1 - m) * Ta))) (KB / (L - mB * Tb)))
        (min smax (KB / ((1 - mB) * Tb))),
      s ≠ (y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1)) →
      WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S s
        < WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S
            ((y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1))) := by
  apply p16_power_unique_max a α K Ta m KB Tb mB y L Vc S _ _ ha hα hTa hKB hy hVc
    (le_trans hsmin.le (le_trans (le_max_left _ _) (le_max_left _ _))) _ hin
  intro s hs
  have hs0 : 0 < s := lt_of_lt_of_le hsmin
    (le_trans (le_trans (le_max_left _ _) (le_max_left _ _)) hs.1.le)
  have hkc : K / ((1 - m) * Ta) < s := lt_of_le_of_lt (le_trans (le_max_right _ _)
    (le_max_left _ _)) hs.1
  have hkL : KB / (L - mB * Tb) < s := lt_of_le_of_lt (le_max_right _ _) hs.1
  have hkB : s < KB / ((1 - mB) * Tb) := lt_of_lt_of_le hs.2 (min_le_right _ _)
  have hpos : 0 < (1 - m) * Ta := mul_pos (by linarith) hTa
  refine ⟨?_, (kink_iff KB Tb mB s hs0 hTb hmB1).mpr hkB,
    (p16_horizon_activation KB Tb mB L s hs0 hTb hmB0 hmB1.le hLTb).mpr hkL⟩
  rw [div_lt_iff₀ hs0]; rw [div_lt_iff₀ hpos] at hkc; linarith

/-- With `L ≤ T_b` the branch does not exist: arrival is never inside the horizon. -/
theorem p16_power_branch_empty (KB Tb mB L s : ℝ) (hL : L ≤ Tb) : ¬ clock KB Tb mB s < L := by
  have := clock_ge_own KB Tb mB s; intro h; linarith

/-- **"If instead `sW_L′` is positive just above `k_c` and negative just below `k_B`, with
arrival already active, continuity gives an interior maximum on that branch, unique there"**:
sign change of `sW_L′` inside the branch places `s₀` between the two speeds, and condition 4's
uniqueness applies. -/
theorem p16_power_sign_change (a α K Ta m KB Tb mB y L Vc S lo hi x₁ x₂ : ℝ) (ha : 0 < a)
    (hα : 0 < α) (hTa : 0 < Ta) (hKB : 0 < KB) (hy : 0 < y) (hVc : 0 < Vc) (hlo : 0 ≤ lo)
    (hbr : ∀ s ∈ Ioo lo hi,
      K / s < (1 - m) * Ta ∧ (1 - mB) * Tb < KB / s ∧ clock KB Tb mB s < L)
    (h₁ : x₁ ∈ Ioo lo hi) (h₂ : x₂ ∈ Ioo lo hi)
    (hp : 0 < x₁ * deriv (fun x => WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S x) x₁)
    (hn : x₂ * deriv (fun x => WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S x) x₂ < 0) :
    ∃ s₀ ∈ Ioo x₁ x₂, ∀ s ∈ Ioo lo hi, s ≠ s₀ →
      WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S s
        < WL (fun x => a * x ^ α) K Ta m KB Tb mB y L Vc S s₀ := by
  obtain ⟨hs₀, hg0⟩ := p16_power_g_zero a α Ta KB y Vc ha hα hTa hKB hy hVc
  have hanti := p16_power_g_strictAnti a α Ta KB y Vc ha hα hTa hKB hy hVc
  have hx₁ : 0 < x₁ := lt_of_le_of_lt hlo h₁.1
  have hx₂ : 0 < x₂ := lt_of_le_of_lt hlo h₂.1
  rw [p16_power_sW a α K Ta m KB Tb mB y L Vc S x₁ hx₁ (hbr x₁ h₁).1 (hbr x₁ h₁).2.1
    (hbr x₁ h₁).2.2] at hp
  rw [p16_power_sW a α K Ta m KB Tb mB y L Vc S x₂ hx₂ (hbr x₂ h₂).1 (hbr x₂ h₂).2.1
    (hbr x₂ h₂).2.2] at hn
  set s₀ := (y * KB / (α * Vc * a * Ta)) ^ (1 / (α + 1))
  have hlt1 : x₁ < s₀ := by
    by_contra hc; push Not at hc
    rcases eq_or_lt_of_le hc with h | h
    · rw [h] at hg0; linarith
    · have := hanti hs₀ hx₁ h; simp only at this; linarith
  have hlt2 : s₀ < x₂ := by
    by_contra hc; push Not at hc
    rcases eq_or_lt_of_le hc with h | h
    · rw [← h] at hg0; linarith
    · have := hanti hx₂ hs₀ h; simp only at this; linarith
  exact ⟨s₀, ⟨hlt1, hlt2⟩, p16_power_unique_max a α K Ta m KB Tb mB y L Vc S lo hi ha hα hTa hKB
    hy hVc hlo hbr ⟨lt_trans h₁.1 hlt1, lt_trans hlt2 h₂.2⟩⟩

/-- **"Section 4.7's example is the case `a = α = 1`"**: there `s₀ = (yK_B/(V_caT_a))^{1/2} = 2`,
and the branch closed form is the example's `10 − 4/s − s`. -/
theorem p16_power_example :
    ((1:ℝ) * 4 / (1 * 1 * 1 * 1)) ^ ((1:ℝ) / (1 + 1)) = 2 ∧
    ∀ s ∈ Ioo (1:ℝ) 4, WL (fun x => 1 * x ^ (1:ℝ)) 1 1 0 4 1 0 1 10 1 0 s = Wex s := by
  refine ⟨?_, fun s hs => ?_⟩
  · rw [show ((1:ℝ) * 4 / (1 * 1 * 1 * 1)) = 2 ^ (2:ℝ) by norm_num, ← Real.rpow_mul (by norm_num)]
    norm_num
  · have hs0 : 0 < s := by linarith [hs.1]
    rw [p16_power_closed 1 1 1 1 0 4 1 0 1 10 1 0 s
      (by rw [div_le_iff₀ hs0]; linarith [hs.1]) (by rw [le_div_iff₀ hs0]; linarith [hs.2])
      (by rw [clock_cap 4 1 0 s (by rw [le_div_iff₀ hs0]; linarith [hs.2])]
          have : 4 / s ≤ 4 := by rw [div_le_iff₀ hs0]; linarith [hs.1]
          linarith),
      ex_piece2 s hs.1.le hs.2.le, Real.rpow_one]
    ring


/-! ## Remaining assertions: perpetual threshold, widening, horizon truncation, and (iii) for
the discounted objectives -/

/-- **P16(ii), the speed-set threshold, perpetual case** (`η_L = 1`). -/
theorem p16_ii_threshold_perpetual (H : ℝ → ℝ) (Sr : ℝ → ℝ) (H' Sr' K Ta m KB Tb mB y r Vc s : ℝ)
    (hs : 0 < s) (hr : 0 < r) (hH : HasDerivAt H H' s) (hHpos : 0 < H s) (hVc : 0 < Vc)
    (hTa : 0 < Ta) (hS : HasDerivAt Sr Sr' s) (hkc : K / s ≠ (1 - m) * Ta)
    (hkB : KB / s ≠ (1 - mB) * Tb) :
    0 < deriv (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) s ↔
      elast H H' s < (ind K Ta m s * (K / s) * exp (-r * clock K Ta m s)
        + y * (KB / s) * ind KB Tb mB s / (Vc * H s)
          * exp (-r * clock KB Tb mB s) - s * Sr' / H s) / Ar r (clock K Ta m s) := by
  rw [(p16_ii_hasDerivAt H Sr H' Sr' K Ta m KB Tb mB y r Vc s hs hr hH hHpos hS hkc hkB).deriv,
    div_pos_iff_of_pos_right hs]
  have hA : 0 < Ar r (clock K Ta m s) := Ar_pos r _ hr (clock_pos K Ta m s hTa)
  have hVH : 0 < Vc * H s := mul_pos hVc hHpos
  rw [lt_div_iff₀ hA]
  have e : Vc * H s * (ind K Ta m s * (K / s) * exp (-r * clock K Ta m s)
        + y * (KB / s) * ind KB Tb mB s / (Vc * H s)
          * exp (-r * clock KB Tb mB s) - s * Sr' / H s)
        = Vc * H s * (ind K Ta m s * (K / s) * exp (-r * clock K Ta m s))
          + y * (KB / s) * ind KB Tb mB s * exp (-r * clock KB Tb mB s) - Vc * (s * Sr') := by
    field_simp
  constructor
  · intro h
    refine lt_of_mul_lt_mul_left (a := Vc * H s) ?_ hVH.le
    rw [e]; linarith
  · intro h
    have := mul_lt_mul_of_pos_left h hVH
    rw [e] at this; linarith

/-- **"Below the cyber kink, benefits widen the range in which speed helps"** (§4.7 line 203):
the below-kink threshold with the benefit term is at least the threshold without it. -/
theorem p16_benefits_widen_range (H : ℝ → ℝ) (K Ta m KB Tb mB y L Vc s : ℝ) (hs : 0 < s)
    (hHpos : 0 < H s) (hVc : 0 < Vc) (hTa : 0 < Ta) (hy : 0 ≤ y) (hKB : 0 ≤ KB) :
    (K / s) / clock K Ta m s ≤ (K / s + y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s)
        / (Vc * H s)) / clock K Ta m s := by
  have hT := clock_pos K Ta m s hTa
  have hi : 0 ≤ ind KB Tb mB s := by unfold ind; split_ifs <;> norm_num
  have he : 0 ≤ eta L (clock KB Tb mB s) := by unfold eta; split_ifs <;> norm_num
  have : 0 ≤ y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) / (Vc * H s) := by
    positivity
  exact div_le_div_of_nonneg_right (by linarith) hT.le

/-- The speed-set discounted cyber ledger **truncated at the horizon**:
`∫₀^{min(T, L)} H(s)e^{−rt}dt + S_r(s)`, with `S_r` the present value of the steps counted. -/
noncomputable def CcrTrunc (H : ℝ → ℝ) (K Ta m r L : ℝ) (Sr : ℝ → ℝ) (s : ℝ) : ℝ :=
  (∫ t in (0:ℝ)..min (clock K Ta m s) L, H s * exp (-r * t)) + Sr s

/-- The discounted level-set cyber ledger truncated at the horizon. -/
noncomputable def ClevrTrunc (h : ℝ → ℝ) (K Ta m r L : ℝ) (Sr : ℝ → ℝ) (s : ℝ) : ℝ :=
  (∫ t in (0:ℝ)..min (clock K Ta m s) L, exp (-r * t) * h (min (s * t) K)) + Sr s

/-- **"The cyber terms are unchanged when the transition … fall[s] within `L`"** (restated in
fix round 1 on the defined ledgers): if the cyber transition ends by `L` at all speeds near `s`,
the horizon-truncated ledgers of both hazards coincide with `C_{c,r}` and `C^{lev}_{c,r}` near
`s`, so they have the same derivatives.  The steps clause is carried by reading `S_r` as the
present value of the steps counted (a modelling stipulation). -/
theorem p16_ii_truncation_harmless (H h Sr : ℝ → ℝ) (K Ta m r L s : ℝ)
    (hT : ∀ᶠ x in 𝓝 s, clock K Ta m x ≤ L) :
    (fun x => CcrTrunc H K Ta m r L Sr x) =ᶠ[𝓝 s] (fun x => Ccr H K Ta m r Sr x) ∧
    (fun x => ClevrTrunc h K Ta m r L Sr x) =ᶠ[𝓝 s] (fun x => Clevr h K Ta m r Sr x) ∧
    ∀ d, (HasDerivAt (fun x => CcrTrunc H K Ta m r L Sr x) d s ↔
        HasDerivAt (fun x => Ccr H K Ta m r Sr x) d s) ∧
      (HasDerivAt (fun x => ClevrTrunc h K Ta m r L Sr x) d s ↔
        HasDerivAt (fun x => Clevr h K Ta m r Sr x) d s) := by
  have e1 : (fun x => CcrTrunc H K Ta m r L Sr x) =ᶠ[𝓝 s] (fun x => Ccr H K Ta m r Sr x) := by
    filter_upwards [hT] with x hx
    rw [CcrTrunc, Ccr, min_eq_left hx, intervalIntegral.integral_const_mul, Ar]
  have e2 : (fun x => ClevrTrunc h K Ta m r L Sr x) =ᶠ[𝓝 s]
      (fun x => Clevr h K Ta m r Sr x) := by
    filter_upwards [hT] with x hx
    rw [ClevrTrunc, Clevr, min_eq_left hx]
  exact ⟨e1, e2, fun d => ⟨⟨fun hd => hd.congr_of_eventuallyEq e1.symm,
    fun hd => hd.congr_of_eventuallyEq e1⟩, ⟨fun hd => hd.congr_of_eventuallyEq e2.symm,
    fun hd => hd.congr_of_eventuallyEq e2⟩⟩⟩

theorem Ar_continuous (r : ℝ) : Continuous (fun u => Ar r u) :=
  continuous_iff_continuousAt.2 fun u => (Ar_hasDerivAt r u).continuousAt

theorem Br_clock_continuousAt (y r KB Tb mB s : ℝ) (hr : 0 < r) (hs : 0 < s) :
    ContinuousAt (fun x => Br y r (clock KB Tb mB x)) s := by
  rw [show (fun x => Br y r (clock KB Tb mB x)) = fun x => y / r * exp (-r * clock KB Tb mB x)
    from funext fun x => Br_eq y r _ hr]
  exact continuousAt_const.mul (continuous_exp.continuousAt.comp
    (continuousAt_const.mul (clock_continuousAt KB Tb mB s hs.ne')))

theorem BrL_clock_continuousAt (y r L KB Tb mB s : ℝ) (hr : 0 < r) (hs : 0 < s) :
    ContinuousAt (fun x => BrL y r L (clock KB Tb mB x)) s := by
  rw [show (fun x => BrL y r L (clock KB Tb mB x))
    = fun x => y / r * max (exp (-r * clock KB Tb mB x) - exp (-r * L)) 0
    from funext fun x => BrL_eq y r L _ hr]
  exact continuousAt_const.mul (((continuous_exp.continuousAt.comp
    (continuousAt_const.mul (clock_continuousAt KB Tb mB s hs.ne'))).sub
      continuousAt_const).max continuousAt_const)

theorem Ccr_continuousWithinAt (H Sr : ℝ → ℝ) (K Ta m r s : ℝ) (U : Set ℝ) (hs : 0 < s)
    (hH : ContinuousWithinAt H U s) (hS : ContinuousWithinAt Sr U s) :
    ContinuousWithinAt (fun x => Ccr H K Ta m r Sr x) U s :=
  (hH.mul ((Ar_continuous r).continuousAt.comp
    (clock_continuousAt K Ta m s hs.ne')).continuousWithinAt).add hS

theorem Clevr_continuousWithinAt (h Sr : ℝ → ℝ) (K Ta m r s : ℝ) (U : Set ℝ)
    (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) (hr : 0 ≤ r)
    (hS : ContinuousWithinAt Sr U s) :
    ContinuousWithinAt (fun x => Clevr h K Ta m r Sr x) U s := by
  have hev : (fun x => x⁻¹ * Gr h K r x + h K * (Ar r (clock K Ta m x) - Ar r (K / x)) + Sr x)
      =ᶠ[𝓝[U] s] fun x => Clevr h K Ta m r Sr x := by
    filter_upwards [eventually_nhdsWithin_of_eventually_nhds (lt_mem_nhds hs)] with x hx
    exact (Clevr_eq h K Ta m r Sr x hcont hx hK.le hm hTa).symm
  refine ContinuousWithinAt.congr_of_eventuallyEq ?_ hev.symm
    (Clevr_eq h K Ta m r Sr s hcont hs hK.le hm hTa)
  have h1 : ContinuousAt (fun x => x⁻¹ * Gr h K r x) s :=
    (ramp_disc_hasDerivAt h K r s hcont hK hr hs).continuousAt
  have h2 : ContinuousAt (fun x => h K * (Ar r (clock K Ta m x) - Ar r (K / x))) s :=
    continuousAt_const.mul (((Ar_continuous r).continuousAt.comp
      (clock_continuousAt K Ta m s hs.ne')).sub ((Ar_continuous r).continuousAt.comp
        (continuousAt_const.div continuousAt_id hs.ne')))
  exact (h1.continuousWithinAt.add h2.continuousWithinAt).add hS

/-- **P16(iii), existence for the four discounted objectives**: on `[s_min, s_max]`,
`s_min > 0`, with `H` and `S_r` continuous (and `h` continuous), each attains both extrema. -/
theorem p16_iii_exists_discounted (H h Sr : ℝ → ℝ) (K Ta m KB Tb mB y r L Vc a b : ℝ)
    (ha : 0 < a) (hab : a ≤ b) (hr : 0 < r) (hH : ContinuousOn H (Icc a b))
    (hS : ContinuousOn Sr (Icc a b)) (hcont : Continuous h) (hK : 0 < K) (hm : 0 ≤ m)
    (hTa : 0 ≤ Ta) :
    let I := Icc a b
    ((∃ x ∈ I, IsMaxOn (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) I x) ∧
      ∃ x ∈ I, IsMinOn (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) I x) ∧
    ((∃ x ∈ I, IsMaxOn (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) I x) ∧
      ∃ x ∈ I, IsMinOn (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) I x) ∧
    ((∃ x ∈ I, IsMaxOn (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) I x) ∧
      ∃ x ∈ I, IsMinOn (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) I x) ∧
    ((∃ x ∈ I, IsMaxOn (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) I x) ∧
      ∃ x ∈ I, IsMinOn (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) I x) := by
  intro I
  have hne : I.Nonempty := nonempty_Icc.mpr hab
  have ext : ∀ f : ℝ → ℝ, ContinuousOn f I →
      (∃ x ∈ I, IsMaxOn f I x) ∧ ∃ x ∈ I, IsMinOn f I x := fun f hf =>
    ⟨isCompact_Icc.exists_isMaxOn hne hf, isCompact_Icc.exists_isMinOn hne hf⟩
  have hpos : ∀ x ∈ I, 0 < x := fun x hx => lt_of_lt_of_le ha hx.1
  refine ⟨ext _ fun x hx => ?_, ext _ fun x hx => ?_, ext _ fun x hx => ?_,
    ext _ fun x hx => ?_⟩
  · exact (Br_clock_continuousAt y r KB Tb mB x hr (hpos x hx)).continuousWithinAt.sub
      (continuousWithinAt_const.mul (Ccr_continuousWithinAt H Sr K Ta m r x I (hpos x hx)
        (hH x hx) (hS x hx)))
  · exact (BrL_clock_continuousAt y r L KB Tb mB x hr (hpos x hx)).continuousWithinAt.sub
      (continuousWithinAt_const.mul (Ccr_continuousWithinAt H Sr K Ta m r x I (hpos x hx)
        (hH x hx) (hS x hx)))
  · exact (Br_clock_continuousAt y r KB Tb mB x hr (hpos x hx)).continuousWithinAt.sub
      (continuousWithinAt_const.mul (Clevr_continuousWithinAt h Sr K Ta m r x I hcont
        (hpos x hx) hK hm hTa hr.le (hS x hx)))
  · exact (BrL_clock_continuousAt y r L KB Tb mB x hr (hpos x hx)).continuousWithinAt.sub
      (continuousWithinAt_const.mul (Clevr_continuousWithinAt h Sr K Ta m r x I hcont
        (hpos x hx) hK hm hTa hr.le (hS x hx)))

/-- **P16(iii), the candidates, discounted speed-set (finite horizon)**, with `H` and `S_r`
differentiable at interior speeds off the clock and horizon kinks (fix round 1). -/
theorem p16_iii_candidates_discounted (H Sr H'f Sr'f : ℝ → ℝ) (K Ta m KB Tb mB y r L Vc a b x : ℝ)
    (ha : 0 < a) (hr : 0 < r) (hx : x ∈ Icc a b)
    (hH : ∀ z ∈ Ioo a b, K / z ≠ (1 - m) * Ta → KB / z ≠ (1 - mB) * Tb → clock KB Tb mB z ≠ L →
      HasDerivAt H (H'f z) z)
    (hS : ∀ z ∈ Ioo a b, K / z ≠ (1 - m) * Ta → KB / z ≠ (1 - mB) * Tb → clock KB Tb mB z ≠ L →
      HasDerivAt Sr (Sr'f z) z)
    (hext : IsMaxOn (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) (Icc a b) x ∨
      IsMinOn (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) (Icc a b) x) :
    x = a ∨ x = b ∨ K / x = (1 - m) * Ta ∨ KB / x = (1 - mB) * Tb ∨ clock KB Tb mB x = L ∨
      ∃ d, HasDerivAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) d x ∧ d = 0 := by
  by_cases h1 : x = a; · exact Or.inl h1
  by_cases h2 : x = b; · exact Or.inr (Or.inl h2)
  by_cases h3 : K / x = (1 - m) * Ta; · exact Or.inr (Or.inr (Or.inl h3))
  by_cases h4 : KB / x = (1 - mB) * Tb; · exact Or.inr (Or.inr (Or.inr (Or.inl h4)))
  by_cases h5 : clock KB Tb mB x = L; · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h5))))
  right; right; right; right; right
  have hx0 : 0 < x := lt_of_lt_of_le ha hx.1
  have hxI : x ∈ Ioo a b := ⟨lt_of_le_of_ne hx.1 (Ne.symm h1), lt_of_le_of_ne hx.2 h2⟩
  have hd := (BrL_within_offhorizon y r L KB Tb mB x _ univ hr
    (clock_hasDerivAt KB Tb mB x hx0 h4).hasDerivWithinAt h5).sub
    ((Ccr_hasDerivWithinAt_of H Sr (H'f x) K Ta m r x _ (Sr'f x) univ (hH x hxI h3 h4 h5)
      (clock_hasDerivAt K Ta m x hx0 h3).hasDerivWithinAt (hS x hxI h3 h4 h5)).const_mul Vc)
  rw [hasDerivWithinAt_univ] at hd
  exact ⟨_, hd, fermat_Icc _ a b x _ hxI hd hext⟩

/-- **P16(iii), the candidates, discounted level-set (finite horizon)**, with `S_r`
differentiable at interior speeds off the kinks. -/
theorem p16_iii_candidates_discounted_levelset (h Sr Sr'f : ℝ → ℝ)
    (K Ta m KB Tb mB y r L Vc a b x : ℝ) (hcont : Continuous h) (hK : 0 < K) (hm : 0 ≤ m)
    (hTa : 0 ≤ Ta) (ha : 0 < a) (hr : 0 < r) (hx : x ∈ Icc a b)
    (hS : ∀ z ∈ Ioo a b, K / z ≠ (1 - m) * Ta → KB / z ≠ (1 - mB) * Tb → clock KB Tb mB z ≠ L →
      HasDerivAt Sr (Sr'f z) z)
    (hext : IsMaxOn (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) (Icc a b) x ∨
      IsMinOn (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) (Icc a b) x) :
    x = a ∨ x = b ∨ K / x = (1 - m) * Ta ∨ KB / x = (1 - mB) * Tb ∨ clock KB Tb mB x = L ∨
      ∃ d, HasDerivAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) d x ∧ d = 0 := by
  by_cases h1 : x = a; · exact Or.inl h1
  by_cases h2 : x = b; · exact Or.inr (Or.inl h2)
  by_cases h3 : K / x = (1 - m) * Ta; · exact Or.inr (Or.inr (Or.inl h3))
  by_cases h4 : KB / x = (1 - mB) * Tb; · exact Or.inr (Or.inr (Or.inr (Or.inl h4)))
  by_cases h5 : clock KB Tb mB x = L; · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h5))))
  right; right; right; right; right
  have hx0 : 0 < x := lt_of_lt_of_le ha hx.1
  have hxI : x ∈ Ioo a b := ⟨lt_of_le_of_ne hx.1 (Ne.symm h1), lt_of_le_of_ne hx.2 h2⟩
  have hd := p16_C3_finite_hasDerivAt h Sr (Sr'f x) K Ta m KB Tb mB y r L Vc x hcont hx0 hK hm hTa
    hr (hS x hxI h3 h4 h5) h3 h4 h5
  exact ⟨_, hd, fermat_Icc _ a b x _ hxI hd hext⟩

/-- **P16(iii), the candidates, discounted speed-set, perpetual benefit** (fix round 1): an
optimizer is an endpoint, a clock kink, or a smooth stationary point (no horizon). -/
theorem p16_iii_candidates_perpetual (H Sr H'f Sr'f : ℝ → ℝ) (K Ta m KB Tb mB y r Vc a b x : ℝ)
    (ha : 0 < a) (hr : 0 < r) (hx : x ∈ Icc a b)
    (hH : ∀ z ∈ Ioo a b, K / z ≠ (1 - m) * Ta → KB / z ≠ (1 - mB) * Tb → HasDerivAt H (H'f z) z)
    (hS : ∀ z ∈ Ioo a b, K / z ≠ (1 - m) * Ta → KB / z ≠ (1 - mB) * Tb →
      HasDerivAt Sr (Sr'f z) z)
    (hext : IsMaxOn (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) (Icc a b) x ∨
      IsMinOn (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) (Icc a b) x) :
    x = a ∨ x = b ∨ K / x = (1 - m) * Ta ∨ KB / x = (1 - mB) * Tb ∨
      ∃ d, HasDerivAt (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) d x ∧ d = 0 := by
  by_cases h1 : x = a; · exact Or.inl h1
  by_cases h2 : x = b; · exact Or.inr (Or.inl h2)
  by_cases h3 : K / x = (1 - m) * Ta; · exact Or.inr (Or.inr (Or.inl h3))
  by_cases h4 : KB / x = (1 - mB) * Tb; · exact Or.inr (Or.inr (Or.inr (Or.inl h4)))
  right; right; right; right
  have hx0 : 0 < x := lt_of_lt_of_le ha hx.1
  have hxI : x ∈ Ioo a b := ⟨lt_of_le_of_ne hx.1 (Ne.symm h1), lt_of_le_of_ne hx.2 h2⟩
  have hd := (Br_comp_within y r _ _ x univ hr
    (clock_hasDerivAt KB Tb mB x hx0 h4).hasDerivWithinAt).sub
    ((Ccr_hasDerivWithinAt_of H Sr (H'f x) K Ta m r x _ (Sr'f x) univ (hH x hxI h3 h4)
      (clock_hasDerivAt K Ta m x hx0 h3).hasDerivWithinAt (hS x hxI h3 h4)).const_mul Vc)
  rw [hasDerivWithinAt_univ] at hd
  exact ⟨_, hd, fermat_Icc _ a b x _ hxI hd hext⟩

/-- **P16(iii), the candidates, discounted level-set, perpetual benefit** (fix round 1). -/
theorem p16_iii_candidates_perpetual_levelset (h Sr Sr'f : ℝ → ℝ)
    (K Ta m KB Tb mB y r Vc a b x : ℝ) (hcont : Continuous h) (hK : 0 < K) (hm : 0 ≤ m)
    (hTa : 0 ≤ Ta) (ha : 0 < a) (hr : 0 < r) (hx : x ∈ Icc a b)
    (hS : ∀ z ∈ Ioo a b, K / z ≠ (1 - m) * Ta → KB / z ≠ (1 - mB) * Tb →
      HasDerivAt Sr (Sr'f z) z)
    (hext : IsMaxOn (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) (Icc a b) x ∨
      IsMinOn (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) (Icc a b) x) :
    x = a ∨ x = b ∨ K / x = (1 - m) * Ta ∨ KB / x = (1 - mB) * Tb ∨
      ∃ d, HasDerivAt (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) d x ∧ d = 0 := by
  by_cases h1 : x = a; · exact Or.inl h1
  by_cases h2 : x = b; · exact Or.inr (Or.inl h2)
  by_cases h3 : K / x = (1 - m) * Ta; · exact Or.inr (Or.inr (Or.inl h3))
  by_cases h4 : KB / x = (1 - mB) * Tb; · exact Or.inr (Or.inr (Or.inr (Or.inl h4)))
  right; right; right; right
  have hx0 : 0 < x := lt_of_lt_of_le ha hx.1
  have hxI : x ∈ Ioo a b := ⟨lt_of_le_of_ne hx.1 (Ne.symm h1), lt_of_le_of_ne hx.2 h2⟩
  have hd := p16_C3_hasDerivAt h Sr (Sr'f x) K Ta m KB Tb mB y r Vc x hcont hx0 hK hm hTa hr
    (hS x hxI h3 h4) h3 h4
  exact ⟨_, hd, fermat_Icc _ a b x _ hxI hd hext⟩

/-- **Why `S_r` must be differentiable for the candidate list** (finding; witness rebuilt in fix
round 1 to satisfy every set-up hypothesis): with `S_r` continuous only, a discounted optimizer
can sit at a speed that is neither an endpoint, nor a clock or horizon kink, nor a smooth
stationary point.  Here `H(s) = s` (so `H > 0`, `H′ = 1 > 0`, `C¹`), `V_c = y = r = 1`, parallel
timing on both clocks, both on their adoption branches on `[2, 4]` (`K = T_a = T_b = 1`,
`K_B = 2`), `L = 10 ≥ sup T = 1` (one calendar ledger, line 1025), and the continuous,
nonnegative `S_r(s) = |s − 3|`.  The **unique** maximizer on `[2, 4]` is `s = 3`, where `W_{r,L}`
has no derivative. -/
theorem p16_iii_candidates_need_smooth_Sr :
    let W := fun x => WrL (fun x => x) 1 1 0 2 1 0 1 1 10 1 (fun x => |x - 3|) x
    (∀ z : ℝ, HasDerivAt (fun x : ℝ => x) 1 z) ∧ (∀ z ∈ Icc (2:ℝ) 4, 0 < z) ∧
      Continuous (fun x : ℝ => |x - 3|) ∧ (∀ z : ℝ, 0 ≤ |z - 3|) ∧
      (∀ z ∈ Icc (2:ℝ) 4, clock 1 1 0 z ≤ 10) ∧
      IsMaxOn W (Icc 2 4) 3 ∧ (∀ x ∈ Icc (2:ℝ) 4, x ≠ 3 → W x < W 3) ∧
      ¬ DifferentiableAt ℝ W 3 ∧
      (3:ℝ) ≠ 2 ∧ (3:ℝ) ≠ 4 ∧ (1:ℝ) / 3 ≠ (1 - 0) * 1 ∧ (2:ℝ) / 3 ≠ (1 - 0) * 1 ∧
      clock 2 1 0 3 ≠ 10 := by
  intro W
  have hval : ∀ x ∈ Icc (2:ℝ) 4, W x = BrL 1 1 10 1 - (x * Ar 1 1 + |x - 3|) := by
    intro x hx
    have hx0 : 0 < x := by linarith [hx.1]
    simp only [W, WrL, Ccr]
    rw [clock_adopt 1 1 0 x (by rw [div_le_iff₀ hx0]; linarith [hx.1]),
      clock_adopt 2 1 0 x (by rw [div_le_iff₀ hx0]; linarith [hx.1])]
    ring
  have hA0 : 0 < Ar 1 1 := Ar_pos 1 1 one_pos one_pos
  have hA1 : Ar 1 1 < 1 := by
    rw [Ar_eq 1 1 one_ne_zero, div_one]
    have := exp_pos (-1 * 1)
    linarith
  have hloc : ∀ᶠ x in 𝓝 (3:ℝ), W x = BrL 1 1 10 1 - (x * Ar 1 1 + |x - 3|) := by
    filter_upwards [Icc_mem_nhds (show (2:ℝ) < 3 by norm_num) (show (3:ℝ) < 4 by norm_num)]
      with x hx using hval x hx
  have hstrict : ∀ x ∈ Icc (2:ℝ) 4, x ≠ 3 → W x < W 3 := by
    intro x hx hne
    rw [hval x hx, hval 3 ⟨by norm_num, by norm_num⟩]
    rcases lt_or_gt_of_ne hne with h | h
    · rw [abs_of_neg (by linarith : x - 3 < 0)]; norm_num; nlinarith
    · rw [abs_of_pos (by linarith : 0 < x - 3)]; norm_num; nlinarith
  refine ⟨fun z => hasDerivAt_id z, fun z hz => by linarith [hz.1], by fun_prop,
    fun z => abs_nonneg _, fun z hz => ?_, fun x hx => ?_, hstrict, fun hd => ?_,
    by norm_num, by norm_num, by norm_num, by norm_num, ?_⟩
  · have hz0 : 0 < z := by linarith [hz.1]
    rw [clock_adopt 1 1 0 z (by rw [div_le_iff₀ hz0]; linarith [hz.1])]; norm_num
  · show W x ≤ W 3
    rcases eq_or_ne x 3 with h | h
    · rw [h]
    · exact (hstrict x hx h).le
  · have hd' : DifferentiableAt ℝ (fun x => BrL 1 1 10 1 - (x * Ar 1 1 + |x - 3|)) 3 :=
      hd.congr_of_eventuallyEq (hloc.mono fun x hx => hx.symm)
    have : DifferentiableAt ℝ (fun x : ℝ => |x - 3|) 3 := by
      have h4 := ((differentiableAt_const (BrL 1 1 10 1)).sub
        (differentiableAt_id.mul_const (Ar 1 1))).sub hd'
      refine h4.congr_of_eventuallyEq (Eventually.of_forall fun x => ?_)
      simp only [Pi.sub_apply, id]; ring
    have h2 : DifferentiableAt ℝ (fun x : ℝ => |x|) 0 := by
      have h3 : DifferentiableAt ℝ (fun x : ℝ => |x - 3|) ((fun x : ℝ => x + 3) 0) := by
        simpa using this
      have := h3.comp (0:ℝ) ((differentiableAt_id).add_const (3:ℝ))
      simpa [Function.comp_def] using this
    exact not_differentiableAt_abs_zero h2
  · rw [clock_adopt 2 1 0 3 (by norm_num)]; norm_num


/-! ## Completing the kink list and (C1) -/

/-- **(C1)** `sC_c′ = H(ε_HT − χ_cτ)` off the cyber kink, for `S` constant. -/
theorem p16_C1 (H : ℝ → ℝ) (H' K Ta m S s : ℝ) (hs : 0 < s) (hH : HasDerivAt H H' s)
    (hHpos : 0 < H s) (hkc : K / s ≠ (1 - m) * Ta) :
    HasDerivAt (fun x => Cc H K Ta m S x)
      (H s * (elast H H' s * clock K Ta m s - ind K Ta m s * (K / s)) / s) s := by
  have hC : HasDerivAt (fun x => Cc H K Ta m S x)
      (H' * clock K Ta m s + H s * (-(ind K Ta m s * (K / s)) / s)) s := by
    simpa [Cc] using (hH.mul (clock_hasDerivAt K Ta m s hs hkc)).add_const S
  refine hC.congr_deriv ?_
  unfold elast; field_simp; ring

/-- **Coincident cyber and benefit kinks, level-set**: the changes add, `−V_cτh(K) − yqη_L`. -/
theorem p16_kink_coincident_levelset (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 ≤ K) (hKB : 0 ≤ KB) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hkc : K / s₀ = (1 - m) * Ta) (hkB : KB / s₀ = (1 - mB) * Tb) (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * (K / s₀) * h K) - y * (KB / s₀) * eta L (clock KB Tb mB s₀) := by
  refine ⟨_, _, (BL_within_offhorizon y L KB Tb mB s₀ _ (Iic s₀)
      (clock_hasDerivWithinAt_Iic_kink KB Tb mB s₀ hs hKB hkB) hL).sub
    ((Clev_hasDerivWithinAt_of h K Ta m S s₀ _ (Iic s₀) hcont hs hK hm hTa
      (clock_hasDerivWithinAt_Iic_kink K Ta m s₀ hs hK hkc)).const_mul Vc),
    (BL_within_offhorizon y L KB Tb mB s₀ _ (Ici s₀)
      (clock_hasDerivWithinAt_Ici_kink KB Tb mB s₀ hs hKB hkB) hL).sub
    ((Clev_hasDerivWithinAt_of h K Ta m S s₀ _ (Ici s₀) hcont hs hK hm hTa
      (clock_hasDerivWithinAt_Ici_kink K Ta m s₀ hs hK hkc)).const_mul Vc), ?_⟩
  field_simp; ring

/-- **Coincident kinks, discounted speed-set**: `−V_cHτe^{−rT} − yqe^{−rt_B}`. -/
theorem p16_kink_coincident_discounted (H : ℝ → ℝ) (Sr : ℝ → ℝ)
    (H' Sr' K Ta m KB Tb mB y r Vc s₀ : ℝ)
    (hs : 0 < s₀) (hr : 0 < r) (hK : 0 ≤ K) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ = (1 - m) * Ta) (hkB : KB / s₀ = (1 - mB) * Tb) :
    ∃ dl dr, HasDerivWithinAt (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * H s₀ * (K / s₀)) * exp (-r * clock K Ta m s₀)
        - y * (KB / s₀) * exp (-r * clock KB Tb mB s₀) := by
  refine ⟨_, _, (Br_comp_within y r _ _ s₀ (Iic s₀) hr
      (clock_hasDerivWithinAt_Iic_kink KB Tb mB s₀ hs hKB hkB)).sub
    ((Ccr_hasDerivWithinAt_of H Sr H' K Ta m r s₀ _ Sr' (Iic s₀) hH
      (clock_hasDerivWithinAt_Iic_kink K Ta m s₀ hs hK hkc) hS).const_mul Vc),
    (Br_comp_within y r _ _ s₀ (Ici s₀) hr
      (clock_hasDerivWithinAt_Ici_kink KB Tb mB s₀ hs hKB hkB)).sub
    ((Ccr_hasDerivWithinAt_of H Sr H' K Ta m r s₀ _ Sr' (Ici s₀) hH
      (clock_hasDerivWithinAt_Ici_kink K Ta m s₀ hs hK hkc) hS).const_mul Vc), ?_⟩
  field_simp; ring

/-- **Benefit kink, discounted level-set**: `−yqe^{−rt_B}`, as for the speed-set hazard. -/
theorem p16_kink_benefit_levelset_discounted (h : ℝ → ℝ) (Sr : ℝ → ℝ)
    (Sr' K Ta m KB Tb mB y r Vc s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hr : 0 < r) (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ ≠ (1 - m) * Ta)
    (hkB : KB / s₀ = (1 - mB) * Tb) :
    ∃ dl dr, HasDerivWithinAt (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(y * (KB / s₀)) * exp (-r * clock KB Tb mB s₀) := by
  have hT0 := clock_hasDerivAt K Ta m s₀ hs hkc
  refine ⟨_, _, (Br_comp_within y r _ _ s₀ (Iic s₀) hr
      (clock_hasDerivWithinAt_Iic_kink KB Tb mB s₀ hs hKB hkB)).sub
    ((Clevr_hasDerivWithinAt_of h Sr K Ta m r s₀ _ Sr' (Iic s₀) hcont hs hK hm hTa hr.le
      hT0.hasDerivWithinAt hS).const_mul Vc),
    (Br_comp_within y r _ _ s₀ (Ici s₀) hr
      (clock_hasDerivWithinAt_Ici_kink KB Tb mB s₀ hs hKB hkB)).sub
    ((Clevr_hasDerivWithinAt_of h Sr K Ta m r s₀ _ Sr' (Ici s₀) hcont hs hK hm hTa hr.le
      hT0.hasDerivWithinAt hS).const_mul Vc), ?_⟩
  field_simp; ring

/-- **Horizon activation, discounted level-set**: `+yqe^{−rL}`. -/
theorem p16_kink_activation_levelset_discounted (h : ℝ → ℝ) (Sr : ℝ → ℝ)
    (Sr' K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hr : 0 < r) (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ ≠ (1 - m) * Ta)
    (hcap : (1 - mB) * Tb < KB / s₀) (hL : clock KB Tb mB s₀ = L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = y * (KB / s₀) * exp (-r * L) := by
  have hT0 := clock_hasDerivAt K Ta m s₀ hs hkc
  have htB := (clock_hasDerivAt KB Tb mB s₀ hs hcap.ne').hasDerivWithinAt (s := Ici s₀)
  refine ⟨_, _, (BrL_activation_left y r L KB Tb mB s₀ hKB hs hL).sub
    ((Clevr_hasDerivWithinAt_of h Sr K Ta m r s₀ _ Sr' (Iic s₀) hcont hs hK hm hTa hr.le
      hT0.hasDerivWithinAt hS).const_mul Vc),
    (BrL_activation_right y r L KB Tb mB s₀ _ hKB hs hr hL htB).sub
    ((Clevr_hasDerivWithinAt_of h Sr K Ta m r s₀ _ Sr' (Ici s₀) hcont hs hK hm hTa hr.le
      hT0.hasDerivWithinAt hS).const_mul Vc), ?_⟩
  simp only [ind, hcap, ite_true]
  field_simp; ring

/-- **"Plateaus and nonisolated critical sets are possible"; compactness gives existence, not
uniqueness** (lines 1341, 1343): with the illustrative values but `T_b = L = 10` (fix round 1:
`L` covers the whole transition, `ex_transition_within_10`), every speed in `[0.5, 1]`
maximizes the balance on `[0.5, 6]`. -/
theorem p16_flat_set_of_maximizers :
    ∀ s ∈ Icc (1 / 2 : ℝ) 1,
      IsMaxOn (fun x => WL (fun x => x) 1 1 0 4 10 0 1 10 1 0 x) (Icc (1 / 2) 6) s := by
  have hval : ∀ x, 0 < x → WL (fun x => x) 1 1 0 4 10 0 1 10 1 0 x = -max 1 x := by
    intro x hx
    simp only [WL, Cc]
    rw [p16_horizon_none 1 10 4 10 0 x le_rfl]
    simp only [clock]
    rcases le_or_gt x 1 with h | h
    · rw [max_eq_left (show (1 - 0) * (1:ℝ) ≤ 1 / x by rw [le_div_iff₀ hx]; linarith),
        max_eq_left h]
      field_simp; ring
    · rw [max_eq_right (show 1 / x ≤ (1 - 0) * (1:ℝ) by rw [div_le_iff₀ hx]; linarith),
        max_eq_right h.le]
      ring
  intro s hs x hx
  show WL (fun x => x) 1 1 0 4 10 0 1 10 1 0 x ≤ WL (fun x => x) 1 1 0 4 10 0 1 10 1 0 s
  rw [hval x (by linarith [hx.1]), hval s (by linarith [hs.1]), max_eq_left hs.2]
  linarith [le_max_left 1 x]


/-- **"A first-order condition alone is not a global result"** (line 1348): `x³ − 3x` is
stationary at `−1` (a strict local maximum) but `−1` does not maximize it on `[−2, 3]`. -/
theorem p16_suff3_foc_not_global :
    HasDerivAt (fun x : ℝ => x ^ 3 - 3 * x) 0 (-1) ∧
      ¬ IsMaxOn (fun x : ℝ => x ^ 3 - 3 * x) (Icc (-2) 3) (-1) := by
  refine ⟨?_, fun hmax => ?_⟩
  · have := (hasDerivAt_pow 3 (-1 : ℝ)).sub ((hasDerivAt_id (-1 : ℝ)).const_mul 3)
    refine this.congr_deriv ?_
    norm_num
  · have := hmax (show (3:ℝ) ∈ Icc (-2) 3 by norm_num)
    have h : (3:ℝ) ^ 3 - 3 * 3 ≤ (-1) ^ 3 - 3 * (-1) := this
    norm_num at h


/-! ## Fix round 1: every kink, by substituting the indicators of each side (line 1058)

"At a kink `s₀`, take all primitives at `s₀` and substitute the indicators of each side."  On
the lower-speed side a clock at its kink is on its capability branch (`indL`, weak inequality);
on the higher-speed side it is on its adoption branch (`ind`, strict).  At the horizon the
arrival date is at or after `L` on the lower side (`eta`, strict) and at or before it on the
higher side (`etaR`, weak).  `H` and `S_r` enter through their own one-sided derivatives, so a
further kink in `H` or `S_r` is covered too ("where there is one, its one-sided derivatives enter
too").  One general theorem per objective gives both one-sided derivatives and the change in
`sW′`; every single and coincident kink (cyber, benefit, horizon, primitive) is the evaluation
of its indicators. -/

/-- `χ` on the lower-speed side of `s`: capability binds weakly. -/
noncomputable def indL (D t₀ m s : ℝ) : ℝ := if (1 - m) * t₀ ≤ D / s then 1 else 0

/-- `η_L` on the higher-speed side of `s`: arrival at or before the horizon. -/
noncomputable def etaR (L t : ℝ) : ℝ := if t ≤ L then 1 else 0

theorem ind_kink (D t₀ m s : ℝ) (hk : D / s = (1 - m) * t₀) :
    indL D t₀ m s = 1 ∧ ind D t₀ m s = 0 := by
  simp [indL, ind, hk]

theorem indL_off (D t₀ m s : ℝ) (hne : D / s ≠ (1 - m) * t₀) : indL D t₀ m s = ind D t₀ m s := by
  unfold indL ind
  rcases lt_or_gt_of_ne hne with h | h
  · simp [not_le.mpr h, not_lt.mpr h.le]
  · simp [h.le, h]

theorem eta_at (L : ℝ) : eta L L = 0 ∧ etaR L L = 1 := by simp [eta, etaR]

theorem etaR_off (L t : ℝ) (hne : t ≠ L) : etaR L t = eta L t := by
  unfold eta etaR
  rcases lt_or_gt_of_ne hne with h | h
  · simp [h.le, h]
  · simp [not_le.mpr h, not_lt.mpr h.le]

/-- Left derivative of a clock at any positive speed: `−indL·(D/s₀)/s₀`. -/
theorem clock_left (D t₀ m s₀ : ℝ) (hs : 0 < s₀) (hD : 0 ≤ D) :
    HasDerivWithinAt (fun x => clock D t₀ m x) (-(indL D t₀ m s₀ * (D / s₀)) / s₀) (Iic s₀) s₀ := by
  rcases lt_trichotomy ((1 - m) * t₀) (D / s₀) with h | h | h
  · have := (clock_hasDerivAt D t₀ m s₀ hs h.ne').hasDerivWithinAt (s := Iic s₀)
    simpa [indL, ind, h, h.le] using this
  · have := clock_hasDerivWithinAt_Iic_kink D t₀ m s₀ hs hD h.symm
    simpa [indL, h.le] using this
  · have := (clock_hasDerivAt D t₀ m s₀ hs h.ne).hasDerivWithinAt (s := Iic s₀)
    simpa [indL, ind, not_le.mpr h, not_lt.mpr h.le] using this

/-- Right derivative of a clock at any positive speed: `−ind·(D/s₀)/s₀`. -/
theorem clock_right (D t₀ m s₀ : ℝ) (hs : 0 < s₀) (hD : 0 ≤ D) :
    HasDerivWithinAt (fun x => clock D t₀ m x) (-(ind D t₀ m s₀ * (D / s₀)) / s₀) (Ici s₀) s₀ := by
  by_cases h : (1 - m) * t₀ < D / s₀
  · exact (clock_hasDerivAt D t₀ m s₀ hs h.ne').hasDerivWithinAt
  · rcases eq_or_lt_of_le (not_lt.mp h) with h' | h'
    · have := clock_hasDerivWithinAt_Ici_kink D t₀ m s₀ hs hD h'
      simpa [ind, h] using this
    · exact (clock_hasDerivAt D t₀ m s₀ hs h'.ne).hasDerivWithinAt

/-- Left derivative of `B_L(t_B(s))` at any positive speed, horizon crossing included. -/
theorem BL_left (y L KB Tb mB s₀ : ℝ) (hs : 0 < s₀) (hKB : 0 ≤ KB) :
    HasDerivWithinAt (fun x => BL y L (clock KB Tb mB x))
      (y * (KB / s₀) * indL KB Tb mB s₀ * eta L (clock KB Tb mB s₀) / s₀) (Iic s₀) s₀ := by
  have hT := clock_left KB Tb mB s₀ hs hKB
  rcases lt_trichotomy (clock KB Tb mB s₀) L with h | h | h
  · refine (BL_comp_within_before y L _ _ s₀ _ hT h).congr_deriv ?_
    simp only [eta, h, ite_true]; ring
  · refine (BL_activation_left y L KB Tb mB s₀ hKB hs h).congr_deriv ?_
    simp [eta, h]
  · refine (BL_comp_within_after y L _ _ s₀ _ hT h).congr_deriv ?_
    simp [eta, not_lt.mpr h.le]

/-- Right derivative of `B_L(t_B(s))` at any positive speed. -/
theorem BL_right (y L KB Tb mB s₀ : ℝ) (hs : 0 < s₀) (hKB : 0 ≤ KB) :
    HasDerivWithinAt (fun x => BL y L (clock KB Tb mB x))
      (y * (KB / s₀) * ind KB Tb mB s₀ * etaR L (clock KB Tb mB s₀) / s₀) (Ici s₀) s₀ := by
  have hT := clock_right KB Tb mB s₀ hs hKB
  rcases lt_trichotomy (clock KB Tb mB s₀) L with h | h | h
  · refine (BL_comp_within_before y L _ _ s₀ _ hT h).congr_deriv ?_
    simp only [etaR, h.le, ite_true]; ring
  · refine (BL_activation_right y L KB Tb mB s₀ _ hKB hs h hT).congr_deriv ?_
    simp only [etaR, h.le, ite_true]; ring
  · refine (BL_comp_within_after y L _ _ s₀ _ hT h).congr_deriv ?_
    simp [etaR, not_le.mpr h]

/-- Left derivative of `B_{r,L}(t_B(s))` at any positive speed. -/
theorem BrL_left (y r L KB Tb mB s₀ : ℝ) (hs : 0 < s₀) (hKB : 0 ≤ KB) (hr : 0 < r) :
    HasDerivWithinAt (fun x => BrL y r L (clock KB Tb mB x))
      (y * (KB / s₀) * indL KB Tb mB s₀ * eta L (clock KB Tb mB s₀)
        * exp (-r * clock KB Tb mB s₀) / s₀) (Iic s₀) s₀ := by
  have hT := clock_left KB Tb mB s₀ hs hKB
  rcases lt_trichotomy (clock KB Tb mB s₀) L with h | h | h
  · refine (BrL_comp_within_before y r L _ _ s₀ _ hr hT h).congr_deriv ?_
    simp only [eta, h, ite_true]; ring
  · refine (BrL_activation_left y r L KB Tb mB s₀ hKB hs h).congr_deriv ?_
    simp [eta, h]
  · refine (BrL_comp_within_after y r L _ _ s₀ _ hr hT h).congr_deriv ?_
    simp [eta, not_lt.mpr h.le]

/-- Right derivative of `B_{r,L}(t_B(s))` at any positive speed. -/
theorem BrL_right (y r L KB Tb mB s₀ : ℝ) (hs : 0 < s₀) (hKB : 0 ≤ KB) (hr : 0 < r) :
    HasDerivWithinAt (fun x => BrL y r L (clock KB Tb mB x))
      (y * (KB / s₀) * ind KB Tb mB s₀ * etaR L (clock KB Tb mB s₀)
        * exp (-r * clock KB Tb mB s₀) / s₀) (Ici s₀) s₀ := by
  have hT := clock_right KB Tb mB s₀ hs hKB
  rcases lt_trichotomy (clock KB Tb mB s₀) L with h | h | h
  · refine (BrL_comp_within_before y r L _ _ s₀ _ hr hT h).congr_deriv ?_
    simp only [etaR, h.le, ite_true]; ring
  · refine (BrL_activation_right y r L KB Tb mB s₀ _ hKB hs hr h hT).congr_deriv ?_
    rw [h]; simp only [etaR, le_refl, ite_true]; ring
  · refine (BrL_comp_within_after y r L _ _ s₀ _ hr hT h).congr_deriv ?_
    simp [etaR, not_le.mpr h]

/-- The discounted level-set loss within a set, with `S_r` differentiable only within it. -/
theorem Clevr_hasDerivWithinAt_within (h : ℝ → ℝ) (Sr : ℝ → ℝ) (K Ta m r s T' Sr' : ℝ)
    (U : Set ℝ) (hcont : Continuous h) (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hr : 0 ≤ r) (hT : HasDerivWithinAt (fun x => clock K Ta m x) T' U s)
    (hS : HasDerivWithinAt Sr Sr' U s) :
    HasDerivWithinAt (fun x => Clevr h K Ta m r Sr x)
      (-(K / s) * hbarRD h K r s / s
        + h K * (exp (-r * clock K Ta m s) * T' - exp (-r * (K / s)) * (-(K / s) / s)) + Sr')
      U s := by
  have hev : ∀ᶠ x in 𝓝[U] s, Clevr h K Ta m r Sr x
      = x⁻¹ * Gr h K r x + h K * (Ar r (clock K Ta m x) - Ar r (K / x)) + Sr x := by
    filter_upwards [eventually_nhdsWithin_of_eventually_nhds (lt_mem_nhds hs)] with x hx
    exact Clevr_eq h K Ta m r Sr x hcont hx hK.le hm hTa
  have hA1 := (Ar_hasDerivAt r (clock K Ta m s)).comp_hasDerivWithinAt s hT
  have hA2 := (Ar_hasDerivAt r (K / s)).comp s (hasDerivAt_div_self K s hs.ne')
  have hd := (((ramp_disc_hasDerivAt h K r s hcont hK hr hs).hasDerivWithinAt (s := U)).add
    ((hA1.sub hA2.hasDerivWithinAt).const_mul (h K))).add hS
  exact hd.congr_of_eventuallyEq hev (Clevr_eq h K Ta m r Sr s hcont hs hK.le hm hTa)

/-- **General kink, undiscounted speed-set**: at any `s₀ > 0`, with one-sided derivatives
`H′₋, H′₊` of `H`, both one-sided derivatives of `W_L` exist, `s₀W′₋` and `s₀W′₊` are the master
formula with each side's indicators, and the change is
`−V_cTs₀ΔH′ − V_cHτ(χ_c⁻ − χ_c⁺) + yq(χ_B⁺η⁺ − χ_B⁻η⁻)`. -/
theorem p16_kink_general_speedset (H : ℝ → ℝ) (Hl Hr K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hs : 0 < s₀) (hK : 0 ≤ K) (hKB : 0 ≤ KB)
    (hHl : HasDerivWithinAt H Hl (Iic s₀) s₀) (hHr : HasDerivWithinAt H Hr (Ici s₀) s₀) :
    ∃ dl dr, HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * dl = y * (KB / s₀) * indL KB Tb mB s₀ * eta L (clock KB Tb mB s₀)
        - Vc * (s₀ * Hl * clock K Ta m s₀ - H s₀ * indL K Ta m s₀ * (K / s₀)) ∧
      s₀ * dr = y * (KB / s₀) * ind KB Tb mB s₀ * etaR L (clock KB Tb mB s₀)
        - Vc * (s₀ * Hr * clock K Ta m s₀ - H s₀ * ind K Ta m s₀ * (K / s₀)) ∧
      s₀ * (dr - dl) = -(Vc * clock K Ta m s₀ * (s₀ * (Hr - Hl)))
        + Vc * H s₀ * (K / s₀) * (ind K Ta m s₀ - indL K Ta m s₀)
        + y * (KB / s₀) * (ind KB Tb mB s₀ * etaR L (clock KB Tb mB s₀)
          - indL KB Tb mB s₀ * eta L (clock KB Tb mB s₀)) := by
  have hCl : HasDerivWithinAt (fun x => Cc H K Ta m S x) _ (Iic s₀) s₀ :=
    (hHl.mul (clock_left K Ta m s₀ hs hK)).add_const S
  have hCr : HasDerivWithinAt (fun x => Cc H K Ta m S x) _ (Ici s₀) s₀ :=
    (hHr.mul (clock_right K Ta m s₀ hs hK)).add_const S
  refine ⟨_, _, (BL_left y L KB Tb mB s₀ hs hKB).sub (hCl.const_mul Vc),
    (BL_right y L KB Tb mB s₀ hs hKB).sub (hCr.const_mul Vc), ?_, ?_, ?_⟩ <;>
  (field_simp; ring)

/-- **General kink, undiscounted level-set.** -/
theorem p16_kink_general_levelset (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m)
    (hTa : 0 ≤ Ta) :
    ∃ dl dr, HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * dl = y * (KB / s₀) * indL KB Tb mB s₀ * eta L (clock KB Tb mB s₀)
        - Vc * (K / s₀) * ((1 - indL K Ta m s₀) * h K - hbar h K) ∧
      s₀ * dr = y * (KB / s₀) * ind KB Tb mB s₀ * etaR L (clock KB Tb mB s₀)
        - Vc * (K / s₀) * ((1 - ind K Ta m s₀) * h K - hbar h K) ∧
      s₀ * (dr - dl) = Vc * (K / s₀) * h K * (ind K Ta m s₀ - indL K Ta m s₀)
        + y * (KB / s₀) * (ind KB Tb mB s₀ * etaR L (clock KB Tb mB s₀)
          - indL KB Tb mB s₀ * eta L (clock KB Tb mB s₀)) := by
  refine ⟨_, _, (BL_left y L KB Tb mB s₀ hs hKB).sub
      ((Clev_hasDerivWithinAt_of h K Ta m S s₀ _ (Iic s₀) hcont hs hK.le hm hTa
        (clock_left K Ta m s₀ hs hK.le)).const_mul Vc),
    (BL_right y L KB Tb mB s₀ hs hKB).sub
      ((Clev_hasDerivWithinAt_of h K Ta m S s₀ _ (Ici s₀) hcont hs hK.le hm hTa
        (clock_right K Ta m s₀ hs hK.le)).const_mul Vc), ?_, ?_, ?_⟩ <;>
  ((try simp only [hbar]); field_simp; ring)

/-- **General kink, discounted speed-set, perpetual benefit.**  The change is
`−V_cA_r(T)s₀ΔH′ − V_cHτe^{−rT}(χ_c⁻ − χ_c⁺) − V_cs₀ΔS_r′ − yqe^{−rt_B}(χ_B⁻ − χ_B⁺)`. -/
theorem p16_kink_general_discounted (H Sr : ℝ → ℝ) (Hl Hr Sl Srr K Ta m KB Tb mB y r Vc s₀ : ℝ)
    (hs : 0 < s₀) (hr : 0 < r) (hK : 0 ≤ K) (hKB : 0 ≤ KB)
    (hHl : HasDerivWithinAt H Hl (Iic s₀) s₀) (hHr : HasDerivWithinAt H Hr (Ici s₀) s₀)
    (hSl : HasDerivWithinAt Sr Sl (Iic s₀) s₀) (hSr : HasDerivWithinAt Sr Srr (Ici s₀) s₀) :
    ∃ dl dr, HasDerivWithinAt (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => Wr H K Ta m KB Tb mB y r Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * dl = y * (KB / s₀) * indL KB Tb mB s₀ * exp (-r * clock KB Tb mB s₀)
        - Vc * (s₀ * Hl * Ar r (clock K Ta m s₀)
          - H s₀ * indL K Ta m s₀ * (K / s₀) * exp (-r * clock K Ta m s₀)) - Vc * (s₀ * Sl) ∧
      s₀ * dr = y * (KB / s₀) * ind KB Tb mB s₀ * exp (-r * clock KB Tb mB s₀)
        - Vc * (s₀ * Hr * Ar r (clock K Ta m s₀)
          - H s₀ * ind K Ta m s₀ * (K / s₀) * exp (-r * clock K Ta m s₀)) - Vc * (s₀ * Srr) ∧
      s₀ * (dr - dl) = -(Vc * Ar r (clock K Ta m s₀) * (s₀ * (Hr - Hl)))
        + Vc * H s₀ * (K / s₀) * exp (-r * clock K Ta m s₀) * (ind K Ta m s₀ - indL K Ta m s₀)
        - Vc * (s₀ * (Srr - Sl))
        + y * (KB / s₀) * exp (-r * clock KB Tb mB s₀)
          * (ind KB Tb mB s₀ - indL KB Tb mB s₀) := by
  have hCl : HasDerivWithinAt (fun x => Ccr H K Ta m r Sr x) _ (Iic s₀) s₀ :=
    (hHl.mul ((Ar_hasDerivAt r (clock K Ta m s₀)).comp_hasDerivWithinAt s₀
      (clock_left K Ta m s₀ hs hK))).add hSl
  have hCr : HasDerivWithinAt (fun x => Ccr H K Ta m r Sr x) _ (Ici s₀) s₀ :=
    (hHr.mul ((Ar_hasDerivAt r (clock K Ta m s₀)).comp_hasDerivWithinAt s₀
      (clock_right K Ta m s₀ hs hK))).add hSr
  refine ⟨_, _, (Br_comp_within y r _ _ s₀ (Iic s₀) hr (clock_left KB Tb mB s₀ hs hKB)).sub
      (hCl.const_mul Vc),
    (Br_comp_within y r _ _ s₀ (Ici s₀) hr (clock_right KB Tb mB s₀ hs hKB)).sub
      (hCr.const_mul Vc), ?_, ?_, ?_⟩ <;>
  (simp only [Function.comp_apply]; field_simp; ring)

/-- **General kink, discounted speed-set, finite horizon.** -/
theorem p16_kink_general_discounted_finite (H Sr : ℝ → ℝ)
    (Hl Hr Sl Srr K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hs : 0 < s₀) (hr : 0 < r) (hK : 0 ≤ K) (hKB : 0 ≤ KB)
    (hHl : HasDerivWithinAt H Hl (Iic s₀) s₀) (hHr : HasDerivWithinAt H Hr (Ici s₀) s₀)
    (hSl : HasDerivWithinAt Sr Sl (Iic s₀) s₀) (hSr : HasDerivWithinAt Sr Srr (Ici s₀) s₀) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * dl = y * (KB / s₀) * indL KB Tb mB s₀ * eta L (clock KB Tb mB s₀)
          * exp (-r * clock KB Tb mB s₀)
        - Vc * (s₀ * Hl * Ar r (clock K Ta m s₀)
          - H s₀ * indL K Ta m s₀ * (K / s₀) * exp (-r * clock K Ta m s₀)) - Vc * (s₀ * Sl) ∧
      s₀ * dr = y * (KB / s₀) * ind KB Tb mB s₀ * etaR L (clock KB Tb mB s₀)
          * exp (-r * clock KB Tb mB s₀)
        - Vc * (s₀ * Hr * Ar r (clock K Ta m s₀)
          - H s₀ * ind K Ta m s₀ * (K / s₀) * exp (-r * clock K Ta m s₀)) - Vc * (s₀ * Srr) ∧
      s₀ * (dr - dl) = -(Vc * Ar r (clock K Ta m s₀) * (s₀ * (Hr - Hl)))
        + Vc * H s₀ * (K / s₀) * exp (-r * clock K Ta m s₀) * (ind K Ta m s₀ - indL K Ta m s₀)
        - Vc * (s₀ * (Srr - Sl))
        + y * (KB / s₀) * exp (-r * clock KB Tb mB s₀)
          * (ind KB Tb mB s₀ * etaR L (clock KB Tb mB s₀)
            - indL KB Tb mB s₀ * eta L (clock KB Tb mB s₀)) := by
  have hCl : HasDerivWithinAt (fun x => Ccr H K Ta m r Sr x) _ (Iic s₀) s₀ :=
    (hHl.mul ((Ar_hasDerivAt r (clock K Ta m s₀)).comp_hasDerivWithinAt s₀
      (clock_left K Ta m s₀ hs hK))).add hSl
  have hCr : HasDerivWithinAt (fun x => Ccr H K Ta m r Sr x) _ (Ici s₀) s₀ :=
    (hHr.mul ((Ar_hasDerivAt r (clock K Ta m s₀)).comp_hasDerivWithinAt s₀
      (clock_right K Ta m s₀ hs hK))).add hSr
  refine ⟨_, _, (BrL_left y r L KB Tb mB s₀ hs hKB hr).sub (hCl.const_mul Vc),
    (BrL_right y r L KB Tb mB s₀ hs hKB hr).sub (hCr.const_mul Vc), ?_, ?_, ?_⟩ <;>
  (simp only [Function.comp_apply]; field_simp; ring)

/-- **General kink, discounted level-set, perpetual benefit.** -/
theorem p16_kink_general_discounted_levelset (h Sr : ℝ → ℝ) (Sl Srr K Ta m KB Tb mB y r Vc s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hr : 0 < r) (hSl : HasDerivWithinAt Sr Sl (Iic s₀) s₀)
    (hSr : HasDerivWithinAt Sr Srr (Ici s₀) s₀) :
    ∃ dl dr, HasDerivWithinAt (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * dl = y * (KB / s₀) * indL KB Tb mB s₀ * exp (-r * clock KB Tb mB s₀)
        - Vc * (K / s₀) * (h K * (exp (-r * (K / s₀))
            - indL K Ta m s₀ * exp (-r * clock K Ta m s₀)) - hbarRD h K r s₀)
        - Vc * (s₀ * Sl) ∧
      s₀ * dr = y * (KB / s₀) * ind KB Tb mB s₀ * exp (-r * clock KB Tb mB s₀)
        - Vc * (K / s₀) * (h K * (exp (-r * (K / s₀))
            - ind K Ta m s₀ * exp (-r * clock K Ta m s₀)) - hbarRD h K r s₀)
        - Vc * (s₀ * Srr) ∧
      s₀ * (dr - dl) = Vc * (K / s₀) * h K * exp (-r * clock K Ta m s₀)
          * (ind K Ta m s₀ - indL K Ta m s₀)
        - Vc * (s₀ * (Srr - Sl))
        + y * (KB / s₀) * exp (-r * clock KB Tb mB s₀)
          * (ind KB Tb mB s₀ - indL KB Tb mB s₀) := by
  refine ⟨_, _, (Br_comp_within y r _ _ s₀ (Iic s₀) hr (clock_left KB Tb mB s₀ hs hKB)).sub
      ((Clevr_hasDerivWithinAt_within h Sr K Ta m r s₀ _ Sl (Iic s₀) hcont hs hK hm hTa hr.le
        (clock_left K Ta m s₀ hs hK.le) hSl).const_mul Vc),
    (Br_comp_within y r _ _ s₀ (Ici s₀) hr (clock_right KB Tb mB s₀ hs hKB)).sub
      ((Clevr_hasDerivWithinAt_within h Sr K Ta m r s₀ _ Srr (Ici s₀) hcont hs hK hm hTa hr.le
        (clock_right K Ta m s₀ hs hK.le) hSr).const_mul Vc), ?_, ?_, ?_⟩ <;>
  (field_simp; ring)

/-- **General kink, discounted level-set, finite horizon.** -/
theorem p16_kink_general_discounted_levelset_finite (h Sr : ℝ → ℝ)
    (Sl Srr K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hr : 0 < r) (hSl : HasDerivWithinAt Sr Sl (Iic s₀) s₀)
    (hSr : HasDerivWithinAt Sr Srr (Ici s₀) s₀) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * dl = y * (KB / s₀) * indL KB Tb mB s₀ * eta L (clock KB Tb mB s₀)
          * exp (-r * clock KB Tb mB s₀)
        - Vc * (K / s₀) * (h K * (exp (-r * (K / s₀))
            - indL K Ta m s₀ * exp (-r * clock K Ta m s₀)) - hbarRD h K r s₀)
        - Vc * (s₀ * Sl) ∧
      s₀ * dr = y * (KB / s₀) * ind KB Tb mB s₀ * etaR L (clock KB Tb mB s₀)
          * exp (-r * clock KB Tb mB s₀)
        - Vc * (K / s₀) * (h K * (exp (-r * (K / s₀))
            - ind K Ta m s₀ * exp (-r * clock K Ta m s₀)) - hbarRD h K r s₀)
        - Vc * (s₀ * Srr) ∧
      s₀ * (dr - dl) = Vc * (K / s₀) * h K * exp (-r * clock K Ta m s₀)
          * (ind K Ta m s₀ - indL K Ta m s₀)
        - Vc * (s₀ * (Srr - Sl))
        + y * (KB / s₀) * exp (-r * clock KB Tb mB s₀)
          * (ind KB Tb mB s₀ * etaR L (clock KB Tb mB s₀)
            - indL KB Tb mB s₀ * eta L (clock KB Tb mB s₀)) := by
  refine ⟨_, _, (BrL_left y r L KB Tb mB s₀ hs hKB hr).sub
      ((Clevr_hasDerivWithinAt_within h Sr K Ta m r s₀ _ Sl (Iic s₀) hcont hs hK hm hTa hr.le
        (clock_left K Ta m s₀ hs hK.le) hSl).const_mul Vc),
    (BrL_right y r L KB Tb mB s₀ hs hKB hr).sub
      ((Clevr_hasDerivWithinAt_within h Sr K Ta m r s₀ _ Srr (Ici s₀) hcont hs hK hm hTa hr.le
        (clock_right K Ta m s₀ hs hK.le) hSr).const_mul Vc), ?_, ?_, ?_⟩ <;>
  (field_simp; ring)

/-! ### The kink combinations the earlier certificates left out, as evaluations -/

/-- **Cyber kink coinciding with horizon activation, speed-set** (Sol 5): the changes add,
`−V_cHτ + yq`. -/
theorem p16_kink_cyber_activation_speedset (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hs : 0 < s₀) (hK : 0 ≤ K) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hkc : K / s₀ = (1 - m) * Ta) (hcap : (1 - mB) * Tb < KB / s₀)
    (hL : clock KB Tb mB s₀ = L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * H s₀ * (K / s₀)) + y * (KB / s₀) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_speedset H H' H' K Ta m KB Tb mB y L Vc
    S s₀ hs hK hKB hH.hasDerivWithinAt hH.hasDerivWithinAt
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, hL, (ind_kink K Ta m s₀ hkc).1, (ind_kink K Ta m s₀ hkc).2,
    indL_off KB Tb mB s₀ hcap.ne', (eta_at L).1, (eta_at L).2,
    show ind KB Tb mB s₀ = 1 by simp [ind, hcap]]
  ring

/-- **Benefit kink exactly at the horizon (`t_B = L`, i.e. `L = T_b`), speed-set** (Sol 5): the
change is zero, the "zero if it is not [inside]" case at equality. -/
theorem p16_kink_benefit_at_horizon_speedset (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hs : 0 < s₀) (hK : 0 ≤ K) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hkc : K / s₀ ≠ (1 - m) * Ta) (hkB : KB / s₀ = (1 - mB) * Tb)
    (hL : clock KB Tb mB s₀ = L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = 0 := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_speedset H H' H' K Ta m KB Tb mB y L Vc
    S s₀ hs hK hKB hH.hasDerivWithinAt hH.hasDerivWithinAt
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, hL, indL_off K Ta m s₀ hkc, (ind_kink KB Tb mB s₀ hkB).1,
    (ind_kink KB Tb mB s₀ hkB).2, (eta_at L).1, (eta_at L).2]
  ring

/-- **Benefit kink exactly at the horizon, level-set**: zero change. -/
theorem p16_kink_benefit_at_horizon_levelset (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m)
    (hTa : 0 ≤ Ta) (hkc : K / s₀ ≠ (1 - m) * Ta) (hkB : KB / s₀ = (1 - mB) * Tb)
    (hL : clock KB Tb mB s₀ = L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = 0 := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_levelset h K Ta m KB Tb mB y L Vc S s₀
    hcont hs hK hKB hm hTa
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, hL, indL_off K Ta m s₀ hkc, (ind_kink KB Tb mB s₀ hkB).1,
    (ind_kink KB Tb mB s₀ hkB).2, (eta_at L).1, (eta_at L).2]
  ring

/-- **Cyber kink coinciding with horizon activation, level-set**: `−V_cτh(K) + yq`. -/
theorem p16_kink_cyber_activation_levelset (h : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m)
    (hTa : 0 ≤ Ta) (hkc : K / s₀ = (1 - m) * Ta) (hcap : (1 - mB) * Tb < KB / s₀)
    (hL : clock KB Tb mB s₀ = L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WLlev h K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * (K / s₀) * h K) + y * (KB / s₀) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_levelset h K Ta m KB Tb mB y L Vc S s₀
    hcont hs hK hKB hm hTa
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, hL, (ind_kink K Ta m s₀ hkc).1, (ind_kink K Ta m s₀ hkc).2,
    indL_off KB Tb mB s₀ hcap.ne', (eta_at L).1, (eta_at L).2,
    show ind KB Tb mB s₀ = 1 by simp [ind, hcap]]
  ring

/-- **Cyber kink, discounted speed-set, finite horizon** (Opus 3): `−V_cHτe^{−rT}`. -/
theorem p16_kink_cyber_discounted_finite (H Sr : ℝ → ℝ) (H' Sr' K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hs : 0 < s₀) (hr : 0 < r) (hK : 0 ≤ K) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ = (1 - m) * Ta) (hkB : KB / s₀ ≠ (1 - mB) * Tb)
    (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * H s₀ * (K / s₀)) * exp (-r * clock K Ta m s₀) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_discounted_finite H Sr H' H' Sr' Sr' K Ta
    m KB Tb mB y r L Vc s₀ hs hr hK hKB hH.hasDerivWithinAt hH.hasDerivWithinAt
    hS.hasDerivWithinAt hS.hasDerivWithinAt
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, (ind_kink K Ta m s₀ hkc).1, (ind_kink K Ta m s₀ hkc).2, indL_off KB Tb mB s₀ hkB,
    etaR_off L _ hL]
  ring

/-- **Benefit kink, discounted speed-set, finite horizon** (Opus 3): `−yqη_Le^{−rt_B}`. -/
theorem p16_kink_benefit_discounted_finite (H Sr : ℝ → ℝ) (H' Sr' K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hs : 0 < s₀) (hr : 0 < r) (hK : 0 ≤ K) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ ≠ (1 - m) * Ta) (hkB : KB / s₀ = (1 - mB) * Tb)
    (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl)
        = -(y * (KB / s₀) * eta L (clock KB Tb mB s₀)) * exp (-r * clock KB Tb mB s₀) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_discounted_finite H Sr H' H' Sr' Sr' K Ta
    m KB Tb mB y r L Vc s₀ hs hr hK hKB hH.hasDerivWithinAt hH.hasDerivWithinAt
    hS.hasDerivWithinAt hS.hasDerivWithinAt
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, indL_off K Ta m s₀ hkc, (ind_kink KB Tb mB s₀ hkB).1, (ind_kink KB Tb mB s₀ hkB).2,
    etaR_off L _ hL]
  ring

/-- **Coincident cyber and benefit kinks, discounted speed-set, finite horizon.** -/
theorem p16_kink_coincident_discounted_finite (H Sr : ℝ → ℝ)
    (H' Sr' K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hs : 0 < s₀) (hr : 0 < r) (hK : 0 ≤ K) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ = (1 - m) * Ta) (hkB : KB / s₀ = (1 - mB) * Tb)
    (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * H s₀ * (K / s₀)) * exp (-r * clock K Ta m s₀)
        - y * (KB / s₀) * eta L (clock KB Tb mB s₀) * exp (-r * clock KB Tb mB s₀) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_discounted_finite H Sr H' H' Sr' Sr' K Ta
    m KB Tb mB y r L Vc s₀ hs hr hK hKB hH.hasDerivWithinAt hH.hasDerivWithinAt
    hS.hasDerivWithinAt hS.hasDerivWithinAt
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, (ind_kink K Ta m s₀ hkc).1, (ind_kink K Ta m s₀ hkc).2, (ind_kink KB Tb mB s₀ hkB).1,
    (ind_kink KB Tb mB s₀ hkB).2, etaR_off L _ hL]
  ring

/-- **Cyber kink coinciding with horizon activation, discounted speed-set** (Sol 5):
`−V_cHτe^{−rT} + yqe^{−rL}`. -/
theorem p16_kink_cyber_activation_discounted (H Sr : ℝ → ℝ)
    (H' Sr' K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hs : 0 < s₀) (hr : 0 < r) (hK : 0 ≤ K) (hKB : 0 ≤ KB) (hH : HasDerivAt H H' s₀)
    (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ = (1 - m) * Ta) (hcap : (1 - mB) * Tb < KB / s₀)
    (hL : clock KB Tb mB s₀ = L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * H s₀ * (K / s₀)) * exp (-r * clock K Ta m s₀)
        + y * (KB / s₀) * exp (-r * L) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_discounted_finite H Sr H' H' Sr' Sr' K Ta
    m KB Tb mB y r L Vc s₀ hs hr hK hKB hH.hasDerivWithinAt hH.hasDerivWithinAt
    hS.hasDerivWithinAt hS.hasDerivWithinAt
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, hL, (ind_kink K Ta m s₀ hkc).1, (ind_kink K Ta m s₀ hkc).2,
    indL_off KB Tb mB s₀ hcap.ne', (eta_at L).1, (eta_at L).2,
    show ind KB Tb mB s₀ = 1 by simp [ind, hcap]]
  ring

/-- **Cyber kink, discounted level-set, finite horizon** (Opus 3): `−V_cτh(K)e^{−rT}`. -/
theorem p16_kink_cyber_levelset_discounted_finite (h Sr : ℝ → ℝ)
    (Sr' K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hr : 0 < r) (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ = (1 - m) * Ta)
    (hkB : KB / s₀ ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * (K / s₀) * h K) * exp (-r * clock K Ta m s₀) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_discounted_levelset_finite h Sr Sr' Sr' K
    Ta m KB Tb mB y r L Vc s₀ hcont hs hK hKB hm hTa hr hS.hasDerivWithinAt hS.hasDerivWithinAt
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, (ind_kink K Ta m s₀ hkc).1, (ind_kink K Ta m s₀ hkc).2, indL_off KB Tb mB s₀ hkB,
    etaR_off L _ hL]
  ring

/-- **Benefit kink, discounted level-set, finite horizon** (Opus 3): `−yqη_Le^{−rt_B}`. -/
theorem p16_kink_benefit_levelset_discounted_finite (h Sr : ℝ → ℝ)
    (Sr' K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hr : 0 < r) (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ ≠ (1 - m) * Ta)
    (hkB : KB / s₀ = (1 - mB) * Tb) (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl)
        = -(y * (KB / s₀) * eta L (clock KB Tb mB s₀)) * exp (-r * clock KB Tb mB s₀) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_discounted_levelset_finite h Sr Sr' Sr' K
    Ta m KB Tb mB y r L Vc s₀ hcont hs hK hKB hm hTa hr hS.hasDerivWithinAt hS.hasDerivWithinAt
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, indL_off K Ta m s₀ hkc, (ind_kink KB Tb mB s₀ hkB).1, (ind_kink KB Tb mB s₀ hkB).2,
    etaR_off L _ hL]
  ring

/-- **Coincident kinks, discounted level-set, perpetual benefit** (Opus 3):
`−V_cτh(K)e^{−rT} − yqe^{−rt_B}`. -/
theorem p16_kink_coincident_levelset_discounted (h Sr : ℝ → ℝ) (Sr' K Ta m KB Tb mB y r Vc s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hr : 0 < r) (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ = (1 - m) * Ta)
    (hkB : KB / s₀ = (1 - mB) * Tb) :
    ∃ dl dr, HasDerivWithinAt (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => Wrlev h K Ta m KB Tb mB y r Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * (K / s₀) * h K) * exp (-r * clock K Ta m s₀)
        - y * (KB / s₀) * exp (-r * clock KB Tb mB s₀) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_discounted_levelset h Sr Sr' Sr' K Ta m
    KB Tb mB y r Vc s₀ hcont hs hK hKB hm hTa hr hS.hasDerivWithinAt hS.hasDerivWithinAt
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, (ind_kink K Ta m s₀ hkc).1, (ind_kink K Ta m s₀ hkc).2, (ind_kink KB Tb mB s₀ hkB).1,
    (ind_kink KB Tb mB s₀ hkB).2]
  ring

/-- **Coincident kinks, discounted level-set, finite horizon.** -/
theorem p16_kink_coincident_levelset_discounted_finite (h Sr : ℝ → ℝ)
    (Sr' K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hcont : Continuous h) (hs : 0 < s₀) (hK : 0 < K) (hKB : 0 ≤ KB) (hm : 0 ≤ m) (hTa : 0 ≤ Ta)
    (hr : 0 < r) (hS : HasDerivAt Sr Sr' s₀) (hkc : K / s₀ = (1 - m) * Ta)
    (hkB : KB / s₀ = (1 - mB) * Tb) (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrLlev h K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * (K / s₀) * h K) * exp (-r * clock K Ta m s₀)
        - y * (KB / s₀) * eta L (clock KB Tb mB s₀) * exp (-r * clock KB Tb mB s₀) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_discounted_levelset_finite h Sr Sr' Sr' K
    Ta m KB Tb mB y r L Vc s₀ hcont hs hK hKB hm hTa hr hS.hasDerivWithinAt hS.hasDerivWithinAt
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, (ind_kink K Ta m s₀ hkc).1, (ind_kink K Ta m s₀ hkc).2, (ind_kink KB Tb mB s₀ hkB).1,
    (ind_kink KB Tb mB s₀ hkB).2, etaR_off L _ hL]
  ring

/-- **A kink in `H` alone, undiscounted** (Sol 6, line 1058 "where there is one, its one-sided
derivatives enter too"): off clock and horizon kinks, the change is `−V_cTs₀ΔH′`. -/
theorem p16_kink_primitive_speedset (H : ℝ → ℝ) (Hl Hr K Ta m KB Tb mB y L Vc S s₀ : ℝ)
    (hs : 0 < s₀) (hK : 0 ≤ K) (hKB : 0 ≤ KB)
    (hHl : HasDerivWithinAt H Hl (Iic s₀) s₀) (hHr : HasDerivWithinAt H Hr (Ici s₀) s₀)
    (hkc : K / s₀ ≠ (1 - m) * Ta) (hkB : KB / s₀ ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * clock K Ta m s₀ * (s₀ * (Hr - Hl))) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_speedset H Hl Hr K Ta m KB Tb mB y L Vc
    S s₀ hs hK hKB hHl hHr
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, indL_off K Ta m s₀ hkc, indL_off KB Tb mB s₀ hkB, etaR_off L _ hL]
  ring

/-- **A kink in `H` or `S_r`, discounted, finite horizon** (Sol 6): off clock and horizon kinks,
the change is `−V_cA_r(T)s₀ΔH′ − V_cs₀ΔS_r′`. -/
theorem p16_kink_primitive_discounted (H Sr : ℝ → ℝ) (Hl Hr Sl Srr K Ta m KB Tb mB y r L Vc s₀ : ℝ)
    (hs : 0 < s₀) (hr : 0 < r) (hK : 0 ≤ K) (hKB : 0 ≤ KB)
    (hHl : HasDerivWithinAt H Hl (Iic s₀) s₀) (hHr : HasDerivWithinAt H Hr (Ici s₀) s₀)
    (hSl : HasDerivWithinAt Sr Sl (Iic s₀) s₀) (hSr : HasDerivWithinAt Sr Srr (Ici s₀) s₀)
    (hkc : K / s₀ ≠ (1 - m) * Ta) (hkB : KB / s₀ ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s₀ ≠ L) :
    ∃ dl dr, HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dl (Iic s₀) s₀ ∧
      HasDerivWithinAt (fun x => WrL H K Ta m KB Tb mB y r L Vc Sr x) dr (Ici s₀) s₀ ∧
      s₀ * (dr - dl) = -(Vc * Ar r (clock K Ta m s₀) * (s₀ * (Hr - Hl)))
        - Vc * (s₀ * (Srr - Sl)) := by
  obtain ⟨dl, dr, h1, h2, -, -, hch⟩ := p16_kink_general_discounted_finite H Sr Hl Hr Sl Srr K Ta
    m KB Tb mB y r L Vc s₀ hs hr hK hKB hHl hHr hSl hSr
  refine ⟨dl, dr, h1, h2, ?_⟩
  rw [hch, indL_off K Ta m s₀ hkc, indL_off KB Tb mB s₀ hkB, etaR_off L _ hL]
  ring

/-! ## Fix round 1: further certificates -/

/-- **`h̄_{1,D} = (13e^{−3} − 1)/3 < 0`** for `h(c) = c`, `K = 3`, `s = 1` (Opus 4): the
derivative-weighted level average "need not be nonnegative" (line 1331). -/
theorem p16_hbarRD_neg :
    hbarRD (fun c => c) 3 1 1 = (13 * exp (-3) - 1) / 3 ∧ hbarRD (fun c => c) 3 1 1 < 0 := by
  have he : hbarRD (fun c => c) 3 1 1 = (13 * exp (-3) - 1) / 3 := by
    simp only [hbarRD]
    rw [integral_exp_lin_quad]
  refine ⟨he, ?_⟩
  rw [he]
  have he1 := Real.exp_one_gt_d9
  have h3 : exp 3 = exp 1 ^ 3 := by rw [← exp_nat_mul]; norm_num
  have h13 : 13 < exp 3 := by
    have := pow_lt_pow_left₀ he1 (by norm_num) (by norm_num : (3:ℕ) ≠ 0)
    rw [h3]; norm_num at this; linarith
  have hpos : 0 < exp 3 := exp_pos 3
  have h' : 13 * exp (-3) < 1 := by
    rw [exp_neg, mul_inv_lt_iff₀ hpos]; linarith
  exact div_neg_of_neg_of_pos (by linarith) (by norm_num)

/-- **"A step mass that is constant undiscounted need not be constant discounted"** (line 1325;
Opus 8): with capability-set dates `t_j = k_j/s`, the undiscounted mass `Σ_j S_j` does not depend
on speed, but the discounted `S_r` has a nonzero speed derivative when `r > 0` and some positive
mass has a positive distance. -/
theorem p16_step_mass_not_constant_discounted {n : ℕ} (Sj kj : Fin n → ℝ) (r s : ℝ)
    (hs : 0 < s) (hS : ∀ j, 0 ≤ Sj j) (hk : ∀ j, 0 ≤ kj j) (hr : 0 < r)
    (hex : ∃ j, 0 < Sj j ∧ 0 < kj j) :
    (∀ x, SrD Sj (fun j x => kj j / x) 0 x = ∑ j, Sj j) ∧
    deriv (fun x => SrD Sj (fun j x => kj j / x) r x) s ≠ 0 := by
  obtain ⟨hd, -, hpos⟩ := p16_dated_steps_capability Sj kj r s hs hS hk hr.le
  refine ⟨fun x => by simp [SrD], ?_⟩
  rw [hd.deriv]
  exact (div_pos (hpos hr hex) hs).ne'

/-- **"It is not obtained by substituting `H = h(K)` into the speed-set model"** (line 1025;
Opus 8): the level-set loss exceeds the substituted speed-set loss by `τ(h̄ − h(K))`, so they
differ whenever `h̄ ≠ h(K)`, which happens (e.g. `h(c) = c`, `K = 1`: `h̄ = 1/2`). -/
theorem p16_levelset_not_substitution (h : ℝ → ℝ) (K Ta m S s : ℝ) (hcont : Continuous h)
    (hs : 0 < s) (hK : 0 < K) (hm : 0 ≤ m) (hTa : 0 ≤ Ta) :
    Clev h K Ta m S s - Cc (fun _ => h K) K Ta m S s = (K / s) * (hbar h K - h K) ∧
    (hbar h K ≠ h K → Clev h K Ta m S s ≠ Cc (fun _ => h K) K Ta m S s) ∧
    hbar (fun c : ℝ => c) 1 = 1 / 2 := by
  have e : Clev h K Ta m S s - Cc (fun _ => h K) K Ta m S s = (K / s) * (hbar h K - h K) := by
    rw [Clev_eq h K Ta m S s hcont hs hK hm hTa]; simp only [Cc]; ring
  refine ⟨e, fun hne heq => ?_, by norm_num [hbar, integral_id]⟩
  have h0 : (K / s) * (hbar h K - h K) = 0 := by rw [← e, heq, sub_self]
  rcases mul_eq_zero.mp h0 with h1 | h1
  · exact (div_pos hK hs).ne' h1
  · exact hne (sub_eq_zero.mp h1)

/-- **"Below the cyber kink, benefits widen the range in which speed helps"** (§4.7 line 203;
Sol 7), on the defined balance: at any speed off the clock and horizon kinks, adding the benefit
raises `sW_L′` by exactly `yqχ_Bη_L ≥ 0`, so every speed at which acceleration helps without the
benefit (`y = 0`) still has it help with the benefit. -/
theorem p16_benefits_widen_range_balance (H : ℝ → ℝ) (H' K Ta m KB Tb mB y L Vc S s : ℝ)
    (hs : 0 < s) (hH : HasDerivAt H H' s) (hHpos : 0 < H s) (hy : 0 ≤ y) (hKB : 0 ≤ KB)
    (hkc : K / s ≠ (1 - m) * Ta) (hkB : KB / s ≠ (1 - mB) * Tb) (hL : clock KB Tb mB s ≠ L) :
    s * deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s
        = s * deriv (fun x => WL H K Ta m KB Tb mB 0 L Vc S x) s
          + y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) ∧
    (0 < deriv (fun x => WL H K Ta m KB Tb mB 0 L Vc S x) s →
      0 < deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s) := by
  have e : s * deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s
      = s * deriv (fun x => WL H K Ta m KB Tb mB 0 L Vc S x) s
        + y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) := by
    rw [(p16_i_speedset_hasDerivAt H H' K Ta m KB Tb mB y L Vc S s hs hH hHpos hkc hkB hL).deriv,
      (p16_i_speedset_hasDerivAt H H' K Ta m KB Tb mB 0 L Vc S s hs hH hHpos hkc hkB hL).deriv]
    field_simp; ring
  refine ⟨e, fun h0 => ?_⟩
  have hi : 0 ≤ ind KB Tb mB s := by unfold ind; split_ifs <;> norm_num
  have he : 0 ≤ eta L (clock KB Tb mB s) := by unfold eta; split_ifs <;> norm_num
  have hX : 0 ≤ y * (KB / s) * ind KB Tb mB s * eta L (clock KB Tb mB s) := by positivity
  have : 0 < s * deriv (fun x => WL H K Ta m KB Tb mB y L Vc S x) s := by
    rw [e]; nlinarith [mul_pos hs h0]
  exact pos_of_mul_pos_right this hs.le

/-- **Strict widening occurs** (Sol 7): in the `H = s²` instance below the cyber kink, at
`s = 1/2`, acceleration lowers the balance without the benefit (`W′ = −1`) and raises it with the
benefit (`W′ = 15`). -/
theorem p16_benefits_widen_strict_instance :
    deriv (fun x => WL (fun x => x ^ 2) 1 1 0 4 1 0 0 10 1 0 x) (1 / 2) = -1 ∧
    deriv Wsq (1 / 2) = 15 := by
  have hs : (0:ℝ) < 1 / 2 := by norm_num
  have hH : HasDerivAt (fun x : ℝ => x ^ 2) (2 * (1 / 2)) (1 / 2) := ex_Hsq.2.2.2.2
  have hkc : (1:ℝ) / (1 / 2) ≠ (1 - 0) * 1 := by norm_num
  have hkB : (4:ℝ) / (1 / 2) ≠ (1 - 0) * 1 := by norm_num
  have hL : clock 4 1 0 (1 / 2) ≠ 10 := by rw [clock_cap 4 1 0 _ (by norm_num)]; norm_num
  have hW0 := p16_i_speedset_hasDerivAt (fun x => x ^ 2) (2 * (1 / 2)) 1 1 0 4 1 0 0 10 1 0
    (1 / 2) hs hH (by norm_num) hkc hkB hL
  refine ⟨?_, ex_Hsq.2.2.2.1.deriv⟩
  rw [hW0.deriv]
  simp only [ind, eta, elast, clock]; norm_num

/-- **"The candidate is a global maximum if it also beats the other candidates"** (line 1349;
Sol 8), generic form: if a continuous `f` on `[a, b]` has all its maximizers in a candidate set
`C`, a candidate that is at least as high as every candidate in `[a, b]` maximizes `f`. -/
theorem p16_candidate_comparison (f : ℝ → ℝ) (a b x₀ : ℝ) (C : Set ℝ) (hab : a ≤ b)
    (hc : ContinuousOn f (Icc a b))
    (hcand : ∀ x ∈ Icc a b, IsMaxOn f (Icc a b) x → x ∈ C)
    (hbeat : ∀ c ∈ C ∩ Icc a b, f c ≤ f x₀) : IsMaxOn f (Icc a b) x₀ := by
  obtain ⟨x, hx, hmax⟩ := isCompact_Icc.exists_isMaxOn (nonempty_Icc.mpr hab) hc
  intro z hz
  exact le_trans (hmax hz) (hbeat x ⟨hcand x hx hmax, hx⟩)

/-- **Candidate comparison for the speed-set balance** (Sol 8): with `H` continuous on the
interval and differentiable off the kinks, a speed that beats every endpoint, clock or horizon
kink and smooth stationary point in `[a, b]` is a global maximizer. -/
theorem p16_candidate_comparison_speedset (H H'f : ℝ → ℝ) (K Ta m KB Tb mB y L Vc S a b x₀ : ℝ)
    (ha : 0 < a) (hab : a ≤ b) (hHc : ∀ z ∈ Icc a b, ContinuousAt H z)
    (hH : ∀ z ∈ Ioo a b, K / z ≠ (1 - m) * Ta → KB / z ≠ (1 - mB) * Tb → clock KB Tb mB z ≠ L →
      HasDerivAt H (H'f z) z)
    (hbeat : ∀ c ∈ Icc a b, (c = a ∨ c = b ∨ K / c = (1 - m) * Ta ∨ KB / c = (1 - mB) * Tb ∨
        clock KB Tb mB c = L ∨
        ∃ d, HasDerivAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) d c ∧ d = 0) →
      WL H K Ta m KB Tb mB y L Vc S c ≤ WL H K Ta m KB Tb mB y L Vc S x₀) :
    IsMaxOn (fun x => WL H K Ta m KB Tb mB y L Vc S x) (Icc a b) x₀ := by
  refine p16_candidate_comparison _ a b x₀ {c | c = a ∨ c = b ∨ K / c = (1 - m) * Ta ∨
      KB / c = (1 - mB) * Tb ∨ clock KB Tb mB c = L ∨
      ∃ d, HasDerivAt (fun x => WL H K Ta m KB Tb mB y L Vc S x) d c ∧ d = 0} hab
    (fun z hz => (WL_continuousAt H K Ta m KB Tb mB y L Vc S z (lt_of_lt_of_le ha hz.1)
      (hHc z hz)).continuousWithinAt)
    (fun x hx hmax => p16_iii_candidates_speedset H H'f K Ta m KB Tb mB y L Vc S a b x ha hx hH
      (Or.inl hmax))
    (fun c hc => hbeat c hc.2 hc.1)


/-! ## Axiom audit -/

#print axioms clock_ge_cap
#print axioms clock_ge_own
#print axioms clock_pos
#print axioms clock_cap
#print axioms clock_adopt
#print axioms clock_antitone
#print axioms clock_continuousAt
#print axioms hasDerivAt_div_self
#print axioms clock_hasDerivAt
#print axioms clock_hasDerivWithinAt_Iic_kink
#print axioms clock_hasDerivWithinAt_Ici_kink
#print axioms ind_sequential
#print axioms BL_eq_integral
#print axioms BL_comp_within_before
#print axioms BL_comp_within_after
#print axioms BL_comp_hasDerivAt
#print axioms p16_BL_hasDerivAt
#print axioms WL_hasDerivWithinAt_of
#print axioms p16_i_speedset_hasDerivAt
#print axioms ramp_integral
#print axioms path_integral_eq
#print axioms Clev_eq
#print axioms Clev_hasDerivWithinAt_of
#print axioms p16_C2
#print axioms p16_i_levelset_hasDerivAt
#print axioms sign_div_pos
#print axioms p16_i_speedset_sign
#print axioms p16_i_levelset_sign
#print axioms p16_i_speedset_above_kink_test
#print axioms p16_i_levelset_above_kink_test
#print axioms p16_i_levelset_above_kink_test_speedfree
#print axioms p16_i_speedset_below_kink_test
#print axioms p16_i_speedset_below_kink_no_benefit
#print axioms BL_beyond_benefit_kink
#print axioms p16_i_speedset_beyond_benefit_kink
#print axioms p16_i_levelset_beyond_benefit_kink
#print axioms p16_cell_speedset_cap_cap
#print axioms p16_cell_speedset_adopt_cap
#print axioms p16_cell_speedset_cap_adopt
#print axioms p16_cell_speedset_adopt_adopt
#print axioms p16_cell_speedset_adopt_adopt_neg
#print axioms p16_cell_levelset_cap_cap
#print axioms p16_cell_levelset_adopt_cap
#print axioms p16_cell_levelset_cap_adopt
#print axioms p16_cell_levelset_adopt_adopt
#print axioms p16_cell_levelset_cap_adopt_pos
#print axioms p16_cell_levelset_adopt_adopt_sign
#print axioms hbar_lt_of_monotoneOn_nonconst
#print axioms hbar_eq_endpoint_counterexample
#print axioms kink_iff
#print axioms clock_below_kink
#print axioms clock_above_kink
#print axioms clock_sequential
#print axioms ind_eq_step
#print axioms p16_branch_order_finite
#print axioms p16_branch_order_sequential
#print axioms p16_horizon_none
#print axioms p16_horizon_activation
#print axioms p16_horizon_kL_on_cap_branch
#print axioms BL_activation_left
#print axioms BL_activation_right
#print axioms BL_within_offhorizon
#print axioms p16_kink_cyber_speedset
#print axioms p16_kink_cyber_levelset
#print axioms p16_kink_benefit_speedset
#print axioms p16_kink_benefit_levelset
#print axioms p16_kink_coincident_speedset
#print axioms p16_kink_activation_speedset
#print axioms p16_kink_activation_levelset
#print axioms WL_continuousAt
#print axioms WLlev_continuousAt
#print axioms p16_iii_exists_speedset
#print axioms p16_iii_exists_levelset
#print axioms fermat_Icc
#print axioms p16_iii_candidates_speedset
#print axioms p16_iii_candidates_levelset
#print axioms right_cmp_of_hasDerivWithinAt
#print axioms left_cmp_of_hasDerivWithinAt
#print axioms p16_iii_kink_max
#print axioms p16_iii_kink_min
#print axioms p16_suff1_interior_max
#print axioms strict_localmax_of_deriv_sign
#print axioms p16_suff2_second_deriv
#print axioms p16_suff2_equality_fails
#print axioms strict_incr_finite_exc
#print axioms p16_suff3_unique_global_max
#print axioms ex_unfold
#print axioms ex_piece1
#print axioms ex_piece2
#print axioms ex_piece3
#print axioms ex_values
#print axioms ex_kinks_and_horizon
#print axioms ex_unique_global_max
#print axioms ex_deriv_piece1
#print axioms ex_deriv_piece2
#print axioms ex_deriv_piece3
#print axioms ex_one_sided
#print axioms ex_optimum_balance
#print axioms ex_second_deriv
#print axioms ex_s5_counterexample
#print axioms ex_Hsq
#print axioms ub_closed
#print axioms p16_existence_needs_upper_bound
#print axioms p16_existence_needs_lower_bound
#print axioms p16_optimum_above_kink_possible_not_guaranteed
#print axioms p16_capability_share
#print axioms p16_test_via_share
#print axioms p16_share_parallel
#print axioms p16_share_0806
#print axioms p16_P4_objective
#print axioms p16_near_loss_rises_balance_improves
#print axioms p16_tB_mono_Tb
#print axioms p16_BL_level_strict
#print axioms p16_dBL_dTb_cap
#print axioms p16_dBL_dTb_adopt
#print axioms p16_dBL_dTb_parallel
#print axioms p16_BL_marginal_free_of_Tb
#print axioms hasDerivAt_neg_exp_div
#print axioms continuous_exp_neg_mul
#print axioms Ar_eq
#print axioms Ar_zero
#print axioms Ar_hasDerivAt
#print axioms Ar_pos
#print axioms Br_eq
#print axioms BrL_eq
#print axioms Br_comp_within
#print axioms BrL_comp_within_before
#print axioms BrL_comp_within_after
#print axioms BrL_within_offhorizon
#print axioms Ccr_hasDerivWithinAt_of
#print axioms p16_ii_hasDerivAt
#print axioms p16_ii_finite_hasDerivAt
#print axioms p16_ii_threshold
#print axioms p16_ii_above_kink_test
#print axioms p16_ii_above_kink_test_finite
#print axioms p16_ii_reduces_to_P4
#print axioms p16_ii_parallel_is_P4
#print axioms p16_ii_above_kink_no_benefit_neg
#print axioms p16_ii_discount_lowers_credit
#print axioms p16_dated_steps_hasDerivAt
#print axioms p16_dated_steps_fixed
#print axioms p16_dated_steps_capability
#print axioms p16_dated_steps_subtract
#print axioms Br_speed_deriv_cap
#print axioms p16_dBr'_dTb
#print axioms p16_dBr'_dTb_sign
#print axioms p16_kink_cyber_discounted
#print axioms p16_kink_benefit_discounted
#print axioms BrL_activation_left
#print axioms BrL_activation_right
#print axioms p16_kink_activation_discounted
#print axioms Clevr_eq
#print axioms Gr_hasDerivAt
#print axioms ramp_disc_hasDerivAt
#print axioms Clevr_hasDerivWithinAt_of
#print axioms p16_C3_hasDerivAt
#print axioms p16_C3_finite_hasDerivAt
#print axioms p16_C3_test
#print axioms p16_kink_cyber_levelset_discounted
#print axioms Ar_tendsto_zero
#print axioms exp_tendsto_zero
#print axioms hbarRD_tendsto_zero
#print axioms p16_limit_speedset
#print axioms p16_limit_levelset
#print axioms p16_limit_BrL
#print axioms p16_limit_Br_diverges
#print axioms p16_limit_Br_deriv
#print axioms p16_ranking_plus_to_minus
#print axioms p16_ranking_minus_to_plus
#print axioms integral_exp_lin_quad
#print axioms p16_levelset_sign_flip
#print axioms p16_power_closed
#print axioms p16_power_hasDerivAt
#print axioms p16_power_sW
#print axioms p16_power_g_strictAnti
#print axioms p16_power_g_zero
#print axioms p16_power_unique_max
#print axioms p16_power_second_deriv
#print axioms p16_power_unique_max_kinks
#print axioms p16_power_branch_empty
#print axioms p16_power_sign_change
#print axioms p16_power_example
#print axioms p16_ii_threshold_perpetual
#print axioms p16_benefits_widen_range
#print axioms p16_ii_truncation_harmless
#print axioms Ar_continuous
#print axioms Br_clock_continuousAt
#print axioms BrL_clock_continuousAt
#print axioms Ccr_continuousWithinAt
#print axioms Clevr_continuousWithinAt
#print axioms p16_iii_exists_discounted
#print axioms p16_iii_candidates_discounted
#print axioms p16_iii_candidates_discounted_levelset
#print axioms p16_iii_candidates_need_smooth_Sr
#print axioms p16_C1
#print axioms p16_kink_coincident_levelset
#print axioms p16_kink_coincident_discounted
#print axioms p16_kink_benefit_levelset_discounted
#print axioms p16_kink_activation_levelset_discounted
#print axioms p16_flat_set_of_maximizers
#print axioms p16_suff3_foc_not_global
#print axioms p16_iii_candidates_perpetual
#print axioms p16_iii_candidates_perpetual_levelset
#print axioms ex_transition_within_10
#print axioms ind_kink
#print axioms indL_off
#print axioms eta_at
#print axioms etaR_off
#print axioms clock_left
#print axioms clock_right
#print axioms BL_left
#print axioms BL_right
#print axioms BrL_left
#print axioms BrL_right
#print axioms Clevr_hasDerivWithinAt_within
#print axioms p16_kink_general_speedset
#print axioms p16_kink_general_levelset
#print axioms p16_kink_general_discounted
#print axioms p16_kink_general_discounted_finite
#print axioms p16_kink_general_discounted_levelset
#print axioms p16_kink_general_discounted_levelset_finite
#print axioms p16_kink_cyber_activation_speedset
#print axioms p16_kink_benefit_at_horizon_speedset
#print axioms p16_kink_benefit_at_horizon_levelset
#print axioms p16_kink_cyber_activation_levelset
#print axioms p16_kink_cyber_discounted_finite
#print axioms p16_kink_benefit_discounted_finite
#print axioms p16_kink_coincident_discounted_finite
#print axioms p16_kink_cyber_activation_discounted
#print axioms p16_kink_cyber_levelset_discounted_finite
#print axioms p16_kink_benefit_levelset_discounted_finite
#print axioms p16_kink_coincident_levelset_discounted
#print axioms p16_kink_coincident_levelset_discounted_finite
#print axioms p16_kink_primitive_speedset
#print axioms p16_kink_primitive_discounted
#print axioms p16_hbarRD_neg
#print axioms p16_step_mass_not_constant_discounted
#print axioms p16_levelset_not_substitution
#print axioms p16_benefits_widen_range_balance
#print axioms p16_benefits_widen_strict_instance
#print axioms p16_candidate_comparison
#print axioms p16_candidate_comparison_speedset

end RTTRBenefits
