import Mathlib

/-!
# RTTR v8, seat L1b: the other timings, the level-set hazard, many populations, falling far risk

Formalizes the §4.3 timing claims of "Running Through the Rain" (PAPER-DRAFT-v8, lines 100–129,
including the timing × hazard table) and the A.7 entries at lines 1148, 1149, 1152, 1155, 1159.

## Modelling choices — how each paper object is represented

1. **Loss index.** `Rc H T S s = H s * T s + S` (A.2.2 defines the index this way, so the closed
   form *is* the definition).  `T` is the transition length as a function of speed:
   * parallel `Tpar K Ta s = max (K/s) Ta` (A.2.4),
   * sequential `Tseq K Ta s = K/s + Ta` (A.7, line 1148),
   * mixed `Tmix K Ta m s = max (K/s) ((1 − m) Ta) + m Ta` (A.7, line 1155).
   `Tpar = Tmix · · 0` and `Tmix · · 1 = Tseq` on `s > 0` are proved (`tmix_zero`, `tmix_one`),
   so the parallel cells of the table are corollaries of the mixed ones.
2. **Elasticity.** `elast H s = s * deriv H s / H s` — tied to `H` itself, not a free number.
   Derivative claims are `HasDerivAt` of the defined `Rc`, at the point, on the open branch.
   A4 (`H` positive, differentiable, `H′ > 0`) is assumed only at the point where it is used,
   and only the parts each claim needs (`H′ > 0` is needed only above a kink).
3. **"Sign of X" in the table** is `SignType.sign (derivative) = SignType.sign X`.
4. **Level-set hazard.** The cumulative hazard is **defined as an integral**:
   `CumLev h K S T s = ∫_0^{T s} h(min(s t, K)) dt + S`, i.e. the path `c(t) = min(st, K)`, the
   hazard `h(c(t))`, which is automatically `h(K)` on the adoption tail `t ≥ K/s`, plus the step
   term.  The closed form `τ h̄ + (T − τ) h(K) + S` with `τ = K/s`, `h̄ = K⁻¹∫_0^K h` is a theorem
   (`cumLev_closed_form`).  Regularity: the paper (line 1025, describing the A.7 calculation)
   takes `h` continuous and nonnegative; the proofs use **only** `IntervalIntegrable h volume 0 K`,
   which continuity on the compact `[0, K]` implies, plus `h̄ > 0` where the sign "negative" is
   claimed and strict monotonicity for `h̄ < h(K)`.  The zero hazard is continuous and
   nonnegative, so it satisfies the paper's conditions; it refutes every unconditional
   "always negative / always helps" clause (`lev_*_zero_hazard_counterexample`).
5. **Separate populations.** `Rpop J w Taj H K S s = Σ_{j∈J} w_j H(s) max(K/s, T_{a,j}) + S` over
   a `Finset`.  "Away from every kink" is `∀ j ∈ J, K/s ≠ T_{a,j}`.  The cap set is
   `J.filter (T_{a,j} < K/s)`, the adoption set its complement.  The iff holds for any real
   weights; nonnegativity is not needed.
6. **Far risk falling.** The near loss is the model's `Rc H (Tpar K Ta) S`; the far cumulative
   hazard `C_A` is a primitive of P4 (the paper never defines it), so it is an arbitrary function
   with a derivative `dA < 0` at `s`.
-/

open MeasureTheory intervalIntegral Set Filter Topology

namespace RTTR.Timings

/-! ## Objects -/

/-- The elasticity `ε_H = sH′/H`, computed from `H`. -/
noncomputable def elast (H : ℝ → ℝ) (s : ℝ) : ℝ := s * deriv H s / H s

/-- Parallel timing, `T = max(K/s, T_a)`. -/
noncomputable def Tpar (K Ta : ℝ) (s : ℝ) : ℝ := max (K / s) Ta

/-- Sequential timing, `T = K/s + T_a`. -/
noncomputable def Tseq (K Ta : ℝ) (s : ℝ) : ℝ := K / s + Ta

/-- Mixed timing, `T = max(K/s, (1 − m)T_a) + mT_a`. -/
noncomputable def Tmix (K Ta m : ℝ) (s : ℝ) : ℝ := max (K / s) ((1 - m) * Ta) + m * Ta

/-- The loss index `R_c = H·T + S` (A.2.2). -/
noncomputable def Rc (H : ℝ → ℝ) (T : ℝ → ℝ) (S : ℝ) (s : ℝ) : ℝ := H s * T s + S

/-- The mixed-timing kink `K/((1 − m)T_a)`. -/
noncomputable def kinkMix (K Ta m : ℝ) : ℝ := K / ((1 - m) * Ta)

theorem tmix_zero (K Ta : ℝ) : Tmix K Ta 0 = Tpar K Ta := by
  funext s; simp [Tmix, Tpar]

/-- **A.7 line 1155: "m = 1 is the sequential case above".** -/
theorem tmix_one (K Ta s : ℝ) (hK : 0 ≤ K) (hs : 0 < s) : Tmix K Ta 1 s = Tseq K Ta s := by
  have : 0 ≤ K / s := div_nonneg hK hs.le
  simp [Tmix, Tseq, max_eq_left this]

/-! ## Calculus helpers -/

theorem hasDerivAt_K_div (K s : ℝ) (hs : s ≠ 0) :
    HasDerivAt (fun x : ℝ => K / x) (-(K / s ^ 2)) s := by
  have := (hasDerivAt_inv hs).const_mul K
  convert this using 1
  · funext x; rw [div_eq_mul_inv]
  · ring

/-- On a branch where capability binds, `T = K/x + c` with `c` constant. -/
theorem capBranch_hasDerivAt (H : ℝ → ℝ) (K c S s : ℝ) (hs : 0 < s)
    (hH : DifferentiableAt ℝ H s) :
    HasDerivAt (fun x => H x * (K / x + c) + S) (deriv H s * (K / s + c) - H s * K / s ^ 2) s := by
  have h1 : HasDerivAt (fun x : ℝ => K / x + c) (-(K / s ^ 2)) s :=
    (hasDerivAt_K_div K s hs.ne').add_const c
  have := (hH.hasDerivAt.mul h1).add_const S
  convert this using 1
  ring

/-- The capability-branch derivative factors as a positive number times `ε_H − (K/s)/(K/s + c)`. -/
theorem capBranch_factor (H : ℝ → ℝ) (K c s : ℝ) (hs : 0 < s) (hH0 : 0 < H s) (hK : 0 < K)
    (hc : 0 ≤ c) :
    deriv H s * (K / s + c) - H s * K / s ^ 2
      = (H s / s * (K / s + c)) * (elast H s - (K / s) / (K / s + c)) := by
  have hKs : 0 < K / s + c := by positivity
  unfold elast
  field_simp

theorem capBranch_factor_pos (H : ℝ → ℝ) (K c s : ℝ) (hs : 0 < s) (hH0 : 0 < H s) (hK : 0 < K)
    (hc : 0 ≤ c) : 0 < H s / s * (K / s + c) := by positivity

theorem sign_of_pos_mul {a x : ℝ} (ha : 0 < a) : SignType.sign (a * x) = SignType.sign x := by
  rw [sign_mul, sign_pos ha, one_mul]

theorem neg_iff_of_pos_mul {a x : ℝ} (ha : 0 < a) : a * x < 0 ↔ x < 0 := by
  constructor
  · intro h; by_contra hx; push Not at hx; nlinarith
  · intro h; nlinarith

/-! ## 1. Sequential timing (A.7 line 1148; §4.3 line 112; table row 3, speed-set column) -/

/-- **Sequential, the derivative.** At every `s > 0`, with no branch condition: this is the
content of "there is no kink" — `R_c` is differentiable at every positive speed. -/
theorem seq_hasDerivAt (H : ℝ → ℝ) (K Ta S s : ℝ) (hs : 0 < s) (hH : DifferentiableAt ℝ H s) :
    HasDerivAt (Rc H (Tseq K Ta) S) (deriv H s * (K / s + Ta) - H s * K / s ^ 2) s :=
  capBranch_hasDerivAt H K Ta S s hs hH

/-- **Sequential, "no kink".** `R_c` is differentiable on all of `(0, ∞)`. -/
theorem seq_no_kink (H : ℝ → ℝ) (K Ta S : ℝ) (hH : ∀ s, 0 < s → DifferentiableAt ℝ H s) :
    ∀ s, 0 < s → DifferentiableAt ℝ (Rc H (Tseq K Ta) S) s :=
  fun s hs => (seq_hasDerivAt H K Ta S s hs (hH s hs)).differentiableAt

/-- **Sequential, table cell: sign of `ε_H − (K/s)/(K/s + T_a)`.** -/
theorem seq_sign (H : ℝ → ℝ) (K Ta s : ℝ) (hs : 0 < s) (hH0 : 0 < H s) (hK : 0 < K)
    (hTa : 0 ≤ Ta) :
    SignType.sign (deriv H s * (K / s + Ta) - H s * K / s ^ 2)
      = SignType.sign (elast H s - (K / s) / (K / s + Ta)) := by
  rw [capBranch_factor H K Ta s hs hH0 hK hTa,
    sign_of_pos_mul (capBranch_factor_pos H K Ta s hs hH0 hK hTa)]

/-- **Sequential, the iff (A.7 line 1148; §4.3 line 112).** A marginal acceleration lowers the
loss index iff `ε_H < (K/s)/(K/s + T_a)`. -/
theorem seq_lowers_iff (H : ℝ → ℝ) (K Ta S s : ℝ) (hs : 0 < s) (hH : DifferentiableAt ℝ H s)
    (hH0 : 0 < H s) (hK : 0 < K) (hTa : 0 ≤ Ta) :
    ∃ d, HasDerivAt (Rc H (Tseq K Ta) S) d s ∧ (d < 0 ↔ elast H s < (K / s) / (K / s + Ta)) := by
  refine ⟨_, seq_hasDerivAt H K Ta S s hs hH, ?_⟩
  rw [capBranch_factor H K Ta s hs hH0 hK hTa,
    neg_iff_of_pos_mul (capBranch_factor_pos H K Ta s hs hH0 hK hTa), sub_neg]

/-- **Sequential, table cell, bundled:** the derivative of the defined `R_c` has the sign of
`ε_H − (K/s)/(K/s + T_a)`. -/
theorem seq_cell_sign (H : ℝ → ℝ) (K Ta S s : ℝ) (hs : 0 < s) (hH : DifferentiableAt ℝ H s)
    (hH0 : 0 < H s) (hK : 0 < K) (hTa : 0 ≤ Ta) :
    ∃ d, HasDerivAt (Rc H (Tseq K Ta) S) d s ∧
      SignType.sign d = SignType.sign (elast H s - (K / s) / (K / s + Ta)) :=
  ⟨_, seq_hasDerivAt H K Ta S s hs hH, seq_sign H K Ta s hs hH0 hK hTa⟩

/-! ## 2. Mixed timing (A.7 line 1155; §4.3 line 116; table row 2) -/

theorem kinkMix_pos (K Ta m : ℝ) (hK : 0 < K) (hTa : 0 < Ta) (hm1 : m < 1) :
    0 < kinkMix K Ta m := by
  unfold kinkMix; have : 0 < 1 - m := by linarith
  positivity

/-- **The kink is at `K/((1 − m)T_a)`: strictly below it capability binds.** -/
theorem mix_below_iff (K Ta m x : ℝ) (hTa : 0 < Ta) (hm1 : m < 1) (hx : 0 < x) :
    x < kinkMix K Ta m ↔ (1 - m) * Ta < K / x := by
  have hp : 0 < (1 - m) * Ta := by have : 0 < 1 - m := by linarith
                                   positivity
  unfold kinkMix
  rw [lt_div_iff₀ hp, lt_div_iff₀ hx, mul_comm]

theorem mix_le_iff (K Ta m x : ℝ) (hTa : 0 < Ta) (hm1 : m < 1) (hx : 0 < x) :
    x ≤ kinkMix K Ta m ↔ (1 - m) * Ta ≤ K / x := by
  have hp : 0 < (1 - m) * Ta := by have : 0 < 1 - m := by linarith
                                   positivity
  unfold kinkMix
  rw [le_div_iff₀ hp, le_div_iff₀ hx, mul_comm]

/-- At the kink itself capability and adoption time coincide, `K/s_m = (1 − m)T_a`. -/
theorem kinkMix_K_div (K Ta m : ℝ) (hK : 0 < K) (hTa : 0 < Ta) (hm1 : m < 1) :
    K / kinkMix K Ta m = (1 - m) * Ta := by
  have hp : (1 - m) * Ta ≠ 0 := by
    have : 0 < 1 - m := by linarith
    positivity
  unfold kinkMix; field_simp

theorem mix_ge (K Ta m x : ℝ) (hK : 0 < K) (hTa : 0 < Ta) (hm1 : m < 1)
    (hx : kinkMix K Ta m ≤ x) : K / x ≤ (1 - m) * Ta := by
  rw [← kinkMix_K_div K Ta m hK hTa hm1]
  exact div_le_div_of_nonneg_left hK.le (kinkMix_pos K Ta m hK hTa hm1) hx

/-- **§6 line 253: only `(1 − m)T_a` sets the kink.** The kink is a function of `K` and the
parallel share `(1 − m)T_a` alone; two (m, T_a) pairs with the same parallel share have the same
kink, whatever their waiting shares `mT_a`. -/
theorem kinkMix_depends_on_parallel_share (K Ta m Ta' m' : ℝ)
    (h : (1 - m) * Ta = (1 - m') * Ta') : kinkMix K Ta m = kinkMix K Ta' m' := by
  unfold kinkMix; rw [h]

/-- **Mixed, below the kink: the derivative.** -/
theorem mix_below_hasDerivAt (H : ℝ → ℝ) (K Ta m S s : ℝ) (hTa : 0 < Ta) (hm1 : m < 1)
    (hs : 0 < s) (hlt : s < kinkMix K Ta m) (hH : DifferentiableAt ℝ H s) :
    HasDerivAt (Rc H (Tmix K Ta m) S) (deriv H s * (K / s + m * Ta) - H s * K / s ^ 2) s := by
  refine (capBranch_hasDerivAt H K (m * Ta) S s hs hH).congr_of_eventuallyEq ?_
  filter_upwards [Ioo_mem_nhds hs hlt] with x hx
  have hb := (mix_below_iff K Ta m x hTa hm1 hx.1).1 hx.2
  simp [Rc, Tmix, max_eq_left hb.le]

/-- **Mixed, below the kink, table cell: sign of `ε_H − (K/s)/(K/s + mT_a)`.** -/
theorem mix_below_sign (H : ℝ → ℝ) (K Ta m s : ℝ) (hs : 0 < s) (hH0 : 0 < H s) (hK : 0 < K)
    (hTa : 0 ≤ Ta) (hm0 : 0 ≤ m) :
    SignType.sign (deriv H s * (K / s + m * Ta) - H s * K / s ^ 2)
      = SignType.sign (elast H s - (K / s) / (K / s + m * Ta)) := by
  have hc : 0 ≤ m * Ta := mul_nonneg hm0 hTa
  rw [capBranch_factor H K _ s hs hH0 hK hc, sign_of_pos_mul (capBranch_factor_pos H K _ s hs hH0 hK hc)]

/-- **Mixed, below the kink, the iff (A.7 line 1155).** For `0 ≤ m < 1` (the table's `0 < m < 1`
is a special case). -/
theorem mix_below_lowers_iff (H : ℝ → ℝ) (K Ta m S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hm0 : 0 ≤ m) (hm1 : m < 1) (hs : 0 < s) (hlt : s < kinkMix K Ta m)
    (hH : DifferentiableAt ℝ H s) (hH0 : 0 < H s) :
    ∃ d, HasDerivAt (Rc H (Tmix K Ta m) S) d s ∧
      (d < 0 ↔ elast H s < (K / s) / (K / s + m * Ta)) := by
  have hc : 0 ≤ m * Ta := mul_nonneg hm0 hTa.le
  refine ⟨_, mix_below_hasDerivAt H K Ta m S s hTa hm1 hs hlt hH, ?_⟩
  rw [capBranch_factor H K _ s hs hH0 hK hc,
    neg_iff_of_pos_mul (capBranch_factor_pos H K _ s hs hH0 hK hc), sub_neg]

/-- **"The share of the transition that capability sets"** (lines 26, 124, 529): below the mixed
kink the threshold `(K/s)/(K/s + mT_a)` is `(K/s)/T(s)`. -/
theorem mix_capability_share (K Ta m s : ℝ) (hTa : 0 < Ta) (hm1 : m < 1) (hs : 0 < s)
    (hlt : s < kinkMix K Ta m) :
    (K / s) / (K / s + m * Ta) = (K / s) / Tmix K Ta m s := by
  have hb := (mix_below_iff K Ta m s hTa hm1 hs).1 hlt
  simp [Tmix, max_eq_left hb.le]

/-- **Mixed, above the kink: the derivative is `H′T_a`, positive under A4.** -/
theorem mix_above_hasDerivAt (H : ℝ → ℝ) (K Ta m S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hm1 : m < 1) (hgt : kinkMix K Ta m < s) (hH : DifferentiableAt ℝ H s) :
    HasDerivAt (Rc H (Tmix K Ta m) S) (deriv H s * Ta) s := by
  have hk0 := kinkMix_pos K Ta m hK hTa hm1
  refine (hH.hasDerivAt.mul_const Ta |>.add_const S).congr_of_eventuallyEq ?_
  filter_upwards [Ioi_mem_nhds hgt] with x hx
  have hx0 : 0 < x := lt_trans hk0 hx
  have hb : K / x ≤ (1 - m) * Ta := by
    by_contra hc; push Not at hc
    exact absurd ((mix_below_iff K Ta m x hTa hm1 hx0).2 hc) (not_lt.mpr hx.le)
  simp only [Rc, Tmix, max_eq_right hb]; ring

theorem mix_above_pos (H : ℝ → ℝ) (Ta s : ℝ) (hTa : 0 < Ta) (hH' : 0 < deriv H s) :
    0 < deriv H s * Ta := mul_pos hH' hTa

/-- **Mixed, below the kink, table cell, bundled:** the derivative of the defined `R_c` has the
sign of `ε_H − (K/s)/(K/s + mT_a)`. -/
theorem mix_below_cell_sign (H : ℝ → ℝ) (K Ta m S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hm0 : 0 ≤ m) (hm1 : m < 1) (hs : 0 < s) (hlt : s < kinkMix K Ta m)
    (hH : DifferentiableAt ℝ H s) (hH0 : 0 < H s) :
    ∃ d, HasDerivAt (Rc H (Tmix K Ta m) S) d s ∧
      SignType.sign d = SignType.sign (elast H s - (K / s) / (K / s + m * Ta)) :=
  ⟨_, mix_below_hasDerivAt H K Ta m S s hTa hm1 hs hlt hH,
    mix_below_sign H K Ta m s hs hH0 hK hTa.le hm0⟩

/-- **Mixed, above the kink, bundled: "as in P1, acceleration only raises it".** The derivative
of the defined `R_c` is `H′T_a`, and it is positive under A4. -/
theorem mix_above_raises (H : ℝ → ℝ) (K Ta m S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hm1 : m < 1) (hgt : kinkMix K Ta m < s) (hH : DifferentiableAt ℝ H s)
    (hH' : 0 < deriv H s) :
    HasDerivAt (Rc H (Tmix K Ta m) S) (deriv H s * Ta) s ∧ 0 < deriv H s * Ta :=
  ⟨mix_above_hasDerivAt H K Ta m S s hK hTa hm1 hgt hH, mul_pos hH' hTa⟩

/-- **Mixed, the kink is a kink.** At `s_m = K/((1 − m)T_a)` the left derivative (on `Iic`) is the
capability-branch value and the right derivative (on `Ici`) is `H′T_a`. -/
theorem mix_kink_left (H : ℝ → ℝ) (K Ta m S : ℝ) (hK : 0 < K) (hTa : 0 < Ta) (hm1 : m < 1)
    (hH : DifferentiableAt ℝ H (kinkMix K Ta m)) :
    HasDerivWithinAt (Rc H (Tmix K Ta m) S)
      (deriv H (kinkMix K Ta m) * (K / kinkMix K Ta m + m * Ta)
        - H (kinkMix K Ta m) * K / kinkMix K Ta m ^ 2) (Iic (kinkMix K Ta m)) (kinkMix K Ta m) := by
  set k := kinkMix K Ta m
  have hk0 : 0 < k := kinkMix_pos K Ta m hK hTa hm1
  have hb : ∀ x, 0 < x → x ≤ k → Rc H (Tmix K Ta m) S x = H x * (K / x + m * Ta) + S := by
    intro x hx hxk
    have := (mix_le_iff K Ta m x hTa hm1 hx).1 hxk
    simp [Rc, Tmix, max_eq_left this]
  refine (capBranch_hasDerivAt H K (m * Ta) S k hk0 hH).hasDerivWithinAt.congr_of_eventuallyEq
    ?_ (hb k hk0 le_rfl)
  filter_upwards [self_mem_nhdsWithin, nhdsWithin_le_nhds (Ioi_mem_nhds hk0)] with x hx1 hx2
  exact hb x hx2 hx1

theorem mix_kink_right (H : ℝ → ℝ) (K Ta m S : ℝ) (hK : 0 < K) (hTa : 0 < Ta) (hm1 : m < 1)
    (hH : DifferentiableAt ℝ H (kinkMix K Ta m)) :
    HasDerivWithinAt (Rc H (Tmix K Ta m) S) (deriv H (kinkMix K Ta m) * Ta)
      (Ici (kinkMix K Ta m)) (kinkMix K Ta m) := by
  set k := kinkMix K Ta m
  have hk0 : 0 < k := kinkMix_pos K Ta m hK hTa hm1
  have hb : ∀ x, k ≤ x → Rc H (Tmix K Ta m) S x = H x * Ta + S := by
    intro x hxk
    have hx : 0 < x := lt_of_lt_of_le hk0 hxk
    have hle : K / x ≤ (1 - m) * Ta := mix_ge K Ta m x hK hTa hm1 hxk
    simp only [Rc, Tmix, max_eq_right hle]; ring
  refine (hH.hasDerivAt.mul_const Ta |>.add_const S).hasDerivWithinAt.congr_of_eventuallyEq
    ?_ (hb k le_rfl)
  filter_upwards [self_mem_nhdsWithin] with x hx
  exact hb x hx

/-- **Mixed, not differentiable at the kink.** The one-sided derivatives differ by
`H(s_m)K/s_m² > 0`, so `R_c` has a genuine kink at `K/((1 − m)T_a)`. -/
theorem mix_kink_not_differentiable (H : ℝ → ℝ) (K Ta m S : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hm1 : m < 1) (hH : DifferentiableAt ℝ H (kinkMix K Ta m)) (hH0 : 0 < H (kinkMix K Ta m)) :
    ¬ DifferentiableAt ℝ (Rc H (Tmix K Ta m) S) (kinkMix K Ta m) := by
  intro hd
  set k := kinkMix K Ta m with hkdef
  have hk0 : 0 < k := kinkMix_pos K Ta m hK hTa hm1
  have hKk : K / k = (1 - m) * Ta := kinkMix_K_div K Ta m hK hTa hm1
  have eL := (uniqueDiffWithinAt_Iic k).eq_deriv _ hd.hasDerivAt.hasDerivWithinAt
    (mix_kink_left H K Ta m S hK hTa hm1 hH)
  have eR := (uniqueDiffWithinAt_Ici k).eq_deriv _ hd.hasDerivAt.hasDerivWithinAt
    (mix_kink_right H K Ta m S hK hTa hm1 hH)
  rw [hKk] at eL
  have : H k * K / k ^ 2 = 0 := by linarith
  have hpos : 0 < H k * K / k ^ 2 := by positivity
  linarith

/-! ### Parallel timing as the case `m = 0` (table row 1, speed-set column) -/

theorem kinkMix_zero (K Ta : ℝ) : kinkMix K Ta 0 = K / Ta := by simp [kinkMix]

/-- **Parallel, below the kink: sign of `ε_H − 1`.** -/
theorem par_below_sign (H : ℝ → ℝ) (K Ta S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta) (hs : 0 < s)
    (hlt : s < K / Ta) (hH : DifferentiableAt ℝ H s) (hH0 : 0 < H s) :
    ∃ d, HasDerivAt (Rc H (Tpar K Ta) S) d s ∧
      SignType.sign d = SignType.sign (elast H s - 1) ∧ (d < 0 ↔ elast H s < 1) := by
  have hd := mix_below_hasDerivAt H K Ta 0 S s hTa (by norm_num) hs (by rwa [kinkMix_zero]) hH
  rw [tmix_zero] at hd
  have hKs : K / s ≠ 0 := (div_pos hK hs).ne'
  have hthr : (K / s) / (K / s + 0 * Ta) = 1 := by simp [hKs]
  refine ⟨_, hd, ?_, ?_⟩
  · rw [mix_below_sign H K Ta 0 s hs hH0 hK hTa.le le_rfl, hthr]
  · obtain ⟨d', hd', hiff⟩ := mix_below_lowers_iff H K Ta 0 S s hK hTa le_rfl (by norm_num) hs
      (by rwa [kinkMix_zero]) hH hH0
    rw [tmix_zero] at hd'
    rw [hd.unique hd', hiff, hthr]

/-- **Parallel, above the kink: positive.** -/
theorem par_above_pos (H : ℝ → ℝ) (K Ta S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta) (hgt : K / Ta < s)
    (hH : DifferentiableAt ℝ H s) (hH' : 0 < deriv H s) :
    HasDerivAt (Rc H (Tpar K Ta) S) (deriv H s * Ta) s ∧ 0 < deriv H s * Ta := by
  have hd := mix_above_hasDerivAt H K Ta 0 S s hK hTa (by norm_num) (by rwa [kinkMix_zero]) hH
  rw [tmix_zero] at hd
  exact ⟨hd, mul_pos hH' hTa⟩

/-! ## 3. The level-set hazard (A.7 line 1149; §4.3 lines 108, 112, 120–124; Figure 2(b)) -/

/-- The average hazard over capability levels `0..K`, `h̄ = K⁻¹∫_0^K h`. -/
noncomputable def hbar (h : ℝ → ℝ) (K : ℝ) : ℝ := (∫ c in (0:ℝ)..K, h c) / K

/-- **Cumulative hazard under the level-set hazard, defined as the time integral** of
`h(c(t))`, `c(t) = min(st, K)`, over the transition `[0, T(s)]`, plus the step term. -/
noncomputable def CumLev (h : ℝ → ℝ) (K S : ℝ) (T : ℝ → ℝ) (s : ℝ) : ℝ :=
  (∫ t in (0:ℝ)..T s, h (min (s * t) K)) + S

/-- **The closed form `τh̄ + (T − τ)h(K) + S`**, for any transition at least as long as the
capability ramp `τ = K/s`; only integrability of `h` on `[0, K]` is used. -/
theorem cumLev_closed_form (h : ℝ → ℝ) (K S : ℝ) (T : ℝ → ℝ) (s : ℝ) (hs : 0 < s) (hK : 0 < K)
    (hint : IntervalIntegrable h volume 0 K) (hT : K / s ≤ T s) :
    CumLev h K S T s = (K / s) * hbar h K + (T s - K / s) * h K + S := by
  have hτ : 0 ≤ K / s := by positivity
  have hle : ∀ t, t ≤ K / s → s * t ≤ K := fun t ht => by
    calc s * t ≤ s * (K / s) := mul_le_mul_of_nonneg_left ht hs.le
    _ = K := mul_div_cancel₀ K hs.ne'
  have hge : ∀ t, K / s ≤ t → K ≤ s * t := fun t ht => by
    calc K = s * (K / s) := (mul_div_cancel₀ K hs.ne').symm
    _ ≤ s * t := mul_le_mul_of_nonneg_left ht hs.le
  have hcomp : IntervalIntegrable (fun t => h (s * t)) volume 0 (K / s) := by
    have := hint.comp_mul_left (c := s); rwa [zero_div] at this
  have hi1 : IntervalIntegrable (fun t => h (min (s * t) K)) volume 0 (K / s) := by
    rw [intervalIntegrable_congr_uIoo (g := fun t => h (s * t)) ?_]
    · exact hcomp
    · intro t ht; rw [uIoo_of_le hτ] at ht; simp [min_eq_left (hle t ht.2.le)]
  have hi2 : IntervalIntegrable (fun t => h (min (s * t) K)) volume (K / s) (T s) := by
    rw [intervalIntegrable_congr_uIoo (g := fun _ => h K) ?_]
    · exact intervalIntegrable_const
    · intro t ht; rw [uIoo_of_le hT] at ht; simp [min_eq_right (hge t ht.1.le)]
  have e1 : (∫ t in (0:ℝ)..(K / s), h (min (s * t) K)) = s⁻¹ * ∫ c in (0:ℝ)..K, h c := by
    rw [integral_congr_Ioo_of_le hτ (g := fun t => h (s * t)) ?_]
    · rw [integral_comp_mul_left (f := h) hs.ne', smul_eq_mul, mul_zero, mul_div_cancel₀ K hs.ne']
    · intro t ht; simp [min_eq_left (hle t ht.2.le)]
  have e2 : (∫ t in (K / s)..(T s), h (min (s * t) K)) = (T s - K / s) * h K := by
    rw [integral_congr_Ioo_of_le hT (g := fun _ => h K) ?_, intervalIntegral.integral_const,
      smul_eq_mul]
    intro t ht; simp [min_eq_right (hge t ht.1.le)]
  rw [CumLev, ← integral_add_adjacent_intervals hi1 hi2, e1, e2, hbar]
  field_simp

theorem tpar_ge (K Ta s : ℝ) : K / s ≤ Tpar K Ta s := le_max_left _ _
theorem tseq_ge (K Ta s : ℝ) (hTa : 0 ≤ Ta) : K / s ≤ Tseq K Ta s := by
  unfold Tseq; linarith
theorem tmix_ge (K Ta m s : ℝ) (hm0 : 0 ≤ m) (hTa : 0 ≤ Ta) : K / s ≤ Tmix K Ta m s := by
  unfold Tmix; have := le_max_left (K / s) ((1 - m) * Ta); nlinarith [mul_nonneg hm0 hTa]

/-- A closed form `(K/x)a + c·b + S`: its derivative is `−Ka/s²`. -/
theorem hasDerivAt_ramp (K a c S s : ℝ) (hs : 0 < s) :
    HasDerivAt (fun x : ℝ => (K / x) * a + c + S) (-(K * a / s ^ 2)) s := by
  have := (((hasDerivAt_K_div K s hs.ne').mul_const a).add_const c).add_const S
  convert this using 1; ring

/-- The adoption-branch closed form `(K/x)a + (T_a − K/x)b + S`: derivative `K(b − a)/s²`. -/
theorem hasDerivAt_tail (K a b Ta S s : ℝ) (hs : 0 < s) :
    HasDerivAt (fun x : ℝ => (K / x) * a + (Ta - K / x) * b + S) (K * (b - a) / s ^ 2) s := by
  have hk := hasDerivAt_K_div K s hs.ne'
  have := ((hk.mul_const a).add ((hk.const_sub Ta).mul_const b)).add_const S
  convert this using 1; ring

/-- **Level-set, sequential (table row 3): derivative `−Kh̄/s²` at every `s > 0`, no kink.** -/
theorem lev_seq_hasDerivAt (h : ℝ → ℝ) (K Ta S s : ℝ) (hK : 0 < K) (hTa : 0 ≤ Ta) (hs : 0 < s)
    (hint : IntervalIntegrable h volume 0 K) :
    HasDerivAt (CumLev h K S (Tseq K Ta)) (-(K * hbar h K / s ^ 2)) s := by
  refine (hasDerivAt_ramp K (hbar h K) (Ta * h K) S s hs).congr_of_eventuallyEq ?_
  filter_upwards [Ioi_mem_nhds hs] with x hx
  rw [cumLev_closed_form h K S _ x hx hK hint (tseq_ge K Ta x hTa)]
  simp [Tseq]

/-- **Level-set, parallel, below the kink (table row 1): `−Kh̄/s²`.** -/
theorem lev_par_below_hasDerivAt (h : ℝ → ℝ) (K Ta S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hs : 0 < s) (hlt : s < K / Ta) (hint : IntervalIntegrable h volume 0 K) :
    HasDerivAt (CumLev h K S (Tpar K Ta)) (-(K * hbar h K / s ^ 2)) s := by
  refine (hasDerivAt_ramp K (hbar h K) 0 S s hs).congr_of_eventuallyEq ?_
  filter_upwards [Ioo_mem_nhds hs hlt] with x hx
  have hb : Ta ≤ K / x := by
    have h2 : x < K / Ta := hx.2
    rw [lt_div_iff₀ hTa] at h2; rw [le_div_iff₀ hx.1]; linarith
  rw [cumLev_closed_form h K S _ x hx.1 hK hint (tpar_ge K Ta x)]
  simp [Tpar, max_eq_left hb]

/-- **Level-set, parallel, above the kink (table row 1; A.7 line 1149): `K[h(K) − h̄]/s²`.** -/
theorem lev_par_above_hasDerivAt (h : ℝ → ℝ) (K Ta S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hgt : K / Ta < s) (hint : IntervalIntegrable h volume 0 K) :
    HasDerivAt (CumLev h K S (Tpar K Ta)) (K * (h K - hbar h K) / s ^ 2) s := by
  have hk0 : 0 < K / Ta := div_pos hK hTa
  refine (hasDerivAt_tail K (hbar h K) (h K) Ta S s (lt_trans hk0 hgt)).congr_of_eventuallyEq ?_
  filter_upwards [Ioi_mem_nhds hgt] with x hx
  have hx0 : 0 < x := lt_trans hk0 hx
  have hb : K / x ≤ Ta := by
    have h2 : K / Ta < x := hx
    rw [div_lt_iff₀ hTa] at h2; rw [div_le_iff₀ hx0]; linarith
  rw [cumLev_closed_form h K S _ x hx0 hK hint (tpar_ge K Ta x)]
  simp [Tpar, max_eq_right hb]

/-- **Level-set, mixed, below the kink (table row 2): `−Kh̄/s²`.** -/
theorem lev_mix_below_hasDerivAt (h : ℝ → ℝ) (K Ta m S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hm0 : 0 ≤ m) (hm1 : m < 1) (hs : 0 < s) (hlt : s < kinkMix K Ta m)
    (hint : IntervalIntegrable h volume 0 K) :
    HasDerivAt (CumLev h K S (Tmix K Ta m)) (-(K * hbar h K / s ^ 2)) s := by
  refine (hasDerivAt_ramp K (hbar h K) (m * Ta * h K) S s hs).congr_of_eventuallyEq ?_
  filter_upwards [Ioo_mem_nhds hs hlt] with x hx
  have hb := (mix_below_iff K Ta m x hTa hm1 hx.1).1 hx.2
  rw [cumLev_closed_form h K S _ x hx.1 hK hint (tmix_ge K Ta m x hm0 hTa.le)]
  simp [Tmix, max_eq_left hb.le]

/-- **Level-set, mixed, above the kink (table row 2): `K[h(K) − h̄]/s²`.** -/
theorem lev_mix_above_hasDerivAt (h : ℝ → ℝ) (K Ta m S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hm0 : 0 ≤ m) (hm1 : m < 1) (hgt : kinkMix K Ta m < s)
    (hint : IntervalIntegrable h volume 0 K) :
    HasDerivAt (CumLev h K S (Tmix K Ta m)) (K * (h K - hbar h K) / s ^ 2) s := by
  have hk0 := kinkMix_pos K Ta m hK hTa hm1
  refine (hasDerivAt_tail K (hbar h K) (h K) Ta S s (lt_trans hk0 hgt)).congr_of_eventuallyEq ?_
  filter_upwards [Ioi_mem_nhds hgt] with x hx
  have hx0 : 0 < x := lt_trans hk0 hx
  have hb : K / x ≤ (1 - m) * Ta := by
    by_contra hc; push Not at hc
    exact absurd ((mix_below_iff K Ta m x hTa hm1 hx0).2 hc) (not_lt.mpr hx.le)
  rw [cumLev_closed_form h K S _ x hx0 hK hint (tmix_ge K Ta m x hm0 hTa.le)]
  simp only [Tmix, max_eq_right hb]; ring

/-- **Signs of the level-set entries.** Below a kink and under sequential timing the entry
`−Kh̄/s²` is negative **iff** `h̄ > 0` ("with `h̄ > 0` it always does"); above a kink the entry
`K[h(K) − h̄]/s²` has the sign of `h(K) − h̄` (A.7 line 1149, §4.3 line 112). -/
theorem lev_ramp_neg_iff (K s hb : ℝ) (hK : 0 < K) (hs : 0 < s) :
    -(K * hb / s ^ 2) < 0 ↔ 0 < hb := by
  have hp : 0 < K / s ^ 2 := by positivity
  have : -(K * hb / s ^ 2) = (K / s ^ 2) * (-hb) := by ring
  rw [this, neg_iff_of_pos_mul hp, neg_lt_zero]

theorem lev_tail_sign (K s hK' hb : ℝ) (hK : 0 < K) (hs : 0 < s) :
    SignType.sign (K * (hK' - hb) / s ^ 2) = SignType.sign (hK' - hb) := by
  have hp : 0 < K / s ^ 2 := by positivity
  have : K * (hK' - hb) / s ^ 2 = (K / s ^ 2) * (hK' - hb) := by ring
  rw [this, sign_of_pos_mul hp]

/-- A positive hazard on `(0, K)` has `h̄ > 0`. -/
theorem hbar_pos_of_pos (h : ℝ → ℝ) (K : ℝ) (hK : 0 < K) (hint : IntervalIntegrable h volume 0 K)
    (hpos : ∀ c ∈ Ioo 0 K, 0 < h c) : 0 < hbar h K :=
  div_pos (intervalIntegral_pos_of_pos_on hint hpos hK) hK

/-! ### The table's level-set cells, with the sign tied to the proved derivative

Each theorem below states the derivative of the *defined* cumulative hazard and its sign in one
statement, so no sign lemma with a free numerator stands in for the result. -/

/-- **Sequential, level-set: negative iff `h̄ > 0`.** -/
theorem lev_seq_lowers_iff (h : ℝ → ℝ) (K Ta S s : ℝ) (hK : 0 < K) (hTa : 0 ≤ Ta) (hs : 0 < s)
    (hint : IntervalIntegrable h volume 0 K) :
    ∃ d, HasDerivAt (CumLev h K S (Tseq K Ta)) d s ∧ d = -(K * hbar h K / s ^ 2) ∧
      (d < 0 ↔ 0 < hbar h K) :=
  ⟨_, lev_seq_hasDerivAt h K Ta S s hK hTa hs hint, rfl, lev_ramp_neg_iff K s _ hK hs⟩

/-- **Parallel, level-set, below the kink: negative iff `h̄ > 0`.** -/
theorem lev_par_below_lowers_iff (h : ℝ → ℝ) (K Ta S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hs : 0 < s) (hlt : s < K / Ta) (hint : IntervalIntegrable h volume 0 K) :
    ∃ d, HasDerivAt (CumLev h K S (Tpar K Ta)) d s ∧ d = -(K * hbar h K / s ^ 2) ∧
      (d < 0 ↔ 0 < hbar h K) :=
  ⟨_, lev_par_below_hasDerivAt h K Ta S s hK hTa hs hlt hint, rfl, lev_ramp_neg_iff K s _ hK hs⟩

/-- **Mixed, level-set, below the kink: negative iff `h̄ > 0`.** -/
theorem lev_mix_below_lowers_iff (h : ℝ → ℝ) (K Ta m S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hm0 : 0 ≤ m) (hm1 : m < 1) (hs : 0 < s) (hlt : s < kinkMix K Ta m)
    (hint : IntervalIntegrable h volume 0 K) :
    ∃ d, HasDerivAt (CumLev h K S (Tmix K Ta m)) d s ∧ d = -(K * hbar h K / s ^ 2) ∧
      (d < 0 ↔ 0 < hbar h K) :=
  ⟨_, lev_mix_below_hasDerivAt h K Ta m S s hK hTa hm0 hm1 hs hlt hint, rfl,
    lev_ramp_neg_iff K s _ hK hs⟩

/-- **Parallel, level-set, above the kink: the sign of `h(K) − h̄` (A.7 line 1149).** -/
theorem lev_par_above_sign (h : ℝ → ℝ) (K Ta S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hgt : K / Ta < s) (hint : IntervalIntegrable h volume 0 K) :
    ∃ d, HasDerivAt (CumLev h K S (Tpar K Ta)) d s ∧ d = K * (h K - hbar h K) / s ^ 2 ∧
      SignType.sign d = SignType.sign (h K - hbar h K) :=
  ⟨_, lev_par_above_hasDerivAt h K Ta S s hK hTa hgt hint, rfl,
    lev_tail_sign K s _ _ hK (lt_trans (div_pos hK hTa) hgt)⟩

/-- **Mixed, level-set, above the kink: the sign of `h(K) − h̄`.** -/
theorem lev_mix_above_sign (h : ℝ → ℝ) (K Ta m S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hm0 : 0 ≤ m) (hm1 : m < 1) (hgt : kinkMix K Ta m < s)
    (hint : IntervalIntegrable h volume 0 K) :
    ∃ d, HasDerivAt (CumLev h K S (Tmix K Ta m)) d s ∧ d = K * (h K - hbar h K) / s ^ 2 ∧
      SignType.sign d = SignType.sign (h K - hbar h K) :=
  ⟨_, lev_mix_above_hasDerivAt h K Ta m S s hK hTa hm0 hm1 hgt hint, rfl,
    lev_tail_sign K s _ _ hK (lt_trans (kinkMix_pos K Ta m hK hTa hm1) hgt)⟩

/-- The zero hazard has average `h̄ = 0`. -/
theorem hbar_zero (K : ℝ) : hbar (fun _ => (0:ℝ)) K = 0 := by simp [hbar]

/-- **§4.3 line 124, "the level-set derivative is always negative" (sequential), is false as
stated.** `h ≡ 0` is continuous and nonnegative — the paper's own conditions on `h` (line 1025) —
the derivative of the defined cumulative hazard is `0`, and no derivative at `s` is negative. -/
theorem lev_seq_zero_hazard_counterexample (K Ta S s : ℝ) (hK : 0 < K) (hTa : 0 ≤ Ta)
    (hs : 0 < s) :
    Continuous (fun _ : ℝ => (0:ℝ)) ∧ (∀ c : ℝ, 0 ≤ (fun _ : ℝ => (0:ℝ)) c) ∧
      HasDerivAt (CumLev (fun _ => 0) K S (Tseq K Ta)) 0 s ∧
      ∀ d, HasDerivAt (CumLev (fun _ => 0) K S (Tseq K Ta)) d s → ¬ d < 0 := by
  have h0 := lev_seq_hasDerivAt (fun _ => (0:ℝ)) K Ta S s hK hTa hs intervalIntegrable_const
  rw [hbar_zero, mul_zero, zero_div, neg_zero] at h0
  exact ⟨continuous_const, fun _ => le_rfl, h0,
    fun d hd => by rw [hd.unique h0]; exact lt_irrefl 0⟩

/-- **Parallel, below the kink: "a hazard set by the level reached lets acceleration help"
(line 26) and "always for a level-set hazard" (line 529) are false as stated.** With the
continuous nonnegative `h ≡ 0`, the derivative of the defined cumulative hazard is `0`. -/
theorem lev_par_below_zero_hazard_counterexample (K Ta S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hs : 0 < s) (hlt : s < K / Ta) :
    Continuous (fun _ : ℝ => (0:ℝ)) ∧ (∀ c : ℝ, 0 ≤ (fun _ : ℝ => (0:ℝ)) c) ∧
      HasDerivAt (CumLev (fun _ => 0) K S (Tpar K Ta)) 0 s ∧
      ∀ d, HasDerivAt (CumLev (fun _ => 0) K S (Tpar K Ta)) d s → ¬ d < 0 := by
  have h0 := lev_par_below_hasDerivAt (fun _ => (0:ℝ)) K Ta S s hK hTa hs hlt
    intervalIntegrable_const
  rw [hbar_zero, mul_zero, zero_div, neg_zero] at h0
  exact ⟨continuous_const, fun _ => le_rfl, h0,
    fun d hd => by rw [hd.unique h0]; exact lt_irrefl 0⟩

/-- **Mixed, below the kink: the same counterexample** (lines 26 and 529, mixed timing). -/
theorem lev_mix_below_zero_hazard_counterexample (K Ta m S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hm0 : 0 ≤ m) (hm1 : m < 1) (hs : 0 < s) (hlt : s < kinkMix K Ta m) :
    Continuous (fun _ : ℝ => (0:ℝ)) ∧ (∀ c : ℝ, 0 ≤ (fun _ : ℝ => (0:ℝ)) c) ∧
      HasDerivAt (CumLev (fun _ => 0) K S (Tmix K Ta m)) 0 s ∧
      ∀ d, HasDerivAt (CumLev (fun _ => 0) K S (Tmix K Ta m)) d s → ¬ d < 0 := by
  have h0 := lev_mix_below_hasDerivAt (fun _ => (0:ℝ)) K Ta m S s hK hTa hm0 hm1 hs hlt
    intervalIntegrable_const
  rw [hbar_zero, mul_zero, zero_div, neg_zero] at h0
  exact ⟨continuous_const, fun _ => le_rfl, h0,
    fun d hd => by rw [hd.unique h0]; exact lt_irrefl 0⟩

/-- **§4.3 line 108: a hazard that rises with capability has `h(K) > h̄`.** Strict monotonicity
on `[0, K]` suffices (integrability follows from monotonicity). -/
theorem hbar_lt_of_strictMonoOn (h : ℝ → ℝ) (K : ℝ) (hK : 0 < K)
    (hmono : StrictMonoOn h (Icc 0 K)) : hbar h K < h K := by
  have hint : IntervalIntegrable h volume 0 K :=
    MonotoneOn.intervalIntegrable (by rw [uIcc_of_le hK.le]; exact hmono.monotoneOn)
  have hpos : 0 < ∫ c in (0:ℝ)..K, (h K - h c) := by
    refine intervalIntegral_pos_of_pos_on (intervalIntegrable_const.sub hint) ?_ hK
    intro c hc
    have := hmono ⟨hc.1.le, hc.2.le⟩ ⟨hK.le, le_rfl⟩ hc.2
    linarith
  rw [intervalIntegral.integral_sub intervalIntegrable_const hint,
    intervalIntegral.integral_const, smul_eq_mul, sub_zero] at hpos
  rw [hbar, div_lt_iff₀ hK]; linarith

/-- **§4.3 line 108 / main text line 26: above the parallel kink, a hazard that rises with
capability makes acceleration raise the level-set cumulative hazard.** -/
theorem lev_par_above_raises_of_strictMono (h : ℝ → ℝ) (K Ta S s : ℝ) (hK : 0 < K)
    (hTa : 0 < Ta) (hgt : K / Ta < s) (hmono : StrictMonoOn h (Icc 0 K)) :
    ∃ d, HasDerivAt (CumLev h K S (Tpar K Ta)) d s ∧ 0 < d := by
  have hint : IntervalIntegrable h volume 0 K :=
    MonotoneOn.intervalIntegrable (by rw [uIcc_of_le hK.le]; exact hmono.monotoneOn)
  have hs : 0 < s := lt_trans (div_pos hK hTa) hgt
  have hlt := hbar_lt_of_strictMonoOn h K hK hmono
  refine ⟨_, lev_par_above_hasDerivAt h K Ta S s hK hTa hgt hint, ?_⟩
  have : 0 < h K - hbar h K := sub_pos.mpr hlt
  positivity

/-- **Figure 2(b) examples, `K = 1`.** `h(c) = c` has `h̄ = 1/2 < h(1) = 1` (the derivative above
the kink is positive); `h(c) = 1 − c/2` has `h̄ = 3/4 > h(1) = 1/2` (negative). -/
theorem fig2_examples :
    hbar (fun c => c) 1 = 1 / 2 ∧ hbar (fun c => 1 - c / 2) 1 = 3 / 4 := by
  constructor
  · norm_num [hbar, integral_id]
  · rw [hbar, intervalIntegral.integral_sub intervalIntegrable_const
      (intervalIntegrable_id.div_const 2), intervalIntegral.integral_div, integral_id]
    simp; norm_num

/-- **Figure 2 caption: "Panel (b) is not obtained by substituting `H = h(K)` into panel (a)".**
Above the parallel kink the level-set cumulative hazard differs from the speed-set index with the
constant hazard `h(K)` by exactly `τ(h̄ − h(K))`. -/
theorem lev_vs_substitution (h : ℝ → ℝ) (K Ta S s : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hgt : K / Ta < s) (hint : IntervalIntegrable h volume 0 K) :
    CumLev h K S (Tpar K Ta) s - Rc (fun _ => h K) (Tpar K Ta) S s
      = (K / s) * (hbar h K - h K) := by
  have hs : 0 < s := lt_trans (div_pos hK hTa) hgt
  have hb : K / s ≤ Ta := by rw [div_le_iff₀ hs]; rw [div_lt_iff₀ hTa] at hgt; linarith
  rw [cumLev_closed_form h K S _ s hs hK hint (tpar_ge K Ta s)]
  simp only [Rc, Tpar, max_eq_right hb]; ring

/-! ## 4. Separate adoption populations (A.7 line 1159; §4.3 line 128) -/

/-- The weighted loss over a finite family of adoption populations with a common hazard. -/
noncomputable def Rpop {ι : Type*} (J : Finset ι) (w Taj : ι → ℝ) (H : ℝ → ℝ) (K S : ℝ)
    (s : ℝ) : ℝ :=
  (∑ j ∈ J, w j * (H s * max (K / s) (Taj j))) + S

/-- `Σ_cap w_j K/s` — over the populations where capability binds at `s`. -/
noncomputable def capSum {ι : Type*} (J : Finset ι) (w Taj : ι → ℝ) (K s : ℝ) : ℝ :=
  ∑ j ∈ J.filter (fun j => Taj j < K / s), w j * (K / s)

/-- `Σ_adopt w_j T_{a,j}` — over the populations where adoption binds at `s`. -/
noncomputable def adoptSum {ι : Type*} (J : Finset ι) (w Taj : ι → ℝ) (K s : ℝ) : ℝ :=
  ∑ j ∈ J.filter (fun j => ¬ Taj j < K / s), w j * Taj j

/-- **Many populations, the derivative**, at a speed away from every population's kink. -/
theorem pop_hasDerivAt {ι : Type*} (J : Finset ι) (w Taj : ι → ℝ) (H : ℝ → ℝ) (K S s : ℝ)
    (hs : 0 < s) (hH : DifferentiableAt ℝ H s) (hkink : ∀ j ∈ J, K / s ≠ Taj j) :
    HasDerivAt (Rpop J w Taj H K S)
      (deriv H s * (capSum J w Taj K s + adoptSum J w Taj K s)
        - H s * capSum J w Taj K s / s) s := by
  classical
  have hcd : ContinuousAt (fun x : ℝ => K / x) s := continuousAt_const.div continuousAt_id hs.ne'
  -- each term, on its own branch
  have hterm : ∀ j ∈ J, HasDerivAt (fun x => w j * (H x * max (K / x) (Taj j)))
      (w j * (deriv H s * (if Taj j < K / s then K / s else Taj j)
        + H s * (if Taj j < K / s then -(K / s ^ 2) else 0))) s := by
    intro j hj
    by_cases hp : Taj j < K / s
    · simp only [hp, ite_true]
      have hd := ((hH.hasDerivAt.mul (hasDerivAt_K_div K s hs.ne')).const_mul (w j))
      refine hd.congr_of_eventuallyEq ?_
      filter_upwards [hcd.eventually (Ioi_mem_nhds hp)] with x hx
      simp [max_eq_left (le_of_lt hx)]
    · simp only [hp, ite_false]
      have hlt : K / s < Taj j := lt_of_le_of_ne (not_lt.mp hp) (hkink j hj)
      have hd := ((hH.hasDerivAt.mul_const (Taj j)).const_mul (w j))
      refine (hd.congr_deriv (by ring)).congr_of_eventuallyEq ?_
      filter_upwards [hcd.eventually (Iio_mem_nhds hlt)] with x hx
      simp [max_eq_right (le_of_lt hx)]
  have hsum := (HasDerivAt.fun_sum hterm).add_const S
  refine hsum.congr_deriv ?_
  -- rearrange the sum into the cap/adopt form
  have e : ∀ j, w j * (deriv H s * (if Taj j < K / s then K / s else Taj j)
        + H s * (if Taj j < K / s then -(K / s ^ 2) else 0))
      = deriv H s * (if Taj j < K / s then w j * (K / s) else w j * Taj j)
        + (if Taj j < K / s then -(H s / s) * (w j * (K / s)) else 0) := by
    intro j; split_ifs
    · field_simp
    · ring
  simp only [e, Finset.sum_add_distrib, ← Finset.mul_sum, Finset.sum_ite, Finset.sum_const_zero,
    add_zero, capSum, adoptSum]
  ring

/-- **Many populations, the iff (A.7 line 1159; §4.3 line 128).** Acceleration lowers the weighted
loss iff `(1 − ε_H)Σ_cap w_j K/s > ε_H Σ_adopt w_j T_{a,j}`. -/
theorem pop_lowers_iff {ι : Type*} (J : Finset ι) (w Taj : ι → ℝ) (H : ℝ → ℝ) (K S s : ℝ)
    (hs : 0 < s) (hH : DifferentiableAt ℝ H s) (hH0 : 0 < H s)
    (hkink : ∀ j ∈ J, K / s ≠ Taj j) :
    ∃ d, HasDerivAt (Rpop J w Taj H K S) d s ∧
      (d < 0 ↔ elast H s * adoptSum J w Taj K s < (1 - elast H s) * capSum J w Taj K s) := by
  refine ⟨_, pop_hasDerivAt J w Taj H K S s hs hH hkink, ?_⟩
  set C := capSum J w Taj K s
  set A := adoptSum J w Taj K s
  have hp : 0 < H s / s := div_pos hH0 hs
  have key : deriv H s * (C + A) - H s * C / s
      = (H s / s) * (elast H s * A - (1 - elast H s) * C) := by
    unfold elast; field_simp; ring
  rw [key, neg_iff_of_pos_mul hp, sub_neg]

/-! ## 5. Far risk falling with speed, `C_A′ < 0` (A.7 line 1152) -/

/-- **Far risk falling.** Above the parallel kink the near loss `R_c` rises (`C_c′ = H′T_a > 0`),
and with `C_A′ < 0` acceleration lowers `V_cC_c + V_AC_A` iff `V_A/V_c > C_c′/(−C_A′)`. -/
theorem far_falling_iff (H CA : ℝ → ℝ) (K Ta S Vc VA s dA : ℝ) (hK : 0 < K) (hTa : 0 < Ta)
    (hgt : K / Ta < s) (hH : DifferentiableAt ℝ H s) (hH' : 0 < deriv H s)
    (hCA : HasDerivAt CA dA s) (hdA : dA < 0) (hVc : 0 < Vc) :
    HasDerivAt (fun x => Vc * Rc H (Tpar K Ta) S x + VA * CA x)
        (Vc * (deriv H s * Ta) + VA * dA) s ∧
      0 < deriv H s * Ta ∧
      (Vc * (deriv H s * Ta) + VA * dA < 0 ↔ (deriv H s * Ta) / (-dA) < VA / Vc) := by
  obtain ⟨hd, hpos⟩ := par_above_pos H K Ta S s hK hTa hgt hH hH'
  refine ⟨(hd.const_mul Vc).add (hCA.const_mul VA), hpos, ?_⟩
  have hn : 0 < -dA := neg_pos.mpr hdA
  rw [div_lt_div_iff₀ hn hVc]
  constructor <;> intro h <;> nlinarith

end RTTR.Timings

#print axioms RTTR.Timings.tmix_zero
#print axioms RTTR.Timings.tmix_one
#print axioms RTTR.Timings.hasDerivAt_K_div
#print axioms RTTR.Timings.capBranch_hasDerivAt
#print axioms RTTR.Timings.capBranch_factor
#print axioms RTTR.Timings.capBranch_factor_pos
#print axioms RTTR.Timings.sign_of_pos_mul
#print axioms RTTR.Timings.neg_iff_of_pos_mul
#print axioms RTTR.Timings.seq_hasDerivAt
#print axioms RTTR.Timings.seq_no_kink
#print axioms RTTR.Timings.seq_sign
#print axioms RTTR.Timings.seq_lowers_iff
#print axioms RTTR.Timings.seq_cell_sign
#print axioms RTTR.Timings.kinkMix_pos
#print axioms RTTR.Timings.mix_below_iff
#print axioms RTTR.Timings.mix_le_iff
#print axioms RTTR.Timings.kinkMix_K_div
#print axioms RTTR.Timings.mix_ge
#print axioms RTTR.Timings.kinkMix_depends_on_parallel_share
#print axioms RTTR.Timings.mix_below_hasDerivAt
#print axioms RTTR.Timings.mix_below_sign
#print axioms RTTR.Timings.mix_below_lowers_iff
#print axioms RTTR.Timings.mix_capability_share
#print axioms RTTR.Timings.mix_above_hasDerivAt
#print axioms RTTR.Timings.mix_above_pos
#print axioms RTTR.Timings.mix_below_cell_sign
#print axioms RTTR.Timings.mix_above_raises
#print axioms RTTR.Timings.mix_kink_left
#print axioms RTTR.Timings.mix_kink_right
#print axioms RTTR.Timings.mix_kink_not_differentiable
#print axioms RTTR.Timings.kinkMix_zero
#print axioms RTTR.Timings.par_below_sign
#print axioms RTTR.Timings.par_above_pos
#print axioms RTTR.Timings.cumLev_closed_form
#print axioms RTTR.Timings.tpar_ge
#print axioms RTTR.Timings.tseq_ge
#print axioms RTTR.Timings.tmix_ge
#print axioms RTTR.Timings.hasDerivAt_ramp
#print axioms RTTR.Timings.hasDerivAt_tail
#print axioms RTTR.Timings.lev_seq_hasDerivAt
#print axioms RTTR.Timings.lev_par_below_hasDerivAt
#print axioms RTTR.Timings.lev_par_above_hasDerivAt
#print axioms RTTR.Timings.lev_mix_below_hasDerivAt
#print axioms RTTR.Timings.lev_mix_above_hasDerivAt
#print axioms RTTR.Timings.lev_ramp_neg_iff
#print axioms RTTR.Timings.lev_tail_sign
#print axioms RTTR.Timings.hbar_pos_of_pos
#print axioms RTTR.Timings.lev_seq_lowers_iff
#print axioms RTTR.Timings.lev_par_below_lowers_iff
#print axioms RTTR.Timings.lev_mix_below_lowers_iff
#print axioms RTTR.Timings.lev_par_above_sign
#print axioms RTTR.Timings.lev_mix_above_sign
#print axioms RTTR.Timings.hbar_zero
#print axioms RTTR.Timings.lev_seq_zero_hazard_counterexample
#print axioms RTTR.Timings.lev_par_below_zero_hazard_counterexample
#print axioms RTTR.Timings.lev_mix_below_zero_hazard_counterexample
#print axioms RTTR.Timings.hbar_lt_of_strictMonoOn
#print axioms RTTR.Timings.lev_par_above_raises_of_strictMono
#print axioms RTTR.Timings.fig2_examples
#print axioms RTTR.Timings.lev_vs_substitution
#print axioms RTTR.Timings.pop_hasDerivAt
#print axioms RTTR.Timings.pop_lowers_iff
#print axioms RTTR.Timings.far_falling_iff
