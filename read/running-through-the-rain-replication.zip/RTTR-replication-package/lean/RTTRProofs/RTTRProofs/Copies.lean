import Mathlib

/-!
# Appendix B: open- and closed-weight copies (Propositions E1, E2, E3)

Paper: `PAPER-DRAFT-v8.md`, Appendix B, lines 1165–1304.

## Modelling choices, and why they are faithful

* **Probability space.** One probability space `(Ω, μ)`, `IsProbabilityMeasure μ`. Every
  stream, the holder's safeguard outcome and every random schedule live on it, so "the same
  future primitive streams" under the actions compared (B.2.1, line 1207; E2, line 1242) is the
  literal coupling: the streams do not depend on the action.
* **First arrivals, not Poisson processes.** Mathlib has no Poisson-process or marked-point-process
  library. The premise Lean takes (`FirstArrivals`) is the joint law of the *first-arrival times*
  of the primitive streams: extended nonnegative times `τ i : Ω → ℝ≥0∞`, mutually independent
  (`iIndepFun`), a component with positive rate `r i` exponential with that rate, and a
  zero-rate component identically `⊤` ("a zero-rate component never arrives", line 1205). The
  paper *derives* this premise from homogeneous Poisson streams and independent marking of each
  closed arrival (the thinning step, line 1293). **Lean does not derive it**; the thinning step
  is recorded as its own unresolved row, and every E1/E3 certificate is conditional on this
  joint first-arrival law. E2's proofs assume nothing about the stream vector. Lean's
  `W_H = ω_A.toReal` equals the paper's `ω_A` on `{ω_A < ∞}`, which has probability one under the
  first-arrival premise with `λ_A > 0` (`e1_omegaA_lt_top_ae`, `e2_WH_ae_eq`). The value on the
  null event never affects an expectation; off the premise, `⊤.toReal = 0` is a junk value, so
  reading E2's theorems as statements about the paper's `ω_A` uses the premise.
* **Exponential law.** `HasExpSurvival μ X r` says `μ {X > t} = e^{-r t}` for every `t ≥ 0`. For
  an extended nonnegative time this survival function determines the law on `[0, ∞]`, and for
  `r > 0` it is the exponential distribution with rate `r` (mean `1/r`, proved below as a
  `lintegral`, i.e. an extended nonnegative expectation, so no integrability is presupposed).
* **The first events.** `ω_C` is the first of the five events of the table (line 1189) and `ω_A`
  the first attack-enabling one, excluding C0 (line 1199): `Finset.inf` of the arrival times over
  the corresponding event sets. Nothing about them is assumed; their laws are proved.
* **Windows.** `W_C` and `W_A` are *defined* from B.2.2 (line 1211): the commercial window ends at
  the first of `ω_C` and the holder's own commercially substituting release date; the attacker
  window ends at the first of `ω_A` and the date the holder's own action gives attackers lasting
  capability (immediate open release: `0`; immediate closed release: `0` if its safeguards fail,
  never otherwise; committed holding: never, B-S2). The table of E1 is then a theorem.
* **E2 exposure.** A defensive schedule is a structure carrying every date the paper puts in `Σ`
  (publication `P_f`, deployment delay `τ_fj`, removal `ζ_j`), the attackers' discovery delays
  `d_f`, `d_f^π`, the common lag `ℓ_x`, and the weights (so coverage, encoded by which pairs carry
  weight, may be random). Patched and unfound flaws are indexed by finite types of flaw–operator
  pairs; indexing by pairs is more general than per-flaw data shared across operators, so the
  paper's case is an instance. **Finiteness is a restriction the paper does not state**
  (`[Fintype P] [Fintype U]`): countably many pairs with summable exposure are not covered by the
  concrete `exposure` theorems, only by the generic core, given measurability and antitonicity.
  `exposure π Σ W` is exactly the sum of lines 1213–1221. Windows
  enter as reals: `W_H = ω_A.toReal`; `ω_A < ∞` almost surely when `λ_A > 0`
  (`e1_omegaA_lt_top_ae`), so the value on the null event `ω_A = ∞` never affects an expectation.
* **E2 expectations** are Bochner integrals with explicit integrability hypotheses, which is how
  "assume finite expected total exposure" (line 1221) is read: `X(Σ_H, ω_A)` and `X(Σ_cl, W_cl)`
  are integrable (`X_H`, `X_cl` finite). The general decomposition also needs `X(Σ_H, 0)`
  integrable (`hI0`), which line 1221 does not imply; it is an added hypothesis there. Under
  identical schedule laws, `Γ_def = 0`, the weak raise and equality at `p_h = 0` do not need it:
  `e2_generic_identical` derives it when `p_h > 0` (`e2_integrable_zero`) and argues `B_h = 0`
  a.s. when `p_h = 0`. The strictness clause does: when `p_h = 0` and `X(Σ_H, 0)` is not
  integrable, the paper's `S_H` is `+∞` while the Bochner `SH` is a junk `0`. Strictness is
  therefore certified with `hI0` (`e2_identical_strict`), and separately for the extended
  nonnegative `S_H` with the measure-theoretic convention `0 · ∞ = 0` (`e2_identical_strict_ext`).
* **E2 independence** is the paper's, verbatim: `B_h` independent of the whole stream vector
  (line 1207) and each schedule independent of the pair (stream vector, `B_h`) (line 1221). The
  joint independence of `B_h` from (schedule, streams) that the mixture needs is *derived*
  (`e2_joint_indep`), not assumed.
* **E2 generic core.** The probabilistic part of E2 is proved for any jointly measurable exposure
  `X : Sch → ℝ → ℝ`; the sign results need only that `X(Σ, ·)` is antitone (the paper's own
  reason, line 1219: "exposure onset stays non-decreasing in W"). The paper's exposure
  (`exposure`) is shown antitone, and so is a capability-dependent-lag variant (`exposureLag`).
  Monotonicity needs nonnegative weights and `π ≤ 1` only (`π ≥ 0` is never used).
  The paper does not specify the shortened-lag rule; `exposureLag` uses the natural one (after
  access at `W`, a patch published at `P` yields an exploit at `max(P, W) + ℓ_c`), and the generic
  theorems cover every rule whose excluded-attacker onset is non-decreasing in `W`.
* **E3** uses eight primitive substreams (domestic/outside × open/closed-failed/closed-working,
  plus theft and leak), with the outside quantities a fixed `OutRates` and the covered domestic
  ones an arbitrary admissible `DomRates`.
-/

open MeasureTheory ProbabilityTheory Set
open scoped ENNReal

namespace RTTR.Copies

variable {Ω : Type*} [MeasurableSpace Ω]

/-! ## General first-arrival machinery -/

/-- `X` has the exponential law with rate `r`: its survival function is `e^{-rt}` on `t ≥ 0`. -/
def HasExpSurvival (μ : Measure Ω) (X : Ω → ℝ≥0∞) (r : ℝ) : Prop :=
  ∀ t : ℝ, 0 ≤ t → μ {ω | ENNReal.ofReal t < X ω} = ENNReal.ofReal (Real.exp (-(r * t)))

/-- The premise Lean takes in place of the Poisson streams: independent extended nonnegative
first-arrival times, exponential at positive rates, identically `⊤` at rate zero. -/
structure FirstArrivals (μ : Measure Ω) {ι : Type*} (τ : ι → Ω → ℝ≥0∞) (r : ι → ℝ) : Prop where
  meas : ∀ i, Measurable (τ i)
  indep : iIndepFun τ μ
  rate_nonneg : ∀ i, 0 ≤ r i
  law_pos : ∀ i, 0 < r i → HasExpSurvival μ (τ i) (r i)
  never_of_zero : ∀ i, r i = 0 → ∀ ω, τ i ω = ⊤

variable {μ : Measure Ω} [IsProbabilityMeasure μ]

/-- A zero-rate component also has the (degenerate) exponential survival `e^{0} = 1`. -/
theorem FirstArrivals.law {ι : Type*} {τ : ι → Ω → ℝ≥0∞} {r : ι → ℝ}
    (h : FirstArrivals μ τ r) (i : ι) : HasExpSurvival μ (τ i) (r i) := by
  rcases (h.rate_nonneg i).lt_or_eq with hpos | hzero
  · exact h.law_pos i hpos
  · intro t _
    have hset : {ω | ENNReal.ofReal t < τ i ω} = univ := by
      ext ω; simp [h.never_of_zero i hzero.symm ω]
    rw [hset, measure_univ, ← hzero]; simp

/-- The first arrival over a finite set of independent components is later than `t` exactly
when every component is: survival is the product of the survivals. -/
theorem survival_inf {ι : Type*} {τ : ι → Ω → ℝ≥0∞} {r : ι → ℝ} (h : FirstArrivals μ τ r)
    (S : Finset ι) :
    HasExpSurvival μ (fun ω => S.inf (fun i => τ i ω)) (∑ i ∈ S, r i) := by
  intro t ht
  have hset : {ω | ENNReal.ofReal t < S.inf (fun i => τ i ω)} =
      ⋂ i ∈ S, τ i ⁻¹' Ioi (ENNReal.ofReal t) := by
    ext ω
    simp only [mem_ofPred_eq, mem_iInter, mem_preimage, mem_Ioi]
    exact Finset.lt_inf_iff ENNReal.ofReal_lt_top
  rw [hset, (iIndepFun_iff_measure_inter_preimage_eq_mul.mp h.indep) S
    (fun i _ => measurableSet_Ioi)]
  have hfac : ∀ i ∈ S, μ (τ i ⁻¹' Ioi (ENNReal.ofReal t)) =
      ENNReal.ofReal (Real.exp (-(r i * t))) := fun i _ => h.law i t ht
  rw [Finset.prod_congr rfl hfac, ← ENNReal.ofReal_prod_of_nonneg
    (fun i _ => (Real.exp_pos _).le), ← Real.exp_sum]
  congr 2
  rw [Finset.sum_mul, Finset.sum_neg_distrib]

/-- The minimum over a finite set of coordinates is measurable. -/
theorem measurable_finset_inf {ι : Type*} (S : Finset ι) :
    Measurable (fun s : ι → ℝ≥0∞ => S.inf s) := by
  classical
  induction S using Finset.induction_on with
  | empty => simp
  | insert a S _ ih =>
    simp only [Finset.inf_insert]
    exact (measurable_pi_apply a).inf ih

/-- Layer cake for an extended nonnegative random variable:
`E[X] = ∫₀^∞ P(X > t) dt`. -/
theorem lintegral_eq_lintegral_survival {X : Ω → ℝ≥0∞} (hX : Measurable X) :
    ∫⁻ ω, X ω ∂μ = ∫⁻ t in Ioi (0:ℝ), μ {ω | ENNReal.ofReal t < X ω} := by
  have hms : ∀ a : ℝ≥0∞, MeasurableSet {t : ℝ | ENNReal.ofReal t < a} :=
    fun a => measurableSet_lt ENNReal.measurable_ofReal measurable_const
  have key : ∀ a : ℝ≥0∞,
      a = ∫⁻ t in Ioi (0:ℝ), {t : ℝ | ENNReal.ofReal t < a}.indicator 1 t := by
    intro a
    rw [lintegral_indicator_one (hms a), Measure.restrict_apply (hms a)]
    rcases eq_or_ne a ⊤ with rfl | ha
    · simp
    · have hI : {t : ℝ | ENNReal.ofReal t < a} ∩ Ioi 0 = Ioo 0 a.toReal := by
        ext t
        simp only [mem_inter_iff, mem_ofPred_eq, mem_Ioi, mem_Ioo]
        constructor
        · rintro ⟨h1, h2⟩; exact ⟨h2, (ENNReal.ofReal_lt_iff_lt_toReal h2.le ha).mp h1⟩
        · rintro ⟨h2, h1⟩; exact ⟨(ENNReal.ofReal_lt_iff_lt_toReal h2.le ha).mpr h1, h2⟩
      rw [hI, Real.volume_Ioo, sub_zero, ENNReal.ofReal_toReal ha]
  calc ∫⁻ ω, X ω ∂μ
      = ∫⁻ ω, (∫⁻ t in Ioi (0:ℝ), {t : ℝ | ENNReal.ofReal t < X ω}.indicator 1 t) ∂μ := by
        congr 1; funext ω; exact key (X ω)
    _ = ∫⁻ t in Ioi (0:ℝ), (∫⁻ ω, {t : ℝ | ENNReal.ofReal t < X ω}.indicator 1 t ∂μ) := by
        apply lintegral_lintegral_swap
        apply Measurable.aemeasurable
        have hfun : Function.uncurry
            (fun ω t => {t : ℝ | ENNReal.ofReal t < X ω}.indicator (1 : ℝ → ℝ≥0∞) t) =
            {p : Ω × ℝ | ENNReal.ofReal p.2 < X p.1}.indicator 1 := by
          funext p; simp [Function.uncurry, Set.indicator]
        rw [hfun]
        exact measurable_one.indicator
          (measurableSet_lt (ENNReal.measurable_ofReal.comp measurable_snd) (hX.comp measurable_fst))
    _ = ∫⁻ t in Ioi (0:ℝ), μ {ω | ENNReal.ofReal t < X ω} := by
        congr 1; funext t
        have hfun : (fun ω => {t : ℝ | ENNReal.ofReal t < X ω}.indicator (1 : ℝ → ℝ≥0∞) t) =
            {ω | ENNReal.ofReal t < X ω}.indicator 1 := by
          funext ω; simp [Set.indicator]
        rw [hfun, lintegral_indicator_one (measurableSet_lt measurable_const hX)]

/-- The mean of an exponential time with rate `r > 0` is `1/r` (an extended nonnegative
expectation: no integrability is presupposed). -/
theorem HasExpSurvival.lintegral_eq {X : Ω → ℝ≥0∞} (hX : Measurable X) {r : ℝ} (hr : 0 < r)
    (h : HasExpSurvival μ X r) : ∫⁻ ω, X ω ∂μ = ENNReal.ofReal (1 / r) := by
  rw [lintegral_eq_lintegral_survival hX,
    setLIntegral_congr_fun measurableSet_Ioi (fun t ht => h t (le_of_lt ht))]
  have hint : IntegrableOn (fun t : ℝ => Real.exp (-(r * t))) (Ioi 0) := by
    simpa [neg_mul] using exp_neg_integrableOn_Ioi 0 hr
  rw [← ofReal_integral_eq_lintegral_ofReal hint
    (Filter.Eventually.of_forall (fun t => (Real.exp_pos _).le))]
  congr 1
  have hI := integral_exp_mul_Ioi (a := -r) (by linarith) 0
  simp only [mul_zero, Real.exp_zero] at hI
  simp only [← neg_mul]
  rw [hI]; field_simp

/-- An exponential time with positive rate is finite almost surely. -/
theorem HasExpSurvival.ae_lt_top {X : Ω → ℝ≥0∞} (hX : Measurable X) {r : ℝ} (hr : 0 < r)
    (h : HasExpSurvival μ X r) : ∀ᵐ ω ∂μ, X ω < ⊤ :=
  MeasureTheory.ae_lt_top hX (by rw [h.lintegral_eq hX hr]; exact ENNReal.ofReal_ne_top)

/-! ## The event system of B.2.1 -/

/-- The five event types of the table at line 1189. -/
inductive Ev
  | O   -- rival open-weight comparable release
  | C1  -- rival closed release whose safeguards fail
  | C0  -- rival closed release whose safeguards work
  | Th  -- theft of weights
  | L   -- partner leak
  deriving DecidableEq

/-- Primitive rates: `λ_o, λ_c, p_c, λ_θ, λ_ℓ`. -/
structure Rates where
  lo : ℝ
  lc : ℝ
  pc : ℝ
  lth : ℝ
  ll : ℝ

/-- Line 1205: rates nonnegative and `0 ≤ p_c ≤ 1`. -/
def Rates.Admissible (q : Rates) : Prop :=
  0 ≤ q.lo ∧ 0 ≤ q.lc ∧ 0 ≤ q.pc ∧ q.pc ≤ 1 ∧ 0 ≤ q.lth ∧ 0 ≤ q.ll

/-- The intensity column of the table at line 1189 (after marking). -/
def Rates.rate (q : Rates) : Ev → ℝ
  | .O => q.lo
  | .C1 => q.pc * q.lc
  | .C0 => (1 - q.pc) * q.lc
  | .Th => q.lth
  | .L => q.ll

/-- `λ_C = λ_o + λ_c + λ_θ + λ_ℓ` (line 1201). -/
def Rates.lamC (q : Rates) : ℝ := q.lo + q.lc + q.lth + q.ll

/-- `λ_A = λ_o + p_cλ_c + λ_θ + λ_ℓ` (line 1203). -/
def Rates.lamA (q : Rates) : ℝ := q.lo + q.pc * q.lc + q.lth + q.ll

theorem Rates.rate_nonneg {q : Rates} (hq : q.Admissible) (e : Ev) : 0 ≤ q.rate e := by
  obtain ⟨h1, h2, h3, h4, h5, h6⟩ := hq
  cases e
  · exact h1
  · exact mul_nonneg h3 h2
  · exact mul_nonneg (by linarith) h2
  · exact h5
  · exact h6

/-- Events that end the commercial lead: all five. -/
def commSet : Finset Ev := {.O, .C1, .C0, .Th, .L}

/-- Events that end attacker exclusion: all but C0. -/
def attackSet : Finset Ev := {.O, .C1, .Th, .L}

/-- `ω_C`: the first event of the table. -/
noncomputable def omegaCOf (s : Ev → ℝ≥0∞) : ℝ≥0∞ := commSet.inf s

/-- `ω_A`: the first attack-enabling event. -/
noncomputable def omegaAOf (s : Ev → ℝ≥0∞) : ℝ≥0∞ := attackSet.inf s

theorem sum_commSet (q : Rates) : ∑ e ∈ commSet, q.rate e = q.lamC := by
  simp [commSet, Rates.rate, Rates.lamC]; ring

theorem sum_attackSet (q : Rates) : ∑ e ∈ attackSet, q.rate e = q.lamA := by
  simp [attackSet, Rates.rate, Rates.lamA]; ring

theorem measurable_omegaAOf : Measurable omegaAOf := measurable_finset_inf attackSet

theorem measurable_omegaCOf : Measurable omegaCOf := measurable_finset_inf commSet

/-! ## E1 -/

section E1

variable {τ : Ev → Ω → ℝ≥0∞} {q : Rates}

/-- Line 1205: `λ_A > 0` gives `λ_C > 0`; indeed `λ_A ≤ λ_C`. -/
theorem e1_lambdaC_pos (hq : q.Admissible) (hA : 0 < q.lamA) : q.lamA ≤ q.lamC ∧ 0 < q.lamC := by
  obtain ⟨_, h2, _, h4, _, _⟩ := hq
  have : q.lamA ≤ q.lamC := by
    simp only [Rates.lamA, Rates.lamC]; nlinarith
  exact ⟨this, lt_of_lt_of_le hA this⟩

/-- **E1, first law.** `ω_C` is exponential with rate `λ_C`. -/
theorem e1_omegaC_exp (h : FirstArrivals μ τ q.rate) :
    HasExpSurvival μ (fun ω => omegaCOf (fun e => τ e ω)) q.lamC := by
  rw [← sum_commSet]; exact survival_inf h commSet

/-- **E1, second law.** `ω_A` is exponential with rate `λ_A`. -/
theorem e1_omegaA_exp (h : FirstArrivals μ τ q.rate) :
    HasExpSurvival μ (fun ω => omegaAOf (fun e => τ e ω)) q.lamA := by
  rw [← sum_attackSet]; exact survival_inf h attackSet

/-- **E1, ordering.** `ω_C ≤ ω_A` on every path (no probabilistic premise at all). -/
theorem e1_omegaC_le_omegaA (s : Ev → ℝ≥0∞) : omegaCOf s ≤ omegaAOf s :=
  Finset.inf_mono (by intro e he; simp [attackSet, commSet] at he ⊢; tauto)

/-- **E1, means of the first events.** `E[ω_C] = 1/λ_C`, `E[ω_A] = 1/λ_A`. -/
theorem e1_means (h : FirstArrivals μ τ q.rate) (hq : q.Admissible) (hA : 0 < q.lamA) :
    ∫⁻ ω, omegaCOf (fun e => τ e ω) ∂μ = ENNReal.ofReal (1 / q.lamC) ∧
    ∫⁻ ω, omegaAOf (fun e => τ e ω) ∂μ = ENNReal.ofReal (1 / q.lamA) := by
  have hS : Measurable (fun ω e => τ e ω) := measurable_pi_iff.mpr h.meas
  exact ⟨(e1_omegaC_exp h).lintegral_eq (measurable_omegaCOf.comp hS) (e1_lambdaC_pos hq hA).2,
    (e1_omegaA_exp h).lintegral_eq (measurable_omegaAOf.comp hS) hA⟩

/-- `ω_A < ∞` almost surely (used to read E2's real-valued windows). -/
theorem e1_omegaA_lt_top_ae (h : FirstArrivals μ τ q.rate) (hA : 0 < q.lamA) :
    ∀ᵐ ω ∂μ, omegaAOf (fun e => τ e ω) < ⊤ :=
  (e1_omegaA_exp h).ae_lt_top
    (measurable_omegaAOf.comp (measurable_pi_iff.mpr h.meas)) hA

/-- Line 1205: the two windows share events; they are dependent (whenever `λ_A > 0`). -/
theorem e1_windows_dependent (h : FirstArrivals μ τ q.rate) (hA : 0 < q.lamA) :
    ¬ IndepFun (fun ω => omegaCOf (fun e => τ e ω)) (fun ω => omegaAOf (fun e => τ e ω)) μ := by
  intro hind
  have hsub : (fun ω => omegaCOf (fun e => τ e ω)) ⁻¹' Ioi (ENNReal.ofReal 1) ∩
      (fun ω => omegaAOf (fun e => τ e ω)) ⁻¹' Ioi (ENNReal.ofReal 1) =
      {ω | ENNReal.ofReal 1 < omegaCOf (fun e => τ e ω)} := by
    ext ω
    simp only [mem_inter_iff, mem_preimage, mem_Ioi, mem_ofPred_eq, and_iff_left_iff_imp]
    exact fun h1 => lt_of_lt_of_le h1 (e1_omegaC_le_omegaA _)
  have hmul := hind.measure_inter_preimage_eq_mul _ _
    (measurableSet_Ioi (a := ENNReal.ofReal 1)) (measurableSet_Ioi (a := ENNReal.ofReal 1))
  rw [hsub] at hmul
  have hC := e1_omegaC_exp h 1 zero_le_one
  have hA' := e1_omegaA_exp h 1 zero_le_one
  simp only [Set.preimage, mem_Ioi] at hmul
  rw [hC, hA', ← ENNReal.ofReal_mul (Real.exp_pos _).le] at hmul
  have hreal := (ENNReal.ofReal_eq_ofReal_iff (Real.exp_pos _).le
    (mul_nonneg (Real.exp_pos _).le (Real.exp_pos _).le)).mp hmul
  have hpos := Real.exp_pos (-(q.lamC * 1))
  have hlt : Real.exp (-(q.lamA * 1)) < 1 := by
    have := Real.exp_lt_exp.mpr (show -(q.lamA * 1) < 0 by linarith)
    rwa [Real.exp_zero] at this
  nlinarith [hreal, hpos, hlt]

/-- The E1 roles of rival events (line 1236): open and failed-closed rival copies end both the
commercial lead and attacker exclusion; a working closed copy ends the commercial lead, and
`ω_A` does not depend on it. Content: definitional (the event sets). -/
theorem e1_event_roles (s : Ev → ℝ≥0∞) :
    omegaCOf s ≤ s .O ∧ omegaAOf s ≤ s .O ∧ omegaCOf s ≤ s .C1 ∧ omegaAOf s ≤ s .C1 ∧
    omegaCOf s ≤ s .C0 ∧
    ∀ s' : Ev → ℝ≥0∞, (∀ e, e ≠ .C0 → s e = s' e) → omegaAOf s = omegaAOf s' := by
  refine ⟨Finset.inf_le (by simp [commSet]), Finset.inf_le (by simp [attackSet]),
    Finset.inf_le (by simp [commSet]), Finset.inf_le (by simp [attackSet]),
    Finset.inf_le (by simp [commSet]), ?_⟩
  intro s' hs
  unfold omegaAOf
  apply Finset.inf_congr rfl
  intro e he
  apply hs
  intro hc; subst hc; simp [attackSet] at he

/-- The holder's initial actions (B.2.1, line 1207). -/
inductive Action
  | hold
  | openRel
  | closedRel
  deriving DecidableEq

/-- Date at which the holder's own action supplies a commercial substitute. -/
def holderCommDate : Action → ℝ≥0∞
  | .hold => ⊤
  | .openRel => 0
  | .closedRel => 0

/-- Date at which the holder's own action gives excluded attackers lasting capability.
`b = true` is `B_h = 1` (failed safeguards). Committed holding includes no later release (B-S2). -/
def holderAttackDate : Action → Bool → ℝ≥0∞
  | .hold, _ => ⊤
  | .openRel, _ => 0
  | .closedRel, b => if b then 0 else ⊤

/-- The commercial window (line 1211): until the first commercial substitute. -/
def WC (a : Action) (ωC : ℝ≥0∞) : ℝ≥0∞ := min ωC (holderCommDate a)

/-- The attacker-access window (line 1211): until excluded attackers obtain lasting capability. -/
def WA (a : Action) (b : Bool) (ωA : ℝ≥0∞) : ℝ≥0∞ := min ωA (holderAttackDate a b)

/-- **E1, the window table** (lines 1229–1234), derived from the window definitions. -/
theorem e1_window_table (ωC ωA : ℝ≥0∞) :
    (WC .hold ωC = ωC ∧ WA .hold false ωA = ωA ∧ WA .hold true ωA = ωA) ∧
    (WC .openRel ωC = 0 ∧ WA .openRel false ωA = 0 ∧ WA .openRel true ωA = 0) ∧
    (WC .closedRel ωC = 0 ∧ WA .closedRel false ωA = ωA) ∧
    (WC .closedRel ωC = 0 ∧ WA .closedRel true ωA = 0) := by
  simp [WC, WA, holderCommDate, holderAttackDate]

/-- **E1, `W_C ≤ W_A`** for every action, every safeguard outcome and every path. -/
theorem e1_WC_le_WA (a : Action) (b : Bool) (s : Ev → ℝ≥0∞) :
    WC a (omegaCOf s) ≤ WA a b (omegaAOf s) := by
  unfold WC WA
  apply min_le_min (e1_omegaC_le_omegaA s)
  cases a <;> cases b <;> simp [holderCommDate, holderAttackDate]

/-- **E1, means under holding**: `E[W_C] = 1/λ_C`, `E[W_A] = 1/λ_A`. -/
theorem e1_hold_means (h : FirstArrivals μ τ q.rate) (hq : q.Admissible) (hA : 0 < q.lamA)
    (B : Ω → Bool) :
    ∫⁻ ω, WC .hold (omegaCOf (fun e => τ e ω)) ∂μ = ENNReal.ofReal (1 / q.lamC) ∧
    ∫⁻ ω, WA .hold (B ω) (omegaAOf (fun e => τ e ω)) ∂μ = ENNReal.ofReal (1 / q.lamA) := by
  have hm := e1_means h hq hA
  have h1 : ∀ x : ℝ≥0∞, WC .hold x = x := fun x => by simp [WC, holderCommDate]
  have h2 : ∀ b x, WA .hold b x = x := fun b x => by simp [WA, holderAttackDate]
  simp only [h1, h2]; exact hm

omit [IsProbabilityMeasure μ] in
/-- Line 1238: immediate closed release with failure probability `p_h` puts mass at least `p_h`
on `W_A = 0`. -/
theorem e1_closed_atom (B : Ω → Bool) (s : Ω → Ev → ℝ≥0∞) :
    μ {ω | B ω = true} ≤ μ {ω | WA .closedRel (B ω) (omegaAOf (s ω)) = 0} :=
  measure_mono (fun ω hω => by
    simp only [mem_ofPred_eq] at hω ⊢; simp [WA, holderAttackDate, hω])

/-- Line 1238: with `p_h > 0`, the closed-release attacker window is not exponential at any
(substituted) rate `κ`. -/
theorem e1_closed_not_exponential {B : Ω → Bool} (hB : Measurable B) (s : Ω → Ev → ℝ≥0∞)
    (hp : 0 < μ {ω | B ω = true}) (κ : ℝ) :
    ¬ HasExpSurvival μ (fun ω => WA .closedRel (B ω) (omegaAOf (s ω))) κ := by
  intro hexp
  have h0 := hexp 0 le_rfl
  simp only [ENNReal.ofReal_zero, mul_zero, neg_zero, Real.exp_zero, ENNReal.ofReal_one] at h0
  have hmeas : MeasurableSet {ω | B ω = true} := hB (measurableSet_singleton true)
  have hsub : {ω | 0 < WA .closedRel (B ω) (omegaAOf (s ω))} ⊆ {ω | B ω = true}ᶜ := by
    intro ω hω
    simp only [mem_ofPred_eq, mem_compl_iff] at hω ⊢
    intro hb; simp [WA, holderAttackDate, hb] at hω
  have hle := measure_mono (μ := μ) hsub
  rw [h0, prob_compl_eq_one_sub hmeas] at hle
  have : (1 : ℝ≥0∞) - μ {ω | B ω = true} < 1 :=
    ENNReal.sub_lt_self ENNReal.one_ne_top one_ne_zero hp.ne'
  exact absurd hle (not_le.mpr this)

/-- B-S5 (line 1181): if theft armed attackers without supplying a commercial substitute, the
ordering `ω_C ≤ ω_A` could fail on a path. -/
theorem e1_covert_theft_breaks_order :
    ∃ s : Ev → ℝ≥0∞, attackSet.inf s < (commSet.erase .Th).inf s := by
  refine ⟨fun e => if e = .Th then 1 else 2, ?_⟩
  simp [attackSet, commSet]
  intro b hb _
  simp [hb]

end E1

/-! ## E2 -/

section E2

/-- The attacker date under holding, as a real (`W_H = ω_A`). -/
noncomputable def WH (S : Ω → Ev → ℝ≥0∞) (ω : Ω) : ℝ := (omegaAOf (S ω)).toReal

/-- The attacker date under immediate closed release, as a real. -/
noncomputable def Wcl (B : Ω → Bool) (S : Ω → Ev → ℝ≥0∞) (ω : Ω) : ℝ :=
  (WA .closedRel (B ω) (omegaAOf (S ω))).toReal

omit [MeasurableSpace Ω] in
/-- **E2, the mixture of windows** (line 1252): `W_cl = 0` if `B_h = 1`, `ω_A` otherwise. -/
theorem e2_Wcl_eq (B : Ω → Bool) (S : Ω → Ev → ℝ≥0∞) (ω : Ω) :
    Wcl B S ω = if B ω then 0 else WH S ω := by
  unfold Wcl WH WA holderAttackDate
  cases B ω <;> simp

/-- E2 (line 1250): a working safeguarded release ends the commercial window at once and leaves
the attacker window at `ω_A`. -/
theorem e2_working_release (s : Ev → ℝ≥0∞) :
    WC .closedRel (omegaCOf s) = 0 ∧ WA .closedRel false (omegaAOf s) = omegaAOf s :=
  ⟨(e1_window_table (omegaCOf s) (omegaAOf s)).2.2.1.1,
    (e1_window_table (omegaCOf s) (omegaAOf s)).2.2.1.2⟩

/-- Under the first-arrival premise with `λ_A > 0`, Lean's real window `W_H = ω_A.toReal` is the
paper's `ω_A` almost surely (the junk value `⊤.toReal = 0` lives on a null event). -/
theorem e2_WH_ae_eq {τ : Ev → Ω → ℝ≥0∞} {q : Rates} (h : FirstArrivals μ τ q.rate)
    (hA : 0 < q.lamA) :
    ∀ᵐ ω ∂μ, ENNReal.ofReal (WH (fun ω e => τ e ω) ω) = omegaAOf (fun e => τ e ω) := by
  filter_upwards [e1_omegaA_lt_top_ae h hA] with ω hω
  exact ENNReal.ofReal_toReal hω.ne

theorem measurable_WA_closed :
    Measurable (fun p : (Ev → ℝ≥0∞) × Bool => WA .closedRel p.2 (omegaAOf p.1)) :=
  (measurable_omegaAOf.comp measurable_fst).min
    ((measurable_of_countable (holderAttackDate .closedRel)).comp measurable_snd)

variable {Sch : Type*} [MeasurableSpace Sch]

/-- `p_h = P(B_h = 1)`. -/
noncomputable def ph (μ : Measure Ω) (B : Ω → Bool) : ℝ := μ.real {ω | B ω = true}

/-- `X_H = E[X(Σ_H, ω_A)]`. -/
noncomputable def XH (μ : Measure Ω) (X : Sch → ℝ → ℝ) (sigH : Ω → Sch)
    (S : Ω → Ev → ℝ≥0∞) : ℝ :=
  ∫ ω, X (sigH ω) (WH S ω) ∂μ

/-- `X_cl = E[X(Σ_cl, W_cl)]`. -/
noncomputable def Xcl (μ : Measure Ω) (X : Sch → ℝ → ℝ) (sigCl : Ω → Sch) (B : Ω → Bool)
    (S : Ω → Ev → ℝ≥0∞) : ℝ :=
  ∫ ω, X (sigCl ω) (Wcl B S ω) ∂μ

/-- `S_H = E[X(Σ_H, 0) − X(Σ_H, ω_A)]`. -/
noncomputable def SH (μ : Measure Ω) (X : Sch → ℝ → ℝ) (sigH : Ω → Sch)
    (S : Ω → Ev → ℝ≥0∞) : ℝ :=
  ∫ ω, (X (sigH ω) 0 - X (sigH ω) (WH S ω)) ∂μ

/-- `S_H` as an extended nonnegative expectation, `E[(X(Σ_H, 0) − X(Σ_H, ω_A))⁺] ∈ [0, ∞]`. For
an exposure antitone in the window the integrand is already nonnegative, so this is the paper's
`S_H` with no integrability presupposed; it may be `∞`. -/
noncomputable def SHext (μ : Measure Ω) (X : Sch → ℝ → ℝ) (sigH : Ω → Sch)
    (S : Ω → Ev → ℝ≥0∞) : ℝ≥0∞ :=
  ∫⁻ ω, ENNReal.ofReal (X (sigH ω) 0 - X (sigH ω) (WH S ω)) ∂μ

/-- `Γ_def = E[X(Σ_H, W_cl) − X(Σ_cl, W_cl)]`. -/
noncomputable def Gdef (μ : Measure Ω) (X : Sch → ℝ → ℝ) (sigH sigCl : Ω → Sch) (B : Ω → Bool)
    (S : Ω → Ev → ℝ≥0∞) : ℝ :=
  ∫ ω, (X (sigH ω) (Wcl B S ω) - X (sigCl ω) (Wcl B S ω)) ∂μ

/-- The paper's independence premises (lines 1207, 1221) imply that `B_h` is independent of the
pair (schedule, stream vector) jointly — not merely of each separately. -/
theorem e2_joint_indep {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sig : Ω → Sch}
    (hB : Measurable B) (hS : Measurable S) (hsig : Measurable sig)
    (hBS : IndepFun B S μ) (hsSB : IndepFun sig (fun ω => (S ω, B ω)) μ) :
    IndepFun B (fun ω => (sig ω, S ω)) μ := by
  have hsS : IndepFun sig S μ := by
    have := hsSB.comp measurable_id measurable_fst
    simpa [Function.comp_def] using this
  rw [indepFun_iff_map_prod_eq_prod_map_map hB.aemeasurable (hsig.prodMk hS).aemeasurable,
    (indepFun_iff_map_prod_eq_prod_map_map hsig.aemeasurable hS.aemeasurable).mp hsS]
  have h1 := (indepFun_iff_map_prod_eq_prod_map_map hsig.aemeasurable
    (hS.prodMk hB).aemeasurable).mp hsSB
  rw [(indepFun_iff_map_prod_eq_prod_map_map hS.aemeasurable hB.aemeasurable).mp hBS.symm] at h1
  -- rearrange `(σ, (s, b)) ↦ (b, (σ, s))`
  let g : Sch × ((Ev → ℝ≥0∞) × Bool) → Bool × (Sch × (Ev → ℝ≥0∞)) :=
    fun p => (p.2.2, (p.1, p.2.1))
  have hg : Measurable g :=
    (measurable_snd.snd).prodMk (measurable_fst.prodMk measurable_snd.fst)
  have hcomp : (fun ω => (B ω, (sig ω, S ω))) = g ∘ (fun ω => (sig ω, (S ω, B ω))) := rfl
  rw [hcomp, ← Measure.map_map hg (hsig.prodMk (hS.prodMk hB)), h1]
  have hmp : MeasurePreserving (Prod.swap ∘ (MeasurableEquiv.prodAssoc.symm))
      ((μ.map sig).prod ((μ.map S).prod (μ.map B)))
      ((μ.map B).prod ((μ.map sig).prod (μ.map S))) :=
    Measure.measurePreserving_swap.comp
      ((measurePreserving_prodAssoc (μ.map sig) (μ.map S) (μ.map B)).symm _)
  have hgeq : g = Prod.swap ∘ (MeasurableEquiv.prodAssoc.symm) := by
    funext p; rfl
  rw [hgeq]; exact hmp.map_eq

omit [MeasurableSpace Ω] [MeasurableSpace Sch] in
/-- Pathwise form of the release window: `X(Σ, W_cl)` splits on `B_h`. -/
theorem e2_split (X : Sch → ℝ → ℝ) (B : Ω → Bool) (S : Ω → Ev → ℝ≥0∞) (sig : Ω → Sch) :
    (fun ω => X (sig ω) (Wcl B S ω)) =
      {ω | B ω = true}.indicator (fun ω => X (sig ω) 0) +
      {ω | B ω = true}ᶜ.indicator (fun ω => X (sig ω) (WH S ω)) := by
  funext ω
  simp only [Pi.add_apply, Set.indicator, mem_compl_iff, mem_ofPred_eq, e2_Wcl_eq]
  cases B ω <;> simp

/-- **E2, the mixture of expectations** (line 1297):
`E[X(Σ_H, W_cl)] = p_h E[X(Σ_H, 0)] + (1 − p_h) E[X(Σ_H, ω_A)]`, from the paper's
independence premises. -/
theorem e2_mixture {X : Sch → ℝ → ℝ} (hX : Measurable (Function.uncurry X))
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH : Ω → Sch}
    (hB : Measurable B) (hS : Measurable S) (hsig : Measurable sigH)
    (hBS : IndepFun B S μ) (hsSB : IndepFun sigH (fun ω => (S ω, B ω)) μ)
    (hI0 : Integrable (fun ω => X (sigH ω) 0) μ)
    (hI1 : Integrable (fun ω => X (sigH ω) (WH S ω)) μ) :
    ∫ ω, X (sigH ω) (Wcl B S ω) ∂μ =
      ph μ B * ∫ ω, X (sigH ω) 0 ∂μ + (1 - ph μ B) * XH μ X sigH S := by
  have hJ := e2_joint_indep hB hS hsig hBS hsSB
  let φ1 : Bool → ℝ := fun b => if b then 1 else 0
  let φ0 : Bool → ℝ := fun b => if b then 0 else 1
  let ψ1 : Sch × (Ev → ℝ≥0∞) → ℝ := fun p => X p.1 0
  let ψ0 : Sch × (Ev → ℝ≥0∞) → ℝ := fun p => X p.1 (omegaAOf p.2).toReal
  have hψ1 : Measurable ψ1 := hX.comp (measurable_fst.prodMk measurable_const)
  have hψ0 : Measurable ψ0 :=
    hX.comp (measurable_fst.prodMk ((measurable_omegaAOf.comp measurable_snd).ennreal_toReal))
  have hφ1 : Measurable φ1 := measurable_of_countable _
  have hφ0 : Measurable φ0 := measurable_of_countable _
  have hpair : Measurable fun ω => (sigH ω, S ω) := hsig.prodMk hS
  have hmeas : MeasurableSet {ω | B ω = true} := hB (measurableSet_singleton true)
  have p1 : (φ1 ∘ B) * (ψ1 ∘ fun ω => (sigH ω, S ω)) =
      {ω | B ω = true}.indicator (fun ω => X (sigH ω) 0) := by
    funext ω; simp only [Pi.mul_apply, Function.comp_apply, φ1, ψ1, Set.indicator, mem_ofPred_eq]
    cases B ω <;> simp
  have p0 : (φ0 ∘ B) * (ψ0 ∘ fun ω => (sigH ω, S ω)) =
      {ω | B ω = true}ᶜ.indicator (fun ω => X (sigH ω) (WH S ω)) := by
    funext ω; simp only [Pi.mul_apply, Function.comp_apply, φ0, ψ0, Set.indicator, mem_compl_iff,
      mem_ofPred_eq, WH]
    cases B ω <;> simp
  have i1 := IndepFun.integral_mul_eq_mul_integral (hJ.comp hφ1 hψ1)
    (hφ1.comp hB).aestronglyMeasurable (hψ1.comp hpair).aestronglyMeasurable
  have i0 := IndepFun.integral_mul_eq_mul_integral (hJ.comp hφ0 hψ0)
    (hφ0.comp hB).aestronglyMeasurable (hψ0.comp hpair).aestronglyMeasurable
  rw [p1] at i1
  rw [p0] at i0
  have hind1 : (φ1 ∘ B) = {ω | B ω = true}.indicator 1 := by
    funext ω; simp only [Function.comp_apply, φ1, Set.indicator, mem_ofPred_eq, Pi.one_apply]
  have e1 : ∫ ω, (φ1 ∘ B) ω ∂μ = ph μ B := by
    rw [hind1, integral_indicator_one hmeas]; rfl
  have e0 : ∫ ω, (φ0 ∘ B) ω ∂μ = 1 - ph μ B := by
    have : (φ0 ∘ B) = fun ω => 1 - (φ1 ∘ B) ω := by
      funext ω; simp only [Function.comp_apply, φ1, φ0]; cases B ω <;> simp
    have hint : Integrable (φ1 ∘ B) μ := by
      rw [hind1]; exact (integrable_const (1 : ℝ)).indicator hmeas
    rw [this, integral_sub (integrable_const 1) hint, integral_const, e1]
    simp
  rw [e2_split, integral_add' (hI0.indicator hmeas) (hI1.indicator hmeas.compl), i1, i0, e1, e0]
  rfl

omit [IsProbabilityMeasure μ] [MeasurableSpace Sch] in
/-- Integrability of `X(Σ_H, W_cl)` follows from that of its two branches. -/
theorem e2_integrable_mix {X : Sch → ℝ → ℝ} {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞}
    {sigH : Ω → Sch} (hB : Measurable B)
    (hI0 : Integrable (fun ω => X (sigH ω) 0) μ)
    (hI1 : Integrable (fun ω => X (sigH ω) (WH S ω)) μ) :
    Integrable (fun ω => X (sigH ω) (Wcl B S ω)) μ := by
  have hmeas : MeasurableSet {ω | B ω = true} := hB (measurableSet_singleton true)
  rw [e2_split]; exact (hI0.indicator hmeas).add (hI1.indicator hmeas.compl)

/-- **E2, the decomposition** (line 1254): `X_cl − X_H = p_h S_H − Γ_def`. -/
theorem e2_decomposition {X : Sch → ℝ → ℝ} (hX : Measurable (Function.uncurry X))
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Sch}
    (hB : Measurable B) (hS : Measurable S) (hsig : Measurable sigH)
    (hBS : IndepFun B S μ) (hsSB : IndepFun sigH (fun ω => (S ω, B ω)) μ)
    (hI0 : Integrable (fun ω => X (sigH ω) 0) μ)
    (hI1 : Integrable (fun ω => X (sigH ω) (WH S ω)) μ)
    (hIcl : Integrable (fun ω => X (sigCl ω) (Wcl B S ω)) μ) :
    Xcl μ X sigCl B S - XH μ X sigH S = ph μ B * SH μ X sigH S - Gdef μ X sigH sigCl B S := by
  have hmix := e2_mixture hX hB hS hsig hBS hsSB hI0 hI1
  unfold SH Gdef
  rw [integral_sub hI0 hI1, integral_sub (e2_integrable_mix hB hI0 hI1) hIcl, hmix]
  unfold XH Xcl; ring

omit [IsProbabilityMeasure μ] [MeasurableSpace Sch] in
/-- **E2, `S_H ≥ 0`** (line 1254): any exposure non-increasing in the window. -/
theorem e2_SH_nonneg {X : Sch → ℝ → ℝ} {sigH : Ω → Sch} {S : Ω → Ev → ℝ≥0∞}
    (hanti : ∀ ω, Antitone (X (sigH ω))) : 0 ≤ SH μ X sigH S :=
  integral_nonneg (fun ω => sub_nonneg.mpr (hanti ω ENNReal.toReal_nonneg))

/-- **E2, `Γ_def = 0` under identical schedule distributions** (lines 1256, 1299), each
independent of the complete stream vector and `B_h`; the schedules need not coincide pathwise. -/
theorem e2_gamma_zero {X : Sch → ℝ → ℝ} (hX : Measurable (Function.uncurry X))
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Sch}
    (hB : Measurable B) (hS : Measurable S) (hH : Measurable sigH) (hC : Measurable sigCl)
    (hlaw : μ.map sigH = μ.map sigCl)
    (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ) (hCi : IndepFun sigCl (fun ω => (S ω, B ω)) μ)
    (hImix : Integrable (fun ω => X (sigH ω) (Wcl B S ω)) μ)
    (hIcl : Integrable (fun ω => X (sigCl ω) (Wcl B S ω)) μ) :
    Gdef μ X sigH sigCl B S = 0 := by
  have hV : Measurable fun ω => (S ω, B ω) := hS.prodMk hB
  let F : Sch × ((Ev → ℝ≥0∞) × Bool) → ℝ :=
    fun p => X p.1 (WA .closedRel p.2.2 (omegaAOf p.2.1)).toReal
  have hF : Measurable F :=
    hX.comp (measurable_fst.prodMk (measurable_WA_closed.comp measurable_snd).ennreal_toReal)
  have hmapH := (indepFun_iff_map_prod_eq_prod_map_map hH.aemeasurable hV.aemeasurable).mp hHi
  have hmapC := (indepFun_iff_map_prod_eq_prod_map_map hC.aemeasurable hV.aemeasurable).mp hCi
  have h1 : ∫ ω, X (sigH ω) (Wcl B S ω) ∂μ =
      ∫ p, F p ∂(μ.map (fun ω => (sigH ω, (S ω, B ω)))) :=
    (integral_map (hH.prodMk hV).aemeasurable hF.aestronglyMeasurable).symm
  have h2 : ∫ ω, X (sigCl ω) (Wcl B S ω) ∂μ =
      ∫ p, F p ∂(μ.map (fun ω => (sigCl ω, (S ω, B ω)))) :=
    (integral_map (hC.prodMk hV).aemeasurable hF.aestronglyMeasurable).symm
  unfold Gdef
  rw [integral_sub hImix hIcl, h1, h2, hmapH, hmapC, hlaw, sub_self]

/-- Under identical schedule laws, each independent of (streams, `B_h`), finite `X_cl` gives
finite expected exposure of `Σ_H` at the release window: the two have the same law. -/
theorem e2_integrable_transfer {X : Sch → ℝ → ℝ} (hX : Measurable (Function.uncurry X))
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Sch}
    (hB : Measurable B) (hS : Measurable S) (hH : Measurable sigH) (hC : Measurable sigCl)
    (hlaw : μ.map sigH = μ.map sigCl)
    (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ) (hCi : IndepFun sigCl (fun ω => (S ω, B ω)) μ)
    (hIcl : Integrable (fun ω => X (sigCl ω) (Wcl B S ω)) μ) :
    Integrable (fun ω => X (sigH ω) (Wcl B S ω)) μ := by
  have hV : Measurable fun ω => (S ω, B ω) := hS.prodMk hB
  let F : Sch × ((Ev → ℝ≥0∞) × Bool) → ℝ :=
    fun p => X p.1 (WA .closedRel p.2.2 (omegaAOf p.2.1)).toReal
  have hF : Measurable F :=
    hX.comp (measurable_fst.prodMk (measurable_WA_closed.comp measurable_snd).ennreal_toReal)
  have hmapH := (indepFun_iff_map_prod_eq_prod_map_map hH.aemeasurable hV.aemeasurable).mp hHi
  have hmapC := (indepFun_iff_map_prod_eq_prod_map_map hC.aemeasurable hV.aemeasurable).mp hCi
  have hC' : Integrable F (μ.map (fun ω => (sigCl ω, (S ω, B ω)))) :=
    (integrable_map_measure hF.aestronglyMeasurable (hC.prodMk hV).aemeasurable).mpr hIcl
  rw [hmapC, ← hlaw, ← hmapH] at hC'
  exact (integrable_map_measure hF.aestronglyMeasurable (hH.prodMk hV).aemeasurable).mp hC'

omit [IsProbabilityMeasure μ] in
/-- If `p_h > 0`, finite expected exposure of `Σ_H` at the release window forces
`E|X(Σ_H, 0)| < ∞`: on `{B_h = 1}` the two coincide, and `B_h` is independent of `Σ_H`, so
`E[1_{B_h} |X(Σ_H, 0)|] = p_h E|X(Σ_H, 0)|`. -/
theorem e2_integrable_zero {X : Sch → ℝ → ℝ} (hX : Measurable (Function.uncurry X))
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH : Ω → Sch}
    (hB : Measurable B) (hH : Measurable sigH)
    (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ) (hp : 0 < ph μ B)
    (hImix : Integrable (fun ω => X (sigH ω) (Wcl B S ω)) μ) :
    Integrable (fun ω => X (sigH ω) 0) μ := by
  have hmeas : MeasurableSet {ω | B ω = true} := hB (measurableSet_singleton true)
  have hf : Measurable (fun ω => X (sigH ω) 0) := hX.comp (hH.prodMk measurable_const)
  have hBi : IndepFun B sigH μ := by
    have := (hHi.comp measurable_id measurable_snd).symm
    simpa [Function.comp_def] using this
  have hind : Integrable ({ω | B ω = true}.indicator (fun ω => X (sigH ω) 0)) μ := by
    have hI := hImix.indicator hmeas
    have heq : {ω | B ω = true}.indicator (fun ω => X (sigH ω) 0) =
        {ω | B ω = true}.indicator (fun ω => X (sigH ω) (Wcl B S ω)) := by
      funext ω
      simp only [Set.indicator, mem_ofPred_eq, e2_Wcl_eq]
      cases B ω <;> simp
    rw [heq]; exact hI
  refine ⟨hf.aestronglyMeasurable, ?_⟩
  let φ : Bool → ℝ≥0∞ := fun b => if b then 1 else 0
  let ψ : Sch → ℝ≥0∞ := fun σ => ‖X σ 0‖ₑ
  have hφ : Measurable φ := measurable_of_countable _
  have hψ : Measurable ψ := (hX.comp (measurable_id.prodMk measurable_const)).enorm
  have hmul := lintegral_mul_eq_lintegral_mul_lintegral_of_indepFun (hφ.comp hB) (hψ.comp hH)
    (hBi.comp hφ hψ)
  have e1 : (φ ∘ B) * (ψ ∘ sigH) =
      fun ω => ‖{ω | B ω = true}.indicator (fun ω => X (sigH ω) 0) ω‖ₑ := by
    funext ω
    simp only [Pi.mul_apply, Function.comp_apply, φ, ψ, Set.indicator, mem_ofPred_eq]
    cases B ω <;> simp
  have e2 : ∫⁻ ω, (φ ∘ B) ω ∂μ = μ {ω | B ω = true} := by
    have : (φ ∘ B) = {ω | B ω = true}.indicator 1 := by
      funext ω; simp only [Function.comp_apply, φ, Set.indicator, mem_ofPred_eq, Pi.one_apply]
    rw [this, lintegral_indicator_one hmeas]
  rw [e1, e2] at hmul
  have hfin := hind.2
  unfold HasFiniteIntegral at hfin
  rw [hmul] at hfin
  have hpos : μ {ω | B ω = true} ≠ 0 := by
    intro h0
    rw [ph, measureReal_def, h0, ENNReal.toReal_zero] at hp
    exact lt_irrefl _ hp
  rcases ENNReal.mul_lt_top_iff.mp hfin with h | h | h
  · exact h.2
  · exact absurd h hpos
  · exact (show ∫⁻ ω, (ψ ∘ sigH) ω ∂μ < ⊤ by rw [h]; exact ENNReal.zero_lt_top)

/-- **E2, the sign results** (line 1256), for any measurable exposure antitone in the window:
the decomposition, `S_H ≥ 0`, and "release lowers exposure exactly when `Γ_def > p_h S_H`".
Content of the last: algebraic, from the decomposition of the model's objects. -/
theorem e2_generic {X : Sch → ℝ → ℝ} (hX : Measurable (Function.uncurry X))
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Sch}
    (hB : Measurable B) (hS : Measurable S) (hH : Measurable sigH)
    (hanti : ∀ ω, Antitone (X (sigH ω)))
    (hBS : IndepFun B S μ) (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ)
    (hI0 : Integrable (fun ω => X (sigH ω) 0) μ)
    (hI1 : Integrable (fun ω => X (sigH ω) (WH S ω)) μ)
    (hIcl : Integrable (fun ω => X (sigCl ω) (Wcl B S ω)) μ) :
    (Xcl μ X sigCl B S - XH μ X sigH S = ph μ B * SH μ X sigH S - Gdef μ X sigH sigCl B S) ∧
    0 ≤ SH μ X sigH S ∧
    (Xcl μ X sigCl B S < XH μ X sigH S ↔ ph μ B * SH μ X sigH S < Gdef μ X sigH sigCl B S) := by
  have hd := e2_decomposition hX hB hS hH hBS hHi hI0 hI1 hIcl
  refine ⟨hd, e2_SH_nonneg hanti, ?_⟩
  constructor <;> intro h <;> linarith

/-- **E2 with unchanged schedule law** (line 1256): `Γ_def = 0`; release weakly raises
outsiders' exposure; strictly exactly when `p_h S_H > 0`; with perfectly working safeguards
(`p_h = 0`) exposure is equal. Only `X_H` and `X_cl` are assumed finite: `E|X(Σ_H, 0)| < ∞` is
derived when `p_h > 0` (`e2_integrable_zero`), and is not needed when `p_h = 0`. Caveat on the
third conjunct: `SH` is a Bochner integral, so when `p_h = 0` and `X(Σ_H, 0)` is not integrable
it reads a junk `0` where the paper's `S_H` is `+∞`. The strictness certificates are
`e2_identical_strict` (with `hI0`) and `e2_identical_strict_ext` (extended `S_H`). -/
theorem e2_generic_identical {X : Sch → ℝ → ℝ} (hX : Measurable (Function.uncurry X))
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Sch}
    (hB : Measurable B) (hS : Measurable S) (hH : Measurable sigH) (hC : Measurable sigCl)
    (hanti : ∀ ω, Antitone (X (sigH ω)))
    (hBS : IndepFun B S μ) (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ)
    (hCi : IndepFun sigCl (fun ω => (S ω, B ω)) μ) (hlaw : μ.map sigH = μ.map sigCl)
    (hI1 : Integrable (fun ω => X (sigH ω) (WH S ω)) μ)
    (hIcl : Integrable (fun ω => X (sigCl ω) (Wcl B S ω)) μ) :
    Gdef μ X sigH sigCl B S = 0 ∧
    XH μ X sigH S ≤ Xcl μ X sigCl B S ∧
    (XH μ X sigH S < Xcl μ X sigCl B S ↔ 0 < ph μ B * SH μ X sigH S) ∧
    (ph μ B = 0 → Xcl μ X sigCl B S = XH μ X sigH S) := by
  have hImix := e2_integrable_transfer hX hB hS hH hC hlaw hHi hCi hIcl
  have hG := e2_gamma_zero hX hB hS hH hC hlaw hHi hCi hImix hIcl
  have hSH := e2_SH_nonneg (μ := μ) (S := S) hanti
  have hp : 0 ≤ ph μ B := measureReal_nonneg
  have hd : Xcl μ X sigCl B S - XH μ X sigH S = ph μ B * SH μ X sigH S := by
    rcases hp.lt_or_eq with hpos | hzero
    · have hI0 := e2_integrable_zero hX hB hH hHi hpos hImix
      have h := e2_decomposition hX hB hS hH hBS hHi hI0 hI1 hIcl
      rw [hG, sub_zero] at h; exact h
    · -- `B_h = 0` almost surely, so the release window is `ω_A` almost surely
      have hnull : μ {ω | B ω = true} = 0 := by
        have h0 : (μ {ω | B ω = true}).toReal = 0 := hzero.symm
        rcases (ENNReal.toReal_eq_zero_iff _).mp h0 with h | h
        · exact h
        · exact absurd h (measure_ne_top _ _)
      have hBf : ∀ᵐ ω ∂μ, B ω ≠ true := ae_iff.mpr (by simpa using hnull)
      have hae : (fun ω => X (sigH ω) (Wcl B S ω)) =ᵐ[μ] fun ω => X (sigH ω) (WH S ω) := by
        filter_upwards [hBf] with ω hω
        rw [e2_Wcl_eq]; simp [hω]
      have hmixeq : ∫ ω, X (sigH ω) (Wcl B S ω) ∂μ = XH μ X sigH S := integral_congr_ae hae
      unfold Gdef at hG
      rw [integral_sub hImix hIcl, hmixeq] at hG
      rw [← hzero, zero_mul]; unfold Xcl; linarith
  refine ⟨hG, by nlinarith [mul_nonneg hp hSH], ?_, fun h0 => by rw [h0, zero_mul] at hd; linarith⟩
  constructor <;> intro h <;> linarith

/-- **E2 strictness, `S_H` a genuine finite expectation** (line 1256). With `E|X(Σ_H, 0)| < ∞`
(`hI0`, supplied by the second sentence of the 1221 text fix) the integrand of `S_H` is
integrable, `S_H = E[X(Σ_H, 0)] − X_H` is the paper's finite `S_H`, and release raises exposure
strictly exactly when `p_h S_H > 0`. -/
theorem e2_identical_strict {X : Sch → ℝ → ℝ} (hX : Measurable (Function.uncurry X))
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Sch}
    (hB : Measurable B) (hS : Measurable S) (hH : Measurable sigH) (hC : Measurable sigCl)
    (hanti : ∀ ω, Antitone (X (sigH ω)))
    (hBS : IndepFun B S μ) (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ)
    (hCi : IndepFun sigCl (fun ω => (S ω, B ω)) μ) (hlaw : μ.map sigH = μ.map sigCl)
    (hI0 : Integrable (fun ω => X (sigH ω) 0) μ)
    (hI1 : Integrable (fun ω => X (sigH ω) (WH S ω)) μ)
    (hIcl : Integrable (fun ω => X (sigCl ω) (Wcl B S ω)) μ) :
    Integrable (fun ω => X (sigH ω) 0 - X (sigH ω) (WH S ω)) μ ∧
    SH μ X sigH S = ∫ ω, X (sigH ω) 0 ∂μ - XH μ X sigH S ∧
    (XH μ X sigH S < Xcl μ X sigCl B S ↔ 0 < ph μ B * SH μ X sigH S) :=
  ⟨hI0.sub hI1, by unfold SH XH; exact integral_sub hI0 hI1,
    (e2_generic_identical hX hB hS hH hC hanti hBS hHi hCi hlaw hI1 hIcl).2.2.1⟩

/-- **E2 strictness for the extended `S_H`** (line 1256), with no integrability beyond finite
`X_H` and `X_cl`: release raises exposure strictly exactly when `p_h S_H > 0` in `[0, ∞]`, under
the measure-theoretic convention `0 · ∞ = 0` that `ℝ≥0∞` multiplication uses. -/
theorem e2_identical_strict_ext {X : Sch → ℝ → ℝ} (hX : Measurable (Function.uncurry X))
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Sch}
    (hB : Measurable B) (hS : Measurable S) (hH : Measurable sigH) (hC : Measurable sigCl)
    (hanti : ∀ ω, Antitone (X (sigH ω)))
    (hBS : IndepFun B S μ) (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ)
    (hCi : IndepFun sigCl (fun ω => (S ω, B ω)) μ) (hlaw : μ.map sigH = μ.map sigCl)
    (hI1 : Integrable (fun ω => X (sigH ω) (WH S ω)) μ)
    (hIcl : Integrable (fun ω => X (sigCl ω) (Wcl B S ω)) μ) :
    XH μ X sigH S < Xcl μ X sigCl B S ↔ 0 < ENNReal.ofReal (ph μ B) * SHext μ X sigH S := by
  have g := e2_generic_identical hX hB hS hH hC hanti hBS hHi hCi hlaw hI1 hIcl
  have hp : 0 ≤ ph μ B := measureReal_nonneg
  rcases hp.lt_or_eq with hpos | hzero
  · have hImix := e2_integrable_transfer hX hB hS hH hC hlaw hHi hCi hIcl
    have hI0 := e2_integrable_zero hX hB hH hHi hpos hImix
    have hnn : 0 ≤ᵐ[μ] fun ω => X (sigH ω) 0 - X (sigH ω) (WH S ω) :=
      Filter.Eventually.of_forall fun ω => sub_nonneg.mpr (hanti ω ENNReal.toReal_nonneg)
    have hext : SHext μ X sigH S = ENNReal.ofReal (SH μ X sigH S) :=
      (ofReal_integral_eq_lintegral_ofReal (hI0.sub hI1) hnn).symm
    rw [g.2.2.1, hext, ← ENNReal.ofReal_mul hp, ENNReal.ofReal_pos]
  · have heq := g.2.2.2 hzero.symm
    rw [← hzero, ENNReal.ofReal_zero, zero_mul, heq]
    simp

omit [IsProbabilityMeasure μ] [MeasurableSpace Sch] in
/-- B-S6 (line 1182; body line 396): an added attack-enabling hazard, or any other event that can
only shorten the access window (B-S2, line 1178), raises exposure weakly at a fixed schedule. -/
theorem e2_shorter_window_raises {X : Sch → ℝ → ℝ} {sig : Ω → Sch}
    (hanti : ∀ ω, Antitone (X (sig ω))) {W W' : Ω → ℝ} (hle : ∀ᵐ ω ∂μ, W' ω ≤ W ω)
    (hI : Integrable (fun ω => X (sig ω) (W ω)) μ)
    (hI' : Integrable (fun ω => X (sig ω) (W' ω)) μ) :
    ∫ ω, X (sig ω) (W ω) ∂μ ≤ ∫ ω, X (sig ω) (W' ω) ∂μ :=
  integral_mono_ae hI hI' (hle.mono fun ω h => hanti ω h)

omit [MeasurableSpace Ω] in
/-- An added attack-enabling arrival `τ'` gives the window `min(W, τ')`, which is no longer than
`W` wherever `W` is finite (almost surely, by `e1_omegaA_lt_top_ae`). -/
theorem e2_added_event_shortens (W τ' : ℝ≥0∞) (hW : W ≠ ⊤) :
    (min W τ').toReal ≤ W.toReal :=
  ENNReal.toReal_mono hW (min_le_left _ _)

omit [MeasurableSpace Sch] in
/-- **B-S6, composed** (line 1182): an added attack-enabling arrival `τ'` (any random time) turns
the holding window into `min(ω_A, τ')`, and at a fixed schedule this weakly raises expected
exposure. Conditional on the first-arrival premise with `λ_A > 0`, which makes `ω_A` finite
almost surely; on `{ω_A = ∞}` the real junk value would reverse the step. -/
theorem e2_added_hazard_raises {X : Sch → ℝ → ℝ} {sig : Ω → Sch}
    (hanti : ∀ ω, Antitone (X (sig ω))) {τ : Ev → Ω → ℝ≥0∞} {q : Rates}
    (h : FirstArrivals μ τ q.rate) (hA : 0 < q.lamA) (τ' : Ω → ℝ≥0∞)
    (hI : Integrable (fun ω => X (sig ω) (WH (fun ω e => τ e ω) ω)) μ)
    (hI' : Integrable (fun ω => X (sig ω) (min (omegaAOf (fun e => τ e ω)) (τ' ω)).toReal) μ) :
    ∫ ω, X (sig ω) (WH (fun ω e => τ e ω) ω) ∂μ ≤
      ∫ ω, X (sig ω) (min (omegaAOf (fun e => τ e ω)) (τ' ω)).toReal ∂μ :=
  e2_shorter_window_raises hanti
    ((e1_omegaA_lt_top_ae h hA).mono fun _ hω => e2_added_event_shortens _ _ hω.ne) hI hI'

/-! ### The paper's exposure (lines 1213–1221) -/

/-- A defensive schedule `Σ` (line 1213), for patched flaw–operator pairs `P` and unfound
flaw–operator pairs `U`. -/
structure Schedule (P U : Type*) where
  /-- `P_f`, patch publication. -/
  pub : P → ℝ
  /-- `τ_fj`, deployment time after publication. -/
  dep : P → ℝ
  /-- `d_f`, excluded attackers' discovery time after access. -/
  disc : P → ℝ
  /-- `d_f^π`, discovery by attackers already holding access. -/
  discPi : P → ℝ
  /-- operator/flaw weight (nonnegative when admissible). -/
  w : P → ℝ
  /-- `ℓ_x`, the common patch-to-exploit lag. -/
  lag : ℝ
  /-- `ζ_j`, removal date. -/
  rem : U → ℝ
  /-- `d_f` for an unfound flaw. -/
  udisc : U → ℝ
  /-- `d_f^π` for an unfound flaw. -/
  udiscPi : U → ℝ
  /-- weight of an unfound pair. -/
  uw : U → ℝ

variable {P U : Type*}

/-- The data of a schedule as a tuple, to give schedules their product measurable structure. -/
def Schedule.toTuple (σ : Schedule P U) :
    (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × ℝ × (U → ℝ) × (U → ℝ) × (U → ℝ) × (U → ℝ) :=
  (σ.pub, σ.dep, σ.disc, σ.discPi, σ.w, σ.lag, σ.rem, σ.udisc, σ.udiscPi, σ.uw)

instance : MeasurableSpace (Schedule P U) := MeasurableSpace.comap Schedule.toTuple inferInstance

section fields
variable (P U)
@[fun_prop] theorem measurable_pub : Measurable (fun σ : Schedule P U => σ.pub) :=
  (by fun_prop : Measurable fun t : (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × ℝ ×
    (U → ℝ) × (U → ℝ) × (U → ℝ) × (U → ℝ) => t.1).comp (comap_measurable _)
@[fun_prop] theorem measurable_dep : Measurable (fun σ : Schedule P U => σ.dep) :=
  (by fun_prop : Measurable fun t : (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × ℝ ×
    (U → ℝ) × (U → ℝ) × (U → ℝ) × (U → ℝ) => t.2.1).comp (comap_measurable _)
@[fun_prop] theorem measurable_disc : Measurable (fun σ : Schedule P U => σ.disc) :=
  (by fun_prop : Measurable fun t : (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × ℝ ×
    (U → ℝ) × (U → ℝ) × (U → ℝ) × (U → ℝ) => t.2.2.1).comp (comap_measurable _)
@[fun_prop] theorem measurable_discPi : Measurable (fun σ : Schedule P U => σ.discPi) :=
  (by fun_prop : Measurable fun t : (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × ℝ ×
    (U → ℝ) × (U → ℝ) × (U → ℝ) × (U → ℝ) => t.2.2.2.1).comp (comap_measurable _)
@[fun_prop] theorem measurable_w : Measurable (fun σ : Schedule P U => σ.w) :=
  (by fun_prop : Measurable fun t : (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × ℝ ×
    (U → ℝ) × (U → ℝ) × (U → ℝ) × (U → ℝ) => t.2.2.2.2.1).comp (comap_measurable _)
@[fun_prop] theorem measurable_lag : Measurable (fun σ : Schedule P U => σ.lag) :=
  (by fun_prop : Measurable fun t : (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × ℝ ×
    (U → ℝ) × (U → ℝ) × (U → ℝ) × (U → ℝ) => t.2.2.2.2.2.1).comp (comap_measurable _)
@[fun_prop] theorem measurable_rem : Measurable (fun σ : Schedule P U => σ.rem) :=
  (by fun_prop : Measurable fun t : (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × ℝ ×
    (U → ℝ) × (U → ℝ) × (U → ℝ) × (U → ℝ) => t.2.2.2.2.2.2.1).comp (comap_measurable _)
@[fun_prop] theorem measurable_udisc : Measurable (fun σ : Schedule P U => σ.udisc) :=
  (by fun_prop : Measurable fun t : (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × ℝ ×
    (U → ℝ) × (U → ℝ) × (U → ℝ) × (U → ℝ) => t.2.2.2.2.2.2.2.1).comp (comap_measurable _)
@[fun_prop] theorem measurable_udiscPi : Measurable (fun σ : Schedule P U => σ.udiscPi) :=
  (by fun_prop : Measurable fun t : (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × ℝ ×
    (U → ℝ) × (U → ℝ) × (U → ℝ) × (U → ℝ) => t.2.2.2.2.2.2.2.2.1).comp (comap_measurable _)
@[fun_prop] theorem measurable_uw : Measurable (fun σ : Schedule P U => σ.uw) :=
  (by fun_prop : Measurable fun t : (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × (P → ℝ) × ℝ ×
    (U → ℝ) × (U → ℝ) × (U → ℝ) × (U → ℝ) => t.2.2.2.2.2.2.2.2.2).comp (comap_measurable _)
end fields

/-- Nonnegative operator/flaw weights (line 1221). -/
def Schedule.Admissible (σ : Schedule P U) : Prop := (∀ i, 0 ≤ σ.w i) ∧ ∀ k, 0 ≤ σ.uw k

/-- Weighted exposure of a patched pair (line 1215–1217): excluded attackers' onset
`min(P_f + ℓ_x, W + d_f)`, parallel-access onset `min(P_f + ℓ_x, d_f^π)`, end `D = P_f + τ_fj`. -/
def patchedTerm (π : ℝ) (σ : Schedule P U) (W : ℝ) (i : P) : ℝ :=
  σ.w i * ((1 - π) * max (σ.pub i + σ.dep i - min (σ.pub i + σ.lag) (W + σ.disc i)) 0
    + π * max (σ.pub i + σ.dep i - min (σ.pub i + σ.lag) (σ.discPi i)) 0)

/-- Weighted exposure of an unfound pair (line 1219): `(ζ_j − W − d_f)⁺` and `(ζ_j − d_f^π)⁺`. -/
def unfoundTerm (π : ℝ) (σ : Schedule P U) (W : ℝ) (k : U) : ℝ :=
  σ.uw k * ((1 - π) * max (σ.rem k - W - σ.udisc k) 0 + π * max (σ.rem k - σ.udiscPi k) 0)

/-- `X(Σ, W)` (line 1221). -/
def exposure [Fintype P] [Fintype U] (π : ℝ) (σ : Schedule P U) (W : ℝ) : ℝ :=
  ∑ i, patchedTerm π σ W i + ∑ k, unfoundTerm π σ W k

theorem measurable_exposure [Fintype P] [Fintype U] (π : ℝ) :
    Measurable (Function.uncurry (exposure (P := P) (U := U) π)) := by
  change Measurable (fun p : Schedule P U × ℝ => exposure π p.1 p.2)
  unfold exposure patchedTerm unfoundTerm
  fun_prop

/-- **E2, pathwise monotonicity** (line 1295): with nonnegative weights and `π ∈ [0, 1]`, raising
`W` weakly lowers exposure. -/
theorem e2_exposure_antitone [Fintype P] [Fintype U] {π : ℝ} (hπ1 : π ≤ 1)
    {σ : Schedule P U} (hσ : σ.Admissible) : Antitone (exposure π σ) := by
  intro W W' hWW'
  unfold exposure
  apply add_le_add
  · apply Finset.sum_le_sum; intro i _
    unfold patchedTerm
    apply mul_le_mul_of_nonneg_left _ (hσ.1 i)
    apply add_le_add _ le_rfl
    apply mul_le_mul_of_nonneg_left _ (by linarith)
    exact max_le_max (sub_le_sub_left (min_le_min le_rfl (by linarith)) _) le_rfl
  · apply Finset.sum_le_sum; intro k _
    unfold unfoundTerm
    apply mul_le_mul_of_nonneg_left _ (hσ.2 k)
    apply add_le_add _ le_rfl
    apply mul_le_mul_of_nonneg_left _ (by linarith)
    exact max_le_max (by linarith) le_rfl

/-- Line 1258: an unfound flaw contributes regardless of coverage — a positive-weight unfound
pair that excluded attackers would find before removal makes exposure strictly decreasing in a
positive window (whenever `π < 1`). -/
theorem e2_unfound_contributes [Fintype P] [Fintype U] {π : ℝ} (hπ1 : π < 1)
    {σ : Schedule P U} (hσ : σ.Admissible) (k : U) (hk : 0 < σ.uw k)
    (hd : σ.udisc k < σ.rem k) {W : ℝ} (hW : 0 < W) :
    exposure π σ W < exposure π σ 0 := by
  unfold exposure
  apply add_lt_add_of_le_of_lt
  · apply Finset.sum_le_sum; intro i _
    unfold patchedTerm
    apply mul_le_mul_of_nonneg_left _ (hσ.1 i)
    apply add_le_add _ le_rfl
    apply mul_le_mul_of_nonneg_left _ (by linarith)
    exact max_le_max (sub_le_sub_left (min_le_min le_rfl (by linarith)) _) le_rfl
  · apply Finset.sum_lt_sum
    · intro j _
      unfold unfoundTerm
      apply mul_le_mul_of_nonneg_left _ (hσ.2 j)
      apply add_le_add _ le_rfl
      apply mul_le_mul_of_nonneg_left _ (by linarith)
      exact max_le_max (by linarith) le_rfl
    · refine ⟨k, Finset.mem_univ _, ?_⟩
      unfold unfoundTerm
      apply mul_lt_mul_of_pos_left _ hk
      apply add_lt_add_of_lt_of_le _ le_rfl
      apply mul_lt_mul_of_pos_left _ (by linarith)
      rw [max_eq_left (by linarith : (0:ℝ) ≤ σ.rem k - 0 - σ.udisc k)]
      exact max_lt (by linarith) (by linarith)

/-- **Proposition E2 for the paper's exposure**: decomposition, `S_H ≥ 0`, and the
lowering condition. -/
theorem e2_main [Fintype P] [Fintype U] {π : ℝ} (hπ1 : π ≤ 1)
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Schedule P U}
    (hB : Measurable B) (hS : Measurable S) (hH : Measurable sigH)
    (hadm : ∀ ω, (sigH ω).Admissible)
    (hBS : IndepFun B S μ) (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ)
    (hI0 : Integrable (fun ω => exposure π (sigH ω) 0) μ)
    (hI1 : Integrable (fun ω => exposure π (sigH ω) (WH S ω)) μ)
    (hIcl : Integrable (fun ω => exposure π (sigCl ω) (Wcl B S ω)) μ) :
    (Xcl μ (exposure π) sigCl B S - XH μ (exposure π) sigH S =
      ph μ B * SH μ (exposure π) sigH S - Gdef μ (exposure π) sigH sigCl B S) ∧
    0 ≤ SH μ (exposure π) sigH S ∧
    (Xcl μ (exposure π) sigCl B S < XH μ (exposure π) sigH S ↔
      ph μ B * SH μ (exposure π) sigH S < Gdef μ (exposure π) sigH sigCl B S) :=
  e2_generic (measurable_exposure π) hB hS hH (fun ω => e2_exposure_antitone hπ1 (hadm ω))
    hBS hHi hI0 hI1 hIcl

/-- **Proposition E2 for the paper's exposure, unchanged schedule law**: `Γ_def = 0`, weak
raise, strict exactly when `p_h S_H > 0`, equality when `p_h = 0`. -/
theorem e2_main_identical [Fintype P] [Fintype U] {π : ℝ} (hπ1 : π ≤ 1)
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Schedule P U}
    (hB : Measurable B) (hS : Measurable S) (hH : Measurable sigH) (hC : Measurable sigCl)
    (hadm : ∀ ω, (sigH ω).Admissible)
    (hBS : IndepFun B S μ) (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ)
    (hCi : IndepFun sigCl (fun ω => (S ω, B ω)) μ) (hlaw : μ.map sigH = μ.map sigCl)
    (hI1 : Integrable (fun ω => exposure π (sigH ω) (WH S ω)) μ)
    (hIcl : Integrable (fun ω => exposure π (sigCl ω) (Wcl B S ω)) μ) :
    Gdef μ (exposure π) sigH sigCl B S = 0 ∧
    XH μ (exposure π) sigH S ≤ Xcl μ (exposure π) sigCl B S ∧
    (XH μ (exposure π) sigH S < Xcl μ (exposure π) sigCl B S ↔
      0 < ph μ B * SH μ (exposure π) sigH S) ∧
    (ph μ B = 0 → Xcl μ (exposure π) sigCl B S = XH μ (exposure π) sigH S) :=
  e2_generic_identical (measurable_exposure π) hB hS hH hC
    (fun ω => e2_exposure_antitone hπ1 (hadm ω)) hBS hHi hCi hlaw hI1 hIcl

/-- **E2 strictness for the paper's exposure**, with `S_H` a genuine finite expectation (`hI0`). -/
theorem e2_main_strict [Fintype P] [Fintype U] {π : ℝ} (hπ1 : π ≤ 1)
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Schedule P U}
    (hB : Measurable B) (hS : Measurable S) (hH : Measurable sigH) (hC : Measurable sigCl)
    (hadm : ∀ ω, (sigH ω).Admissible)
    (hBS : IndepFun B S μ) (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ)
    (hCi : IndepFun sigCl (fun ω => (S ω, B ω)) μ) (hlaw : μ.map sigH = μ.map sigCl)
    (hI0 : Integrable (fun ω => exposure π (sigH ω) 0) μ)
    (hI1 : Integrable (fun ω => exposure π (sigH ω) (WH S ω)) μ)
    (hIcl : Integrable (fun ω => exposure π (sigCl ω) (Wcl B S ω)) μ) :
    Integrable (fun ω => exposure π (sigH ω) 0 - exposure π (sigH ω) (WH S ω)) μ ∧
    SH μ (exposure π) sigH S = ∫ ω, exposure π (sigH ω) 0 ∂μ - XH μ (exposure π) sigH S ∧
    (XH μ (exposure π) sigH S < Xcl μ (exposure π) sigCl B S ↔
      0 < ph μ B * SH μ (exposure π) sigH S) :=
  e2_identical_strict (measurable_exposure π) hB hS hH hC
    (fun ω => e2_exposure_antitone hπ1 (hadm ω)) hBS hHi hCi hlaw hI0 hI1 hIcl

/-- **E2 strictness for the paper's exposure, extended `S_H`** (`0 · ∞ = 0`), no `hI0`. -/
theorem e2_main_strict_ext [Fintype P] [Fintype U] {π : ℝ} (hπ1 : π ≤ 1)
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Schedule P U}
    (hB : Measurable B) (hS : Measurable S) (hH : Measurable sigH) (hC : Measurable sigCl)
    (hadm : ∀ ω, (sigH ω).Admissible)
    (hBS : IndepFun B S μ) (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ)
    (hCi : IndepFun sigCl (fun ω => (S ω, B ω)) μ) (hlaw : μ.map sigH = μ.map sigCl)
    (hI1 : Integrable (fun ω => exposure π (sigH ω) (WH S ω)) μ)
    (hIcl : Integrable (fun ω => exposure π (sigCl ω) (Wcl B S ω)) μ) :
    XH μ (exposure π) sigH S < Xcl μ (exposure π) sigCl B S ↔
      0 < ENNReal.ofReal (ph μ B) * SHext μ (exposure π) sigH S :=
  e2_identical_strict_ext (measurable_exposure π) hB hS hH hC
    (fun ω => e2_exposure_antitone hπ1 (hadm ω)) hBS hHi hCi hlaw hI1 hIcl

/-! ### A capability-dependent exploit lag (lines 943, 1160, 1219) -/

/-- Patched-pair exposure when the lag shortens to `ℓ_c` once attackers hold the capability:
excluded attackers' onset `min(P_f + ℓ_x, max(P_f, W) + ℓ_c, W + d_f)`; parallel-access attackers
hold it throughout, onset `min(P_f + ℓ_c, d_f^π)`. The paper does not state this rule. -/
def patchedTermLag (π lc : ℝ) (σ : Schedule P U) (W : ℝ) (i : P) : ℝ :=
  σ.w i * ((1 - π) * max (σ.pub i + σ.dep i -
      min (min (σ.pub i + σ.lag) (max (σ.pub i) W + lc)) (W + σ.disc i)) 0
    + π * max (σ.pub i + σ.dep i - min (σ.pub i + lc) (σ.discPi i)) 0)

/-- `X(Σ, W)` under the shortened-lag rule. -/
def exposureLag [Fintype P] [Fintype U] (π lc : ℝ) (σ : Schedule P U) (W : ℝ) : ℝ :=
  ∑ i, patchedTermLag π lc σ W i + ∑ k, unfoundTerm π σ W k

theorem measurable_exposureLag [Fintype P] [Fintype U] (π lc : ℝ) :
    Measurable (Function.uncurry (exposureLag (P := P) (U := U) π lc)) := by
  change Measurable (fun p : Schedule P U × ℝ => exposureLag π lc p.1 p.2)
  unfold exposureLag patchedTermLag unfoundTerm
  fun_prop

/-- Under the shortened lag, exposure onset is still non-decreasing in `W`, so exposure is still
antitone in the window (the reason line 1219 gives). -/
theorem e2_lag_antitone [Fintype P] [Fintype U] {π : ℝ} (hπ1 : π ≤ 1) (lc : ℝ)
    {σ : Schedule P U} (hσ : σ.Admissible) : Antitone (exposureLag π lc σ) := by
  intro W W' hWW'
  unfold exposureLag
  apply add_le_add
  · apply Finset.sum_le_sum; intro i _
    unfold patchedTermLag
    apply mul_le_mul_of_nonneg_left _ (hσ.1 i)
    apply add_le_add _ le_rfl
    apply mul_le_mul_of_nonneg_left _ (by linarith)
    refine max_le_max (sub_le_sub_left (min_le_min (min_le_min le_rfl ?_) (by linarith)) _) le_rfl
    exact add_le_add (max_le_max le_rfl hWW') le_rfl
  · apply Finset.sum_le_sum; intro k _
    unfold unfoundTerm
    apply mul_le_mul_of_nonneg_left _ (hσ.2 k)
    apply add_le_add _ le_rfl
    apply mul_le_mul_of_nonneg_left _ (by linarith)
    exact max_le_max (by linarith) le_rfl

/-- **E2's sign survives a capability-dependent exploit lag** (lines 943, 1160, 1219): under the
shortened-lag exposure, the decomposition, `S_H ≥ 0`, and with unchanged schedule law
`Γ_def = 0`, the weak raise and the strictness condition all hold. -/
theorem e2_lag_sign [Fintype P] [Fintype U] {π : ℝ} (hπ1 : π ≤ 1) (lc : ℝ)
    {B : Ω → Bool} {S : Ω → Ev → ℝ≥0∞} {sigH sigCl : Ω → Schedule P U}
    (hB : Measurable B) (hS : Measurable S) (hH : Measurable sigH) (hC : Measurable sigCl)
    (hadm : ∀ ω, (sigH ω).Admissible)
    (hBS : IndepFun B S μ) (hHi : IndepFun sigH (fun ω => (S ω, B ω)) μ)
    (hCi : IndepFun sigCl (fun ω => (S ω, B ω)) μ) (hlaw : μ.map sigH = μ.map sigCl)
    (hI0 : Integrable (fun ω => exposureLag π lc (sigH ω) 0) μ)
    (hI1 : Integrable (fun ω => exposureLag π lc (sigH ω) (WH S ω)) μ)
    (hIcl : Integrable (fun ω => exposureLag π lc (sigCl ω) (Wcl B S ω)) μ) :
    (Xcl μ (exposureLag π lc) sigCl B S - XH μ (exposureLag π lc) sigH S =
      ph μ B * SH μ (exposureLag π lc) sigH S - Gdef μ (exposureLag π lc) sigH sigCl B S) ∧
    0 ≤ SH μ (exposureLag π lc) sigH S ∧
    Gdef μ (exposureLag π lc) sigH sigCl B S = 0 ∧
    XH μ (exposureLag π lc) sigH S ≤ Xcl μ (exposureLag π lc) sigCl B S ∧
    (XH μ (exposureLag π lc) sigH S < Xcl μ (exposureLag π lc) sigCl B S ↔
      0 < ph μ B * SH μ (exposureLag π lc) sigH S) := by
  have hanti := fun ω => e2_lag_antitone hπ1 lc (hadm ω)
  have g1 := e2_generic (measurable_exposureLag π lc) hB hS hH hanti hBS hHi hI0 hI1 hIcl
  have g2 := e2_generic_identical (measurable_exposureLag π lc) hB hS hH hC hanti hBS hHi hCi
    hlaw hI1 hIcl
  exact ⟨g1.1, g1.2.1, g2.1, g2.2.1, g2.2.2.1⟩

end E2

/-! ## E3 -/

section E3

/-- The eight primitive substreams of E3 (lines 1264–1266). -/
inductive Ev3
  | Odom | Oout | C1dom | C0dom | C1out | C0out | Th | L
  deriving DecidableEq

/-- Covered domestic hazards: `λ_o^dom, λ_c^dom, p_c^dom` (the levers). -/
structure DomRates where
  lo : ℝ
  lc : ℝ
  pc : ℝ

/-- Unbound and other fixed quantities: `λ_o^out, λ_c^out, p_c^out, λ_θ, λ_ℓ`. -/
structure OutRates where
  lo : ℝ
  lc : ℝ
  pc : ℝ
  lth : ℝ
  ll : ℝ

/-- Admissible domestic settings: nonnegative rates, `p_c^dom ∈ [0, 1]`. -/
def DomRates.Admissible (d : DomRates) : Prop := 0 ≤ d.lo ∧ 0 ≤ d.lc ∧ 0 ≤ d.pc ∧ d.pc ≤ 1

/-- The intensities of the eight substreams after marking. -/
def rate3 (d : DomRates) (o : OutRates) : Ev3 → ℝ
  | .Odom => d.lo
  | .Oout => o.lo
  | .C1dom => d.pc * d.lc
  | .C0dom => (1 - d.pc) * d.lc
  | .C1out => o.pc * o.lc
  | .C0out => (1 - o.pc) * o.lc
  | .Th => o.lth
  | .L => o.ll

/-- `λ_U = λ_o^out + p_c^outλ_c^out + λ_θ + λ_ℓ` (line 1266). -/
def lamU (o : OutRates) : ℝ := o.lo + o.pc * o.lc + o.lth + o.ll

/-- `λ_o = λ_o^dom + λ_o^out` (line 1264). -/
def lamO3 (d : DomRates) (o : OutRates) : ℝ := d.lo + o.lo

/-- `p_cλ_c = p_c^domλ_c^dom + p_c^outλ_c^out` (line 1264). -/
def pcLc3 (d : DomRates) (o : OutRates) : ℝ := d.pc * d.lc + o.pc * o.lc

/-- `λ_c = λ_c^dom + λ_c^out` (line 1264), the total closed-release intensity. -/
def lamC3 (d : DomRates) (o : OutRates) : ℝ := d.lc + o.lc

/-- The superposed working-closed rate is `λ_c − p_cλ_c`, i.e. `(1 − p_c)λ_c` for the aggregate
failure share defined by `p_cλ_c = p_c^domλ_c^dom + p_c^outλ_c^out` (line 1264). Algebraic. -/
theorem e3_closed_split (d : DomRates) (o : OutRates) :
    (1 - d.pc) * d.lc + (1 - o.pc) * o.lc = lamC3 d o - pcLc3 d o := by
  unfold lamC3 pcLc3; ring

/-- E1's `λ_A = λ_o + p_cλ_c + λ_θ + λ_ℓ` with the split rates. -/
def lamA3 (d : DomRates) (o : OutRates) : ℝ := lamO3 d o + pcLc3 d o + o.lth + o.ll

/-- **E3, the rate identity** (line 1270): `λ_A = λ_U + λ_o^dom + p_c^domλ_c^dom`. -/
theorem e3_lambdaA_eq (d : DomRates) (o : OutRates) :
    lamA3 d o = lamU o + d.lo + d.pc * d.lc := by
  unfold lamA3 lamO3 pcLc3 lamU; ring

/-- The rate ordering `λ_U ≤ λ_A`, derived (not assumed) from admissible domestic hazards. -/
theorem e3_lamU_le_lamA {d : DomRates} (hd : d.Admissible) (o : OutRates) :
    lamU o ≤ lamA3 d o := by
  rw [e3_lambdaA_eq]; nlinarith [hd.1, mul_nonneg hd.2.2.1 hd.2.1]

/-- All attack-enabling substreams. -/
def attack3 : Finset Ev3 := {.Odom, .Oout, .C1dom, .C1out, .Th, .L}

/-- Attack-enabling substreams not reached by covered domestic levers. -/
def attackOut : Finset Ev3 := {.Oout, .C1out, .Th, .L}

/-- `ω_A`, the first attack-enabling event of the split system. -/
noncomputable def omegaA3 (s : Ev3 → ℝ≥0∞) : ℝ≥0∞ := attack3.inf s

/-- `ω_A^out`, the first attack-enabling event from unbound developers, theft and leaks. -/
noncomputable def omegaAout (s : Ev3 → ℝ≥0∞) : ℝ≥0∞ := attackOut.inf s

/-- Superposing the substreams gives E1's five primitive streams. -/
noncomputable def aggregate (s : Ev3 → ℝ≥0∞) : Ev → ℝ≥0∞
  | .O => min (s .Odom) (s .Oout)
  | .C1 => min (s .C1dom) (s .C1out)
  | .C0 => min (s .C0dom) (s .C0out)
  | .Th => s .Th
  | .L => s .L

/-- E3's `ω_A` is E1's `ω_A` of the superposed streams. -/
theorem e3_omegaA_eq_E1 (s : Ev3 → ℝ≥0∞) : omegaAOf (aggregate s) = omegaA3 s := by
  simp only [omegaAOf, attackSet, omegaA3, attack3, Finset.inf_insert, Finset.inf_singleton,
    aggregate]
  simp only [min_assoc]

variable {τ : Ev3 → Ω → ℝ≥0∞} {d : DomRates} {o : OutRates}

/-- **E3, superposition** (lines 1264–1270): the superposed open, failed-closed and
working-closed first arrivals are exponential with rates `λ_o`, `p_cλ_c` and `(1 − p_c)λ_c`. -/
theorem e3_superposition (h : FirstArrivals μ τ (rate3 d o)) :
    HasExpSurvival μ (fun ω => aggregate (fun e => τ e ω) .O) (lamO3 d o) ∧
    HasExpSurvival μ (fun ω => aggregate (fun e => τ e ω) .C1) (pcLc3 d o) ∧
    HasExpSurvival μ (fun ω => aggregate (fun e => τ e ω) .C0)
      ((1 - d.pc) * d.lc + (1 - o.pc) * o.lc) := by
  have hO := survival_inf h {.Odom, .Oout}
  have h1 := survival_inf h {.C1dom, .C1out}
  have h0 := survival_inf h {.C0dom, .C0out}
  simp only [Finset.inf_insert, Finset.inf_singleton] at hO h1 h0
  simp [rate3] at hO h1 h0
  exact ⟨hO, h1, h0⟩

/-- All eight substreams end the commercial lead. -/
def comm3 : Finset Ev3 := {.Odom, .Oout, .C1dom, .C1out, .C0dom, .C0out, .Th, .L}

/-- E1's `ω_C` of the superposed streams is the first arrival over all eight substreams. -/
theorem e3_omegaC_eq_E1 (s : Ev3 → ℝ≥0∞) : omegaCOf (aggregate s) = comm3.inf s := by
  simp only [omegaCOf, commSet, comm3, Finset.inf_insert, Finset.inf_singleton, aggregate]
  simp only [min_assoc]

/-- **E3, the total commercial law**: the superposed `ω_C` is exponential with rate
`λ_o + λ_c + λ_θ + λ_ℓ`, where `λ_o = λ_o^dom + λ_o^out` and `λ_c = λ_c^dom + λ_c^out`. -/
theorem e3_omegaC_exp (h : FirstArrivals μ τ (rate3 d o)) :
    HasExpSurvival μ (fun ω => omegaCOf (aggregate (fun e => τ e ω)))
      (lamO3 d o + lamC3 d o + o.lth + o.ll) := by
  simp only [e3_omegaC_eq_E1]
  have := survival_inf h comm3
  have hs : ∑ e ∈ comm3, rate3 d o e = lamO3 d o + lamC3 d o + o.lth + o.ll := by
    simp [comm3, rate3, lamO3, lamC3]; ring
  rw [hs] at this; exact this

/-- **E3, the law of `ω_A`**: exponential with rate `λ_A = λ_U + λ_o^dom + p_c^domλ_c^dom`. -/
theorem e3_omegaA_exp (h : FirstArrivals μ τ (rate3 d o)) :
    HasExpSurvival μ (fun ω => omegaA3 (fun e => τ e ω)) (lamA3 d o) := by
  have := survival_inf h attack3
  have hs : ∑ e ∈ attack3, rate3 d o e = lamA3 d o := by
    simp [attack3, rate3, lamA3, lamO3, pcLc3]; ring
  rw [hs] at this; exact this

/-- **E3, the outside first-arrival law** (line 1301): `ω_A^out` is exponential with rate
`λ_U`, by independence of the dom and out substreams and their marks. -/
theorem e3_outside_exp (h : FirstArrivals μ τ (rate3 d o)) :
    HasExpSurvival μ (fun ω => omegaAout (fun e => τ e ω)) (lamU o) := by
  have := survival_inf h attackOut
  have hs : ∑ e ∈ attackOut, rate3 d o e = lamU o := by
    simp [attackOut, rate3, lamU]; ring
  rw [hs] at this; exact this

/-- **E3, the pathwise chain** (line 1301): `W_A ≤ ω_A ≤ ω_A^out` for every initial action and
safeguard outcome. -/
theorem e3_chain (a : Action) (b : Bool) (s : Ev3 → ℝ≥0∞) :
    WA a b (omegaA3 s) ≤ omegaA3 s ∧ omegaA3 s ≤ omegaAout s :=
  ⟨min_le_left _ _, Finset.inf_mono (by intro e he; simp [attackOut, attack3] at he ⊢; tauto)⟩

/-- **Proposition E3** (line 1274): for every admissible setting of the covered domestic hazards,
every safeguard outcome and each initial action studied, `E[W_A] ≤ 1/λ_A ≤ 1/λ_U`; moreover
`E[ω_A] = 1/λ_A` and `E[ω_A^out] = 1/λ_U`. The outside quantities `o` are fixed with `λ_U > 0`.
The rate ordering and the window bound are derived, not assumed. -/
theorem e3_reach_limit (o : OutRates) (hU : 0 < lamU o) (d : DomRates) (hd : d.Admissible)
    {τ : Ev3 → Ω → ℝ≥0∞} (h : FirstArrivals μ τ (rate3 d o)) (B : Ω → Bool) (a : Action) :
    ∫⁻ ω, WA a (B ω) (omegaA3 (fun e => τ e ω)) ∂μ ≤ ENNReal.ofReal (1 / lamA3 d o) ∧
    ENNReal.ofReal (1 / lamA3 d o) ≤ ENNReal.ofReal (1 / lamU o) ∧
    ∫⁻ ω, omegaA3 (fun e => τ e ω) ∂μ = ENNReal.ofReal (1 / lamA3 d o) ∧
    ∫⁻ ω, omegaAout (fun e => τ e ω) ∂μ = ENNReal.ofReal (1 / lamU o) := by
  have hle := e3_lamU_le_lamA hd o
  have hA : 0 < lamA3 d o := lt_of_lt_of_le hU hle
  have hS : Measurable (fun ω e => τ e ω) := measurable_pi_iff.mpr h.meas
  have mA := (e3_omegaA_exp h).lintegral_eq ((measurable_finset_inf attack3).comp hS) hA
  have mU := (e3_outside_exp h).lintegral_eq ((measurable_finset_inf attackOut).comp hS) hU
  refine ⟨?_, ENNReal.ofReal_le_ofReal (one_div_le_one_div_of_le hU hle), mA, mU⟩
  rw [← mA]
  exact lintegral_mono (fun ω => (e3_chain a (B ω) _).1)

/-- **E3, the reach limit as stated** (line 1276): levers that reach only covered domestic
developers cannot raise the expected attacker-access window above `1/λ_U`. -/
theorem e3_reach_limit_forall (o : OutRates) (hU : 0 < lamU o) :
    ∀ d : DomRates, d.Admissible → ∀ τ : Ev3 → Ω → ℝ≥0∞, FirstArrivals μ τ (rate3 d o) →
      ∀ (B : Ω → Bool) (a : Action),
        ∫⁻ ω, WA a (B ω) (omegaA3 (fun e => τ e ω)) ∂μ ≤ ENNReal.ofReal (1 / lamU o) :=
  fun d hd _ h B a =>
    let r := e3_reach_limit o hU d hd h B a
    r.1.trans r.2.1

end E3

end RTTR.Copies

open RTTR.Copies

#print axioms FirstArrivals.law
#print axioms survival_inf
#print axioms measurable_finset_inf
#print axioms lintegral_eq_lintegral_survival
#print axioms HasExpSurvival.lintegral_eq
#print axioms HasExpSurvival.ae_lt_top
#print axioms Rates.rate_nonneg
#print axioms sum_commSet
#print axioms sum_attackSet
#print axioms measurable_omegaAOf
#print axioms measurable_omegaCOf
#print axioms e1_lambdaC_pos
#print axioms e1_omegaC_exp
#print axioms e1_omegaA_exp
#print axioms e1_omegaC_le_omegaA
#print axioms e1_means
#print axioms e1_omegaA_lt_top_ae
#print axioms e1_windows_dependent
#print axioms e1_event_roles
#print axioms e1_window_table
#print axioms e1_WC_le_WA
#print axioms e1_hold_means
#print axioms e1_closed_atom
#print axioms e1_closed_not_exponential
#print axioms e1_covert_theft_breaks_order
#print axioms e2_Wcl_eq
#print axioms e2_working_release
#print axioms e2_WH_ae_eq
#print axioms measurable_WA_closed
#print axioms e2_joint_indep
#print axioms e2_split
#print axioms e2_mixture
#print axioms e2_integrable_mix
#print axioms e2_decomposition
#print axioms e2_SH_nonneg
#print axioms e2_gamma_zero
#print axioms e2_integrable_transfer
#print axioms e2_integrable_zero
#print axioms e2_generic
#print axioms e2_generic_identical
#print axioms e2_identical_strict
#print axioms e2_identical_strict_ext
#print axioms e2_shorter_window_raises
#print axioms e2_added_event_shortens
#print axioms e2_added_hazard_raises
#print axioms measurable_pub
#print axioms measurable_dep
#print axioms measurable_disc
#print axioms measurable_discPi
#print axioms measurable_w
#print axioms measurable_lag
#print axioms measurable_rem
#print axioms measurable_udisc
#print axioms measurable_udiscPi
#print axioms measurable_uw
#print axioms measurable_exposure
#print axioms e2_exposure_antitone
#print axioms e2_unfound_contributes
#print axioms e2_main
#print axioms e2_main_identical
#print axioms e2_main_strict
#print axioms e2_main_strict_ext
#print axioms measurable_exposureLag
#print axioms e2_lag_antitone
#print axioms e2_lag_sign
#print axioms e3_closed_split
#print axioms e3_lambdaA_eq
#print axioms e3_lamU_le_lamA
#print axioms e3_omegaA_eq_E1
#print axioms e3_superposition
#print axioms e3_omegaC_eq_E1
#print axioms e3_omegaC_exp
#print axioms e3_omegaA_exp
#print axioms e3_outside_exp
#print axioms e3_chain
#print axioms e3_reach_limit
#print axioms e3_reach_limit_forall
