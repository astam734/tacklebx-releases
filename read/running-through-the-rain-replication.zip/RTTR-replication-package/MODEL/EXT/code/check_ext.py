#!/usr/bin/env python3
"""Finite checks of EXT-SECTION E1-E3, with executed source mutations.

Standard library only. PASS checks numerical instances, not empirical premises.
Each mutant is a standalone source copy run under -I, with auditing disabled to
avoid recursion. It must turn its previously passing target red, exit 1, print a
SUMMARY, and finish without a traceback. Full mutant sources/output are retained.
"""
import argparse
from dataclasses import dataclass
import math
from pathlib import Path
import random
import subprocess
import sys

SEED = 20261022
INF = math.inf


@dataclass(frozen=True)
class Hazards:
    lo: float
    lc: float
    pc: float
    theft: float
    leak: float

    @property
    def commercial(self):
        return self.lo + self.lc + self.theft + self.leak

    @property
    def access(self):
        return self.lo + self.pc * self.lc + self.theft + self.leak  # E1-MUTATION


def arrival(rng, rate):
    return rng.expovariate(rate) if rate > 0 else INF


def streams(rng, hz):
    """Closed arrivals are marked one at a time, continuing past working ones.

    Only arrivals before another attack-enabling event need to be marked.
    All callers have positive total access intensity, so the loop terminates.
    """
    other = min(arrival(rng, hz.lo), arrival(rng, hz.theft), arrival(rng, hz.leak))
    first_closed = arrival(rng, hz.lc)
    closed = first_closed
    access = other
    while closed < other:
        if rng.random() < hz.pc:
            access = closed
            break
        closed += arrival(rng, hz.lc)
    return min(other, first_closed), access


def windows(hc, ha, action, failed=False):
    if action == 'hold':
        return hc, ha
    if action == 'open':
        return 0.0, 0.0
    if action == 'closed':
        return 0.0, 0.0 if failed else ha
    raise ValueError(action)


def estimate(values):
    n = len(values)
    mean = math.fsum(values) / n
    variance = math.fsum((v - mean) ** 2 for v in values) / (n - 1)
    return mean, math.sqrt(variance / n)


def zscore(values, expected):
    mean, se = estimate(values)
    if se == 0:
        return 0.0 if abs(mean - expected) < 1e-12 else INF
    return abs(mean - expected) / se


def simpson(function, end, intervals=6000):
    step = end / intervals
    total = function(0.0) + function(end)
    total += math.fsum((4 if i % 2 else 2) * function(i * step)
                       for i in range(1, intervals))
    return total * step / 3


def check_e1():
    rng = random.Random(SEED)
    cases = [Hazards(.1, .3, .2, .05, .05),
             Hazards(.1, .3, 0, .05, .05),
             Hazards(.1, .3, 1, .05, .05),
             Hazards(0, .4, .25, 0, 0)]
    ok, worst_z, saw_split = True, 0.0, False
    for hz in cases:
        pairs = [streams(rng, hz) for _ in range(50000)]
        cs, ats = zip(*pairs)
        worst_z = max(worst_z, zscore(cs, 1 / hz.commercial),
                      zscore(ats, 1 / hz.access))
        ok &= all(c <= a for c, a in pairs)
        saw_split |= any(c < a for c, a in pairs)
        for time in (.5, 2.0, 5.0):
            worst_z = max(worst_z,
                          zscore([float(c > time) for c in cs], math.exp(-hz.commercial * time)),
                          zscore([float(a > time) for a in ats], math.exp(-hz.access * time)))
        # Both safeguard outcomes are checked on each coupled path.
        for c, a in pairs[:500]:
            ok &= windows(c, a, 'hold') == (c, a)
            ok &= windows(c, a, 'open') == (0, 0)
            ok &= windows(c, a, 'closed', False) == (0, a)
            ok &= windows(c, a, 'closed', True) == (0, 0)
        if hz.pc == 1:
            ok &= all(c == a for c, a in pairs)
    return bool(ok and saw_split and worst_z < 5), f'marked-stream means/survivals: max error {worst_z:.3f} SE; path ordering and both safeguard outcomes checked'


@dataclass(frozen=True)
class Flaw:
    kind: str
    publication: float
    deployment: float
    discovery: float
    removal: float
    parallel_discovery: float
    weight: float


LAG = .4
PI = .3


def exposure(schedule, access):
    total = 0.0
    for f in schedule:
        if f.kind == 'patched':
            end = f.publication + f.deployment
            onset = min(f.publication + LAG, access + f.discovery)
            parallel = min(f.publication + LAG, f.parallel_discovery)
        else:
            end = f.removal
            onset = access + f.discovery
            parallel = f.parallel_discovery
        total += f.weight * ((1 - PI) * max(end - onset, 0.0)
                             + PI * max(end - parallel, 0.0))
    return total


def expected_exposure(schedule, rate):
    # Beyond this horizon the window-dependent exposure is constant.
    end = max(max(f.publication + f.deployment, f.removal) for f in schedule)
    tail = exposure(schedule, end)
    return tail + simpson(lambda t: rate * math.exp(-rate * t)
                          * (exposure(schedule, t) - tail), end, 12000)


def exposure_difference(ph, saving, improvement):
    return ph * saving - improvement  # E2-MUTATION


def check_e2():
    rng = random.Random(SEED + 1)
    hz = Hazards(.1, .3, .2, .05, .05)
    # Includes a patch-driven onset, early attacker discovery, an uncovered
    # unfound flaw, and a flaw already removed before attackers can discover it.
    hold = [Flaw('patched', 1, 3, .1, 0, .2, 1),
            Flaw('patched', 2, 4, 3, 0, 1, .8),
            Flaw('unfound', 0, 0, .5, 8, .3, 1.4),
            Flaw('unfound', 0, 0, 3, 1, 2, .6)]
    improved = [Flaw('patched', 1, .2, .1, 0, .2, 1),
                Flaw('patched', 2, .2, 3, 0, 1, .8),
                Flaw('unfound', 0, 0, .5, 1, .3, 1.4), hold[-1]]
    delayed = [Flaw('patched', 1, 6, .1, 0, .2, 1), *hold[1:]]
    scenarios = [(0, hold), (.25, hold), (1, hold), (.25, improved), (.25, delayed)]
    hbar = expected_exposure(hold, hz.access)
    saving = exposure(hold, 0) - hbar
    ok, worst_z = saving > 0, 0.0
    for ph, released in scenarios:
        rbar = expected_exposure(released, hz.access)
        at_release_old = ph * exposure(hold, 0) + (1 - ph) * hbar
        at_release_new = ph * exposure(released, 0) + (1 - ph) * rbar
        improvement = at_release_old - at_release_new
        predicted = exposure_difference(ph, saving, improvement)
        diffs = []
        for _ in range(80000):
            hc, ha = streams(rng, hz)
            failed = rng.random() < ph
            wc, wa = windows(hc, ha, 'closed', failed)
            diffs.append(exposure(released, wa) - exposure(hold, ha))
            ok &= wc == 0 and wa == (0 if failed else ha)
            if released is hold:
                ok &= diffs[-1] >= -1e-12
        worst_z = max(worst_z, zscore(diffs, predicted))
        ok &= abs((at_release_new - hbar) - predicted) < 2e-8
        if released is improved:
            ok &= improvement > ph * saving and predicted < 0
        if released is delayed:
            ok &= improvement < 0 and predicted > 0
    # Uncovered unfound exposure has a positive hold benefit in its own right.
    uncovered = [hold[2]]
    ok &= exposure(uncovered, 0) > expected_exposure(uncovered, hz.access)
    return bool(ok and worst_z < 5), f'direct coupled flaw exposures vs quadrature decomposition: max error {worst_z:.3f} SE; unchanged, improved and delayed schedules checked'


def unbound_floor(lo_u, lc_u, pc_u, theft, leak):
    return lo_u + pc_u * lc_u + theft + leak  # E3-MUTATION


def check_e3():
    # Integrate the product of primitive-stream survivals independently of the
    # floor formula. Working closed arrivals are absent from this product.
    lo_u, lc_u, pc_u, theft, leak = .03, .6, .1, .05, .04
    floor = unbound_floor(lo_u, lc_u, pc_u, theft, leak)
    unbound_rates = (lo_u, pc_u * lc_u, theft, leak)
    ok, largest_ratio = floor > 0, 0.0
    for lo_d, lc_d, pc_d in [(0, 0, 0), (.2, .4, .3), (0, .7, 0), (.6, .9, 1)]:
        rates = (*unbound_rates, lo_d, pc_d * lc_d)
        total = math.fsum(rates)
        for action, ph in [('hold', 0), ('closed', 0), ('closed', .4), ('closed', 1), ('open', 1)]:
            mass = 1.0 if action == 'hold' else (1 - ph if action == 'closed' else 0.0)
            def survival(t):
                return mass * math.prod(math.exp(-rate * t) for rate in rates)
            mean = simpson(survival, 40 / total, 12000)
            ok &= mean <= 1 / total + 1e-8 and mean <= 1 / floor + 1e-8
            largest_ratio = max(largest_ratio, floor * mean)
    return bool(ok), f'product-survival integration: largest b E[W_A] = {largest_ratio:.9f}; covered-hazard settings and initial actions checked against 1/b'


CHECKS = [('E1', check_e1), ('E2', check_e2), ('E3', check_e3)]
MUTATIONS = [
    ('E1', 'return self.lo + self.pc * self.lc + self.theft + self.leak  # E1-MUTATION',
     'return self.lo + self.lc + self.theft + self.leak  # E1-MUTATION',
     'count working closed copies as attack-enabling'),
    ('E2', 'return ph * saving - improvement  # E2-MUTATION',
     'return -ph * saving - improvement  # E2-MUTATION',
     'reverse the exposure cost of safeguard failure'),
    ('E3', 'return lo_u + pc_u * lc_u + theft + leak  # E3-MUTATION',
     'return lo_u + lc_u + theft + leak  # E3-MUTATION',
     'count all unbound closed arrivals in the attack-enabling floor'),
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--no-mutations', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    lines, problems, status = [], [], {}
    for name, function in CHECKS:
        try:
            ok, detail = function()
        except Exception as exc:
            ok, detail = False, f'{type(exc).__name__}: {exc}'
        status[name] = ok
        lines.append(f'{"PASS" if ok else "FAIL"} {name} | {detail}')
        if not ok:
            problems.append(name)
    executed, rejected = 0, 0
    if not args.no_mutations:
        source = Path(__file__).resolve().read_text()
        directory = Path(__file__).resolve().parent / 'mutation_runs'
        directory.mkdir(exist_ok=True)
        executable, specifications = source.split('\nMUTATIONS = [', 1)
        for name, before, after, description in MUTATIONS:
            if executable.count(before) != 1:
                problems.append('invalid mutation anchor ' + name)
                lines.append(f'MISSED {name} mutation | anchor is not unique in executable source')
                continue
            candidate = directory / f'{name}.py'
            candidate.write_text(executable.replace(before, after, 1)
                                 + '\nMUTATIONS = [' + specifications)
            try:
                run = subprocess.run([sys.executable, '-I', str(candidate), '--no-mutations'],
                                     capture_output=True, text=True, timeout=60)
            except (OSError, subprocess.TimeoutExpired) as exc:
                problems.append('mutation execution ' + name)
                lines.append(f'MISSED {name} mutation | {type(exc).__name__}: {exc}')
                continue
            executed += 1
            transcript = run.stdout + run.stderr
            (directory / f'{name}_out.txt').write_text(transcript)
            caught = (status[name] and run.returncode == 1
                      and f'FAIL {name} |' in run.stdout
                      and 'SUMMARY:' in run.stdout and 'Traceback' not in transcript)
            rejected += int(caught)
            lines.append(f'{"REJECTED" if caught else "MISSED"} {name} mutation | {description}; target FAIL, exit {run.returncode}; mutation_runs/{name}_out.txt')
            if not caught:
                problems.append('mutation ' + name)
    lines.append(f'SUMMARY: {sum(status.values())} of {len(CHECKS)} result checks passed; '
                 f'{rejected} of {executed} executed source mutations rejected; {len(problems)} problems')
    output = '\n'.join(lines) + '\n'
    if args.out:
        args.out.write_text(output)
    print(output, end='')
    return int(bool(problems))


if __name__ == '__main__':
    sys.exit(main())
