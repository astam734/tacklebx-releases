#!/usr/bin/env python3
"""Deterministic numerical audit of BEN-MATH.md / P16 (illustrative inputs only).

Run in this directory: python3 check_benefits.py > check_benefits_out.txt
Standard library only. Every printed line starts PASS or FAIL. A failed check
sets exit status 1. No files are written by the script.
"""

import math
import sys
from dataclasses import dataclass, replace
from itertools import product


FAILURES = []
CHECKS = 0


def check(name, ok, detail=""):
    global CHECKS
    CHECKS += 1
    print(f"{'PASS' if ok else 'FAIL'} {name}" + (f" | {detail}" if detail else ""))
    if not ok:
        FAILURES.append(name)


def close(a, b, tol=3e-6):
    return math.isfinite(a) and math.isfinite(b) and abs(a - b) <= tol * max(1, abs(a), abs(b))


def sign(x, tol=2e-7):
    return 1 if x > tol else -1 if x < -tol else 0


def simpson(f, a, b, n=128):
    """Integrate a smooth piece; never integrate across a clock breakpoint."""
    if a == b:
        return 0.0
    d = (b - a) / n
    return d / 3 * (
        f(a) + f(b)
        + 4 * sum(f(a + j * d) for j in range(1, n, 2))
        + 2 * sum(f(a + j * d) for j in range(2, n, 2))
    )


def fd(f, s):
    d = 1e-5 * s
    return (f(s + d) - f(s - d)) / (2 * d)


def one_sided(f, s, side):
    """Second-order forward/backward derivative, entirely on the chosen side."""
    d = side * 1e-5 * s
    return (-3 * f(s) + 4 * f(s + d) - f(s + 2 * d)) / (2 * d)


def ar(r, t):
    return t if r == 0 else -math.expm1(-r * t) / r


@dataclass(frozen=True)
class Clock:
    distance: float
    adoption: float
    share: float
    name: str = ""

    def time(self, s):
        return max(self.distance / s, (1 - self.share) * self.adoption) + self.share * self.adoption

    def cap(self, s, side=0):
        if self.share == 1:
            return 1
        k = self.kink()
        if side and math.isclose(s, k, rel_tol=1e-11):
            return int(side < 0)
        return int(s < k)

    def kink(self):
        return math.inf if self.share == 1 else self.distance / ((1 - self.share) * self.adoption)


@dataclass(frozen=True)
class Model:
    cyber: Clock
    benefit: Clock
    y: float = 1.0
    vc: float = 1.0
    a: float = 0.7
    alpha: float = 1.0
    h0: float = 0.2
    h1: float = 0.4
    h2: float = 0.08
    step: float = 0.3

    def H(self, s):
        return self.a * s ** self.alpha

    def h(self, c):
        return self.h0 + self.h1 * c + self.h2 * c * c

    def hbar(self):
        k = self.cyber.distance
        return self.h0 + self.h1 * k / 2 + self.h2 * k * k / 3


CYBER = [Clock(2, 1.3, m, n) for m, n in [(0, "parallel"), (0.35, "mixed"), (1, "sequential")]]
BENEFIT = [Clock(5.2, 1.1, m, n) for m, n in [(0, "parallel"), (0.6, "mixed"), (1, "sequential")]]


def step_pv(model, s, r, dated=False):
    if not dated:
        return model.step
    return sum(w * math.exp(-r * k / s) for w, k in [(0.2, 0.3), (0.1, 1.1)])


def step_scaled_prime(s, r, dated=False):
    if not dated:
        return 0.0
    return r * sum(w * k / s * math.exp(-r * k / s) for w, k in [(0.2, 0.3), (0.1, 1.1)])


def benefit_value(model, s, r, horizon):
    arrival = model.benefit.time(s)
    if horizon is not None and arrival >= horizon:
        return 0.0
    if r == 0:
        if horizon is None:
            raise ValueError("An undiscounted perpetual benefit has no finite level")
        return model.y * (horizon - arrival)
    if horizon is None:
        return model.y / r * math.exp(-r * arrival)
    # Stable finite-horizon integral; useful for the r -> 0 check.
    return model.y * math.exp(-r * arrival) * ar(r, horizon - arrival)


def objective(model, s, hazard, r=0.0, horizon=50.0, dated=False):
    """Evaluate the primitive ledger, integrating the level hazard in calendar time."""
    tau = model.cyber.distance / s
    end = model.cyber.time(s)
    if hazard == "speed":
        cyber = model.H(s) * ar(r, end)
    else:
        cyber = simpson(lambda t: math.exp(-r * t) * model.h(s * t), 0, tau)
        # Integrate the constant endpoint-hazard tail analytically.
        cyber += model.h(model.cyber.distance) * math.exp(-r * tau) * ar(r, end - tau)
    cyber += step_pv(model, s, r, dated)
    return benefit_value(model, s, r, horizon) - model.vc * cyber


def activity(model, s, horizon, side=0):
    if horizon is None:
        return 1
    arrival = model.benefit.time(s)
    if side and math.isclose(arrival, horizon, rel_tol=1e-11, abs_tol=1e-11):
        # At L == adoption the positive part is identically zero, including
        # the plateau. A genuine activation requires L > adoption.
        return int(horizon > model.benefit.adoption and side > 0)
    return int(arrival < horizon)


def master(model, s, hazard, r=0.0, horizon=50.0, dated=False, side=0):
    """P16's analytic s W', independent of the finite-difference calculation."""
    tau = model.cyber.distance / s
    q = model.benefit.distance / s
    end = model.cyber.time(s)
    arrival = model.benefit.time(s)
    cc = model.cyber.cap(s, side)
    cb = model.benefit.cap(s, side)
    benefit = model.y * q * cb * activity(model, s, horizon, side) * math.exp(-r * arrival)
    if hazard == "speed":
        cyber = model.H(s) * (model.alpha * ar(r, end) - cc * tau * math.exp(-r * end))
    elif r == 0:
        cyber = tau * ((1 - cc) * model.h(model.cyber.distance) - model.hbar())
    else:
        k = model.cyber.distance
        average = simpson(
            lambda c: math.exp(-r * c / s) * (1 - r * c / s) * model.h(c), 0, k
        ) / k
        cyber = tau * (
            model.h(k) * (math.exp(-r * tau) - cc * math.exp(-r * end)) - average
        )
    return benefit - model.vc * (cyber + step_scaled_prime(s, r, dated))


def smooth(model, s, horizon):
    return (
        all(abs(s / k - 1) > 0.001 for k in (model.cyber.kink(), model.benefit.kink()) if math.isfinite(k))
        and (horizon is None or abs(model.benefit.time(s) - horizon) > 0.001)
    )


def grid_checks():
    # All nine independent timing combinations, all four branch states where
    # reachable, three hazard elasticities and three benefit scales.
    for cyber, benefit in product(CYBER, BENEFIT):
        for hazard in ("speed", "level"):
            counts = [0, 0, 0, 0]
            worst = 0.0
            ok = True
            sign_ok = True
            branches = set()
            signs = set()
            for alpha, y, s in product((0.3, 1.0, 2.0), (0.05, 1.0, 20.0), (0.25, 0.6, 1.2, 2, 3, 5, 9, 16)):
                model = Model(cyber, benefit, y=y, alpha=alpha)
                # The shorter horizon still includes the complete cyber transition.
                horizons = (cyber.time(s) + 0.51, 50.0, None)
                for r, horizon, dated in product((0.0, 0.13), horizons, (False, True)):
                    if r == 0 and horizon is None:
                        continue
                    if not smooth(model, s, horizon):
                        continue
                    val = master(model, s, hazard, r, horizon, dated)
                    numerical = s * fd(lambda v: objective(model, v, hazard, r, horizon, dated), s)
                    error = abs(val - numerical) / max(1, abs(val), abs(numerical))
                    worst = max(worst, error)
                    ok &= close(val, numerical)
                    if abs(val) > 2e-6:
                        sign_ok &= sign(val) == sign(numerical)
                    signs.add(sign(val))
                    branches.add((cyber.cap(s), benefit.cap(s)))
                    counts[0 if r == 0 else 1] += 1
                    counts[2 if activity(model, s, horizon) else 3] += 1
            tag = f"{cyber.name}/{benefit.name}, {hazard}-set"
            check("master derivatives " + tag, ok,
                  f"undiscounted={counts[0]}, discounted={counts[1]}, active={counts[2]}, inactive={counts[3]}, max_relative_error={worst:.3g}")
            check("strict/equality sign conditions " + tag, sign_ok,
                  f"branches={sorted(branches)}, signs={sorted(signs)}")


def timing_and_kink_checks():
    # Explicitly realize both orders and coincidence for all four finite-clock
    # timing pairs. All six timing/hazard cells are thereby exercised.
    for mc, mb, order in product((0.0, 0.35), (0.0, 0.6), ("cyber-first", "benefit-first", "coincident")):
        kc, kb = {"cyber-first": (1.5, 4.0), "benefit-first": (4.0, 1.5), "coincident": (2.0, 2.0)}[order]
        cyber = Clock(kc * (1 - mc), 1, mc)
        benefit = Clock(kb * (1 - mb), 1, mb)
        model = Model(cyber, benefit)
        points = sorted(set((kc, kb)))
        middle = (kc + kb) / 2 if kc != kb else 1.5 * kc
        samples = (min(points) / 2, middle, max(points) * 2)
        observed = [(cyber.cap(s), benefit.cap(s)) for s in samples]
        expected = {
            "cyber-first": [(1, 1), (0, 1), (0, 0)],
            "benefit-first": [(1, 1), (1, 0), (0, 0)],
            "coincident": [(1, 1), (0, 0), (0, 0)],
        }[order]
        check(f"ordering m={mc}, m_B={mb}, {order}", observed == expected, f"branches={observed}")
        ok = True
        for hazard, r, s in product(("speed", "level"), (0.0, 0.17), points):
            f = lambda v: objective(model, v, hazard, r, 50.0)
            left = master(model, s, hazard, r, 50.0, side=-1)
            right = master(model, s, hazard, r, 50.0, side=1)
            ok &= close(left / s, one_sided(f, s, -1), 1e-5)
            ok &= close(right / s, one_sided(f, s, 1), 1e-5)
            jump = 0.0
            if s == kc:
                hk = model.H(s) if hazard == "speed" else model.h(cyber.distance)
                jump -= model.vc * hk * cyber.distance / s * math.exp(-r * cyber.time(s))
            if s == kb:
                jump -= model.y * benefit.distance / s * math.exp(-r * benefit.time(s))
            ok &= close(right - left, jump, 1e-9)
            delta = 1e-8 * s
            ok &= close(f(s - delta), f(s + delta), 2e-6)
        check(f"one-sided derivatives, continuity and jumps m={mc}, m_B={mb}, {order}", ok)
        ok = True
        seen = set()
        for hazard, r, s, y, alpha in product(
            ("speed", "level"), (0.0, 0.17), samples, (0.05, 1.0, 20.0), (0.3, 1.0, 2.0)
        ):
            m = replace(model, y=y, alpha=alpha)
            numerical = s * fd(lambda v: objective(m, v, hazard, r, 50), s)
            expected_value = master(m, s, hazard, r, 50)
            ok &= close(numerical, expected_value)
            if abs(expected_value) > 2e-6:
                ok &= sign(numerical) == sign(expected_value)
            seen.add((cyber.cap(s), benefit.cap(s)))
        check(f"open-branch signs for both hazards m={mc}, m_B={mb}, {order}",
              ok, f"branches={sorted(seen)}")

    # One finite kink paired with a sequential clock, and no kinks with two
    # sequential clocks. These are separate from the finite/finite ordering grid.
    ok = True
    for cyber, benefit in product(CYBER, BENEFIT):
        if cyber.share != 1 and benefit.share != 1:
            continue
        model = Model(cyber, benefit)
        for hazard, r, clock in product(("speed", "level"), (0.0, 0.2), (cyber, benefit)):
            s = clock.kink()
            if not math.isfinite(s):
                ok &= clock.cap(1e6) == 1
                continue
            f = lambda v: objective(model, v, hazard, r)
            for side in (-1, 1):
                ok &= close(master(model, s, hazard, r, side=side) / s, one_sided(f, s, side), 1e-5)
    check("sequential/finite one-sided derivatives and sequential/sequential no-kink limit", ok)


def horizon_checks():
    for share in (0.0, 0.6, 1.0):
        cyber = Clock(1, 0.3, 0)
        benefit = Clock(4, 1, share)
        model = Model(cyber, benefit)
        horizon = 5.0
        s = benefit.distance / (horizon - share * benefit.adoption)
        ok = True
        for hazard, r in product(("speed", "level"), (0.0, 0.2)):
            f = lambda v: objective(model, v, hazard, r, horizon)
            left = master(model, s, hazard, r, horizon, side=-1)
            right = master(model, s, hazard, r, horizon, side=1)
            for side, val in ((-1, left), (1, right)):
                ok &= close(val / s, one_sided(f, s, side), 1e-5)
            ok &= close(right - left, model.y * benefit.distance / s * math.exp(-r * horizon))
        check(f"arrival-at-L activation kink, m_B={share}", ok, f"L={horizon}, s_L={s:.9f}")

        for horizon in (0.7, 1.0):
            ok = all(benefit_value(model, s, r, horizon) == 0
                     for s, r in product((0.2, 2, 100), (0.0, 0.2)))
            # At L=T_b and a finite benefit kink the positive part remains zero.
            if share < 1:
                k = benefit.kink()
                ok &= activity(model, k, horizon, -1) == activity(model, k, horizon, 1) == 0
            check(f"L<=T_b gives zero benefit, m_B={share}, L={horizon}", ok)

    # A cyber kink can coincide with benefit activation at the horizon.
    model = Model(Clock(1, 1, 0), Clock(4, 1, 0))
    ok = True
    s, horizon = 1.0, 4.0
    for hazard, r in product(("speed", "level"), (0.0, 0.2)):
        f = lambda v: objective(model, v, hazard, r, horizon)
        left = master(model, s, hazard, r, horizon, side=-1)
        right = master(model, s, hazard, r, horizon, side=1)
        hk = model.H(s) if hazard == "speed" else model.h(1)
        expected = 4 * math.exp(-r * horizon) - model.vc * hk * math.exp(-r)
        ok &= close(right - left, expected)
        for side, val in ((-1, left), (1, right)):
            ok &= close(val / s, one_sided(f, s, side), 1e-5)
    check("coincident cyber/horizon kink adds both one-sided changes", ok)

    model = Model(Clock(1, 1, 0), Clock(4, 1, 0))
    ok = True
    for hazard, r in product(("speed", "level"), (0.0, 0.2)):
        # L=0.8 is explicitly a benefit-only horizon in the full-transition ledger.
        # This check is of inactivity, not a claim of a common shorter cyber horizon.
        left = master(model, 4, hazard, r, 0.8, side=-1)
        right = master(model, 4, hazard, r, 0.8, side=1)
        ok &= close(left, right)
    check("benefit-clock kink has no jump when benefit is outside horizon", ok)


def threshold_checks():
    # Explicit thresholds in (8)--(10), (13)--(14), with y chosen below,
    # at and above equality; finite differences supply the observed sign.
    model = Model(Clock(1, 1, 0), Clock(4, 1, 0), a=1, alpha=1)
    s = 2.0
    for hazard, r, dated in product(("speed", "level"), (0.0, 0.2), (False, True)):
        base = master(replace(model, y=0), s, hazard, r, 10, dated)
        marginal_per_y = (model.benefit.distance / s) * math.exp(-r * model.benefit.time(s))
        critical = -base / marginal_per_y
        ok = critical > 0
        observed = []
        for factor in (0.5, 1.0, 1.5):
            m = replace(model, y=critical * factor)
            numerical = s * fd(lambda v: objective(m, v, hazard, r, 10, dated), s)
            observed.append(sign(numerical))
        ok &= observed == [-1, 0, 1]
        check(f"above-cyber threshold including equality, {hazard}, r={r}, dated_steps={dated}",
              ok, f"critical_y={critical:.9f}, numerical_signs={observed}")

    model = Model(Clock(1, 1, 0), Clock(4, 1, 0), a=1, alpha=2, step=0)
    s = 0.5
    derivative = fd(lambda v: objective(model, v, "speed", horizon=10), s)
    check("below-cyber kink can improve with epsilon_H=2>1", close(derivative, 15),
          f"s={s}, epsilon_H=2, B_prime=16, C_prime=1, W_prime={derivative:.9f}")

    # Level-set endpoint hazards below, equal to, and above the average.
    for h0, h1, expected_sign in ((1.0, -0.2, 1), (0.5, 0.0, 0), (0.2, 0.4, -1)):
        m = replace(model, h0=h0, h1=h1, h2=0)
        derivative = fd(lambda v: objective(m, v, "level", horizon=10), 6)
        check(f"level-set no-benefit-marginal row h1={h1}", sign(derivative) == expected_sign,
              f"hK={m.h(1):.6f}, hbar={m.hbar():.6f}, W_prime={derivative:.9f}")


def discount_and_policy_checks():
    ok_steps = True
    for s, r in product((0.4, 2, 6), (0.03, 0.4)):
        model = Model(CYBER[0], BENEFIT[0])
        numerical = s * fd(lambda v: step_pv(model, v, r, True), s)
        ok_steps &= close(numerical, step_scaled_prime(s, r, True))
        ok_steps &= numerical > 0
    check("dated capability steps: constant mass, rising present value with speed", ok_steps)

    ok_limit = True
    for cyber, benefit, hazard, s in product(CYBER, BENEFIT, ("speed", "level"), (0.8, 2.8, 12)):
        model = Model(cyber, benefit)
        small = 1e-9
        ok_limit &= close(master(model, s, hazard, small, 50, True),
                          master(model, s, hazard, 0, 50, True), 5e-6)
        ok_limit &= close(benefit_value(model, s, small, 50),
                          benefit_value(model, s, 0, 50), 5e-6)
    check("r->0: both hazard derivatives and finite-horizon benefit levels converge", ok_limit)

    model = Model(Clock(1, 1, 0), Clock(4, 1, 0), y=1e-20)
    ok = True
    for r, s in product((0.01, 0.2, 1.0), (0.4, 0.8)):
        x = r / s
        threshold = x / math.expm1(x)
        for factor in (0.8, 1.2):
            m = replace(model, alpha=factor * threshold)
            ok &= sign(master(m, s, "speed", r)) == (1 if factor < 1 else -1)
        ok &= 0 < threshold < 1
    check("no-benefit limit reproduces P4(ii)'s discounted elasticity threshold", ok)

    # A direct integral of the speed-set calendar hazard independently checks
    # the discounting of losses as well as benefits.
    model = Model(Clock(1, 1, 0.35), Clock(4, 1, 0.6))
    ok = True
    for s, r in product((0.5, 2, 6), (0.1, 0.4)):
        numerical = simpson(lambda t: model.H(s) * math.exp(-r * t), 0, model.cyber.time(s))
        ok &= close(numerical, model.H(s) * ar(r, model.cyber.time(s)), 1e-8)
        arrival = model.benefit.time(s)
        numerical = simpson(lambda t: model.y * math.exp(-r * t), arrival, 20)
        ok &= close(numerical, benefit_value(model, s, r, 20), 1e-7)
    check("calendar integrals discount both sides consistently", ok)

    # Adoption intervention: level changes and the speed derivative differ.
    for share in (0.0, 0.6, 1.0):
        m = replace(model, benefit=Clock(4, 1, share))
        faster = replace(m, benefit=Clock(4, 0.8, share))
        s = 1.0  # Both points remain on the capability branch.
        b0 = benefit_value(m, s, 0, 10)
        b1 = benefit_value(faster, s, 0, 10)
        d0 = fd(lambda v: benefit_value(m, v, 0, 10), s)
        d1 = fd(lambda v: benefit_value(faster, v, 0, 10), s)
        check(f"shorter T_b: undiscounted capability marginal unchanged, m_B={share}",
              close(d0, d1) and close(b1 - b0, 0.2 * share),
              f"benefit_level_gain={b1-b0:.9f}, marginal_before={d0:.9f}, after={d1:.9f}")
        r = 0.2
        d0 = fd(lambda v: benefit_value(m, v, r, None), s)
        d1 = fd(lambda v: benefit_value(faster, v, r, None), s)
        check(f"shorter T_b: discounted marginal dating qualification, m_B={share}",
              close(d1 / d0, math.exp(r * share * 0.2)),
              f"discounted_marginal_ratio={d1/d0:.9f}")

    ok = True
    for benefit, s in product(BENEFIT, (0.2, 1, 4, 20)):
        m = Model(CYBER[0], benefit)
        faster = replace(m, benefit=replace(benefit, adoption=0.8 * benefit.adoption))
        for r in (0.0, 0.2):
            ok &= benefit_value(faster, s, r, 50) >= benefit_value(m, s, r, 50) - 1e-10
    check("shorter benefit adoption weakly improves levels across regimes", ok)

    m = Model(CYBER[0], Clock(5, 2, 0.6))
    s = 1.0
    measured = -s * fd(lambda v: math.log(m.benefit.time(v)), s)
    expected = (5 / s) / (5 / s + 0.6 * 2)
    check("m_B is not the capability-set waiting share", close(measured, expected) and not close(expected, 0.6),
          f"m_B=0.6, capability_waiting_share={measured:.9f}")

    # Discounted level-set signs need their own formula: faster traversal
    # brings an increasing hazard forward in calendar time.
    m = Model(Clock(1, 1, 0), Clock(1, 1, 0), y=1e-20, h0=0, h1=1, h2=0)
    s, r = 0.1, 1.0
    undisc = master(m, s, "level", 0, 50)
    disc = master(m, s, "level", r, 50)
    numerical = s * fd(lambda v: objective(m, v, "level", r, 50), s)
    check("discounted level-set sign can differ from undiscounted capability-branch sign",
          undisc > 0 > disc and close(disc, numerical),
          f"sW_undisc_prime={undisc:.9f}, sW_disc_prime={disc:.9f}")


def optimum_checks():
    model = Model(Clock(1, 1, 0), Clock(4, 1, 0), a=1, alpha=1, step=0)
    f = lambda s: objective(model, s, "speed", horizon=10)
    grid = [0.5 + 0.0005 * j for j in range(11001)]
    best = max(grid, key=f)
    critical = math.sqrt(4)
    derivative = fd(f, critical)
    second = (f(critical + 1e-3) - 2 * f(critical) + f(critical - 1e-3)) / 1e-6
    check("illustrative optimum above cyber kink", close(best, 2, 1e-10) and close(f(best), 6),
          f"K=T_a=V_c=y=T_b=1, K_B=4, H=s, S=0, L=10, I=[0.5,6]; grid_max_s={best:.6f}, W={f(best):.6f}")
    check("illustrative optimum: FOC, strict local curvature and branch inequalities",
          abs(derivative) < 1e-7 and close(second, -1, 1e-5) and 1 < critical < 4,
          f"W_prime(2)={derivative:.9f}, W_second(2)={second:.9f}")
    vals = [(s, f(s)) for s in (0.5, 1, 2, 4, 6)]
    check("illustrative optimum dominates endpoints and both clock kinks",
          all(close(v, expected) for (_, v), expected in zip(vals, (1, 5, 6, 5, 3))),
          f"values={vals}")
    ok = True
    for s, expected_left, expected_right in ((1, 4, 3), (4, -0.75, -1)):
        ok &= close(one_sided(f, s, -1), expected_left)
        ok &= close(one_sided(f, s, 1), expected_right)
    check("illustrative example one-sided derivatives at both kinks", ok,
          "s=1: (4,3); s=4: (-0.75,-1)")
    check("counterexample to benefits always justify speed",
          close(benefit_value(model, 5, 0, 10), 9) and close(fd(f, 5), -1)
          and close(f(5), 4) and close(f(6), 3),
          f"B_L(5)=9, W_prime(5)={fd(f,5):.9f}, W(5)={f(5):.6f}, W(6)={f(6):.6f}")

    # The power-hazard sufficient condition in (21), with noninteger powers.
    for alpha in (0.4, 1.0, 2.3):
        m = replace(model, alpha=alpha, benefit=Clock(9, 1, 0.4))
        s0 = (m.y * 9 / alpha) ** (1 / (alpha + 1))
        g = lambda s: objective(m, s, "speed", horizon=30)
        d = 1e-3 * s0
        numerical_second = (g(s0 + d) - 2 * g(s0) + g(s0 - d)) / d ** 2
        expected_second = -(alpha + 1) * 9 / s0 ** 3
        check(f"above-cyber power-hazard sufficient condition, alpha={alpha}",
              1 < s0 < 15 and abs(fd(g, s0)) < 1e-6
              and close(numerical_second, expected_second, 2e-5)
              and master(m, 0.9 * s0, "speed", horizon=30) > 0
              and master(m, 1.1 * s0, "speed", horizon=30) < 0,
              f"s0={s0:.9f}, numerical_second={numerical_second:.9f}")

    # Endpoint signs exclude endpoints without asserting uniqueness.
    check("compact-interval endpoint-sign sufficient condition",
          one_sided(f, 0.5, 1) > 0 > one_sided(f, 6, -1))
    # A separate example has a strict maximum at a coincident kink.
    m = replace(model, benefit=Clock(1, 1, 0), y=2)
    g = lambda s: objective(m, s, "speed", horizon=10)
    check("strict one-sided condition permits a maximum at coincident kinks",
          one_sided(g, 1, -1) > 0 > one_sided(g, 1, 1)
          and all(g(1) > g(s) for s in (0.5, 0.9, 1.1, 2, 6)))

    # Continuous increasing W with an unattained supremum on an unbounded set.
    def unbounded_w(s):
        return benefit_value(replace(model, benefit=Clock(1, 1, 1)), s, 0, 10) - (1 - 1 / (2 * s))
    check("upper compactness assumption matters: no attained maximum in illustrative unbounded case",
          all(close(unbounded_w(s), 8 - 1 / (2 * s)) and unbounded_w(s) < 8 for s in (1, 2, 10, 10000))
          and unbounded_w(2) > unbounded_w(1),
          "sequential benefits, H=1-1/(2s), s>=1, W=8-1/(2s), sup=8 not attained")

    # (23): a far-loss slope is an additional marginal debit, including
    # where the near cyber loss itself rises.
    s, va, ca_slope = 1.5, 2.0, 0.1
    full = lambda v: f(v) - va * ca_slope * v
    expected = fd(f, s) - va * ca_slope
    check("P4 connection uses B_prime - V_c C_c_prime - V_A C_A_prime",
          close(fd(full, s), expected) and expected > 0 and s > 1,
          f"s=1.5, near_cyber_prime=1, full_W_prime={fd(full,s):.9f}")


def mutation_checks():
    """A check passes only if the deliberately wrong formula is detected."""
    m = Model(Clock(1, 1, 0), Clock(4, 1, 0), a=1, step=0)
    s = 5.0
    actual = s * fd(lambda v: objective(m, v, "speed", horizon=10), s)
    wrong = master(m, s, "speed", horizon=10) + m.y * m.benefit.distance / s
    check("reject mutation: benefit continues to have a speed derivative after adoption binds",
          not close(actual, wrong), f"actual_sW_prime={actual:.6f}, wrong={wrong:.6f}")

    s, r = 2.0, 0.2
    actual = s * fd(lambda v: objective(m, v, "speed", r, 10), s)
    wrong = m.y * (4 / s) * math.exp(-r * m.benefit.time(s)) - m.H(s) * m.alpha * 1
    check("reject mutation: discount benefits but leave cyber losses undiscounted", not close(actual, wrong))

    s = 0.5
    mixed = replace(m, cyber=Clock(1, 1, 0.4), alpha=1)
    actual = s * fd(lambda v: objective(mixed, v, "speed", horizon=10), s)
    wrong = mixed.y * 4 / s - mixed.H(s) * (mixed.alpha - 1) / s
    check("reject mutation: omit the mixed cyber adoption tail in the elasticity test", not close(actual, wrong))

    s = 2.0
    actual = s * fd(lambda v: objective(m, v, "speed", r, 10, True), s)
    wrong = master(m, s, "speed", r, 10, False)
    check("reject mutation: fixed undiscounted step mass implies zero discounted step derivative",
          not close(actual, wrong))

    actual = s * fd(lambda v: objective(m, v, "level", 0, 10), s)
    wrong = m.y * 4 / s  # Treat h(K) as a constant H and omit the path term.
    check("reject mutation: level-set hazard is a constant speed-set rectangular hazard",
          not close(actual, wrong))

    actual = s * fd(lambda v: objective(m, v, "speed", 0, 1.5), s)
    wrong = master(m, s, "speed", 0, 10)
    check("reject mutation: count benefits before their arrival within L", not close(actual, wrong))


def main():
    check("audit scope: all parameter values illustrative, not empirical estimates", True,
          "standard library; deterministic grids; primitive calendar integrals and finite differences; all 9 timing pairs")
    grid_checks()
    timing_and_kink_checks()
    horizon_checks()
    threshold_checks()
    discount_and_policy_checks()
    optimum_checks()
    mutation_checks()
    check("SUMMARY all checks", not FAILURES, f"checks_including_summary={CHECKS + 1}, failed={len(FAILURES)}")
    return int(bool(FAILURES))


if __name__ == "__main__":
    sys.exit(main())
