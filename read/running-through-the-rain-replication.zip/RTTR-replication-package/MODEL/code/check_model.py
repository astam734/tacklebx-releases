#!/usr/bin/env python3
"""check_model.py -- numerical audit of the fifteen propositions in MODEL-SECTION.md.

Standard library only; fixed seed. Every output line is one of:
  PASS / FAIL             (i)   a check of a stated or corrected result, by a method that
                                does not use the closed form (grids, Monte Carlo, ODE
                                integration, quadrature, best-response search with corners)
  REJECTED / MISSED       (ii)  a pre-registered mutation: a deliberately wrong formula that
                                the checks must reject
  REPRODUCED / NOT-REPRO  (iii) a counterexample to an original claim judged false
  IDENTITY / ID-FAIL            a confirmation that is true by algebra (an evaluation of the
                                model's own definitions or of an elementary inequality); it can
                                fail only if the code is wrong, and it is NOT counted among the
                                checks of stated results
  NOTE                    (iv)  a definition, or an assumption violation that implies no reversal
Counterexamples that hold by construction (arithmetic on a definition) are tagged
"[counterexample, by construction]" and counted separately in the summary.
Exit status 0 only if every check passes, every identity holds, every mutation is
rejected and every counterexample reproduces.

Run:  python3 -I code/check_model.py > code/check_model_out.txt
 or:  python3 -I code/check_model.py --out code/check_model_out.txt   (same text, also to stdout)
"""
import math
import random
import sys

if "--out" in sys.argv:
    class _Tee:
        def __init__(self, path):
            self.f, self.o = open(path, "w"), sys.stdout

        def write(self, s):
            self.f.write(s)
            self.o.write(s)

        def flush(self):
            self.f.flush()
            self.o.flush()
    sys.stdout = _Tee(sys.argv[sys.argv.index("--out") + 1])

SEED = 20261022
RNG = random.Random(SEED)
BAD = []
COUNT = {"check": 0, "identity": 0, "mutation": 0, "counter": 0, "counter_bc": 0, "note": 0}


def check(name, ok, detail=""):
    COUNT["check"] += 1
    print(("PASS        " if ok else "FAIL        ") + name + ("  | " + detail if detail else ""))
    if not ok:
        BAD.append("check: " + name)


def identity(name, ok, detail=""):
    COUNT["identity"] += 1
    print(("IDENTITY    " if ok else "ID-FAIL     ") + name + ("  | " + detail if detail else ""))
    if not ok:
        BAD.append("identity: " + name)


def mutation(name, rejected, detail=""):
    COUNT["mutation"] += 1
    print(("REJECTED    " if rejected else "MISSED      ") + "[mutation] " + name
          + ("  | " + detail if detail else ""))
    if not rejected:
        BAD.append("mutation: " + name)


def counter(name, reproduced, detail="", by_construction=False):
    COUNT["counter_bc" if by_construction else "counter"] += 1
    tag = "[counterexample, by construction] " if by_construction else "[counterexample] "
    print(("REPRODUCED  " if reproduced else "NOT-REPRO   ") + tag + name
          + ("  | " + detail if detail else ""))
    if not reproduced:
        BAD.append("counterexample: " + name)


def note(text):
    COUNT["note"] += 1
    print("NOTE        " + text)


# ------------------------------------------------------------------ numerics
def close(a, b, tol):
    return abs(a - b) <= tol * max(1.0, abs(a), abs(b))


def d1(f, x, h=1e-6):
    return (f(x + h) - f(x - h)) / (2 * h)


def argmax(f, lo, hi, n=2000, iters=80):
    """Global maximiser of f on [lo, hi] from evaluations only: dense grid (endpoints
    included, so corners are candidates), then golden-section refinement."""
    xs = [lo + (hi - lo) * i / n for i in range(n + 1)]
    vals = [f(x) for x in xs]
    bi = max(range(n + 1), key=lambda i: vals[i])
    a, b = xs[max(bi - 1, 0)], xs[min(bi + 1, n)]
    g = (math.sqrt(5) - 1) / 2
    c1, c2 = b - g * (b - a), a + g * (b - a)
    f1, f2 = f(c1), f(c2)
    for _ in range(iters):
        if f1 < f2:
            a, c1, f1 = c1, c2, f2
            c2 = a + g * (b - a)
            f2 = f(c2)
        else:
            b, c2, f2 = c2, c1, f1
            c1 = b - g * (b - a)
            f1 = f(c1)
    xm = (a + b) / 2
    return max([(f(xm), xm), (vals[bi], xs[bi]), (vals[0], lo), (vals[-1], hi)])[1]


def bisect(f, lo, hi, iters=200):
    flo = f(lo)
    for _ in range(iters):
        mid = (lo + hi) / 2
        fm = f(mid)
        if (fm > 0) == (flo > 0):
            lo, flo = mid, fm
        else:
            hi = mid
    return (lo + hi) / 2


def simpson(f, a, b, n=4000):
    n += n % 2
    h = (b - a) / n
    s = f(a) + f(b)
    for i in range(1, n):
        s += (4 if i % 2 else 2) * f(a + i * h)
    return s * h / 3


def rk4_path(rhs, y0, t1, dt):
    t, y = 0.0, y0
    out = [(t, y)]
    for _ in range(int(round(t1 / dt))):
        k1 = rhs(t, y)
        k2 = rhs(t + dt / 2, y + dt * k1 / 2)
        k3 = rhs(t + dt / 2, y + dt * k2 / 2)
        k4 = rhs(t + dt, y + dt * k3)
        y += dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6
        t += dt
        out.append((t, y))
    return out


def m_exp(lam, tau):
    """E[min(W, tau)] for W ~ Exp(lam) (closed form under test in P6)."""
    return (1 - math.exp(-lam * tau)) / lam


# Two-player Tullock contest (r = 1), used by P9, P10, P15.
def u2(x, y, P):
    X = x + y
    p = 0.5 if X == 0 else x / X
    haz = P["th"] * X * X if P.get("quad") else P["th"] * X
    return (p * P["vW"] + (1 - p) * P["vL"] - P["c"] * x - 0.5 * P.get("k", 0.0) * x * x
            - P["L"] * haz + P.get("bp", 0.0) * X)


def br2(y, P, hi):
    return argmax(lambda x: u2(x, y, P), 0.0, hi)


def nash2(P1, P2, hi, x0=0.1, tol=1e-10, maxit=400):
    x1 = x2 = x0
    for _ in range(maxit):
        n1 = 0.5 * x1 + 0.5 * br2(x2, P1, hi)
        n2 = 0.5 * x2 + 0.5 * br2(x1, P2, hi)
        if abs(n1 - x1) + abs(n2 - x2) < tol:
            return n1, n2
        x1, x2 = n1, n2
    return x1, x2


def is_nash2(x1, x2, P1, P2, hi, tol=1e-7):
    g1 = u2(br2(x2, P1, hi), x2, P1) - u2(x1, x2, P1)
    g2 = u2(br2(x1, P2, hi), x1, P2) - u2(x2, x1, P2)
    return g1 <= tol and g2 <= tol and u2(0.0, x2, P1) <= u2(x1, x2, P1) + tol


print("check_model.py  seed=%d" % SEED)
print()

# ================================================================== S0
print("== S0  Set-up: the loss index counts expected harmful events (Poisson)")
LAM_TOT, n = 0.7, 200000
cnt, any_ = 0, 0
for _ in range(n):
    t, k = RNG.expovariate(1.0), 0
    while t < LAM_TOT:
        k += 1
        t += RNG.expovariate(1.0)
    cnt += k
    any_ += k > 0
check("cumulative hazard 0.7: mean event count %.4f = 0.7; P(at least one) %.4f = 1-e^-0.7 = %.4f"
      % (cnt / n, any_ / n, 1 - math.exp(-LAM_TOT)),
      abs(cnt / n - 0.7) < 0.01 and abs(any_ / n - (1 - math.exp(-0.7))) < 0.005)
# cause-specific intensities of mutually exclusive exits add; marginal rates of causes sharing a shock do not
rates = [0.1, 0.2, 0.05]
mn = sum(min(RNG.expovariate(r) for r in rates) for _ in range(n)) / n
check("cause-specific intensities (0.1, 0.2, 0.05) of mutually exclusive exits: mean first arrival %.3f = 1/0.35 = %.3f" % (mn, 1 / 0.35),
      abs(mn - 1 / 0.35) < 0.03)
mn2 = sum(RNG.expovariate(0.2) for _ in range(n)) / n   # leak and theft triggered by one event
counter("marginal hazards of causes that share one shock do not add: two causes with marginal rate 0.2 each, one common shock",
        abs(mn2 - 1 / 0.4) > 1.0, "mean first arrival %.3f, not 1/(0.2+0.2) = 2.5; the shock is one exit, counted once" % mn2)
print()

# ================================================================== P1
print("== P1  Speed threshold with a constant adoption time")
K, TA, S0 = 2.0, 1.0, 0.3
SSTAR = K / TA
HFAM = {
    "H=s^0.6": (lambda s: s ** 0.6, lambda s: 0.6 * s ** -0.4, lambda s: 0.6),
    "H=s^1.4": (lambda s: s ** 1.4, lambda s: 1.4 * s ** 0.4, lambda s: 1.4),
    "H=1+s^2": (lambda s: 1 + s * s, lambda s: 2 * s, lambda s: 2 * s * s / (1 + s * s)),
}


def Rc(H, s, K=K, Ta=TA, S=S0):
    return H(s) * max(K / s, Ta) + S


for name, (H, dH, eps) in HFAM.items():
    ok, err, npts = True, 0.0, 0
    for i in range(5, 400):
        s = 0.01 * i
        if abs(s - SSTAR) < 0.02 or abs(eps(s) - 1) < 1e-3:
            continue
        num = d1(lambda x: Rc(H, x), s)
        if s < SSTAR:
            cf, pred_neg = K * H(s) / s ** 2 * (eps(s) - 1), eps(s) < 1
        else:
            cf, pred_neg = dH(s) * TA, False
        err = max(err, abs(num - cf) / max(1, abs(cf)))
        ok = ok and ((num < 0) == pred_neg)
        npts += 1
    check("%s: dR/ds = (K H/s^2)(eps_H-1) below s*, = H' T_a above; sign rule on %d grid points"
          % (name, npts), ok and err < 1e-5, "max rel. error %.1e" % err)
    h = 1e-7
    left = (Rc(H, SSTAR) - Rc(H, SSTAR - h)) / h
    right = (Rc(H, SSTAR + h) - Rc(H, SSTAR)) / h
    lcf, rcf = H(SSTAR) * TA / SSTAR * (eps(SSTAR) - 1), dH(SSTAR) * TA
    check("%s: one-sided derivatives at s*=2: left %.5f (cf %.5f), right %.5f (cf %.5f)"
          % (name, left, lcf, right, rcf), close(left, lcf, 1e-4) and close(right, rcf, 1e-4))
smin = argmax(lambda s: -Rc(HFAM["H=s^0.6"][0], s), 0.05, 4.0)
check("H=s^0.6 (eps_H < 1 everywhere): global minimiser of R_c is s* = 2 (found %.4f)" % smin,
      abs(smin - SSTAR) < 1e-3)
smin = argmax(lambda s: -Rc(HFAM["H=1+s^2"][0], s), 0.05, 4.0)
check("H=1+s^2: global minimiser is where eps_H = 1, s = 1 < s* (found %.4f)" % smin, abs(smin - 1) < 1e-3)
smin14 = argmax(lambda s: -Rc(HFAM["H=s^1.4"][0], s), 0.05, 4.0)
check("H=s^1.4 (eps_H > 1 everywhere) on [s_min, 4] = [0.05, 4]: the minimiser is the lower endpoint s_min (found %.4f)" % smin14,
      abs(smin14 - 0.05) < 1e-9, "R_c(0.05) = %.4f < R_c(s*) = %.4f" % (Rc(HFAM["H=s^1.4"][0], 0.05), Rc(HFAM["H=s^1.4"][0], SSTAR)))
mutation("M1c 'otherwise R_c is minimised where eps_H = 1 below s*, or at s*' (no lower endpoint)",
         abs(smin14 - SSTAR) > 0.5, "H=s^1.4 has no point with eps_H = 1, so the sentence predicts s* = 2; the minimiser is %.2f" % smin14)
# flat valley (non-isolated eps_H = 1): H = s q(s), K = 4, T_a = 1, s_min = 1, so s* = 4 and R_c = 4 q(s) + S below s*
qv = lambda s: 1 + 0.1 * max(2 - s, 0) ** 2 + 0.1 * max(s - 3, 0) ** 2
Hv = lambda s: s * qv(s)
dHv = lambda s: qv(s) + s * (-0.2 * max(2 - s, 0) + 0.2 * max(s - 3, 0))
epsv = lambda s: s * dHv(s) / Hv(s)
gridv = [1 + 5 * i / 5000 for i in range(5001)]
Rv = [Rc(Hv, s, K=4.0, Ta=1.0) for s in gridv]
Rvmin = min(Rv)
argv = [s for s, v in zip(gridv, Rv) if v - Rvmin < 1e-12]
check("flat valley H = s q(s), q = 1 + (2-s)_+^2/10 + (s-3)_+^2/10, K = 4, T_a = 1, s_min = 1: H' > 0 and the minimisers of R_c are exactly [2, 3], with eps_H = 1 throughout",
      all(dHv(s) > 0 for s in gridv) and abs(argv[0] - 2) < 1e-12 and abs(argv[-1] - 3) < 1e-12 and len(argv) == 1001
      and all(abs(epsv(s) - 1) < 1e-12 for s in argv) and min(Rv[999], Rv[2001]) > Rvmin + 1e-8,
      "%d grid minimisers on [%.3f, %.3f] (step 0.001), R_c = %.4f; R_c(1.999) - min = %.1e" % (len(argv), argv[0], argv[-1], Rvmin, Rv[999] - Rvmin))
upx = [s for s in argv if epsv(s - 0.01) < 1 - 1e-12 and epsv(s + 0.01) > 1 + 1e-12]
mutation("M1d 'an interior minimiser is a point where eps_H crosses 1 from below' (isolation not assumed)",
         not upx and gridv[0] not in argv and 4.0 not in argv,
         "none of the %d minimisers is a strict upward crossing, and neither s_min nor s* minimises" % len(argv))
bad = 0
for i in range(5, 199):
    s = 0.01 * i
    for name, (H, dH, eps) in HFAM.items():
        if abs(eps(s) - 1) > 1e-3 and (d1(lambda x: Rc(H, x), s) < 0) != (eps(s) > 1):
            bad += 1
mutation("M1a 'below s*, acceleration lowers R_c iff eps_H > 1'", bad > 0, "%d grid points contradict it" % bad)
mutation("M1b 's* = T_a/K'", abs(K / (TA / K) - TA) > 1e-9,
         "at s = T_a/K = 0.5, K/s - T_a = %.2f, so the branches do not meet there" % (K / (TA / K) - TA))
print()

# ================================================================== P2
print("== P2  The step term S")
note("P2, first sentence: a modeling assumption. S = sum_k N_k psi_k d_k carries no speed argument, so dS/ds = 0 by construction.")
N_, psi, dmg = 100, 0.2, 1.0
counter("P2 'only fewer exploitable flaws reduce S': halve damage per exploit d, flaw count N and exploit success psi fixed",
        N_ * psi * dmg / 2 < N_ * psi * dmg, "S = %.1f -> %.1f with N = %d and psi = %.1f unchanged" % (N_ * psi * dmg, N_ * psi * dmg / 2, N_, psi),
        by_construction=True)
counter("P2 same claim, second form: halve exploit success psi, flaw count fixed",
        N_ * psi / 2 * dmg < N_ * psi * dmg, "S = %.1f -> %.1f with N = %d unchanged" % (N_ * psi * dmg, N_ * psi / 2 * dmg, N_),
        by_construction=True)
psi_s = lambda s: 0.2 * (1 + 0.5 * s) / 1.5
counter("P2 'no speed reduces S' once exploit success at a step depends on attackers' tools when it lands",
        N_ * psi_s(0.5) < N_ * psi_s(1.0), "S = %.2f at s = 0.5 vs %.2f at s = 1" % (N_ * psi_s(0.5), N_ * psi_s(1.0)),
        by_construction=True)
print()

# ================================================================== P3
print("== P3  An intermediate peak on a specified flaw-stock path: dE/dt = iota(t) - mu E, hazard = phi E")


def peak_cf(mu, gam, i0, i1):
    if mu * i0 <= gam * i1:
        return None
    return math.log((mu * i0 - gam * i1) / (gam * (i0 - i1))) / (mu - gam)


def peak_num(mu, iota, t1=150.0, dt=0.01):
    path = rk4_path(lambda t, E: iota(t) - mu * E, 0.0, t1, dt)
    first, changes, prev = None, 0, None
    for (t, E) in path:
        dE = iota(t) - mu * E
        if abs(dE) < 1e-10:
            continue
        if prev is not None and (dE > 0) != (prev[1] > 0):
            changes += 1
            if first is None:
                first = prev[0] + (t - prev[0]) * prev[1] / (prev[1] - dE)
        prev = (t, dE)
    return first, changes


ok, rows, cases = True, [], 0
for mu in [0.2, 0.5, 1.0]:
    for gam in [0.1, 0.3, 0.8, 2.0]:
        for (i0, i1) in [(1.0, 0.0), (1.0, 0.3), (1.0, 0.7)]:
            iota = (lambda i0, i1, gam: (lambda t: i1 + (i0 - i1) * math.exp(-gam * t)))(i0, i1, gam)
            tn, ch = peak_num(mu, iota)
            tc = peak_cf(mu, gam, i0, i1)
            rows.append((mu, gam, i0, i1, tn, ch, tc))
            cases += 1
            if tc is None:
                ok = ok and tn is None
            else:
                ok = ok and tn is not None and abs(tn - tc) < 0.02 and ch == 1
check("peak exists iff mu*iota0 > gam*iota1, at t^ = ln[(mu i0 - gam i1)/(gam(i0 - i1))]/(mu - gam), single-peaked (%d cases, RK4)" % cases,
      ok, "%d with a peak, %d without" % (sum(1 for r in rows if r[6] is not None), sum(1 for r in rows if r[6] is None)))
bad = sum(1 for (mu, gam, i0, i1, tn, ch, tc) in rows if (gam * i0 > mu * i1) != (tn is not None))
mutation("M3a 'peak iff gam*iota0 > mu*iota1'", bad > 0, "%d of %d cases misclassified" % (bad, cases))
bad = 0
for (mu, gam, i0, i1, tn, ch, tc) in rows:
    if tc is not None:
        wrong = math.log((mu * i0 - gam * i1) / (gam * (i0 - i1))) / (gam - mu)
        bad += abs(wrong - tn) > 0.02
mutation("M3b 'peak time with denominator (gam - mu)'", bad > 0, "%d peak times wrong" % bad)
# counterexamples to the original sentence
path = rk4_path(lambda t, E: math.exp(t) - math.exp(2 * t) * E, 0.0, 3.0, 1e-4)
tm, Em = max(((t, E) for (t, E) in path), key=lambda z: z[1])
counter("P3 'interior maximum only if introduction stays bounded': iota = e^t (unbounded on [0, inf)), mu = e^2t",
        0.05 < tm < 2.9 and path[-1][1] < 0.5 * Em,
        "E peaks at t = %.3f (E = %.4f) and falls to %.4f at t = 3" % (tm, Em, path[-1][1]))
path = rk4_path(lambda t, E: 1 + t - 0.1 * E, 0.0, 100.0, 0.01)
mono = all(path[i + 1][1] > path[i][1] for i in range(len(path) - 1))
counter("P3 'otherwise it plateaus': iota = 1 + t, mu = 0.1 grows without bound, no plateau",
        mono and path[-1][1] - path[5000][1] > 100, "E(50) = %.1f, E(100) = %.1f" % (path[5000][1], path[-1][1]))
path = rk4_path(lambda t, E: 1.0 - 0.5 * E, 0.0, 60.0, 0.01)
mono = all(path[i + 1][1] >= path[i][1] for i in range(len(path) - 1))
counter("P3 read as 'bounded introduction gives a peak': iota = 1, mu = 0.5 rises monotonically to a plateau",
        mono and abs(path[-1][1] - 2.0) < 1e-6, "E(60) = %.6f = iota/mu" % path[-1][1])
# (iii) at mu = gam: peak time iota0/(mu(iota0 - iota1))
ok, rows_eq = True, []
for (mu, i0, i1) in [(0.5, 1.0, 0.3), (1.0, 1.0, 0.0), (0.2, 2.0, 1.5)]:
    iota = (lambda i0, i1, mu: (lambda t: i1 + (i0 - i1) * math.exp(-mu * t)))(i0, i1, mu)
    tn, ch = peak_num(mu, iota)
    tc = i0 / (mu * (i0 - i1))
    rows_eq.append("mu=gam=%.1f: %.3f vs %.3f" % (mu, tn if tn is not None else -1, tc))
    ok = ok and tn is not None and abs(tn - tc) < 0.02 and ch == 1
check("(iii) at mu = gam the peak time is iota0/(mu(iota0 - iota1)) (three cases, RK4)", ok, "; ".join(rows_eq))
# (ii) constant mu, non-increasing differentiable iota, E(0) < iota(0)/mu: at most one peak (E' is + then -, never - then +)
ok, desc = True, []
for (label, mu, iota) in [("iota = 1, mu = 0.5", 0.5, lambda t: 1.0), ("iota = 1 + e^-t, mu = 0.3", 0.3, lambda t: 1 + math.exp(-t)),
                          ("iota = 1/(1+t), mu = 0.2", 0.2, lambda t: 1 / (1 + t)), ("iota = 2 - tanh(t), mu = 1", 1.0, lambda t: 2 - math.tanh(t))]:
    path = rk4_path(lambda t, E: iota(t) - mu * E, 0.0, 100.0, 0.01)
    sg = [iota(t) - mu * E > 0 for (t, E) in path if abs(iota(t) - mu * E) > 1e-9]
    up_after_down = any((not sg[i]) and sg[i + 1] for i in range(len(sg) - 1))
    nchg = sum(1 for i in range(len(sg) - 1) if sg[i] != sg[i + 1])
    ok = ok and sg[0] and not up_after_down and nchg <= 1
    desc.append("%s: %d peak(s)" % (label, nchg))
check("(ii) constant mu, non-increasing iota, E(0) < iota(0)/mu: at most one peak, monotone paths allowed (four cases, RK4)", ok, "; ".join(desc))
# finite pre-ASI horizon: T_A = 1, E = t(1-t), mu = (1-t)^-2, iota = 1 - 2t + t/(1-t)
iotaF = lambda t: 1 - 2 * t + t / (1 - t)
muF = lambda t: (1 - t) ** -2
path = rk4_path(lambda t, E: iotaF(t) - muF(t) * E, 0.0, 0.95, 1e-5)
errF = max(abs(E - t * (1 - t)) for (t, E) in path)
tmF, EmF = max(path, key=lambda z: z[1])
posF = all(iotaF(0.001 * i) > 0 for i in range(1000))
counter("P3 on a finite horizon [0, T_A) = [0, 1): iota = 1 - 2t + t/(1-t) positive and unbounded, mu = (1-t)^-2, yet an interior peak and no plateau",
        errF < 1e-6 and abs(tmF - 0.5) < 1e-3 and posF and iotaF(1 - 1e-9) > 1e8 and path[-1][1] < 0.25 * EmF,
        "RK4 matches E = t(1-t) (max error %.1e); peak at t = %.4f (E = %.4f); E(0.95) = %.4f; iota(1 - 1e-9) = %.1e"
        % (errF, tmF, EmF, path[-1][1], iotaF(1 - 1e-9)))
print()

# ================================================================== P4
print("== P4  Two peaks: local criterion, break-even ratio, discrete moves, discounting")
H6 = HFAM["H=s^0.6"][0]
Cc = lambda s: Rc(H6, s)
CA = lambda s: 0.05 * s * s
ok, npts = True, 0
for VA in [0.5, 2.0, 5.0]:
    for i in range(5, 400):
        s = 0.01 * i
        if abs(s - SSTAR) < 0.02:
            continue
        Lp = d1(lambda x: Cc(x) + VA * CA(x), s)
        cc, ca = d1(Cc, s), d1(CA, s)
        pred = cc < 0 and (1.0 / VA) > ca / (-cc)
        if abs(Lp) > 1e-7:
            ok = ok and ((Lp < 0) == pred)
            npts += 1
check("local acceleration lowers V_c C_c + V_A C_A iff C_c' < 0 and V_c/V_A > C_A'/(-C_c') (%d points)" % npts, ok)
bad = 0
for VA in [0.5, 2.0, 5.0]:
    for i in range(5, 199):
        s = 0.01 * i
        Lp = d1(lambda x: Cc(x) + VA * CA(x), s)
        cc, ca = d1(Cc, s), d1(CA, s)
        bad += (Lp < 0) != ((1.0 / VA) > (-cc) / ca)
mutation("M4a 'break-even ratio inverted: V_c/V_A > (-C_c')/C_A''", bad > 0, "%d points misclassified" % bad)
Hpw = lambda s: s ** 1.5 if s <= 2 else 2 ** 1.5 + 0.01 * (s - 2)
Ltot = lambda s: Hpw(s) * max(20.0 / s, 1.0) + 0.01 * s
der = d1(Ltot, 1.0)
counter("P4 'justified only if -R_c' > R_A'' applied to a discrete acceleration from s = 1 to s = 10",
        der > 0 and Ltot(10.0) < Ltot(1.0),
        "d(R_c+R_A)/ds at s=1 is %+.3f, yet R_c+R_A falls from %.3f to %.3f" % (der, Ltot(1.0), Ltot(10.0)))
ok, npts = True, 0
for eta in [0.5, 0.8, 0.95]:
    for r in [0.1, 0.5]:
        Rd = (lambda eta, r: (lambda s: s ** eta * (1 - math.exp(-r * max(K / s, TA))) / r + S0))(eta, r)
        for i in range(5, 199):
            s = 0.01 * i
            x = r * K / s
            thr = x / math.expm1(x)
            if abs(eta - thr) < 1e-3:
                continue
            ok = ok and ((d1(Rd, s) < 0) == (eta < thr))
            npts += 1
check("discounted near loss H(1-e^{-rT})/r: below s*, acceleration lowers it iff eps_H < x/(e^x - 1), x = rK/s (%d points)" % npts, ok)
bad = 0
for i in range(5, 199):
    s, r, eta = 0.01 * i, 0.5, 0.95
    Rd = lambda s_: s_ ** eta * (1 - math.exp(-r * max(K / s_, TA))) / r + S0
    bad += (d1(Rd, s) < 0) != (eta < 1)
mutation("M4b 'undiscounted threshold eps_H < 1 when r > 0'", bad > 0, "%d points misclassified at r = 0.5, eps_H = 0.95" % bad)
# general fixed hazard profile H g(t/T), int_0^1 g = 1: discounted near loss H T psi(rT), psi(x) = int_0^1 e^{-xu} g(u) du;
# below s*, acceleration lowers it iff eps_H < 1 + x psi'(x)/psi(x), x = rK/s (the rectangle g = 1 gives x/(e^x - 1)).
# The loss is computed by direct quadrature of the discounted hazard, not from psi.
PROF = {"g = 1": lambda u: 1.0, "g = 2u": lambda u: 2 * u, "g = 2(1-u)": lambda u: 2 * (1 - u)}


def prof_thr(g, x):
    psi = simpson(lambda u: math.exp(-x * u) * g(u), 0.0, 1.0, 400)
    dpsi = -simpson(lambda u: u * math.exp(-x * u) * g(u), 0.0, 1.0, 400)
    return 1 + x * dpsi / psi


ok, npts = True, 0
for gname, g in PROF.items():
    for eta in [0.4, 0.7, 0.9]:
        for r in [0.2, 0.8]:
            Lg = (lambda eta, r, g: (lambda s: simpson(lambda t: math.exp(-r * t) * s ** eta * g(t * s / K), 0.0, K / s, 400)))(eta, r, g)
            for i in range(10, 196, 5):
                s = 0.01 * i
                thr = prof_thr(g, r * K / s)
                if abs(eta - thr) < 1e-3:
                    continue
                ok = ok and ((d1(Lg, s) < 0) == (eta < thr))
                npts += 1
thr1 = [prof_thr(g, 1.0) for g in PROF.values()]
ok = ok and max(thr1) < 1 and abs(thr1[0] - 1 / math.expm1(1.0)) < 1e-9 and min(abs(thr1[0] - thr1[1]), abs(thr1[0] - thr1[2]), abs(thr1[1] - thr1[2])) > 0.05
check("discounted near loss for a fixed hazard profile g (H g(t/T), int g = 1), by quadrature: below s*, acceleration lowers it iff eps_H < 1 + x psi'(x)/psi(x), psi(x) = int_0^1 e^{-xu} g(u) du, x = rK/s (%d points, three profiles)" % npts,
      ok, "threshold at x = 1: %.4f (g = 1, = 1/(e - 1)), %.4f (g = 2u), %.4f (g = 2(1-u)); profile-dependent, all below one" % tuple(thr1))
VA, KA, r = 2.0, 5.0, 0.1
RAd = lambda s: VA * CA(s) * math.exp(-r * KA / s)
err, err_mut = 0.0, 0.0
for s in [0.5, 1.0, 1.5, 3.0]:
    cf = VA * math.exp(-r * KA / s) * (0.1 * s + r * CA(s) * KA / s ** 2)
    mut = VA * math.exp(-r * KA / s) * 0.1 * s
    err = max(err, abs(d1(RAd, s) - cf))
    err_mut = max(err_mut, abs(d1(RAd, s) - mut))
check("discounted far loss V_A C_A e^{-r K_A/s}: derivative V_A e^{-rT_A}[C_A' + r C_A K_A/s^2]", err < 1e-7, "max error %.1e" % err)
mutation("M4c 'far-loss derivative without the timing term'", err_mut > 1e-3, "max error %.3f" % err_mut)
print()

# ================================================================== P5
print("== P5  Adoption time that falls with speed, T_a = A s^-beta")


def kink_num(K_, A, beta):
    f = lambda u: math.log(K_) - u - math.log(A) + beta * u    # ln(K/s) - ln(T_a), u = ln s
    lo, hi = math.log(1e-8), math.log(1e8)
    if (f(lo) > 0) == (f(hi) > 0):
        return None
    return math.exp(bisect(f, lo, hi))


ok = True
for (K_, A) in [(2.0, 1.0), (1.0, 2.0)]:
    for beta in [0.0, 0.3, 0.5, 0.8, 1.5, 2.0]:
        sn, sc = kink_num(K_, A, beta), (K_ / A) ** (1 / (1 - beta))
        cap_low = K_ / (sc / 2) > A * (sc / 2) ** -beta     # capability binds below the kink?
        ok = ok and sn is not None and close(sn, sc, 1e-9) and (cap_low == (beta < 1))
    ok = ok and kink_num(K_, A, 1.0) is None
check("s* = (K/A)^{1/(1-beta)}; capability binds below s* iff beta < 1; no crossing at beta = 1 (K != A)", ok)
mutation("M5a 's* = (A/K)^{1/(1-beta)}'", not close(kink_num(2.0, 1.0, 0.5), (1.0 / 2.0) ** 2, 1e-6),
         "numeric kink %.4f vs %.4f" % (kink_num(2.0, 1.0, 0.5), 0.25))
up = kink_num(2.0, 1.0, 0.5) > kink_num(2.0, 1.0, 0.0)
down = kink_num(1.0, 2.0, 0.5) < kink_num(1.0, 2.0, 0.0)
check("s* rises with beta (beta < 1) iff K > A", up and down,
      "K=2,A=1: %.3f -> %.3f; K=1,A=2: %.3f -> %.3f" % (kink_num(2, 1, 0), kink_num(2, 1, .5), kink_num(1, 2, 0), kink_num(1, 2, .5)))
counter("P5 'if T_a falls with s fast enough, s* rises': K = 1, A = 2, beta 0 -> 0.5", down,
        "s* falls from %.3f to %.3f" % (kink_num(1, 2, 0), kink_num(1, 2, .5)))
ok, npts = True, 0
for beta in [0.3, 0.8, 1.5, 2.0]:
    for eta in [0.2, 0.6, 1.2, 1.8]:
        if abs(beta - eta) < 1e-9:
            continue
        sc = (2.0 / 1.0) ** (1 / (1 - beta))
        s = 2 * sc if beta < 1 else sc / 2          # inside the adoption-binding region
        R = (lambda beta, eta: (lambda x: x ** eta * max(2.0 / x, x ** -beta) + S0))(beta, eta)
        ok = ok and ((d1(R, s) < 0) == (beta > eta))
        npts += 1
check("adoption-binding branch: acceleration lowers R_c iff beta > eps_H (%d cases)" % npts, ok)
Rx = lambda x: x ** 0.5 * max(1.0 / x, 2.0 * x ** -0.8) + S0
s_in = 2 * kink_num(1.0, 2.0, 0.8)
mutation("M5b 'the escape exists iff s* rises'", d1(Rx, s_in) < 0 and down,
         "K=1, A=2, beta=0.8 > eps_H=0.5: R_c falls (slope %.4f) though s* fell" % d1(Rx, s_in))
print()

# ================================================================== P6
print("== P6  The head start is worth at most its length")
n = 200000
ok = True
for (lam, tau, pi_, r) in [(3.0, 0.1, 0.2, 0.1), (3.0, 1.0, 0.2, 0.1), (0.5, 4.0, 0.0, 0.05), (1.0, 1.0, 0.5, 0.3)]:
    Ws = [RNG.expovariate(lam) for _ in range(n)]
    vals = [min(w, tau) for w in Ws]
    mc = sum(vals) / n
    se = math.sqrt(sum((v - mc) ** 2 for v in vals) / n / n)
    dv = [(1 - math.exp(-r * v)) / r for v in vals]
    mcd = sum(dv) / n
    sed = math.sqrt(sum((v - mcd) ** 2 for v in dv) / n / n)
    cf, cfd = m_exp(lam, tau), (1 - math.exp(-(r + lam) * tau)) / (r + lam)
    good = abs(mc - cf) < 5 * se and abs(mcd - cfd) < 5 * sed and (1 - pi_) * cf <= (1 - pi_) * min(1 / lam, tau)
    ok = ok and good
    print("            lam=%.1f tau=%.1f: MC E[min] %.5f cf %.5f; discounted MC %.5f cf (1-e^{-(r+lam)tau})/(r+lam) %.5f"
          % (lam, tau, mc, cf, mcd, cfd))
    wrong_r = (1 - math.exp(-r * tau)) / r
    if lam == 1.0:
        mutation("M6a 'discounted saving (1-e^{-r tau})/r'", abs(wrong_r - mcd) > 10 * sed, "%.5f vs MC %.5f" % (wrong_r, mcd))
        mutation("M6b 'undiscounted formula used when r > 0'", abs(cf - mcd) > 10 * sed, "%.5f vs MC %.5f" % (cf, mcd))
check("E[min(W,tau)] = (1-e^{-lam tau})/lam and discounted (1-e^{-(r+lam)tau})/(r+lam), Monte Carlo 200k", ok)
dists = {
    "lognormal(0,1)": lambda: RNG.lognormvariate(0, 1),
    "uniform(0,2)": lambda: RNG.uniform(0, 2),
    "Pareto(1.5)x0.3": lambda: 0.3 * RNG.paretovariate(1.5),
    "two-point": lambda: 0.1 if RNG.random() < 0.9 else 10.0,
}
ok = True
for name, draw in dists.items():
    Ws = [draw() for _ in range(n)]
    EW = sum(Ws) / n
    for tau in [0.2, 1.0, 5.0]:
        Em = sum(min(w, tau) for w in Ws) / n
        ok = ok and Em <= min(EW, tau) + 1e-12
check("E[min(W,tau)] <= min(E[W], tau) for four non-exponential window laws", ok)
Ws = [dists["two-point"]() for _ in range(n)]
EW = sum(Ws) / n
note("non-exponential window (two-point, tau = 1): E[min] = %.3f while the exponential closed form with the same mean gives %.3f. The closed form fails; the bound holds; no reversal implied."
     % (sum(min(w, 1.0) for w in Ws) / n, m_exp(1 / EW, 1.0)))
pi_ = 0.3
fast = (1 - pi_) * m_exp(1.0, 1e-4) / 1e-4
slow = (1 - pi_) * m_exp(1.0, 1e4) / 1e4
identity("relative saving vs baseline exposure tau: -> (1-pi) = 0.7 as lam tau -> 0, -> (1-pi)/(lam tau) as lam tau -> inf (closed form evaluated)",
         abs(fast - 0.7) < 1e-4 and abs(slow - 0.7e-4) < 1e-9, "%.6f and %.3e" % (fast, slow))
counter("P6 'relative saving tends to one for tau << 1/lam' (pi = 0.3, denominator = baseline exposure)", abs(fast - 1) > 0.1,
        "limit is %.4f" % fast)
mutation("M6c 'slow-operator limit 1/(lam tau) without (1-pi)'", abs(1e-4 - slow) > 1e-5, "%.2e vs %.2e" % (1e-4, slow))
ok, tight = True, 0.0
for _ in range(300):
    nf, ns = RNG.randint(1, 10), RNG.randint(1, 40)
    lam, pi_, eps_ = RNG.uniform(0.5, 6), RNG.uniform(0, 0.6), RNG.uniform(0, 0.3)
    ops = [(RNG.uniform(0.01, 0.3), RNG.uniform(0.1, 2), RNG.uniform(0, 1)) for _ in range(nf)]
    ops += [(RNG.uniform(1, 10), RNG.uniform(0.1, 2), RNG.uniform(0, eps_)) for _ in range(ns)]
    E0 = sum(w * t for t, w, c in ops)
    alpha = sum(w * t for t, w, c in ops[:nf]) / E0
    G = (1 - pi_) * sum(c * w * m_exp(lam, t) for t, w, c in ops)
    taus = min(t for t, w, c in ops[nf:])
    b1 = (1 - pi_) * (alpha + eps_ * (1 - alpha))
    b2 = (1 - pi_) * (alpha + (1 - alpha) * eps_ * min(1, 1 / (lam * taus)))
    ok = ok and G / E0 <= b2 + 1e-12 and b2 <= b1 + 1e-12
    tight = max(tight, (G / E0) / b2)
check("aggregate: G/E0 <= (1-pi)[alpha + eps(1-alpha) min(1, 1/(lam tau_s))] <= (1-pi)[alpha + eps(1-alpha)], 300 random populations",
      ok, "largest G/E0 relative to the bound %.3f" % tight)
g = lambda x: x * x
counter("P6 'worth at most its length' in harm units when harm is convex in exposure (g = x^2, tau = 10, W = 1)",
        g(10) - g(9) > g(1) and g(10) - g(9) > 1, "saving %.0f exceeds g(W) = %.0f" % (g(10) - g(9), g(1)))
ok = True
for gfun, gp in [(lambda x: x * x, lambda x: 2 * x), (lambda x: math.expm1(x), lambda x: math.exp(x)), (lambda x: x ** 1.5, lambda x: 1.5 * x ** 0.5)]:
    for _ in range(2000):
        tau, W, pi_ = RNG.uniform(0.1, 5), RNG.expovariate(1.0), RNG.uniform(0, 0.6)
        w = min(W, tau)
        ok = ok and gfun(tau) - gfun(tau - (1 - pi_) * w) <= (1 - pi_) * w * gp(tau) + 1e-9 <= w * gp(tau) + 2e-9
identity("convex harm g: saving g(tau) - g(tau - (1-pi)w) <= (1-pi) w g'(tau) <= w g'(tau), w = min(W,tau), three g, 6000 draws (supporting-line inequality)", ok)
tau, cc = 2.0, 0.5
lhs = cc * m_exp(2.0, tau)
rhs = cc * (cc * m_exp(2.0, tau) + (1 - cc) * m_exp(0.5, tau))
cov = [(RNG.random() < cc) for _ in range(n)]
mc = sum(min(RNG.expovariate(2.0 if cv else 0.5), tau) * cv for cv in cov) / n
counter("factorisation E[1_cov min(W,tau)] = c E[min(W,tau)] when covered operators shorten the window (lam 2 vs 0.5)",
        abs(mc - lhs) < 0.01 and abs(lhs - rhs) > 0.1, "MC %.4f = %.4f, but c E[min] = %.4f" % (mc, lhs, rhs))
print()

# ================================================================== P7
print("== P7  Fixes are roadmaps, restated flaw by flaw (exposure = time a usable exploit meets an undeployed fix)")
expo = lambda X, Y: max(0.0, Y - X)
ok_a, n_a, gap, mut_miss = True, 0, 0, 0
for _ in range(20000):
    P, lx, tau = RNG.uniform(0, 0.5), RNG.uniform(0, 0.05), RNG.uniform(0.05, 2)
    W, d = RNG.expovariate(2.0), RNG.uniform(0, 2)
    Y = P + tau
    e_rel, e_hold = expo(min(P + lx, d), Y), expo(min(P + lx, W + d), Y)
    if d >= P + lx:
        n_a += 1
        ok_a = ok_a and abs(e_rel - e_hold) < 1e-12 and abs(e_rel - max(0.0, tau - lx)) < 1e-12
        mut_miss += abs((e_rel - e_hold) - min(W, tau)) > 1e-9
    elif e_hold < e_rel - 1e-12:
        gap += 1
check("(a) found-and-patched flaws: if attackers' own discovery under release comes after patch + l_x, exposure is (tau - l_x)^+ under both regimes",
      ok_a and n_a > 1000, "%d draws" % n_a)
note("(a) needs that condition: in %d draws attackers found the flaw before the patch-enabled exploit, d_f < P_f + l_x, under release, and holding lowered exposure" % gap)
mutation("M7a 'holding saves min(W, tau) on found-and-patched flaws'", mut_miss == n_a and n_a > 0,
         "the computed saving differs from min(W, tau) on %d of %d qualifying draws (it is 0)" % (mut_miss, n_a))
ok_b, lam_b, pi_b = True, 1.5, 0.3
for _ in range(20000):
    W, d, Z = RNG.expovariate(lam_b), RNG.uniform(0, 1), RNG.uniform(0.5, 6)
    save = (1 - pi_b) * (expo(d, Z) - expo(W + d, Z))
    ok_b = ok_b and abs(save - (1 - pi_b) * min(W, max(0.0, Z - d))) < 1e-12 and save <= (1 - pi_b) * min(W, Z) + 1e-12
Z, d = 3.0, 0.4
mc = sum((1 - pi_b) * (expo(d, Z) - expo(RNG.expovariate(lam_b) + d, Z)) for _ in range(n)) / n
cf = (1 - pi_b) * m_exp(lam_b, Z - d)
check("(b) unfound flaws: holding saves (1-pi) min(W, (Z-d)^+) <= (1-pi) min(W, Z); expectation (1-pi)(1-e^{-lam(Z-d)^+})/lam",
      ok_b and abs(mc - cf) < 0.005, "MC %.4f vs cf %.4f" % (mc, cf))
Z, d = 0.5, 1.2     # the operator's cycle removes the flaw before attackers would find it: zeta < d
mc = sum((1 - pi_b) * (expo(d, Z) - expo(RNG.expovariate(lam_b) + d, Z)) for _ in range(n)) / n
cf = (1 - pi_b) * (1 - math.exp(-lam_b * max(0.0, Z - d))) / lam_b
mut = (1 - pi_b) * (1 - math.exp(-lam_b * (Z - d))) / lam_b
check("(b) at zeta_j < d_f: saving is zero and the positive-part form (1-pi)(1-e^{-lam(zeta-d)^+})/lam = %.4f matches MC %.4f" % (cf, mc),
      abs(mc) < 1e-12 and abs(cf) < 1e-12)
mutation("M7b 'expectation (1-pi)(1-e^{-lam(zeta-d)})/lam without the positive part'", abs(mut - mc) > 0.1,
         "at zeta = 0.5 < d = 1.2 it gives %.4f, a negative saving" % mut)
weak, strict = True, 0
for _ in range(20000):
    P, lx, tau = RNG.uniform(0, 0.5), RNG.uniform(0, 0.05), RNG.uniform(0.2, 3)
    taup, W = RNG.uniform(0.01, 1) * tau, RNG.expovariate(2.0)
    Yt = lambda t_tool: min(P + tau, max(P, t_tool) + taup)
    e0, eW = expo(P + lx, Yt(0.0)), expo(P + lx, Yt(W))
    weak = weak and e0 <= eW + 1e-12
    strict += e0 < eW - 1e-12
check("(c) withholding a defensive-only tool never lowers outsiders' exposure (weak harm)", weak,
      "strictly higher in %d of 20000 draws" % strict)
P, lx, tau, W = 0.1, 0.01, 1.0, 0.5
counter("P7 'holding the defensive tools makes outsiders strictly worse off': a tool that does not shorten deployment",
        expo(P + lx, min(P + tau, P + tau)) == expo(P + lx, min(P + tau, max(P, W) + tau)), "exposure %.2f either way" % (tau - lx),
        by_construction=True)
p0, rr = 0.1, 0.2
und = lambda tt: (tt + p0 + tau) - (tt + p0 + lx)
disc = lambda tt: (math.exp(-rr * (tt + p0 + lx)) - math.exp(-rr * (tt + p0 + tau))) / rr
counter("P7's two sentences together: if exposure starts at patch publication and the tool produces the patches, withholding it delays exposure",
        abs(und(0) - und(W)) < 1e-12 and disc(W) < disc(0),
        "undiscounted exposure %.2f both ways; discounted %.4f (tool now) vs %.4f (withheld)" % (und(0), disc(0), disc(W)))
lam, pi_, d, Z, P, lx, tau = 3.0, 0.3, 0.2, 5.0, 0.25, 0.01, 0.25
rel = 10 * expo(min(P + lx, d), P + tau) + 90 * expo(d, Z)
hold = hold_alt = hold_sq = 0.0
for _ in range(n):
    W = RNG.expovariate(lam)
    patched = expo(min(P + lx, W + d), P + tau)
    unfound = pi_ * expo(d, Z) + (1 - pi_) * expo(W + d, Z)
    # A8: the same already-equipped attacker share applies to every flaw.
    sample = 10 * (pi_ * expo(min(P + lx, d), P + tau) + (1 - pi_) * patched) + 90 * unfound
    hold += sample
    hold_sq += sample * sample
    # Previous example: patched flaws wholly excluded, pi only on unfound flaws.
    hold_alt += 10 * patched + 90 * unfound
hold /= n
hold_alt /= n
hold_se = math.sqrt(max(0.0, hold_sq / n - hold * hold) / n)
patched_window = min(P + lx, P + tau) - min(P + lx, d, P + tau)
unfound_window = max(0.0, Z - d)
hold_cf = rel - (1 - pi_) * (10 * m_exp(lam, patched_window) + 90 * m_exp(lam, unfound_window))
hold_alt_cf = rel - 10 * m_exp(lam, patched_window) - (1 - pi_) * 90 * m_exp(lam, unfound_window)
counter("P7 'a capability-level hold adds nothing for outsiders': 100 flaws, 10 found and patched, 90 never found",
        hold < rel - 1.0 and abs(hold - hold_cf) < 5 * hold_se,
        "A8 mixture on every flaw: release closed form %.6f; hold closed form %.6f, Monte Carlo %.6f (SE %.6f); "
        "alternative composition (patched flaws wholly excluded): hold closed form %.6f, Monte Carlo %.6f; no patch shipped for the 90"
        % (rel, hold_cf, hold, hold_se, hold_alt_cf, hold_alt))
print()

# ================================================================== P8
print("== P8  The best coalition: B(n) = (1-pi) sum_j c_j(n) w_j E[min(W(n), tau_j)]")


def Bfun(nn, cs, lamf, pi_=0.0):
    return (1 - pi_) * sum(c(nn) * w * m_exp(lamf(nn), tau) for (c, w, tau) in cs)


def m_lam(lam, tau):
    return (lam * tau * math.exp(-lam * tau) - (1 - math.exp(-lam * tau))) / lam ** 2


cs1, lam1 = [(lambda x: x, 1.0, 1.0)], (lambda x: 1 + 0.01 * x)
ns1 = argmax(lambda x: Bfun(x, cs1, lam1), 0.0, 1.0)
inc = all(Bfun(0.01 * (i + 1), cs1, lam1) > Bfun(0.01 * i, cs1, lam1) for i in range(100))
counter("P8 'coverage rising and window shrinking imply interior n*': c = n, lam = 1 + 0.01n, tau = 1 on [0,1]",
        inc and abs(ns1 - 1.0) < 1e-9, "B strictly increasing, n* = %.3f = N" % ns1)
cs2, lam2 = [(lambda x: 1.0, 1.0, 1.0), (lambda x: 0.01 * x, 1.0, 1.0)], (lambda x: 1 + x)
ns2 = argmax(lambda x: Bfun(x, cs2, lam2), 0.0, 10.0)
counter("P8 same claim, other corner: holder's own systems covered at n = 0, partners add little coverage, lam = 1 + n",
        ns2 < 1e-9, "n* = %.3f" % ns2)
cs3, lam3, N3 = [(lambda x: 1 - math.exp(-x), 1.0, 3.0)], (lambda x: 0.5 + 0.3 * x), 10.0
B3 = lambda x: Bfun(x, cs3, lam3)
Bp_cf = lambda x: math.exp(-x) * m_exp(lam3(x), 3.0) + (1 - math.exp(-x)) * m_lam(lam3(x), 3.0) * 0.3
Bp_mut = lambda x: math.exp(-x) * m_exp(lam3(x), 3.0) - (1 - math.exp(-x)) * m_lam(lam3(x), 3.0) * 0.3
errs = [abs(d1(B3, x) - Bp_cf(x)) for x in [0.5, 1, 2, 5, 9]]
check("lemma B'(n) = sum w[c' m + c m_lam lam'], m_lam < 0", max(errs) < 1e-7, "max error %.1e" % max(errs))
mutation("M8a 'B' with the sign of m_lam flipped'", max(abs(d1(B3, x) - Bp_mut(x)) for x in [0.5, 1, 2]) > 1e-3)
ns3 = argmax(B3, 0.0, N3)
root = bisect(Bp_cf, 0.01, N3)
signs = [Bp_cf(0.01 * i) > 0 for i in range(1, 1001)]
crossings = sum(1 for i in range(len(signs) - 1) if signs[i] != signs[i + 1])
concave = all(d1(lambda x: d1(B3, x, 1e-4), 0.05 * i, 1e-4) < 0 for i in range(1, 200))
check("interior: B'(0) = %.3f > 0 > B'(N) = %.4f gives interior n* = %.4f = root of B' (%.4f); B' crosses once"
      % (Bp_cf(0.0), Bp_cf(N3), ns3, root), Bp_cf(0.0) > 0 > Bp_cf(N3) and abs(ns3 - root) < 1e-4 and crossings == 1,
      "B strictly concave on the grid: %s" % concave)
Bi = [B3(k) for k in range(11)]
check("integer n: B(1) > B(0) and B(9) > B(10) make the integer argmax interior (argmax = %d)" % max(range(11), key=lambda k: Bi[k]),
      Bi[1] > Bi[0] and Bi[9] > Bi[10] and 0 < max(range(11), key=lambda k: Bi[k]) < 10)
Btie = [1, 2, 2, 1]
argsT = [k for k in range(4) if Btie[k] == max(Btie)]
mutation("M8b 'strictly decreasing differences make the integer maximiser unique'", len(argsT) == 2,
         "B = (1, 2, 2, 1): differences 1, 0, -1 strictly decreasing, endpoint conditions hold, maximisers %s" % argsT)
ok, ties, uniq = True, 0, 0
for _ in range(5000):
    nd = RNG.randint(2, 8)
    diffs = sorted(RNG.sample(range(-6, 7), nd), reverse=True)      # strictly decreasing integer differences, zero allowed
    Bs = [0]
    for dd in diffs:
        Bs.append(Bs[-1] + dd)
    arg = [k for k in range(len(Bs)) if Bs[k] == max(Bs)]
    adjacent = len(arg) == 1 or (len(arg) == 2 and arg[1] - arg[0] == 1)
    ok = ok and adjacent and ((len(arg) == 1) == (0 not in diffs))
    ties += len(arg) == 2
    uniq += len(arg) == 1
check("integer n: strictly decreasing differences give at most two maximisers, adjacent; unique iff no difference is zero (5000 sequences)",
      ok and ties > 0 and uniq > 0, "%d with a tie, %d unique" % (ties, uniq))
ok = True
for _ in range(5000):
    lam0, rem, add, tau = RNG.uniform(0.2, 3), RNG.uniform(0, 1), RNG.uniform(0, 1), RNG.uniform(0.1, 5)
    lam_new = max(0.05, lam0 - rem + add)
    ok = ok and ((m_exp(lam_new, tau) > m_exp(lam0, tau)) == (lam_new < lam0))
check("rival admitted with coverage, deployment, attack access and beneficiaries fixed: B rises iff hazard removed > hazard added", ok)
before = 0.8 * 1.0 * m_exp(1.0, 1.0)
after = 0.8 * 1.0 * m_exp(1.1, 1.0) + 1.0 * 1.0 * m_exp(1.1, 0.5)
counter("P8 'adding rivals is worth it iff rival-release hazard removed exceeds leak hazard added' when the rival's own systems gain coverage",
        after > before, "hazard 1.0 -> 1.1 (removed 0.1 < added 0.2), yet B %.3f -> %.3f" % (before, after))
print()

# ================================================================== P9
print("== P9  Secrecy and the private race: two-player Tullock (r=1), cost c x, linear expected-loss index theta*X, loss L")
D, c, L, th = 1.0, 1.0, 1.0, 0.4
kk = c + L * th
xs = {}
for (label, vW, vL) in [("winner-only window", D + 0.5, 0.0), ("non-rival window", D + 0.5, 0.5),
                        ("partly shared window", D + 0.5, 0.2), ("no window", D, 0.0)]:
    P = dict(vW=vW, vL=vL, c=c, L=L, th=th)
    x1, x2 = nash2(P, P, 3.0)
    xs[label] = x1
    cf = (vW - vL) / (4 * kk)
    check("%s: equilibrium %.6f = (v_W - v_L)/(4(c + L theta)) = %.6f; no profitable deviation incl. zero" % (label, x1, cf),
          abs(x1 - cf) < 1e-5 and abs(x2 - cf) < 1e-5 and is_nash2(x1, x2, P, P, 3.0))
mutation("M9a 'non-rival window multiplies effort by (D + v_s)/D'", abs(xs["non-rival window"] / xs["no window"] - 1.5) > 0.1,
         "multiplier %.4f" % (xs["non-rival window"] / xs["no window"]))
mutation("M9b 'x* = (v_W - v_L)/(4c), shared hazard ignored'", abs(xs["winner-only window"] - 1.5 / 4) > 1e-3)
for vs in [0.0, 0.5]:
    x = 0.05
    for _ in range(300):
        x = 0.5 * x + 0.5 * argmax(lambda y: (y / (y + 2 * x) if y + 2 * x > 0 else 1 / 3) * (D + vs) - c * y - L * th * (y + 2 * x), 0.0, 2.0)
    xs["N3 %.1f" % vs] = x
check("three players: multiplier %.4f = (D + v_s)/D = 1.5" % (xs["N3 0.5"] / xs["N3 0.0"]), abs(xs["N3 0.5"] / xs["N3 0.0"] - 1.5) < 1e-4)
Pq0 = dict(vW=D, vL=0.0, c=c, L=L, th=th, quad=True)
Pq1 = dict(vW=D + 0.5, vL=0.0, c=c, L=L, th=th, quad=True)
q0, q1 = nash2(Pq0, Pq0, 3.0)[0], nash2(Pq1, Pq1, 3.0)[0]
counter("P9's multiplier under a hazard convex in total racing (theta X^2)", abs(q1 / q0 - 1.5) > 0.02,
        "multiplier %.4f, not 1.5" % (q1 / q0))


def welfare(X, G_, LA, b, holder=0.0):
    """Total welfare: outsiders' gross real gain G (before any payments to the holder), the real surplus
    'holder' (sigma_s) of the racers who receive a window, and per unit of total effort the public value b,
    the cost c and the expected-loss term L_A theta. Payments from outsiders are transfers and cancel."""
    return G_ + holder + b * X - c * X - LA * th * X


def welfare_parties(X, G_, pay, sigma, LA, b):
    """Sum of every party's payoff: outsiders G - pay, the window's holder sigma + pay, racing terms per unit of X."""
    return (G_ - pay) + (sigma + pay) + (b - c - LA * th) * X


ok, mutw, mdev = True, 0, 0.0
for (vs, G_, LA, b) in [(0.5, 0.05, 10.0, 0.0), (0.2, 0.3, 3.0, 0.5), (1.0, 0.1, 20.0, 0.0)]:
    P1_ = dict(vW=D + vs, vL=0.0, c=c, L=L, th=th)
    P0_ = dict(vW=D, vL=0.0, c=c, L=L, th=th)
    X1, X0 = 2 * nash2(P1_, P1_, 3.0)[0], 2 * nash2(P0_, P0_, 3.0)[0]
    for share in [1.0, 0.5, 0.0]:
        sig, pay = share * vs, (1 - share) * vs
        dW = welfare_parties(X1, G_, pay, sig, LA, b) - welfare_parties(X0, 0.0, 0.0, 0.0, LA, b)
        cf = G_ + sig - (c + LA * th - b) * vs / (2 * kk)
        ok = ok and abs(dW - cf) < 1e-5 and abs(dW - (welfare(X1, G_, LA, b, sig) - welfare(X0, 0.0, LA, b))) < 1e-12
        if pay > 0:
            mdev = max(mdev, abs(dW - ((G_ - pay) + sig - (c + LA * th - b) * vs / (2 * kk)) - pay))
        mutw += pay > 0 and abs(dW - ((G_ - pay) + sig - (c + LA * th - b) * vs / (2 * kk)) - pay) < 1e-5
check("welfare change from a winner-only prize v_s with real surplus sigma_s = v_s, v_s/2, 0 (rest paid by outsiders): every party's payoff summed gives dW = G + sigma_s - (c + L_A theta - b) v_s/(2(c + L theta)), G gross; three prizes x three shares (efforts by best-response search)", ok)
mutation("M9c 'G net of outsiders' payments, holder's receipt dropped when v_s is a transfer'", mutw == 6,
         "%d of 6 cases with payments get dW wrong by exactly the payment (largest deviation %.1e, within the effort search's 1e-5)" % (mutw, mdev))
P1_ = dict(vW=D + 5.0, vL=5.0, c=c, L=L, th=th)
X1 = 2 * nash2(P1_, P1_, 3.0)[0]
X0 = 2 * xs["no window"]
dW_s, dW_t = welfare(X1, 1.0, 10.0, 0.0, 10.0) - welfare(X0, 0.0, 10.0, 0.0), welfare(X1, 1.0, 10.0, 0.0) - welfare(X0, 0.0, 10.0, 0.0)
counter("P9 'secrecy raises private racing by more than its social value whenever v_s exceeds the P6 gain': window both players receive, v_s = 5 > G = 1",
        abs(X1 - X0) < 1e-5 and dW_t > 0, "racing unchanged (X %.4f vs %.4f); welfare rises by %.3f (by %.3f if v_s is a transfer)" % (X1, X0, dW_s, dW_t))
P1_ = dict(vW=D + 5.0, vL=0.0, c=c, L=L, th=th)
X1 = 2 * nash2(P1_, P1_, 3.0)[0]
dW_s, dW_t = welfare(X1, 1.0, 10.0, 6.0, 5.0) - welfare(X0, 0.0, 10.0, 6.0), welfare(X1, 1.0, 10.0, 6.0) - welfare(X0, 0.0, 10.0, 6.0)
counter("same claim, winner-only v_s = 5 > G = 1, when racing has uncaptured public value b = 6 > c + L_A theta = 5",
        dW_t > 0, "welfare rises by %.3f (by %.3f if v_s is a transfer)" % (dW_s, dW_t))
xi, LA, G_, vs_sh = 0.005, 100.0, 1.0, 0.5
P1_ = dict(vW=D + vs_sh, vL=vs_sh, c=c, L=L, th=th)
dX = 2 * nash2(P1_, P1_, 3.0)[0] - X0
dW_t = G_ - (c + LA * th - 0.0) * dX - LA * xi
counter("P9 'even a modest escalatory response dominates': window both players receive (dX computed), xi = 0.005, L_A = 100, G = 1",
        abs(dX) < 1e-5 and dW_t > 0, "dX = %.1e; dW = G + 2 v_s - (c + L_A theta - b) dX - L_A xi = %.2f, and %.2f if v_s is a transfer; harm requires xi > %.3f if each v_s = 0.5 is real surplus, xi > %.3f if a transfer"
        % (dX, dW_t + 2 * vs_sh, dW_t, (G_ + 2 * vs_sh - (c + LA * th) * dX) / LA, (G_ - (c + LA * th) * dX) / LA))
print()

# ================================================================== P10
print("== P10  The private race in general: reproduction of the race supplement's closed forms")
P = dict(vW=1.0, vL=0.0, c=1.0, L=2.0, th=0.4)
x1, _ = nash2(P, P, 3.0)
check("shared-hazard equilibrium D/(4(c + L theta)) = %.6f (numeric %.6f); joint optimum zero effort" % (1 / 7.2, x1),
      abs(x1 - 1 / 7.2) < 1e-5 and argmax(lambda y: 2 * u2(y, y, P), 0.0, 1.0) < 1e-9)


def u5e(x, y, Dv, k, b, Lt):
    X = x + y
    p = 0.5 if X == 0 else x / X
    return Dv * p - 0.5 * k * x * x + (b - Lt) * X


res = {}
for Dv in [0.36, 0.72, 1.44]:
    beta, k = 0.5 - 0.2, 1.0
    x = 0.3
    for _ in range(300):
        x = 0.5 * x + 0.5 * argmax(lambda y: u5e(y, x, Dv, k, 0.5, 0.2), 0.0, 3.0)
    xo = argmax(lambda y: 2 * u5e(y, y, Dv, k, 0.5, 0.2), 0.0, 3.0)
    res[Dv] = (x, xo, (beta + math.sqrt(beta ** 2 + k * Dv)) / (2 * k), 2 * beta / k)
ok = all(abs(v[0] - v[2]) < 1e-5 and abs(v[1] - v[3]) < 1e-5 for v in res.values())
check("public value b: x* = [beta + sqrt(beta^2 + kD)]/(2k), x_o = 2 beta/k (b=0.5, L theta=0.2, k=1; D = 0.36, 0.72, 1.44)", ok,
      "; ".join("D=%.2f: %.4f vs %.4f" % (Dv, v[0], v[1]) for Dv, v in res.items()))
counter("P10 'equilibrium speed exceeds the social optimum': D = 0.36 < 8 beta^2/k = 0.72", res[0.36][0] < res[0.36][1] - 0.05,
        "x* = %.4f < x_o = %.4f (under-racing)" % res[0.36][:2])
cR, LR, thR, DR = 1.0, 2.0, 0.4, 1.0
UC = 2.0 - DR / 2
UN = 2.0 - DR / 2 - DR * (cR + 2 * LR * thR) / (4 * (cR + LR * thR))
Gd = DR / 2


def dev_gain(pi, dlt):
    VC, VN = UC / (1 - dlt), UN / (1 - dlt)
    return (UC + Gd + dlt * pi * VN) / (1 - dlt * (1 - pi)) - VC


dlt = 0.9
pistar = (1 - dlt) / dlt * 2 * (cR + LR * thR) / (cR + 2 * LR * thR)
check("restraint holds iff nu >= nu* = ((1-varrho)/varrho) 2(c+L theta)/(c+2L theta) = %.4f at varrho = 0.9 (stationary deviation vs restraint)" % pistar,
      dev_gain(0.0, dlt) > 0 and dev_gain(0.95 * pistar, dlt) > 0 and dev_gain(1.05 * pistar, dlt) < 0)
counter("P10 'verification is the condition for restraint': verification present (nu = nu*/2 > 0) and restraint still fails",
        dev_gain(0.5 * pistar, dlt) > 0, "deviation gain %.4f > 0" % dev_gain(0.5 * pistar, dlt))
mut_pi = 2 * (cR + LR * thR) / (cR + 2 * LR * thR)
mutation("M10a 'nu* without the (1-varrho)/varrho factor'", dev_gain(2 * pistar, dlt) < 0 and 2 * pistar < mut_pi,
         "at nu = %.3f < %.3f the mutation predicts deviation, but the gain is %.4f" % (2 * pistar, mut_pi, dev_gain(2 * pistar, dlt)))
dlt_lo = 0.3
nu_lo = (1 - dlt_lo) / dlt_lo * 2 * (cR + LR * thR) / (cR + 2 * LR * thR)
check("restraint impossible when nu* > 1: at varrho = 0.3, nu* = %.3f and deviation pays even with certain detection" % nu_lo,
      nu_lo > 1 and dev_gain(1.0, dlt_lo) > 0, "deviation gain at nu = 1: %.4f" % dev_gain(1.0, dlt_lo))
print()

# ================================================================== P11
print("== P11  Release timing as an optimal-stopping problem")
print("            old public lead g(t) = g0 e^{-k_pre t}; rent pi(x) = M x^alpha; release adds Delta to the lead, which then")
print("            decays at k_post; held flow F; involuntary end at hazard lam with continuation Z (Z = 0 unless stated)")


def p11(F, M, al, g0, Dl, r, lam, kpre, kpost, Z=0.0):
    a = r + lam
    rho = r + al * kpost
    Pi = lambda x: M * x ** al / rho
    dPi = lambda x: al * M * x ** (al - 1) / rho
    gT = lambda T: g0 * math.exp(-kpre * T)

    def V(T):
        v = (F + lam * Z) * (1 - math.exp(-a * T)) / a
        if g0 > 0:
            v += M * g0 ** al * (1 - math.exp(-(a + al * kpre) * T)) / (a + al * kpre)
        return v + math.exp(-a * T) * Pi(gT(T) + Dl)

    Vinf = (F + lam * Z) / a + (M * g0 ** al / (a + al * kpre) if g0 > 0 else 0.0)

    def gain_key(T):
        # V(T)-Vinf = exp(-a*T) * Q(T). Cancel the held-flow integrals
        # algebraically, before rounding erases a small positive release gain.
        # Signed log magnitudes also avoid underflow of the discount factor.
        gv = gT(T)
        q = math.fsum((Pi(gv + Dl), -(F + lam * Z) / a,
                       -M * gv ** al / (a + al * kpre)))
        if q == 0.0:
            return (0, 0.0)
        log_abs = -a * T + math.log(abs(q))
        return (1, log_abs) if q > 0 else (-1, -log_abs)

    def Phi(T):           # e^{aT} V'(T) = f(T) + lam Z - a J(T) + J'(T)
        gv = gT(T)
        return F + lam * Z + (M * gv ** al if gv > 0 else 0.0) - a * Pi(gv + Dl) - kpre * gv * dPi(gv + Dl)

    Tmax = (math.log(g0 / 1e-9) / kpre) if g0 > 0 else 50.0
    # For the selected random-scan band Phi(inf) < 0. Since Pi is increasing
    # and the final term of Phi is nonpositive, Phi(T) <= Phi(inf)+M*g(T)^al.
    # Beyond tail_Tmax this upper bound is at most Phi(inf)/2 < 0, so no
    # later maximum can be missed. A lead cutoff alone fails at small al.
    phi_inf = F + lam * Z - a * Pi(Dl)
    tail_Tmax = None
    if phi_inf < 0:
        tail_Tmax = max(0.0, Tmax)
        if g0 > 0:
            tail_Tmax = max(tail_Tmax,
                            (math.log(M) + al * math.log(g0) - math.log(-phi_inf / 2)) / (al * kpre))
    return dict(V=V, Vinf=Vinf, Phi=Phi, Pi=Pi, Tmax=Tmax, a=a,
                gain_key=gain_key, tail_Tmax=tail_Tmax)


def plan_from_foc(m, ngrid=3000, stable=False):
    """Candidates from the first-order condition: T = 0, every + to - crossing of Phi, and holding forever."""
    horizon = m["Tmax"]
    if stable:
        if m["tail_Tmax"] is None:
            raise ValueError("stable random-scan solver requires Phi(inf) < 0")
        horizon = m["tail_Tmax"]
    Ts = [horizon * i / ngrid for i in range(ngrid + 1)]
    ph = [m["Phi"](T) for T in Ts]
    cands = [(m["V"](0.0), 0.0)]
    for i in range(ngrid):
        if ph[i] > 0 >= ph[i + 1]:
            T = bisect(m["Phi"], Ts[i], Ts[i + 1])
            cands.append((m["V"](T), T))
    cands.append((m["Vinf"], math.inf))
    if stable:
        return max(cands, key=lambda vt: ((0, 0.0) if math.isinf(vt[1])
                                         else m["gain_key"](vt[1]), vt[1]))
    return max(cands)


def plan_brute(m, ngrid=20000):
    Ts = [m["Tmax"] * i / ngrid for i in range(ngrid + 1)]
    best = max((m["V"](T), T) for T in Ts)
    return max(best, (m["Vinf"], math.inf))


# independent check of V by quadrature
m = p11(0.42, 1.0, 0.5, 0.2, 0.3, 0.05, 0.2, 0.5, 0.5)
err = 0.0
for T in [0.0, 1.0, 5.0, 20.0]:
    held = simpson(lambda t: math.exp(-0.25 * t) * (0.42 + (0.2 * math.exp(-0.5 * t)) ** 0.5), 0.0, T) if T > 0 else 0.0
    x0 = 0.2 * math.exp(-0.5 * T) + 0.3
    J = simpson(lambda s: math.exp(-0.05 * s) * (x0 * math.exp(-0.5 * s)) ** 0.5, 0.0, 600.0, 20000)
    err = max(err, abs(held + math.exp(-0.25 * T) * J - m["V"](T)))
check("V(T) closed form equals direct quadrature of held flows plus discounted release value", err < 1e-6, "max error %.1e" % err)
err = max(abs(math.exp(m["a"] * T) * d1(m["V"], T, 1e-5) - m["Phi"](T)) for T in [0.5, 2.0, 6.0])
check("V'(T) = e^{-(r+lam)T}[F + pi(g(T)) - (r+lam)J(T) + J'(T)]: interior condition F + pi(g) = (r+lam)J - J'", err < 1e-6,
      "max error %.1e" % err)
mz = p11(0.42, 1.0, 0.5, 0.2, 0.3, 0.05, 0.2, 0.5, 0.5, Z=0.3)
err = max(abs(math.exp(mz["a"] * T) * d1(mz["V"], T, 1e-5) - mz["Phi"](T)) for T in [0.5, 2.0, 6.0])
check("with continuation Z after involuntary loss the condition becomes F + lam Z + pi(g) = (r+lam)J - J'", err < 1e-6)
# constant flows (no old public lead): bang-bang
for kap in [0.5, 1.0]:
    mb = p11(0.4, 1.0, 1.0, 0.0, 1.0, 0.05, 0.2, kap, kap)
    vb, Tb = plan_brute(mb)
    pred = 0.0 if 0.4 < 0.25 * 1.0 / (0.05 + kap) else math.inf
    check("constant flows, k = %.1f: V'(T) has the constant sign of F - (r+lam)M Delta/(r+k) = %+.3f; optimum T = %s"
          % (kap, 0.4 - 0.25 / (0.05 + kap), Tb), Tb == pred)
counter("P11 'release when the inference revenue forgone exceeds F': forgone flow M Delta = 1 > F = 0.4, k = 1",
        plan_brute(p11(0.4, 1.0, 1.0, 0.0, 1.0, 0.05, 0.2, 1.0, 1.0))[1] == math.inf, "optimal plan: hold until involuntary loss")
counter("P11 'release comes sooner the faster the copying': constant flows, k 0.5 -> 1.0 moves release from now to never",
        plan_brute(p11(0.4, 1.0, 1.0, 0.0, 1.0, 0.05, 0.2, 0.5, 0.5))[1] == 0.0
        and plan_brute(p11(0.4, 1.0, 1.0, 0.0, 1.0, 0.05, 0.2, 1.0, 1.0))[1] == math.inf)
ok = True
for (F, g0, Dl, kap) in [(0.3, 1.0, 0.5, 0.5), (0.2, 0.5, 1.0, 1.0), (0.5, 2.0, 0.3, 0.3), (0.25, 1.0, 1.0, 0.5)]:
    ml = p11(F, 1.0, 1.0, g0, Dl, 0.05, 0.2, kap, kap)
    ok = ok and plan_brute(ml)[1] in (0.0, math.inf) and plan_from_foc(ml)[1] in (0.0, math.inf)
check("linear rents (alpha = 1), one copy rate, old public lead: Phi rises over time, so the optimum is a corner (four cases)", ok)
ml = p11(0.03, 1.0, 1.0, 1.0, 0.5, 0.05, 0.1, 0.2, 1.0)
vf, Tf = plan_from_foc(ml)
vb, Tb = plan_brute(ml)
Tlin = math.log(1.0 / ((0.15 * 0.5 / 1.05 - 0.03) / (0.7 / 1.05))) / 0.2
check("linear rents with k_post > k_pre + lam (0.2, 1.0, lam 0.1): interior T* = %.4f = brute force %.4f = ln(g0/G*)/k_pre with G* = %.4f"
      % (Tf, Tb, (0.15 * 0.5 / 1.05 - 0.03) / (0.7 / 1.05)), 0 < Tf < math.inf and abs(Tf - Tb) < 0.01 and abs(Tf - Tlin) < 1e-6)
mc_ = p11(0.42, 1.0, 0.5, 0.2, 0.3, 0.05, 0.2, 0.5, 0.5)
vf, Tf = plan_from_foc(mc_)
vb, Tb = plan_brute(mc_)
check("concave rents (alpha = 0.5): interior release T* = %.4f from the first-order condition = brute-force grid optimum %.4f" % (Tf, Tb),
      0 < Tf < math.inf and abs(Tf - Tb) < 2 * mc_["Tmax"] / 20000 + 1e-6 and abs(vf - vb) < 1e-8,
      "V* = %.6f vs %.6f; V(0) = %.6f; V(inf) = %.6f" % (vf, vb, mc_["V"](0.0), mc_["Vinf"]))
# convex rents with two copy rates also give a strict interior release (Phi = (3g^2 - 6g - 1)/7 along g = 3e^{-t})
mv = p11(1 / 7, 1.0, 2.0, 3.0, 1.0, 1.0, 1.0, 1.0, 3.0)
vfv, Tfv = plan_from_foc(mv)
vbv, Tbv = plan_brute(mv)
gstar = 1 + 2 / math.sqrt(3)
Tsv = [mv["Tmax"] * i / 4000 for i in range(4001)]
phv = [mv["Phi"](T) for T in Tsv]
ncross = sum((phv[i] > 0) != (phv[i + 1] > 0) for i in range(4000))
phierr = max(abs(mv["Phi"](T) - (3 * (3 * math.exp(-T)) ** 2 - 6 * 3 * math.exp(-T) - 1) / 7) for T in Tsv)
check("convex rents (alpha = 2), r = lam = k_pre = 1, k_post = 3, Delta = 1, g0 = 3, F = 1/7, Z = 0: Phi = (3g^2 - 6g - 1)/7 crosses zero once, downward, at g* = 1 + 2/sqrt(3); strict interior release",
      ncross == 1 and phv[0] > 0 > phv[-1] and phierr < 1e-12 and abs(Tfv - math.log(3 / gstar)) < 1e-9
      and abs(Tfv - Tbv) < 2 * mv["Tmax"] / 20000 + 1e-6 and vfv > mv["V"](0.0) + 1e-3 and vfv > mv["Vinf"] + 1e-3,
      "T* = %.4f = ln(3/g*) = %.4f, brute force %.4f; V* = %.5f > V(0) = %.5f and V(inf) = %.5f"
      % (Tfv, math.log(3 / gstar), Tbv, vfv, mv["V"](0.0), mv["Vinf"]))
# linear rents, degenerate case of (iii): k_post = k_pre + lam and F + lam Z = (r+lam) M Delta/(r+k_post) give Phi = 0
okd = True
for Zc in [0.0, 0.5]:
    md = p11(0.15 * 0.5 / 0.35 - 0.1 * Zc, 1.0, 1.0, 1.0, 0.5, 0.05, 0.1, 0.2, 0.3, Z=Zc)
    Tds = [0.0, 0.5, 2.0, 10.0, 40.0]
    okd = okd and max(abs(md["Phi"](T)) for T in Tds) < 1e-12 and max(abs(md["V"](T) - md["Vinf"]) for T in Tds) < 1e-9
identity("linear rents with k_post = k_pre + lam (0.3 = 0.2 + 0.1) and F + lam Z = (r+lam) M Delta/(r+k_post): Phi = 0 and V(T) = V(inf) at every T, so every date is optimal and none is a strict interior maximum (Z = 0, 0.5)", okd)
# a rent with a jump (increasing, rho(0) = 0, not C^2): rho(x) = x + 1{x >= 1}, r = lam = k_pre = k_post = Delta = 1,
# g0 = 1.1, F = 9/4, Z = 0. g(T) = 1 at T0 = ln 1.1, where V has a kink. Closed forms Pi(x) = x/2 + (1 - 1/x)^+ and the
# held integral are first confirmed by quadrature split at the jump, then used on the grid.
gj = lambda T: 1.1 * math.exp(-T)
T0j = math.log(1.1)
Pij = lambda x: x / 2 + max(0.0, 1 - 1 / x)
Hj = lambda T: 2.25 * (1 - math.exp(-2 * T)) / 2 + 1.1 * (1 - math.exp(-3 * T)) / 3 + (1 - math.exp(-2 * min(T, T0j))) / 2
Vj = lambda T: Hj(T) + math.exp(-2 * T) * Pij(gj(T) + 1)
Vj_inf = 2.25 / 2 + 1.1 / 3 + (1 - 1.1 ** -2) / 2
qerr = 0.0
for x in [0.5, 1.5, 2.1]:
    cut = math.log(x) if x > 1 else 0.0
    q = (simpson(lambda s: math.exp(-s) * (x * math.exp(-s) + 1), 0.0, cut, 400) if cut > 0 else 0.0) \
        + simpson(lambda s: math.exp(-2 * s) * x, cut, 40.0, 4000)
    qerr = max(qerr, abs(q - Pij(x)))
for T in [0.05, 0.5, 3.0]:
    q = simpson(lambda t: math.exp(-2 * t) * (3.25 + gj(t)), 0.0, min(T, T0j), 400) \
        + (simpson(lambda t: math.exp(-2 * t) * (2.25 + gj(t)), T0j, T, 4000) if T > T0j else 0.0)
    qerr = max(qerr, abs(q - Hj(T)))
hj = 1e-6
phi_l = math.exp(2 * T0j) * (Vj(T0j) - Vj(T0j - hj)) / hj
phi_r = math.exp(2 * T0j) * (Vj(T0j + hj) - Vj(T0j)) / hj
Tgj = [0.002 * i for i in range(1, 5001)]
Vgj = [Vj(T) for T in Tgj]
off = max(v for T, v in zip(Tgj, Vgj) if abs(T - T0j) > 0.01)
# P11(i)'s smooth candidates: T = 0, zeros of e^{2T} V'(T) away from the kink, holding until loss
dV = [math.exp(2 * T) * d1(Vj, T, 1e-6) for T in Tgj]
zer = [Tgj[i] for i in range(len(Tgj) - 1) if (dV[i] > 0) != (dV[i + 1] > 0) and not (Tgj[i] <= T0j <= Tgj[i + 1])]
best_smooth = max([Vj(0.0), Vj_inf] + [Vj(T) for T in zer])
# after the kink (0 < g < 1), Phi = -3/4 - g/2 + (g + 2)/(g + 1)^2: one smooth zero, an upward crossing (a local minimum of V)
zi = [i for i in range(len(Tgj) - 1) if (dV[i] > 0) != (dV[i + 1] > 0) and not (Tgj[i] <= T0j <= Tgj[i + 1])]
phij = lambda T: math.exp(2 * T) * d1(Vj, T, 1e-6)
Tuj = bisect(phij, Tgj[zi[0]], Tgj[zi[0] + 1], 60) if zi else math.nan
up_ok = len(zi) == 1 and Tgj[zi[0]] > T0j and dV[zi[0]] < 0 < dV[zi[0] + 1] and Vj(Tuj) < min(Vj(Tuj - 0.01), Vj(Tuj + 0.01))
ph_half, ph_35 = phij(math.log(1.1 / 0.5)), phij(math.log(1.1 / 0.6))
counter("P11 set-up with a jump in the rent: rho(x) = x + 1{x >= 1}, r = lam = k_pre = k_post = Delta = 1, g0 = 1.1, F = 9/4, Z = 0; the strict global optimum is the kink T0 = ln 1.1, where Phi jumps from +1/2 to -1/2 and does not satisfy the smooth first-order condition at the maximizing kink; Phi then has a later upward crossing, a local minimum (Phi(g = 1/2) = 1/9 > 0, Phi(g = 3/5) = -11/320 < 0)",
        qerr < 1e-6 and abs(phi_l - 0.5) < 1e-3 and abs(phi_r + 0.5) < 1e-3 and Vj(T0j) > off + 1e-3 and Vj(T0j) > best_smooth + 0.03
        and up_ok and 0.5 < gj(Tuj) < 0.6 and abs(ph_half - 1 / 9) < 1e-6 and abs(ph_35 + 11 / 320) < 1e-6,
        "one-sided Phi(T0-) = %+.4f, Phi(T0+) = %+.4f; V(T0) = %.5f > V(0) = %.5f, V(inf) = %.5f; max V at |T - T0| > 0.01 is %.5f; best smooth candidate (T = 0, zeros of Phi, holding) %.5f; closed forms match quadrature to %.1e; "
        "the only other zero of Phi is upward at T = %.4f (g = %.4f), a local minimum of V; Phi(g = 1/2) = %+.6f, Phi(g = 3/5) = %+.6f"
        % (phi_l, phi_r, Vj(T0j), Vj(0.0), Vj_inf, off, best_smooth, qerr, Tuj, gj(Tuj), ph_half, ph_35))
# mutations: wrong first-order conditions
F, M, al, g0, Dl, r, lam, kap = 0.42, 1.0, 0.5, 0.2, 0.3, 0.05, 0.2, 0.5
rho = r + al * kap
Pi = lambda x: M * x ** al / rho
gT = lambda T: g0 * math.exp(-kap * T)
for mname, fn in [("M11a 'condition without the J' term: F + pi(g) = (r+lam)J'", lambda T: F + M * gT(T) ** al - (r + lam) * Pi(gT(T) + Dl)),
                  ("M11b 'flow rule: release when pi(g+Delta) - pi(g) exceeds F'", lambda T: F - (M * (gT(T) + Dl) ** al - M * gT(T) ** al)),
                  ("M11c 'condition with r in place of r + lam'", lambda T: F + M * gT(T) ** al - r * Pi(gT(T) + Dl)
                   - kap * gT(T) * al * M * (gT(T) + Dl) ** (al - 1) / rho)]:
    Ts = [mc_["Tmax"] * i / 4000 for i in range(4001)]
    vals = [fn(T) for T in Ts]
    Tm = None
    for i in range(4000):
        if (vals[i] > 0) != (vals[i + 1] > 0):
            Tm = bisect(fn, Ts[i], Ts[i + 1])
            break
    if Tm is None:
        Tm = 0.0 if vals[0] <= 0 else math.inf
    mutation(mname, Tm == math.inf or abs(Tm - Tb) > 0.05, "implied release %s vs optimum %.4f" % ("never" if Tm == math.inf else "%.4f" % Tm, Tb))


def interior_T(F, M, al, g0, Dl, r, lam, kpre, kpost, Z=0.0, stable=False):
    mm = p11(F, M, al, g0, Dl, r, lam, kpre, kpost, Z=Z)
    v, T = plan_from_foc(mm, stable=stable)
    return T


npre = npost = 0
pre_ok = post_ok = True
common = {"sooner": [], "later": []}
for al in [0.3, 0.5, 0.7]:
    for Dl in [0.2, 0.5]:
        for g0 in [0.2, 0.5, 1.0]:
            for kap in [0.3, 0.6, 1.0]:
                for lam in [0.1, 0.3]:
                    r = 0.05
                    rho = r + al * kap
                    h = lambda gv: M * gv ** al - (r + lam) * M * (gv + Dl) ** al / rho - kap * gv * al * M * (gv + Dl) ** (al - 1) / rho
                    h0 = -(r + lam) * M * Dl ** al / rho
                    if h(g0) <= h0:
                        continue
                    F = -(h(g0) + h0) / 2
                    T0 = interior_T(F, M, al, g0, Dl, r, lam, kap, kap)
                    if not (0 < T0 < math.inf):
                        continue
                    e = 1e-4 * kap
                    Tpre = interior_T(F, M, al, g0, Dl, r, lam, kap + e, kap)
                    Tpost = interior_T(F, M, al, g0, Dl, r, lam, kap, kap + e)
                    Tboth = interior_T(F, M, al, g0, Dl, r, lam, kap + e, kap + e)
                    if 0 < Tpre < math.inf:
                        npre += 1
                        pre_ok = pre_ok and Tpre < T0
                    if 0 < Tpost < math.inf:
                        npost += 1
                        post_ok = post_ok and Tpost > T0
                    if 0 < Tboth < math.inf:
                        common["sooner" if Tboth < T0 else "later"].append((al, Dl, g0, kap, lam, round(F, 4), T0, (Tboth - T0) / e))
check("faster copying of the public model before release (k_pre) brings interior release sooner (%d cases)" % npre, pre_ok and npre > 10)
check("faster copying of the released model (k_post) delays interior release (%d cases)" % npost, post_ok and npost > 10)
# App. P11(v)'s k_post sign for power rents holds at every eta > 0; checked here at eta > 1 (convex rents). Pi by
# quadrature, Pi' and d/dk_post by central differences, so the closed forms are not used on the numerical side.


def phit_q(g, Dl, r, lam, kpre, kp, eta):
    Piq = lambda x: simpson(lambda s: math.exp(-r * s) * (x * math.exp(-kp * s)) ** eta, 0.0, 40.0 / r)
    return g ** eta - (r + lam) * Piq(g + Dl) - kpre * g * d1(Piq, g + Dl, 1e-4)


pk_min, pk_err = math.inf, 0.0
for eta in [1.5, 2.0, 3.0]:
    for (g, Dl, r, lam, kpre, kp) in [(0.5, 1.0, 0.5, 0.2, 0.5, 0.3), (2.0, 0.5, 0.5, 1.0, 2.0, 1.0), (1.0, 0.2, 1.0, 0.1, 0.3, 0.05)]:
        fd = d1(lambda k: phit_q(g, Dl, r, lam, kpre, k, eta), kp, 1e-4)
        x = g + Dl
        an = eta * x ** (eta - 1) * ((r + lam) * x + kpre * eta * g) / (r + eta * kp) ** 2
        pk_min, pk_err = min(pk_min, fd), max(pk_err, abs(fd - an) / abs(an))
check("power rents with eta > 1 (eta = 1.5, 2, 3; nine cases): dPhi~/dk_post = M eta x^{eta-1}[(r+lam)x + k_pre eta g]/(r + eta k_post)^2 > 0, x = g + Delta",
      pk_min > 0 and pk_err < 1e-5, "smallest difference-quotient derivative %.4f; max rel. error vs the formula %.1e" % (pk_min, pk_err))
note("one copy rate for both: dT*/dk < 0 in %d interior cases and > 0 in %d" % (len(common["sooner"]), len(common["later"])))
for tag in ["sooner", "later"]:
    if common[tag]:
        ex = common[tag][0]
        note("  example (%s): alpha=%.1f Delta=%.1f g0=%.1f k=%.1f lam=%.1f F=%.4f: T* = %.3f, dT*/dk = %+.3f" % ((tag,) + ex))
wide = {"sooner": 0, "later": 0, "tried": 0}
for _ in range(400):
    al, Dl, g0 = RNG.uniform(0.15, 0.95), RNG.uniform(0.05, 2.0), RNG.uniform(0.05, 3.0)
    kap, lam, r = RNG.uniform(0.05, 3.0), RNG.uniform(0.02, 1.0), RNG.uniform(0.01, 0.2)
    rho = r + al * kap
    h = lambda gv: M * gv ** al - (r + lam) * M * (gv + Dl) ** al / rho - kap * gv * al * M * (gv + Dl) ** (al - 1) / rho
    h0 = -(r + lam) * M * Dl ** al / rho
    if h(g0) <= h0:
        continue
    F = -(h0 + RNG.uniform(0.05, 0.95) * (h(g0) - h0))
    wide["tried"] += 1
    T0 = interior_T(F, M, al, g0, Dl, r, lam, kap, kap, stable=True)
    if not (0 < T0 < math.inf):
        continue
    e = 1e-4 * kap
    Tb_ = interior_T(F, M, al, g0, Dl, r, lam, kap + e, kap + e, stable=True)
    if 0 < Tb_ < math.inf:
        wide["sooner" if Tb_ < T0 else "later"] += 1
assert wide["sooner"] + wide["later"] == wide["tried"], "a kept draw failed the interior classification"
note("wider random scan (alpha 0.15-0.95, Delta 0.05-2, g0 0.05-3, k 0.05-3, lam 0.02-1, r 0.01-0.2; %d draws with a band): one copy rate gives dT*/dk < 0 in %d interior cases and > 0 in %d"
     % (wide["tried"], wide["sooner"], wide["later"]))
ex = common["later"][0] if common["later"] else None
counter("P11 'release comes sooner the faster the copying', interior case with one copy rate",
        ex is not None and ex[7] > 0,
        "alpha=%.1f Delta=%.1f g0=%.1f k=%.1f lam=%.1f F=%.4f: dT*/dk = %+.3f > 0" % (ex[0], ex[1], ex[2], ex[3], ex[4], ex[5], ex[7])
        if ex else "no interior case with dT*/dk > 0 found")
# P11(v)'s k_post sign is proved for linear and power rents only; a saturating rent reverses it. rho(x) = 1 - e^{-4x},
# r = lam = k_pre = Delta = 1, g0 = e, Z = 0, F = 1 + e^{-4} + 2e^{-8}: at k_post = 0, Phi crosses zero at g = 1 (T* = 1)
# and dT*/dk_post = -3/(e^4 + 1). V by quadrature (release value integrated along the post-release lead), Phi = e^{2T} V'(T)
# by difference quotients of V, so neither the Phi formula nor P11(v)'s derivative is used.
Fs = 1 + math.exp(-4) + 2 * math.exp(-8)
rhos = lambda x: 1 - math.exp(-4 * x)
gs = lambda T: math.e * math.exp(-T)
heldS = lambda T: simpson(lambda t: math.exp(-2 * t) * (Fs + rhos(gs(t))), 0.0, T, 400) if T > 0 else 0.0
Vs = lambda T, kp: heldS(T) + math.exp(-2 * T) * simpson(lambda s: math.exp(-s) * rhos((gs(T) + 1) * math.exp(-kp * s)), 0.0, 40.0, 2000)
Vs_inf = simpson(lambda t: math.exp(-2 * t) * (Fs + rhos(gs(t))), 0.0, 40.0, 8000)
sres, s_ok = [], True
for kp in [0.0, 0.001, 0.01]:
    phis = lambda T: math.exp(2 * T) * d1(lambda u: Vs(u, kp), T, 1e-4)
    Tg = [0.02 * i for i in range(1, 301)]          # (0, 6]; e^{2T} amplifies quadrature noise beyond
    ph = [phis(T) for T in Tg]
    cr = [i for i in range(len(Tg) - 1) if (ph[i] > 0) != (ph[i + 1] > 0)]
    Ts_ = bisect(phis, Tg[cr[0]], Tg[cr[0] + 1], 60) if len(cr) == 1 else math.nan
    Tv = [0.01 * i for i in range(601)]
    Tgrid = max((Vs(T, kp), T) for T in Tv)[1]
    s_ok = s_ok and len(cr) == 1 and ph[cr[0]] > 0 > ph[cr[0] + 1] and abs(Tgrid - Ts_) <= 0.02 \
        and Vs(Ts_, kp) > Vs(0.0, kp) + 1e-3 and Vs(Ts_, kp) > Vs_inf + 1e-3
    sres.append((Ts_, Tgrid, Vs(Ts_, kp), Vs(0.0, kp)))
s_slope, s_an = (sres[1][0] - sres[0][0]) / 0.001, -3 / (math.e ** 4 + 1)
counter("P11 'faster copying of the released model delays release' for every rent (P11(v) proves it for linear and power rents only): rho(x) = 1 - e^{-4x}, r = lam = k_pre = Delta = 1, g0 = e, Z = 0, F = 1 + e^{-4} + 2e^{-8}; at k_post = 0, Phi crosses zero once, downward, at T* = 1, the strict global optimum (App. P11's sign argument establishes this; the scan illustrates it), and the right derivative dT*/dk_post at 0 is -3/(e^4 + 1) < 0",
        s_ok and abs(sres[0][0] - 1) < 1e-6 and sres[2][0] < sres[1][0] < sres[0][0] and abs(s_slope - s_an) < 0.02 * abs(s_an),
        "T* = %.6f, %.6f, %.6f at k_post = 0, 0.001, 0.01 (scan: one downward crossing of Phi on (0, 6] at each; grid argmax of V %.2f, %.2f, %.2f); right derivative dT*/dk_post at 0 by forward difference %+.5f vs -3/(e^4 + 1) = %+.5f; at k_post = 0, V* = %.5f > V(0) = %.5f, V(inf) = %.5f"
        % (sres[0][0], sres[1][0], sres[2][0], sres[0][1], sres[1][1], sres[2][1], s_slope, s_an, sres[0][2], sres[0][3], Vs_inf))
# richer held uses: internal research u (no hazard effect) vs artifacts a with theft feedback lam = lam0 + theta a.
# The baseline (F = u + a = 0.42, lam = 0.2) does not depend on a, so one line per distinct theta.
found = None
a_ = 0.05
for theta in [0.1, 0.5, 0.75, 1.0, 1.5]:
    T0 = interior_T(0.42, M, 0.5, 0.2, 0.3, 0.05, 0.2, 0.5, 0.5)
    if not (0 < T0 < math.inf):
        continue
    e = 1e-5
    Ta = interior_T(0.42 + e, M, 0.5, 0.2, 0.3, 0.05, 0.2 + theta * e, 0.5, 0.5)
    Tu = interior_T(0.42 + e, M, 0.5, 0.2, 0.3, 0.05, 0.2, 0.5, 0.5)
    Gs = 0.2 * math.exp(-0.5 * T0)
    pred = 1 - theta * (M * (Gs + 0.3) ** 0.5 / (0.05 + 0.25))
    good = (Tu > T0) and ((Ta < T0) == (pred < 0))
    if found is None and Ta < T0:
        found = (theta, a_, T0, (Ta - T0) / e, (Tu - T0) / e, pred)
    check("Z = 0, theta=%.2f: dT*/du = %+.2f > 0; dT*/da = %+.2f has the sign of 1 - theta(J(T*) - Z) = %+.3f"
          % (theta, (Tu - T0) / e, (Ta - T0) / e, pred), good)
counter("P11 'release comes later the richer the artifact uses' when theft responds to artifact earnings",
        found is not None, "theta=%.2f a=%.2f: dT*/da = %+.2f < 0 while dT*/du = %+.2f > 0" % (found[0], found[1], found[3], found[4]) if found else "")
# continuation Z != 0: F lowered by lam Z keeps the same interior T*; the term is 1 - lam'(J - Z), not 1 - lam' J
okZ, mutZ, rowsZ = True, 0, []
for (theta, Zc) in [(0.75, 0.8), (1.0, 1.2), (1.5, 0.4), (0.5, 0.8)]:
    FZ = 0.42 - 0.2 * Zc
    T0 = interior_T(FZ, M, 0.5, 0.2, 0.3, 0.05, 0.2, 0.5, 0.5, Z=Zc)
    e = 1e-5
    Ta = interior_T(FZ + e, M, 0.5, 0.2, 0.3, 0.05, 0.2 + theta * e, 0.5, 0.5, Z=Zc)
    J = M * (0.2 * math.exp(-0.5 * T0) + 0.3) ** 0.5 / 0.3
    new, old = 1 - theta * (J - Zc), 1 - theta * J
    okZ = okZ and 0 < T0 < math.inf and ((Ta > T0) == (new > 0))
    mutZ += (Ta > T0) != (old > 0)
    rowsZ.append("theta=%.2f Z=%.1f: dT*/da = %+.2f, 1 - theta(J-Z) = %+.3f, 1 - theta J = %+.3f" % (theta, Zc, (Ta - T0) / e, new, old))
check("artifact term with continuation Z != 0: dT*/da has the sign of 1 - lam'(f_a)(J(T*) - Z) (four cases)", okZ, "; ".join(rowsZ))
mutation("M11d 'artifact term 1 - lam'(f_a) J(T*), continuation omitted'", mutZ > 0, "%d of 4 cases with Z != 0 get the sign wrong" % mutZ)
note("P11 corollary 'realized window = min(leak time, release time)' is true by definition of the two clocks that end the hold.")
print()

# ================================================================== P12
print("== P12  Perishability and the decisive prize")
ok = True
for (r, kap) in [(0.05, 0.5), (0.1, 1.0), (0.03, 0.2)]:
    ok = ok and abs(simpson(lambda t: math.exp(-(r + kap) * t), 0, 40 / r, 40000) - 1 / (r + kap)) < 1e-6
    ok = ok and abs(simpson(lambda t: math.exp(-r * t), 0, 40 / r, 40000) - 1 / r) < 1e-5
check("eroding unit flow worth 1/(r+k), non-eroding 1/r (quadrature, three cases); ratio (r+k)/r rises in k", ok)
note("at r = 0 the non-eroding value diverges (integral to T is T), so the comparison needs r > 0.")
mutation("M12a 'eroding value 1/(r - k)'", abs(1 / (0.05 - 0.5) - 1 / 0.55) > 1, "1/(r-k) = %.2f is negative" % (1 / (0.05 - 0.5)))
c_, m_, Pd = 1.0, 1.0, 5.0
inc = [m_ / (0.05 + kap) / (4 * c_) for kap in [0.2, 0.5, 1.0]]
dec = [Pd / (4 * c_) for kap in [0.2, 0.5, 1.0]]
counter("P12 'the pull toward a decisive prize rises with k' read as pursuit: separate contests, k = 0.2, 0.5, 1.0",
        inc[0] > inc[1] > inc[2] and dec[0] == dec[1] == dec[2],
        "incremental effort %.3f, %.3f, %.3f; decisive effort %.3f unchanged; only the ratio rises" % (inc[0], inc[1], inc[2], dec[0]))
print()

# ================================================================== P13
print("== P13  What to sell while holding")
ok = True
for _ in range(20000):
    F, f, r, lam, dl = RNG.uniform(0.1, 5), RNG.uniform(0, 5), RNG.uniform(0, 0.2), RNG.uniform(0.05, 2), RNG.uniform(0.001, 2)
    lhs = (F + f) / (r + lam + dl) > F / (r + lam)
    if abs((F + f) / (r + lam + dl) - F / (r + lam)) > 1e-12:
        ok = ok and lhs == (f * (r + lam) > F * dl) and lhs == (f / dl > F / (r + lam))
identity("(F+f)/(r+lam+delta) > F/(r+lam) iff f(r+lam) > F delta iff f/delta > F/(r+lam), 20000 draws (threshold equivalence by algebra)", ok)
F, r, lam = 1.0, 0.05, 0.25
mc = sum(F * (1 - math.exp(-r * RNG.expovariate(lam))) / r for _ in range(n)) / n
check("hold value with exponential loss F/(r+lam) = %.4f (MC %.4f)" % (F / (r + lam), mc), abs(mc - F / (r + lam)) < 0.02)
identity("delta = 0: any f > 0 passes", (F + 0.01) / (r + lam) > F / (r + lam))
counter("P13 'interactive products pass only when the hold is nearly worthless': f = 1000, delta = 10, F/lam = 50 (r = 0)",
        1000 / 10 > 50 and (50 + 1000) / (1 + 10) > 50, "use passes; hold worth 50 -> %.1f" % ((50 + 1000) / 11))
counter("P13 'artifacts in distant domains almost always pass': f = delta = 0.001, F/lam = 100",
        (100 + 0.001) / (1 + 0.001) < 100, "hold value %.5f < 100" % ((100 + 0.001) / 1.001))
ok = True
for _ in range(20000):
    F, f, r, lam, dl, Z = RNG.uniform(0.1, 5), RNG.uniform(0, 5), RNG.uniform(0.01, 0.2), RNG.uniform(0.05, 2), RNG.uniform(0.001, 2), RNG.uniform(0, 10)
    a0, a1 = (F + lam * Z) / (r + lam), (F + f + (lam + dl) * Z) / (r + lam + dl)
    if abs(a1 - a0) > 1e-12:
        ok = ok and (a1 > a0) == (f / dl > (F - r * Z) / (r + lam))
identity("with continuation Z after loss: worth it iff f/delta > (F - rZ)/(r+lam) = V_H - Z (threshold equivalence by algebra)", ok)
ok = True
for _ in range(20000):
    F, f, r, lam, dl, th_ = RNG.uniform(0.1, 5), RNG.uniform(0, 5), RNG.uniform(0.01, 0.2), RNG.uniform(0.05, 2), RNG.uniform(0, 1), RNG.uniform(0, 1)
    a0, a1 = F / (r + lam), (F + f) / (r + lam + dl + th_ * f)
    if abs(a1 - a0) > 1e-12:
        ok = ok and (a1 > a0) == (f * (r + lam) > F * (dl + th_ * f))
identity("theft responding to earnings (added hazard delta + theta f): worth it iff f(r+lam) > F(delta + theta f) (threshold equivalence by algebra)", ok)
bad = 0
for _ in range(20000):
    F, f, r, lam, dl = RNG.uniform(0.1, 5), RNG.uniform(0, 5), RNG.uniform(0.05, 0.3), RNG.uniform(0.05, 1), RNG.uniform(0.01, 2)
    truth = (F + f) / (r + lam + dl) > F / (r + lam)
    bad += truth != (f / dl > F / lam)
mutation("M13a 'undiscounted threshold F/lam applied when r > 0' (an extension beyond the original's r = 0 domain)", bad > 0,
         "%d of 20000 draws misclassified (F in [0.1, 5], f in [0, 5], r in [0.05, 0.3], lam in [0.05, 1], delta in [0.01, 2])" % bad)
# a live release option: a use committed to for the rest of the hold raises the no-release hold value yet lowers
# the firm's optimal value. The benchmark is the true no-release value V_inf, which includes the old model's rent.
base = (0.42, 1.0, 0.5, 0.2, 0.3, 0.05, 0.2, 0.5, 0.5)
m0 = p11(*base)
v0, T0_ = plan_from_foc(m0)
dl, ratio = 0.02, 2.147
f = ratio * dl
m1 = p11(0.42 + f, 1.0, 0.5, 0.2, 0.3, 0.05, 0.2 + dl, 0.5, 0.5)
v1, T1_ = plan_from_foc(m1)
vb1 = plan_brute(m1)[0]
counter("P13 with a live release option: a committed use (delta = 0.02, f/delta = 2.147) raises the no-release hold value yet lowers the optimal value",
        m1["Vinf"] > m0["Vinf"] + 1e-6 and v1 < v0 - 1e-4 and abs(v1 - vb1) < 1e-6,
        "no-release value %.5f -> %.5f; optimal value %.5f -> %.5f (brute force %.5f); release date %.3f -> %.3f"
        % (m0["Vinf"], m1["Vinf"], v0, v1, vb1, T0_, T1_))
print()

# ================================================================== P14
print("== P14  The value of a secret and the theft hazard")
r, lam0, th_ = 0.05, 0.1, 0.5
V14 = lambda F: F / (r + lam0 + th_ * F)
identity("linear theft: V(F) = F/(r + lam0 + theta F) rises in F and stays below 1/theta = 2 (F up to 1e9)",
         all(V14(10 ** k) < 2 and V14(10 ** (k + 1)) > V14(10 ** k) for k in range(-3, 9)) and abs(V14(1e9) - 2) < 1e-6)
ok = True
for _ in range(5000):
    F = 10 ** RNG.uniform(-3, 6)
    extra = RNG.choice([0.0, RNG.uniform(0, 1) * F, th_ * F * F * RNG.uniform(0, 1), RNG.uniform(0, 3)])
    ok = ok and F / (r + lam0 + th_ * F + extra) <= 1 / th_
identity("any theft hazard at least theta F keeps V <= 1/theta (5000 draws, superlinear included)", ok)
Vev = lambda F: F / (r + lam0 + (th_ * math.sqrt(F) if F < 100 else th_ * F))
supev = max(Vev(10 ** (k / 20)) for k in range(-60, 200))
identity("exact condition, sufficient side: theft sublinear below F = 100 and linear above (liminf lam_theta/F = theta > 0) keeps V bounded (closed form evaluated)",
         supev <= max(100 / (r + lam0), 1 / th_) + 1e-9 and Vev(1e9) < 1 / th_, "sup over F in [1e-3, 1e10) = %.3f <= max(100/(r+lam0), 1/theta)" % supev)
Vlog = lambda F: F / (r + lam0 + th_ * F / (1 + math.log1p(F)))
ratio_log = lambda F: Vlog(F) * th_ / (1 + math.log1p(F))
identity("exact condition, necessary side: lam_theta = theta F/(1 + ln(1+F)) rises with F, liminf lam_theta/F = 0, and V tracks (1 + ln(1+F))/theta without bound (closed form evaluated; a finite scan illustrates, the proof establishes unboundedness)",
         Vlog(1e300) > Vlog(1e30) > Vlog(1e12) > Vlog(1e6) and abs(ratio_log(1e30) - 1) < 1e-6 and abs(ratio_log(1e300) - 1) < 1e-6,
         "V(1e6) = %.1f, V(1e12) = %.1f, V(1e30) = %.1f, V(1e300) = %.1f; V theta/(1 + ln(1+F)) = %.8f at 1e30"
         % (Vlog(1e6), Vlog(1e12), Vlog(1e30), Vlog(1e300), ratio_log(1e30)))
Vs = lambda F: F / (r + lam0 + th_ * math.sqrt(F))
counter("P14 cap with theft proportional to sqrt(F)", Vs(1e8) > 100 / th_, "V(1e8) = %.0f > 100/theta" % Vs(1e8))
Vv = lambda F: (-(r + lam0) + math.sqrt((r + lam0) ** 2 + 4 * th_ * F)) / (2 * th_)
fp = abs(Vv(1e6) - 1e6 / (r + lam0 + th_ * Vv(1e6)))
counter("P14 cap when theft rises with capitalized value V (V = F/(r + lam0 + theta V))", fp < 1e-6 and Vv(1e6) > 100 / th_,
        "V(1e6) = %.1f, about sqrt(F/theta) = %.1f" % (Vv(1e6), math.sqrt(1e6 / th_)))
kc = 1.0
Vchoose = lambda F: max(F / (r + lam0 + th_ * math.exp(-s) * F) - kc * s for s in [0.1 * i for i in range(0, 400)])
counter("P14 cap when the holder chooses security, theta(s) = theta0 e^{-s} at cost k s", Vchoose(1e6) > 100 / th_,
        "V(1e6) = %.0f" % Vchoose(1e6))
Zd = 3.0
Vz = lambda F: (F + (lam0 + th_ * F) * Zd) / (r + lam0 + th_ * F)
ok = all(Vz(10 ** (k / 20)) < 1 / th_ + Zd for k in range(-60, 200))
identity("durable assets Z that survive leakage: V = F/(r+lam) + [lam/(r+lam)] Z < 1/theta + Z = %.1f at every F in [1e-3, 1e10) (V(1e9) = %.4f)"
         % (1 / th_ + Zd, Vz(1e9)), ok and Vz(1e9) > 1 / th_)
mutation("M14a 'cap 1/(r + theta)'", V14(1e9) > 1 / (r + th_), "V(1e9) = %.4f > %.4f" % (V14(1e9), 1 / (r + th_)))
mutation("M14b 'a bigger target lowers the value of the secret (V falling in F)'", V14(10) > V14(1))
print()

# ================================================================== P15
print("== P15  Durable assets")
r, kap = 0.05, 0.5
Vd = lambda d: (1 - d) / (r + kap) + d / r
ok = True
for d in [0.0, 0.3, 0.7, 1.0]:
    q = simpson(lambda t: math.exp(-r * t) * ((1 - d) * math.exp(-kap * t) + d), 0, 40 / r, 40000)
    ok = ok and abs(q - Vd(d)) < 1e-4 and abs((1 / r) / Vd(d) - (r + kap) / (r + d * kap)) < 1e-12
grid = [i / 100 for i in range(101)]
ok = ok and all(Vd(grid[i + 1]) > Vd(grid[i]) and (1 / r) / Vd(grid[i + 1]) < (1 / r) / Vd(grid[i]) for i in range(100))
check("V(d) = (1-d)/(r+k) + d/r by quadrature; pull (1/r)/V(d) = (r+k)/(r+dk) falls in d, V rises in d", ok)
xs15 = []
for d in [0.0, 0.5, 1.0]:
    P = dict(vW=0.05 * Vd(d), vL=0.0, c=1.0, L=0.0, th=0.0)
    xs15.append(nash2(P, P, 3.0)[0])
check("step race with durable rents to the winner only: effort %s rises in d = 0, 0.5, 1" % ", ".join("%.4f" % x for x in xs15),
      xs15[0] < xs15[1] < xs15[2] and abs(xs15[2] - 0.05 * Vd(1.0) / 4) < 1e-5)
xs15b = []
for d in [0.0, 0.5, 1.0]:
    P = dict(vW=0.05 * Vd(d), vL=0.05 * d / r, c=1.0, L=0.0, th=0.0)
    xs15b.append(nash2(P, P, 3.0)[0])
counter("P15(b) 'racing at each step rises with d' when each firm banks durable rents from its own products",
        xs15b[0] > xs15b[1] > xs15b[2], "effort %s falls" % ", ".join("%.4f" % x for x in xs15b))
Pd, rho0 = 100.0, 0.5
stake = lambda d: 1.0 * Vd(d) + Pd * rho0 * (1 - d)
counter("P15(b) when the step stake includes continuation value from the decisive prize, rho(d) = 0.5(1-d), P = 100",
        stake(1.0) < stake(0.5) < stake(0.0), "stake %.2f, %.2f, %.2f at d = 0, 0.5, 1" % (stake(0), stake(0.5), stake(1)))


def two_contest_br(yS, yD, S, Pv, k, rounds=40):
    xS, xD = 0.1, 0.1
    for _ in range(rounds):
        xS = argmax(lambda z: (S * z / (z + yS) if z + yS > 0 else S / 2) - 0.5 * k * (z + xD) ** 2, 0.0, 3.0, 800, 60)
        xD = argmax(lambda z: (Pv * z / (z + yD) if z + yD > 0 else Pv / 2) - 0.5 * k * (xS + z) ** 2, 0.0, 3.0, 800, 60)
    return xS, xD


ok = True
for (S, Pv, k) in [(1.0, 2.0, 1.0), (2.0, 1.0, 1.0), (0.5, 3.0, 2.0)]:
    Y = math.sqrt((S + Pv) / (4 * k))
    cS, cD = S / (4 * k * Y), Pv / (4 * k * Y)
    bS, bD = two_contest_br(cS, cD, S, Pv, k)
    ok = ok and abs(bS - cS) < 1e-4 and abs(bD - cD) < 1e-4
check("shared budget (cost k(x_S + x_D)^2/2), S > 0: equilibrium x_S = S/(4kY), x_D = P/(4kY), Y = sqrt((S+P)/(4k)) is a best reply to itself", ok)
b0S, b0D = two_contest_br(0.0, math.sqrt(2.0 / 4), 0.0, 2.0, 1.0)
check("shared budget at S = 0: step effort 0 and decisive effort sqrt(P/(4k)), the formulas' value at S = 0 (best replies with corners)",
      b0S < 1e-9 and abs(b0D - math.sqrt(2.0 / 4)) < 1e-4, "x_S = %.2e, x_D = %.5f vs %.5f" % (b0S, b0D, math.sqrt(2.0 / 4)))
xD = lambda S, Pv, k: Pv / (4 * k * math.sqrt((S + Pv) / (4 * k)))
identity("shared budget: decisive effort falls as the step stake S = m V(d) rises with d (closed form evaluated)",
         xD(Vd(0) * 0.05, 2.0, 1.0) > xD(Vd(0.5) * 0.05, 2.0, 1.0) > xD(Vd(1.0) * 0.05, 2.0, 1.0))
Pdec = dict(vW=2.0, vL=0.0, c=0.0, k=1.0, L=0.0, th=0.0)   # decisive contest, own budget; d does not enter it
xdec = nash2(Pdec, Pdec, 3.0)[0]
counter("P15(a) read as 'weakens the pursuit of a decisive lead' with separate budgets (cost k x^2/2 per contest)",
        abs(xdec - math.sqrt(2.0 / 4)) < 1e-5 and xs15[0] < xs15[2],
        "decisive effort %.4f = sqrt(P/(4k)) at every d while step effort rises %.4f -> %.4f; only the relative weight falls"
        % (xdec, xs15[0], xs15[2]))
ok, bad = True, 0
for _ in range(5000):
    S, Pv, k, tS, tD = RNG.uniform(0.1, 5), RNG.uniform(0.1, 5), RNG.uniform(0.5, 2), RNG.uniform(0.1, 2), RNG.uniform(0.1, 10)
    Rk = lambda S_: 2 * (tS * S_ + tD * Pv) / (4 * k * math.sqrt((S_ + Pv) / (4 * k)))
    dR = (Rk(S + 1e-6) - Rk(S - 1e-6)) / 2e-6
    if abs(tD / tS - (2 + S / Pv)) > 1e-3:
        ok = ok and ((dR > 0) == (tD / tS < 2 + S / Pv))
        bad += (dR > 0) != (tD / tS < 1 + S / Pv)
check("shared budget: total racing risk rises with the step stake iff theta_D/theta_S < 2 + S/P (5000 draws)", ok)
mutation("M15a 'risk rises iff theta_D/theta_S < 1 + S/P'", bad > 0, "%d draws misclassified" % bad)
print()

print("SUMMARY: %d checks of stated results, %d identity confirmations, %d mutations, %d counterexamples (+ %d by construction), %d notes; %d problems"
      % (COUNT["check"], COUNT["identity"], COUNT["mutation"], COUNT["counter"], COUNT["counter_bc"], COUNT["note"], len(BAD)))
for b in BAD:
    print("  PROBLEM:", b)
sys.exit(1 if BAD else 0)
