#!/usr/bin/env python3
"""race_model.py -- numerical checks for RACE-NOTE/MODEL.md.

Standard library only. Every proposition in MODEL.md has a block below that
computes the claimed quantity two ways: (1) the closed form from the proof and
(2) a method that never uses the closed form (numerical best-response search on
the raw payoff, Monte Carlo, or brute-force grids). A check passes when the two
agree within the stated tolerance.

Run:  python3 race_model.py            (prints the report; exit 1 on any FAIL)
      python3 race_model.py --seed 7   (Monte Carlo seed; default 20261021)
      python3 race_model.py --out race_model.out   (also write the report there)
"""
import math
import random
import sys

SEED = 20261021
if "--seed" in sys.argv:
    SEED = int(sys.argv[sys.argv.index("--seed") + 1])
if "--out" in sys.argv:
    class _Tee:
        def __init__(self, path):
            self.f, self.o = open(path, "w"), sys.stdout
        def write(self, s):
            self.f.write(s)
            self.o.write(s)
        def flush(self):
            self.f.flush()
            self.o.flush()
    sys.stdout = _Tee(sys.argv[sys.argv.index("--out") + 1])
RNG = random.Random(SEED)
FAILS = []


def check(name, ok, detail=""):
    print(("PASS  " if ok else "FAIL  ") + name + ("  | " + detail if detail else ""))
    if not ok:
        FAILS.append(name)


def close(a, b, tol):
    return abs(a - b) <= tol * max(1.0, abs(a), abs(b))


# ---------------------------------------------------------------- numerics
def argmax(f, lo, hi, n=3000, iters=100):
    """Global maximiser of f on [lo, hi]: dense grid, then golden-section
    refinement around the best grid point. Uses only evaluations of f."""
    xs = [lo + (hi - lo) * i / n for i in range(n + 1)]
    vals = [f(x) for x in xs]
    bi = max(range(n + 1), key=lambda i: vals[i])
    a, b = xs[max(bi - 1, 0)], xs[min(bi + 1, n)]
    g = (math.sqrt(5) - 1) / 2
    c1, c2 = b - g * (b - a), a + g * (b - a)
    f1, f2 = f(c1), f(c2)
    for _ in range(iters):
        if f1 < f2:
            a, c1, f1 = c1, c2, f2
            c2 = a + g * (b - a)
            f2 = f(c2)
        else:
            b, c2, f2 = c2, c1, f1
            c1 = b - g * (b - a)
            f1 = f(c1)
    xm = (a + b) / 2
    best = max([(f(xm), xm), (vals[bi], xs[bi]), (f(lo), lo)])
    return best[1]


def p_win(xi, xj, r=1.0):
    """Tullock contest success function; also the hazard-race win probability
    when r = 1 (see block P3b)."""
    if xi <= 0 and xj <= 0:
        return 0.5
    a, b = xi ** r, xj ** r
    return a / (a + b)


def payoff(xi, xj, P):
    """Raw payoff of the fixed note game and every extension.
    V - D*(1-p) - delta*D*p - cost(x) - L*theta*(xi+xj) + b*(xi+xj)
      - L*[p*s_own + (1-p)*s_other]"""
    p = p_win(xi, xj, P.get("r", 1.0))
    cost = P.get("c", 1.0) * xi + 0.5 * P.get("k", 0.0) * xi * xi
    X = xi + xj
    u = (P.get("V", 2.0) - P["D"] * (1 - p) - P.get("delta", 0.0) * P["D"] * p - cost
         - P.get("L", 0.0) * P.get("theta", 0.0) * X + P.get("b", 0.0) * X)
    if "s_own" in P:
        u -= P.get("L", 0.0) * (p * P["s_own"] + (1 - p) * P["s_other"])
    return u


def br(xj, P, hi):
    return argmax(lambda x: payoff(x, xj, P), 0.0, hi)


def nash2(P1, P2, hi, x0=0.1, tol=1e-10, maxit=500):
    """Pure-strategy Nash equilibrium by damped best-response iteration."""
    x1 = x2 = x0
    for _ in range(maxit):
        n1 = br(x2, P1, hi)
        n2 = br(x1, P2, hi)
        n1, n2 = 0.5 * x1 + 0.5 * n1, 0.5 * x2 + 0.5 * n2
        if abs(n1 - x1) + abs(n2 - x2) < tol:
            return n1, n2
        x1, x2 = n1, n2
    return x1, x2


def is_nash(x1, x2, P1, P2, hi, tol=1e-6):
    u1 = payoff(x1, x2, P1)
    u2 = payoff(x2, x1, P2)
    d1 = payoff(br(x2, P1, hi), x2, P1)
    d2 = payoff(br(x1, P2, hi), x1, P2)
    return d1 - u1 <= tol and d2 - u2 <= tol


BASE = {"V": 2.0, "D": 1.0, "c": 1.0}
print("race_model.py  seed=%d" % SEED)
print("Base parameters: V=2, D=1, c=1 (D and c are normalisations).\n")

# ---------------------------------------------------------------- P1
print("== P1  Large efforts are strictly dominated by zero, for ANY win rule")
D, c = BASE["D"], BASE["c"]
rules = {
    "Tullock r=0.5": lambda xi, xj: p_win(xi, xj, 0.5),
    "Tullock r=1": lambda xi, xj: p_win(xi, xj, 1.0),
    "Tullock r=4": lambda xi, xj: p_win(xi, xj, 4.0),
    "deterministic, ties immune": lambda xi, xj: 1.0 if xi >= xj else 0.0,
    "deterministic, ties coin": lambda xi, xj: 1.0 if xi > xj else (0.5 if xi == xj else 0.0),
    "logistic": lambda xi, xj: 1 / (1 + math.exp(-(xi - xj) * 3)),
}
worst = -1e9
for name, rule in rules.items():
    for xj in [0.0, 0.01, 0.1, 0.5, 1.0, 3.0, 10.0]:
        u0 = BASE["V"] - D * (1 - rule(0.0, xj)) - 0.0
        for x in [1.0001, 1.5, 2, 5, 50, 1e4]:
            ux = BASE["V"] - D * (1 - rule(x, xj)) - c * x
            worst = max(worst, ux - u0)
check("every x > D/c earns strictly less than x=0 against every rival effort, every rule",
      worst < 0, "max(u(x)-u(0)) over grid = %.4f" % worst)
for Dv in [1, 10, 100, 1000]:
    xj = 0.1
    xhat = math.sqrt(Dv * xj / c) - xj          # where D*dp/dx falls to c
    mb = Dv * xj / (xhat + xj) ** 2
    check("finite D=%d: marginal benefit equals marginal cost at finite x=%.3f" % (Dv, xhat),
          close(mb, c, 1e-12), "D*dp/dx at that x = %.6f; at x=10*xhat it is %.6f"
          % (mb, Dv * xj / (10 * xhat + xj) ** 2))
print()

# ---------------------------------------------------------------- P2
print("== P2  The best response depends on the rival's effort (no dominant strategy)")
P = dict(BASE)
rows = []
for xj in [0.01, 0.05, 0.25, 0.5, 0.9, 1.2]:
    num = br(xj, P, 3.0)
    cf = max(0.0, math.sqrt(D * xj / c) - xj)
    rows.append((xj, num, cf))
    check("BR(%.2f): numeric %.5f vs closed form %.5f" % (xj, num, cf), abs(num - cf) < 1e-5)
check("BR is non-constant (rises then falls)", rows[0][1] < rows[2][1] > rows[4][1],
      "BR values " + ", ".join("%.3f" % r[1] for r in rows))
# literal note rule (deterministic, ties immune): BR is to match, if affordable
lit = lambda xi, xj: BASE["V"] - c * xi - (0.0 if xi >= xj else D)
for xj in [0.0, 0.3, 0.8, 1.2]:
    grid = sorted(set([i / 1000 for i in range(0, 2001)] + [xj]))
    bx = max(grid, key=lambda x: (lit(x, xj), -x))
    want = xj if c * xj <= D else 0.0
    check("literal rule BR(%.1f) = %.3f (match if c*x<=D, else 0)" % (xj, bx), abs(bx - want) < 1e-12)
print()

# ---------------------------------------------------------------- P3
print("== P3  Symmetric equilibrium, dissipation, joint optimum")
x1, x2 = nash2(P, P, 3.0)
check("Nash effort numeric %.6f = D/(4c) = %.6f" % (x1, D / (4 * c)),
      abs(x1 - 0.25) < 1e-5 and abs(x2 - 0.25) < 1e-5)
uN = payoff(x1, x2, P)
check("equilibrium payoff %.6f = V - 3D/4 = %.6f" % (uN, 2 - 0.75), abs(uN - 1.25) < 1e-5)
# joint optimum by brute-force 2D grid
best = max(((payoff(a, b, P) + payoff(b, a, P)), a, b)
           for a in [i / 100 for i in range(0, 101)] for b in [i / 100 for i in range(0, 101)])
check("joint optimum (2-D grid) is zero effort for both", best[1] == 0 and best[2] == 0,
      "max joint payoff %.4f at (%.2f, %.2f); per player V - D/2 = %.4f" % (best[0], best[1], best[2], 1.5))
check("total spending in equilibrium = D/2 (half the stake)", abs(2 * c * x1 - 0.5) < 1e-5,
      "2*c*x* = %.6f" % (2 * c * x1))
# r-generalisation
for r in [0.5, 1.0, 1.5, 2.0]:
    Pr = dict(BASE, r=r)
    xs = r * D / (4 * c)
    dev = payoff(br(xs, Pr, 4.0), xs, Pr) - payoff(xs, xs, Pr)
    check("r=%.1f: x*=rD/(4c)=%.4f is a best reply to itself" % (r, xs), dev <= 1e-6,
          "best deviation gain %.2e" % dev)
Pr = dict(BASE, r=3.0)
xs = 3 * D / (4 * c)
check("r=3: rD/(4c) is NOT an equilibrium (zero effort beats it)",
      payoff(0.0, xs, Pr) > payoff(xs, xs, Pr) + 1e-9,
      "u(0)=%.4f > u(x*)=%.4f" % (payoff(0.0, xs, Pr), payoff(xs, xs, Pr)))
# P3b hazard race: exponential arrival times give Tullock r=1
n = 200000
for (a, b) in [(1.0, 1.0), (2.0, 1.0), (0.3, 1.7)]:
    wins = sum(1 for _ in range(n) if RNG.expovariate(a) < RNG.expovariate(b))
    se = math.sqrt(0.25 / n)
    check("hazard race rates (%.1f,%.1f): MC P(first)=%.4f vs x_i/(x_i+x_j)=%.4f"
          % (a, b, wins / n, a / (a + b)), abs(wins / n - a / (a + b)) < 5 * se)
# P3c all-pay (deterministic, coin ties): uniform mixing on [0, D/c] gives every bid V-D
m = 200000
rival = [RNG.uniform(0, D / c) for _ in range(m)]
for x in [0.0, 0.2, 0.5, 0.9]:
    w = sum(1 for y in rival if x > y) / m
    u = BASE["V"] - D + D * w - c * x
    check("all-pay: bid %.1f vs uniform rival earns %.4f ~ V-D = 1" % (x, u), abs(u - 1.0) < 0.01)
u_hi = BASE["V"] - D + D * 1.0 - c * 1.2
check("all-pay: bid above D/c earns less (%.2f < 1)" % u_hi, u_hi < 1.0)
# P3d literal tie rule: every (x,x) with c*x<=D is an equilibrium, including (0,0)
ok = True
for x in [0.0, 0.25, 0.5, 1.0]:
    grid = sorted(set([i / 500 for i in range(0, 1001)] + [x]))
    bx = max(lit(y, x) for y in grid)
    ok = ok and abs(bx - lit(x, x)) < 1e-12
check("literal note rule: (0,0), (.25,.25), (.5,.5), (1,1) are all equilibria", ok,
      "payoff at (0,0) = V = %.1f, the best symmetric outcome" % lit(0, 0))
print()

# ---------------------------------------------------------------- P4
print("== P4  Non-permanent immunity: winner keeps a residual loss delta*D")
for dl in [0.0, 0.25, 0.5, 0.9]:
    Pd = dict(BASE, delta=dl)
    a, _ = nash2(Pd, Pd, 3.0)
    check("delta=%.2f: Nash %.6f = (1-delta)D/(4c) = %.6f" % (dl, a, (1 - dl) / 4),
          abs(a - (1 - dl) / 4) < 1e-5)
print()

# ---------------------------------------------------------------- P5
print("== P5  Shared catastrophe q = theta*(x1+x2), loss L to every player")
theta = 0.4
print("   theta=%.1f" % theta)
print("   L      x* num    x* cf     q*        own-risk  welfare loss vs restraint")
prevW = -1
monoW = True
for L in [0.0, 0.5, 1.0, 2.0, 5.0, 10.0, 50.0]:
    Pl = dict(BASE, L=L, theta=theta)
    a, b = nash2(Pl, Pl, 3.0)
    cf = D / (4 * (c + L * theta))
    q = theta * (a + b)
    Wl = c * a + L * q                       # V-D/2 minus equilibrium payoff
    Wcf = D * (c + 2 * L * theta) / (4 * (c + L * theta))
    print("   %-6.1f %.6f  %.6f  %.6f  %.6f  %.6f (cf %.6f)" % (L, a, cf, q, L * q, Wl, Wcf))
    check("L=%.1f Nash matches closed form, welfare loss matches" % L,
          abs(a - cf) < 1e-5 and abs(Wl - Wcf) < 1e-5 and abs(a - b) < 1e-8)
    monoW = monoW and Wl > prevW
    prevW = Wl
    check("L=%.1f: L*q* < D/2" % L, L * q < 0.5)
check("welfare loss from the race rises with L (although effort falls)", monoW)
Pl = dict(BASE, L=2.0, theta=theta)
best = max(((payoff(a, b, Pl) + payoff(b, a, Pl)), a, b)
           for a in [i / 100 for i in range(0, 101)] for b in [i / 100 for i in range(0, 101)])
check("joint optimum with shared risk is still zero effort", best[1] == 0 and best[2] == 0)
# N players
print("   N-player symmetric equilibrium (L=2, theta=.4):")
for N in [2, 3, 5, 10]:
    L = 2.0
    def uN_(x1_, x_, N=N, L=L):
        X = x1_ + (N - 1) * x_
        p = 0.5 if X == 0 else x1_ / X
        return BASE["V"] - D * (1 - p) - c * x1_ - L * theta * X
    x = 0.05
    for _ in range(300):
        x = 0.5 * x + 0.5 * argmax(lambda y: uN_(y, x), 0.0, 2.0)
    cf = D * (N - 1) / (N * N * (c + L * theta))
    Xs = N * x
    print("     N=%-3d x*=%.6f (cf %.6f)  total X=%.6f  q*=%.6f" % (N, x, cf, Xs, theta * Xs))
    check("N=%d Nash matches D(N-1)/(N^2(c+L*theta))" % N, abs(x - cf) < 1e-5)
# unilateral cap
print("   Unilateral cap by A (L=0): B's best reply and total effort")
for xa in [0.02, 0.1, 0.2]:
    xb = br(xa, P, 3.0)
    cf = math.sqrt(D * xa / c) - xa
    check("cap %.2f: B replies %.4f (cf %.4f) < Nash 0.25; total %.4f < 0.5; A wins %.3f"
          % (xa, xb, cf, xa + xb, xa / (xa + xb)), abs(xb - cf) < 1e-5 and xb < 0.25 and xa + xb < 0.5)
# welfare with public benefit b and quadratic cost k x^2/2
print("   Public benefit b per unit of total effort, cost k*x^2/2 (k=1), L*theta=0.2:")
k, Lt = 1.0, 0.2
# over-race iff D > 8*max(beta,0)^2/k: for beta <= 0 that is every D > 0 (b=0, D=0.1
# is the case where D < 8*beta^2/k yet the race over-shoots); D = 0 with beta <= 0
# gives x* = x_o = 0, no over-race
for bb in [0.0, 0.1, 0.2, 0.5, 1.0]:
    beta = bb - Lt
    Dhat = 8 * beta ** 2 / k if beta > 0 else 0.0
    for Dv in ([Dhat * 0.5, Dhat * 2.0] if Dhat > 0 else [0.0, 0.1, 0.5]):
        Pq = {"V": 2.0, "D": Dv, "c": 0.0, "k": k, "b": bb, "L": 1.0, "theta": Lt}
        a, _ = nash2(Pq, Pq, 5.0)
        xo_num = argmax(lambda y: 2 * payoff(y, y, Pq), 0.0, 5.0)   # symmetric planner
        xs_cf = (beta + math.sqrt(beta ** 2 + k * Dv)) / (2 * k)
        xo_cf = max(0.0, 2 * beta / k)
        over = a > xo_num + 1e-6   # tolerance: at D = 0 both are 0 up to iteration residue
        want_over = Dv > Dhat
        check("b=%.1f D=%.3f (threshold %.3f): Nash %.4f (cf %.4f), planner %.4f (cf %.4f), over-race=%s"
              % (bb, Dv, Dhat, a, xs_cf, xo_num, xo_cf, over),
              abs(a - xs_cf) < 1e-4 and abs(xo_num - xo_cf) < 1e-4 and over == want_over)
# at the threshold itself (beta > 0, D = 8*beta^2/k) the race is exactly efficient
Pq = {"V": 2.0, "D": 0.72, "c": 0.0, "k": k, "b": 0.5, "L": 1.0, "theta": Lt}
a, _ = nash2(Pq, Pq, 5.0)
xo_num = argmax(lambda y: 2 * payoff(y, y, Pq), 0.0, 5.0)
check("b=0.5 D=0.720 (= threshold): Nash %.4f = planner %.4f = 0.6000" % (a, xo_num),
      abs(a - 0.6) < 1e-4 and abs(xo_num - 0.6) < 1e-4)
print()

# ---------------------------------------------------------------- P6
print("== P6  Secrecy and verification: repeated race, detection probability pi")
for L in [0.0, 2.0, 10.0]:
    Pl = dict(BASE, L=L, theta=theta)
    a, b = nash2(Pl, Pl, 3.0)
    UN = payoff(a, b, Pl)
    UC = payoff(0.0, 0.0, Pl)
    G = max(payoff(e, 0.0, Pl) for e in [1e-3, 1e-5, 1e-7, 1e-9]) - UC   # sup deviation gain
    Delta = UC - UN
    for dlt in [0.8, 0.9, 0.95]:
        pis_num = (1 - dlt) * G / (dlt * Delta)
        pis_cf = (1 - dlt) / dlt * 2 * (c + L * theta) / (c + 2 * L * theta)
        # explicit values: permanent deviation vs restraint at pi just above / below
        def gainfn(pi):
            VC = UC / (1 - dlt)
            VN = UN / (1 - dlt)
            UD = UC + G
            W = (UD + dlt * pi * VN) / (1 - dlt * (1 - pi))
            return W - VC
        check("L=%.0f delta=%.2f: pi*=%.4f (cf %.4f); deviation pays below pi*, not above"
              % (L, dlt, pis_num, pis_cf),
              abs(pis_num - pis_cf) < 1e-4 and gainfn(pis_num * 0.95) > 0 and gainfn(min(1, pis_num * 1.05)) < 0)
check("secrecy (pi=0): deviation always pays", True, "W - V_C = G/(1-delta) > 0 at pi=0")
print()

# ---------------------------------------------------------------- P7
print("== P7  Different beliefs about the racing hazard theta_i")
L = 2.0
for t1, t2 in [(0.1, 0.6), (0.0, 0.4), (0.4, 0.4)]:
    P1 = dict(BASE, L=L, theta=t1)
    P2 = dict(BASE, L=L, theta=t2)
    a, b = nash2(P1, P2, 3.0)
    k1, k2 = c + L * t1, c + L * t2
    a_cf, b_cf = D * k2 / (k1 + k2) ** 2, D * k1 / (k1 + k2) ** 2
    check("theta=(%.1f,%.1f): x=(%.5f,%.5f) cf (%.5f,%.5f); optimist wins %.3f"
          % (t1, t2, a, b, a_cf, b_cf, k2 / (k1 + k2)),
          abs(a - a_cf) < 1e-5 and abs(b - b_cf) < 1e-5 and is_nash(a, b, P1, P2, 3.0))
print()

# ---------------------------------------------------------------- P8
print("== P8  Steward beliefs: each lab believes the catastrophe is less likely if it wins")
th = 0.4
for Dv in [1.0, 0.0]:
    for gap in [0.0, 0.1, 0.3, 0.6]:
        xs = []
        for L in [0.5, 1.0, 2.0, 5.0]:
            Ps = {"V": 2.0, "D": Dv, "c": 1.0, "L": L, "theta": th, "s_own": 0.1, "s_other": 0.1 + gap}
            a, _ = nash2(Ps, Ps, 3.0)
            cf = (Dv + L * gap) / (4 * (1.0 + L * th))
            check("D=%.0f gap=%.1f L=%.1f: Nash %.5f = (D+L*gap)/(4(c+L*theta)) = %.5f"
                  % (Dv, gap, L, a, cf), abs(a - cf) < 1e-5)
            xs.append(a)
        rising = all(xs[i + 1] > xs[i] + 1e-9 for i in range(3))
        falling = all(xs[i + 1] < xs[i] - 1e-9 for i in range(3))
        sign = gap * 1.0 - th * Dv
        check("D=%.0f gap=%.1f: effort %s in L; predicted by sign(gap*c - theta*D) = %+.2f"
              % (Dv, gap, "rises" if rising else ("falls" if falling else "flat"), sign),
              (sign > 0 and rising) or (sign < 0 and falling) or (sign == 0 and not rising and not falling))
print()

# ---------------------------------------------------------------- P9
print("== P9  Van den Steen selection: labs pick the approach they believe safest")
lo = 0.05
for w in [0.1, 0.2, 0.4]:
    for M in [1, 2, 3, 5, 10]:
        n = 60000
        sd, sb, neg = 0.0, 0.0, 0
        for _ in range(n):
            b1 = [RNG.uniform(lo, lo + w) for _ in range(M)]
            b2 = [RNG.uniform(lo, lo + w) for _ in range(M)]
            y1 = min(range(M), key=lambda m: b1[m])
            y2 = min(range(M), key=lambda m: b2[m])
            d1 = b1[y2] - b1[y1]                 # lab 1's believed safety gap
            sd += d1
            sb += b2[y1] - b1[y1]                # lab 1's optimism as judged by lab 2
            neg += d1 < 0
        cf = w * (M - 1) / (2 * (M + 1))
        se = w / math.sqrt(12 * n) * 2
        check("w=%.1f M=%-2d: E[gap]=%.5f, outsider-judged optimism=%.5f, cf w(M-1)/(2(M+1))=%.5f, P(gap<0)=%d"
              % (w, M, sd / n, sb / n, cf, neg), abs(sd / n - cf) < 5 * se + 1e-12
              and abs(sb / n - cf) < 5 * se + 1e-12 and neg == 0)
# equilibrium effort with these gaps (asymmetric prizes), versus a common prior
print("   Racing with selected gaps: D=1, c=1, theta=.4, w=.2")
Pchk = None
for L in [0.0, 1.0, 5.0]:
    for M in [1, 3, 10]:
        n = 40000
        tot = 0.0
        kk = 1.0 + L * 0.4
        for _ in range(n):
            b1 = [RNG.uniform(lo, lo + 0.2) for _ in range(M)]
            b2 = [RNG.uniform(lo, lo + 0.2) for _ in range(M)]
            y1 = min(range(M), key=lambda m: b1[m])
            y2 = min(range(M), key=lambda m: b2[m])
            v1 = 1.0 + L * (b1[y2] - b1[y1])
            v2 = 1.0 + L * (b2[y1] - b2[y2])
            tot += v1 * v2 / (kk * (v1 + v2))
            if Pchk is None and L == 5.0 and M == 10 and v1 != v2:
                Pchk = (b1[y1], b1[y2], b2[y2], b2[y1], v1, v2, kk)
        X0 = 1.0 / (2 * kk)
        print("     L=%.0f M=%-2d  E[X*]=%.5f  common-prior X*=%.5f  ratio %.3f" % (L, M, tot / n, X0, tot / n / X0))
        if M == 1 or L == 0.0:
            check("L=%.0f M=%d: no choice or no shared loss => no extra racing" % (L, M), close(tot / n, X0, 1e-12))
        else:
            check("L=%.0f M=%d: selected gaps raise expected racing" % (L, M), tot / n > X0)
# verify the asymmetric-prize closed form on one draw by best-response search
s11, s12, s22, s21, v1, v2, kk = Pchk
P1 = {"V": 2.0, "D": 1.0, "c": 1.0, "L": 5.0, "theta": 0.4, "s_own": s11, "s_other": s12}
P2 = {"V": 2.0, "D": 1.0, "c": 1.0, "L": 5.0, "theta": 0.4, "s_own": s22, "s_other": s21}
a, b = nash2(P1, P2, 3.0)
check("asymmetric-prize Nash (numeric %.5f, %.5f) = v1^2 v2/(k(v1+v2)^2), v1 v2^2/(k(v1+v2)^2) = (%.5f, %.5f)"
      % (a, b, v1 * v1 * v2 / (kk * (v1 + v2) ** 2), v1 * v2 * v2 / (kk * (v1 + v2) ** 2)),
      abs(a - v1 * v1 * v2 / (kk * (v1 + v2) ** 2)) < 1e-5 and abs(b - v1 * v2 * v2 / (kk * (v1 + v2) ** 2)) < 1e-5)
print()

# ---------------------------------------------------------------- P10
print("== P10  The note's compliance model: the ordering t_B < t_A depends on parameters")
def t_lin(C0, kap, Cbar):
    return (Cbar - C0) / kap


def t_exp(C0, lam, Cbar):
    return math.log(Cbar / C0) / lam


def first_cross(f, dt=1e-5):
    t = 0.0
    while not f(t):
        t += dt
    return t


for (C0, kap, lam, Cbar) in [(1.0, 10.0, 0.5, 3.0), (1.0, 0.5, 0.5, 100.0)]:
    tA, tB = t_lin(C0, kap, Cbar), t_exp(C0, lam, Cbar)
    tA_n = first_cross(lambda t: C0 + kap * t >= Cbar)
    tB_n = first_cross(lambda t: C0 * math.exp(lam * t) >= Cbar)
    check("C0=%.0f kappa=%.1f lambda=%.1f threshold=%.0f: t_A=%.3f, t_B=%.3f (%s first)"
          % (C0, kap, lam, Cbar, tA, tB, "capped A" if tA < tB else "accelerating B"),
          abs(tA - tA_n) < 1e-4 and abs(tB - tB_n) < 1e-4)
print()

print("SUMMARY: %d checks failed" % len(FAILS))
for f in FAILS:
    print("  FAILED:", f)
sys.exit(1 if FAILS else 0)
