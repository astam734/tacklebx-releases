# Supplement: evidence snapshot and versions read

Supplement to "Running Through the Rain: Speed, Secrecy and Risk in the AI Cyber Transition" (Allan C. Stam, University of Virginia), prepared for draft v6 on 25 October 2026; its head forms were checked against draft v14 on 11 November 2026. Version 16 of the paper (14 November 2026) rewrote Sections 1 to 12 at about half their length without changing a result, a number or a source; the claims audited below are those of the main text as it stood through version 15, some of which version 16 states more briefly or leaves to the appendices. Section, proposition and reference citations refer to the paper. Supplement S1 records the version of each work we read where the paper's reference list needs that stated; Supplement S2 is the claim-by-claim source audit, with the data note behind our calculations from CISA's catalogue. Both are dated: they describe the sources as we read them in October 2026, except the four works added to the reference list later (Australian Signals Directorate 2026; Imas, Koh and Legg 2026; Open Source Initiative 2024; Sullivan and von Wachter 2009), whose cited passages were read and checked in November 2026.

## S1. Versions read

Entries are keyed by the paper's in-text citation and follow the reference list's order. References not listed here have no separate version note.

- **Adkins, Evron and Schneier 2025.** The reprint on schneier.com, with the CSO original saved for byline, date and subtitle, fetched 23 October 2026. The article is not paginated; the body pinpoints its subtitle and section headings. No DOI; Crossref and OpenAlex hold no record.
- **Aghion and Howitt 1990.** NBER Working Paper 3223 (January 1990). The published version was revised after refereeing, so the body cites a section, not an equation number. The published page range is not given, because only its first page could be confirmed (Crossref, OpenAlex).
- **Aghion et al. 2001.** Harvard DASH accepted manuscript, October 2000.
- **AISI 2026.** Saved copy fetched 23 October 2026. The 4.7-month figure is AISI's February 2026 estimate as reported in this post; the fit is shown as a figure, not published as data.
- **Anderson and Moore 2006.** Authors' 11-page manuscript (Cambridge Computer Laboratory). The body's quotation and p. 1 pinpoint refer to this manuscript, not to the edited Science text.
- **Anthropic 2025.** Saved copy of the announcement post, fetched 22 October 2026. The quoted phrase “in a small number of cases” is in this post, not in the accompanying November 2025 PDF report. This is Anthropic's account of the campaign.
- **Anthropic 2026a.** Saved copy. This is a lab's report on its own model.
- **Anthropic 2026b.** Saved copy. This is a lab's report on its own model.
- **Anthropic 2026c.** Saved copy, whose text matched the live page on 22 October 2026. This is a lab's report on its own model.
- **Anthropic 2026d.** Saved copy. These are Anthropic's reported evaluations, including its runs of the external ExploitBench benchmark.
- **Anthropic 2026e.** Overview and process explanation; archive snapshot dated 7 October 2026, 12:53:16 UTC, https://web.archive.org/web/20261007125316/https://red.anthropic.com/2026/cvd/. No archive capture dated 2 October is held. The live page fetched 22 October 2026, 19:55:56 UTC, was byte-identical to that archive capture. These are the lab's dated disclosure and patch counts, not a cohort patch rate or a measure of deployment.
- **Anthropic 2026f.** Saved copy fetched 23 October 2026. This is a lab's report on its own model.
- **Anthropic 2026g.** Saved copy fetched 23 October 2026. This is a lab's report on its own model.
- **Anthropic 2026h.** Saved copy fetched 23 October 2026. This is a lab's report on its own model.
- **Arbatskaya and Mialon 2010.** The published version.
- **Arbaugh, Fithen and McHugh 2000.** Author-hosted PDF of the published *IEEE Computer* layout, with printed folios 52–59. Author order follows the printed byline; Crossref and OpenAlex list McHugh, Fithen, Arbaugh.
- **ARC Prize 2026.** Data file generated 21 October 2026, downloaded 23 October 2026.
- **Armstrong, Bostrom and Shulman 2013.** Future of Humanity Institute Technical Report #2013-1 (October 2013). The body pinpoints by section because the pages differ.
- **Arrow 1962.** NBER chapter scan (nber.org/chapters/c2144). The DOI 10.1007/978-1-349-15486-9_13 is for a 1972 reprint, not the version read.
- **Askell, Brundage and Hadfield 2019.** arXiv v1.
- **Belson 2025.** Page fetched 23 October 2026. Cloudflare's own traffic data.
- **Brumley et al. 2008.** BitBlaze project PDF, which has no page numbers. Pages are per OpenAlex.
- **Buterin 2023.** Saved copy fetched 23 October 2026. The essay is not paginated; the body pinpoints its section headings. No DOI; Crossref and OpenAlex hold no record.
- **Carlini et al. 2024.** arXiv:2403.06634v2 (9 July 2024), which carries the ICML/PMLR 235 line.
- **Charrier and Weiner 2024.** Saved article text.
- **Charrier et al. 2026.** Saved page text, fetched 23 October 2026. Counts are detected and disclosed zero-days, cutoff 31 December 2025.
- **CISA 2026.** JSON and CSV feeds, fetched 23 October 2026 (1,754 entries; dateAdded 3 November 2021 to 20 October 2026). Class shares in the body are our calculation from the catalogue's CWE tags (Supplement S2, data note); CISA publishes none.
- **Cognition 2026.** Saved copy, 23 October 2026. The leaderboard was launched on 17 July 2026. Cognition's own models (SWE-1.6, SWE-2) are among those listed.
- **DARPA 2025.** Saved copy fetched 23 October 2026, carrying an undated editor's note that corrects the number of synthetic vulnerabilities in the final from 70 to 63. This is the competition organizer's report of its results; ARPA-H's page of 4 September 2025 repeats the same counts.
- **Debenedetti et al. 2025.** Abstract page, fetched 23 October 2026; the passage cited is in the abstract. Preprint.
- **DeepSeek-AI et al. 2025.** arXiv v2 (4 January 2026) abstract page, 23 October 2026; the passage cited is in the abstract. This is a lab's report on its own model.
- **Dixit and Pindyck 1994.** Chapters 1, 2, 4, 5 and 8 only. The body cites chapter 4 (pp. 93–132) by section.
- **dots team 2026.** Saved copy, 23 October 2026. This is a lab's report on its own model; no IMO record of the marking was located.
- **Epoch AI 2026a.** Export downloaded 23 October 2026, files dated 23 October 2026. The FrontierMath rows are Epoch's own evaluations on the private sets; the FrontierSWE and FrontierCode rows are Epoch's copies of the benchmark owners' leaderboards.
- **Epoch AI 2026b.** Saved copy, 23 October 2026. FrontierMath was developed with funding from OpenAI, which has exclusive access to a subset of the benchmark.
- **FBI et al. 2023.** Saved page text of the July 2025 revision, fetched 23 October 2026.
- **FinCEN 2024.** Saved PDF, fetched 23 October 2026.
- **Fonseca et al. 2017.** Author-hosted PDF, abstract and §4.4, 23 October 2026.
- **Ford 2026.** Page fetched 23 October 2026.
- **FrontierSWE 2026.** Saved copy, 23 October 2026.
- **GAO 2025.** A copy of the PDF downloaded 21 October 2026; gao.gov refused scripted retrieval on 23 October 2026. Modernization statuses are agency-reported.
- **Google 2026.** File fetched 23 October 2026, last row 21 October 2026. Share of users reaching Google over IPv6.
- **Grunewald, Mazumdar and Vanderlee 2026.** Saved page text, fetched 23 October 2026. Covers vulnerabilities disclosed 1 January 2025 to 31 August 2026.
- **Gudibande et al. 2023.** arXiv v1.
- **Hinton, Vinyals and Dean 2015.** arXiv v1.
- **Hoffmann et al. 2022.** arXiv v1 abstract page, 23 October 2026; the passage cited is in the abstract.
- **Horn 2018.** Full post, including n. 1, which excludes Meltdown from the initial report.
- **Kaplan et al. 2020.** arXiv v1 abstract page, 23 October 2026; the passage cited is in the abstract.
- **Kapoor et al. 2024.** arXiv v1 (27 February 2024). An ICML 2024 position-paper version exists and was not checked.
- **Kenna Security and Cyentia Institute 2019.** PDF fetched 23 October 2026 (© 2019 Cyentia Institute); Key Findings, p. 4, and the survival analysis, pp. 18–19. Commissioned by Kenna Security, which supplied the data. The remediation-time figures are a survival analysis of 190 million vulnerabilities at 12 Kenna customer organizations, with data to late 2018.
- **Khatry et al. 2025.** Abstract page, fetched 23 October 2026; the passage cited is in the abstract.
- **Lermen, Rogers-Smith and Ladish 2024.** arXiv:2310.20624v2 (22 May 2024), the workshop version. It was first posted in October 2023, and OpenAlex confirms the author order.
- **Li and Paxson 2017.** Author-hosted camera-ready PDF carrying the ACM copyright block and DOI. Its pages carry no proceedings folios, so the body pinpoints sections.
- **Linton and Parseghian 2018.** Opening of the post; the mitigation-status table was not in the saved text.
- **METR 2025.** Saved copy fetched 23 October 2026 (the earlier address, evaluations.metr.org/gpt-5-report/, redirects here); Appendix, "METR's access to GPT-5". This is an external evaluator's account of its own access period.
- **METR 2026.** Saved copy, 23 October 2026.
- **Microsoft 2026.** Page fetched 23 October 2026. Vendor documentation of configurable defaults, not a measured rollout.
- **Nappa et al. 2015.** Authors' 17-page copy, numbered 1–17 rather than with the proceedings folios, so the body pinpoints sections.
- **Nasr et al. 2025.** Abstract page and v1 PDF (table 1), fetched 23 October 2026. Preprint.
- **Nordhaus 1969.** Chapter 5, "The Economics of Patents" (pp. 70ff). No DOI; the edition is confirmed by 1970–71 reviews.
- **Owen 2024.** arXiv v1 abstract page, 23 October 2026; the passage cited is in the abstract.
- **Palmer and Sleevi 2014.** Page fetched 23 October 2026.
- **PutnamBench 2026.** Both downloaded 23 October 2026. Entries are submitter-reported.
- **Rescorla 2004.** The 18-page workshop paper (sos-vo.org PDF). A shorter version, not read, appeared in *IEEE Security & Privacy* in 2005, https://doi.org/10.1109/MSP.2005.17. Workshop name per the paper's acknowledgements and Anderson and Moore's reference [12] (WEIS 3, 2004).
- **Rice 1953.** Full text from the AMS archive PDF. The body pinpoints the theorem and its interpretation because the text read has no printed page numbers. The garbled proof of Theorem 6 is not quoted.
- **Sandbrink et al. 2022.** SSRN working paper, with the title shown here; the later Science and Public Policy article was not read or cited.
- **Schneier 2018.** The author's reprint of the March/April 2018 column on schneier.com; the print text was not compared. The column is one page.
- **Seger et al. 2023.** arXiv:2311.09227v1, the same report.
- **seL4 Project n.d.** Saved copy, 23 October 2026, the answers to "Does seL4 have zero bugs?" and "What are the proof assumptions?". This is the project's account of its own proofs.
- **Shevlane 2022.** arXiv v1 (13 January 2022), all 26 pages; the body cites the abstract on p. 1. The current arXiv version, dated 11 April 2022, is titled "Structured Access: An Emerging Paradigm for Safe AI Deployment" and was not read.
- **Shevlane and Dafoe 2020.** arXiv:2001.00463v2.
- **Snell et al. 2024.** arXiv v1 abstract page, 23 October 2026; the passage cited is in the abstract.
- **Stix et al. 2025.** arXiv v1.
- **Sullivan and von Wachter 2009.** The published article’s abstract, available through the publisher’s indexed primary record; full-article access was not verified.
- **The White House 2025.** PDF fetched 23 October 2026; Introduction, p. 1.
- **Thompson et al. 2025.** Page fetched 23 October 2026. Google's own Chrome telemetry.
- **Tramèr et al. 2016.** arXiv:1609.02943v2, the extended version (https://doi.org/10.48550/arXiv.1609.02943). The body pinpoints the abstract.
- **Trump 2026.** Federal Register full text, fetched 23 October 2026; §3.
- **Van den Steen 2004.** Published text. The body cites the choice-driven optimism mechanism; its application to lab safety is the paper's own interpretation.
- **Weeds 2000.** Warwick Economic Research Paper 576 (20 September 2000). The body pinpoints by section.
- **Westerbaan 2024.** Page fetched 23 October 2026. Cloudflare's own connection data.
- **Whalley 2016.** Page fetched 23 October 2026. States the planned removal date; the actual release date was not checked.
- **Yang et al. 2024.** Abstract page, fetched 23 October 2026; the passage cited is in the abstract. A later ASE 2025 version was not read.
- **Yang et al. 2011.** Author preprint PDF, §3.1 "Testing CompCert", 23 October 2026.

## S2. Source audit and KEV data note

The table lists the empirical claims of Sections 2, 4.7 and 5–11 that rest on outside records, as this draft states them. For each it gives the primary source; whether that source is independent of the lab, meaning the developer or operator whose model or system it reports on; and the claim's status after our claim-by-claim check. VERIFIED means the record says what the text says. CORRECTED means the record supports a narrower or reworded claim, which is the one the text now states. DERIVED means our calculation from the record. JUDGMENT means our own reading, labeled as such in the text and consistent with the record. Checking a report establishes what it reports, not that its figures are right. Model results are proved in Appendices A and B and are not listed. Claims we could not support were cut and do not appear.

| Claim, as stated in the text | Source | Independent of the lab? | Status |
|---|---|---|---|
| The restricting lab expects defense to dominate in the long run, after a fraught transition (Section 2) | Anthropic 2026g | No | VERIFIED |
| That expectation is not evidence (Section 2) | — | NA | JUDGMENT |
| AI may upend attack's advantage and tip the scales toward defense (Section 2) | Schneier 2018 | NA | VERIFIED |
| A defense-favoring world is better; promoting defense-favoring technology as differential technology development; cyber examples that are not AI vulnerability-finding (Section 2) | Buterin 2023 | NA | VERIFIED |
| A speculative path to automatic patching before production, with a warning that AI may tip the scales to attackers (Section 2) | Adkins, Evron and Schneier 2025 | NA | VERIFIED |
| No source read states the case as a whole or speaks of sprinting through a window (Section 2) | — | NA | JUDGMENT |
| The holder called its model general-purpose and unreleased, did not plan general availability, and expected the capability to proliferate soon (Sections 2, 5, 7.1) | Anthropic 2026a | No | VERIFIED |
| AlphaFold as the first computational method to predict protein structures regularly with atomic accuracy where no similar structure is known; determining one structure took months to years (Section 4.7) | Jumper et al. 2021, abstract and opening paragraph | No; the developers' report on their own method | VERIFIED |
| Half of the 2024 Nobel Prize in Chemistry to Hassabis and Jumper "for protein structure prediction" (Section 4.7) | Nobel Prize Outreach 2024 | Yes | VERIFIED |
| Clinical phase about 95 months against 31 non-clinical, a figure the report attributes to an earlier study; the non-clinical stage includes target discovery; Phase 3 the longest stage at 38.0 months; FDA review 16.2 months including the sponsor's time; clinical phases may overlap (Section 4.7) | Sertkaya and Berger 2024, pp. v, 12 | NA | VERIFIED |
| About 18 months from target discovery to a preclinical candidate, in one programme (Section 4.7) | Ren et al. 2024, abstract | No; the developer's report on its own programme | VERIFIED |
| Under 30 months from the start of target discovery to the end of phase 0/1 testing, followed by a phase 2a trial (Section 4.7) | Xu et al. 2025, introduction | No; the developer's report on its own programme | VERIFIED |
| Ransomware attacks cut hospital volume by 17–24 percent in the attack week and raise in-hospital mortality by 34–38 percent among patients already admitted (Section 4.7) | Neprash, McGlave and Nikpay 2026, published abstract | NA | VERIFIED |
| 30-day acute myocardial infarction mortality up as much as 0.36 percentage points in the 3 years after a breach, which the authors associate with remediation they did not directly observe (Sections 4.7, 10.2) | Choi, Johnson and Lehmann 2019, abstract and discussion | NA | VERIFIED |
| Targeted hospital cyberattacks may be associated with disruptions at nontargeted hospitals (Section 4.7) | Dameff et al. 2023, abstract | NA | VERIFIED |
| The DALY combines premature death and time in less than optimal health, one DALY being one lost year of healthy life; WHO's current estimates use no discounting for time (Section 4.7) | WHO 2024, pp. 6, 7 | NA | VERIFIED |
| A gain that does not fall as AI improves: in a model of one industry, where equilibrium is the efficient allocation and the outside option and the price of compute are fixed, an AI at least as capable in every dimension weakly raises total surplus (Section 4.7) | Imas, Koh and Legg 2026, pp. 25, 66 | NA | VERIFIED |
| The gain is indexed to AI capability, not to dates (Section 4.7) | Imas, Koh and Legg 2026, pp. 27–28 | NA | VERIFIED |
| Displacement costs come from outside the model, in which wages above the outside option are transfers (Section 4.7) | Imas, Koh and Legg 2026, p. 23 | NA | VERIFIED |
| Higher mortality after job loss among high-seniority men in Pennsylvania administrative data (Section 4.7) | Sullivan and von Wachter 2009, indexed publisher abstract | NA | VERIFIED |
| Best FrontierMath scores of 93.7% on Tiers 1–3 and 100% on Tier 4, by OpenAI models, on a benchmark OpenAI funded and partly holds (Section 5) | Epoch AI 2026a; 2026b | Yes; OpenAI's funding and access are stated | VERIFIED |
| Tier 4's private set has 41 problems (Section 5) | Epoch AI 2026b | Yes | DERIVED |
| Best ARC-AGI-2 semi-private score of 95% (Section 5) | ARC Prize 2026 | Yes | VERIFIED |
| An IMO 2026 perfect score, on a lab's own account of official marking (Section 5) | dots team 2026 | No | VERIFIED |
| Five PutnamBench entries report all 672 Lean problems; the records do not document public verification; three name general frontier models (Section 5) | PutnamBench 2026 | No; submitter-reported | CORRECTED |
| FrontierSWE and FrontierCode unsaturated, at 65.5% and 54.6%, with about four and eight months of dated rows (Section 5) | FrontierSWE 2026; Cognition 2026; Epoch AI 2026a | Partly; Cognition lists its own models on FrontierCode | CORRECTED |
| Too little data for a trend fit (Section 5) | — | NA | JUDGMENT |
| METR's 50% horizon, its 16-hour warning, and no update since 8 September 2026 (Section 5) | METR 2026 | Yes | VERIFIED |
| Scaling laws are fitted to loss (Section 5) | Kaplan et al. 2020; Hoffmann et al. 2022 | NA | VERIFIED |
| Extrapolation errors of 6 and 18 percentage points (Section 5) | Owen 2024 | NA | VERIFIED |
| Improved reasoning through reinforcement learning after pre-training (Section 5) | DeepSeek-AI et al. 2025 | No | CORRECTED |
| Test-time compute can let a smaller model outperform a fourteen-times larger one (Section 5) | Snell et al. 2024 | NA | VERIFIED |
| Rice's theorem and its room for special methods (Section 5) | Rice 1953 | NA | VERIFIED |
| seL4's proof assumptions; no guarantee about covert timing channels (Section 5) | seL4 Project n.d. | No | CORRECTED |
| CompCert 1.6's front-end bugs and PowerPC semantics gap (Section 5) | Yang et al. 2011 | Yes | CORRECTED |
| Sixteen bugs in three verified distributed systems, mostly at interfaces (Section 5) | Fonseca et al. 2017 | Yes | VERIFIED |
| AI Cyber Challenge final: 54 unique synthetic vulnerabilities found in the final's 63 challenges and 43 patched (63 synthetic vulnerabilities in all, by DARPA's corrected count); 18 real found and 11 patched (Section 6.1) | DARPA 2025 | Yes | VERIFIED |
| More than 500 high-severity vulnerabilities found with Claude and validated by human researchers (Section 6.1) | Anthropic 2026f | No | CORRECTED |
| 181 working exploits against two successes, in a harness without the browser's sandbox (Section 6.1) | Anthropic 2026g | No | VERIFIED |
| The 181 successes include repeats (Section 6.1) | Anthropic 2026g; 2026h | No | DERIVED |
| Eight Firefox exploits, timed by the fastest of three trials per stage; patches public for at least 90 days (Section 6.1) | Anthropic 2026c | No | CORRECTED |
| A 4.7-month doubling of the 80%-reliability cyber horizon, with AISI's own caveats (Section 6.1) | AISI 2026 | Yes | VERIFIED |
| Average time-to-exploit of five days, or 47 with outliers (Section 6.1) | Charrier and Weiner 2024 | NA | VERIFIED |
| A campaign that succeeded "in a small number of cases" (Section 6.1) | Anthropic 2025 | No | VERIFIED |
| Counts of exploitation in the wild after 2023 exist but do not isolate AI (Section 6.1) | Charrier et al. 2026; Grunewald, Mazumdar and Vanderlee 2026; CISA 2026 | Yes | CORRECTED |
| The balance depends on adversaries and shifts with investment (Section 6.1) | Slayton 2017; Garfinkel and Dafoe 2019 | NA | VERIFIED |
| Much of the quantitative evidence comes from one lab (Section 6.1) | — | NA | JUDGMENT |
| 6,157 vulnerabilities disclosed and 516 known patched; patches a lagging indicator; human triage the rate-limiting step (Sections 6.1, 6.5) | Anthropic 2026e | No | VERIFIED |
| Median remediation of 90 days and 32.5% open after 180 days, at 12 firms (Section 6.2) | Kenna Security and Cyentia Institute 2019 | NA | VERIFIED |
| Seven days to 90% of devices, as Anthropic's reading of Windows Autopatch; the Microsoft pages examined do not state it (Section 6.2) | Anthropic 2026c; Microsoft 2026 | Anthropic: yes, about Microsoft's channel; Microsoft: no | CORRECTED |
| Client hosts: 45 days to patch half of vulnerable hosts; at most 14% patched when exploits are released; 28% of patches reach 95% of hosts (Section 6.2) | Nappa et al. 2015 | Yes | VERIFIED |
| Over half of CVEs patched in repositories more than a week before disclosure; attackers can get a jump of weeks to months (Section 6.2) | Li and Paxson 2017 | Yes | VERIFIED |
| Patches available at least a month before intrusions; systems vulnerable months or years after corrections; the prevented intrusions likely nuisance attacks (Section 6.2) | Arbaugh, Fithen and McHugh 2000 | Yes | VERIFIED |
| Patching series bear on the share of adoption that waits for the capability; retirement and migration series on whether adoption binds (Section 6.2) | — | NA | JUDGMENT |
| Three of ten critical federal legacy systems modernized by February 2025 (Section 6.2) | GAO 2025 | Yes; agency-reported status | VERIFIED |
| HTTPS in Chrome from 30–45% to 95–99% (Section 6.2) | Thompson et al. 2025 | No | VERIFIED |
| Post-quantum key agreement on nearly 2% of TLS 1.3 connections to Cloudflare in March 2024 and, on a different denominator, 52% of the human-generated Web traffic Cloudflare observed in December 2025 (Section 6.2) | Westerbaan 2024; Belson 2025 | No | CORRECTED |
| About two and a half years planned from SHA-1 announcement to removal (Section 6.2) | Palmer and Sleevi 2014; Whalley 2016 | No | DERIVED |
| IPv6 access to Google past 50% on one day, about 27 years after RFC 2460 (Section 6.2) | Google 2026; Deering and Hinden 1998; Ford 2026 | Google: no; Internet Society: yes | DERIVED |
| The externality quotation (Section 6.2) | Anderson and Moore 2006 | NA | VERIFIED |
| Shares of access-policy and memory-corruption classes among known exploited vulnerabilities, with CWE-20 excluded and restricted by CVE identifier year as checks (Section 6.3) | CISA 2026; the data note below | Yes | DERIVED |
| Batch listing in 2022 and the yearly memory-corruption shares behind Predictions 2 and 3, with the conditional binomial calculations (Section 11) | CISA 2026; the data note below | Yes | DERIVED |
| Help-desk calls to reset passwords and transfer tokens (Section 6.4) | FBI et al. 2023 | Yes | VERIFIED |
| Generative AI reportedly used to impersonate executives (Section 6.4) | FinCEN 2024 | Yes | CORRECTED |
| Twelve defenses against jailbreaks and prompt injections bypassed by adaptive attacks (Section 6.4) | Nasr et al. 2025 | Yes | CORRECTED |
| CaMeL solves 77% of AgentDojo tasks with provable security, against 84% undefended (Section 6.4) | Debenedetti et al. 2025 | No (developer's own evaluation) | VERIFIED |
| Defenses that need no frontier capability (Sections 6.4, 10.2) | Sandbrink et al. 2022 for the principle | NA | JUDGMENT |
| A benchmark of 100 C repositories, correctness assessed by test cases, with 15 solved single-shot by the best model (Section 6.5) | Khatry et al. 2025 | Yes | CORRECTED |
| Claude-2 with VERT passed bounded model checking on 42% of 1,394 competitive-programming programs (Section 6.5) | Yang et al. 2024 | No (developer's own evaluation) | CORRECTED |
| GLM-5.3 released 14 August 2026, weights two weeks later; about four months behind the US frontier among released models CAISI evaluated (Section 7.1) | CAISI 2026 | Yes | VERIFIED |
| ExploitBench: 50 of 410 against 56 of 410 (Section 7.1) | Anthropic 2026d | No | VERIFIED |
| Open models' benchmark lag: a 90% interval of five to twenty-two months (Section 7.1) | Cottier et al. 2024 | Yes | CORRECTED |
| Spectre's report and coordinated date (Sections 7.1, 7.2) | Horn 2018; Linton and Parseghian 2018 | No | VERIFIED |
| RAND, in 2024: protecting internet-connected models against the most capable actors "currently not feasible", current applicability unverified; at least one known leak; the equities process (Section 7.3) | Nevo et al. 2024 | Yes | VERIFIED |
| More information raises the danger in one race model; a wide gap may calm the race on one reading (Section 7.4) | Armstrong, Bostrom and Shulman 2013 | NA | VERIFIED; the reading is JUDGMENT |
| Every similarly capable model other than GLM-5.3 released with safeguards or limited access (Section 7.4) | Anthropic 2026d | No | VERIFIED |
| Structured access as the developer's controlled interaction (Section 7.4; Appendix B) | Shevlane 2022 | NA | VERIFIED |
| Abliterated versions of the open-weight model within days (Section 8.3) | Anthropic 2026d | Yes; a competitor's report on another developer's model | VERIFIED |
| Open weights are publicly downloadable trained parameters that permit local operation and modification, subject to the release's terms; that the weights are available does not mean the training materials are (Section 8.3; Appendix B) | Australian Signals Directorate 2026, Purpose and Open-weight models | NA | VERIFIED |
| An open model supplies the weights, all the source code used to train and run it, and enough information about its training data for a skilled person to build a substantially equivalent system, under terms that allow use for any purpose, inspection, modification and redistribution, its components meeting the Open Source AI Definition 1.0; this requires neither every raw training datum nor guaranteed identical reproduction (Section 8.3; Appendix B) | Open Source Initiative 2024 | NA | VERIFIED |
| ASD describes its open-source category as including weights, training data, code and recipes (Section 8.3; Appendix B) | Australian Signals Directorate 2026, Open-source models | NA | CORRECTED |
| ASD reported on 5 November 2026 that genuinely open-source releases remain rare and most “open” models are open-weight only (Section 8.3) | Australian Signals Directorate 2026, Open-source models | NA | VERIFIED |
| US policy frames AI as a race (Section 9) | The White House 2025 | NA | VERIFIED |
| METR's GPT-5 evaluation took three weeks (Section 9) | METR 2025 | Yes | VERIFIED |
| Sunk capital and falling compute prices may push labs to ship (Section 9) | — | NA | JUDGMENT |
| EO 14409 §3: a voluntary framework for access up to thirty days before release (Section 10.2) | Trump 2026 | NA | VERIFIED |
| Measuring the cross-sectional distribution of firms, and firms' payroll against their AI spending, as Imas, Koh and Legg propose (Section 11) | Imas, Koh and Legg 2026, p. 53 | NA | VERIFIED |

**Data note: weakness classes in CISA's catalogue (Sections 6.3 and 11).** DERIVED. These are our calculations, run on 23 October 2026, from the CISA catalogue of known exploited vulnerabilities, version 2026.10.21 (released 21 October 2026; 1,754 entries; dateAdded 3 November 2021 to 20 October 2026). An entry's weaknesses are its `cwes` strings of the form CWE-*n*. Entries with no CWE, or only NVD-CWE-noinfo or NVD-CWE-Other, are excluded. An entry with several weaknesses takes the first matching class in the order memory corruption, injection and input handling, access policy, other. Periods are by dateAdded: through 2023, and from 2024. The class lists are our judgment:
- *Memory corruption* (43 CWEs): 119–127, 131, 134, 170, 190, 191, 401, 415, 416, 457, 466–469, 476, 562, 590, 680, 690, 761–763, 786–788, 805, 806, 822–825, 843, 908, 909, 1284.
- *Injection and input handling* (59 CWEs, including the catch-all CWE-20): 20, 22–24, 35, 36, 59, 61, 73, 74, 77–80, 88–91, 93–98, 113, 116, 117, 138, 140, 141, 150, 158, 159, 172, 176, 177, 179, 180, 184, 434, 436, 444, 470, 502, 564, 601, 611, 641, 643, 652, 776, 829, 913, 915, 917, 918, 1236, 1321, 1336.
- *Authentication, authorization and access policy* (109 CWEs, including the exposure CWEs 200, 201, 209 and 215): 200, 201, 209, 215, 250, 254–257, 259, 260, 264, 266–277, 279–294, 302–309, 312, 313, 319, 345–347, 352, 359, 384, 425, 441, 497, 521–523, 532, 538, 539, 548, 549, 551, 552, 565, 566, 598, 612, 613, 620, 639, 640, 642, 648, 668, 669, 672, 693, 703, 732, 749, 798, 799, 836, 840–842, 862, 863, 912, 922, 923, 939, 940, 1021, 1188, 1220, 1230, 1231, 1233, 1390–1392.
- *Other classified:* any other CWE.

| | 2021–23 | 2024–26 |
|---|---|---|
| Entries | 1,053 | 701 |
| Excluded, no usable CWE | 133 | 42 |
| Usable (the denominator) | 920 | 659 |
| Memory corruption | 299 (32.5%) | 125 (19.0%) |
| Injection and input handling | 368 (40.0%) | 295 (44.8%) |
| Authentication, authorization and access policy | 171 (18.6%) | 180 (27.3%) |
| Other classified | 82 (8.9%) | 59 (9.0%) |

Entries whose weaknesses fall in more than one of the first three classes, resolved by the order above, number 17 and 7. Any other order changes any one class's count by at most those numbers, so its share by at most 17/920 and 7/659, that is, by less than 1.9 and 1.1 percentage points.

*CWE-20.* Excluding the catch-all CWE-20 from the usable denominator, as NVD-CWE-noinfo is, the usable counts are 839 and 648 (214 and 53 excluded). The four classes, memory corruption, injection and input handling, access policy and other, then number 299, 287, 171 and 82 of 839 in 2021–23 and 125, 284, 180 and 59 of 648 in 2024–26; the memory-corruption and access-policy shares are 35.6% and 20.4% in 2021–23 and 19.3% and 27.8% in 2024–26.

*Listing of older flaws.* The feed has no publication date, so we restrict by CVE identifier year. Keeping entries listed in their identifier's year or the next, the usable counts are 454 and 532; memory corruption is 160 (35.2%) and 105 (19.7%), and access policy 90 (19.8%) and 149 (28.0%). Additions numbered 311 in 2021 (from 3 November), 555 in 2022, 187 in 2023, 186 in 2024, 245 in 2025 and 270 in 2026 through 20 October. In 2022, 381 of the 555 additions (68.6%) were CVEs at least three identifier-years old; across 2021–22 the share was 49.7% (430 of 866).

*Yearly shares.* By year of dateAdded, the memory-corruption share of usable entries, with CWE-20 included, was 32.0% (86 of 269) in 2021, 33.1% (161 of 486) in 2022, 31.5% (52 of 165) in 2023, 20.2% (36 of 178) in 2024, 22.3% (49 of 220) in 2025 and 15.3% (40 of 261) in 2026 through 20 October.

*Prediction 3's cut.* With a fixed stationary share *p* = 125/659 and independent entries, the probability that one year's share exceeds a cut is a conditional binomial calculation, not a measured error rate. At the earlier cut of 19.0% it is 51.2%, 50.9% and 49.4% at *n* = 178, 220 and 261 usable entries, and pooling two years leaves it at 49.3% (*n* = 440) and 47.4% (*n* = 522). At 23.0% it is 10.1% at *n* = 178 and between 4.4% and 7.4% at every *n* from 220 to 261. If AI makes old C and C++ code cheap to harvest for flaws, the share could rise with no change in the residual introduction of new flaws; that is a hypothesis.

Two separate implementations give identical counts, and the catalogue's JSON and CSV feeds agree on every entry's dateAdded.
