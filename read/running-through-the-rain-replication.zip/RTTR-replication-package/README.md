# Replication package: Running Through the Rain

This replication package accompanies the paper "Running Through the Rain: Speed, Secrecy and Risk in the AI Cyber Transition" by Allan C. Stam, University of Virginia. It was assembled against version 16 of the manuscript (14 November 2026). The paper and this package are posted at https://updates.tacklebx.com/read/ (running-through-the-rain-technical.pdf and running-through-the-rain-replication.zip). All package paths below are relative to the package root containing `MODEL/`, `M8/`, `lean/` and `supplement/`. Place this README in that root for publication.

It contains:

- five Python scripts that rerun the paper's numerical checks, with each script's saved output for comparison;
- a saved copy of CISA's catalogue of known exploited vulnerabilities that one of those scripts reads;
- the Lean 4 project behind the machine-checked proofs, with the build log and axiom audit recorded when it was last built;
- the paper's supplement.

## Folder map

**Numerical checks of the model (Appendices A and C)**

- `MODEL/code/check_model.py`: checks Appendix A's formulas, parameter cases and counterexamples (paper, Code and data availability). The paper's Section A.6 says it "numerically checks selected formulas, parameter cases and counterexamples". Its header says each output line is a PASS/FAIL check, a REJECTED/MISSED "pre-registered mutation: a deliberately wrong formula that the checks must reject", a REPRODUCED/NOT-REPRO counterexample, an IDENTITY ("NOT counted among the checks of stated results") or a NOTE.
- `MODEL/code/check_model_out.txt`: saved output of `check_model.py`, 203 lines. Its last line is `SUMMARY: 69 checks of stated results, 13 identity confirmations, 31 mutations, 37 counterexamples (+ 4 by construction), 8 notes; 0 problems`.
- `MODEL/code/race_model.py`: "checks the closed forms of Proposition 10's contest (equilibrium and jointly optimal effort, the over-racing and detection thresholds, best responses, a unilateral cap and the bound on large efforts for several win rules) against numerical best-response search, grids and Monte Carlo draws, together with further variants of the contest" (paper, Code and data availability).
- `MODEL/code/race_model_out.txt`: saved output of `race_model.py`, 205 lines, ending `SUMMARY: 0 checks failed`. Its section headings `== P1` to `== P10` follow the script's own numbering, not the paper's propositions (see "Names inside the files" below).
- `MODEL/code/check_benefits.py`: "checks Proposition 16 and Appendix C" (Code and data availability). In Appendix C's words, it "uses only Python's standard library, deterministic grids, direct calendar-time hazard integration and finite differences". Its header adds: "No files are written by the script."
- `MODEL/code/check_benefits_out.txt`: saved output of `check_benefits.py`, 129 lines, every one beginning `PASS`. The last is `PASS SUMMARY all checks | checks_including_summary=129, failed=0`.

**Numerical checks of the extension (Appendix B)**

- `MODEL/EXT/code/check_ext.py`: "checks finite instances of E1–E3 using marked primitive arrivals, direct flaw-level exposure and numerical survival integration. For each result it also confirms that the check fails when the formula it tests is deliberately altered" (Appendix B, Section B.5). It "does not cover E4–E6".
- `MODEL/EXT/code/check_ext_out.txt`: saved output of `check_ext.py`, 7 lines, ending `SUMMARY: 3 of 3 result checks passed; 3 of 3 executed source mutations rejected; 0 problems`.
- `MODEL/EXT/code/mutation_runs/E1.py`: the copy of `check_ext.py` with E1's formula deliberately altered. `check_ext.py` writes this file every time it runs.
- `MODEL/EXT/code/mutation_runs/E1_out.txt`: what `E1.py` printed when `check_ext.py` ran it. It is rewritten on every run.
- `MODEL/EXT/code/mutation_runs/E2.py`: the same, for E2.
- `MODEL/EXT/code/mutation_runs/E2_out.txt`: the same, for E2.
- `MODEL/EXT/code/mutation_runs/E3.py`: the same, for E3.
- `MODEL/EXT/code/mutation_runs/E3_out.txt`: the same, for E3.

**Data calculations (Sections 6.3 and 11, Supplement S2)**

- `M8/kev_v5.py`: "computes the shares, yearly counts and binomial calculations of Sections 6.3 and 11 and Supplement S2 from the saved CISA catalogue, version 2026.10.21" (Code and data availability). Its header says it uses the "Standard library only; no network or random simulation."
- `M8/kev_v5_out.txt`: saved output of `kev_v5.py`, 138 lines. The first line is `Saved source: M8/sources/G4-kev_live.json (no live fetch)` and the last is `PASS: saved-feed metadata, classifications and CSV cross-checks agree`.
- `M8/kev_mix.py`: holds the weakness-class lists that `kev_v5.py` loads. `kev_v5.py` also checks its own classification against this file's, entry by entry. Its standalone interface accepts a snapshot JSON, a comparison JSON and a comparison CSV. The historical snapshot named in its header is not separately included; using the packaged JSON for both JSON arguments runs the calculations but does not establish independent historical-snapshot provenance. It is used here only as a source of class lists.
- `M8/sources/G4-kev_live.json`: saved copy of CISA's catalogue of known exploited vulnerabilities, version 2026.10.21, in JSON (see "Saved data").
- `M8/sources/G4-kev_live.csv`: the same catalogue in CISA's CSV format.

**Lean project (Section A.6)**

- `lean/RTTRProofs/lean-toolchain`: the Lean version, `leanprover/lean4:v4.35.0`.
- `lean/RTTRProofs/lakefile.toml`: the Lake build file. The package is `RTTRProofs`, it requires `mathlib` (scope `leanprover-community`, `rev = "v4.35.0"`), and its default target is the library `RTTRProofs`.
- `lean/RTTRProofs/lake-manifest.json`: pins each dependency to a commit. Mathlib is pinned to `56a005855ea17e0b0958f73ec801ae140b0a1679`, input revision `v4.35.0`.
- `lean/RTTRProofs/.gitignore`: one line, `/.lake`.
- `lean/RTTRProofs/RTTRProofs.lean`: the root module. It imports the fourteen proof modules below and nothing else.
- `lean/RTTRProofs/RTTRProofs/Speed.lean`: "sub-model Speed: Propositions 1, 2, 4, 5" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/Timings.lean`: "the other timings, the level-set hazard, many populations, falling far risk" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/Peak.lean`: "Proposition 3 (the existence of a peak) and A.7's two P3 extensions" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/Hold.lean`: "Sub-model Hold: Propositions 6, 7 and 8" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/Contest.lean`: "sub-model Contest: Propositions 9 and 10" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/Release.lean`: "Proposition 11 (release timing) and its two A.7 extensions" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/Program.lean`: "sub-model Program: Propositions 12–15" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/Benefits.lean`: "P16 — health benefits on a second adoption clock" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/Copies.lean`: "Appendix B: open- and closed-weight copies (Propositions E1, E2, E3)" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/Gaps1.lean`: "loss-index and window readings, Appendix B scope claims, the P8 rebuild remark" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/Gaps2.lean`: "body-only algebra, cited theorems, negative-generality claims" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/Gaps3.lean`: "data arithmetic, the binomial calculation, numeric captions, missing inputs" (header, line 4).
- `lean/RTTRProofs/RTTRProofs/OpenModels.lean`: "Appendix B, the enlarged event system: Propositions E4, E5 (with its corollary) and E6, and E1's thinning step" (header, lines 4–5).
- `lean/RTTRProofs/RTTRProofs/Gaps4.lean`: "the items Paper v14's status table still marks "not machine-checked"" (header, line 10). The header was written against version 14 of the manuscript; Section A.6 of version 16 gives each item's present status.
- `lean/RTTRProofs/RTTRProofs/AuditAll.lean`: the whole-project axiom audit (see "Lean project"). The root module does not import it, so `lake build` does not run it.
- `lean/RTTRProofs/RTTRProofs/Smoke.lean`: a one-theorem toolchain smoke test. The root module's own comment says it "is left out", so the build does not include it.
- `lean/build-record/RTTR-lake-build.txt`: the recorded output of `lake build`, 2,474 lines, ending `Build completed successfully (9062 jobs).` and `exit 0`.
- `lean/build-record/RTTR-auditall.txt`: the recorded audit result, two lines: `AUDIT 1908 theorems, 0 outside the standard three` and `exit 0`.

**Supplement**

- `supplement/SUPPLEMENT-v9.md`: the paper's supplement. S1 lists the versions of sources read. S2 is the source audit and the data note behind the CISA calculations.

The lake project therefore has seventeen `.lean` files: the root module, the fourteen proof modules it imports, `AuditAll.lean` and `Smoke.lean`.

## Requirements

- **Python 3 and its standard library only.** Every `import` in the nine `.py` files (the five scripts, `kev_mix.py` and the three mutation copies) names a standard-library module: `argparse`, `collections`, `csv`, `dataclasses`, `fractions`, `itertools`, `json`, `math`, `pathlib`, `random`, `re`, `runpy`, `subprocess`, `sys`. Nothing is installed and nothing is fetched from the network.
- **Tested versions:** Python 3.14.5 (macOS), on 14 November 2026; an earlier assembly of this package was tested with Python 3.14.3, on 11 November 2026. No minimum version has been established. Other Python 3 versions have not been tested.
- **Random seeds.** The seeds are fixed in the code:
  - `check_model.py` uses seed 20261022. The paper states this in Section A.6: "The code uses one random-number generator with seed 20261022, so each random draw depends on the draws before it."
  - `race_model.py` defaults to seed 20261021. It accepts `--seed N`, but the saved output was made with the default (its first line is `race_model.py  seed=20261021`).
  - `check_ext.py` uses seed 20261022, and 20261023 for its second check (`SEED + 1`).
  - `check_benefits.py` and `kev_v5.py` draw no random numbers.
- **Lean (only for the proofs):** `elan` installs the toolchain named in `lean-toolchain`. Fetching Mathlib's prebuilt cache needs network access. A disk and time budget has not been measured for this package.

## Running the numerical checks

Run everything in a working copy, not in the folder you downloaded. `check_ext.py` rewrites the six files in `MODEL/EXT/code/mutation_runs/` every time it runs, and a careless redirect can overwrite a saved output. Run in a new disposable copy. The setup below preserves the saved mutation files in `fresh/saved-mutation_runs/` before `check_ext.py` generates new files. Fresh standard output and exit statuses go to `fresh/`; each fresh output is compared byte for byte with its saved reference.

Below, set `package` to the folder you downloaded and unpacked: the one holding `MODEL/`, `M8/`, `lean/` and `supplement/`.

```sh
package='/absolute/path/to/unpacked-package'
run_parent=$(mktemp -d) || exit 1
cp -R "$package" "$run_parent/package" || exit 1
cd "$run_parent/package" || exit 1      # the working directory for every command below
mkdir fresh || exit 1
mv MODEL/EXT/code/mutation_runs fresh/saved-mutation_runs || exit 1

# 1. Appendix A: formulas, parameter cases, counterexamples
python3 -I MODEL/code/check_model.py > fresh/check_model.txt; echo $? > fresh/check_model.exit
cmp fresh/check_model.txt MODEL/code/check_model_out.txt && cat fresh/check_model.exit

# 2. Proposition 10's contest
python3 -I MODEL/code/race_model.py > fresh/race_model.txt; echo $? > fresh/race_model.exit
cmp fresh/race_model.txt MODEL/code/race_model_out.txt && cat fresh/race_model.exit

# 3. Proposition 16 and Appendix C
python3 -I MODEL/code/check_benefits.py > fresh/check_benefits.txt; echo $? > fresh/check_benefits.exit
cmp fresh/check_benefits.txt MODEL/code/check_benefits_out.txt && cat fresh/check_benefits.exit

# 4. Appendix B, E1-E3 (rewrites MODEL/EXT/code/mutation_runs/ in this copy)
python3 -I MODEL/EXT/code/check_ext.py > fresh/check_ext.txt; echo $? > fresh/check_ext.exit
cmp fresh/check_ext.txt MODEL/EXT/code/check_ext_out.txt && cat fresh/check_ext.exit
diff -r fresh/saved-mutation_runs MODEL/EXT/code/mutation_runs && echo "mutation files unchanged"

# 5. CISA catalogue: shares, yearly counts, binomial calculations
python3 -I M8/kev_v5.py > fresh/kev_v5.txt; echo $? > fresh/kev_v5.exit
cmp fresh/kev_v5.txt M8/kev_v5_out.txt && cat fresh/kev_v5.exit
```

A successful run looks like this:

- each `cmp` prints nothing, so the fresh output is byte-identical to the saved output;
- each exit file holds `0`;
- the `diff -r` prints nothing.

`-I` runs Python in isolated mode, which ignores environment variables and the user's site-packages. `check_ext.py` runs its three mutated copies the same way.

What a nonzero exit means:

- `check_model.py` exits nonzero unless every check passes, every identity holds, every mutation is rejected and every counterexample reproduces (its header).
- `race_model.py` exits 1 on any FAIL.
- `check_benefits.py` exits 1 if any check fails.
- `check_ext.py` exits 1 if any result check fails, or if any mutation is not rejected.
- `kev_v5.py` stops with an error if any of its internal cross-checks disagree.

The run lines printed in some scripts' own headers redirect into the saved output file. For example, `kev_v5.py`'s header gives `python3 -I M8/kev_v5.py > M8/kev_v5_out.txt`. Do not use those lines in a copy you mean to compare. The `--out FILE` option of `check_model.py`, `race_model.py` and `check_ext.py` also writes to FILE, so do not point it at a saved output.

**Record from assembly.** On 14 November 2026, the five scripts were run as above from clean copies of this package with Python 3.14.5. Every fresh output was byte-identical to the saved output, and every exit status was 0. The mutation files that `check_ext.py` rewrote were byte-identical to the packaged ones, and no other file changed.

## Saved data

`M8/sources/G4-kev_live.json` and `M8/sources/G4-kev_live.csv` are saved copies of CISA's "CISA Catalog of Known Exploited Vulnerabilities". They are not live data, and no script downloads anything.

- The JSON file's own header gives `catalogVersion` 2026.10.21, `dateReleased` 2026-10-21T14:04:39.8983Z and `count` 1754.
- The paper's reference list gives the JSON feed's address as `https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json`. The paper and supplement do not give the CSV feed's address.
- The supplement (S1) says both feeds were "fetched 23 October 2026 (1,754 entries; dateAdded 3 November 2021 to 20 October 2026)".
- The CISA feed changes as entries are added. A fresh download will not match these files. Rerunning the paper's figures needs this saved copy.

`kev_v5.py` cross-checks the two files against each other. Its output reports `CSV cross-check: rows=1754, dateAdded disagreements=0, numeric-CWE disagreements=0`.

The weakness classes are the authors' own. The supplement says "The class lists are our judgment" (S2, data note), and that the binomial figures are "a conditional binomial calculation, not a measured error rate".

## The Lean project

**Toolchain.** `leanprover/lean4:v4.35.0` (from `lean-toolchain`), with Mathlib at `rev = "v4.35.0"` (from `lakefile.toml`). `lake-manifest.json` pins Mathlib to commit `56a005855ea17e0b0958f73ec801ae140b0a1679`.

**Modules.** The proofs are in fourteen modules, all imported by the root module `RTTRProofs.lean`:

- `Speed`, `Timings`, `Peak`, `Hold`, `Contest`, `Release`, `Program` and `Benefits`;
- `Copies`, `Gaps1`, `Gaps2` and `Gaps3`;
- `OpenModels` and `Gaps4`, added on 13 November 2026 (the root module's comment says "OpenModels and Gaps4 added for v15, 13 November 2026").

`AuditAll.lean` and `Smoke.lean` are not among the fourteen.

Counting declarations introduced by `theorem` or `lemma` in the fourteen modules, with comments removed, gives 1,508. That matches the paper's "fourteen modules with 1,508 theorems". By module the counts are: Speed 118, Timings 63, Peak 160, Hold 115, Contest 108, Release 141, Program 90, Benefits 242, Copies 77, Gaps1 46, Gaps2 97, Gaps3 64, OpenModels 107 and Gaps4 80. `Smoke.lean`'s one theorem is not counted, because the root module does not import it. No `sorry`, `admit` or `axiom` declaration appears in any of the seventeen `.lean` files.

**Building.** From the package root:

```sh
cd lean/RTTRProofs
lake exe cache get      # download Mathlib's prebuilt files for the pinned commit
lake build              # builds the root module and the fourteen modules it imports
```

The recorded build is `lean/build-record/RTTR-lake-build.txt`. It lists the root and the fourteen modules as built, and ends `Build completed successfully (9062 jobs).` and `exit 0`. It also contains warnings and information lines, which are expected:

- linter warnings, for example "This line exceeds the 100 character limit" and "Copyright too short!";
- a notice that Mathlib "is designed for use with the module system";
- 1,463 lines of the form `'<theorem>' depends on axioms: [propext, Classical.choice, Quot.sound]`, printed by the `#print axioms` commands in the modules. None lists any other axiom. One further line, for `RTTR.Gaps3.b90_order_bound`, says it "does not depend on any axioms".

**Running the axiom audit.** `lake build` does not run the audit. Run it as a separate command after a successful build, from the same folder `lean/RTTRProofs/`:

```sh
lake env lean RTTRProofs/AuditAll.lean
```

`AuditAll.lean` checks every non-internal theorem declared in a module under `RTTRProofs` with `Lean.collectAxioms`. It reports through Lean's information messages:

- one summary line, `AUDIT <n> theorems, <k> outside the standard three`;
- then one `OFFENDING <theorem>: <axioms>` line for each theorem that depends on anything other than `propext`, `Classical.choice` and `Quot.sound`. Its header says "`sorryAx` or any added axiom counts as offending".

The audit's exit status can be zero even when it reports offending theorems. Exit status zero alone is therefore not enough. Reproduction requires all of the following:

- the build succeeds;
- the audit command succeeds;
- its output contains the summary `AUDIT 1908 theorems, 0 outside the standard three`;
- its output contains no `OFFENDING` line.

A different theorem count needs investigating.

The audit's count is larger than the 1,508 above because it counts theorem constants in the compiled project, not `theorem` and `lemma` keywords. The 1,908 are the 1,508 declared theorems and 400 further constants that those keywords do not introduce, most of them generated by Lean (306 are equation lemmas with names ending `eq_1`, `eq_2` and so on).

**What the paper says the build and audit show** (Section A.6):

> A full `lake build` of the project completes. A whole-project audit runs `Lean.collectAxioms` over every theorem constant the project declares, other than names Lean marks internal: 1,908 constants, including some the compiler generates. It finds no dependence on any axiom beyond Lean's standard three, `propext`, `Classical.choice` and `Quot.sound`, and none of the fourteen modules contains `sorry`.

**When the record was made.** The two record files were made on 14 November 2026, on macOS 27.0.1 (Apple silicon), with Lean 4.35.0 and Lake 5.0.0-src+eb6cafb. This package's `lean/` folder was copied to an empty directory and the three commands above were run there in order: `lake exe cache get`, `lake build`, then the audit. Each record file is the complete output of its command, followed by a line giving the command's exit status.

The sources built were byte-for-byte the sources in this package. Their SHA-256 checksums were taken before the build and again after it; the two lists were identical, and they match `FILES.md`. Lake did not rewrite `lake-manifest.json`. Mathlib's prebuilt proof-library files for the pinned commit were used. The cache command compiled Cache modules, Batteries.Tactic.OpenPrivate and the cache executable; the subsequent lake build compiled the root module and the fourteen proof modules from source. Neither record file contains a date or a list of checksums; this paragraph is the record of both.

## What this package does not cover

- **E4 to E6 in the numerical checks.** No script checks E4–E6 numerically. Appendix B, Section B.5, says of `check_ext.py`: "The script does not cover E4–E6." Their proofs are in the Lean module `OpenModels`; B.5 says: "E4–E6, including the corollary to E5, are machine-checked from the first-arrival law of the marked streams and, for E6, B-S9's law of each added wait and terminal dates of positively weighted terms finite on every path; E4's invariance of exposure is checked on paths where the attacker-access window is finite (Section A.6)."
- **Parts the paper marks "not machine-checked".** Section A.6's table marks parts of some results "not machine-checked"; the table below quotes every status. One example is the thinning and marking of the event streams. B.5 says: "the thinning, splitting and marking that yield them are standard and are not machine-checked." The header of `OpenModels.lean` says: "**Not proved**: the thinning theorem itself".
- **Formal statements and the paper's claims.** Section A.6 says: "Lean checks that the proofs prove the formal statements, not that the statements are the paper's claims, which is why each result was read against its statement in a separate review." That separate review is not part of this package.
- **Steps taken as hypotheses.** Section A.6 says: "Four kinds of step are taken as hypotheses rather than derived: the comparative statics of Proposition 11 and Section A.7 assume a differentiable selection of crossings, which the text obtains from the implicit function theorem; E1–E3 start from the first-arrival law of the event streams; E4–E6 start from the first-arrival law of the seven marked streams of Section B.2.3 and, in E6, from B-S9's law of each added wait and that wait's independence from its own term's cutoff *g_fji*; and the readings of *R_c* in Section A.2.2 start from a Poisson law for each period's count."
- **Numerical results.** Section A.6 says: "Results that are computed rather than proved are labelled numerical." The table below lists them.
- **Empirical premises.** The numerical checks do not test them:
  - Appendix B: "These numerical checks supplement the proofs; they do not validate the event or policy premises empirically."
  - Appendix C: "The parameter values are illustrative, never estimates; the checks supplement the proofs and do not test the model's empirical premises."
  - `check_ext.py`'s header: "PASS checks numerical instances, not empirical premises."
- **The CISA figures** are calculations on one saved version of the catalogue, under class lists the authors chose (see "Saved data").

## Results and where each is checked

The rows follow the status table of Section A.6. The second column quotes the paper's status in Lean, unchanged. The Lean column names the module and one declaration, or the header line that places the result there. The script column names the script and the output section or line that carries the check. "Not determined from the files" means the module headers, declarations and output headings do not settle the question.

Lean line numbers refer to the files in this package. Script line numbers refer to the saved `_out.txt` files.

| Result | Status in Lean (Section A.6, verbatim) | Lean module (evidence) | Numerical script (evidence) |
|---|---|---|---|
| P1 | Proved as stated; Section 4.3's restatement: corrected (*H′ > 0* in place of "rising") | `Speed` (`p1_deriv_below_kink`, Speed.lean:112) | `check_model.py`, section `== P1` (check_model_out.txt:8) |
| P2 | Proved as stated; speed dependence through attackers' tools: proved under the stated condition | `Speed` (`p2_indep_of_speed`, Speed.lean:945) | `check_model.py`, section `== P2` (line 24) |
| P3 | (i)–(iii): proved as stated; Section 4.5's restatement of (ii): proved under the stated condition (differentiable introduction) | `Peak` (`p3i_witnesses_of_risesFalls`, Peak.lean:167) | `check_model.py`: `check_model_out.txt:31` and `:37` check P3(iii); `:38` checks P3(ii). Original counterexamples appear at `:34–36` and `:39`. There is no separately labelled numerical check of general P3(i). |
| P3, counterexamples to the original | Proved as stated or under the stated condition (an empty stock); the finite example's "no plateau": corrected to "no positive plateau"; the *e^t* example's peak date and fall: numerical | `Peak` (`origF_no_positive_plateau`, Peak.lean:1535; `p3_orig_first_half_false_finite`, :1553; `p3_orig_first_half_false_unbounded`, :1689; `p3_orig_unbounded_peak_falls_to_zero`, :1704; `p3_orig_second_half_false`, :1747; `origC_no_peak`, :1864). The exponential example's numerical peak date and amount of decline remain numerical. | `check_model.py`, `check_model_out.txt:34–36` and `:39`; the exponential example's numerical peak date and decline are at `:34`. |
| P3, what follows a peak | Section 6.3's sentence and its repetition in Section 12, as limited to a declining stock: proved as stated | `Peak` (`line276_second_rise`, Peak.lean:1206; `line276_no_residue_falls`, :1233; `line276_second_rise_no_residue`, :1293). These are explicit constructions, not a characterization over every intensity path. | — |
| P4 | (i), (iii), (iv) and the discrete counterexample: proved as stated; (ii): proved under the stated condition (*r > 0*, *g ≥ 0*, positive step losses) | `Speed` (`p4_i`, Speed.lean:1454) | `check_model.py`, section `== P4` (line 41) |
| P5 | Proved as stated; the counterexample to the original: proved under the stated condition (*β < 1*) | `Speed` (`p5_adopt_iff`, Speed.lean:1065) | `check_model.py`, section `== P5` (line 51) |
| P6 | (i), (ii), (iv), (v): proved as stated; (iii), its first-stated limit and Section 7.1's fast-patcher claim: proved under the stated condition (*π < 1*; an exponential window) | `Hold` (`p6_pathwise_saving`, Hold.lean:80) | `check_model.py`, section `== P6` (line 59) |
| P7 | (a)–(c): proved as stated; the shortening lag and the patch-producing tool: proved under the stated condition; the 100-flaw example: proved to one decimal, its six-decimal and Monte Carlo values numerical | `Hold` (`p7a_no_gain`, Hold.lean:450; section "The 100-flaw example", Hold.lean:614) | `check_model.py`, section `== P7` (line 77); the 100-flaw numbers are in A.6's numerical table |
| P8 | (ii)–(iv): proved as stated; (i), *m_λ < 0* and the corner and rival examples: proved under the stated condition; the interior example's *n\* = 1.59* and single sign change of *B′*: numerical | `Hold` (`p8i_deriv`, Hold.lean:829) | `check_model.py`, section `== P8` (line 89); the interior coalition is in A.6's numerical table |
| P9 | (i)–(ii): proved as stated; (iii)'s harm threshold, the convex-hazard and escalation examples, and Section 7.4's "raises": proved under the stated condition | `Contest` (`p9_i_nash_iff`, Contest.lean:189) | `check_model.py`, section `== P9` (line 101) |
| P10 | (i)–(iii): proved under the stated condition (*k > 0*; *L, θ ≥ 0*), the sufficiency half of (iii) against every pure strategy of the repeated game, with detection publicly observed; (iv): proved as stated | `Contest` (`p10_i_equilibrium`, Contest.lean:815). The sufficiency half of (iii): `Gaps4` (`p10_iii_full_sufficiency`, Gaps4.lean:325; header, Gaps4.lean:16: "the one-shot deviation principle, proved"). `Contest`'s own header, written before `Gaps4`, still says "**Not formalised:** the one-shot deviation principle" (Contest.lean:45). | `check_model.py`, section `== P10` (line 116); `race_model.py`, whole output (Code and data availability; proof of P10 in A.6) |
| P11 (i)–(iv) | (i), (ii), (iv): proved as stated, the set-up's equation for *Π* under the stated condition; the jump-point clause of (i): proved under the stated condition (interior dates; a rent bounded and measurable on *[0, g₀ + Δ]* whose only discontinuities are its jump points; an eroding public model when *κ_post > 0*; when *κ_post = 0*, a rent differentiable away from its jump points), as is its example; the continuity of *V*, the jump of *J* and the kink conditions in its proof: not machine-checked; (iii): proved as stated, "the optimum is a corner" under the stated condition (*λ > 0*, an eroding public model) | `Release` (`p11i_V_hasDerivAt`, Release.lean:126); the jump-point clause: `Gaps4` (`p11i_jump_candidates`, Gaps4.lean:611; `p11i_jump_candidates_kpost0`, :639); its example: `Gaps2` (header, Gaps2.lean:21; `p33_jump_kink_optimum`, Gaps2.lean:1160) and `Gaps4` (`p11i_jump_example`, Gaps4.lean:705) | `check_model.py`, section `== P11` (line 125) |
| P11 (v) and the sign of *κ* | Proved under the stated condition (a simple downward crossing; the implicit-function step taken as a hypothesis), as are the opposing channels for linear and power rents and both signs of the net effect; post-release copying for general rents: proved under the stated condition (*κ_post > 0*, an eroding public model, a strictly increasing rent continuous on *[0, g₀ + Δ]* and differentiable inside it, the implicit-function step taken as a hypothesis); the saturating reversal: proved under the stated condition (the implicit-function step taken as a hypothesis); the proof's printed formula for *∂Π′/∂κ_post* and its sign: not machine-checked (the machine-checked proof reaches the sign of *∂Φ̃/∂κ_post* through a different expression for that derivative, which it does not state as a theorem); a strict inequality in the proof: corrected (*≤ 0*); scan frequencies: numerical | `Release` (header, Release.lean:6–7, "the sign of κ"); the identity for *∂Φ̃/∂κ_pre* and the counterexample to its strict sign: `Gaps2` (header, Gaps2.lean:13–14); post-release copying for general rents: `Gaps4` (`p11v_kpost_later_general`, Gaps4.lean:1185); the saturating reversal: `Gaps4` (`p11v_saturating_reversal`, Gaps4.lean:1526) | `check_model.py`, section `== P11` (line 125); the 56-case grid and random scan are in A.6's numerical table |
| P11, as first stated, and Section 1's restatement | The constant-flow counterexample: proved as stated; the +86, −45.5 and +122 examples: numerical; Section 1's restatement: corrected (a simple crossing) | `Release` (header, Release.lean:6–7, "as first stated") | `check_model.py`, section `== P11` (line 125); the +86 and artifact examples are in A.6's numerical table |
| P12 | Proved as stated | `Program` (`p12_eroding_value`, Program.lean:167) | `check_model.py`, section `== P12` (line 162) |
| P13 | Proved as stated; the plain-terms gloss: proved under the stated condition; the first-stated corollaries: proved not to follow from the model, as the text states; P11's interior example: numerical (an exact instance of the same effect is proved) | `Program` (`p13_general`, Program.lean:314) | `check_model.py`, section `== P13` (line 168) |
| P14 | Proved as stated; the cap's premises: proved under the stated condition; the bought-security grid value: numerical | `Program` (`p14Value_eq`, Program.lean:688) | `check_model.py`, section `== P14` (line 179) |
| P15 | Proved as stated; the plain-terms gloss and the counterexamples: proved under the stated condition | `Program` (`p15_value`, Program.lean:1038) | `check_model.py`, section `== P15` (line 191) |
| P16 | (i), (ii): proved as stated; (iii), Appendix C's candidate set, the level-set timing clause, Section 4.7's range claim and (C3)'s illustrative case: proved under the stated condition; check-script values: numerical | `Benefits` (`p16_BL_hasDerivAt`, Benefits.lean:225) | `check_benefits.py`, all 129 lines (Appendix C, "Numerical checks") |
| E1 | The window table and orderings: proved as stated; the exponential laws and means: proved under the stated condition (the first-arrival law); the first arrival of a merged group of streams (exponential at the summed rate, the groups' first arrivals independent) and the competing-exponentials law (for a positive closed-release rate): proved from independent exponential first arrivals; thinning and marking of the streams: not machine-checked | `Copies` (`e1_lambdaC_pos`, Copies.lean:276; header, Copies.lean:14–22, on the first-arrival premise); the merged-group and competing-exponentials laws: `OpenModels` (`e1t_group`, OpenModels.lean:118; `e1t_race_joint`, :314); thinning: "**Not proved**" (header, OpenModels.lean:34) | `check_ext.py`, check_ext_out.txt:1 (`PASS E1`) and :4 (`REJECTED E1 mutation`) |
| E2 | Proved under the stated condition (finite sets of flaw–operator pairs; finite expected exposure at *W = 0*); Section 12's summary, as limited to outsiders' exposure: proved under the stated conditions; B-S2's statement that optimized responses have no general direction: not machine-checked | `Copies` (`e2_Wcl_eq`, Copies.lean:454). On B-S2's statement, `Gaps4` has two instances with opposite signs (header, Gaps4.lean:89; `bs2_instance_raises`, :1731; `bs2_instance_lowers`, :1764); the paper's status for the statement remains "not machine-checked". | `check_ext.py`, check_ext_out.txt:2 and :5 |
| E3 | The rate identity and pathwise chain: proved as stated; the reach limit: proved under the stated condition (the first-arrival law) | `Copies` (`e3_closed_split`, Copies.lean:1200) | `check_ext.py`, check_ext_out.txt:3 and :6 |
| E4 | The pathwise invariance of the windows under relabelling, the two permissive releases and the *η_f = 0* clause: proved as stated; the invariance of exposure: proved on paths where the attacker-access window is finite; the window laws: proved under the stated condition (the first-arrival law of the marked streams) | `OpenModels` (section "3. Proposition E4", OpenModels.lean:706; `e4_relabel`, :769; `e4_window_law`, :879) | None: "The script does not cover E4–E6" (B.5) |
| E5, including its corollary | Proved under the stated condition (the first-arrival law of the marked streams); the corollary's windows and exposure equalities: proved as stated | `OpenModels` (section "4. Proposition E5 and its corollary", OpenModels.lean:949; `e5_laws`, :1022; `e5c_windows`, :1206) | None: as for E4 |
| E6 | Proved under the stated condition (terminal dates of positively weighted terms finite on every path; *ω_full > 0* almost surely from the first-arrival law); the difference identity and the conditional law of the added wait: proved as stated | `OpenModels` (section "5. Proposition E6", OpenModels.lean:1268; `e6_strict_iff`, :1470; `e6_conditional_wait`, :1786) | None: as for E4 |
| B.2.3, what survives of E1–E3, and B.4 | E1's laws and ordering, the holding-order equivalence and the restricted-release violation: proved under the stated condition (the first-arrival law of the marked streams); E2's decomposition, *S_H ≥ 0* and improvement threshold: proved for any measurable exposure function that does not rise as the window lengthens, with an attacker-access window finite almost surely; their application to the defined *X*, E2's unchanged-schedule clauses and E2 for *X̃(Σ, W, ω_full)* in the enlarged system: not machine-checked; E3's bound through *1/λ_A*: proved under the stated condition (the first-arrival law; *λ_A > 0*); the recovery identities (*X̃ = X* when every *η_f = 0*; *ω_A^R = ω_A* when *λ_R = 0*): proved under the stated condition (the first-arrival law); that the event laws, windows and exposure accounting are then exactly those of Sections B.2.1 and B.2.2, E3's chain through *ω_A^out*, the *λ_R^out* tightening, recovery by reclassification and Section B.4's remarks: not machine-checked | `OpenModels` (section "2. The enlarged event system of Section B.2.3", OpenModels.lean:518; `b23_e1_survives`, :1246; `b23_e3_survives`, :1255; `b23_e2_survives`, :1932; `b23_recovery_lR_zero`, :1986). Which declaration carries which clause is not determined here. | — |

**A.6's numerical table.** Section A.6 has a second table of inputs and printed outputs. Its rows are P7's 100-flaw example, P8's interior coalition, P9's convex hazard, and P11's +86 example, 56-case grid, random scan, interior example and artifact example. It also covers P13, P12's separate contests, and P14's sublinear theft and bought security. The paper attributes all of these values to `check_model.py` ("The table gives the inputs behind the numbers quoted in the text, as the code sets them, and the outputs as the code prints them"). P11's grid and random-scan frequencies apply only to the sampled ranges and selection rules; they are not a property of the model.

**Section A.7 rows** (from the same status table):

- sequential timing, mixed timing, level-set hazard, populations, and falling far risk: `Timings` (header, Timings.lean:4–7);
- capped introduction and non-empty stock: `Peak` ("A.7's two P3 extensions", Peak.lean:4);
- loss hazard rising with copy speed, and research surviving release: `Release` ("its two A.7 extensions", Release.lean:4; declarations from `a7_kpost_hazard_partial`, Release.lean:1804).

Which declaration in each module carries which of these rows is not determined here. Section A.2.2's readings of *R_c* are in `Gaps1` ("loss-index and window readings", Gaps1.lean:4).

## Names inside the files

These do not affect any output, but a reader may otherwise be puzzled by them.

- **Line numbers in the Lean headers.** The headers of the twelve earlier modules cite line numbers in version 8 of the paper (ten name the file `PAPER-DRAFT-v8.md`; `Hold` and `Benefits` say "v8"), and the headers of `OpenModels` and `Gaps4` cite line numbers in `PAPER-DRAFT-v14.md`. Both are earlier drafts of the paper. The headers also cite working files that are not in this package (for example `LEAN/INV-RTTR.md`, `LEAN/COMMON-LEAN.md`, `LEAN/V15/BRIEF-GAPS4.md`) and seat labels used while the proofs were written. Those line numbers do not match the paper as posted. The root module's comment says "(v8; OpenModels and Gaps4 added for v15, 13 November 2026)".
- **Script headers.** These name working notes that are not included: `MODEL-SECTION.md` in `check_model.py`, `RACE-NOTE/MODEL.md` in `race_model.py`, `BEN-MATH.md` in `check_benefits.py` and `EXT-SECTION` in `check_ext.py`. `check_model.py`'s header speaks of "the fifteen propositions". Proposition 16 is checked by `check_benefits.py`.
- **`race_model.py` numbering.** Its sections `== P1` to `== P10` follow the numbering of its own note, not the paper's propositions. The paper uses the script for Proposition 10's contest.
- **`kev_mix.py` header.** It describes a reproduction on an earlier snapshot file (`RACE-NOTE/codecrux/data/kev_2026.10.21.json`) that is not in the package. `kev_v5.py` uses only the class lists and the classification rule from it.
- **Supplement header.** The supplement's first paragraph says it was prepared for draft v6 on 25 October 2026, that its head forms were checked against draft v14 on 11 November 2026, that version 16 rewrote Sections 1 to 12 at about half their length so that the claims audited are those of the main text as it stood through version 15, and that the cited passages of four works added later were read and checked in November 2026.

## Licence

The code (the Python scripts and the Lean project) is released under the MIT License; see `LICENSE`. The other material written for this package (this README, the supplement, the saved outputs and the build record) is released under the Creative Commons Attribution 4.0 International licence (CC BY 4.0); see `LICENSE-CC-BY-4.0.txt`. The files in `M8/sources/` are a saved copy of a catalogue published by the U.S. Cybersecurity and Infrastructure Security Agency; they are CISA's work, not the author's, and these licences make no claim over them.

See `FILES.md` for every file's size and SHA-256.
