#!/usr/bin/env python3
"""Reproduce the v5 KEV quantities from the saved 2026.10.21 catalogue.

Standard library only; no network or random simulation. Run from any directory:
    python3 -I M8/kev_v5.py > M8/kev_v5_out.txt

Class lists come from the saved kev_mix.py; classification is independently
implemented here and checked entry by entry against that script. Periods and
years use dateAdded. Identifier age is added year minus the CVE identifier year,
not time since publication (the feed supplies no publication-date field).
Binomial probabilities condition on fixed p=125/659 and independent entries;
rejection means X/n strictly exceeds the stated cut.
"""

import collections
import csv
from fractions import Fraction
import itertools
import json
import math
from pathlib import Path
import re
import runpy


HERE = Path(__file__).resolve().parent
SAVED = runpy.run_path(str(HERE / 'kev_mix.py'))
GROUPS = {k: SAVED[name] for k, name in zip('abc', ('A', 'B', 'C'))}
NAMES = SAVED['NAMES']


def cwe_ids(entry, exclude20=False):
    ids = {int(c[4:]) for c in entry.get('cwes', [])
           if re.fullmatch(r'CWE-[0-9]+', c)}
    return ids - {20} if exclude20 else ids


def hits(entry):
    ids = cwe_ids(entry)
    return {k for k, group in GROUPS.items() if ids & group}


def classify(entry, exclude20=False, order='abc'):
    ids = cwe_ids(entry, exclude20)
    if not ids:
        return 'e'
    return next((k for k in order if ids & GROUPS[k]), 'd')


def tally(entries, exclude20=False, order='abc'):
    return collections.Counter(classify(e, exclude20, order) for e in entries)


def show_mix(entries, label, exclude20=False):
    counts = tally(entries, exclude20)
    usable = sum(counts[k] for k in 'abcd')
    print(f'{label}: entries={len(entries)}, usable={usable}, excluded={counts["e"]}')
    for k in 'abcd':
        print(f'  {k} {NAMES[k]}: {counts[k]}/{usable} = {100 * counts[k] / usable:.6f}%'
              f' ({100 * counts[k] / usable:.1f}%)')
    return counts, usable


def identifier_age(entry):
    return int(entry['dateAdded'][:4]) - int(entry['cveID'].split('-')[1])


def rejection(n, cut, p=Fraction(125, 659)):
    """P[X/n > cut], using an exact rational cut and a direct positive tail sum.

    The threshold is exact even where n*cut is integral. Integer combinations
    and positive terms avoid cancellation in 1-CDF; only probabilities round.
    """
    first = (n * cut.numerator) // cut.denominator + 1
    prob = float(p)
    tail = math.fsum(math.comb(n, k) * prob ** k * (1 - prob) ** (n - k)
                     for k in range(first, n + 1))
    return first, tail


def main():
    json_path = HERE / 'sources/G4-kev_live.json'
    csv_path = HERE / 'sources/G4-kev_live.csv'
    data = json.loads(json_path.read_text(encoding='utf-8'))
    entries = data['vulnerabilities']
    assert len(entries) == data['count']
    by_id = {e['cveID']: e for e in entries}
    assert len(by_id) == len(entries)
    print('Saved source: M8/sources/G4-kev_live.json (no live fetch)')
    print(f'catalogVersion={data["catalogVersion"]}; dateReleased={data["dateReleased"]}; entries={len(entries)}')
    print(f'dateAdded={min(e["dateAdded"] for e in entries)}..{max(e["dateAdded"] for e in entries)}')
    print('Class lists: M8/kev_mix.py; order a>b>c; a=memory, b=injection/input, c=access, d=other, e=excluded')
    print('Class-list sizes: ' + ', '.join(f'{k}={len(GROUPS[k])}' for k in 'abc'))
    for exclude20 in (False, True):
        disagreements = sum(classify(e, exclude20) != SAVED['classify'](e.get('cwes'), not exclude20)
                            for e in entries)
        assert disagreements == 0
        print(f'Entry classification disagreements vs saved script, exclude_CWE20={exclude20}: {disagreements}')
    with csv_path.open(encoding='utf-8', newline='') as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == len(entries) and {r['cveID'] for r in rows} == set(by_id)
    dates_bad = sum(r['dateAdded'] != by_id[r['cveID']]['dateAdded'] for r in rows)
    cwes_bad = sum(set(re.findall(r'CWE-[0-9]+', r['cwes'])) !=
                   {f'CWE-{i}' for i in cwe_ids(by_id[r['cveID']])} for r in rows)
    assert dates_bad == cwes_bad == 0
    print(f'CSV cross-check: rows={len(rows)}, dateAdded disagreements={dates_bad}, numeric-CWE disagreements={cwes_bad}')

    periods = [('2021-23', [e for e in entries if e['dateAdded'][:4] <= '2023']),
               ('2024-26', [e for e in entries if e['dateAdded'][:4] >= '2024'])]
    print('\nPERIOD COUNTS AND FOUR NUMERATORS (CWE-20 included, then excluded)')
    for exclude20 in (False, True):
        print(f'CWE-20 {"excluded from usable IDs" if exclude20 else "included"}')
        for label, sub in periods:
            show_mix(sub, label, exclude20)

    print('\nYEARLY ADDITIONS, USABLE COUNTS AND MEMORY SHARES (CWE-20 included)')
    for year in sorted({e['dateAdded'][:4] for e in entries}):
        sub = [e for e in entries if e['dateAdded'][:4] == year]
        counts = tally(sub)
        usable = sum(counts[k] for k in 'abcd')
        through = f'; through {max(e["dateAdded"] for e in sub)}' if year == '2026' else ''
        print(f'{year}: additions={len(sub)}, usable={usable}, excluded={counts["e"]}; '
              f'memory={counts["a"]}/{usable} = {100 * counts["a"] / usable:.6f}%'
              f' ({100 * counts["a"] / usable:.1f}%){through}')

    print('\nCONDITIONAL BINOMIAL REJECTION PROBABILITIES')
    print('Fixed stationary p=125/659; independent entries; reject iff X/n > cut; these are not measured error rates')
    for cut in (Fraction(19, 100), Fraction(223, 1000), Fraction(23, 100)):
        for n in (178, 220, 261):
            first, prob = rejection(n, cut)
            print(f'cut={100 * float(cut):.1f}%, n={n}, reject X>={first}: '
                  f'probability={prob:.9f} ({100 * prob:.6f}%)')
    values = [(rejection(n, Fraction(23, 100))[1], n) for n in range(220, 262)]
    lo, hi = min(values), max(values)
    print(f'cut=23.0%, every integer n=220..261: min={lo[0]:.9f} ({100 * lo[0]:.6f}%) at n={lo[1]}; '
          f'max={hi[0]:.9f} ({100 * hi[0]:.6f}%) at n={hi[1]}')
    print('All n=220..261 at cut=23.0%:')
    for prob, n in sorted(values, key=lambda pair: pair[1]):
        print(f'  n={n}: {prob:.9f} ({100 * prob:.6f}%)')
    # This is the rejected standalone pooling remedy in the folded plan.
    for n in (440, 522):
        first, prob = rejection(n, Fraction(19, 100))
        print(f'Pooling only, cut=19.0%, n={n}, reject X>={first}: '
              f'probability={prob:.9f} ({100 * prob:.6f}%)')

    print('\nBACKFILL RESTRICTION BY CVE IDENTIFIER YEAR')
    print('Keep 0 <= dateAdded year - CVE identifier year <= 1; no publication-date field is available')
    for label, sub in periods:
        recent = [e for e in sub if 0 <= identifier_age(e) <= 1]
        show_mix(recent, label)
    print('\nSHARES OF ADDITIONS AT LEAST THREE IDENTIFIER-YEARS OLD (all additions, including no usable CWE)')
    for label, years in [('2021', {'2021'}), ('2022', {'2022'}), ('2021-22 combined', {'2021', '2022'})]:
        sub = [e for e in entries if e['dateAdded'][:4] in years]
        old = sum(identifier_age(e) >= 3 for e in sub)
        print(f'{label}: {old}/{len(sub)} = {100 * old / len(sub):.6f}% ({100 * old / len(sub):.1f}%)')

    print('\nTIE-BREAK OVERLAPS (CWE-20 included)')
    for label, sub in periods:
        usable = sum(tally(sub)[k] for k in 'abcd')
        overlap = collections.Counter(''.join(sorted(hits(e))) for e in sub if len(hits(e)) > 1)
        total = sum(overlap.values())
        print(f'{label}: overlap entries={total}/{usable}; '
              + ', '.join(f'{k}={overlap[k]}' for k in ('ab', 'ac', 'bc', 'abc')))
        print(f'  Any one class changes by at most {total}/{usable} = {100 * total / usable:.6f} percentage points; '
              f'rounded to one decimal: {100 * total / usable:.1f} points')
        print('  Six priority orders, numerators a/b/c/d:')
        for order in itertools.permutations('abc'):
            counts = tally(sub, order=order)
            print(f'    {">".join(order)}: ' + '/'.join(str(counts[k]) for k in 'abcd'))
    print('\nPASS: saved-feed metadata, classifications and CSV cross-checks agree')


if __name__ == '__main__':
    main()
