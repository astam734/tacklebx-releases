#!/usr/bin/env python3
"""M8-G4: KEV weakness-class mix, v3 line 181 (RB-D §3.3). Standard library only.

usage: python3 -I kev_mix.py <RB snapshot json> <live CISA json> <live CISA csv> > kev_mix_out.txt

1. REPRODUCTION on RB's own snapshot (catalogVersion 2026.10.21, the file RB's kev_classify.py read:
   RACE-NOTE/codecrux/data/kev_2026.10.21.json), with RB's class lists copied verbatim from
   RACE-NOTE/codecrux/kev_classify.py lines 23-32 and RB's rule:
   - an entry's CWE ids are the 'cwes' strings of the form CWE-<digits>; NVD-CWE-noinfo / NVD-CWE-Other / none -> (e);
   - overlap: an entry with several CWEs takes the FIRST matching class in the order a, b, c, d
     (any CWE in A -> a; else any in B -> b; else any in C -> c; else d);
   - CWE-20 sensitivity: CWE-20 counted in (b), or ignored, so an entry whose only CWE is 20 goes to (e);
   - periods by the 'dateAdded' field: year <= 2023 ("2021-23") and year >= 2024 ("2024-26");
   - shares are of entries with a usable CWE (classes a-d); (e) is the excluded count.
2. PROVENANCE CHECK: every entry of RB's snapshot is looked up in today's CISA feed (same cveID, dateAdded, cwes).
3. UPDATED CALCULATION on today's CISA feed (JSON), same rules; the CSV is parsed as a cross-check of counts.
4. Additions per dateAdded year (line 161 aggregate-count question)."""
import collections, csv, json, sys

# RB class lists, verbatim from RACE-NOTE/codecrux/kev_classify.py (lines 23-32)
A = {119, 120, 121, 122, 123, 124, 125, 126, 127, 131, 134, 170, 190, 191, 401, 415, 416, 457, 466, 467, 468, 469, 476,
     562, 590, 680, 690, 761, 762, 763, 786, 787, 788, 805, 806, 822, 823, 824, 825, 843, 908, 909, 1284}
B = {20, 22, 23, 24, 35, 36, 59, 61, 73, 74, 77, 78, 79, 80, 88, 89, 90, 91, 93, 94, 95, 96, 97, 98, 113, 116, 117, 138,
     140, 141, 150, 158, 159, 172, 176, 177, 179, 180, 184, 434, 436, 444, 470, 502, 564, 601, 611, 641, 643, 652, 776,
     829, 913, 915, 917, 918, 1236, 1321, 1336}
C = {250, 254, 255, 256, 257, 259, 260, 264, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 279, 280, 281,
     282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 302, 303, 304, 305, 306, 307, 308, 309, 312, 313,
     319, 345, 346, 347, 352, 359, 384, 425, 441, 497, 521, 522, 523, 532, 538, 539, 548, 549, 551, 552, 565, 566, 598,
     612, 613, 620, 639, 640, 642, 648, 668, 669, 672, 693, 703, 732, 749, 798, 799, 836, 840, 841, 842, 862, 863, 912,
     922, 923, 939, 940, 1021, 1188, 1220, 1230, 1231, 1233, 1390, 1391, 1392, 200, 201, 209, 215}
NAMES = {'a': 'memory corruption', 'b': 'injection/input handling', 'c': 'authn/authz/access policy',
         'd': 'other classified', 'e': 'no usable CWE (excluded)'}


def ids_of(cwes):
    return [int(c[4:]) for c in (cwes or []) if c.startswith('CWE-') and c[4:].isdigit()]


def classify(cwes, cwe20_in_b=True):
    ids = ids_of(cwes)
    if not ids: return 'e'
    if any(i in A for i in ids): return 'a'
    if any(i in B and (i != 20 or cwe20_in_b) for i in ids): return 'b'
    if any(i in C for i in ids): return 'c'
    if ids == [20] and not cwe20_in_b: return 'e'
    return 'd'


def classes_hit(cwes):
    ids = ids_of(cwes)
    return {k for k, S in (('a', A), ('b', B), ('c', C)) if any(i in S for i in ids)}


def mix(entries, label, out):
    periods = (('2021-23 (dateAdded year <= 2023)', lambda e: e['dateAdded'][:4] <= '2023'),
               ('2024-26 (dateAdded year >= 2024)', lambda e: e['dateAdded'][:4] >= '2024'))
    res = {}
    for cwe20_in_b in (True, False):
        out(f"\n[{label}] CWE-20 {'in (b)' if cwe20_in_b else 'ignored (CWE-20-only -> e)'}")
        for pname, sel in periods:
            sub = [e for e in entries if sel(e)]
            cnt = collections.Counter(classify(e.get('cwes'), cwe20_in_b) for e in sub)
            n_cls = sum(cnt[k] for k in 'abcd')
            multi = sum(1 for e in sub if len(classes_hit(e.get('cwes'))) > 1)
            first, last = min(e['dateAdded'] for e in sub), max(e['dateAdded'] for e in sub)
            out(f"  {pname}: dateAdded {first}..{last}; entries {len(sub)}; usable CWE (denominator) {n_cls}; "
                f"excluded (e) {cnt['e']}; entries whose CWEs hit >1 of classes a/b/c (resolved by order a>b>c) {multi}")
            for k in 'abcd':
                out(f"    ({k}) {NAMES[k]:28s} {cnt[k]:4d} / {n_cls} = {cnt[k] / n_cls:.3f}")
            res[(cwe20_in_b, pname[:7])] = {k: (cnt[k], n_cls) for k in 'abcde'}
    return res


def main():
    rb_path, live_json, live_csv = sys.argv[1:4]
    out = print
    rb = json.load(open(rb_path, encoding='utf-8'))
    live = json.load(open(live_json, encoding='utf-8'))
    out(f"RB snapshot: {rb_path}\n  catalogVersion {rb['catalogVersion']}, dateReleased {rb['dateReleased']}, "
        f"count {rb['count']}, entries {len(rb['vulnerabilities'])}")
    out(f"Live CISA feed: {live_json}\n  catalogVersion {live['catalogVersion']}, dateReleased {live['dateReleased']}, "
        f"count {live['count']}, entries {len(live['vulnerabilities'])}")

    # 1. reproduction
    out("\n=== 1. REPRODUCTION on RB's snapshot, RB's mapping and rules ===")
    mix(rb['vulnerabilities'], 'RB snapshot 2026.10.21', out)

    # 2. provenance check of RB's snapshot against today's CISA feed
    out("\n=== 2. PROVENANCE: RB snapshot entries vs today's CISA feed ===")
    L = {e['cveID']: e for e in live['vulnerabilities']}
    missing = [e['cveID'] for e in rb['vulnerabilities'] if e['cveID'] not in L]
    d_date = [e['cveID'] for e in rb['vulnerabilities'] if e['cveID'] in L and L[e['cveID']]['dateAdded'] != e['dateAdded']]
    d_cwe = [e['cveID'] for e in rb['vulnerabilities'] if e['cveID'] in L and
             sorted(L[e['cveID']].get('cwes') or []) != sorted(e.get('cwes') or [])]
    newer = [e for e in live['vulnerabilities'] if e['cveID'] not in {x['cveID'] for x in rb['vulnerabilities']}]
    out(f"  RB entries absent from live feed: {len(missing)} {missing[:10]}")
    out(f"  RB entries whose dateAdded differs in live feed: {len(d_date)} {d_date[:10]}")
    out(f"  RB entries whose CWE list differs in live feed: {len(d_cwe)} {d_cwe[:10]}")
    out(f"  live entries not in RB snapshot: {len(newer)}; their dateAdded: "
        f"{sorted(collections.Counter(e['dateAdded'] for e in newer).items())}")

    # 3. updated calculation
    out("\n=== 3. UPDATED CALCULATION on today's CISA feed (same mapping and rules) ===")
    mix(live['vulnerabilities'], f"live {live['catalogVersion']}", out)
    rows = list(csv.DictReader(open(live_csv, encoding='utf-8', newline='')))
    js = {e['cveID']: e for e in live['vulnerabilities']}
    agree = sum(1 for r in rows if r['cveID'] in js and r['dateAdded'] == js[r['cveID']]['dateAdded'])
    out(f"  CSV cross-check: {len(rows)} rows; {agree} match a JSON entry with the same dateAdded")

    # 4. additions per year
    out("\n=== 4. Additions per dateAdded year (live feed) ===")
    yr = collections.Counter(e['dateAdded'][:4] for e in live['vulnerabilities'])
    for y in sorted(yr):
        out(f"  {y}: {yr[y]}")
    out(f"  first dateAdded {min(e['dateAdded'] for e in live['vulnerabilities'])}; "
        f"last {max(e['dateAdded'] for e in live['vulnerabilities'])}")


if __name__ == '__main__':
    main()
